package kryzex.modules.macros;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroActionSetting;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroColorSetting;
import kryzex.module.settings.MacroModeSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.misc.MacroModule;
import kryzex.util.SecureString;

/**
 * Auto Builder (Corz v3.1) bridge.
 *
 * The original Corz AutoBuilder runs unchanged inside the embedded "corz" mod (Yarn sources, remapped by Loom).
 * This module only toggles it and mirrors its settings into the Kryzex GUI. Corz classes are reached through
 * reflection so Kryzex (intermediary) never has to compile against the Yarn-named Corz sources.
 */
public final class AutoBuilderBridge
extends MacroModule {
    private static final String REGISTRY = "ai.auth.ModuleRegistry";
    private static final String AUTO_BUILDER = "com.corz.client.categories.bots.AutoBuilder";

    private Object corz;
    private boolean mirrored;
    private final List<Mirror> mirrors = new ArrayList<Mirror>();
    private final Set<String> usedIds = new HashSet<String>();

    public AutoBuilderBridge() {
        super("auto-builder", "Auto Builder", "Builds schematics automatically (Corz AutoBuilder v3.1)", MacroCategories.DONUT_MACROS);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public List<Setting> getSettings() {
        this.ensureMirrored();
        return super.getSettings();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.ensureMirrored();
        if (this.corz == null) {
            System.err.println("Kryzex: Auto Builder - Corz runtime not found (is the embedded corz mod loaded?)");
            this.requestDisable();
            return;
        }
        this.sync();
        this.call(this.corz, "setEnabled", new Class<?>[]{Boolean.TYPE}, Boolean.TRUE);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (this.corz == null) return;
        this.sync();
        this.call(this.corz, "setEnabled", new Class<?>[]{Boolean.TYPE}, Boolean.FALSE);
    }

    @MacroSubscribe
    public void onTick(MacroTickEvent event) {
        this.sync();
        if (this.corz == null) return;
        Object on = this.call(this.corz, "isEnabled", new Class<?>[0]);
        // AutoBuilder switches itself off when it is done / aborts: follow it.
        if (on instanceof Boolean && !((Boolean)on).booleanValue()) {
            this.requestDisable();
        }
    }

    // ------------------------------------------------------------------ Corz access (reflection)

    private Object findCorz() {
        try {
            Class<?> registry = Class.forName(REGISTRY);
            Class<?> builder = Class.forName(AUTO_BUILDER);
            return registry.getMethod("getModule", Class.class).invoke(null, builder);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object call(Object target, String name, Class<?>[] types, Object ... args) {
        try {
            Method method = target.getClass().getMethod(name, types);
            return method.invoke(target, args);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object field(Object target, String name) {
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                Field f = clazz.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(target);
            }
            catch (Throwable throwable) {
                clazz = clazz.getSuperclass();
            }
        }
        return null;
    }

    private double dbl(Object target, String name, double fallback) {
        Object v = this.field(target, name);
        return v instanceof Number ? ((Number)v).doubleValue() : fallback;
    }

    private JsonElement json(Object setting) {
        Object v = this.call(setting, "getJsonValue", new Class<?>[0]);
        return v instanceof JsonElement ? (JsonElement)v : null;
    }

    private void apply(Object setting, JsonElement element) {
        this.call(setting, "applyJsonValue", new Class<?>[]{JsonElement.class}, element);
    }

    private static String kind(Object setting) {
        for (Class<?> c = setting.getClass(); c != null; c = c.getSuperclass()) {
            switch (c.getSimpleName()) {
                case "ButtonBase": return "button";
                case "BooleanSetting": return "bool";
                case "IntegerSetting": return "int";
                case "DoubleSetting": return "double";
                case "EnumSetting": return "enum";
                case "RangeSetting": return "range";
                case "StringBase": return "string";
                case "ColorSetting": return "color";
                default: break;
            }
        }
        return "";
    }

    // ------------------------------------------------------------------ settings mirror

    private static final class Mirror {
        Supplier<String> kzGet;
        Consumer<String> kzSet;
        Supplier<String> corzGet;
        Consumer<String> corzSet;
        String lastKz;
        String lastCorz;
    }

    private static boolean same(String a, String b) {
        if (a == null || b == null) return a == b;
        if (a.equals(b)) return true;
        try {
            if (a.indexOf('|') >= 0 && b.indexOf('|') >= 0) {
                String[] x = a.split("\\|");
                String[] y = b.split("\\|");
                if (x.length != y.length) return false;
                for (int i = 0; i < x.length; ++i) {
                    if (Math.abs(Double.parseDouble(x[i]) - Double.parseDouble(y[i])) > 1.0E-3) return false;
                }
                return true;
            }
            return Math.abs(Double.parseDouble(a) - Double.parseDouble(b)) <= 1.0E-3;
        }
        catch (NumberFormatException numberFormatException) {
            return false;
        }
    }

    private String uniqueId(String name) {
        String base = "ab-" + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-");
        String id = base;
        int n = 2;
        while (!this.usedIds.add(id)) {
            id = base + "-" + n++;
        }
        return id;
    }

    private void ensureMirrored() {
        if (this.mirrored) return;
        this.corz = this.findCorz();
        if (this.corz == null) return;
        Object list = this.call(this.corz, "getSettings", new Class<?>[0]);
        if (!(list instanceof List)) return;
        this.mirrored = true;
        List<Object> ordered = new ArrayList<Object>((List<?>)list);
        // Keep only the whitelisted settings, in the whitelist order.
        ordered.removeIf(o -> this.priority(o) == Integer.MAX_VALUE);
        ordered.sort((a, b) -> Integer.compare(this.priority(a), this.priority(b)));
        for (Object setting : ordered) {
            try {
                this.mirrorOne(setting);
            }
            catch (Throwable throwable) {
                System.err.println("Kryzex: Auto Builder - could not mirror a setting: " + throwable);
            }
        }
    }

    /**
     * ONLY these Corz settings are shown in the Kryzex GUI, in this order. Everything else stays inside Corz
     * with its saved/default value and is simply not mirrored. To show more later, add the exact Corz name here.
     */
    private static final List<String> SHOW = java.util.Arrays.asList(
        // schematic (.litematic) + buy
        "Open Folder", "Refresh", "Preview Schematic", "Cancel Preview", "Origin: Player", "Origin: Looking",
        "Buy Materials", "Auto-Buy Key", "Buy Mode", "Spending Limit Per Item", "Spending Limit Per Buy", "Max Total Spend",
        // speed / human
        "Fast Place (V3)", "Fast Place Delay (ms)", "Places / Tick", "Placement Delay", "Reach", "V2Speed",
        "Human Flow (V3)", "Human Flow Level %",
        // eating
        "Auto Eat", "Eat At"
    );

    private int priority(Object setting) {
        Object n = this.call(setting, "getSettingName", new Class<?>[0]);
        int i = n == null ? -1 : SHOW.indexOf(n.toString());
        return i < 0 ? Integer.MAX_VALUE : i;
    }

    private void mirrorOne(Object s) {
        String kind = AutoBuilderBridge.kind(s);
        if (kind.isEmpty()) return;
        Object hidden = this.call(s, "isHiddenFromList", new Class<?>[0]);
        if (hidden instanceof Boolean && ((Boolean)hidden).booleanValue()) return;
        Object nameObj = this.call(s, "getSettingName", new Class<?>[0]);
        String name = nameObj == null ? "Setting" : nameObj.toString();
        if (kind.equals("button")) {
            // Corz buttons just run an action; no value to sync.
            this.addSetting(this.uniqueId(name), new MacroActionSetting(name, () -> this.call(s, "updateAction", new Class<?>[0])));
            return;
        }
        JsonElement cur = this.json(s);
        if (cur == null) return;
        Mirror m = new Mirror();
        switch (kind) {
            case "bool": {
                MacroBoolSetting kz = this.addSetting(this.uniqueId(name), new MacroBoolSetting(name, cur.getAsBoolean()));
                m.kzGet = () -> String.valueOf(kz.get());
                m.kzSet = v -> kz.set(Boolean.parseBoolean(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsBoolean());
                m.corzSet = v -> this.apply(s, new JsonPrimitive(Boolean.parseBoolean(v)));
                break;
            }
            case "int": {
                int min = ((Number)this.call(s, "getMinValue", new Class<?>[0])).intValue();
                int max = ((Number)this.call(s, "getMaxValue", new Class<?>[0])).intValue();
                int step = ((Number)this.call(s, "getStepSize", new Class<?>[0])).intValue();
                MacroNumberSetting kz = this.addSetting(this.uniqueId(name), new MacroNumberSetting(name, cur.getAsInt(), min, max).step(Math.max(1, step)));
                m.kzGet = () -> String.valueOf(kz.getInt());
                m.kzSet = v -> kz.set((float)Double.parseDouble(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsInt());
                m.corzSet = v -> this.apply(s, new JsonPrimitive((int)Math.round(Double.parseDouble(v))));
                break;
            }
            case "double": {
                double min = this.dbl(s, "minValue", 0.0);
                double max = this.dbl(s, "maxValue", 100.0);
                double step = this.dbl(s, "stepSize", 0.1);
                MacroNumberSetting kz = this.addSetting(this.uniqueId(name), new MacroNumberSetting(name, (float)cur.getAsDouble(), (float)min, (float)max).step((float)step));
                m.kzGet = () -> String.valueOf(kz.get());
                m.kzSet = v -> kz.set((float)Double.parseDouble(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsDouble());
                m.corzSet = v -> this.apply(s, new JsonPrimitive(Double.parseDouble(v)));
                break;
            }
            case "enum": {
                Object opts = this.call(s, "getOptions", new Class<?>[0]);
                List<String> options = new ArrayList<String>();
                if (opts instanceof List) {
                    for (Object o : (List<?>)opts) options.add(String.valueOf(o));
                }
                if (options.isEmpty()) return;
                MacroModeSetting kz = this.addSetting(this.uniqueId(name), new MacroModeSetting(name, cur.getAsString(), options.toArray(new String[0])));
                m.kzGet = kz::get;
                m.kzSet = kz::set;
                m.corzGet = () -> this.json(s).getAsString();
                m.corzSet = v -> this.apply(s, new JsonPrimitive(v));
                break;
            }
            case "range": {
                double rMin = this.dbl(s, "rangeMin", 0.0);
                double rMax = this.dbl(s, "rangeMax", 100.0);
                double step = this.dbl(s, "step", 0.1);
                JsonObject o = cur.getAsJsonObject();
                MacroNumberSetting lo = this.addSetting(this.uniqueId(name + " min"), new MacroNumberSetting(name + " (min)", (float)o.get("min").getAsDouble(), (float)rMin, (float)rMax).step((float)step));
                MacroNumberSetting hi = this.addSetting(this.uniqueId(name + " max"), new MacroNumberSetting(name + " (max)", (float)o.get("max").getAsDouble(), (float)rMin, (float)rMax).step((float)step));
                m.kzGet = () -> lo.get() + "|" + hi.get();
                m.kzSet = v -> {
                    String[] p = v.split("\\|");
                    lo.set((float)Double.parseDouble(p[0]));
                    hi.set((float)Double.parseDouble(p[1]));
                };
                m.corzGet = () -> {
                    JsonObject c = this.json(s).getAsJsonObject();
                    return c.get("min").getAsDouble() + "|" + c.get("max").getAsDouble();
                };
                m.corzSet = v -> {
                    String[] p = v.split("\\|");
                    JsonObject c = new JsonObject();
                    c.addProperty("min", Double.parseDouble(p[0]));
                    c.addProperty("max", Double.parseDouble(p[1]));
                    this.apply(s, c);
                };
                break;
            }
            case "string": {
                StringSetting kz = new StringSetting(SecureString.of(name), cur.getAsString());
                super.addSetting(kz);
                m.kzGet = kz::getValue;
                m.kzSet = kz::setValue;
                m.corzGet = () -> this.json(s).getAsString();
                m.corzSet = v -> this.apply(s, new JsonPrimitive(v));
                break;
            }
            case "color": {
                MacroColorSetting kz = this.addSetting(this.uniqueId(name), new MacroColorSetting(name, cur.getAsInt()));
                m.kzGet = () -> String.valueOf(kz.argb());
                m.kzSet = v -> kz.setArgb(Integer.parseInt(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsInt());
                m.corzSet = v -> this.apply(s, new JsonPrimitive(Integer.parseInt(v)));
                break;
            }
            default:
                return;
        }
        m.lastKz = m.kzGet.get();
        m.lastCorz = m.corzGet.get();
        this.mirrors.add(m);
    }

    /** Kryzex GUI <-> Corz settings. Whichever side changed since the last sync wins. */
    private void sync() {
        for (Mirror m : this.mirrors) {
            try {
                String kz = m.kzGet.get();
                String cz = m.corzGet.get();
                if (!AutoBuilderBridge.same(kz, m.lastKz)) {
                    m.corzSet.accept(kz);
                    cz = m.corzGet.get();
                    m.lastKz = kz;
                    m.lastCorz = cz;
                } else if (!AutoBuilderBridge.same(cz, m.lastCorz)) {
                    m.kzSet.accept(cz);
                    m.lastKz = m.kzGet.get();
                    m.lastCorz = cz;
                }
            }
            catch (Throwable throwable) {
                // keep going; a single bad setting must not break the rest
            }
        }
    }
}
