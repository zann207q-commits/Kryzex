package kryzex.modules.donut;

import net.minecraft.class_2596;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import kryzex.event.MacroRender3DEvent;
import kryzex.event.PacketReceiveEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.gui.NotificationToast;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.misc.MacroModule;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.PixelPerDepth;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_1935;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2676;
import net.minecraft.class_2678;
import net.minecraft.class_638;

public final class PrimeChunkFinder
extends MacroModule {
    private static String[] a;
    private final BoolSetting tracers = new BoolSetting("Tracers", true);
    private final Map<class_1923, Integer> updates = new ConcurrentHashMap<class_1923, Integer>();
    private final Map<class_1923, Long> candidates = new ConcurrentHashMap<class_1923, Long>();
    private final Set<class_1923> excluded = ConcurrentHashMap.newKeySet();
    private final Set<class_1923> highlights = ConcurrentHashMap.newKeySet();
    private class_638 world;
    private int ticks;

    public PrimeChunkFinder() {
        super("prime-chunk-finder", "Prime Chunk Finder", "Highlights repeated chunk lighting updates.", MacroCategories.BASE_FINDING);
        super.addSettings(new Setting[]{this.tracers});
    }

    private void t() {
        this.updates.clear();
        this.candidates.clear();
        this.excluded.clear();
        this.highlights.clear();
        this.ticks = 0;
    }

    @Override
    public void onEnable() {
        this.t();
        this.world = this.mc.field_1687;
    }

    @Override
    public void onDisable() {
        this.t();
        this.world = null;
    }

    @Subscribe
    public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
        if (packetReceiveEvent.packet instanceof class_2678) {
            this.t();
            return;
        }
        class_2596<?> packet = packetReceiveEvent.packet;
        if (!(packet instanceof class_2676)) return;
        class_2676 class_26762 = (class_2676)packet;
        if (this.mc.field_1724 == null) return;
        class_1923 chunkPos = new class_1923(class_26762.method_11558(), class_26762.method_11554());
        if (Math.abs(chunkPos.field_9181 - (this.mc.field_1724.method_31477() >> 4)) > 50 || Math.abs(chunkPos.field_9180 - (this.mc.field_1724.method_31479() >> 4)) > 50) {
            return;
        }
        if (this.excluded.contains(chunkPos) || this.updates.size() >= 12000 || this.updates.merge(chunkPos, 1, Integer::sum) < 5) return;
        this.candidates.putIfAbsent(chunkPos, System.nanoTime());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        double d;
        if (this.world != this.mc.field_1687) {
            this.t();
            this.world = this.mc.field_1687;
        }
        if (this.mc.field_1724 == null || this.world == null) {
            return;
        }
        if (++this.ticks % 20 == 0) {
            int n = this.mc.field_1724.method_31477() >> 4;
            int n2 = this.mc.field_1724.method_31479() >> 4;
            Predicate<class_1923> predicate = arg_0 -> PrimeChunkFinder.lmbd$onTick$0(n, n2, arg_0);
            this.updates.keySet().removeIf(predicate);
            this.candidates.keySet().removeIf(predicate);
            this.excluded.removeIf(predicate);
            this.highlights.removeIf(predicate);
        }
        if ((d = this.mc.field_1724.method_18798().method_37267() * 20.0) > 10.0 && this.ticks % 5 == 0) {
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)String.format(Locale.ROOT, "Speed: %.2f bps%s", d, d > 18.0 ? "          \u00a7cSlow down!" : "")), true);
        }
        if (this.mc.field_1724.method_23318() <= 30.0) {
            return;
        }
        long l = System.nanoTime();
        int n = 0;
        for (Map.Entry<class_1923, Long> entry : this.candidates.entrySet()) {
            class_1923 class_19232;
            if (n >= 4) return;
            if (l - entry.getValue() < 1000000000L || !this.candidates.remove(entry.getKey(), entry.getValue()) || !this.excluded.add(class_19232 = entry.getKey())) continue;
            class_1923 class_19233 = new class_1923(class_19232.field_9181 + ThreadLocalRandom.current().nextInt(-1, 2), class_19232.field_9180 + ThreadLocalRandom.current().nextInt(-1, 2));
            this.highlights.add(class_19233);
            ++n;
            NotificationToast.addOrUpdate(new class_1799((class_1935)class_1802.field_28866), "Prime Chunk Finder", (class_2561)class_2561.method_43470((String)("X: " + (class_19233.field_9181 * 16 + 8) + " Z: " + (class_19233.field_9180 * 16 + 8))), false);
            for (int i = -3; i <= 3; ++i) {
                for (int j = -3; j <= 3; ++j) {
                    class_1923 class_19234 = new class_1923(class_19232.field_9181 + i, class_19232.field_9180 + j);
                    this.excluded.add(class_19234);
                    this.candidates.remove(class_19234);
                    this.updates.remove(class_19234);
                }
            }
        }
    }

    @MacroSubscribe
    public void onMacroRender3D(MacroRender3DEvent macroRender3DEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.highlights.isEmpty()) {
            return;
        }
        int n = this.mc.field_1724.method_31477() >> 4;
        int n2 = this.mc.field_1724.method_31479() >> 4;
        PixelPerDepth pixelPerDepth = PixelPerDepth.forFrame(macroRender3DEvent.partialTick);
        for (class_1923 class_19232 : this.highlights) {
            if (Math.abs(class_19232.field_9181 - n) > 50 || Math.abs(class_19232.field_9180 - n2) > 50) continue;
            class_238 class_2382 = new class_238((double)((class_19232.field_9181 - 1) * 16), 63.0, (double)((class_19232.field_9180 - 1) * 16), (double)((class_19232.field_9181 - 1) * 16 + 48), 63.1, (double)((class_19232.field_9180 - 1) * 16 + 48));
            if (macroRender3DEvent.frustum != null && !macroRender3DEvent.frustum.method_23093(class_2382)) continue;
            class_12180.method_75541((class_238)class_2382, (class_12179)class_12179.method_75539(671153920)).method_75533();
            pixelPerDepth.box(class_2382, -1275003136, 1.0f);
            if (!this.tracers.getValue()) continue;
            pixelPerDepth.line(InverseProjectionScratch.getTracerStart(this.mc.field_1773.method_19418()), new class_243((double)(class_19232.field_9181 * 16 + 8), 63.05, (double)(class_19232.field_9180 * 16 + 8)), -939458816, 1.0f);
        }
    }

    private static boolean lmbd$onTick$0(int n, int n2, class_1923 class_19232) {
        if (Math.abs(class_19232.field_9181 - n) > 50) return true;
        if (Math.abs(class_19232.field_9180 - n2) <= 50) return false;
        return true;
    }

    static {
        a = new String[]{"Highlights repeated chunk lighting updates.", "Prime Chunk Finder", "Tracers", "prime-chunk-finder"};
    }
}
