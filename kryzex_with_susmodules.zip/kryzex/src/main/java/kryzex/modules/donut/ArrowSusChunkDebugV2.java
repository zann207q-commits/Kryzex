package kryzex.modules.donut;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.ArrowChunkAppear;
import kryzex.util.ArrowNotify;
import kryzex.util.ArrowScan;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.KingMcGuard;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1604;
import net.minecraft.class_1646;
import net.minecraft.class_1693;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2601;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_3986;
import net.minecraft.class_4184;
import net.minecraft.class_4482;
import net.minecraft.class_4587;
import net.minecraft.class_5689;
import net.minecraft.class_5691;
import net.minecraft.class_5704;
import net.minecraft.class_638;
import net.minecraft.class_7132;
import net.minecraft.class_7133;
import net.minecraft.class_7923;
import net.minecraft.class_8961;
import net.minecraft.class_9199;

/**
 * Port of the Meteor "Sus Chunk Debug V2" (arrowaddon) to the Kryzex module API.
 * Finds bases / base farms underground (through anti-xray) from block entities, blocks, entities,
 * beehives, pillagers, llamas, dripstone, bamboo, kelp and vines. Reports only one sus zone at a time.
 */
public final class ArrowSusChunkDebugV2
extends Module {
    private static final int K_BE = 1;
    private static final int K_FARM = 2;
    private static final int K_BUILD = 4;
    private static final int K_ENTITY = 8;
    private static final int K_CROP = 16;
    private static final int K_ROT = 32;
    private static final int K_AMETHYST = 64;
    private static final int K_BEE = 128;
    private static final int K_PILLAGER = 256;
    private static final int K_LLAMA = 512;
    private static final int K_DRIP = 1024;
    private static final int K_VINE = 2048;
    private static final int K_BAMBOO = 4096;
    private static final BInfo NONE = new BInfo(0.0f, 0, false, 0);
    private static final int M_STRONGHOLD = 1;
    private static final int M_DEEP = 2;
    private static final int M_MINE = 3;
    private static final int M_TRIAL = 4;
    private static final int M_DUNGEON = 5;
    private static final int M_SCULK = 6;
    private static final Map<class_2248, Boolean> TARGET_CACHE = new ConcurrentHashMap<class_2248, Boolean>();
    private static final Map<class_2248, BInfo> INFO_CACHE = new ConcurrentHashMap<class_2248, BInfo>();
    private static final int MAX_SIGS_PER_CHUNK = 500;
    private static final int FARM_SIGS_FOR_FARM = 4;
    private static final double ISOLATION_DIST = 10.0;
    private static final long GRACE_MS = 10000L;
    private static final double SWITCH_FACTOR = 2.0;
    private static final long SINGLE_KEY = 1L;
    public final NumberSetting sensitivity = new NumberSetting(SecureString.of("Sensitivity"), 1.0, 40.0, 3.0, 1.0);
    public final NumberSetting minSignals = new NumberSetting(SecureString.of("Min Signals"), 2.0, 30.0, 3.0, 1.0);
    public final NumberSetting minDepth = new NumberSetting(SecureString.of("Min Depth"), 0.0, 64.0, 6.0, 1.0);
    public final NumberSetting confirmSeconds = new NumberSetting(SecureString.of("Confirm Seconds"), 0.0, 10.0, 1.0, 1.0);
    public final NumberSetting minY = new NumberSetting(SecureString.of("Min Y"), -64.0, 100.0, -64.0, 1.0);
    public final NumberSetting maxY = new NumberSetting(SecureString.of("Max Y"), -64.0, 320.0, 90.0, 1.0);
    public final NumberSetting mergeRadius = new NumberSetting(SecureString.of("Merge Radius"), 1.0, 6.0, 2.0, 1.0);
    public final BoolSetting undergroundBase = new BoolSetting(SecureString.of("Underground Base"), true);
    public final NumberSetting baseMinBlocks = new NumberSetting(SecureString.of("Base Min Blocks"), 1.0, 20.0, 2.0, 1.0);
    public final BoolSetting nearbyChat = new BoolSetting(SecureString.of("Nearby Blocks Chat"), true);
    public final NumberSetting nearbyRadius = new NumberSetting(SecureString.of("Nearby Radius"), 16.0, 1024.0, 535.0, 1.0);
    public final BoolSetting chatCoords = new BoolSetting(SecureString.of("Chat Coords"), true);
    public final BoolSetting blockEntities = new BoolSetting(SecureString.of("Block Entities"), true);
    public final BoolSetting blocks = new BoolSetting(SecureString.of("Block Signals"), true);
    public final BoolSetting entities = new BoolSetting(SecureString.of("Entity Signals"), false);
    public final BoolSetting structureFilter = new BoolSetting(SecureString.of("Natural Structure Filter"), true);
    public final NumberSetting structureMargin = new NumberSetting(SecureString.of("Structure Margin"), 0.0, 3.0, 1.0, 1.0);
    public final BoolSetting beeNest = new BoolSetting(SecureString.of("Bee Nest"), true);
    public final BoolSetting beeUndergroundOnly = new BoolSetting(SecureString.of("Bee Underground Only"), false);
    public final NumberSetting beehiveMinY = new NumberSetting(SecureString.of("Bee Min Y"), -64.0, 128.0, 50.0, 1.0);
    public final NumberSetting beehiveMaxY = new NumberSetting(SecureString.of("Bee Max Y"), -64.0, 320.0, 200.0, 1.0);
    public final BoolSetting includeBeehives = new BoolSetting(SecureString.of("Bee: Beehives"), true);
    public final BoolSetting includeBeeNests = new BoolSetting(SecureString.of("Bee: Bee Nests"), true);
    public final BoolSetting beeLevel0 = new BoolSetting(SecureString.of("Bee Level 0"), false);
    public final BoolSetting beeLevel1 = new BoolSetting(SecureString.of("Bee Level 1"), false);
    public final BoolSetting beeLevel2 = new BoolSetting(SecureString.of("Bee Level 2"), false);
    public final BoolSetting beeLevel3 = new BoolSetting(SecureString.of("Bee Level 3"), false);
    public final BoolSetting beeLevel4 = new BoolSetting(SecureString.of("Bee Level 4"), false);
    public final BoolSetting beeLevel5 = new BoolSetting(SecureString.of("Bee Level 5"), true);
    public final BoolSetting pillager = new BoolSetting(SecureString.of("Pillager"), true);
    public final NumberSetting pillagerMin = new NumberSetting(SecureString.of("Pillager Min"), 1.0, 20.0, 1.0, 1.0);
    public final BoolSetting llama = new BoolSetting(SecureString.of("Llama"), true);
    public final NumberSetting llamaMin = new NumberSetting(SecureString.of("Llama Min"), 1.0, 20.0, 1.0, 1.0);
    public final NumberSetting llamaDistance = new NumberSetting(SecureString.of("Llama Max Distance"), 16.0, 256.0, 128.0, 1.0);
    public final BoolSetting amethyst = new BoolSetting(SecureString.of("Amethyst"), true);
    public final BoolSetting amethystDetect = new BoolSetting(SecureString.of("Amethyst Detect"), true);
    public final NumberSetting amethystMin = new NumberSetting(SecureString.of("Amethyst Min Clusters"), 1.0, 32.0, 3.0, 1.0);
    public final BoolSetting dripstone = new BoolSetting(SecureString.of("Dripstone"), true);
    public final NumberSetting stalactiteMinLength = new NumberSetting(SecureString.of("Stalactite Min Length"), 1.0, 16.0, 4.0, 1.0);
    public final NumberSetting stalagmiteMinLength = new NumberSetting(SecureString.of("Stalagmite Min Length"), 1.0, 16.0, 8.0, 1.0);
    public final NumberSetting dripstoneAlertLength = new NumberSetting(SecureString.of("Dripstone Alert Length"), 1.0, 20.0, 8.0, 1.0);
    public final BoolSetting grownBamboo = new BoolSetting(SecureString.of("Bamboo"), true);
    public final NumberSetting bambooMin = new NumberSetting(SecureString.of("Bamboo Min Count"), 1.0, 128.0, 8.0, 1.0);
    public final NumberSetting bambooMinHeight = new NumberSetting(SecureString.of("Bamboo Min Height"), 2.0, 16.0, 12.0, 1.0);
    public final BoolSetting bambooUndergroundOnly = new BoolSetting(SecureString.of("Bamboo Underground Only"), true);
    public final BoolSetting grownCaveVines = new BoolSetting(SecureString.of("Cave Vines"), true);
    public final NumberSetting caveVinesMin = new NumberSetting(SecureString.of("Cave Vines Min Count"), 1.0, 128.0, 8.0, 1.0);
    public final BoolSetting grownKelp = new BoolSetting(SecureString.of("Grown Kelp"), true);
    public final NumberSetting kelpMin = new NumberSetting(SecureString.of("Kelp Min Count"), 1.0, 64.0, 4.0, 1.0);
    public final BoolSetting grownVines = new BoolSetting(SecureString.of("Grown Vines"), true);
    public final NumberSetting vineMin = new NumberSetting(SecureString.of("Vine Min Count"), 1.0, 64.0, 8.0, 1.0);
    public final NumberSetting vineMinLength = new NumberSetting(SecureString.of("Vine Min Length"), 15.0, 35.0, 20.0, 1.0);
    public final NumberSetting vineMinY = new NumberSetting(SecureString.of("Vine Min Y"), -64.0, 128.0, -64.0, 1.0);
    public final NumberSetting vineMaxY = new NumberSetting(SecureString.of("Vine Max Y"), -64.0, 320.0, 320.0, 1.0);
    public final BoolSetting rotatedDeepslate = new BoolSetting(SecureString.of("Rotated Deepslate"), true);
    public final NumberSetting rotatedMin = new NumberSetting(SecureString.of("Rotated Deepslate Min"), 1.0, 32.0, 2.0, 1.0);
    public final BoolSetting rotatedEsp = new BoolSetting(SecureString.of("Rotated ESP"), true);
    public final BoolSetting rotatedTracers = new BoolSetting(SecureString.of("Rotated Tracers"), true);
    public final ColorSetting susColor = new ColorSetting(SecureString.of("Color"), 0xFFFF2828);
    public final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 10.0, 255.0, 70.0, 1.0);
    public final BoolSetting outline = new BoolSetting(SecureString.of("Outline"), false);
    public final NumberSetting renderY = new NumberSetting(SecureString.of("Render Y"), -64.0, 320.0, 64.0, 1.0);
    public final NumberSetting length = new NumberSetting(SecureString.of("Box Length"), 4.0, 160.0, 40.0, 1.0);
    public final NumberSetting width = new NumberSetting(SecureString.of("Box Width"), 2.0, 32.0, 6.0, 1.0);
    public final NumberSetting maxWidth = new NumberSetting(SecureString.of("Max Width"), 4.0, 128.0, 48.0, 1.0);
    private final Map<Long, ChunkSig> results = new ConcurrentHashMap<Long, ChunkSig>();
    private final Map<Long, long[]> track = new ConcurrentHashMap<Long, long[]>();
    private final Set<Long> scanned = ConcurrentHashMap.newKeySet();
    private final Map<Long, long[]> burst = new ConcurrentHashMap<Long, long[]>();
    private volatile Map<Long, List<Sig>> lastEntBuckets = Collections.emptyMap();
    private final Map<Long, List<Target>> targetMap = new ConcurrentHashMap<Long, List<Target>>();
    private final Set<Long> notifiedTargets = ConcurrentHashMap.newKeySet();
    private final Set<Long> naturalChunks = ConcurrentHashMap.newKeySet();
    private final Set<Long> inFlight = ConcurrentHashMap.newKeySet();
    private final Set<Long> announced = new HashSet<Long>();
    private final Map<Long, Integer> pendingChunks = new ConcurrentHashMap<Long, Integer>();
    private volatile List<Zone> zones = Collections.emptyList();
    private Zone primary;
    private final ArrowChunkAppear ANIM = new ArrowChunkAppear();
    private final ArrowChunkAppear ANIM_ESP = new ArrowChunkAppear();
    private final ArrowChunkAppear ANIM_TRACER = new ArrowChunkAppear();
    private volatile List<int[]> rotBlocks = Collections.emptyList();
    private static final int MAX_ROT_ESP = 64;
    private ExecutorService executor;
    private class_638 lastWorld;
    private int tickCounter;

    public ArrowSusChunkDebugV2() {
        super(SecureString.of("Arrow Sus Chunk Debug V2"), SecureString.of("Finds bases / base farms underground (through anti-xray) from block entities, blocks, entities, beehives, pillagers, llamas, dripstone, bamboo and kelp / vines. Few false positives, only 1 sus chunk (KingMC)"), -1, Category.BASE_FINDING);
        this.addSettings(new Setting[]{
            this.sensitivity, this.minSignals, this.minDepth, this.confirmSeconds, this.minY, this.maxY,
            this.mergeRadius, this.undergroundBase, this.baseMinBlocks, this.nearbyChat, this.nearbyRadius, this.chatCoords,
            this.blockEntities, this.blocks, this.entities, this.structureFilter, this.structureMargin, this.beeNest,
            this.beeUndergroundOnly, this.beehiveMinY, this.beehiveMaxY, this.includeBeehives, this.includeBeeNests, this.beeLevel0,
            this.beeLevel1, this.beeLevel2, this.beeLevel3, this.beeLevel4, this.beeLevel5, this.pillager,
            this.pillagerMin, this.llama, this.llamaMin, this.llamaDistance, this.amethyst, this.amethystDetect,
            this.amethystMin, this.dripstone, this.stalactiteMinLength, this.stalagmiteMinLength, this.dripstoneAlertLength, this.grownBamboo,
            this.bambooMin, this.bambooMinHeight, this.bambooUndergroundOnly, this.grownCaveVines, this.caveVinesMin, this.grownKelp,
            this.kelpMin, this.grownVines, this.vineMin, this.vineMinLength, this.vineMinY, this.vineMaxY,
            this.rotatedDeepslate, this.rotatedMin, this.rotatedEsp, this.rotatedTracers, this.susColor, this.alpha,
            this.outline, this.renderY, this.length, this.width, this.maxWidth});
    }

    private static boolean bool(BoolSetting s) {
        return s.getValue();
    }

    private static int num(NumberSetting s) {
        return s.getIntValue();
    }

    @Override
    public void onEnable() {
        if (!KingMcGuard.check(this)) {
            return;
        }
        this.clearState();
        this.executor = Executors.newFixedThreadPool(Math.max(1, Math.min(3, Runtime.getRuntime().availableProcessors() / 2)), r -> {
            Thread t = new Thread(r, "ArrowSusChunkDebugV2-scan");
            t.setDaemon(true);
            return t;
        });
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (KingMcGuard.wasDenied(this)) {
            return;
        }
        if (this.executor != null && !this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
        this.executor = null;
        this.clearState();
        super.onDisable();
    }

    public void resetState() {
        this.clearState();
    }

    private void clearState() {
        this.results.clear();
        this.track.clear();
        this.naturalChunks.clear();
        this.burst.clear();
        this.pendingChunks.clear();
        this.lastEntBuckets = Collections.emptyMap();
        this.targetMap.clear();
        this.notifiedTargets.clear();
        this.scanned.clear();
        this.inFlight.clear();
        this.announced.clear();
        this.primary = null;
        this.zones = Collections.emptyList();
        this.rotBlocks = Collections.emptyList();
        this.ANIM.clear();
        this.ANIM_ESP.clear();
        this.ANIM_TRACER.clear();
        this.lastWorld = null;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent event) {
        if (this.executor == null) {
            return;
        }
        // The chunk may not be in the world yet when the packet arrives; resolve it on the next ticks.
        this.pendingChunks.put(class_1923.method_8331((int)event.packet.method_11523(), (int)event.packet.method_11524()), 0);
    }

    /** Re-scans chunks whose data packet just arrived (as soon as they exist in the client world). */
    private void drainPending(Cfg cfg) {
        if (this.pendingChunks.isEmpty()) {
            return;
        }
        Map<Long, List<Sig>> ents = this.lastEntBuckets;
        for (Map.Entry<Long, Integer> entry : this.pendingChunks.entrySet()) {
            long key = entry.getKey();
            class_2818 chunk = this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)key), class_1923.method_8332((long)key));
            if (chunk != null) {
                this.pendingChunks.remove(key);
                this.scanned.remove(key);
                this.submitScan(chunk, cfg, ents.getOrDefault(key, List.of()));
                continue;
            }
            if (entry.getValue() < 100) {
                entry.setValue(entry.getValue() + 1);
                continue;
            }
            this.pendingChunks.remove(key);
        }
    }

    @Subscribe
    public void onTick(TickEvent event) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            if (this.lastWorld != null) {
                this.clearState();
            }
            return;
        }
        if (this.lastWorld != this.mc.field_1687) {
            this.clearState();
            this.lastWorld = this.mc.field_1687;
        }
        if (!this.mc.field_1687.method_8597().comp_642()) {
            return;
        }
        long now = System.currentTimeMillis();
        ++this.tickCounter;
        if (this.tickCounter % 2 == 0) {
            this.drainPending(this.snapshot());
            this.fastPass(now);
        }
        if (this.tickCounter % 10 != 0) {
            return;
        }
        Cfg cfg = this.snapshot();
        Map<Long, List<Sig>> entBuckets = ArrowSusChunkDebugV2.bool(this.entities) || ArrowSusChunkDebugV2.bool(this.pillager) || ArrowSusChunkDebugV2.bool(this.llama) ? this.collectEntities(cfg) : Collections.emptyMap();
        this.lastEntBuckets = entBuckets;
        class_1923 c = this.mc.field_1724.method_31476();
        int r = Math.min(8, this.mc.field_1690.method_38521() + 1);
        boolean full = this.tickCounter % 60 == 0;
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                boolean near;
                class_2818 chunk = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz);
                if (chunk == null) continue;
                near = Math.abs(dx) <= 2 && Math.abs(dz) <= 2;
                if (!near && !full && this.scanned.contains(chunk.method_12004().method_8324())) continue;
                this.submitScan(chunk, cfg, entBuckets.getOrDefault(chunk.method_12004().method_8324(), List.of()));
            }
        }
        this.track.entrySet().removeIf(e -> now - ((long[])e.getValue())[1] > 10000L);
        this.results.keySet().removeIf(k -> !this.track.containsKey(k) || this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)k), class_1923.method_8332((long)k)) == null);
        this.naturalChunks.removeIf(k -> this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)k), class_1923.method_8332((long)k)) == null);
        this.burst.keySet().removeIf(k -> this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)k), class_1923.method_8332((long)k)) == null);
        this.scanned.removeIf(k -> this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)k), class_1923.method_8332((long)k)) == null);
        this.targetMap.keySet().removeIf(k -> this.mc.field_1687.method_2935().method_21730(class_1923.method_8325((long)k), class_1923.method_8332((long)k)) == null);
        this.rebuildZones(now);
        if (ArrowSusChunkDebugV2.bool(this.nearbyChat)) {
            this.announceNearby();
        }
    }

    private void fastPass(long now) {
        Cfg cfg = this.snapshot();
        class_1923 c = this.mc.field_1724.method_31476();
        int r = Math.min(8, this.mc.field_1690.method_38521() + 1);
        Map<Long, List<Sig>> ents = this.lastEntBuckets;
        int budget = 6;
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                class_2818 chunk;
                boolean due;
                long key = class_1923.method_8331((int)(c.field_9181 + dx), (int)(c.field_9180 + dz));
                long[] b = this.burst.get(key);
                boolean fresh = !this.scanned.contains(key);
                boolean bl = due = b != null && now >= b[1];
                if (!fresh && !due || this.inFlight.contains(key) || (chunk = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz)) == null) continue;
                this.submitScan(chunk, cfg, ents.getOrDefault(key, List.of()));
                if (b == null) {
                    this.burst.put(key, new long[]{1L, now + 400L});
                } else if (b[0] == 1L) {
                    b[0] = 2L;
                    b[1] = now + 1500L;
                } else {
                    this.burst.remove(key);
                }
                if (--budget > 0) continue;
                return;
            }
        }
    }

    private void announceNearby() {
        class_2338 pp = this.mc.field_1724.method_24515();
        int rad = ArrowSusChunkDebugV2.num(this.nearbyRadius);
        double maxSq = (double)(rad + 32) * (double)(rad + 32);
        this.notifiedTargets.removeIf(k -> class_2338.method_10092((long)k).method_10262((class_2382)pp) > maxSq);
        long radSq = (long)rad * (long)rad;
        ArrayList<String> found = new ArrayList<String>();
        block0: for (List<Target> list : this.targetMap.values()) {
            for (Target t : list) {
                long dz;
                if (found.size() >= 12) continue block0;
                long dx = t.x() - pp.method_10263();
                if (dx * dx + (dz = (long)(t.z() - pp.method_10260())) * dz > radSq || !this.notifiedTargets.add(class_2338.method_10064((int)t.x(), (int)t.y(), (int)t.z()))) continue;
                found.add(t.block().method_9518().getString() + " [" + t.x() + ", " + t.y() + ", " + t.z() + "]");
            }
        }
        if (!found.isEmpty()) {
            ArrowNotify.chat("SusChunkDebugV2", ("Machine blocks nearby: " + String.join((CharSequence)" | ", found)));
        }
    }

    private Cfg snapshot() {
        int lo = Math.min(ArrowSusChunkDebugV2.num(this.minY), ArrowSusChunkDebugV2.num(this.maxY));
        int hi = Math.max(ArrowSusChunkDebugV2.num(this.minY), ArrowSusChunkDebugV2.num(this.maxY));
        return new Cfg(lo, hi, ArrowSusChunkDebugV2.num(this.minDepth), ArrowSusChunkDebugV2.num(this.minSignals), ArrowSusChunkDebugV2.num(this.sensitivity), ArrowSusChunkDebugV2.bool(this.blockEntities), ArrowSusChunkDebugV2.bool(this.blocks), ArrowSusChunkDebugV2.bool(this.grownKelp), ArrowSusChunkDebugV2.num(this.kelpMin), ArrowSusChunkDebugV2.bool(this.grownVines), ArrowSusChunkDebugV2.num(this.vineMin), ArrowSusChunkDebugV2.num(this.vineMinLength), ArrowSusChunkDebugV2.bool(this.structureFilter), ArrowSusChunkDebugV2.bool(this.rotatedDeepslate), ArrowSusChunkDebugV2.num(this.rotatedMin), ArrowSusChunkDebugV2.bool(this.amethyst), ArrowSusChunkDebugV2.bool(this.amethystDetect), ArrowSusChunkDebugV2.num(this.amethystMin), ArrowSusChunkDebugV2.bool(this.undergroundBase), ArrowSusChunkDebugV2.num(this.baseMinBlocks), ArrowSusChunkDebugV2.bool(this.beeNest), ArrowSusChunkDebugV2.bool(this.beeUndergroundOnly), ArrowSusChunkDebugV2.bool(this.pillager), ArrowSusChunkDebugV2.num(this.pillagerMin), ArrowSusChunkDebugV2.bool(this.grownBamboo), ArrowSusChunkDebugV2.num(this.bambooMin), ArrowSusChunkDebugV2.bool(this.bambooUndergroundOnly), ArrowSusChunkDebugV2.bool(this.grownCaveVines), ArrowSusChunkDebugV2.num(this.caveVinesMin), ArrowSusChunkDebugV2.num(this.bambooMinHeight), Math.min(ArrowSusChunkDebugV2.num(this.vineMinY), ArrowSusChunkDebugV2.num(this.vineMaxY)), Math.max(ArrowSusChunkDebugV2.num(this.vineMinY), ArrowSusChunkDebugV2.num(this.vineMaxY)), Math.min(ArrowSusChunkDebugV2.num(this.beehiveMinY), ArrowSusChunkDebugV2.num(this.beehiveMaxY)), Math.max(ArrowSusChunkDebugV2.num(this.beehiveMinY), ArrowSusChunkDebugV2.num(this.beehiveMaxY)), ArrowSusChunkDebugV2.bool(this.includeBeehives), ArrowSusChunkDebugV2.bool(this.includeBeeNests), (ArrowSusChunkDebugV2.bool(this.beeLevel0) ? 1 : 0) | (ArrowSusChunkDebugV2.bool(this.beeLevel1) ? 2 : 0) | (ArrowSusChunkDebugV2.bool(this.beeLevel2) ? 4 : 0) | (ArrowSusChunkDebugV2.bool(this.beeLevel3) ? 8 : 0) | (ArrowSusChunkDebugV2.bool(this.beeLevel4) ? 16 : 0) | (ArrowSusChunkDebugV2.bool(this.beeLevel5) ? 32 : 0), ArrowSusChunkDebugV2.bool(this.llama), ArrowSusChunkDebugV2.num(this.llamaMin), ArrowSusChunkDebugV2.num(this.llamaDistance), ArrowSusChunkDebugV2.bool(this.dripstone), ArrowSusChunkDebugV2.num(this.stalactiteMinLength), ArrowSusChunkDebugV2.num(this.stalagmiteMinLength), ArrowSusChunkDebugV2.num(this.dripstoneAlertLength));
    }

    private Map<Long, List<Sig>> collectEntities(Cfg cfg) {
        HashMap<Long, List<Sig>> out = new HashMap<Long, List<Sig>>();
        boolean regular = ArrowSusChunkDebugV2.bool(this.entities);
        for (class_1297 e : this.mc.field_1687.method_18112()) {
            int top;
            class_2338 p;
            float w;
            if (cfg.llama() && e instanceof class_3986) {
                double d = cfg.llamaDist();
                if (Math.abs(e.method_23317() - this.mc.field_1724.method_23317()) > d || Math.abs(e.method_23318() - this.mc.field_1724.method_23318()) > d || Math.abs(e.method_23321() - this.mc.field_1724.method_23321()) > d) continue;
                class_2338 lp = e.method_24515();
                out.computeIfAbsent(e.method_31476().method_8324(), k -> new ArrayList()).add(new Sig(lp.method_10263(), lp.method_10264(), lp.method_10260(), 1.0f, 512, false));
                continue;
            }
            if (cfg.pillager() && e instanceof class_1604) {
                class_2338 pp = e.method_24515();
                out.computeIfAbsent(e.method_31476().method_8324(), k -> new ArrayList()).add(new Sig(pp.method_10263(), pp.method_10264(), pp.method_10260(), 1.0f, 256, false));
                continue;
            }
            if (!regular) continue;
            if (e instanceof class_1533 || e instanceof class_1531) {
                w = 0.5f;
            } else if (e instanceof class_1693) {
                w = 0.8f;
            } else {
                if (!(e instanceof class_1646)) continue;
                w = 0.3f;
            }
            if ((p = e.method_24515()).method_10264() < cfg.minY() || p.method_10264() > cfg.maxY()) continue;
            try {
                top = this.mc.field_1687.method_8624(class_2902.class_2903.field_13202, p.method_10263(), p.method_10260());
            }
            catch (Throwable t) {
                continue;
            }
            if (p.method_10264() > top - cfg.depth()) continue;
            out.computeIfAbsent(e.method_31476().method_8324(), k -> new ArrayList()).add(new Sig(p.method_10263(), p.method_10264(), p.method_10260(), w, 8, false));
        }
        return out;
    }

    private void submitScan(class_2818 chunk, Cfg cfg, List<Sig> entSigs) {
        ExecutorService ex = this.executor;
        if (ex == null || ex.isShutdown() || this.mc.field_1687 == null) {
            return;
        }
        long key = chunk.method_12004().method_8324();
        if (!this.inFlight.add(key)) {
            return;
        }
        this.scanned.add(key);
        class_638 world = this.mc.field_1687;
        List<class_2586> bes = cfg.bes() || cfg.bee() ? new ArrayList<class_2586>(chunk.method_12214().values()) : List.of();
        ArrayList<Sig> ents = new ArrayList<Sig>(entSigs);
        try {
            ex.submit(() -> {
                try {
                    ChunkSig res = this.scan(chunk, world, cfg, bes, ents);
                    long now = System.currentTimeMillis();
                    if (res.targets().isEmpty()) {
                        this.targetMap.remove(key);
                    } else {
                        this.targetMap.put(key, res.targets());
                    }
                    if (this.naturalChunks.contains(key)) {
                        this.results.remove(key);
                        this.track.remove(key);
                        return;
                    }
                    if (res.valid()) {
                        this.results.put(key, res);
                        this.track.compute(key, (k, v) -> {
                            long[] lArray;
                            if (v == null) {
                                long[] lArray2 = new long[3];
                                lArray2[0] = now;
                                lArray2[1] = now;
                                lArray = lArray2;
                                lArray2[2] = 1L;
                            } else {
                                long[] lArray3 = new long[3];
                                lArray3[0] = v[0];
                                lArray3[1] = now;
                                lArray = lArray3;
                                lArray3[2] = v[2] + 1L;
                            }
                            return lArray;
                        });
                    }
                }
                catch (Throwable t) {
                    this.scanned.remove(key);
                }
                finally {
                    this.inFlight.remove(key);
                }
            });
        }
        catch (Throwable t) {
            this.scanned.remove(key);
            this.inFlight.remove(key);
        }
    }

    private ChunkSig scan(class_2818 chunk, class_638 world, Cfg cfg, List<class_2586> bes, List<Sig> ents) {
        boolean dripForced;
        boolean llamaForced;
        boolean pillForced;
        boolean beeForced;
        ArrayList<int[]> cl;
        int[] cnt;
        int cx = chunk.method_12004().field_9181;
        int cz = chunk.method_12004().field_9180;
        int startX = chunk.method_12004().method_8326();
        int startZ = chunk.method_12004().method_8328();
        List<Sig> sigs = new ArrayList<Sig>();
        boolean natural = false;
        boolean hard = false;
        int[] markers = new int[8];
        int[] surf = new int[256];
        Arrays.fill(surf, Integer.MIN_VALUE);
        ArrayList<Sig> beeSigs = new ArrayList<Sig>();
        ArrayList<Sig> dripSigs = new ArrayList<Sig>();
        HashSet<Long> dripSeen = new HashSet<Long>();
        HashSet<Long> beeSeen = new HashSet<Long>();
        ArrayList<Target> targets = new ArrayList<Target>();
        HashMap<Long, Boolean> artifactMemo = new HashMap<Long, Boolean>();
        HashSet<Long> seenPos = new HashSet<Long>();
        for (class_2586 be : bes) {
            float w;
            if (be instanceof class_4482) {
                if (!cfg.bee() || beeSigs.size() >= 16) continue;
                class_2338 bp = be.method_11016();
                if (!ArrowSusChunkDebugV2.isValidBeehive(be.method_11010(), bp.method_10264(), cfg) || cfg.beeUnderground() && !ArrowSusChunkDebugV2.underground(chunk, surf, bp.method_10263(), bp.method_10264(), bp.method_10260(), cfg) || !beeSeen.add(bp.method_10063())) continue;
                beeSigs.add(new Sig(bp.method_10263(), bp.method_10264(), bp.method_10260(), 1.0f, 128, false));
                continue;
            }
            if (!cfg.bes() || sigs.size() >= 500) continue;
            if (be instanceof class_8961 || be instanceof class_9199 || be instanceof class_7133 || be instanceof class_7132 || be instanceof class_5704) {
                hard = true;
                continue;
            }
            if (be instanceof class_2636) {
                natural = true;
                continue;
            }
            class_2338 p = be.method_11016();
            if (!ArrowSusChunkDebugV2.underground(chunk, surf, p.method_10263(), p.method_10264(), p.method_10260(), cfg) || (w = ArrowSusChunkDebugV2.beWeight(be)) <= 0.0f) continue;
            boolean farm = be instanceof class_2614 || be instanceof class_2601;
            boolean prone = be instanceof class_2601;
            sigs.add(new Sig(p.method_10263(), p.method_10264(), p.method_10260(), w, farm ? 2 : 1, prone));
            seenPos.add(p.method_10063());
            if (!farm || targets.size() >= 64 || cfg.filter() && ArrowSusChunkDebugV2.structureArtifact(world, p.method_10263(), p.method_10264(), p.method_10260(), artifactMemo)) continue;
            targets.add(new Target(p.method_10263(), p.method_10264(), p.method_10260(), be.method_11010().method_26204()));
        }
        ArrayList<Sig> kelpSigs = new ArrayList<Sig>();
        ArrayList<Sig> vineSigs = new ArrayList<Sig>();
        ArrayList<Sig> bambooSigs = new ArrayList<Sig>();
        ArrayList<Sig> caveSigs = new ArrayList<Sig>();
        int caveYoung = 0;
        ArrayList<Sig> rotSigs = new ArrayList<Sig>();
        int kelpYoung = 0;
        if (cfg.blocks() || cfg.kelp() || cfg.vines() || cfg.rot() || cfg.bamboo() || cfg.cave() || cfg.bee() || cfg.drip()) {
            class_2338.class_2339 mp = new class_2338.class_2339();
            class_2826[] sections = chunk.method_12006();
            int bottom = chunk.method_31607();
            for (int i = 0; i < sections.length; ++i) {
                boolean beeInRange;
                class_2826 s = sections[i];
                int baseY = bottom + i * 16;
                if (s == null || s.method_38292()) continue;
                boolean secInRange = baseY + 15 >= cfg.minY() && baseY <= cfg.maxY();
                boolean vineInRange = cfg.vines() && baseY + 15 >= cfg.vineLo() && baseY <= cfg.vineHi();
                boolean bl = beeInRange = cfg.bee() && baseY + 15 >= cfg.beeLo() && baseY <= cfg.beeHi();
                if (!secInRange && !cfg.kelp() && !vineInRange && !beeInRange && !cfg.cave() && !cfg.drip() && (!cfg.bamboo() || cfg.bambooUnder()) || !s.method_19523(st -> {
                    class_2248 b = st.method_26204();
                    return cfg.kelp() && b == class_2246.field_9993 || vineInRange && b == class_2246.field_10597 || beeInRange && (b == class_2246.field_20422 || b == class_2246.field_20421) || cfg.drip() && b == class_2246.field_28048 || cfg.bamboo() && b == class_2246.field_10211 || cfg.cave() && b == class_2246.field_28675 || secInRange && cfg.rot() && b == class_2246.field_28888 || secInRange && cfg.blocks() && ArrowSusChunkDebugV2.infoOf(b) != NONE;
                })) continue;
                for (int x = 0; x < 16; ++x) {
                    for (int y = 0; y < 16; ++y) {
                        int wy = baseY + y;
                        for (int z = 0; z < 16; ++z) {
                            BInfo info;
                            class_2680 st2 = s.method_12254(x, y, z);
                            class_2248 b = st2.method_26204();
                            if (cfg.kelp() && b == class_2246.field_9993) {
                                if (st2.method_28498((class_2769)class_2741.field_12517) && (Integer)st2.method_11654((class_2769)class_2741.field_12517) >= 25) {
                                    kelpSigs.add(new Sig(startX + x, wy, startZ + z, 0.5f, 16, false));
                                    continue;
                                }
                                ++kelpYoung;
                                continue;
                            }
                            if (cfg.cave() && b == class_2246.field_28675) {
                                if (st2.method_28498((class_2769)class_2741.field_12517) && (Integer)st2.method_11654((class_2769)class_2741.field_12517) >= 25) {
                                    caveSigs.add(new Sig(startX + x, wy, startZ + z, 0.5f, 16, false));
                                    continue;
                                }
                                ++caveYoung;
                                continue;
                            }
                            if (cfg.bamboo() && b == class_2246.field_10211) {
                                if (!ArrowSusChunkDebugV2.columnGrounded(chunk, mp, startX + x, wy, startZ + z, class_2246.field_10211, 24, cfg.bambooHeight()) || cfg.bambooUnder() && !ArrowSusChunkDebugV2.underground(chunk, surf, startX + x, wy, startZ + z, cfg)) continue;
                                bambooSigs.add(new Sig(startX + x, wy, startZ + z, 0.5f, 4096, false));
                                continue;
                            }
                            if (cfg.vines() && b == class_2246.field_10597) {
                                if (wy < cfg.vineLo() || wy > cfg.vineHi() || !ArrowSusChunkDebugV2.vineGrounded(chunk, mp, startX + x, wy, startZ + z, cfg)) continue;
                                vineSigs.add(new Sig(startX + x, wy, startZ + z, 0.5f, 2048, false));
                                continue;
                            }
                            if (cfg.bee() && (b == class_2246.field_20422 || b == class_2246.field_20421)) {
                                if (beeSigs.size() >= 16 || !ArrowSusChunkDebugV2.isValidBeehive(st2, wy, cfg) || cfg.beeUnderground() && !ArrowSusChunkDebugV2.underground(chunk, surf, startX + x, wy, startZ + z, cfg) || !beeSeen.add(class_2338.method_10064((int)(startX + x), (int)wy, (int)(startZ + z)))) continue;
                                beeSigs.add(new Sig(startX + x, wy, startZ + z, 1.0f, 128, false));
                                continue;
                            }
                            if (cfg.drip() && b == class_2246.field_28048) {
                                int up;
                                if (dripSigs.size() >= 16 || !ArrowSusChunkDebugV2.isDripTip(st2)) continue;
                                int wx = startX + x;
                                int wz = startZ + z;
                                int dn = ArrowSusChunkDebugV2.dripDown(chunk, mp, wx, wy, wz);
                                if (dn >= Math.max(cfg.stalactiteMin(), cfg.dripAlert()) && dripSeen.add(class_2338.method_10064((int)wx, (int)(wy - dn + 1), (int)wz))) {
                                    dripSigs.add(new Sig(wx, wy - dn + 1, wz, 1.0f, 1024, false));
                                }
                                if ((up = ArrowSusChunkDebugV2.dripUp(chunk, mp, wx, wy, wz)) < Math.max(cfg.stalagmiteMin(), cfg.dripAlert()) || !dripSeen.add(class_2338.method_10064((int)wx, (int)(wy + up - 1), (int)wz))) continue;
                                dripSigs.add(new Sig(wx, wy + up - 1, wz, 1.0f, 1024, false));
                                continue;
                            }
                            if (cfg.rot() && secInRange && b == class_2246.field_28888 && st2.method_28498((class_2769)class_2741.field_12496) && st2.method_11654((class_2769)class_2741.field_12496) != class_2350.class_2351.field_11052) {
                                if (!ArrowSusChunkDebugV2.underground(chunk, surf, startX + x, wy, startZ + z, cfg) || !ArrowSusChunkDebugV2.buried(world, startX + x, wy, startZ + z)) continue;
                                rotSigs.add(new Sig(startX + x, wy, startZ + z, 2.0f, 32, false));
                                continue;
                            }
                            if (!secInRange || !cfg.blocks() || (info = ArrowSusChunkDebugV2.infoOf(b)) == NONE || info.marker() == 0 && seenPos.contains(class_2338.method_10064((int)(startX + x), (int)wy, (int)(startZ + z)))) continue;
                            if (info.marker() < 0) {
                                if (info.marker() == -2) {
                                    hard = true;
                                    continue;
                                }
                                natural = true;
                                continue;
                            }
                            if (info.marker() > 0) {
                                int n = info.marker();
                                markers[n] = markers[n] + 1;
                                continue;
                            }
                            if (sigs.size() >= 500 || !ArrowSusChunkDebugV2.underground(chunk, surf, startX + x, wy, startZ + z, cfg)) continue;
                            sigs.add(new Sig(startX + x, wy, startZ + z, info.w(), info.kind(), info.prone()));
                            if (!ArrowSusChunkDebugV2.isTargetBlock(b) || targets.size() >= 64 || cfg.filter() && ArrowSusChunkDebugV2.structureArtifact(world, startX + x, wy, startZ + z, artifactMemo)) continue;
                            targets.add(new Target(startX + x, wy, startZ + z, b));
                        }
                    }
                }
            }
        }
        if (markers[6] >= 2 || markers[4] >= 12) {
            hard = true;
        }
        if (markers[2] >= 20 || markers[1] >= 16 || markers[3] >= 10 || markers[5] >= 6) {
            natural = true;
        }
        ArrayList<Sig> pillSigs = new ArrayList<Sig>();
        ArrayList<Sig> llamaSigs = new ArrayList<Sig>();
        for (Sig e : ents) {
            if (e.kind() == 256) {
                pillSigs.add(e);
                continue;
            }
            if (e.kind() == 512) {
                llamaSigs.add(e);
                continue;
            }
            if (sigs.size() >= 500) continue;
            sigs.add(e);
        }
        if (natural && cfg.filter()) {
            sigs.removeIf(Sig::prone);
        }
        if (hard && cfg.filter()) {
            this.naturalChunks.add(chunk.method_12004().method_8324());
            return new ChunkSig(chunk.method_12004().method_8324(), cx, cz, List.of(), 0.0, 0, false, List.of());
        }
        sigs = ArrowSusChunkDebugV2.dropIsolated(sigs);
        boolean amethystForced = false;
        if (cfg.amethyst() && (cnt = ArrowSusChunkDebugV2.amethystPass(chunk, cl = new ArrayList<int[]>(), 8))[0] > 0 && cnt[1] == 0) {
            int[] pos = (int[])cl.get(0);
            sigs.add(new Sig(pos[0], pos[1], pos[2], 1.0f, 64, false));
            if (cfg.amethystDetect() && cnt[0] >= cfg.amethystMin()) {
                for (int i = 1; i < cl.size(); ++i) {
                    int[] q = (int[])cl.get(i);
                    sigs.add(new Sig(q[0], q[1], q[2], 0.5f, 64, false));
                }
                amethystForced = true;
            }
        }
        boolean baseForced = false;
        if (cfg.baseOn() && targets.size() >= cfg.baseMin()) {
            baseForced = true;
            for (int i = 0; i < targets.size() && i < 8; ++i) {
                Target t = (Target)targets.get(i);
                sigs.add(new Sig(t.x(), t.y(), t.z(), 0.5f, 2, false));
            }
        }
        boolean bl = beeForced = !beeSigs.isEmpty();
        if (beeForced) {
            sigs.addAll(beeSigs);
        }
        boolean bl2 = pillForced = cfg.pillager() && pillSigs.size() >= cfg.pillagerMin();
        if (pillForced) {
            sigs.addAll(pillSigs);
        }
        boolean bl3 = llamaForced = cfg.llama() && llamaSigs.size() >= cfg.llamaMin();
        if (llamaForced) {
            sigs.addAll(llamaSigs);
        }
        boolean bl4 = dripForced = cfg.drip() && !dripSigs.isEmpty();
        if (dripForced) {
            sigs.addAll(dripSigs);
        }
        double score = 0.0;
        int kinds = 0;
        int farmSigs = 0;
        for (Sig sg : sigs) {
            score += (double)sg.w();
            kinds |= sg.kind();
            if (sg.kind() != 2) continue;
            ++farmSigs;
        }
        boolean valid = sigs.size() >= cfg.minSignals() && score >= cfg.need();
        boolean cropFlag = false;
        if (cfg.kelp() && kelpSigs.size() >= cfg.kelpMin() && kelpYoung <= kelpSigs.size()) {
            for (Sig k : kelpSigs) {
                if (sigs.size() >= 800) break;
                sigs.add(k);
                score += (double)k.w();
                ++farmSigs;
            }
            cropFlag = true;
        }
        if (cfg.bamboo() && bambooSigs.size() >= cfg.bambooMin()) {
            for (Sig k : bambooSigs) {
                if (sigs.size() >= 800) break;
                sigs.add(k);
                score += (double)k.w();
                ++farmSigs;
            }
            cropFlag = true;
        }
        if (cfg.cave() && caveSigs.size() >= cfg.caveMin() && caveYoung <= caveSigs.size()) {
            for (Sig k : caveSigs) {
                if (sigs.size() >= 800) break;
                sigs.add(k);
                score += (double)k.w();
                ++farmSigs;
            }
            cropFlag = true;
        }
        if (cfg.vines() && vineSigs.size() >= cfg.vineMin()) {
            for (Sig v : vineSigs) {
                if (sigs.size() >= 800) break;
                sigs.add(v);
                score += (double)v.w();
                ++farmSigs;
            }
            cropFlag = true;
        }
        if (cfg.rot() && rotSigs.size() >= cfg.rotMin()) {
            for (Sig r : rotSigs) {
                if (sigs.size() >= 800) break;
                sigs.add(r);
                score += (double)r.w();
            }
            cropFlag = true;
        }
        if (cropFlag || amethystForced || baseForced || beeForced || pillForced || llamaForced || dripForced) {
            valid = true;
            if (score < cfg.need()) {
                score = cfg.need();
            }
        }
        return new ChunkSig(chunk.method_12004().method_8324(), cx, cz, sigs, score, farmSigs, valid, targets);
    }

    private static boolean isTargetBlock(class_2248 b) {
        return TARGET_CACHE.computeIfAbsent(b, k -> {
            String id = class_7923.field_41175.method_10221(k).method_12832();
            return id.equals("observer") || id.equals("piston") || id.equals("sticky_piston") || id.equals("note_block") || id.equals("hopper") || id.equals("dropper") || id.equals("dispenser");
        });
    }

    private static boolean structureArtifact(class_638 world, int x, int y, int z, Map<Long, Boolean> memo) {
        long ck = ArrowSusChunkDebugV2.cell(x >> 2, y >> 2, z >> 2);
        Boolean cached = memo.get(ck);
        if (cached != null) {
            return cached;
        }
        boolean found = false;
        class_2338.class_2339 mp = new class_2338.class_2339();
        block0: for (int dx = -6; dx <= 6; dx += 2) {
            for (int dy = -4; dy <= 4; dy += 2) {
                for (int dz = -6; dz <= 6; dz += 2) {
                    BInfo info;
                    class_2680 st = world.method_8320((class_2338)mp.method_10103(x + dx, y + dy, z + dz));
                    if (st.method_26215() || (info = ArrowSusChunkDebugV2.infoOf(st.method_26204())).marker() != -2 && info.marker() != 6 && info.marker() != 4) continue;
                    found = true;
                    break block0;
                }
            }
        }
        memo.put(ck, found);
        return found;
    }

    private static boolean buried(class_638 world, int x, int y, int z) {
        class_2338 pos = new class_2338(x, y, z);
        for (class_2350 d : class_2350.values()) {
            if (!world.method_8320(pos.method_10093(d)).method_26215()) continue;
            return false;
        }
        return true;
    }

    private static int[] amethystPass(class_2818 chunk, List<int[]> out, int maxPos) {
        class_2826[] secs = chunk.method_12006();
        int bottom = chunk.method_31607();
        int sx = chunk.method_12004().method_8326();
        int sz = chunk.method_12004().method_8328();
        int clusters = 0;
        int buds = 0;
        for (int i = 0; i < secs.length; ++i) {
            class_2826 sec = secs[i];
            if (sec == null || sec.method_38292() || !sec.method_19523(ArrowScan::isRelevant)) continue;
            for (int x = 0; x < 16; ++x) {
                for (int y = 0; y < 16; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        class_2248 b = sec.method_12254(x, y, z).method_26204();
                        if (b == class_2246.field_27161) {
                            ++clusters;
                            if (out.size() >= maxPos) continue;
                            out.add(new int[]{sx + x, bottom + i * 16 + y, sz + z});
                            continue;
                        }
                        if (!ArrowScan.isBud(b)) continue;
                        ++buds;
                    }
                }
            }
        }
        return new int[]{clusters, buds};
    }

    private static boolean underground(class_2818 chunk, int[] surf, int wx, int wy, int wz, Cfg cfg) {
        if (wy < cfg.minY() || wy > cfg.maxY()) {
            return false;
        }
        int idx = (wz & 0xF) << 4 | wx & 0xF;
        int top = surf[idx];
        if (top == Integer.MIN_VALUE) {
            try {
                top = chunk.method_12005(class_2902.class_2903.field_13202, wx & 0xF, wz & 0xF);
            }
            catch (Throwable t) {
                return false;
            }
            surf[idx] = top;
        }
        return wy <= top - cfg.depth();
    }

    private static List<Sig> dropIsolated(List<Sig> in) {
        if (in.size() < 2) {
            return in.size() == 1 ? new ArrayList() : in;
        }
        HashMap<Long, List<Sig>> grid = new HashMap<Long, List<Sig>>();
        for (Sig s : in) {
            grid.computeIfAbsent(ArrowSusChunkDebugV2.cell(s.x() >> 3, s.y() >> 3, s.z() >> 3), k -> new ArrayList()).add(s);
        }
        double lim = 100.0;
        ArrayList<Sig> out = new ArrayList<Sig>(in.size());
        for (Sig s : in) {
            boolean friend = false;
            int gx = s.x() >> 3;
            int gy = s.y() >> 3;
            int gz = s.z() >> 3;
            block2: for (int dx = -1; dx <= 1; ++dx) {
                for (int dy = -1; dy <= 1; ++dy) {
                    for (int dz = -1; dz <= 1; ++dz) {
                        List<Sig> l = grid.get(ArrowSusChunkDebugV2.cell(gx + dx, gy + dy, gz + dz));
                        if (l == null) continue;
                        for (Sig o : l) {
                            double ddz;
                            double ddy;
                            double ddx;
                            if (o == s || !((ddx = (double)(o.x() - s.x())) * ddx + (ddy = (double)(o.y() - s.y())) * ddy + (ddz = (double)(o.z() - s.z())) * ddz <= lim)) continue;
                            friend = true;
                            break block2;
                        }
                    }
                }
            }
            if (!friend) continue;
            out.add(s);
        }
        return out;
    }

    private static long cell(int x, int y, int z) {
        return (long)(x & 0x1FFFFF) << 42 | (long)(y & 0x1FFFFF) << 21 | (long)(z & 0x1FFFFF);
    }

    private static float beWeight(class_2586 be) {
        if (be instanceof class_2614) {
            return 1.5f;
        }
        if (be instanceof class_2601) {
            return 1.0f;
        }
        if (be instanceof class_2627) {
            return 0.9f;
        }
        if (be instanceof class_2611) {
            return 0.4f;
        }
        return 0.0f;
    }

    private static BInfo infoOf(class_2248 b) {
        return INFO_CACHE.computeIfAbsent(b, SusChunkDebugV2::computeInfo);
    }

    private static BInfo computeInfo(class_2248 b) {
        String id;
        switch (id = class_7923.field_41175.method_10221(b).method_12832()) {
            case "cobweb": 
            case "end_portal_frame": {
                return new BInfo(0.0f, 0, false, -1);
            }
            case "sculk_shrieker": 
            case "sculk_catalyst": 
            case "reinforced_deepslate": 
            case "trial_spawner": 
            case "vault": {
                return new BInfo(0.0f, 0, false, -2);
            }
        }
        if (id.equals("stone_bricks") || id.equals("mossy_stone_bricks") || id.equals("cracked_stone_bricks") || id.equals("chiseled_stone_bricks") || id.equals("stone_brick_stairs") || id.equals("stone_brick_slab")) {
            return new BInfo(0.0f, 0, false, 1);
        }
        if (id.equals("sculk") || id.equals("sculk_vein") || id.equals("sculk_sensor") || id.equals("calibrated_sculk_sensor")) {
            return new BInfo(0.0f, 0, false, 6);
        }
        if (id.contains("deepslate_brick") || id.contains("deepslate_tile") || id.equals("chiseled_deepslate")) {
            return new BInfo(0.0f, 0, false, 2);
        }
        if (id.equals("oak_planks") || id.equals("oak_fence") || id.equals("rail")) {
            return new BInfo(0.0f, 0, false, 3);
        }
        if (id.contains("tuff_brick") || id.equals("chiseled_tuff") || id.contains("polished_tuff") || id.contains("copper_bulb") || id.contains("copper_grate") || id.contains("copper_door") || id.contains("copper_trapdoor") || id.equals("heavy_core")) {
            return new BInfo(0.0f, 0, false, 4);
        }
        if (id.equals("mossy_cobblestone")) {
            return new BInfo(0.0f, 0, false, 5);
        }
        switch (id) {
            case "observer": {
                return new BInfo(1.0f, 2, false, 0);
            }
            case "piston": 
            case "sticky_piston": {
                return new BInfo(0.8f, 2, false, 0);
            }
            case "note_block": {
                return new BInfo(0.5f, 4, false, 0);
            }
            case "hopper": {
                return new BInfo(1.5f, 2, false, 0);
            }
            case "dropper": 
            case "dispenser": {
                return new BInfo(1.0f, 2, true, 0);
            }
            case "ender_chest": {
                return new BInfo(0.4f, 1, false, 0);
            }
        }
        if (id.equals("shulker_box") || id.endsWith("_shulker_box")) {
            return new BInfo(0.9f, 1, false, 0);
        }
        return NONE;
    }

    private static boolean columnGrounded(class_2818 chunk, class_2338.class_2339 mp, int wx, int wy, int wz, class_2248 kind, int cap, int minLen) {
        int len;
        class_2680 below = chunk.method_8320((class_2338)mp.method_10103(wx, wy - 1, wz));
        if (below.method_26215() || below.method_27852(kind)) {
            return false;
        }
        for (len = 1; len < cap && chunk.method_8320((class_2338)mp.method_10103(wx, wy + len, wz)).method_27852(kind); ++len) {
        }
        return len >= minLen;
    }

    private static boolean vineGrounded(class_2818 chunk, class_2338.class_2339 mp, int wx, int wy, int wz, Cfg cfg) {
        class_2680 below = chunk.method_8320((class_2338)mp.method_10103(wx, wy - 1, wz));
        if (below.method_26215() || below.method_27852(class_2246.field_10597)) {
            return false;
        }
        int top = Math.min(cfg.vineHi(), chunk.method_31607() + chunk.method_31605() - 1);
        int len = 1;
        for (int yy = wy + 1; yy <= top && len < cfg.vineLen() && chunk.method_8320((class_2338)mp.method_10103(wx, yy, wz)).method_27852(class_2246.field_10597); ++len, ++yy) {
        }
        return len >= cfg.vineLen();
    }

    private static boolean isDripTip(class_2680 st) {
        return st.method_28498((class_2769)class_5689.field_28051) && ((class_5691)st.method_11654((class_2769)class_5689.field_28051)).name().contains("TIP");
    }

    private static int dripDown(class_2818 chunk, class_2338.class_2339 mp, int wx, int wy, int wz) {
        int minY = chunk.method_31607();
        int len = 0;
        for (int yy = wy; yy >= minY && chunk.method_8320((class_2338)mp.method_10103(wx, yy, wz)).method_27852(class_2246.field_28048); --yy) {
            ++len;
        }
        return len;
    }

    private static int dripUp(class_2818 chunk, class_2338.class_2339 mp, int wx, int wy, int wz) {
        int topY;
        try {
            topY = chunk.method_12005(class_2902.class_2903.field_13202, wx & 0xF, wz & 0xF);
        }
        catch (Throwable t) {
            topY = chunk.method_31607() + chunk.method_31605();
        }
        int len = 0;
        for (int yy = wy; yy < topY && chunk.method_8320((class_2338)mp.method_10103(wx, yy, wz)).method_27852(class_2246.field_28048); ++yy) {
            ++len;
        }
        return len;
    }

    private static boolean isValidBeehive(class_2680 state, int y, Cfg cfg) {
        boolean nest;
        if (y < cfg.beeLo() || y > cfg.beeHi()) {
            return false;
        }
        class_2248 b = state.method_26204();
        boolean hive = cfg.beeHives() && b == class_2246.field_20422;
        boolean bl = nest = cfg.beeNests() && b == class_2246.field_20421;
        if (!hive && !nest) {
            return false;
        }
        if (!state.method_28498((class_2769)class_2741.field_20432)) {
            return false;
        }
        int lvl = (Integer)state.method_11654((class_2769)class_2741.field_20432);
        return lvl >= 0 && lvl <= 5 && (cfg.beeMask() & 1 << lvl) != 0;
    }

    private void rebuildZones(long now) {
        long[] t;
        double need = ArrowSusChunkDebugV2.num(this.sensitivity);
        long confirmMs = (long)ArrowSusChunkDebugV2.num(this.confirmSeconds) * 1000L;
        int rad = ArrowSusChunkDebugV2.num(this.mergeRadius);
        int margin = ArrowSusChunkDebugV2.bool(this.structureFilter) ? ArrowSusChunkDebugV2.num(this.structureMargin) : -1;
        HashMap<Long, ChunkSig> cand = new HashMap<Long, ChunkSig>();
        for (ChunkSig cs : this.results.values()) {
            t = this.track.get(cs.key());
            if (t == null || now - t[0] < confirmMs || t.length > 2 && t[2] < 2L || this.nearNatural(cs.cx(), cs.cz(), margin) || !(cs.score() >= need)) continue;
            cand.put(cs.key(), cs);
        }
        if (cand.isEmpty()) {
            this.primary = null;
            this.rotBlocks = Collections.emptyList();
            this.zones = Collections.emptyList();
            return;
        }
        ArrayList<Zone> all = new ArrayList<Zone>();
        HashSet<Long> seen = new HashSet<Long>();
        Iterator<ChunkSig> candIt = cand.values().iterator();
        while (candIt.hasNext()) {
            ChunkSig start = candIt.next();
            if (!seen.add(start.key())) continue;
            ArrayDeque<ChunkSig> q = new ArrayDeque<ChunkSig>();
            q.add(start);
            ArrayList<ChunkSig> members = new ArrayList<ChunkSig>();
            while (!q.isEmpty()) {
                ChunkSig c = q.poll();
                members.add(c);
                for (int dx = -rad; dx <= rad; ++dx) {
                    for (int dz = -rad; dz <= rad; ++dz) {
                        ChunkSig nb = (ChunkSig)cand.get(class_1923.method_8331((int)(c.cx() + dx), (int)(c.cz() + dz)));
                        if (nb == null || !seen.add(nb.key())) continue;
                        q.add(nb);
                    }
                }
            }
            all.add(this.makeZone(members));
        }
        Zone best = null;
        for (Zone z : all) {
            if (best != null && !(z.score() > best.score())) continue;
            best = z;
        }
        Zone keep = null;
        Zone prev = this.primary;
        if (prev != null) {
            for (Zone z : all) {
                boolean overlap = false;
                for (long k : z.chunkKeys()) {
                    if (!prev.chunkKeys().contains(k)) continue;
                    overlap = true;
                    break;
                }
                double dx = z.x() - prev.x();
                double dz = z.z() - prev.z();
                if (!overlap && !(dx * dx + dz * dz <= 4096.0) || keep != null && !(z.score() > keep.score())) continue;
                keep = z;
            }
        }
        Zone chosen = best;
        if (keep != null && (best == null || best.score() < keep.score() * 2.0)) {
            chosen = keep;
        }
        this.primary = chosen;
        boolean fresh = true;
        for (long k : chosen.chunkKeys()) {
            if (!this.announced.contains(k)) continue;
            fresh = false;
            break;
        }
        this.announced.addAll(chosen.chunkKeys());
        if (fresh && ArrowSusChunkDebugV2.bool(this.chatCoords)) {
            ArrowNotify.chat("SusChunkDebugV2", ("Sus chunk detected at X: " + Math.round(chosen.x()) + "  Z: " + Math.round(chosen.z()) + " (" + (chosen.farm() ? "Farm" : "Base") + ")"));
        }
        this.zones = List.of(chosen);
        ArrayList<int[]> rots = new ArrayList<int[]>();
        for (long k : chosen.chunkKeys()) {
            ChunkSig cs = this.results.get(k);
            if (cs == null) continue;
            for (Sig sg : cs.sigs()) {
                if (sg.kind() != 32 || rots.size() >= 64) continue;
                rots.add(new int[]{sg.x(), sg.y(), sg.z()});
            }
        }
        this.rotBlocks = rots;
    }

    private boolean nearNatural(int cx, int cz, int margin) {
        if (margin < 0 || this.naturalChunks.isEmpty()) {
            return false;
        }
        for (int dx = -margin; dx <= margin; ++dx) {
            for (int dz = -margin; dz <= margin; ++dz) {
                if (!this.naturalChunks.contains(class_1923.method_8331((int)(cx + dx), (int)(cz + dz)))) continue;
                return true;
            }
        }
        return false;
    }

    private static boolean isSpotKind(int kind) {
        return kind == 2048 || kind == 4096 || kind == 128 || kind == 512 || kind == 1024;
    }

    private Zone makeZone(List<ChunkSig> members) {
        double sx = 0.0;
        double sz = 0.0;
        double sw = 0.0;
        double totalScore = 0.0;
        int minX = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxZ = Integer.MIN_VALUE;
        int lo = Integer.MAX_VALUE;
        int hi = Integer.MIN_VALUE;
        int farmSigs = 0;
        ChunkSig anchor = members.get(0);
        boolean hasSpot = false;
        for (ChunkSig cs : members) {
            for (Sig s : cs.sigs()) {
                if (!ArrowSusChunkDebugV2.isSpotKind(s.kind())) continue;
                hasSpot = true;
                break;
            }
            if (!hasSpot) continue;
            break;
        }
        ArrayList<Long> keys = new ArrayList<Long>();
        for (ChunkSig cs : members) {
            keys.add(cs.key());
            farmSigs += cs.farmSigs();
            totalScore += cs.score();
            if (cs.cx() < anchor.cx() || cs.cx() == anchor.cx() && cs.cz() < anchor.cz()) {
                anchor = cs;
            }
            for (Sig s : cs.sigs()) {
                if (hasSpot && !ArrowSusChunkDebugV2.isSpotKind(s.kind())) continue;
                sx += ((double)s.x() + 0.5) * (double)s.w();
                sz += ((double)s.z() + 0.5) * (double)s.w();
                sw += (double)s.w();
                minX = Math.min(minX, s.x());
                maxX = Math.max(maxX, s.x());
                minZ = Math.min(minZ, s.z());
                maxZ = Math.max(maxZ, s.z());
                lo = Math.min(lo, s.y());
                hi = Math.max(hi, s.y());
            }
        }
        if (sw <= 0.0 || lo == Integer.MAX_VALUE) {
            return new Zone(anchor.key(), (double)anchor.cx() * 16.0 + 8.0, (double)anchor.cz() * 16.0 + 8.0, 0, 0, 0, 0, false, keys, totalScore);
        }
        return new Zone(anchor.key(), sx / sw, sz / sw, lo, hi, maxX - minX, maxZ - minZ, farmSigs >= 4, keys, totalScore);
    }


    private static Color rgba(int argb, double a) {
        return new Color(argb >> 16 & 0xFF, argb >> 8 & 0xFF, argb & 0xFF, Math.max(0, Math.min(255, (int)Math.round(a))));
    }

    private static void plate(List<Start> lines, double x1, double y, double z1, double x2, double z2, Color line) {
        lines.add(new Start(new class_243(x1, y, z1), new class_243(x2, y, z1), line, 1.5f));
        lines.add(new Start(new class_243(x2, y, z1), new class_243(x2, y, z2), line, 1.5f));
        lines.add(new Start(new class_243(x2, y, z2), new class_243(x1, y, z2), line, 1.5f));
        lines.add(new Start(new class_243(x1, y, z2), new class_243(x1, y, z1), line, 1.5f));
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent event) {
        if (this.mc.field_1687 == null) {
            return;
        }
        List<Zone> current = this.zones;
        this.ANIM.begin();
        double baseWid = ArrowSusChunkDebugV2.num(this.width);
        double maxWid = Math.max(baseWid, (double)ArrowSusChunkDebugV2.num(this.maxWidth));
        for (Zone zone : current) {
            ArrowChunkAppear.Entry e = this.ANIM.flag(1L, zone.x(), zone.z());
            double span = zone.maxY() - zone.minY() + 1;
            double w = Math.min(maxWid, baseWid + Math.max(0.0, span - 8.0) * 0.5);
            e.tag = new Shape(w, zone.spanX() >= zone.spanZ());
        }
        this.ANIM.end();
        List<int[]> rots = this.rotBlocks;
        this.ANIM_ESP.begin();
        this.ANIM_TRACER.begin();
        if (!current.isEmpty()) {
            for (int[] b : rots) {
                long key = class_2338.method_10064((int)b[0], (int)b[1], (int)b[2]);
                if (ArrowSusChunkDebugV2.bool(this.rotatedEsp)) {
                    this.ANIM_ESP.flag(key, (double)b[0] + 0.5, (double)b[2] + 0.5).tag = Integer.valueOf(b[1]);
                }
                if (!ArrowSusChunkDebugV2.bool(this.rotatedTracers)) continue;
                this.ANIM_TRACER.flag(key, (double)b[0] + 0.5, (double)b[2] + 0.5).tag = Integer.valueOf(b[1]);
            }
        }
        this.ANIM_ESP.end();
        this.ANIM_TRACER.end();
        if (this.ANIM.isEmpty() && this.ANIM_ESP.isEmpty() && this.ANIM_TRACER.isEmpty()) {
            return;
        }
        class_4184 camera = InverseProjectionScratch.getCamera();
        if (camera == null || !camera.method_19332()) {
            return;
        }
        int argb = this.susColor.getArgb();
        int a = Math.max(0, Math.min(255, ArrowSusChunkDebugV2.num(this.alpha)));
        double halfLen = (double)ArrowSusChunkDebugV2.num(this.length) * 0.5;
        double y = ArrowSusChunkDebugV2.num(this.renderY);
        boolean drawOutline = ArrowSusChunkDebugV2.bool(this.outline);
        List<kryzex.util.Color> boxes = new ArrayList<kryzex.util.Color>();
        List<Start> lines = new ArrayList<Start>();
        for (ArrowChunkAppear.Entry e : this.ANIM_ESP.entries()) {
            if (!(e.tag instanceof Integer)) continue;
            int by = (Integer)e.tag;
            double bx = Math.floor(e.x);
            double bz = Math.floor(e.z);
            if (!OriginX.box(bx, (double)by, bz, bx + 1.0, (double)(by + 1), bz + 1.0)) continue;
            Color f = ArrowSusChunkDebugV2.rgba(argb, 70.0f * e.alpha);
            Color l = ArrowSusChunkDebugV2.rgba(argb, 255.0f * e.alpha);
            boxes.add(new kryzex.util.Color(bx, (double)by, bz, bx + 1.0, (double)(by + 1), bz + 1.0, f));
            InverseProjectionScratch.addBoxOutline(lines, bx, (double)by, bz, bx + 1.0, (double)(by + 1), bz + 1.0, l, 1.5f);
        }
        if (this.mc.field_1724 != null && !this.ANIM_TRACER.isEmpty()) {
            class_243 start = InverseProjectionScratch.getTracerStart(camera);
            for (ArrowChunkAppear.Entry e : this.ANIM_TRACER.entries()) {
                if (!(e.tag instanceof Integer)) continue;
                int by = (Integer)e.tag;
                lines.add(new Start(start, new class_243(e.x, (double)by + 0.5, e.z), ArrowSusChunkDebugV2.rgba(argb, 255.0f * e.alpha), 1.5f));
            }
        }
        for (ArrowChunkAppear.Entry e : this.ANIM.entries()) {
            if (!(e.tag instanceof Shape)) continue;
            Shape sh = (Shape)e.tag;
            double hw = sh.width() * 0.5;
            double hx = sh.alongX() ? halfLen : hw;
            double hz = sh.alongX() ? hw : halfLen;
            double x1 = e.x - hx;
            double x2 = e.x + hx;
            double z1 = e.z - hz;
            double z2 = e.z + hz;
            Color fill = ArrowSusChunkDebugV2.rgba(argb, (float)a * e.alpha);
            if (OriginX.box(x1, y, z1, x2, y + 0.05, z2)) {
                boxes.add(new kryzex.util.Color(x1, y, z1, x2, y + 0.05, z2, fill));
            }
            if (!drawOutline) continue;
            ArrowSusChunkDebugV2.plate(lines, x1, y, z1, x2, z2, ArrowSusChunkDebugV2.rgba(argb, (float)Math.min(255, a + 120) * e.alpha));
        }
        if (boxes.isEmpty() && lines.isEmpty()) {
            return;
        }
        class_4587 stack = event.matrixStack;
        stack.method_22903();
        try {
            InverseProjectionScratch.applyCameraTransform(stack, camera);
            if (!boxes.isEmpty()) {
                InverseProjectionScratch.renderFilledBoxes(stack, boxes);
            }
            if (!lines.isEmpty()) {
                InverseProjectionScratch.renderLines(stack, lines);
            }
        }
        finally {
            stack.method_22909();
        }
    }

    public String getInfoString() {
        return String.valueOf(this.zones.size());
    }

    private record Zone(long key, double x, double z, int minY, int maxY, int spanX, int spanZ, boolean farm, List<Long> chunkKeys, double score) {
    }

    private record Cfg(int minY, int maxY, int depth, int minSignals, double need, boolean bes, boolean blocks, boolean kelp, int kelpMin, boolean vines, int vineMin, int vineLen, boolean filter, boolean rot, int rotMin, boolean amethyst, boolean amethystDetect, int amethystMin, boolean baseOn, int baseMin, boolean bee, boolean beeUnderground, boolean pillager, int pillagerMin, boolean bamboo, int bambooMin, boolean bambooUnder, boolean cave, int caveMin, int bambooHeight, int vineLo, int vineHi, int beeLo, int beeHi, boolean beeHives, boolean beeNests, int beeMask, boolean llama, int llamaMin, int llamaDist, boolean drip, int stalactiteMin, int stalagmiteMin, int dripAlert) {
    }

    private record Target(int x, int y, int z, class_2248 block) {
    }

    private record Sig(int x, int y, int z, float w, int kind, boolean prone) {
    }

    private record BInfo(float w, int kind, boolean prone, int marker) {
    }

    private record ChunkSig(long key, int cx, int cz, List<Sig> sigs, double score, int farmSigs, boolean valid, List<Target> targets) {
    }

    private record Shape(double width, boolean alongX) {
    }
}
