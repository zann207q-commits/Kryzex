package kryzex.modules.donut;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.ArrowNotify;
import kryzex.util.ArrowScan;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.KingMcGuard;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;

/**
 * Port of the Meteor "Sus Chunk Finder" (arrowaddon) to the Kryzex module API.
 * Finds probable base locations using growth signals (kelp, vines, amethyst, bamboo, cocoa, bee nests)
 * and rotated deepslate.
 */
public final class ArrowSusChunkFinder
extends Module {
    private static final int DEFAULT_SENSITIVITY = 4;
    private static final double RENDER_Y = 60.0;
    private static final double PLATE_THICKNESS = 0.05;
    private static final int MAX_TRACERS = 64;
    private static final int[][] DIRS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    // General
    private final NumberSetting simDistance = new NumberSetting(SecureString.of("Simulation Distance"), 1.0, 32.0, 3.0, 1.0).getValue(SecureString.of("Radius (chunks) around you that is rescanned continuously (min 5 while scanning)."));
    private final NumberSetting sensitivity = new NumberSetting(SecureString.of("Sensitivity"), 1.0, 100.0, 4.0, 1.0).getValue(SecureString.of("Minimum score inside one chunk before it is flagged."));
    private final BoolSetting autoSensitivity = new BoolSetting(SecureString.of("Auto Sensitivity"), true).setDescription(SecureString.of("Raises / lowers sensitivity depending on how many chunks are flagged around you."));
    private final NumberSetting autoRange = new NumberSetting(SecureString.of("Auto Range"), 1.0, 32.0, 10.0, 1.0).getValue(SecureString.of("Radius (chunks) used to count flagged chunks for auto sensitivity."));
    private final ActionSetting restoreSensitivity = new ActionSetting(SecureString.of("Restore Sensitivity"), this::restoreSensitivity);
    // Checks
    private final BoolSetting kelp = new BoolSetting(SecureString.of("Kelp"), true);
    private final BoolSetting caveVine = new BoolSetting(SecureString.of("Cave Vine"), true);
    private final BoolSetting vines = new BoolSetting(SecureString.of("Vines"), true);
    private final BoolSetting amethyst = new BoolSetting(SecureString.of("Amethyst"), true);
    private final BoolSetting bamboo = new BoolSetting(SecureString.of("Bamboo"), true);
    private final BoolSetting cocoa = new BoolSetting(SecureString.of("Cocoa"), true);
    private final BoolSetting beeNest = new BoolSetting(SecureString.of("Bee Nest"), true);
    private final BoolSetting rotatedDeepslate = new BoolSetting(SecureString.of("Rotated Deepslate"), true);
    private final BoolSetting lowHole = new BoolSetting(SecureString.of("Low Hole"), false);
    private final NumberSetting maxHoles = new NumberSetting(SecureString.of("Max Holes"), 1.0, 10.0, 2.0, 1.0).getValue(SecureString.of("A chunk with more holes than this is treated as a natural cave and ignored."));
    // Render
    private final NumberSetting fillOpacity = new NumberSetting(SecureString.of("Fill Opacity"), 0.0, 255.0, 32.0, 1.0);
    private final NumberSetting lineOpacity = new NumberSetting(SecureString.of("Line Opacity"), 0.0, 255.0, 210.0, 1.0);
    private final NumberSetting ringSegments = new NumberSetting(SecureString.of("Ring Segments"), 8.0, 256.0, 96.0, 1.0);
    private final BoolSetting rainbow = new BoolSetting(SecureString.of("Rainbow"), false);
    private final BoolSetting animation = new BoolSetting(SecureString.of("Animation"), true);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false);
    private final Map<class_1923, Result> results = new ConcurrentHashMap<class_1923, Result>();
    private final Set<class_1923> scanned = ConcurrentHashMap.newKeySet();
    private final Set<class_1923> inFlight = ConcurrentHashMap.newKeySet();
    private final Set<class_1923> announced = ConcurrentHashMap.newKeySet();
    private final Map<Long, Integer> pendingChunks = new ConcurrentHashMap<Long, Integer>();
    private volatile Set<class_1923> painted = Collections.emptySet();
    private volatile List<double[]> regions = Collections.emptyList();
    private ExecutorService executor;
    private class_638 lastWorld;
    private int tickCounter;
    private int autoBoost = 0;

    public ArrowSusChunkFinder() {
        super(SecureString.of("Arrow Sus Chunk Finder"), SecureString.of("Finds probable base locations using growth and rotated-deepslate signals (KingMC)"), -1, Category.BASE_FINDING);
        this.addSettings(new Setting[]{this.simDistance, this.sensitivity, this.autoSensitivity, this.autoRange, this.restoreSensitivity, this.kelp, this.caveVine, this.vines, this.amethyst, this.bamboo, this.cocoa, this.beeNest, this.rotatedDeepslate, this.lowHole, this.maxHoles, this.fillOpacity, this.lineOpacity, this.ringSegments, this.rainbow, this.animation, this.tracers});
    }

    private void restoreSensitivity() {
        this.autoBoost = 0;
        this.sensitivity.getValue(4.0);
        if (this.isEnabled()) {
            ArrowNotify.chat("SusChunkFinder", "Sensitivity restored to 4.");
        }
    }

    private int need() {
        return this.sensitivity.getIntValue() + (this.autoSensitivity.getValue() ? this.autoBoost : 0);
    }

    @Override
    public void onEnable() {
        if (!KingMcGuard.check(this)) {
            return;
        }
        this.clearState();
        this.autoBoost = 0;
        this.executor = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "ArrowSusChunkFinder-scan");
            t.setDaemon(true);
            return t;
        });
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (KingMcGuard.wasDenied(this)) {
            return;
        }
        if (this.executor != null && !this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
        this.executor = null;
        this.clearState();
        super.onDisable();
    }

    private void clearState() {
        this.results.clear();
        this.scanned.clear();
        this.inFlight.clear();
        this.announced.clear();
        this.pendingChunks.clear();
        this.painted = Collections.emptySet();
        this.regions = Collections.emptyList();
        this.lastWorld = null;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent event) {
        if (this.executor == null) {
            return;
        }
        // The chunk may not be in the world yet when the packet arrives; resolve it on the next ticks.
        this.pendingChunks.put(class_1923.method_8331((int)event.packet.method_11523(), (int)event.packet.method_11524()), 0);
    }

    private void drainPending() {
        if (this.pendingChunks.isEmpty()) {
            return;
        }
        for (Map.Entry<Long, Integer> entry : this.pendingChunks.entrySet()) {
            long key = entry.getKey();
            int cx = class_1923.method_8325((long)key);
            int cz = class_1923.method_8332((long)key);
            class_2818 chunk = this.mc.field_1687.method_2935().method_21730(cx, cz);
            if (chunk != null) {
                this.pendingChunks.remove(key);
                this.scanned.remove(chunk.method_12004());
                this.submitScan(chunk, true);
                continue;
            }
            if (entry.getValue() < 100) {
                entry.setValue(entry.getValue() + 1);
                continue;
            }
            this.pendingChunks.remove(key);
        }
    }

    @Subscribe
    public void onTick(TickEvent event) {
        class_2818 chunk;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            if (this.lastWorld != null) {
                this.clearState();
            }
            return;
        }
        if (this.lastWorld != this.mc.field_1687) {
            this.clearState();
            this.lastWorld = this.mc.field_1687;
        }
        this.drainPending();
        if (++this.tickCounter % 5 != 0) {
            return;
        }
        class_1923 c = this.mc.field_1724.method_31476();
        for (int dx = -2; dx <= 2; ++dx) {
            for (int dz = -2; dz <= 2; ++dz) {
                class_2818 near = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz);
                if (near == null) continue;
                this.submitScan(near, true);
            }
        }
        if (this.tickCounter % 10 != 0) {
            return;
        }
        this.results.keySet().removeIf(p -> this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180) == null);
        this.scanned.removeIf(p -> this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180) == null);
        int r = (Integer)this.mc.field_1690.method_42503().method_41753() + 1;
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                class_1923 p2 = new class_1923(c.field_9181 + dx, c.field_9180 + dz);
                if (this.scanned.contains(p2) || (chunk = this.mc.field_1687.method_2935().method_21730(p2.field_9181, p2.field_9180)) == null) continue;
                this.submitScan(chunk, false);
            }
        }
        if (this.tickCounter % 20 == 0) {
            int rr = Math.min(6, Math.max(5, this.simDistance.getIntValue()));
            for (int dx = -rr; dx <= rr; ++dx) {
                for (int dz = -rr; dz <= rr; ++dz) {
                    chunk = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz);
                    if (chunk == null) continue;
                    this.submitScan(chunk, true);
                }
            }
        }
        this.rebuild();
        if (this.autoSensitivity.getValue() && this.tickCounter % 40 == 0) {
            this.autoAdjust(c);
        }
    }

    private void autoAdjust(class_1923 me) {
        int range = this.autoRange.getIntValue();
        int count = 0;
        for (class_1923 p : this.painted) {
            if (Math.max(Math.abs(p.field_9181 - me.field_9181), Math.abs(p.field_9180 - me.field_9180)) > range) continue;
            ++count;
        }
        if (count > 5 && this.autoBoost < 10) {
            ++this.autoBoost;
        } else if (count == 0 && this.autoBoost > 0) {
            --this.autoBoost;
        }
    }

    private boolean[] enabled() {
        return new boolean[]{this.kelp.getValue(), this.caveVine.getValue(), this.vines.getValue(), this.amethyst.getValue(), this.bamboo.getValue(), this.beeNest.getValue(), this.rotatedDeepslate.getValue(), this.cocoa.getValue()};
    }

    private void submitScan(class_2818 chunk, boolean force) {
        ExecutorService ex = this.executor;
        if (ex == null || ex.isShutdown()) {
            return;
        }
        class_1923 pos = chunk.method_12004();
        if (!force && this.scanned.contains(pos)) {
            return;
        }
        if (!this.inFlight.add(pos)) {
            return;
        }
        this.scanned.add(pos);
        boolean[] on = this.enabled();
        boolean holes = this.lowHole.getValue();
        try {
            ex.submit(() -> {
                try {
                    Result res = ArrowSusChunkFinder.scan(chunk, on, holes);
                    if (this.heatOf(res) > 0) {
                        this.results.put(pos, res);
                    } else {
                        this.results.remove(pos);
                    }
                }
                catch (Throwable t) {
                    this.scanned.remove(pos);
                }
                finally {
                    this.inFlight.remove(pos);
                }
            });
        }
        catch (Throwable t) {
            this.scanned.remove(pos);
            this.inFlight.remove(pos);
        }
    }

    private int heatOf(Result r) {
        int heat = (r.hasUngrown() ? 0 : r.heat()) + r.rotated().size() * 4;
        if (this.lowHole.getValue() && r.holes() >= 1 && r.holes() <= this.maxHoles.getIntValue()) {
            ++heat;
        }
        return heat;
    }

    private void rebuild() {
        if (this.mc.field_1687 == null) {
            return;
        }
        int need = this.need();
        HashSet<class_1923> out = new HashSet<class_1923>();
        for (Map.Entry<class_1923, Result> e : this.results.entrySet()) {
            if (this.heatOf(e.getValue()) < need) continue;
            class_1923 p = e.getKey();
            if (this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180) == null) continue;
            out.add(p);
        }
        if (out.isEmpty()) {
            this.painted = Collections.emptySet();
            this.regions = Collections.emptyList();
            return;
        }
        ArrayList<double[]> reg = new ArrayList<double[]>();
        HashSet<class_1923> seen = new HashSet<class_1923>();
        for (class_1923 start : out) {
            if (!seen.add(start)) continue;
            ArrayDeque<class_1923> q = new ArrayDeque<class_1923>();
            q.add(start);
            ArrayList<class_1923> members = new ArrayList<class_1923>();
            double sx = 0.0;
            double sz = 0.0;
            while (!q.isEmpty()) {
                class_1923 c = q.poll();
                members.add(c);
                sx += (double)(c.method_8326() + 8);
                sz += (double)(c.method_8328() + 8);
                for (int[] d : DIRS) {
                    class_1923 nb = new class_1923(c.field_9181 + d[0], c.field_9180 + d[1]);
                    if (!out.contains(nb) || !seen.add(nb)) continue;
                    q.add(nb);
                }
            }
            double cx = sx / (double)members.size();
            double cz = sz / (double)members.size();
            double radius = 8.0;
            for (class_1923 m : members) {
                double dx = (double)(m.method_8326() + 8) - cx;
                double dz = (double)(m.method_8328() + 8) - cz;
                radius = Math.max(radius, Math.sqrt(dx * dx + dz * dz) + 10.0);
            }
            reg.add(new double[]{cx, cz, radius});
            boolean fresh = true;
            for (class_1923 m : members) {
                if (!this.announced.contains(m)) continue;
                fresh = false;
                break;
            }
            if (!fresh) continue;
            this.announced.addAll(members);
            ArrowNotify.chat("SusChunkFinder", "Sus chunk at X: " + Math.round(cx) + " Z: " + Math.round(cz));
        }
        this.painted = out;
        this.regions = reg;
    }

    private static Result scan(class_2818 chunk, boolean[] on, boolean holeCheck) {
        int heat = 0;
        int young = 0;
        ArrayList<class_2338> rotated = new ArrayList<class_2338>();
        class_2826[] sections = chunk.method_12006();
        int bottom = chunk.method_31607();
        class_2338.class_2339 mp = new class_2338.class_2339();
        for (int i = 0; i < sections.length; ++i) {
            class_2826 s = sections[i];
            if (s == null || !s.method_19523(st -> ArrowSusChunkFinder.relevant(st.method_26204(), on))) continue;
            int baseY = bottom + i * 16;
            for (int x = 0; x < 16; ++x) {
                for (int y = 0; y < 16; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        class_2680 st2 = s.method_12254(x, y, z);
                        class_2248 b = st2.method_26204();
                        int grow = ArrowSusChunkFinder.growth(b, st2, chunk, on, chunk.method_12004().method_8326() + x, baseY + y, chunk.method_12004().method_8328() + z, mp);
                        if (grow == 1) {
                            ++heat;
                            continue;
                        }
                        if (grow == -1) {
                            ++young;
                            continue;
                        }
                        if (grow != 2) continue;
                        rotated.add(new class_2338(chunk.method_12004().method_8326() + x, baseY + y, chunk.method_12004().method_8328() + z));
                    }
                }
            }
        }
        int holes = holeCheck ? ArrowScan.scanLowHoles(chunk) : 0;
        return new Result(heat, young > heat, rotated, holes);
    }

    private static boolean relevant(class_2248 b, boolean[] on) {
        return on[0] && b == class_2246.field_9993 || on[1] && b == class_2246.field_28675 || on[2] && b == class_2246.field_10597 || on[3] && (b == class_2246.field_27161 || b == class_2246.field_27164 || b == class_2246.field_27163 || b == class_2246.field_27162) || on[4] && b == class_2246.field_10211 || on[5] && b == class_2246.field_20421 || on[6] && b == class_2246.field_28888 || on[7] && b == class_2246.field_10302;
    }

    private static int growth(class_2248 b, class_2680 st, class_2818 chunk, boolean[] on, int wx, int wy, int wz, class_2338.class_2339 mp) {
        if (on[0] && b == class_2246.field_9993) {
            return st.method_28498((class_2769)class_2741.field_12517) && (Integer)st.method_11654((class_2769)class_2741.field_12517) >= 25 ? 1 : -1;
        }
        if (on[1] && b == class_2246.field_28675) {
            return st.method_28498((class_2769)class_2741.field_12517) && (Integer)st.method_11654((class_2769)class_2741.field_12517) >= 25 ? 1 : -1;
        }
        if (on[4] && b == class_2246.field_10211) {
            return st.method_28498((class_2769)class_2741.field_12521) && (Integer)st.method_11654((class_2769)class_2741.field_12521) >= 1 ? 1 : -1;
        }
        if (on[5] && b == class_2246.field_20421) {
            return st.method_28498((class_2769)class_2741.field_20432) && (Integer)st.method_11654((class_2769)class_2741.field_20432) >= 5 ? 1 : -1;
        }
        if (on[7] && b == class_2246.field_10302) {
            return st.method_28498((class_2769)class_2741.field_12556) && (Integer)st.method_11654((class_2769)class_2741.field_12556) >= 2 ? 1 : -1;
        }
        if (on[3]) {
            if (b == class_2246.field_27161) {
                return 1;
            }
            if (b == class_2246.field_27164 || b == class_2246.field_27163 || b == class_2246.field_27162) {
                return -1;
            }
        }
        if (on[2] && b == class_2246.field_10597) {
            int len = 1;
            for (int k = 1; k <= 5 && chunk.method_8320((class_2338)mp.method_10103(wx, wy + k, wz)).method_26204() == class_2246.field_10597; ++k) {
                ++len;
            }
            return len >= 5 ? 1 : 0;
        }
        if (on[6] && b == class_2246.field_28888 && st.method_28498((class_2769)class_2741.field_12496) && st.method_11654((class_2769)class_2741.field_12496) != class_2350.class_2351.field_11052) {
            return 2;
        }
        return 0;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent event) {
        Set<class_1923> set = this.painted;
        if (set.isEmpty() || this.mc.field_1687 == null) {
            return;
        }
        class_4184 camera = InverseProjectionScratch.getCamera();
        if (camera == null || !camera.method_19332()) {
            return;
        }
        long now = System.currentTimeMillis();
        int r = 255;
        int g = 40;
        int b = 40;
        if (this.rainbow.getValue()) {
            int rgb = Color.HSBtoRGB((float)(now % 4000L) / 4000.0f, 1.0f, 1.0f);
            r = rgb >> 16 & 0xFF;
            g = rgb >> 8 & 0xFF;
            b = rgb & 0xFF;
        }
        Color fill = new Color(r, g, b, Math.max(0, Math.min(255, this.fillOpacity.getIntValue())));
        Color line = new Color(r, g, b, Math.max(0, Math.min(255, this.lineOpacity.getIntValue())));
        double y = RENDER_Y;
        List<kryzex.util.Color> boxes = new ArrayList<kryzex.util.Color>();
        List<Start> lines = new ArrayList<Start>();
        for (class_1923 p : set) {
            double x = p.method_8326();
            double z = p.method_8328();
            if (!OriginX.box(x, y, z, x + 16.0, y + PLATE_THICKNESS, z + 16.0)) continue;
            boxes.add(new kryzex.util.Color(x, y, z, x + 16.0, y + PLATE_THICKNESS, z + 16.0, fill));
            InverseProjectionScratch.addBoxOutline(lines, x, y, z, x + 16.0, y + PLATE_THICKNESS, z + 16.0, line, 1.5f);
        }
        int segs = Math.max(8, this.ringSegments.getIntValue());
        int n = 0;
        class_243 tracerStart = InverseProjectionScratch.getTracerStart(camera);
        for (double[] reg : this.regions) {
            double radius = reg[2] + (this.animation.getValue() ? 1.5 + 1.5 * Math.sin((double)now / 300.0) : 0.0);
            for (int i = 0; i < segs; ++i) {
                double a1 = Math.PI * 2 * (double)i / (double)segs;
                double a2 = Math.PI * 2 * (double)(i + 1) / (double)segs;
                lines.add(new Start(new class_243(reg[0] + Math.cos(a1) * radius, y, reg[1] + Math.sin(a1) * radius), new class_243(reg[0] + Math.cos(a2) * radius, y, reg[1] + Math.sin(a2) * radius), line, 1.5f));
            }
            if (!this.tracers.getValue() || n++ >= MAX_TRACERS) continue;
            lines.add(new Start(tracerStart, new class_243(reg[0], y, reg[1]), line, 1.5f));
        }
        if (boxes.isEmpty() && lines.isEmpty()) {
            return;
        }
        class_4587 stack = event.matrixStack;
        stack.method_22903();
        try {
            InverseProjectionScratch.applyCameraTransform(stack, camera);
            if (!boxes.isEmpty()) {
                InverseProjectionScratch.renderFilledBoxes(stack, boxes);
            }
            if (!lines.isEmpty()) {
                InverseProjectionScratch.renderLines(stack, lines);
            }
        }
        finally {
            stack.method_22909();
        }
    }

    public String getInfoString() {
        return String.valueOf(this.painted.size());
    }

    private record Result(int heat, boolean hasUngrown, List<class_2338> rotated, int holes) {
    }
}
