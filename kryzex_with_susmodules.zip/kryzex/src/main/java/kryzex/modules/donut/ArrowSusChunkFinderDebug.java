package kryzex.modules.donut;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kryzex.event.ChunkDataEvent;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.KingMcGuard;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;

/**
 * Port of the Meteor "Sus Chunk Finder Debug" (arrowaddon) to the Kryzex module API.
 * Finds chunks with build / farm signals, paints a flat red plate at Y 60 and shows an achievement-style toast.
 */
public final class ArrowSusChunkFinderDebug
extends Module {
    private static final int[][] DIRS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int MAX_TRACERS = 64;
    private static final double RENDER_Y = 60.0;
    private static final double PLATE_THICKNESS = 0.05;
    private static final long TOAST_SLIDE_MS = 600L;
    private static final long TOAST_HOLD_MS = 5000L;
    private static final int TOAST_MAX_QUEUE = 5;
    private final NumberSetting simulationDistance = new NumberSetting(SecureString.of("Simulation Distance"), 1.0, 32.0, 4.0, 1.0).getValue(SecureString.of("Radius (chunks) around you that is rescanned continuously (min 5)."));
    private final NumberSetting sensitivity = new NumberSetting(SecureString.of("Sensitivity"), 1.0, 100.0, 4.0, 1.0).getValue(SecureString.of("Minimum number of grown blocks inside one chunk."));
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 111.0, 1.0).getValue(SecureString.of("Opacity of the filled plate."));
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), true).setDescription(SecureString.of("Draws a red line from the screen center to every sus chunk patch."));
    private final BoolSetting achievement = new BoolSetting(SecureString.of("Achievement"), true).setDescription(SecureString.of("Shows a toast at the top right every time a new sus chunk is found."));
    private final BoolSetting kelp = new BoolSetting(SecureString.of("Kelp"), true).setDescription(SecureString.of("Check kelp."));
    private final BoolSetting caveVines = new BoolSetting(SecureString.of("Cave Vines"), true).setDescription(SecureString.of("Check cave vines."));
    private final BoolSetting vines = new BoolSetting(SecureString.of("Vines"), false).setDescription(SecureString.of("Check vines."));
    private final BoolSetting amethyst = new BoolSetting(SecureString.of("Amethyst"), true).setDescription(SecureString.of("Check amethyst."));
    private final BoolSetting bamboo = new BoolSetting(SecureString.of("Bamboo"), false).setDescription(SecureString.of("Check bamboo."));
    private final BoolSetting beeNest = new BoolSetting(SecureString.of("Bee Nest"), false).setDescription(SecureString.of("Check bee nest."));
    private final BoolSetting rotatedDeepslate = new BoolSetting(SecureString.of("Rotated Deepslate"), false).setDescription(SecureString.of("Check rotated deepslate."));
    private final Queue<int[]> pendingToasts = new ConcurrentLinkedQueue<int[]>();
    private final Set<class_1923> announced = ConcurrentHashMap.newKeySet();
    private int[] currentToast;
    private long toastStart;
    private class_1799 toastIcon;
    private final Map<class_1923, Result> results = new ConcurrentHashMap<class_1923, Result>();
    private final Set<class_1923> scanned = ConcurrentHashMap.newKeySet();
    private final Set<class_1923> inFlight = ConcurrentHashMap.newKeySet();
    private final Map<Long, Integer> pendingChunks = new ConcurrentHashMap<Long, Integer>();
    private volatile Set<class_1923> painted = Collections.emptySet();
    private volatile List<double[]> regions = Collections.emptyList();
    private ExecutorService executor;
    private class_638 lastWorld;
    private int tickCounter;

    public ArrowSusChunkFinderDebug() {
        super(SecureString.of("Arrow Sus Chunk Finder Debug"), SecureString.of("Finds chunks with build / farm signals and draws a flat red plate at Y 60 (KingMC)"), -1, Category.BASE_FINDING);
        this.addSettings(new Setting[]{this.simulationDistance, this.sensitivity, this.alpha, this.tracers, this.achievement, this.kelp, this.caveVines, this.vines, this.amethyst, this.bamboo, this.beeNest, this.rotatedDeepslate});
    }

    @Override
    public void onEnable() {
        if (!KingMcGuard.check(this)) {
            return;
        }
        this.clearState();
        this.executor = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "ArrowSusChunkFinderDebug-scan");
            t.setDaemon(true);
            return t;
        });
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (KingMcGuard.wasDenied(this)) {
            return;
        }
        if (this.executor != null && !this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
        this.executor = null;
        this.clearState();
        super.onDisable();
    }

    private void clearState() {
        this.results.clear();
        this.scanned.clear();
        this.inFlight.clear();
        this.pendingChunks.clear();
        this.painted = Collections.emptySet();
        this.regions = Collections.emptyList();
        this.announced.clear();
        this.pendingToasts.clear();
        this.currentToast = null;
        this.lastWorld = null;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent event) {
        if (this.executor == null) {
            return;
        }
        // The chunk may not be in the world yet when the packet arrives; resolve it on the next ticks.
        this.pendingChunks.put(class_1923.method_8331((int)event.packet.method_11523(), (int)event.packet.method_11524()), 0);
    }

    private void drainPending() {
        if (this.pendingChunks.isEmpty()) {
            return;
        }
        for (Map.Entry<Long, Integer> entry : this.pendingChunks.entrySet()) {
            long key = entry.getKey();
            int cx = class_1923.method_8325((long)key);
            int cz = class_1923.method_8332((long)key);
            class_2818 chunk = this.mc.field_1687.method_2935().method_21730(cx, cz);
            if (chunk != null) {
                this.pendingChunks.remove(key);
                this.scanned.remove(chunk.method_12004());
                this.submitScan(chunk, true);
                continue;
            }
            if (entry.getValue() < 100) {
                entry.setValue(entry.getValue() + 1);
                continue;
            }
            this.pendingChunks.remove(key);
        }
    }

    @Subscribe
    public void onTick(TickEvent event) {
        class_2818 chunk;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            if (this.lastWorld != null) {
                this.clearState();
            }
            return;
        }
        if (this.lastWorld != this.mc.field_1687) {
            this.clearState();
            this.lastWorld = this.mc.field_1687;
        }
        this.drainPending();
        if (++this.tickCounter % 5 != 0) {
            return;
        }
        class_1923 c = this.mc.field_1724.method_31476();
        for (int dx = -2; dx <= 2; ++dx) {
            for (int dz = -2; dz <= 2; ++dz) {
                class_2818 near = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz);
                if (near == null) continue;
                this.submitScan(near, true);
            }
        }
        if (this.tickCounter % 10 != 0) {
            return;
        }
        this.results.keySet().removeIf(p -> this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180) == null);
        this.scanned.removeIf(p -> this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180) == null);
        int r = (Integer)this.mc.field_1690.method_42503().method_41753() + 1;
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                class_1923 p2 = new class_1923(c.field_9181 + dx, c.field_9180 + dz);
                if (this.scanned.contains(p2) || (chunk = this.mc.field_1687.method_2935().method_21730(p2.field_9181, p2.field_9180)) == null) continue;
                this.submitScan(chunk, false);
            }
        }
        if (this.tickCounter % 20 == 0) {
            int rr = Math.min(6, Math.max(5, this.simulationDistance.getIntValue()));
            for (int dx = -rr; dx <= rr; ++dx) {
                for (int dz = -rr; dz <= rr; ++dz) {
                    chunk = this.mc.field_1687.method_2935().method_21730(c.field_9181 + dx, c.field_9180 + dz);
                    if (chunk == null) continue;
                    this.submitScan(chunk, true);
                }
            }
        }
        this.rebuildHeat();
    }

    private boolean[] enabled() {
        return new boolean[]{this.kelp.getValue(), this.caveVines.getValue(), this.vines.getValue(), this.amethyst.getValue(), this.bamboo.getValue(), this.beeNest.getValue(), this.rotatedDeepslate.getValue()};
    }

    private void submitScan(class_2818 chunk, boolean force) {
        ExecutorService ex = this.executor;
        if (ex == null || ex.isShutdown()) {
            return;
        }
        class_1923 pos = chunk.method_12004();
        if (!force && this.scanned.contains(pos)) {
            return;
        }
        if (!this.inFlight.add(pos)) {
            return;
        }
        this.scanned.add(pos);
        boolean[] on = this.enabled();
        try {
            ex.submit(() -> {
                try {
                    Result res = ArrowSusChunkFinderDebug.scan(chunk, on);
                    if (ArrowSusChunkFinderDebug.selfHeatOf(res) > 0) {
                        this.results.put(pos, res);
                    } else {
                        this.results.remove(pos);
                    }
                }
                catch (Throwable t) {
                    this.scanned.remove(pos);
                }
                finally {
                    this.inFlight.remove(pos);
                }
            });
        }
        catch (Throwable t) {
            this.scanned.remove(pos);
            this.inFlight.remove(pos);
        }
    }

    private static int selfHeatOf(Result r) {
        return (r.hasUngrown() ? 0 : r.selfHeat()) + r.rotated().size() * 4;
    }

    private void rebuildHeat() {
        if (this.mc.field_1687 == null) {
            return;
        }
        int need = this.sensitivity.getIntValue();
        HashSet<class_1923> out = new HashSet<class_1923>();
        for (Map.Entry<class_1923, Result> e : this.results.entrySet()) {
            if (ArrowSusChunkFinderDebug.selfHeatOf(e.getValue()) < need) continue;
            class_1923 p = e.getKey();
            class_2818 wc = this.mc.field_1687.method_2935().method_21730(p.field_9181, p.field_9180);
            if (wc == null) continue;
            out.add(p);
        }
        if (out.isEmpty()) {
            this.painted = Collections.emptySet();
            this.regions = Collections.emptyList();
            return;
        }
        ArrayList<double[]> reg = new ArrayList<double[]>();
        HashSet<class_1923> seen = new HashSet<class_1923>();
        for (class_1923 start : out) {
            if (!seen.add(start)) continue;
            ArrayDeque<class_1923> q = new ArrayDeque<class_1923>();
            q.add(start);
            double sx = 0.0;
            double sz = 0.0;
            int n = 0;
            ArrayList<class_1923> members = new ArrayList<class_1923>();
            while (!q.isEmpty()) {
                class_1923 c = q.poll();
                members.add(c);
                sx += (double)(c.method_8326() + 8);
                sz += (double)(c.method_8328() + 8);
                ++n;
                for (int[] dir : DIRS) {
                    class_1923 nb = new class_1923(c.field_9181 + dir[0], c.field_9180 + dir[1]);
                    if (!out.contains(nb) || !seen.add(nb)) continue;
                    q.add(nb);
                }
            }
            reg.add(new double[]{sx / (double)n, sz / (double)n});
            if (!this.achievement.getValue()) continue;
            boolean fresh = true;
            for (class_1923 m : members) {
                if (!this.announced.contains(m)) continue;
                fresh = false;
                break;
            }
            if (!fresh) continue;
            this.announced.addAll(members);
            if (this.pendingToasts.size() >= TOAST_MAX_QUEUE) continue;
            this.pendingToasts.add(new int[]{(int)Math.round(sx / (double)n), (int)Math.round(sz / (double)n)});
        }
        this.painted = out;
        this.regions = reg;
    }

    private static Result scan(class_2818 chunk, boolean[] on) {
        int heat = 0;
        int young = 0;
        long ySum = 0L;
        ArrayList<class_2338> rotated = new ArrayList<class_2338>();
        class_2826[] sections = chunk.method_12006();
        int bottom = chunk.method_31607();
        class_2338.class_2339 mp = new class_2338.class_2339();
        for (int i = 0; i < sections.length; ++i) {
            class_2826 s = sections[i];
            if (s == null || !s.method_19523(st -> ArrowSusChunkFinderDebug.relevant(st.method_26204(), on))) continue;
            int baseY = bottom + i * 16;
            for (int x = 0; x < 16; ++x) {
                for (int y = 0; y < 16; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        class_2680 st2 = s.method_12254(x, y, z);
                        class_2248 b = st2.method_26204();
                        int grow = ArrowSusChunkFinderDebug.growth(b, st2, chunk, on, chunk.method_12004().method_8326() + x, baseY + y, chunk.method_12004().method_8328() + z, mp);
                        if (grow == 1) {
                            ++heat;
                            ySum += (long)(baseY + y);
                            continue;
                        }
                        if (grow == -1) {
                            ++young;
                            continue;
                        }
                        if (grow != 2) continue;
                        rotated.add(new class_2338(chunk.method_12004().method_8326() + x, baseY + y, chunk.method_12004().method_8328() + z));
                    }
                }
            }
        }
        int avgY = heat > 0 ? (int)(ySum / (long)heat) : (rotated.isEmpty() ? bottom : rotated.get(0).method_10264());
        return new Result(heat, young > heat, rotated, avgY);
    }

    private static boolean relevant(class_2248 b, boolean[] on) {
        return on[0] && b == class_2246.field_9993 || on[1] && b == class_2246.field_28675 || on[2] && b == class_2246.field_10597 || on[3] && (b == class_2246.field_27161 || b == class_2246.field_27164 || b == class_2246.field_27163 || b == class_2246.field_27162) || on[4] && b == class_2246.field_10211 || on[5] && b == class_2246.field_20421 || on[6] && b == class_2246.field_28888;
    }

    private static int growth(class_2248 b, class_2680 st, class_2818 chunk, boolean[] on, int wx, int wy, int wz, class_2338.class_2339 mp) {
        if (on[0] && b == class_2246.field_9993) {
            return st.method_28498((class_2769)class_2741.field_12517) && (Integer)st.method_11654((class_2769)class_2741.field_12517) >= 25 ? 1 : -1;
        }
        if (on[1] && b == class_2246.field_28675) {
            return st.method_28498((class_2769)class_2741.field_12517) && (Integer)st.method_11654((class_2769)class_2741.field_12517) >= 25 ? 1 : -1;
        }
        if (on[4] && b == class_2246.field_10211) {
            return st.method_28498((class_2769)class_2741.field_12521) && (Integer)st.method_11654((class_2769)class_2741.field_12521) >= 1 ? 1 : -1;
        }
        if (on[5] && b == class_2246.field_20421) {
            return st.method_28498((class_2769)class_2741.field_20432) && (Integer)st.method_11654((class_2769)class_2741.field_20432) >= 5 ? 1 : -1;
        }
        if (on[3]) {
            if (b == class_2246.field_27161) {
                return 1;
            }
            if (b == class_2246.field_27164 || b == class_2246.field_27163 || b == class_2246.field_27162) {
                return -1;
            }
        }
        if (on[2] && b == class_2246.field_10597) {
            int len = 1;
            for (int k = 1; k <= 5 && chunk.method_8320((class_2338)mp.method_10103(wx, wy + k, wz)).method_26204() == class_2246.field_10597; ++k) {
                ++len;
            }
            return len >= 5 ? 1 : 0;
        }
        if (on[6] && b == class_2246.field_28888 && st.method_28498((class_2769)class_2741.field_12496) && st.method_11654((class_2769)class_2741.field_12496) != class_2350.class_2351.field_11052) {
            return 2;
        }
        return 0;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent event) {
        Set<class_1923> set = this.painted;
        if (set.isEmpty() || this.mc.field_1687 == null) {
            return;
        }
        class_4184 camera = InverseProjectionScratch.getCamera();
        if (camera == null || !camera.method_19332()) {
            return;
        }
        double y = RENDER_Y;
        Color fill = new Color(255, 40, 40, Math.max(0, Math.min(255, this.alpha.getIntValue())));
        Color lineColor = new Color(255, 0, 0, 255);
        List<kryzex.util.Color> boxes = new ArrayList<kryzex.util.Color>();
        List<Start> lines = new ArrayList<Start>();
        for (class_1923 p : set) {
            double x = p.method_8326();
            double z = p.method_8328();
            if (!OriginX.box(x, y, z, x + 16.0, y + PLATE_THICKNESS, z + 16.0)) continue;
            boxes.add(new kryzex.util.Color(x, y, z, x + 16.0, y + PLATE_THICKNESS, z + 16.0, fill));
        }
        if (this.tracers.getValue()) {
            class_243 start = InverseProjectionScratch.getTracerStart(camera);
            int n = 0;
            for (double[] r : this.regions) {
                if (n++ >= MAX_TRACERS) break;
                lines.add(new Start(start, new class_243(r[0], y, r[1]), lineColor, 1.5f));
            }
        }
        if (boxes.isEmpty() && lines.isEmpty()) {
            return;
        }
        class_4587 stack = event.matrixStack;
        stack.method_22903();
        try {
            InverseProjectionScratch.applyCameraTransform(stack, camera);
            if (!boxes.isEmpty()) {
                InverseProjectionScratch.renderFilledBoxes(stack, boxes);
            }
            if (!lines.isEmpty()) {
                InverseProjectionScratch.renderLines(stack, lines);
            }
        }
        finally {
            stack.method_22909();
        }
    }

    @Subscribe
    public void onHudRender(HudRenderEvent event) {
        if (event.context != null) {
            this.renderToast(event.context);
        }
    }

    private void renderToast(class_332 ctx) {
        long total;
        long t;
        if (!this.achievement.getValue() || this.mc.field_1724 == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (this.currentToast == null) {
            this.currentToast = this.pendingToasts.poll();
            if (this.currentToast == null) {
                return;
            }
            this.toastStart = now;
        }
        if ((t = now - this.toastStart) >= (total = 2L * TOAST_SLIDE_MS + TOAST_HOLD_MS)) {
            this.currentToast = null;
            return;
        }
        String title = "SUS CHUNK FINDER DEBUG";
        String coords = "X: " + this.currentToast[0] + "  Z: " + this.currentToast[1];
        int h = 32;
        int textX = 30;
        int padRight = 8;
        int textW = Math.max(this.mc.field_1772.method_1727(title), this.mc.field_1772.method_1727(coords));
        int w = Math.max(160, textX + textW + padRight);
        double slide = t < TOAST_SLIDE_MS ? 1.0 - (double)t / (double)TOAST_SLIDE_MS : (t > total - TOAST_SLIDE_MS ? (double)(t - (total - TOAST_SLIDE_MS)) / (double)TOAST_SLIDE_MS : 0.0);
        slide *= slide;
        int x = this.mc.method_22683().method_4486() - w + (int)Math.round(slide * (double)w);
        int y = 0;
        int cyan = -16711681;
        ctx.method_25294(x, y, x + w, y + h, -16777216);
        ctx.method_25294(x, y, x + w, y + 1, cyan);
        ctx.method_25294(x, y + h - 1, x + w, y + h, cyan);
        ctx.method_25294(x, y, x + 1, y + h, cyan);
        ctx.method_25294(x + w - 1, y, x + w, y + h, cyan);
        if (this.toastIcon == null) {
            this.toastIcon = new class_1799((class_1935)class_1802.field_27070);
        }
        ctx.method_51427(this.toastIcon, x + 8, y + 8);
        ctx.method_51433(this.mc.field_1772, title, x + textX, y + 7, cyan, false);
        ctx.method_51433(this.mc.field_1772, coords, x + textX, y + 18, -1, false);
    }

    public String getInfoString() {
        return String.valueOf(this.painted.size());
    }

    private record Result(int selfHeat, boolean hasUngrown, List<class_2338> rotated, int avgY) {
    }
}
