package kryzex.modules.donut;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.donut.ChunkCluster;
import kryzex.util.CachedThickness;
import kryzex.util.ChunkSetBuilder;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.ChunkUtil;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_4184;
import net.minecraft.class_4481;
import net.minecraft.class_4587;

public final class SusChunkFinder
extends Module {
    private static String[] a;
    private static final int MIN_SCAN_Y = -64;
    private static final int MAX_SCAN_Y = 64;
    private static final double PLATE_Y = 63.0;
    private static final double PLATE_THICKNESS = 0.05;
    private static final int MAX_CLUSTER_MARKERS = 400;
    private static final long SCAN_BUDGET_NANOS = 4000000L;
    private static final int SCAN_CHUNKS_PER_TICK = 24;
    private static final int MAX_TICKS_BETWEEN_COMMITS = 60;
    private final NumberSetting sensitivity = new NumberSetting(SecureString.of("Sensitivity"), 1.0, 20.0, 12.0, 1.0).getValue(SecureString.of("Geode light-signature threshold (maximum 20)"));
    private final NumberSetting simulationDistance = new NumberSetting(SecureString.of("Simulation Distance"), 2.0, 16.0, 4.0, 1.0).getValue(SecureString.of("Chunk radius used to triangulate the possible player origin"));
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 140.0, 1.0);
    private final BoolSetting markGeodeChunks = new BoolSetting(SecureString.of("Mark Geode Chunks"), false);
    private final BoolSetting renderClusters = new BoolSetting(SecureString.of("Render Clusters"), false);
    private final Map<Long,ChunkCluster> geodes = new HashMap<Long,ChunkCluster>();
    private final Queue<Long> scanQueue = new ArrayDeque<Long>();
    private final Set<Long> queued = new HashSet<Long>();
    private final Set<Long> scanned = new HashSet<Long>();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private Set<Long> cachedCandidates = Set.of();
    private final LongOpenHashSet candidateKeys = new LongOpenHashSet();
    private final CachedThickness candidatePlates = new CachedThickness();
    private static class_2350[] DIRECTIONS;
    private boolean candidatesDirty = true;
    private int cachedSimulationRadius = -1;
    private int cachedSensitivity = -1;
    private Object trackedWorld;
    private int ticks;
    private int ticksSinceCommit;
    private static int[][] NEIGHBORS;

    public SusChunkFinder() {
        super(SecureString.of("Sus Chunk Finder"), SecureString.of("Finds suspicious chunks from amethyst and full-beehive generation signals"), -1, Category.BASE_FINDING);
        this.addSettings(new Setting[]{this.sensitivity, this.simulationDistance, this.alpha, this.markGeodeChunks, this.renderClusters});
    }

    @Override
    public void onEnable() {
        this.v();
        this.trackedWorld = this.mc.field_1687;
        this.L();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.v();
        super.onDisable();
    }

    private void v() {
        this.geodes.clear();
        this.scanQueue.clear();
        this.queued.clear();
        this.scanned.clear();
        this.renderBoxes.clear();
        this.renderLines.clear();
        this.cachedCandidates = Set.of();
        this.candidateKeys.clear();
        this.candidatesDirty = true;
        this.cachedSimulationRadius = -1;
        this.cachedSensitivity = -1;
        this.trackedWorld = null;
        this.ticks = 0;
        this.ticksSinceCommit = 0;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.e(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
            if (this.trackedWorld != this.mc.field_1687) {
                this.v();
                this.trackedWorld = this.mc.field_1687;
            }
            ++this.ticks;
            ++this.ticksSinceCommit;
            int n = this.sensitivity.getIntValue();
            if (n != this.cachedSensitivity) {
                this.cachedSensitivity = n;
                this.geodes.clear();
                this.scanQueue.clear();
                this.queued.clear();
                this.scanned.clear();
                this.candidatesDirty = true;
                this.L();
            }
            if (this.ticks % 100 == 1) {
                this.L();
            }
            if (this.ticks % 240 == 0) {
                this.scanned.clear();
                this.L();
            }
            this.t();
            this.o();
            this.S();
            return;
        } else {
            this.v();
        }
    }

    private void t() {
        long l = System.nanoTime() + 4000000L;
        for (int i = 0; i < 24 && !this.scanQueue.isEmpty(); ++i) {
            this.d();
            if (i > 0 && System.nanoTime() >= l) return;
        }
    }

    private void L() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) return;
        class_1923 class_19232 = this.mc.field_1724.method_31476();
        List<class_2818> list = ChunkUtil.getLoadedChunksList();
        list.sort(Comparator.comparingInt(arg_0 -> SusChunkFinder.lmbd$enqueueLoadedChunks$0(class_19232, arg_0)));
        for (class_2818 class_28182 : list) {
            class_1923 class_19233 = class_28182.method_12004();
            this.e(class_19233.field_9181, class_19233.field_9180);
        }
    }

    private void e(int n, int n2) {
        long l = class_1923.method_8331((int)n, (int)n2);
        if (this.scanned.contains(l) || !this.queued.add(l)) return;
        this.scanQueue.offer(l);
    }

    private void d() {
        int n;
        Long l = this.scanQueue.poll();
        if (l == null) return;
        this.queued.remove(l);
        this.scanned.add(l);
        int n2 = class_1923.method_8325((long)l);
        int n3 = class_1923.method_8332((long)l);
        if (!this.mc.field_1687.method_8393(n2, n3)) {
            this.M(l);
            return;
        }
        class_2818 class_28182 = this.mc.field_1687.method_8497(n2, n3);
        class_2826[] class_2826Array = class_28182.method_12006();
        int n4 = class_28182.method_32891();
        int n5 = class_28182.method_12004().method_8326();
        int n6 = class_28182.method_12004().method_8328();
        LongOpenHashSet longOpenHashSet = new LongOpenHashSet();
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        ArrayList<class_2338> arrayList = new ArrayList<class_2338>();
        int n7 = 0;
        for (n = 0; n < class_2826Array.length; ++n) {
            class_2826 class_28262 = class_2826Array[n];
            if (class_28262 == null || !class_28262.method_12265().method_19526(SusChunkFinder::lmbd$scanNextChunk$0)) continue;
            int n8 = n4 + n << 4;
            for (int i = 0; i < 16; ++i) {
                for (int j = 0; j < 16; ++j) {
                    for (int k = 0; k < 16; ++k) {
                        class_2680 class_26802 = class_28262.method_12254(k, i, j);
                        class_2248 class_22482 = class_26802.method_26204();
                        if (SusChunkFinder.f(class_22482)) {
                            class_2338 class_23382 = new class_2338(n5 + k, n8 + i, n6 + j);
                            if (arrayList.size() < 400) {
                                arrayList.add(class_23382);
                            }
                            for (class_2350 class_23502 : DIRECTIONS) {
                                class_2338.class_2339 class_23393 = class_23392.method_10103(class_23382.method_10263() + class_23502.method_10148(), class_23382.method_10264() + class_23502.method_10164(), class_23382.method_10260() + class_23502.method_10165());
                                if (!this.mc.field_1687.method_8320((class_2338)class_23393).method_27852(class_2246.field_10340)) continue;
                                longOpenHashSet.add(class_23393.method_10063());
                            }
                            continue;
                        }
                        if (!class_26802.method_27852(class_2246.field_20422) && !class_26802.method_27852(class_2246.field_20421) || (Integer)class_26802.method_11654((class_2769)class_4481.field_20420) < 5) continue;
                        ++n7;
                    }
                }
            }
        }
        n = Math.max(1, this.sensitivity.getIntValue());
        int n9 = Math.max(longOpenHashSet.size(), n7 >= 2 ? n : 0);
        if (n9 >= n) {
            this.r(l, new ChunkCluster(new class_1923(n2, n3), n9, List.copyOf(arrayList)));
            return;
        } else {
            this.M(l);
        }
    }

    private void r(long l, ChunkCluster sxFyOw7E2eAuhsxyFvs) {
        ChunkCluster sxFyOw7E2eAuhsxyFvs2 = this.geodes.put(l, sxFyOw7E2eAuhsxyFvs);
        if (sxFyOw7E2eAuhsxyFvs.equals(sxFyOw7E2eAuhsxyFvs2)) return;
        this.candidatesDirty = true;
    }

    private void M(long l) {
        if (this.geodes.remove(l) == null) return;
        this.candidatesDirty = true;
    }

    private List<class_2338> I(List<class_2338> list, int n) {
        if (list.size() < n) {
            return List.of();
        }
        boolean[] blArray = new boolean[list.size()];
        List<class_2338> list2 = List.of();
        for (int i = 0; i < list.size(); ++i) {
            if (blArray[i]) continue;
            ArrayList<class_2338> arrayList = new ArrayList<class_2338>();
            ArrayDeque<Integer> arrayDeque = new ArrayDeque<Integer>();
            arrayDeque.add(i);
            blArray[i] = true;
            while (!arrayDeque.isEmpty()) {
                int n2 = (Integer)arrayDeque.remove();
                class_2338 class_23382 = list.get(n2);
                arrayList.add(class_23382);
                for (int j = 0; j < list.size(); ++j) {
                    if (blArray[j] || !(class_23382.method_10262((class_2382)list.get(j)) <= 121.0)) continue;
                    blArray[j] = true;
                    arrayDeque.add(j);
                }
            }
            if (arrayList.size() < n || arrayList.size() <= list2.size() || !this.Q(arrayList)) continue;
            list2 = arrayList;
        }
        return list2;
    }

    private boolean Q(List<class_2338> list) {
        int n = list.size();
        double d = 0.0;
        double d2 = 0.0;
        double d3 = 0.0;
        for (class_2338 object22 : list) {
            d += (double)object22.method_10263();
            d2 += (double)object22.method_10264();
            d3 += (double)object22.method_10260();
        }
        d /= (double)n;
        d2 /= (double)n;
        d3 /= (double)n;
        double[][] object3 = new double[4][4];
        double[] object4 = new double[4];
        for (class_2338 class_23382 : list) {
            double d4 = (double)class_23382.method_10263() - d;
            double d5 = (double)class_23382.method_10264() - d2;
            double d6 = (double)class_23382.method_10260() - d3;
            double d7 = d4 * d4 + d5 * d5 + d6 * d6;
            double[] dArray = new double[]{d4, d5, d6, 1.0};
            for (int i = 0; i < 4; ++i) {
                for (int j = 0; j < 4; ++j) {
                    object3[i][j] = object3[i][j] + dArray[i] * dArray[j];
                }
                object4[i] = object4[i] + dArray[i] * d7;
            }
        }
        double[] object5 = SusChunkFinder.X(object3, object4);
        if (object5 == null) {
            return false;
        }
        double var12_10 = object5[0] / 2.0;
        double var14_19 = object5[1] / 2.0;
        double var16_20 = object5[2] / 2.0;
        double var18_21 = object5[3] + var12_10 * var12_10 + var14_19 * var14_19 + var16_20 * var16_20;
        if (var18_21 <= 0.0) {
            return false;
        }
        double d8 = Math.sqrt((double)var18_21);
        if (d8 < 3.0) return false;
        if (d8 > 7.0) return false;
        double d9 = d + var12_10;
        double d10 = d2 + var14_19;
        double d11 = d3 + var16_20;
        double d12 = 0.0;
        double d13 = 0.0;
        double d14 = 0.0;
        double d15 = 0.0;
        HashSet<Integer> hashSet = new HashSet<Integer>();
        int n3 = Integer.MAX_VALUE;
        int n4 = Integer.MAX_VALUE;
        int n5 = Integer.MAX_VALUE;
        int n6 = Integer.MIN_VALUE;
        int n7 = Integer.MIN_VALUE;
        int n8 = Integer.MIN_VALUE;
        for (class_2338 class_23383 : list) {
            double d16;
            double d17;
            double d18 = (double)class_23383.method_10263() - d9;
            double d19 = Math.sqrt(d18 * d18 + (d17 = (double)class_23383.method_10264() - d10) * d17 + (d16 = (double)class_23383.method_10260() - d11) * d16);
            if (d19 < 1.0E-4) {
                d19 = 1.0;
            }
            d12 += Math.abs(d19 - d8);
            d13 += d18 / d19;
            d14 += d17 / d19;
            d15 += d16 / d19;
            hashSet.add((d18 >= 0.0 ? 1 : 0) | (d17 >= 0.0 ? 2 : 0) | (d16 >= 0.0 ? 4 : 0));
            n3 = Math.min(n3, class_23383.method_10263());
            n6 = Math.max(n6, class_23383.method_10263());
            n4 = Math.min(n4, class_23383.method_10264());
            n7 = Math.max(n7, class_23383.method_10264());
            n5 = Math.min(n5, class_23383.method_10260());
            n8 = Math.max(n8, class_23383.method_10260());
        }
        if (d12 / (double)n > 1.35) return false;
        if (hashSet.size() < 3) return false;
        double d20 = Math.sqrt(d13 * d13 + d14 * d14 + d15 * d15) / (double)n;
        if (d20 > 0.72) {
            return false;
        }
        class_2338 class_23384 = class_2338.method_49637((double)d9, (double)d10, (double)d11);
        if (this.mc.field_1687.method_8314(class_1944.field_9282, class_23384) > 3) {
            return false;
        }
        int n9 = n6 - n3 + 1;
        int n10 = n7 - n4 + 1;
        int n11 = n8 - n5 + 1;
        if (n9 < 3) {
            if (n11 < 3) return false;
        }
        if (n9 + n11 < 6) return false;
        if (n10 < 2) return false;
        return true;
    }

    private static double[] X(double[][] dArray, double[] dArray2) {
        int n;
        int n2;
        double[][] dArray3 = new double[4][5];
        for (n2 = 0; n2 < 4; ++n2) {
            System.arraycopy(dArray[n2], 0, dArray3[n2], 0, 4);
            dArray3[n2][4] = dArray2[n2];
        }
        for (n2 = 0; n2 < 4; ++n2) {
            n = n2;
            for (int i = n2 + 1; i < 4; ++i) {
                if (!(Math.abs(dArray3[i][n2]) > Math.abs(dArray3[n][n2]))) continue;
                n = i;
            }
            double[] dArray4 = dArray3[n2];
            dArray3[n2] = dArray3[n];
            dArray3[n] = dArray4;
            if (Math.abs(dArray3[n2][n2]) < 1.0E-9) {
                return null;
            }
            for (int i = n2 + 1; i < 4; ++i) {
                double d = dArray3[i][n2] / dArray3[n2][n2];
                for (int j = n2; j <= 4; ++j) {
                    dArray3[i][j] = dArray3[i][j] - d * dArray3[n2][j];
                }
            }
        }
        double[] dArray5 = new double[4];
        for (n = 3; n >= 0; --n) {
            double d = 0.0;
            for (int i = n + 1; i < 4; ++i) {
                d += dArray3[n][i] * dArray5[i];
            }
            dArray5[n] = (dArray3[n][4] - d) / dArray3[n][n];
        }
        return dArray5;
    }

    private static long J(int n, int n2) {
        return class_1923.method_8331((int)(n >> 3), (int)(n2 >> 3));
    }

    private static boolean Y(class_2248 class_22482) {
        if (class_22482 == class_2246.field_27159) return true;
        if (class_22482 == class_2246.field_27160) return true;
        if (class_22482 == class_2246.field_27114) return true;
        if (class_22482 == class_2246.field_29032) return true;
        if (!SusChunkFinder.U(class_22482)) return false;
        return true;
    }

    private static boolean f(class_2248 class_22482) {
        if (class_22482 == class_2246.field_27159) return true;
        if (class_22482 == class_2246.field_27160) return true;
        if (!SusChunkFinder.U(class_22482)) return false;
        return true;
    }

    private static boolean U(class_2248 class_22482) {
        if (class_22482 == class_2246.field_27164) return true;
        if (class_22482 == class_2246.field_27163) return true;
        if (class_22482 == class_2246.field_27162) return true;
        if (class_22482 != class_2246.field_27161) return false;
        return true;
    }

    private void o() {
        boolean bl;
        if (this.mc.field_1687 == null || this.ticks % 20 != 0 || !(bl = this.geodes.entrySet().removeIf(this::lmbd$pruneUnloaded$0))) return;
        this.candidatesDirty = true;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        if (this.mc.field_1687 == null || this.geodes.isEmpty()) {
            return;
        }
        this.S();
        int n = this.alpha.getIntValue();
        if (n == 0) {
            return;
        }
        Color color = new Color(255, 0, 0, n);
        this.candidatePlates.draw(worldRenderEvent, (LongSet)this.candidateKeys, color, null, 1.0f, 63.0, 0.05);
        boolean bl = this.markGeodeChunks.getValue();
        boolean bl2 = this.renderClusters.getValue();
        if (!bl && !bl2) {
            return;
        }
        class_4184 class_41842 = InverseProjectionScratch.getCamera();
        if (class_41842 == null || !class_41842.method_19332()) {
            return;
        }
        Color color2 = new Color(180, 100, 255, n / 3);
        Color color3 = new Color(195, 125, 255, n);
        this.renderBoxes.clear();
        this.renderLines.clear();
        for (ChunkCluster sxFyOw7E2eAuhsxyFvs : this.geodes.values()) {
            double d = sxFyOw7E2eAuhsxyFvs.pos.method_8326();
            double d2 = sxFyOw7E2eAuhsxyFvs.pos.method_8328();
            if (bl && OriginX.box(d, 63.0, d2, d + 16.0, 63.05, d2 + 16.0)) {
                this.renderBoxes.add(new kryzex.util.Color(d, 63.0, d2, d + 16.0, 63.05, d2 + 16.0, color2));
                InverseProjectionScratch.addBoxOutline(this.renderLines, d, 63.0, d2, d + 16.0, 63.05, d2 + 16.0, color3, 1.5f);
            }
            if (!bl2) continue;
            for (class_2338 class_23382 : sxFyOw7E2eAuhsxyFvs.clusterPositions) {
                if (!OriginX.box(class_23382.method_10263(), class_23382.method_10264(), class_23382.method_10260(), class_23382.method_10263() + 1, class_23382.method_10264() + 1, class_23382.method_10260() + 1)) continue;
                this.renderBoxes.add(new kryzex.util.Color(class_23382.method_10263(), class_23382.method_10264(), class_23382.method_10260(), class_23382.method_10263() + 1, class_23382.method_10264() + 1, class_23382.method_10260() + 1, color2));
            }
        }
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        try {
            InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
            InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
            InverseProjectionScratch.renderLines(class_45872, this.renderLines);
            return;
        }
        finally {
            class_45872.method_22909();
        }
    }

    private Set<Long> S() {
        boolean bl;
        int n = this.simulationDistance.getIntValue();
        boolean bl2 = bl = this.scanQueue.isEmpty() || this.ticksSinceCommit >= 60;
        if (n == this.cachedSimulationRadius && (!this.candidatesDirty || !bl)) return this.cachedCandidates;
        this.cachedCandidates = this.u(n);
        this.candidateKeys.clear();
        this.candidateKeys.addAll(this.cachedCandidates);
        this.cachedSimulationRadius = n;
        this.candidatesDirty = false;
        this.ticksSinceCommit = 0;
        return this.cachedCandidates;
    }

    private Set<Long> u(int n) {
        ArrayList<ChunkCluster> arrayList = new ArrayList<ChunkCluster>(this.geodes.values());
        arrayList.sort(Comparator.comparingInt(SusChunkFinder::lmbd$calculateCandidateChunks$0).thenComparingInt(SusChunkFinder::lmbd$calculateCandidateChunks$1));
        long[] lArray = new long[arrayList.size()];
        for (int i = 0; i < arrayList.size(); ++i) {
            lArray[i] = arrayList.get((int)i).pos.method_8324();
        }
        return ChunkSetBuilder.build(lArray, n);
    }

    private static int lmbd$calculateCandidateChunks$1(ChunkCluster sxFyOw7E2eAuhsxyFvs) {
        return sxFyOw7E2eAuhsxyFvs.pos.field_9180;
    }

    private static int lmbd$calculateCandidateChunks$0(ChunkCluster sxFyOw7E2eAuhsxyFvs) {
        return sxFyOw7E2eAuhsxyFvs.pos.field_9181;
    }

    private boolean lmbd$pruneUnloaded$0(Map.Entry entry) {
        int n;
        int n2 = class_1923.method_8325((long)((Long)entry.getKey()));
        if (this.mc.field_1687.method_8393(n2, n = class_1923.method_8332((long)((Long)entry.getKey())))) return false;
        return true;
    }

    private static boolean lmbd$scanNextChunk$0(class_2680 class_26802) {
        if (SusChunkFinder.f(class_26802.method_26204())) return true;
        if (class_26802.method_27852(class_2246.field_20422)) return true;
        if (!class_26802.method_27852(class_2246.field_20421)) return false;
        return true;
    }

    private static int lmbd$enqueueLoadedChunks$0(class_1923 class_19232, class_2818 class_28182) {
        class_1923 class_19233 = class_28182.method_12004();
        return Math.max(Math.abs(class_19233.field_9181 - class_19232.field_9181), Math.abs(class_19233.field_9180 - class_19232.field_9180));
    }

    static {
        a = new String[]{"Mark Geode Chunks", "Chunk radius used to triangulate the possible player origin", "Geode light-signature threshold (maximum 20)", "Simulation Distance", "Sus Chunk Finder", "Sensitivity", "Render Clusters", "Alpha", "Finds suspicious chunks from amethyst and full-beehive generation signals"};
        DIRECTIONS = class_2350.values();
        NEIGHBORS = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    }
}
