package kryzex.modules.render;

import java.util.List;
import kryzex.gui.HudInfo;
import kryzex.gui.MarkStore;
import kryzex.gui.ModuleLists;
import kryzex.gui.RadarSource;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.modules.misc.NameProtect;
import kryzex.modules.render.HUD;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_640;

final class Singleplayer
implements HudInfo,
RadarSource {
    final HUD this$0;

    public Singleplayer(HUD hUD) {
        this.this$0 = hUD;
    }

    @Override
    public int fps() {
        return HUD.w(this.this$0).method_47599();
    }

    @Override
    public String ping() {
        if (this.this$0.spoofPing.getValue()) {
            return String.valueOf(this.this$0.spoofedPing.getIntValue());
        }
        if (HUD.f((HUD)this.this$0).field_1724 == null) return "0";
        if (HUD.n(this.this$0).method_1562() == null) return "0";
        class_640 class_6402 = HUD.c(this.this$0).method_1562().method_2871(HUD.L((HUD)this.this$0).field_1724.method_5667());
        if (class_6402 == null) {
            return "0";
        }
        String string = String.valueOf(class_6402.method_2959());
        return string;
    }

    @Override
    public String server() {
        String string = this.this$0.customIp.getValue();
        if (string != null && !string.isBlank()) {
            return string.trim();
        }
        if (HUD.N(this.this$0).method_1558() != null) {
            return HUD.b((HUD)this.this$0).method_1558().field_3761;
        }
        if (!HUD.t(this.this$0).method_1542()) return "";
        return "Singleplayer";
    }

    @Override
    public boolean inWorld() {
        if (HUD.P((HUD)this.this$0).field_1724 == null) return false;
        if (HUD.l((HUD)this.this$0).field_1687 == null) return false;
        return true;
    }

    @Override
    public double x() {
        return HUD.G((HUD)this.this$0).field_1724.method_23317();
    }

    @Override
    public double y() {
        return HUD.E((HUD)this.this$0).field_1724.method_23318();
    }

    @Override
    public double z() {
        return HUD.r((HUD)this.this$0).field_1724.method_23321();
    }

    @Override
    public float yaw() {
        if (HUD.B((HUD)this.this$0).field_1724 == null) {
            return 0.0f;
        }
        float f = HUD.e((HUD)this.this$0).field_1724.method_5705(this.this$0.tickDelta);
        return f;
    }

    @Override
    public boolean nether() {
        if (HUD.V((HUD)this.this$0).field_1687 == null) return false;
        if (HUD.W((HUD)this.this$0).field_1687.method_27983() != class_1937.field_25180) return false;
        return true;
    }

    @Override
    public String playerName() {
        return NameProtect.O(HUD.X((HUD)this.this$0).field_1724 == null ? "" : HUD.C((HUD)this.this$0).field_1724.method_5477().getString());
    }

    @Override
    public float health() {
        if (HUD.j((HUD)this.this$0).field_1724 == null) {
            return 0.0f;
        }
        float f = HUD.K((HUD)this.this$0).field_1724.method_6032();
        return f;
    }

    public int d(String string) {
        Integer n = this.this$0.categories.get(string);
        if (n != null) return n;
        this.this$0.categories.clear();
        for (Category category : Category.values()) {
            for (Module module : ModuleLists.category(this.this$0, category)) {
                this.this$0.categories.put(module.getName().toString(), category.ordinal());
            }
        }
        n = this.this$0.categories.getOrDefault(string, Category.values().length);
        this.this$0.categories.putIfAbsent(string, n);
        return n;
    }

    @Override
    public List<String> modules() {
        return ModuleLists.enabled(this.this$0);
    }

    @Override
    public void scan(float f, boolean bl, MarkStore markStore) {
        if (HUD.i((HUD)this.this$0).field_1724 == null || HUD.k((HUD)this.this$0).field_1687 == null) {
            return;
        }
        float f2 = this.this$0.tickDelta;
        class_243 class_2432 = HUD.q((HUD)this.this$0).field_1724.method_30950(f2);
        double d = (double)f * (double)f;
        for (class_1297 class_12972 : HUD.o((HUD)this.this$0).field_1687.method_18112()) {
            if (class_12972 == HUD.H((HUD)this.this$0).field_1724 || !(class_12972 instanceof class_1309)) continue;
            class_1309 class_13092 = (class_1309)class_12972;
            if (class_12972 instanceof class_1531 || !class_13092.method_5805()) continue;
            int n2 = class_12972 instanceof class_1657 ? 0 : (class_12972 instanceof class_1569 ? 1 : 2);
            if (n2 != 0 && !bl) continue;
            class_243 class_2433 = class_12972.method_30950(f2);
            double d2 = class_2433.field_1352 - class_2432.field_1352;
            double d3 = class_2433.field_1350 - class_2432.field_1350;
            if (!(d2 * d2 + d3 * d3 <= d)) continue;
            markStore.add(class_12972.method_5628(), (float)d2, (float)(class_2433.field_1351 - class_2432.field_1351), (float)d3, n2);
        }
    }
}
