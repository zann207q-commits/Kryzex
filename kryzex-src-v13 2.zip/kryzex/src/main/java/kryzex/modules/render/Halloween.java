package kryzex.modules.render;

import kryzex.cinematic.CinematicDirector;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.util.SecureString;

public final class Halloween
extends Module {
    public static NumberSetting darkness;
    public static NumberSetting fogDensity;
    public static NumberSetting eventVolume;
    private final ActionSetting replay = new ActionSetting(SecureString.of("Replay Intro"), CinematicDirector::replayIntro);
    private static String[] a;

    public Halloween() {
        super(SecureString.of("Halloween"), SecureString.of("A Kryzex Halloween night: darkness, fog, a haunted sky and a visitor on a broom"), -1, Category.RENDER);
        this.replay.setDescription(SecureString.of("Plays the Halloween welcome event again"));
        this.addSettings(darkness, fogDensity, eventVolume, this.replay);
    }

    @Override
    public void onEnable() {
        CinematicDirector.onModuleEnabled();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        CinematicDirector.onModuleDisabled();
        super.onDisable();
    }

    static {
        String[] stringArray = a = new String[]{"How dark the Halloween night gets (fullbright is overridden)", "Plays the Halloween welcome event again", "Fog Density", "How thick the Halloween fog and ground mist are", "A Kryzex Halloween night: darkness, fog, a haunted sky and a visitor on a broom", "Halloween Darkness", "Replay Intro", "Halloween", "Event Music Volume", "Volume of the Halloween event song"};
        darkness = new NumberSetting(SecureString.of(stringArray[5]), 0.0, 100.0, 60.0, 1.0).getValue(SecureString.of(stringArray[0]));
        fogDensity = new NumberSetting(SecureString.of(stringArray[2]), 0.0, 100.0, 55.0, 1.0).getValue(SecureString.of(stringArray[3]));
        eventVolume = new NumberSetting(SecureString.of(stringArray[8]), 0.0, 100.0, 60.0, 1.0).getValue(SecureString.of(stringArray[9]));
    }
}
