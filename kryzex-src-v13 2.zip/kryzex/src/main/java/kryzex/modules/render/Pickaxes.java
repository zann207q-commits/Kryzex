package kryzex.modules.render;

public enum Pickaxes {
    Pickaxes,
    Always,
    Swords,
    Empty_Hand,
    Swords_And_Empty;

}
