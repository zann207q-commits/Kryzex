package kryzex.modules.render;

public enum Spooky {
    Spooky,
    Chrome_Liquid,
    Spooky_3D,
    Chrome_Liquid_3D;

}
