package kryzex.modules.render;

import java.awt.Color;
import kryzex.event.HudRenderEvent;
import kryzex.event.PacketSendEvent;
import kryzex.event.Subscribe;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.render.This0;
import kryzex.util.ColorUtil;
import kryzex.util.FontRenderer;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.MathUtil;
import kryzex.util.SecureString;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import org.joml.Matrix3x2fStack;

public final class TargetHUD
extends Module {
    private final NumberSetting xPosition = new NumberSetting(SecureString.of("X"), 0.0, 1920.0, 500.0, 1.0);
    private final NumberSetting yPosition = new NumberSetting(SecureString.of("Y"), 0.0, 1080.0, 500.0, 1.0);
    private final BoolSetting timeoutEnabled = new BoolSetting(SecureString.of("Timeout"), true).setDescription(SecureString.of("Target hud will disappear after 10 seconds"));
    private final NumberSetting fadeSpeed = new NumberSetting(SecureString.of("Fade Speed"), 5.0, 30.0, 15.0, 1.0).getValue(SecureString.of("Speed of animations"));
    private final Color primaryColor = new Color(255, 50, 100);
    private final Color backgroundColor = new Color(0, 0, 0, 175);
    private long lastAttackTime = 0L;
    public static float fadeProgress;
    private float currentHealth = 0.0f;
    private This0 hudHandler;
    private static String[] a;

    public TargetHUD() {
        super(SecureString.of("Target HUD"), SecureString.of("Displays detailed information about your target with style"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.xPosition, this.yPosition, this.timeoutEnabled, this.fadeSpeed});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onHudRender(HudRenderEvent hudRenderEvent) {
        class_332 class_3322 = hudRenderEvent.context;
        int n = this.xPosition.getIntValue();
        int n2 = this.yPosition.getIntValue();
        float f = this.fadeSpeed.getFloatValue();
        Color color = this.primaryColor;
        Color color2 = this.backgroundColor;
        InverseProjectionScratch.unscaledProjection();
        boolean bl = this.mc.field_1724.method_6052() != null && this.mc.field_1724.method_6052() instanceof class_1657 && this.mc.field_1724.method_6052().method_5805();
        boolean bl2 = !this.timeoutEnabled.getValue() || System.currentTimeMillis() - this.lastAttackTime <= 10000L;
        float f2 = bl && bl2 ? 0.0f : 1.0f;
        fadeProgress = InverseProjectionScratch.fast(fadeProgress, f2, f);
        if (fadeProgress < 0.99f && bl) {
            class_1309 class_13092 = this.mc.field_1724.method_6052();
            class_640 class_6402 = this.mc.method_1562().method_2871(class_13092.method_5667());
            Matrix3x2fStack matrix3x2fStack = class_3322.method_51448();
            matrix3x2fStack.pushMatrix();
            float f3 = 1.0f - fadeProgress;
            float f4 = 0.8f + 0.2f * f3;
            matrix3x2fStack.translate((float)n, (float)n2);
            matrix3x2fStack.scale(f4, f4);
            matrix3x2fStack.translate((float)(-n), (float)(-n2));
            this.currentHealth = InverseProjectionScratch.fast(this.currentHealth, class_13092.method_6032() + class_13092.method_6067(), f * 0.5f);
            this.j(class_3322, n, n2, (class_1657)class_13092, class_6402, f3, color, color2);
            matrix3x2fStack.popMatrix();
        }
        InverseProjectionScratch.scaledProjection();
    }

    private void j(class_332 class_3322, int n, int n2, class_1657 class_16572, class_640 class_6402, float f, Color color, Color color2) {
        Matrix3x2fStack matrix3x2fStack = class_3322.method_51448();
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(50.0f * f)), n - 5, n2 - 5, n + 300 + 5, n2 + 180 + 5, 15.0, 15.0, 15.0, 15.0, 30.0);
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)((float)color2.getAlpha() * f)), n, n2, n + 300, n2 + 180, 10.0, 10.0, 10.0, 10.0, 20.0);
        Color color3 = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f));
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, color3, n + 20, n2, n + 300 - 20, n2 + 3, 0.0, 0.0, 0.0, 0.0, 10.0);
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, color3, n + 20, n2 + 180 - 3, n + 300 - 20, n2 + 180, 0.0, 0.0, 0.0, 0.0, 10.0);
        if (class_6402 != null) {
            String string;
            InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, new Color(30, 30, 30, (int)(200.0f * f)), n + 15, n2 + 15, n + 85, n2 + 85, 5.0, 5.0, 5.0, 5.0, 10.0);
            class_7532.method_52722((class_332)class_3322, (class_8685)class_6402.method_52810(), (int)(n + 25), (int)(n2 + 25), 50);
            FontRenderer.drawString(class_16572.method_5477().getString(), class_3322, n + 100, n2 + 25, ColorUtil.a((int)((float)(System.currentTimeMillis() % 1000L) / 1000.0f), 255).getRGB());
            String[] stringArray = a;
            FontRenderer.drawString(MathUtil.roundToNearest(class_16572.method_5739((class_1297)this.mc.field_1724), 1.0) + " blocks away", class_3322, n + 100, n2 + 45, Color.WHITE.getRGB());
            InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, new Color(60, 60, 60, (int)(200.0f * f)), n + 15, n2 + 95, n + 300 - 15, n2 + 110, 5.0, 5.0, 5.0, 5.0, 10.0);
            float f2 = this.currentHealth / class_16572.method_6063();
            float f3 = 270.0f * Math.min(1.0f, f2);
            InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, this.K(f2 * (float)((double)0.8f + (double)0.2f * Math.sin((double)System.currentTimeMillis() / 300.0)), f), n + 15, n2 + 95, n + 15 + (int)f3, n2 + 110, 5.0, 5.0, 5.0, 5.0, 10.0);
            String string2 = Math.round(this.currentHealth) + "/" + Math.round(class_16572.method_6063()) + " HP";
            FontRenderer.drawString(string2, class_3322, n + 15 + (int)f3 / 2 - FontRenderer.getWidth(string2) / 2, n2 + 95, Color.WHITE.getRGB());
            int n3 = n2 + 120;
            this.C(class_3322, n + 15, n3, 80, 45, "PING", class_6402.method_2959() + "ms", this.c(class_6402.method_2959(), f), color3, f);
            if (class_6402 != null) {
                string = "PLAYER";
            } else {
                stringArray = a;
                string = "BOT";
            }
            Color color4 = class_6402 != null ? new Color(100, 255, 100, (int)(255.0f * f)) : new Color(255, 100, 100, (int)(255.0f * f));
            stringArray = a;
            this.C(class_3322, n + 100 + 5, n3, 80, 45, "TYPE", string, color4, color3, f);
            if (class_16572.field_6235 > 0) {
                this.C(class_3322, n + 200 + 5, n3, 80, 45, "HURT", "" + class_16572.field_6235, this.T(class_16572.field_6235, f), color3, f);
                return;
            } else {
                stringArray = a;
                this.C(class_3322, n + 200 + 5, n3, 80, 45, "HURT", "No", new Color(150, 150, 150, (int)(255.0f * f)), color3, f);
            }
            return;
        } else {
            FontRenderer.drawString("BOT DETECTED", class_3322, n + 150 - FontRenderer.getWidth("BOT DETECTED") / 2, n2 + 90, new Color(255, 50, 50).getRGB());
        }
    }

    private void C(class_332 class_3322, int n, int n2, int n3, int n4, String string, String string2, Color color, Color color2, float f) {
        Matrix3x2fStack matrix3x2fStack = class_3322.method_51448();
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, color2, n, n2, n + n3, n2 + 3, 3.0, 3.0, 0.0, 0.0, 6.0);
        InverseProjectionScratch.renderRoundedQuad(matrix3x2fStack, new Color(30, 30, 30, (int)(200.0f * f)), n, n2 + 3, n + n3, n2 + n4, 0.0, 0.0, 3.0, 3.0, 6.0);
        FontRenderer.drawString(string, class_3322, n + n3 / 2 - FontRenderer.getWidth(string) / 2, n2 + 5, new Color(200, 200, 200, (int)(255.0f * f)).getRGB());
        FontRenderer.drawString(string2, class_3322, n + n3 / 2 - FontRenderer.getWidth(string2) / 2, n2 + n4 - 17, color.getRGB());
    }

    private Color K(float f, float f2) {
        Color color;
        if (f > 0.75f) {
            color = ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (1.0f - f) * 4.0f);
            return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f2));
        } else if (f > 0.25f) {
            color = ColorUtil.a(new Color(255, 255, 100), new Color(255, 100, 100), (0.75f - f) * 2.0f);
            return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f2));
        } else {
            float f3 = f < 0.1f ? (float)((double)0.7f + (double)0.3f * Math.sin((double)System.currentTimeMillis() / 200.0)) : 1.0f;
            color = new Color((int)(255.0f * f3), (int)(100.0f * f3), (int)(100.0f * f3));
        }
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f2));
    }

    private Color c(int n, float f) {
        Color color = n < 50 ? new Color(100, 255, 100) : (n < 100 ? ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (float)(n - 50) / 50.0f) : (n < 200 ? ColorUtil.a(new Color(255, 255, 100), new Color(255, 150, 50), (float)(n - 100) / 100.0f) : ColorUtil.a(new Color(255, 150, 50), new Color(255, 80, 80), Math.min(1.0f, (float)(n - 200) / 300.0f))));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f));
    }

    private Color T(int n, float f) {
        double d = (double)0.7f + (double)0.3f * Math.sin((double)System.currentTimeMillis() / 150.0);
        float f2 = Math.min(1.0f, (float)n / 10.0f);
        Color color = new Color(255, (int)(50.0f + 100.0f * (1.0f - f2)), (int)(50.0f + 100.0f * (1.0f - f2)));
        return new Color((int)((float)color.getRed() * (float)d), (int)((float)color.getGreen() * (float)d), (int)((float)color.getBlue() * (float)d), (int)(255.0f * f));
    }

    @Subscribe
    public void onPacketSend(PacketSendEvent packetSendEvent) {
        class_2596<?> class_25962 = packetSendEvent.packet;
        if (!(class_25962 instanceof class_2824)) return;
        class_2824 class_28242 = (class_2824)class_25962;
        if (this.hudHandler == null) {
            this.hudHandler = new This0(this);
        }
        if (!this.hudHandler.O(class_28242)) return;
        this.lastAttackTime = System.currentTimeMillis();
    }

    static {
        a = new String[]{"HURT", "TYPE", "Speed of animations", "PLAYER", "Target HUD", "Displays detailed information about your target with style", "BOT", "ms", "BOT DETECTED", "Target hud will disappear after 10 seconds", " HP", "No", "Timeout", "HURT", "PING", "BOT DETECTED", "Fade Speed", " blocks away"};
        fadeProgress = 1.0f;
    }
}
