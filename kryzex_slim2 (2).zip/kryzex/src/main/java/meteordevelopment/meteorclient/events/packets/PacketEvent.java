package meteordevelopment.meteorclient.events.packets;

import net.minecraft.class_2596;

public class PacketEvent {
    public static class Receive extends PacketEvent {
        public class_2596<?> packet;

        public Receive(class_2596<?> packet) {
            this.packet = packet;
        }
    }
}
