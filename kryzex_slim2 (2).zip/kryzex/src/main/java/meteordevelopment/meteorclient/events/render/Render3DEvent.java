package meteordevelopment.meteorclient.events.render;

import meteordevelopment.meteorclient.renderer.Renderer3D;

public class Render3DEvent {
    public Renderer3D renderer;
    public float tickDelta;

    public Render3DEvent(Renderer3D renderer, float tickDelta) {
        this.renderer = renderer;
        this.tickDelta = tickDelta;
    }
}
