package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ChatUtils {
    private static String fmt(String msg, Object... args) {
        if (args == null || args.length == 0) return msg;
        try {
            return String.format(msg, args);
        } catch (RuntimeException e) {
            return msg;
        }
    }

    public static void sendMsg(class_2561 text) {
        class_310 mc = MeteorClient.mc;
        if (mc == null) return;
        mc.execute(() -> {
            if (mc.field_1724 != null) {
                mc.field_1724.method_7353(text, false);
            }
        });
    }

    public static void info(String msg, Object... args) {
        ChatUtils.sendMsg((class_2561)class_2561.method_43470((String)("\u00a78[\u00a7bElysia\u00a78] \u00a7f" + fmt(msg, args))));
    }

    public static void warning(String msg, Object... args) {
        ChatUtils.sendMsg((class_2561)class_2561.method_43470((String)("\u00a78[\u00a7bElysia\u00a78] \u00a7e" + fmt(msg, args))));
    }

    public static void error(String msg, Object... args) {
        ChatUtils.sendMsg((class_2561)class_2561.method_43470((String)("\u00a78[\u00a7bElysia\u00a78] \u00a7c" + fmt(msg, args))));
    }
}
