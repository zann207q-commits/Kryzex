package meteordevelopment.meteorclient.utils.render.color;

public class SettingColor extends Color {
    public SettingColor(int r, int g, int b, int a) {
        super(r, g, b, a);
    }

    public SettingColor(int r, int g, int b) {
        super(r, g, b, 255);
    }

    public SettingColor(SettingColor other) {
        super(other);
    }
}
