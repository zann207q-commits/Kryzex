package meteordevelopment.meteorclient.utils;

import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_2818;
import net.minecraft.class_310;

public class Utils {
    /** Loaded chunks around the player (render distance). */
    public static Iterable<class_2818> chunks() {
        List<class_2818> out = new ArrayList<class_2818>();
        class_310 mc = MeteorClient.mc;
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) return out;
        int r = mc.field_1690.method_38521();
        int cx = mc.field_1724.method_31477() >> 4;
        int cz = mc.field_1724.method_31479() >> 4;
        for (int x = cx - r; x <= cx + r; ++x) {
            for (int z = cz - r; z <= cz + r; ++z) {
                class_2818 c = mc.field_1687.method_2935().method_21730(x, z);
                if (c != null) out.add(c);
            }
        }
        return out;
    }
}
