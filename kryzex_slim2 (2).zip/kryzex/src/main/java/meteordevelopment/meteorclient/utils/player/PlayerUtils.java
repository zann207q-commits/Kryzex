package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.MeteorClient;

public class PlayerUtils {
    public static double squaredDistanceTo(double x, double y, double z) {
        if (MeteorClient.mc == null || MeteorClient.mc.field_1724 == null) return Double.MAX_VALUE;
        double dx = MeteorClient.mc.field_1724.method_23317() - x;
        double dy = MeteorClient.mc.field_1724.method_23318() - y;
        double dz = MeteorClient.mc.field_1724.method_23321() - z;
        return dx * dx + dy * dy + dz * dz;
    }
}
