package meteordevelopment.meteorclient.utils.render;

import kryzex.gui.NotificationToast;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2561;

/** Compat toast: reuses the Kryzex notification toast so it is a valid Toast. */
public class MeteorToast
extends NotificationToast {
    private MeteorToast(class_1799 icon, class_2561 title, class_2561 text) {
        super(icon, title, text, false);
    }

    public static class Builder {
        private final String title;
        private String text = "";
        private class_1792 icon = class_1802.field_8106;

        public Builder(String title) {
            this.title = title;
        }

        public Builder icon(class_1792 icon) {
            this.icon = icon;
            return this;
        }

        public Builder text(String text) {
            this.text = text;
            return this;
        }

        public MeteorToast build() {
            return new MeteorToast(new class_1799((class_1935)this.icon), (class_2561)class_2561.method_43470((String)this.title), (class_2561)class_2561.method_43470((String)this.text));
        }
    }
}
