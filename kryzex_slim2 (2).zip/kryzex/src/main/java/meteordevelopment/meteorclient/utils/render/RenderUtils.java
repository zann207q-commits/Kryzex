package meteordevelopment.meteorclient.utils.render;

import net.minecraft.class_243;

public class RenderUtils {
    /** Tracer origin; refreshed every frame by the bridge. */
    public static class_243 center = new class_243(0.0, 0.0, 0.0);
}
