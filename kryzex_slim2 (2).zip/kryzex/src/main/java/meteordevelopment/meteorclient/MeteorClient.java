package meteordevelopment.meteorclient;

import net.minecraft.class_310;

public class MeteorClient {
    public static class_310 mc = class_310.method_1551();
}
