package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public class IntSetting extends Setting<Integer> {
    public final int min;
    public final int max;
    public final int sliderMin;
    public final int sliderMax;

    private IntSetting(String name, String description, Integer defaultValue, Consumer<Integer> onChanged, IVisible visible, int min, int max, int sliderMin, int sliderMax) {
        super(name, description, defaultValue, onChanged, visible);
        this.min = min;
        this.max = max;
        this.sliderMin = sliderMin;
        this.sliderMax = sliderMax;
    }

    public static class Builder extends SettingBuilder<Builder, Integer, IntSetting> {
        private int min = Integer.MIN_VALUE;
        private int max = Integer.MAX_VALUE;
        private int sliderMin = 0;
        private int sliderMax = 10;

        public Builder() {
            this.defaultValue = 0;
        }

        public Builder min(int min) {
            this.min = min;
            return this;
        }

        public Builder max(int max) {
            this.max = max;
            return this;
        }

        public Builder range(int min, int max) {
            this.min = min;
            this.max = max;
            return this;
        }

        public Builder sliderMin(int sliderMin) {
            this.sliderMin = sliderMin;
            return this;
        }

        public Builder sliderMax(int sliderMax) {
            this.sliderMax = sliderMax;
            return this;
        }

        public Builder sliderRange(int sliderMin, int sliderMax) {
            this.sliderMin = sliderMin;
            this.sliderMax = sliderMax;
            return this;
        }

        @Override
        public IntSetting build() {
            return new IntSetting(this.name, this.description, this.defaultValue, this.onChanged, this.visible, this.min, this.max, this.sliderMin, this.sliderMax);
        }
    }
}
