package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public class EnumSetting<T extends Enum<?>> extends Setting<T> {
    public final T[] constants;

    @SuppressWarnings("unchecked")
    private EnumSetting(String name, String description, T defaultValue, Consumer<T> onChanged, IVisible visible) {
        super(name, description, defaultValue, onChanged, visible);
        this.constants = (T[])defaultValue.getDeclaringClass().getEnumConstants();
    }

    public static class Builder<T extends Enum<?>> extends SettingBuilder<Builder<T>, T, EnumSetting<T>> {
        @Override
        public EnumSetting<T> build() {
            return new EnumSetting<T>(this.name, this.description, this.defaultValue, this.onChanged, this.visible);
        }
    }
}
