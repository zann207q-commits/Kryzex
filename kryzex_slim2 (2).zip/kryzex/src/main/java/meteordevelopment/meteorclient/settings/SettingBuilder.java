package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

@SuppressWarnings("unchecked")
public abstract class SettingBuilder<B, V, S extends Setting<V>> {
    protected String name = "UNNAMED";
    protected String description = "";
    protected V defaultValue;
    protected Consumer<V> onChanged;
    protected IVisible visible;

    public B name(String name) {
        this.name = name;
        return (B)this;
    }

    public B description(String description) {
        this.description = description;
        return (B)this;
    }

    public B defaultValue(V defaultValue) {
        this.defaultValue = defaultValue;
        return (B)this;
    }

    public B onChanged(Consumer<V> onChanged) {
        this.onChanged = onChanged;
        return (B)this;
    }

    public B visible(IVisible visible) {
        this.visible = visible;
        return (B)this;
    }

    public abstract S build();
}
