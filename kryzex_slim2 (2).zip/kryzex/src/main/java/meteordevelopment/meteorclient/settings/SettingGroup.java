package meteordevelopment.meteorclient.settings;

import java.util.ArrayList;
import java.util.List;

public class SettingGroup {
    public final String name;
    public final List<Setting<?>> settings = new ArrayList<Setting<?>>();

    public SettingGroup(String name) {
        this.name = name;
    }

    public <T> Setting<T> add(Setting<T> setting) {
        this.settings.add(setting);
        return setting;
    }
}
