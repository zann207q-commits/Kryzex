package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public class BoolSetting extends Setting<Boolean> {
    private BoolSetting(String name, String description, Boolean defaultValue, Consumer<Boolean> onChanged, IVisible visible) {
        super(name, description, defaultValue, onChanged, visible);
    }

    public static class Builder extends SettingBuilder<Builder, Boolean, BoolSetting> {
        public Builder() {
            this.defaultValue = Boolean.FALSE;
        }

        @Override
        public BoolSetting build() {
            return new BoolSetting(this.name, this.description, this.defaultValue, this.onChanged, this.visible);
        }
    }
}
