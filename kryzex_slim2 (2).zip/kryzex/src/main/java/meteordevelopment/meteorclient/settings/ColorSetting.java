package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class ColorSetting extends Setting<SettingColor> {
    private ColorSetting(String name, String description, SettingColor defaultValue, Consumer<SettingColor> onChanged, IVisible visible) {
        super(name, description, new SettingColor(defaultValue), onChanged, visible);
        this.value = new SettingColor(defaultValue);
    }

    public static class Builder extends SettingBuilder<Builder, SettingColor, ColorSetting> {
        public Builder() {
            this.defaultValue = new SettingColor(255, 255, 255, 255);
        }

        @Override
        public Builder defaultValue(SettingColor defaultValue) {
            this.defaultValue = new SettingColor(defaultValue);
            return this;
        }

        @Override
        public ColorSetting build() {
            return new ColorSetting(this.name, this.description, this.defaultValue, this.onChanged, this.visible);
        }
    }
}
