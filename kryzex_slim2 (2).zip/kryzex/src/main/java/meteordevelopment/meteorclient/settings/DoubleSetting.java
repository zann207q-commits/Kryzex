package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public class DoubleSetting extends Setting<Double> {
    public final double min;
    public final double max;
    public final double sliderMin;
    public final double sliderMax;

    private DoubleSetting(String name, String description, Double defaultValue, Consumer<Double> onChanged, IVisible visible, double min, double max, double sliderMin, double sliderMax) {
        super(name, description, defaultValue, onChanged, visible);
        this.min = min;
        this.max = max;
        this.sliderMin = sliderMin;
        this.sliderMax = sliderMax;
    }

    public static class Builder extends SettingBuilder<Builder, Double, DoubleSetting> {
        private double min = Double.NEGATIVE_INFINITY;
        private double max = Double.POSITIVE_INFINITY;
        private double sliderMin = 0.0;
        private double sliderMax = 10.0;

        public Builder() {
            this.defaultValue = 0.0;
        }

        public Builder defaultValue(double defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder min(double min) {
            this.min = min;
            return this;
        }

        public Builder max(double max) {
            this.max = max;
            return this;
        }

        public Builder range(double min, double max) {
            this.min = min;
            this.max = max;
            return this;
        }

        public Builder sliderRange(double sliderMin, double sliderMax) {
            this.sliderMin = sliderMin;
            this.sliderMax = sliderMax;
            return this;
        }

        @Override
        public DoubleSetting build() {
            return new DoubleSetting(this.name, this.description, this.defaultValue, this.onChanged, this.visible, this.min, this.max, this.sliderMin, this.sliderMax);
        }
    }
}
