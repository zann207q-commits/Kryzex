package meteordevelopment.meteorclient.settings;

import java.util.ArrayList;
import java.util.List;

public class Settings {
    public final List<SettingGroup> groups = new ArrayList<SettingGroup>();
    private final SettingGroup defaultGroup = new SettingGroup("General");

    public Settings() {
        this.groups.add(this.defaultGroup);
    }

    public SettingGroup getDefaultGroup() {
        return this.defaultGroup;
    }

    public SettingGroup createGroup(String name) {
        for (SettingGroup g : this.groups) {
            if (g.name.equals(name)) return g;
        }
        SettingGroup group = new SettingGroup(name);
        this.groups.add(group);
        return group;
    }
}
