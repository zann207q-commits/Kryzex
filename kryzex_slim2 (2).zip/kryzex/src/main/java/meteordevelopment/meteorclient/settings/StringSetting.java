package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public class StringSetting extends Setting<String> {
    private StringSetting(String name, String description, String defaultValue, Consumer<String> onChanged, IVisible visible) {
        super(name, description, defaultValue, onChanged, visible);
    }

    public static class Builder extends SettingBuilder<Builder, String, StringSetting> {
        public Builder() {
            this.defaultValue = "";
        }

        @Override
        public StringSetting build() {
            return new StringSetting(this.name, this.description, this.defaultValue, this.onChanged, this.visible);
        }
    }
}
