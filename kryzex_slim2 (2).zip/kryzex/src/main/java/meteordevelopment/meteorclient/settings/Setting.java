package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

public abstract class Setting<T> {
    public final String name;
    public final String description;
    public final IVisible visible;
    public final T defaultValue;
    protected T value;
    protected final Consumer<T> onChanged;

    protected Setting(String name, String description, T defaultValue, Consumer<T> onChanged, IVisible visible) {
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
        this.onChanged = onChanged;
        this.visible = visible;
    }

    public T get() {
        return this.value;
    }

    public boolean set(T newValue) {
        this.value = newValue;
        if (this.onChanged != null) {
            this.onChanged.accept(newValue);
        }
        return true;
    }

    public boolean isVisible() {
        return this.visible == null || this.visible.isVisible();
    }
}
