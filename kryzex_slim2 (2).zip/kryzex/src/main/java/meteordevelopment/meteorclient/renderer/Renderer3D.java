package meteordevelopment.meteorclient.renderer;

import kryzex.util.PixelPerDepth;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2338;

/** Compat renderer: draws through the Kryzex ESP pipeline. Valid only during MacroRender3DEvent. */
public class Renderer3D {
    private final float tickDelta;

    public Renderer3D(float tickDelta) {
        this.tickDelta = tickDelta;
    }

    private static int argb(Color c) {
        return (c.a & 0xFF) << 24 | (c.r & 0xFF) << 16 | (c.g & 0xFF) << 8 | (c.b & 0xFF);
    }

    public void box(double x1, double y1, double z1, double x2, double y2, double z2, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
        this.box(new class_238(x1, y1, z1, x2, y2, z2), sideColor, lineColor, mode, excludeDir);
    }

    public void box(class_2338 pos, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
        this.box(new class_238(pos), sideColor, lineColor, mode, excludeDir);
    }

    public void box(class_238 box, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
        if (mode.sides() && sideColor != null && sideColor.a > 0) {
            class_12180.method_75541((class_238)box, (class_12179)class_12179.method_75539((int)argb(sideColor))).method_75533();
        }
        if (mode.lines() && lineColor != null && lineColor.a > 0) {
            PixelPerDepth.forFrame(this.tickDelta).box(box, argb(lineColor), 1.0f);
        }
    }

    public void line(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        if (color == null || color.a <= 0) return;
        PixelPerDepth.forFrame(this.tickDelta).line(new class_243(x1, y1, z1), new class_243(x2, y2, z2), argb(color), 1.0f);
    }
}
