package meteordevelopment.meteorclient.systems.modules;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_310;

public abstract class Module {
    public final Category category;
    public final String name;
    public final String description;
    public final Settings settings = new Settings();
    protected final class_310 mc = MeteorClient.mc;
    private boolean active;
    private Runnable disableHook;

    public Module(Category category, String name, String description) {
        this.category = category;
        this.name = name;
        this.description = description;
    }

    public void onActivate() {
    }

    public void onDeactivate() {
    }

    public boolean isActive() {
        return this.active;
    }

    /** Called by the Kryzex bridge only. */
    public final void bridgeSetActive(boolean active) {
        this.active = active;
    }

    public final void bridgeSetDisableHook(Runnable hook) {
        this.disableHook = hook;
    }

    public void toggle() {
        if (this.active && this.disableHook != null) {
            this.disableHook.run();
        }
    }

    public void info(String msg, Object... args) {
        ChatUtils.info(msg, args);
    }

    public void warning(String msg, Object... args) {
        ChatUtils.warning(msg, args);
    }

    public void error(String msg, Object... args) {
        ChatUtils.error(msg, args);
    }
}
