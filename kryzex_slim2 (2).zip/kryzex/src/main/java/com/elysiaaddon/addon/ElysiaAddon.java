package com.elysiaaddon.addon;

import meteordevelopment.meteorclient.systems.modules.Category;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Compat stub of the original addon entry point (only the members the module classes read). */
public class ElysiaAddon {
    public static final Category ELYSIA_FINDER = new Category("Elysia Finder");
    public static final Logger LOG = LoggerFactory.getLogger("Elysia");
}
