package com.elysiaaddon.addon.utils.lyricssky.sky;

/** Compat stub: the nested enum ChunkMode ships as a compiled class in libs/elysia-classes.jar. */
public class FloatWords {
}
