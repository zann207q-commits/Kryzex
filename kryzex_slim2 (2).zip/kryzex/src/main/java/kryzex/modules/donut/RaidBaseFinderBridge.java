package kryzex.modules.donut;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import kryzex.event.MacroPacketReceiveEvent;
import kryzex.event.MacroRender3DEvent;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroActionSetting;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.modules.misc.MacroModule;
import kryzex.util.PixelPerDepth;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_2561;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

/**
 * Raid Base Finder V17 bridge.
 * The finder itself lives in the embedded corz subproject (raidfinder.RaidBaseFinderV17, Yarn names)
 * and is driven through reflection, same pattern as AutoBuilderBridge.
 */
public final class RaidBaseFinderBridge
extends MacroModule {
    private static final String FINDER = "raidfinder.RaidBaseFinderV17";
    private static final String CONFIG = "raidfinder.RaidBaseFinderV17$Config";
    private static final String HOST = "raidfinder.RaidBaseFinderV17$Host";

    private final MacroNumberSetting alertScore = this.addSetting("alert-min-score", new MacroNumberSetting("Alert Min Score", 20.0f, 1.0f, 100.0f).step(1.0f));
    private final MacroNumberSetting espScore = this.addSetting("esp-min-score", new MacroNumberSetting("ESP Min Score", 8.0f, 1.0f, 100.0f).step(1.0f));
    private final MacroNumberSetting baseY = this.addSetting("base-y-max", new MacroNumberSetting("Base Y Max", 10.0f, -60.0f, 60.0f).step(1.0f));
    private final MacroNumberSetting radius = this.addSetting("region-radius", new MacroNumberSetting("Region Radius", 3.0f, 1.0f, 8.0f).step(1.0f));
    private final MacroNumberSetting espRange = this.addSetting("esp-range", new MacroNumberSetting("ESP Range", 128.0f, 32.0f, 512.0f).step(16.0f));
    private final MacroBoolSetting esp = this.addSetting("esp", new MacroBoolSetting("ESP", true));
    private final MacroBoolSetting chatAlert = this.addSetting("chat-alert", new MacroBoolSetting("Chat Alert", true));
    private final MacroBoolSetting donut = this.addSetting("donut-profile", new MacroBoolSetting("DonutSMP Profile", false));
    private final MacroBoolSetting nether = this.addSetting("nether", new MacroBoolSetting("Nether", false));
    private final MacroBoolSetting end = this.addSetting("end", new MacroBoolSetting("End", false));
    private final MacroActionSetting top = this.addSetting("cmd-top", new MacroActionSetting("Print Top", () -> this.cmd("top")));
    private final MacroActionSetting suspect = this.addSetting("cmd-suspect", new MacroActionSetting("Print Suspect", () -> this.cmd("suspect")));
    private final MacroActionSetting save = this.addSetting("cmd-save", new MacroActionSetting("Save Data", () -> this.cmd("save")));
    private final MacroActionSetting clear = this.addSetting("cmd-clear", new MacroActionSetting("Clear Data", () -> this.cmd("clear")));

    private Object finder;
    private Object cfg;
    private Method mEnable;
    private Method mDisable;
    private Method mTick;
    private Method mPacket;
    private Method mRender;
    private Method mCommand;
    private float partial;

    public RaidBaseFinderBridge() {
        super("raid-base-finder", "Raid Base Finder V17", "Passive base finder: scores chunks from packets, entities and block signals (RBF V17).", MacroCategories.BASE_FINDING);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!this.init()) {
            System.err.println("Kryzex: Raid Base Finder V17 - raidfinder runtime not found (is the embedded corz mod loaded?)");
            this.requestDisable();
            return;
        }
        this.applyConfig();
        this.invoke(this.mEnable);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (this.finder != null) {
            this.invoke(this.mDisable);
        }
    }

    @MacroSubscribe
    public void onTick(MacroTickEvent event) {
        if (this.finder == null) return;
        this.applyConfig();
        this.invoke(this.mTick);
    }

    @MacroSubscribe
    public void onPacket(MacroPacketReceiveEvent event) {
        if (this.finder == null || this.mPacket == null) return;
        this.invoke(this.mPacket, event.packet);
    }

    @MacroSubscribe
    public void onRender(MacroRender3DEvent event) {
        if (this.finder == null) return;
        this.partial = event.partialTick;
        this.invoke(this.mRender);
    }

    // ------------------------------------------------------------------ reflection

    private boolean init() {
        if (this.finder != null) return true;
        try {
            Class<?> fc = Class.forName(FINDER);
            Class<?> cc = Class.forName(CONFIG);
            Class<?> hc = Class.forName(HOST);
            this.cfg = cc.getConstructor().newInstance();
            Object host = Proxy.newProxyInstance(hc.getClassLoader(), new Class<?>[]{hc}, new HostHandler());
            this.finder = fc.getConstructor(cc, hc).newInstance(this.cfg, host);
            this.mEnable = fc.getMethod("enable");
            this.mDisable = fc.getMethod("disable");
            this.mTick = fc.getMethod("tick");
            this.mRender = fc.getMethod("render");
            this.mCommand = fc.getMethod("command", String.class);
            for (Method m : fc.getMethods()) {
                if (m.getName().equals("onPacket") && m.getParameterCount() == 1) {
                    this.mPacket = m;
                }
            }
            return true;
        } catch (Throwable t) {
            System.err.println("Kryzex: Raid Base Finder V17 init failed: " + t);
            this.finder = null;
            return false;
        }
    }

    private void applyConfig() {
        if (this.cfg == null) return;
        this.set("alertMinScore", this.alertScore.get());
        this.set("espMinScore", this.espScore.get());
        this.set("baseYMax", Math.round(this.baseY.get()));
        this.set("regionRadius", Math.round(this.radius.get()));
        this.set("espRenderRadius", this.espRange.get());
        this.set("enableEsp", this.esp.get());
        this.set("chatAlert", this.chatAlert.get());
        this.set("donutProfile", this.donut.get());
        this.set("enableNether", this.nether.get());
        this.set("enableEnd", this.end.get());
    }

    private void set(String field, Object value) {
        try {
            this.cfg.getClass().getField(field).set(this.cfg, value);
        } catch (Throwable ignored) {
        }
    }

    private Object invoke(Method m, Object... args) {
        if (m == null || this.finder == null) return null;
        try {
            return m.invoke(this.finder, args);
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            System.err.println("Kryzex: Raid Base Finder V17 " + m.getName() + " failed: " + c);
            return null;
        }
    }

    private void cmd(String sub) {
        if (this.finder == null || this.mCommand == null) return;
        this.invoke(this.mCommand, sub);
    }

    // ------------------------------------------------------------------ Host (chat + ESP drawing)

    private final class HostHandler
    implements InvocationHandler {
        @Override
        public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
            try {
                switch (m.getName()) {
                    case "chat" -> RaidBaseFinderBridge.this.hostChat((String)a[0]);
                    case "box" -> RaidBaseFinderBridge.this.hostBox((Double)a[0], (Double)a[1], (Double)a[2], (Double)a[3], (Double)a[4], (Double)a[5], (Integer)a[6], (Integer)a[7]);
                    case "line" -> RaidBaseFinderBridge.this.hostLine((Double)a[0], (Double)a[1], (Double)a[2], (Double)a[3], (Double)a[4], (Double)a[5], (Integer)a[6]);
                    case "text", "waypoint", "removeWaypoints", "stopGoto", "playAlert" -> {
                    }
                    case "gotoBlock" -> {
                        return Boolean.FALSE;
                    }
                    default -> {
                        if (m.isDefault()) return InvocationHandler.invokeDefault(proxy, m, a);
                    }
                }
            } catch (Throwable t) {
                System.err.println("Kryzex: Raid Base Finder V17 host " + m.getName() + " failed: " + t);
            }
            return null;
        }
    }

    private void hostChat(String msg) {
        class_310 mc = class_310.method_1551();
        if (mc == null) return;
        mc.execute(() -> {
            if (mc.field_1724 != null) {
                mc.field_1724.method_7353(class_2561.method_30163(msg), false);
            }
        });
    }

    private void hostBox(double x1, double y1, double z1, double x2, double y2, double z2, int fill, int line) {
        class_238 box = new class_238(x1, y1, z1, x2, y2, z2);
        class_12180.method_75541(box, class_12179.method_75539(fill)).method_75533();
        PixelPerDepth.forFrame(this.partial).box(box, line, 1.0f);
    }

    private void hostLine(double x1, double y1, double z1, double x2, double y2, double z2, int argb) {
        PixelPerDepth.forFrame(this.partial).line(new class_243(x1, y1, z1), new class_243(x2, y2, z2), argb, 1.0f);
    }
}
