package kryzex.module;

import kryzex.util.SecureString;

public enum Category {
    COMBAT((CharSequence)SecureString.of((String)"Combat")),
    MISC((CharSequence)SecureString.of((String)"Misc")),
    MACROS((CharSequence)SecureString.of((String)"Bot")),
    DONUT((CharSequence)SecureString.of((String)"Donut")),
    RENDER((CharSequence)SecureString.of((String)"Render")),
    CLIENT((CharSequence)SecureString.of((String)"Client"));

    public final CharSequence name;

    private Category(CharSequence charSequence) {
        this.name = charSequence;
    }
}
