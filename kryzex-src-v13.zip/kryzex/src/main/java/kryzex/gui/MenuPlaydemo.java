package kryzex.gui;

import java.util.ArrayList;
import java.util.List;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Control;
import kryzex.gui.EssentialUtilGuiutil;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiRenderer;
import kryzex.gui.GuiSoundType;
import kryzex.gui.KryzexClient;
import kryzex.gui.KryzexMenuVideo;
import kryzex.gui.Muted;
import kryzex.gui.MainMenuScene;
import kryzex.gui.SpeakerOff;
import kryzex.gui.UtilityIcons;
import kryzex.gui.Rect;
import net.minecraft.class_10799;
import net.minecraft.class_11907;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import net.minecraft.class_7077;
import net.minecraft.class_8662;

public final class MenuPlaydemo
extends class_442 {
    private static final class_2960 BRAND = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/title.png");
    private static final class_2960[] MENU_ICONS = new class_2960[]{class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/icons/play.png"), class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/icons/globe.png"), class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/icons/cloud.png"), class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/icons/gear.png"), class_2960.method_60655((String)"r87f4560b4c09f4", (String)"menu/icons/power.png")};
    private final class_4185[] buttons = new class_4185[6];
    private final float[] hover = new float[14];
    private final float[] press = new float[14];
    private final List<Control> utilities = new ArrayList<Control>();
    private String notice = "";
    private long opened;
    private long last;
    private UtilityIcons layout;
    private boolean draggingVolume;
    private boolean keyboardMode;
    private int lastMouseX = Integer.MIN_VALUE;
    private int lastMouseY;
    private class_4185 mute;

    public MenuPlaydemo() {
        super(false);
    }

    private class_4185 find(List<class_4185> list, String string) {
        String string2 = class_2561.method_43471((String)string).getString();
        return list.stream().filter(arg_0 -> MenuPlaydemo.lmbd$find$0(string2, arg_0)).findFirst().orElse(null);
    }

    protected void method_25426() {
        super.method_25426();
        this.configureButtons();
        if (this.opened == 0L) {
            this.opened = System.nanoTime();
        }
        this.last = System.nanoTime();
        KryzexMenuVideo.setWanted(true);
    }

    private void configureButtons() {
        Object object42;
        ArrayList<class_4185> arrayList = new ArrayList<class_4185>();
        for (Object object2 : this.method_25396()) {
            if (!(object2 instanceof class_4185)) continue;
            object42 = (class_4185)object2;
            arrayList.add((class_4185)object42);
        }
        this.buttons[0] = this.find(arrayList, this.field_22787.method_1530() ? "menu.playdemo" : "menu.singleplayer");
        this.buttons[1] = this.find(arrayList, "menu.multiplayer");
        this.buttons[2] = this.find(arrayList, "menu.online");
        this.buttons[3] = this.find(arrayList, "menu.options");
        this.buttons[4] = this.find(arrayList, "menu.quit");
        this.utilities.clear();
        Object object3 = null;
        for (Object object4 : List.copyOf(this.method_25396())) {
            class_339 object5;
            if (this.isCoreButton(object4)) continue;
            if (object4 instanceof class_4185 && !EssentialUtilGuiutil.proxy(object5 = (class_339)object4) && !(object5 instanceof class_8662) && !(object5 instanceof class_7077)) {
                String string = object5.method_25369().getString();
                if (string.equalsIgnoreCase("Accounts") || string.equalsIgnoreCase("Account")) {
                    object3 = object5;
                } else if (!string.isBlank() && !string.contains("<essential_") && this.utilities.size() < 8 && this.utilities.stream().noneMatch(arg_0 -> MenuPlaydemo.lmbd$configureButtons$0(string, arg_0))) {
                    boolean bl = object5.field_22763;
                    final class_4185 button = (class_4185)object4;
                    this.addUtility(string, 6, () -> MenuPlaydemo.lmbd$configureButtons$1(button));
                    this.utilities.get((int)(this.utilities.size() - 1)).control().field_22763 = bl;
                }
            }
            if (!(object4 instanceof class_339)) continue;
            object5 = (class_339)object4;
            object5.field_22764 = false;
            object5.field_22763 = false;
        }
        boolean bl = EssentialUtilGuiutil.available();
        Object object6 = object3;
        this.buttons[5] = class_4185.method_46430((class_2561)class_2561.method_43470((String)"Accounts"), arg_0 -> this.lmbd$configureButtons$2(bl, (class_4185)object6, arg_0)).method_46434(0, 0, 108, 44).method_46431();
        this.buttons[5].field_22763 = bl || object6 != null;
        this.method_25429(this.buttons[5]);
        if (bl) {
            this.addUtility("Friends", 7, this::lmbd$configureButtons$3);
            this.addUtility("Wardrobe", 8, this::lmbd$configureButtons$4);
            this.addUtility("Screenshots", 9, this::lmbd$configureButtons$5);
            this.addUtility("Essential Settings", 3, this::lmbd$configureButtons$6);
            this.addUtility("Host World", 7, this::lmbd$configureButtons$7);
        }
        this.mute = class_4185.method_46430((class_2561)class_2561.method_43470((String)"Toggle menu music"), MenuPlaydemo::lmbd$configureButtons$8).method_46434(0, 0, 30, 30).method_46431();
        this.method_25429(this.mute);
        if (this.buttons[0] == null) return;
        this.method_48265(this.buttons[0]);
    }

    private void addUtility(String string, int n, Runnable runnable) {
        if (this.utilities.size() >= 8 || this.utilities.stream().anyMatch(arg_0 -> MenuPlaydemo.lmbd$addUtility$0(string, arg_0))) {
            return;
        }
        class_4185 class_41852 = class_4185.method_46430((class_2561)class_2561.method_43470((String)string), arg_0 -> this.lmbd$addUtility$1(runnable, string, arg_0)).method_46434(0, 0, 120, 24).method_46431();
        this.utilities.add(new Control(string, n, class_41852));
        this.method_25429(class_41852);
    }

    private void openEssential(String string) {
        try {
            EssentialUtilGuiutil.open(string);
            this.notice = "";
            return;
        }
        catch (LinkageError | ReflectiveOperationException | RuntimeException throwable) {
            this.notice = "Essential could not open this menu";
            System.err.println("Kryzex Essential menu: " + throwable.getClass().getSimpleName());
        }
    }

    private void refreshLateAddons() {
        for (class_364 class_3642 : List.copyOf(this.method_25396())) {
            if (!(class_3642 instanceof class_339)) continue;
            class_339 class_3392 = (class_339)class_3642;
            if (!class_3392.field_22764 || class_3642 == this.mute || this.isCoreButton(class_3642) || !this.utilities.stream().noneMatch(arg_0 -> MenuPlaydemo.lmbd$refreshLateAddons$0(class_3642, arg_0))) continue;
            if (class_3392 instanceof class_4185) {
                String string;
                class_4185 class_41852 = (class_4185)class_3392;
                if (!(EssentialUtilGuiutil.proxy(class_3392) || class_3392 instanceof class_8662 || class_3392 instanceof class_7077 || (string = class_3392.method_25369().getString()).isBlank() || string.contains("<essential_") || this.utilities.size() >= 8 || !this.utilities.stream().noneMatch(arg_0 -> MenuPlaydemo.lmbd$refreshLateAddons$1(string, arg_0)))) {
                    boolean bl = class_3392.field_22763;
                    this.addUtility(string, 6, () -> MenuPlaydemo.lmbd$refreshLateAddons$2(class_41852));
                    if (!this.utilities.isEmpty()) {
                        this.utilities.get((int)(this.utilities.size() - 1)).control().field_22763 = bl;
                    }
                }
            }
            class_3392.field_22764 = false;
            class_3392.field_22763 = false;
        }
    }

    private boolean isCoreButton(Object object) {
        for (class_4185 class_41852 : this.buttons) {
            if (class_41852 != object) continue;
            return true;
        }
        return false;
    }

    private float guiScale() {
        return this.field_22787.method_22683().method_4495();
    }

    private static float ease(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return 1.0f - (float)Math.pow(1.0f - f, 4.0);
    }

    private void place(class_4185 class_41852, Rect m62) {
        if (class_41852 == null) {
            return;
        }
        float f = this.guiScale();
        class_41852.method_46421(Math.round(m62.x() / f));
        class_41852.method_46419(Math.round(m62.y() / f));
        class_41852.method_25358(Math.max(1, Math.round(m62.w() / f)));
        class_41852.method_53533(Math.max(1, Math.round(m62.h() / f)));
    }

    public void method_25393() {
        super.method_25393();
        KryzexMenuVideo.setWanted(true);
        if (!Muted.enabled()) return;
        this.field_22787.method_1538().method_4859();
    }

    public void method_25420(class_332 class_3322, int n, int n2, float f) {
    }

    protected void method_57734(class_332 class_3322) {
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        this.refreshLateAddons();
        long l = System.nanoTime();
        float f2 = this.last == 0L ? 0.016f : Math.min(0.05f, (float)(l - this.last) / 1.0E9f);
        this.last = l;
        float f3 = (float)(l - this.opened) / 1.0E9f;
        float f4 = MenuPlaydemo.ease(f3 / 0.65f);
        int n3 = this.field_22787.method_22683().method_4489();
        int n4 = this.field_22787.method_22683().method_4506();
        float f5 = this.guiScale();
        this.layout = new UtilityIcons(n3, n4, f4, this.utilities.size());
        double d = (float)n * f5;
        double d2 = (float)n2 * f5;
        if (this.lastMouseX != n || this.lastMouseY != n2) {
            this.keyboardMode = false;
        }
        this.lastMouseX = n;
        this.lastMouseY = n2;
        int n5 = 0;
        while (n5 < this.buttons.length) {
            this.place(this.buttons[n5], this.layout.buttons[n5]);
            boolean bl = this.buttons[n5] != null && this.buttons[n5].field_22763 && (this.layout.buttons[n5].contains(d, d2) || this.keyboardMode && this.buttons[n5].method_25370());
            int n6 = n5;
            this.hover[n6] = this.hover[n6] + ((float)(bl ? (char)'\u0001' : '\u0000') - this.hover[n5]) * (1.0f - (float)Math.exp(-14.0f * f2));
            int n7 = n5++;
            this.press[n7] = this.press[n7] * (float)Math.exp(-14.0f * f2);
        }
        for (n5 = 0; n5 < this.utilities.size(); ++n5) {
            Control control = this.utilities.get(n5);
            this.place(control.control(), this.layout.utilities[n5]);
            this.layout.utilityIcons[n5] = control.icon();
            int n8 = 6 + n5;
            boolean bl = control.control().field_22763 && (this.layout.utilities[n5].contains(d, d2) || this.keyboardMode && control.control().method_25370());
            int n9 = n8;
            this.hover[n9] = this.hover[n9] + ((float)(bl ? (char)'\u0001' : '\u0000') - this.hover[n8]) * (1.0f - (float)Math.exp(-14.0f * f2));
            int n10 = n8;
            this.press[n10] = this.press[n10] * (float)Math.exp(-14.0f * f2);
        }
        this.place(this.mute, this.layout.mute);
        n5 = MainMenuScene.render(this.layout, n3, n4, f3, f4, (float)d, (float)d2, this.hover, this.press) ? '\u0001' : '\u0000';
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().scale(1.0f / f5, 1.0f / f5);
        try {
            int n11;
            Object record;
            int n12;
            GuiRenderer guiRenderer = new GuiRenderer(class_3322, f5);
            float f6 = this.layout.scale;
            if (n5 == 0) {
                Rect m62;
                int n13;
                guiRenderer.rect(0.0f, 0.0f, n3, n4, 0xFF0B0B0E);
                guiRenderer.rect(0.0f, 0.0f, n3, n4, 806031384);
                Rect m63 = this.layout.panel;
                guiRenderer.round(m63.x(), m63.y(), m63.w(), m63.h(), 28.0f * f6, -1842663366);
                for (n13 = 0; n13 < this.buttons.length; ++n13) {
                    m62 = this.layout.buttons[n13];
                    guiRenderer.round(m62.x(), m62.y(), m62.w(), m62.h(), 16.0f * f6, BaseRenderer.argb(0.35f + this.hover[n13] * 0.16f, 143, 150, 162));
                    guiRenderer.outline(m62.x(), m62.y(), m62.w(), m62.h(), 16.0f * f6, f6, 0x45FFFFFF);
                }
                for (n13 = 0; n13 < this.utilities.size(); ++n13) {
                    m62 = this.layout.utilities[n13];
                    KryzexClient.glass(guiRenderer, m62.x(), m62.y(), m62.w(), m62.h(), this.hover[6 + n13], false);
                }
            }
            guiRenderer.pushAlpha(f4);
            Rect m64 = this.layout.title;
            class_3322.method_25293(class_10799.field_56883, BRAND, Math.round(m64.x()), Math.round(m64.y()), 0.0f, 0.0f, Math.round(m64.w()), Math.round(m64.h()), 1536, 256, 1536, 256, Math.round(255.0f * f4) << 24 | 0xFFFFFF);
            String[] stringArray = new String[]{"Singleplayer", "Multiplayer", "Realms", "Options", "Quit", "Accounts"};
            for (n12 = 0; n12 < this.buttons.length; ++n12) {
                record = this.layout.buttons[n12];
                boolean bl = this.buttons[n12] != null && this.buttons[n12].field_22763;
                n11 = bl ? -657412 : 2011227371;
                float f7 = (this.press[n12] * 1.1f - this.hover[n12] * 0.7f) * f6;
                String string2 = n12 >= 3 ? stringArray[n12] : KryzexClient.brand(this.buttons[n12] != null ? this.buttons[n12].method_25369().getString() : stringArray[n12]);
                if (n5 == 0 && n12 < 5) {
                    class_3322.method_25293(class_10799.field_56883, MENU_ICONS[n12], Math.round(((Rect)record).x() + (float)(n12 >= 3 ? 10 : 18) * f6), Math.round(((Rect)record).y() + (((Rect)record).h() - 18.0f * f6) / 2.0f + f7), 0.0f, 0.0f, Math.round(18.0f * f6), Math.round(18.0f * f6), 96, 96, 96, 96, Math.round((float)(n11 >>> 24) * f4) << 24 | 0xFFFFFF);
                }
                if (n5 == 0 && n12 == 5) {
                    guiRenderer.circle(((Rect)record).x() + 18.0f * f6, ((Rect)record).y() + 17.0f * f6, 3.0f * f6, n11);
                    guiRenderer.round(((Rect)record).x() + 13.0f * f6, ((Rect)record).y() + 23.0f * f6, 10.0f * f6, 6.0f * f6, 3.0f * f6, n11);
                }
                guiRenderer.text(string2, ((Rect)record).x() + (float)(n12 >= 3 ? 32 : 49) * f6, ((Rect)record).y() + (((Rect)record).h() - (float)(n12 >= 3 ? 12 : 17) * f6) / 2.0f + f7, (float)(n12 >= 3 ? 12 : (n12 < 2 ? 17 : 14)) * f6, 0, n11);
                if (n12 >= 3) continue;
                guiRenderer.icon(SpeakerOff.CHEVRON_RIGHT, ((Rect)record).x() + ((Rect)record).w() - 33.0f * f6 + this.hover[n12] * 2.0f * f6, ((Rect)record).y() + (((Rect)record).h() - 14.0f * f6) / 2.0f, 14.0f * f6, bl ? -1428232719 : 1440671217);
            }
            for (n12 = 0; n12 < this.utilities.size(); ++n12) {
                record = this.utilities.get(n12);
                Rect m65 = this.layout.utilities[n12];
                n11 = 6 + n12;
                guiRenderer.text(((Control)record).label(), m65.x() + 42.0f * f6, m65.y() + (m65.h() - 13.0f * f6) / 2.0f - this.hover[n11] * 0.6f * f6, 13.0f * f6, 0, ((Control)record).control().field_22763 ? -920326 : -2134191391);
            }
            if (!this.utilities.isEmpty()) {
                KryzexClient.label(guiRenderer, "QUICK ACCESS", this.layout.utilities[0].x() + 3.0f * f6, this.layout.utilities[0].y() - 20.0f * f6, 9.0f * f6, -1428364046, true);
            }
            if (!this.notice.isBlank()) {
                KryzexClient.centered(guiRenderer, this.notice, (float)n3 * 0.5f, (float)n4 - 34.0f * f6, 10.0f * f6, -2366739, false);
            }
            Rect m66 = this.layout.mute;
            guiRenderer.icon(Muted.enabled() ? SpeakerOff.SPEAKER : SpeakerOff.SPEAKER_OFF, m66.x() + 6.0f * f6, m66.y() + 6.0f * f6, 18.0f * f6, -286067205);
            guiRenderer.text("MENU MUSIC", this.layout.music.x() + 49.0f * f6, this.layout.music.y() + 8.0f * f6, 8.5f * f6, 1, -1429614371);
            guiRenderer.text("Insomniac", this.layout.music.x() + 49.0f * f6, this.layout.music.y() + 21.0f * f6, 11.0f * f6, 0, -854532);
            record = this.layout.slider;
            float f8 = Muted.volume();
            guiRenderer.round(((Rect)record).x(), ((Rect)record).y() + 2.0f * f6, ((Rect)record).w(), 3.0f * f6, 1.5f * f6, 0x40FFFFFF);
            guiRenderer.round(((Rect)record).x(), ((Rect)record).y() + 2.0f * f6, ((Rect)record).w() * f8, 3.0f * f6, 1.5f * f6, Muted.enabled() ? -588911368 : 1891748310);
            guiRenderer.circle(((Rect)record).x() + ((Rect)record).w() * f8, ((Rect)record).y() + 3.5f * f6, 4.0f * f6, -657153);
            guiRenderer.textRight("KRYZEX CLIENT", (float)n3 - 29.0f * f6, (float)n4 - 45.0f * f6, 10.5f * f6, 1, -672206087);
            guiRenderer.textRight("Fabric  \u00b7  1.21.11", (float)n3 - 29.0f * f6, (float)n4 - 28.0f * f6, 10.0f * f6, 0, -1545278991);
            guiRenderer.popAlpha();
            return;
        }
        finally {
            class_3322.method_51448().popMatrix();
        }
    }

    private void volumeAt(double d) {
        if (this.layout == null) return;
        Muted.setVolume((float)((d - (double)this.layout.slider.x()) / (double)this.layout.slider.w()));
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        int n;
        if (class_119092.method_74245() != 0 || this.layout == null) {
            return super.method_25402(class_119092, bl);
        }
        double d = class_119092.comp_4798() * (double)this.guiScale();
        double d2 = class_119092.comp_4799() * (double)this.guiScale();
        this.keyboardMode = false;
        Rect m62 = this.layout.slider;
        if (d >= (double)(m62.x() - 8.0f * this.layout.scale) && d <= (double)(m62.x() + m62.w() + 8.0f * this.layout.scale) && d2 >= (double)(m62.y() - 9.0f * this.layout.scale) && d2 <= (double)(m62.y() + m62.h() + 9.0f * this.layout.scale)) {
            this.draggingVolume = true;
            this.volumeAt(d);
            return true;
        }
        if (this.layout.mute.contains(d, d2)) {
            GuiAudio.play(GuiSoundType.TICK);
            Muted.toggle();
            return true;
        }
        for (n = 0; n < this.buttons.length; ++n) {
            if (!this.layout.buttons[n].contains(d, d2) || this.buttons[n] == null || !this.buttons[n].field_22763) continue;
            this.press[n] = 1.0f;
            this.method_25395((class_364)this.buttons[n]);
            GuiAudio.play(GuiSoundType.CONFIRM);
            this.buttons[n].method_25306((class_11907)class_119092);
            return true;
        }
        for (n = 0; n < this.utilities.size(); ++n) {
            Control control = this.utilities.get(n);
            if (!control.control().field_22763 || !this.layout.utilities[n].contains(d, d2)) continue;
            this.press[6 + n] = 1.0f;
            this.method_25395((class_364)control.control());
            GuiAudio.play(GuiSoundType.CONFIRM);
            control.control().method_25306((class_11907)class_119092);
            return true;
        }
        return super.method_25402(class_119092, bl);
    }

    public boolean method_25403(class_11909 class_119092, double d, double d2) {
        if (!this.draggingVolume) return super.method_25403(class_119092, d, d2);
        this.volumeAt(class_119092.comp_4798() * (double)this.guiScale());
        return true;
    }

    public boolean method_25406(class_11909 class_119092) {
        if (!this.draggingVolume) return super.method_25406(class_119092);
        this.draggingVolume = false;
        Muted.save();
        return true;
    }

    public boolean method_25404(class_11908 class_119082) {
        int n;
        this.keyboardMode = true;
        if (class_119082.comp_4795() == 77) {
            Muted.toggle();
            return true;
        }
        if (class_119082.comp_4795() != 257 && class_119082.comp_4795() != 335 && class_119082.comp_4795() != 32) return super.method_25404(class_119082);
        for (n = 0; n < this.buttons.length; ++n) {
            if (this.buttons[n] == null || !this.buttons[n].method_25370() || !this.buttons[n].field_22763) continue;
            this.press[n] = 1.0f;
            GuiAudio.play(GuiSoundType.CONFIRM);
            this.buttons[n].method_25306((class_11907)class_119082);
            return true;
        }
        for (n = 0; n < this.utilities.size(); ++n) {
            Control control = this.utilities.get(n);
            if (!control.control().field_22763 || !control.control().method_25370()) continue;
            this.press[6 + n] = 1.0f;
            GuiAudio.play(GuiSoundType.CONFIRM);
            control.control().method_25306((class_11907)class_119082);
            return true;
        }
        if (this.mute == null || !this.mute.method_25370()) return super.method_25404(class_119082);
        Muted.toggle();
        return true;
    }

    public void method_25432() {
        super.method_25432();
        if (this.draggingVolume) {
            Muted.save();
        }
        this.draggingVolume = false;
        this.opened = 0L;
    }

    private static void lmbd$refreshLateAddons$2(class_4185 class_41852) {
        class_41852.method_25306((class_11907)null);
    }

    private static boolean lmbd$refreshLateAddons$1(String string, Control control) {
        return control.label().equals(string);
    }

    private static boolean lmbd$refreshLateAddons$0(class_364 class_3642, Control control) {
        if (control.control() != class_3642) return false;
        return true;
    }

    private void lmbd$addUtility$1(Runnable runnable, String string, class_4185 class_41852) {
        try {
            runnable.run();
            return;
        }
        catch (LinkageError | RuntimeException throwable) {
            this.notice = "Could not open " + string;
            System.err.println("Kryzex menu action failed: " + throwable.getClass().getSimpleName());
        }
    }

    private static boolean lmbd$addUtility$0(String string, Control control) {
        return control.label().equals(string);
    }

    private static void lmbd$configureButtons$8(class_4185 class_41852) {
        Muted.toggle();
    }

    private void lmbd$configureButtons$7() {
        this.openEssential("invite_host");
    }

    private void lmbd$configureButtons$6() {
        this.openEssential("settings");
    }

    private void lmbd$configureButtons$5() {
        this.openEssential("pictures");
    }

    private void lmbd$configureButtons$4() {
        this.openEssential("wardrobe");
    }

    private void lmbd$configureButtons$3() {
        this.openEssential("social");
    }

    private void lmbd$configureButtons$2(boolean bl, class_4185 class_41852, class_4185 class_41853) {
        if (bl) {
            this.openEssential("account");
            return;
        } else {
            if (class_41852 == null) return;
            class_41852.method_25306((class_11907)null);
        }
    }

    private static void lmbd$configureButtons$1(class_4185 class_41852) {
        class_41852.method_25306((class_11907)null);
    }

    private static boolean lmbd$configureButtons$0(String string, Control control) {
        return control.label().equals(string);
    }

    private static boolean lmbd$find$0(String string, class_4185 class_41852) {
        return class_41852.method_25369().getString().equals(string);
    }
}
