package kryzex.gui;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jcodec.api.FrameGrab;
import org.jcodec.common.io.ByteBufferSeekableByteChannel;
import org.jcodec.common.model.ColorSpace;
import org.jcodec.common.model.Picture;
import org.jcodec.scale.ColorUtil;
import org.lwjgl.system.MemoryUtil;

public final class KryzexMenuVideo {
    public static final class_2960 TEXTURE = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"dynamic/menu_video");
    private static final Object LOCK = new Object();
    private static final AtomicReference<class_1011> LATEST = new AtomicReference();
    private static volatile boolean wanted;
    private static volatile boolean closed;
    private static Thread worker;
    private static class_1043 texture;

    private KryzexMenuVideo() {
    }

    public static void setWanted(boolean bl) {
        bl = false;
        Object object = LOCK;
        synchronized (object) {
            class_1011 class_10112;
            wanted = bl;
            if (!bl && (class_10112 = (class_1011)LATEST.getAndSet(null)) != null) {
                class_10112.close();
            }
            if (bl && !closed && worker == null) {
                worker = new Thread(KryzexMenuVideo::decode, "Kryzex menu video");
                worker.setDaemon(true);
                worker.setPriority(1);
                worker.start();
            }
            LOCK.notifyAll();
            return;
        }
    }

    private static void publish(class_1011 class_10112) {
        Object object = LOCK;
        synchronized (object) {
            if (!wanted || closed) {
                class_10112.close();
                return;
            }
            class_1011 class_10113 = LATEST.getAndSet(class_10112);
            if (class_10113 == null) return;
            class_10113.close();
            return;
        }
    }

    public static class_1011 rgbImage(Picture picture) {
        int n = picture.getCroppedWidth();
        int n2 = picture.getCroppedHeight();
        int n3 = picture.getWidth();
        int n4 = picture.getStartX();
        int n5 = picture.getStartY();
        byte[] byArray = picture.getPlaneData(0);
        class_1011 class_10112 = new class_1011(n, n2, false);
        IntBuffer intBuffer = MemoryUtil.memIntBuffer((long)class_10112.method_67769(), (int)(n * n2));
        boolean bl = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n; ++j) {
                int n6 = ((i + n5) * n3 + j + n4) * 3;
                int n7 = byArray[n6] + 128;
                int n8 = byArray[n6 + 1] + 128;
                int n9 = byArray[n6 + 2] + 128;
                intBuffer.put(bl ? 0xFF000000 | n9 << 16 | n8 << 8 | n7 : n7 << 24 | n8 << 16 | n9 << 8 | 0xFF);
            }
        }
        return class_10112;
    }

    private static void decode() {
        try (InputStream inputStream = KryzexMenuVideo.class.getResourceAsStream("/assets/r87f4560b4c09f4/menu/halloween.mp4");){
            if (inputStream == null) {
                throw new IOException("Menu video missing");
            }
            byte[] byArray = inputStream.readNBytes(0x5000000);
            if (byArray.length == 0x5000000) {
                throw new IOException("Menu video exceeds size limit");
            }
            try (ByteBufferSeekableByteChannel byteBufferSeekableByteChannel = ByteBufferSeekableByteChannel.readFromByteBuffer(ByteBuffer.wrap(byArray));){
                FrameGrab frameGrab = FrameGrab.createFrameGrab(byteBufferSeekableByteChannel);
                Picture picture = null;
                long l = System.nanoTime();
                while (!closed) {
                    Object object = LOCK;
                    synchronized (object) {
                        while (!wanted && !closed) {
                            LOCK.wait();
                            l = System.nanoTime();
                        }
                    }
                    if (closed) {
                        return;
                    }
                    long l2 = l - System.nanoTime();
                    if (l2 > 0L) {
                        LockSupport.parkNanos(Math.min(l2, 10000000L));
                        continue;
                    }
                    Picture picture2 = frameGrab.getNativeFrame();
                    if (picture2 == null) {
                        frameGrab.seekToFramePrecise(0);
                        l = System.nanoTime();
                        continue;
                    }
                    if (picture == null || picture.getWidth() != picture2.getWidth() || picture.getHeight() != picture2.getHeight()) {
                        picture = Picture.create(picture2.getWidth(), picture2.getHeight(), ColorSpace.RGB);
                    }
                    ColorUtil.getTransform(picture2.getColor(), ColorSpace.RGB).transform(picture2, picture);
                    picture.setCrop(picture2.getCrop());
                    KryzexMenuVideo.publish(KryzexMenuVideo.rgbImage(picture));
                    if (System.nanoTime() - (l += 41666666L) <= 125000000L) continue;
                    l = System.nanoTime();
                }
                return;
            }
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            return;
        }
        catch (Exception exception) {
            System.err.println("Kryzex menu video: " + exception.getClass().getSimpleName() + ": " + exception.getMessage());
        }
    }

    public static class_1043 texture() {
        class_1011 class_10112 = LATEST.getAndSet(null);
        if (texture == null) {
            if (class_10112 == null) {
                try (InputStream inputStream = KryzexMenuVideo.class.getResourceAsStream("/assets/r87f4560b4c09f4/menu/poster.png");){
                    class_10112 = class_1011.method_4309((InputStream)inputStream);
                }
                catch (Exception exception) {
                    class_10112 = new class_1011(1, 1, false);
                    class_10112.method_61941(0, 0, -14671060);
                }
            }
            texture = new class_1043(KryzexMenuVideo::lmbd$texture$0, class_10112);
            class_310.method_1551().method_1531().method_4616(TEXTURE, (class_1044)texture);
            texture.method_4524();
            return texture;
        }
        if (class_10112 == null) return texture;
        texture.method_4526(class_10112);
        texture.method_4524();
        return texture;
    }

    public static void close() {
        Object object = LOCK;
        synchronized (object) {
            class_1011 class_10112;
            closed = true;
            wanted = false;
            LOCK.notifyAll();
            if (worker != null) {
                worker.interrupt();
            }
            if ((class_10112 = (class_1011)LATEST.getAndSet(null)) != null) {
                class_10112.close();
            }
        }
        if (texture == null) return;
        class_310.method_1551().method_1531().method_4615(TEXTURE);
        texture = null;
    }

    private static String lmbd$texture$0() {
        return "Kryzex menu video";
    }
}
