package kryzex.gui;

import kryzex.gui.Easing;
import kryzex.gui.FallbackAdvance;
import kryzex.gui.Handle;
import kryzex.gui.PurpleLogo;
import kryzex.gui.ShapeCache;
import kryzex.gui.SpeakerOff;
import kryzex.gui.FallbackFont;

public abstract class BaseRenderer {
    private final float[] alphaStack = new float[32];
    private int alphaDepth;
    protected float alpha = 1.0f;

    protected abstract void fillRaw(int var1, int var2, int var3, int var4, int var5);

    protected abstract void gradientRaw(int var1, int var2, int var3, int var4, int var5, int var6);

    protected abstract void blitRaw(Handle var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

    public abstract void pushTransform(float var1, float var2, float var3);

    public abstract void popTransform();

    public abstract float scale();

    public abstract void pushClip(float var1, float var2, float var3, float var4);

    public abstract void popClip();

    public abstract void head(float var1, float var2, float var3);

    public abstract void item(Object var1, float var2, float var3, float var4);

    public void imageGradient(String string, float f, float f2, float f3, int n, int n2) {
        float f4 = this.scale();
        int n3 = Math.max(4, Math.round(f3 * f4));
        Handle handle = PurpleLogo.get(string, n3);
        if (handle == null) return;
        this.pushTransform(0.0f, 0.0f, 1.0f / f4);
        int n4 = Math.round(f * f4);
        int n5 = Math.round(f2 * f4);
        for (int i = 0; i < n3; ++i) {
            int n6 = this.mul(Easing.mix(n, n2, ((float)i + 0.5f) / (float)n3));
            if (n6 >>> 24 == 0) continue;
            this.blitRaw(handle, n4, n5 + i, n3, 1, 0, i, n3, 1, n6);
        }
        this.popTransform();
    }

    public void image(String string, float f, float f2, float f3, int n) {
        int n2 = this.mul(n);
        float f4 = this.scale();
        int n3 = Math.max(4, Math.round(f3 * f4));
        Handle handle = PurpleLogo.get(string, n3);
        if (handle == null || n2 >>> 24 == 0) return;
        this.pushTransform(0.0f, 0.0f, 1.0f / f4);
        this.blitRaw(handle, Math.round(f * f4), Math.round(f2 * f4), n3, n3, 0, 0, handle.w, handle.h, n2);
        this.popTransform();
    }

    public void texture(Handle handle, float f, float f2, float f3, float f4, int n) {
        this.textureRegion(handle, f, f2, f3, f4, 0, 0, handle == null ? 0 : handle.w, handle == null ? 0 : handle.h, n);
    }

    public void textureRegion(Handle handle, float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, int n5) {
        int n6 = this.mul(n5);
        if (handle == null || n6 >>> 24 == 0 || !(f3 > 0.0f) || !(f4 > 0.0f)) return;
        float f5 = this.scale();
        float f6 = Math.max(1.0E-4f, f5);
        int n7 = Math.max(1, Math.round(f3 * f6));
        int n8 = Math.max(1, Math.round(f4 * f6));
        this.pushTransform(f, f2, 1.0f / f6);
        this.blitRaw(handle, 0, 0, n7, n8, n, n2, n3, n4, n6);
        this.popTransform();
    }

    public void pushAlpha(float f) {
        this.alphaStack[this.alphaDepth++] = this.alpha;
        this.alpha *= Math.max(0.0f, Math.min(1.0f, f));
    }

    public void popAlpha() {
        this.alpha = this.alphaStack[--this.alphaDepth];
    }

    protected int mul(int n) {
        if (this.alpha >= 0.999f) {
            return n;
        }
        int n2 = Math.round((float)(n >>> 24) * this.alpha);
        return n2 << 24 | n & 0xFFFFFF;
    }

    public void rect(float f, float f2, float f3, float f4, int n) {
        if (!(f3 > 0.0f) || !(f4 > 0.0f) || n >>> 24 == 0) return;
        this.fillRaw(Math.round(f), Math.round(f2), Math.round(f + f3), Math.round(f2 + f4), this.mul(n));
    }

    public void gradient(float f, float f2, float f3, float f4, int n, int n2) {
        if (!(f3 > 0.0f) || !(f4 > 0.0f)) return;
        this.gradientRaw(Math.round(f), Math.round(f2), Math.round(f + f3), Math.round(f2 + f4), this.mul(n), this.mul(n2));
    }

    public void round(float f, float f2, float f3, float f4, float f5, int n) {
        int n2 = this.mul(n);
        if (n2 >>> 24 == 0) return;
        int n3 = Math.round(f);
        int n4 = Math.round(f2);
        int n5 = Math.round(f + f3) - n3;
        int n6 = Math.round(f2 + f4) - n4;
        if (n5 <= 0 || n6 <= 0) return;
        int n7 = Math.min(Math.round(f5), Math.min(n5, n6) / 2);
        if (n7 <= 0) {
            this.fillRaw(n3, n4, n3 + n5, n4 + n6, n2);
            return;
        } else {
            Handle handle = ShapeCache.circle(n7);
            this.blitRaw(handle, n3, n4, n7, n7, 0, 0, n7, n7, n2);
            this.blitRaw(handle, n3 + n5 - n7, n4, n7, n7, n7, 0, n7, n7, n2);
            this.blitRaw(handle, n3, n4 + n6 - n7, n7, n7, 0, n7, n7, n7, n2);
            this.blitRaw(handle, n3 + n5 - n7, n4 + n6 - n7, n7, n7, n7, n7, n7, n7, n2);
            this.fillRaw(n3 + n7, n4, n3 + n5 - n7, n4 + n6, n2);
            this.fillRaw(n3, n4 + n7, n3 + n7, n4 + n6 - n7, n2);
            this.fillRaw(n3 + n5 - n7, n4 + n7, n3 + n5, n4 + n6 - n7, n2);
        }
    }

    public void roundGradient(float f, float f2, float f3, float f4, float f5, int n, int n2) {
        int n3 = this.mul(n);
        int n4 = this.mul(n2);
        int n5 = Math.round(f);
        int n6 = Math.round(f2);
        int n7 = Math.round(f + f3) - n5;
        int n8 = Math.round(f2 + f4) - n6;
        if (n7 <= 0 || n8 <= 0) return;
        int n9 = Math.min(Math.round(f5), Math.min(n7, n8) / 2);
        if (n9 <= 0) {
            this.gradientRaw(n5, n6, n5 + n7, n6 + n8, n3, n4);
            return;
        } else {
            float f6 = (float)n9 / (float)n8;
            int n10 = Easing.mix(n3, n4, f6);
            int n11 = Easing.mix(n3, n4, 1.0f - f6);
            Handle handle = ShapeCache.circle(n9);
            this.blitRaw(handle, n5, n6, n9, n9, 0, 0, n9, n9, Easing.mix(n3, n4, f6 * 0.5f));
            this.blitRaw(handle, n5 + n7 - n9, n6, n9, n9, n9, 0, n9, n9, Easing.mix(n3, n4, f6 * 0.5f));
            this.blitRaw(handle, n5, n6 + n8 - n9, n9, n9, 0, n9, n9, n9, Easing.mix(n3, n4, 1.0f - f6 * 0.5f));
            this.blitRaw(handle, n5 + n7 - n9, n6 + n8 - n9, n9, n9, n9, n9, n9, n9, Easing.mix(n3, n4, 1.0f - f6 * 0.5f));
            this.gradientRaw(n5 + n9, n6, n5 + n7 - n9, n6 + n8, n3, n4);
            this.gradientRaw(n5, n6 + n9, n5 + n9, n6 + n8 - n9, n10, n11);
            this.gradientRaw(n5 + n7 - n9, n6 + n9, n5 + n7, n6 + n8 - n9, n10, n11);
        }
    }

    public void circle(float f, float f2, float f3, int n) {
        int n2 = Math.max(1, Math.round(f3));
        this.round(Math.round(f) - n2, Math.round(f2) - n2, n2 * 2, n2 * 2, n2, n);
    }

    public void outline(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        int n2 = this.mul(n);
        if (n2 >>> 24 == 0) return;
        int n3 = Math.round(f);
        int n4 = Math.round(f2);
        int n5 = Math.round(f + f3) - n3;
        int n6 = Math.round(f2 + f4) - n4;
        int n7 = Math.max(1, Math.round(f6));
        int n8 = Math.min(Math.round(f5), Math.min(n5, n6) / 2);
        if (n5 <= 2 * n7 || n6 <= 2 * n7) return;
        if (n8 <= n7) {
            this.fillRaw(n3, n4, n3 + n5, n4 + n7, n2);
            this.fillRaw(n3, n4 + n6 - n7, n3 + n5, n4 + n6, n2);
            this.fillRaw(n3, n4 + n7, n3 + n7, n4 + n6 - n7, n2);
            this.fillRaw(n3 + n5 - n7, n4 + n7, n3 + n5, n4 + n6 - n7, n2);
            return;
        } else {
            Handle handle = ShapeCache.ring(n8, n7);
            this.blitRaw(handle, n3, n4, n8, n8, 0, 0, n8, n8, n2);
            this.blitRaw(handle, n3 + n5 - n8, n4, n8, n8, n8, 0, n8, n8, n2);
            this.blitRaw(handle, n3, n4 + n6 - n8, n8, n8, 0, n8, n8, n8, n2);
            this.blitRaw(handle, n3 + n5 - n8, n4 + n6 - n8, n8, n8, n8, n8, n8, n8, n2);
            this.fillRaw(n3 + n8, n4, n3 + n5 - n8, n4 + n7, n2);
            this.fillRaw(n3 + n8, n4 + n6 - n7, n3 + n5 - n8, n4 + n6, n2);
            this.fillRaw(n3, n4 + n8, n3 + n7, n4 + n6 - n8, n2);
            this.fillRaw(n3 + n5 - n7, n4 + n8, n3 + n5, n4 + n6 - n8, n2);
        }
    }

    /** Set by the click GUI while it draws: skips the soft glow/shadow textures (many blits per frame). */
    public static boolean liteMode;

    public void shadow(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (liteMode) return;
        int n2 = this.mul(n);
        if (n2 >>> 24 == 0) return;
        int n3 = Math.round(f);
        int n4 = Math.round(f2);
        int n5 = Math.round(f + f3) - n3;
        int n6 = Math.round(f2 + f4) - n4;
        int n7 = Math.min(Math.round(f5), Math.min(n5, n6) / 2);
        int n8 = Math.max(1, Math.round(f6));
        int n9 = n7 + n8;
        Handle handle = ShapeCache.shadow(n7, n8);
        int n10 = n3 - n8;
        int n11 = n4 - n8;
        int n12 = n5 + 2 * n8;
        int n13 = n6 + 2 * n8;
        this.blitRaw(handle, n10, n11, n9, n9, 0, 0, n9, n9, n2);
        this.blitRaw(handle, n10 + n12 - n9, n11, n9, n9, n9, 0, n9, n9, n2);
        this.blitRaw(handle, n10, n11 + n13 - n9, n9, n9, 0, n9, n9, n9, n2);
        this.blitRaw(handle, n10 + n12 - n9, n11 + n13 - n9, n9, n9, n9, n9, n9, n9, n2);
        int n14 = n12 - 2 * n9;
        int n15 = n13 - 2 * n9;
        if (n14 > 0) {
            this.blitRaw(handle, n10 + n9, n11, n14, n9, n9, 0, 1, n9, n2);
            this.blitRaw(handle, n10 + n9, n11 + n13 - n9, n14, n9, n9, n9, 1, n9, n2);
        }
        if (n15 <= 0) return;
        this.blitRaw(handle, n10, n11 + n9, n9, n15, 0, n9, n9, 1, n2);
        this.blitRaw(handle, n10 + n12 - n9, n11 + n9, n9, n15, n9, n9, n9, 1, n2);
    }

    public void glow(float f, float f2, float f3, int n) {
        if (liteMode) return;
        int n2 = this.mul(n);
        if (n2 >>> 24 == 0 || !(f3 >= 1.0f)) return;
        int n3 = Math.round(f3);
        this.blitRaw(ShapeCache.radial(), Math.round(f) - n3, Math.round(f2) - n3, n3 * 2, n3 * 2, 0, 0, 128, 128, n2);
    }

    public void icon(SpeakerOff speakerOff, float f, float f2, float f3, int n) {
        int n2 = this.mul(n);
        if (n2 >>> 24 == 0) return;
        float f4 = this.scale();
        int n3 = Math.max(6, Math.round(f3 * f4));
        Handle handle = speakerOff.tex(96);
        this.pushTransform(0.0f, 0.0f, 1.0f / f4);
        this.blitRaw(handle, Math.round(f * f4), Math.round(f2 * f4), n3, n3, 0, 0, 96, 96, n2);
        this.popTransform();
    }

    public float text(String string, float f, float f2, float f3, int n, int n2) {
        if (string == null || string.isEmpty()) return 0.0f;
        int n3 = this.mul(n2);
        float f4 = this.scale();
        FallbackAdvance fallbackAdvance = FallbackFont.atlas(n, Math.round(f3 * f4));
        if (fallbackAdvance == null) {
            return 0.0f;
        }
        float f5 = f4 * f3 / (float)fallbackAdvance.px;
        this.pushTransform(0.0f, 0.0f, 1.0f / f4);
        float f6 = f * f4;
        float f7 = Math.round(f2 * f4 + (float)fallbackAdvance.px * 0.86f);
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            int n4 = fallbackAdvance.index(c);
            if (n4 < 0) {
                n4 = fallbackAdvance.index('?');
            }
            if (fallbackAdvance.w[n4] > 0 && n3 >>> 24 != 0) {
                this.blitRaw(fallbackAdvance.tex, Math.round(f6) + fallbackAdvance.ox[n4], Math.round(f7) + fallbackAdvance.oy[n4], fallbackAdvance.w[n4], fallbackAdvance.h[n4], fallbackAdvance.u[n4], fallbackAdvance.v[n4], fallbackAdvance.w[n4], fallbackAdvance.h[n4], n3);
            }
            f6 += fallbackAdvance.adv[n4] * f5;
        }
        this.popTransform();
        return f6 / f4 - f;
    }

    public float textWidth(String string, float f, int n) {
        if (string == null) {
            return 0.0f;
        }
        float f2 = FallbackFont.width(string, f, n);
        return f2;
    }

    public void textCentered(String string, float f, float f2, float f3, int n, int n2) {
        this.text(string, f - this.textWidth(string, f3, n) / 2.0f, f2, f3, n, n2);
    }

    public void textRight(String string, float f, float f2, float f3, int n, int n2) {
        this.text(string, f - this.textWidth(string, f3, n), f2, f3, n, n2);
    }

    public String ellipsize(String string, float f, float f2, int n) {
        int n2;
        if (this.textWidth(string, f2, n) <= f) {
            return string;
        }
        String string2 = "\u2026";
        float f3 = this.textWidth(string2, f2, n);
        for (n2 = string.length(); n2 > 0 && this.textWidth(string.substring(0, n2), f2, n) + f3 > f; --n2) {
        }
        return string.substring(0, n2).trim() + string2;
    }

    public static int argb(float f, int n, int n2, int n3) {
        return Math.round(Math.max(0.0f, Math.min(1.0f, f)) * 255.0f) << 24 | n << 16 | n2 << 8 | n3;
    }

    public static int white(float f) {
        return BaseRenderer.argb(f, 255, 255, 255);
    }
}
