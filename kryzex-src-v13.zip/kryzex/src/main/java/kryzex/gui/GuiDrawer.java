package kryzex.gui;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import kryzex.client.KryzexClient;
import kryzex.gui.BaseRenderer;
import kryzex.gui.CategorySwitchMap;
import kryzex.gui.CopyDialog;
import kryzex.gui.Easing;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiPanel;
import kryzex.gui.GuiParticle;
import kryzex.gui.GuiSoundType;
import kryzex.gui.HudActions;
import kryzex.gui.Initialized;
import kryzex.gui.Items;
import kryzex.gui.Layer;
import kryzex.gui.ModuleLists;
import kryzex.gui.ModulePanel;
import kryzex.gui.IntSetter;
import kryzex.gui.PaletteEntry;
import kryzex.gui.SelectItem;
import kryzex.gui.SpeakerOff;
import kryzex.gui.Theme;
import kryzex.gui.WorldPitch;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.RangeSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.module.settings.StringSetting;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.client.KryzexPlus;

final class GuiDrawer
implements GuiPanel {
    private static final float WIN_W = 1000.0f;
    private static final float WIN_H = 624.0f;
    private static final float SIDE_W = 236.0f;
    private static final float GAP = 14.0f;
    private static final float SEARCH_H = 56.0f;
    private static final float PLAYER_H = 108.0f;
    private static final float HEADER_H = 78.0f;
    private static final float CARD_H = 90.0f;
    private static final float CARD_GAP = 12.0f;
    private static final float ROW_GAP = 8.0f;
    private static final float PANEL_R = 22.0f;
    private static final int TEXT = BaseRenderer.argb(1.0f, 244, 245, 247);
    private static final int SUB = BaseRenderer.white(0.56f);
    private static final int FAINT = BaseRenderer.white(0.34f);
    private static final int INK = BaseRenderer.argb(1.0f, 22, 23, 27);
    private final HudActions host;
    private final CopyDialog configs = new CopyDialog();
    private final Map<String, float[]> anims = new HashMap<String, float[]>();
    private final List<Layer> hits = new ArrayList<Layer>();
    private final List<GuiParticle> particles = new ArrayList<GuiParticle>();
    private final Map<Setting, float[]> tracks = new IdentityHashMap<Setting, float[]>();
    private final Random random = new Random();
    private final WorldPitch halloween = new WorldPitch();
    private float hw;
    private Category tab = Category.values()[0];
    private Module page;
    private Module pageShown;
    private float tabT = 10.0f;
    private float vis;
    private boolean closing;
    private long last;
    private float dt;
    private float time = (float)(Math.random() * 1000.0);
    private double mx;
    private double my;
    private int sw;
    private int sh;
    private float u = 1.0f;
    private float wx;
    private float wy;
    private float offX;
    private float offY;
    private boolean posLoaded;
    private boolean dragging;
    private double grabX;
    private double grabY;
    private String query = "";
    private boolean searchFocus;
    private float caretT;
    private StringSetting editing;
    private KeybindSetting listening;
    private Module listeningModule;
    private Setting sliding;
    private int slideKnob;
    private final float[] gridScroll = new float[2];
    private final float[] pageScroll = new float[2];
    private final float[] pickScroll = new float[2];
    private float gridMax;
    private float pageMax;
    private float pickMax;
    private final float[] gridRect = new float[4];
    private final float[] pageRect = new float[4];
    private final float[] pickRect = new float[4];
    private ItemSetting picking;
    private ColorSetting coloring;
    private int colorDrag;
    private final float[] hsv = new float[3];
    private float alphaPick = 1.0f;
    private final float[] svRect = new float[4];
    private final float[] hueRect = new float[4];
    private final float[] alphaRect = new float[4];
    private String pickQuery = "";
    private List<?> pickItems;
    private int layerNow;
    private float[] hitClip;
    private String tip;
    private float tipX;
    private float tipY;
    private final ModulePanel selector = new ModulePanel(this::openPaletteColor);
    private ToggleEntry paletteColor;
    private final Initialized resize = new Initialized();
    private float visualScale = 1.0f;
    private double rawMx;
    private double rawMy;
    private float dragStartX;
    private float dragStartY;
    private static final Object THEME_GRID = new Object();

    public GuiDrawer(HudActions hudActions) {
        this.host = hudActions;
    }

    @Override
    public void onOpen(boolean bl) {
        this.closing = false;
        this.last = 0L;
        if (bl) {
            this.selector.reset();
            this.coloring = null;
            this.paletteColor = null;
            this.colorDrag = 0;
            this.vis = 0.0f;
            this.dragging = false;
            this.searchFocus = false;
            this.editing = null;
            this.listening = null;
            this.sliding = null;
            this.picking = null;
            this.tabT = 0.0f;
            GuiAudio.play(GuiSoundType.GUI_OPEN);
            return;
        } else {
            this.vis = Math.max(this.vis, 0.6f);
        }
    }

    @Override
    public void requestClose() {
        if (this.closing) return;
        this.closing = true;
        GuiAudio.stopScroll();
        GuiAudio.play(GuiSoundType.GUI_CLOSE);
        this.dragging = false;
        this.sliding = null;
        this.searchFocus = false;
        this.editing = null;
        this.listening = null;
    }

    @Override
    public boolean isClosing() {
        return this.closing;
    }

    @Override
    public float visibility() {
        return Easing.out(this.vis);
    }

    @Override
    public boolean isTyping() {
        if (this.selector.active()) return true;
        if (this.configs.active()) return true;
        if (this.searchFocus) return true;
        if (this.editing != null) return true;
        if (this.listening != null) return true;
        if (this.picking != null) return true;
        if (this.coloring == null) return false;
        return true;
    }

    @Override
    public void render(BaseRenderer baseRenderer, int n, int n2, double d, double d2, float f) {
        BaseRenderer.liteMode = KryzexPlus.liteGui != null && KryzexPlus.liteGui.getValue();
        try {
            this.renderInner(baseRenderer, n, n2, d, d2, f);
        }
        finally {
            BaseRenderer.liteMode = false;
        }
    }

    private void renderInner(BaseRenderer baseRenderer, int n, int n2, double d, double d2, float f) {
        long l = System.nanoTime();
        this.dt = this.last == 0L ? 0.016f : Easing.clamp((float)(l - this.last) / 1.0E9f, 0.0f, 0.1f);
        this.last = l;
        this.time += this.dt;
        this.tabT += this.dt;
        this.caretT += this.dt;
        this.rawMx = d;
        this.rawMy = d2;
        this.sw = n;
        this.sh = n2;
        this.hits.clear();
        this.tip = null;
        this.loadPosition();
        this.u = Math.max(0.45f, Math.min((float)n2 / 1080.0f, Math.min((float)(n - 40) / 1000.0f, (float)(n2 - 40) / 624.0f)));
        float f2 = Math.max(0.3f, Math.min(f, Math.min((float)(n - 40) / (1000.0f * this.u), (float)(n2 - 40) / (624.0f * this.u))));
        this.visualScale = this.resize.update(f2, this.dt);
        this.mx = this.logicalX(d);
        this.my = this.logicalY(d2);
        if (this.closing) {
            this.vis -= this.dt / 0.22f;
            if (this.vis <= 0.0f) {
                this.vis = 0.0f;
                this.closing = false;
                this.host.closeNow();
            }
        } else {
            this.vis = Math.min(1.0f, this.vis + this.dt / 0.34f);
        }
        float f3 = Easing.out(this.vis);
        if (this.dragging) {
            this.offX = this.dragStartX + (float)((this.rawMx - this.grabX) / (double)this.u);
            this.offY = this.dragStartY + (float)((this.rawMy - this.grabY) / (double)this.u);
        }
        this.clampPosition();
        this.wx = Math.round(((float)n - 1000.0f * this.u) / 2.0f + this.offX * this.u);
        this.wy = Math.round(((float)n2 - 624.0f * this.u) / 2.0f + this.offY * this.u);
        this.applySlide();
        this.applyColorDrag();
        this.hw = Theme.halloween();
        float[] fArray = new float[]{0.0f, 0.0f};
        float f4 = this.host.shakeStrength();
        if (this.hw > 0.003f && f4 > 0.0f) {
            fArray = this.halloween.shake(this.dt, this.host.beat() * this.hw, f4, n2, this.time);
        } else {
            this.halloween.shake(this.dt, 0.0f, 0.0f, n2, this.time);
            this.halloween.calm();
        }
        baseRenderer.pushTransform(fArray[0], fArray[1], 1.0f);
        this.drawBackground(baseRenderer, f3);
        if (this.hw > 0.003f) {
            baseRenderer.pushAlpha(f3);
            this.halloween.background(baseRenderer, n, n2, this.time, this.dt, this.hw, new float[]{this.wx, this.wy, this.d(1000.0f), this.d(624.0f)});
            baseRenderer.popAlpha();
        }
        baseRenderer.popTransform();
        float f5 = 0.955f + 0.045f * f3;
        float f6 = this.wx + 1000.0f * this.u / 2.0f;
        float f7 = this.wy + 624.0f * this.u / 2.0f;
        float f8 = (float)this.sw / 2.0f + this.offX * this.u;
        float f9 = (float)this.sh / 2.0f + this.offY * this.u;
        baseRenderer.pushTransform(f8 * (1.0f - this.visualScale), f9 * (1.0f - this.visualScale), this.visualScale);
        baseRenderer.pushTransform(f6 * (1.0f - f5), f7 * (1.0f - f5) + (1.0f - f3) * 14.0f * this.u, f5);
        baseRenderer.pushAlpha(f3);
        this.layerNow = 0;
        this.drawSidebar(baseRenderer);
        this.drawPlayer(baseRenderer);
        baseRenderer.pushAlpha(1.0f - this.selector.visibility());
        this.drawMain(baseRenderer);
        this.drawSearchBar(baseRenderer);
        baseRenderer.popAlpha();
        if (this.tip != null) {
            this.drawTip(baseRenderer);
        }
        this.layerNow = 1;
        this.drawPicker(baseRenderer);
        this.selector.render(baseRenderer, this.mainX(), this.wy, this.mainW(), this.mainH(), this.u, this.dt, this.mx, this.my);
        this.drawColorPicker(baseRenderer);
        this.layerNow = 2;
        this.configs.render(baseRenderer, this.mainX(), this.wy, this.mainW(), this.mainH(), this.u, this.dt, this.mx, this.my, !this.closing && this.vis >= 0.6f);
        baseRenderer.popAlpha();
        baseRenderer.popTransform();
        baseRenderer.popTransform();
    }

    private float d(float f) {
        return f * this.u;
    }

    private float an(String string, float f, float f2) {
        float[] fArray = this.anims.computeIfAbsent(string, arg_0 -> GuiDrawer.lmbd$an$0(f, arg_0));
        fArray[0] = fArray[0] + (f - fArray[0]) * (1.0f - (float)Math.exp(-f2 * this.dt));
        if (!(Math.abs(f - fArray[0]) < 5.0E-4f)) return fArray[0];
        fArray[0] = f;
        return fArray[0];
    }

    private void drawBackground(BaseRenderer baseRenderer, float f) {
        baseRenderer.pushAlpha(f);
        float f2 = (float)this.sh * 0.04f;
        baseRenderer.rect(-f2, -f2, (float)this.sw + 2.0f * f2, (float)this.sh + 2.0f * f2, BaseRenderer.argb(0.38f, 5, 6, 8));
        baseRenderer.gradient(-f2, -f2, (float)this.sw + 2.0f * f2, (float)this.sh + 2.0f * f2, Theme.bgTop(0.2f), Theme.bgBottom(0.5f));
        float f3 = Math.max(this.sw, this.sh);
        float f4 = Theme.lightAmount();
        float f5 = this.time;
        baseRenderer.popAlpha();
    }

    private void drawParticles(BaseRenderer baseRenderer, float f) {
        if (this.particles.isEmpty()) {
            for (int i = 0; i < 48; ++i) {
                GuiParticle guiParticle = new GuiParticle();
                guiParticle.x = this.random.nextFloat();
                guiParticle.y = this.random.nextFloat();
                guiParticle.speed = 0.004f + this.random.nextFloat() * 0.01f;
                guiParticle.size = 0.8f + this.random.nextFloat() * 1.7f;
                guiParticle.phase = this.random.nextFloat() * 100.0f;
                guiParticle.fade = 0.18f + this.random.nextFloat() * 0.35f;
                guiParticle.sway = 0.004f + this.random.nextFloat() * 0.01f;
                guiParticle.base = 0.25f + this.random.nextFloat() * 0.55f;
                this.particles.add(guiParticle);
            }
        }
        baseRenderer.pushAlpha(f);
        float f2 = this.hw;
        for (GuiParticle guiParticle : this.particles) {
            guiParticle.y -= guiParticle.speed * this.dt * (1.0f + 0.5f * f2);
            guiParticle.x += (float)Math.sin(this.time * 0.35f + guiParticle.phase) * guiParticle.sway * this.dt;
            if (guiParticle.y < -0.05f) {
                guiParticle.y = 1.05f;
                guiParticle.x = this.random.nextFloat();
            }
            if (guiParticle.x < -0.05f) {
                guiParticle.x = 1.05f;
            } else if (guiParticle.x > 1.05f) {
                guiParticle.x = -0.05f;
            }
            float f3 = 0.5f + 0.5f * (float)Math.sin(this.time * guiParticle.fade + guiParticle.phase);
            float f4 = guiParticle.base * f3 * f3;
            float f5 = guiParticle.x * (float)this.sw;
            float f6 = guiParticle.y * (float)this.sh;
            float f7 = guiParticle.size * Math.max(1.0f, this.u);
            int n = Easing.mix(BaseRenderer.white(0.045f * f4), Theme.light(0.06f * f4), 0.7f);
            int n2 = Easing.mix(BaseRenderer.white(0.42f * f4), Theme.light(0.42f * f4), 0.35f);
            if (f2 > 0.003f) {
                float f8 = 0.75f + 0.25f * (float)Math.sin(this.time * 9.0f + guiParticle.phase * 3.0f);
                boolean bl = (int)(guiParticle.phase * 10.0f) % 5 == 0;
                int n3 = bl ? BaseRenderer.argb(0.06f * f4, 170, 110, 255) : BaseRenderer.argb(0.07f * f4 * f8, 255, 120, 40);
                int n4 = bl ? BaseRenderer.argb(0.45f * f4, 225, 200, 255) : BaseRenderer.argb(0.55f * f4 * f8, 255, 196, 120);
                n = Easing.mix(n, n3, f2);
                n2 = Easing.mix(n2, n4, f2);
            }
            baseRenderer.glow(f5, f6, f7 * 9.0f, n);
            baseRenderer.glow(f5, f6, f7 * 2.4f, n2);
        }
        baseRenderer.popAlpha();
    }

    private void glass(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6) {
        baseRenderer.shadow(f, f2, f3, f4, f5, this.d(30.0f), BaseRenderer.argb(0.42f, 0, 0, 0));
        baseRenderer.round(f, f2, f3, f4, f5, Theme.glass(0.6f));
        baseRenderer.roundGradient(f, f2, f3, Math.min(f4, Math.max(f4 * 0.5f, Math.min(f4, this.d(150.0f)))), f5, BaseRenderer.white(0.05f), BaseRenderer.white(0.0f));
        baseRenderer.outline(f, f2, f3, f4, f5, Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.085f));
        baseRenderer.rect(f + f5, f2 + Math.max(1.0f, this.u), f3 - 2.0f * f5, Math.max(1.0f, this.u * 0.8f), BaseRenderer.white(0.05f));
    }

    private float sideX() {
        return this.wx;
    }

    private float mainX() {
        return this.wx + this.d(250.0f);
    }

    private float mainW() {
        return this.d(750.0f);
    }

    private float mainH() {
        return this.d(554.0f);
    }

    private void drawSidebar(BaseRenderer baseRenderer) {
        float f = this.sideX();
        float f2 = this.wy;
        float f3 = this.d(236.0f);
        float f4 = this.d(502.0f);
        this.glass(baseRenderer, f, f2, f3, f4, this.d(22.0f), 0.4f);
        this.halloween.panelWeb(baseRenderer, f, f2, f3, f4, this.u, this.time, this.hw, true);
        float f5 = this.d(86.0f);
        this.hit(f, f2, f3, f5, this::lmbd$drawSidebar$0);
        float f6 = this.d(40.0f);
        float f7 = f + this.d(20.0f);
        float f8 = f2 + this.d(23.0f);
        float f9 = 0.5f + 0.5f * (float)Math.sin(this.time * 0.8f);
        baseRenderer.glow(f7 + f6 / 2.0f, f8 + f6 / 2.0f, f6 * 1.25f, Easing.mix(BaseRenderer.white(0.07f + 0.03f * f9), Theme.logoBottom(0.1f + 0.04f * f9), 0.6f));
        baseRenderer.imageGradient("logo", f7, f8, f6, Theme.logoTop(1.0f), Theme.logoBottom(1.0f));
        baseRenderer.glow(f7 + f6 + this.d(48.0f), f8 + f6 / 2.0f, this.d(54.0f), Easing.mix(BaseRenderer.white(0.035f), Theme.light(0.045f), 0.6f));
        float f10 = baseRenderer.text("Kryzex", f7 + f6 + this.d(12.0f), f8 + this.d(2.0f), this.d(23.0f), 1, TEXT);
        WorldPitch.lantern(baseRenderer, f7 + f6 + this.d(18.0f) + f10, f8 + this.d(4.0f), this.d(19.0f), this.time, this.hw);
        baseRenderer.rect(f + this.d(18.0f), f2 + f5, f3 - this.d(36.0f), Math.max(1.0f, this.u), BaseRenderer.white(0.06f));
        Category[] categoryArray = Category.values();
        float f11 = f2 + f5 + this.d(14.0f);
        float f12 = this.d(46.0f);
        boolean bl = !this.query.isEmpty();
        for (Category category : categoryArray) {
            String string = "tab:" + category.name();
            float f13 = f + this.d(12.0f);
            float f14 = f3 - this.d(24.0f);
            boolean bl2 = category == this.tab && !bl;
            boolean bl3 = this.hot(f13, f11, f14, f12);
            float f15 = this.an(string + ":h", bl3 ? 1.0f : 0.0f, 14.0f);
            float f16 = this.an(string + ":s", bl2 ? 1.0f : 0.0f, 11.0f);
            if (f16 > 0.01f) {
                baseRenderer.glow(f13 + this.d(30.0f), f11 + f12 / 2.0f, this.d(70.0f), Easing.mix(BaseRenderer.white(0.045f * f16), Theme.accent(0.07f * f16), 0.6f));
            }
            baseRenderer.round(f13, f11, f14, f12, this.d(14.0f), Easing.mix(BaseRenderer.white(0.035f * f15 + 0.085f * f16), Theme.accent(0.035f * f15 + 0.085f * f16), 0.35f * f16));
            if (f16 > 0.01f) {
                baseRenderer.outline(f13, f11, f14, f12, this.d(14.0f), Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.1f * f16), Theme.accent(0.16f * f16), 0.6f));
                float f17 = this.d(18.0f) * f16;
                baseRenderer.round(f13 + this.d(3.0f), f11 + (f12 - f17) / 2.0f, this.d(3.0f), f17, this.d(1.5f), Theme.accent(0.95f * f16));
            }
            int n = Easing.mix(BaseRenderer.white(0.66f), TEXT, Math.max(f15 * 0.6f, f16));
            float f18 = this.d(19.0f);
            baseRenderer.icon(GuiDrawer.iconFor(category), f13 + this.d(16.0f), f11 + (f12 - f18) / 2.0f, f18, n);
            baseRenderer.text(category.name.toString(), f13 + this.d(46.0f), f11 + (f12 - this.d(15.0f)) / 2.0f - this.d(0.5f), this.d(14.5f), 0, n);
            int n2 = this.modules(category).size();
            String string2 = String.valueOf(n2);
            float f19 = Math.max(this.d(24.0f), baseRenderer.textWidth(string2, this.d(11.0f), 1) + this.d(14.0f));
            float f20 = f13 + f14 - f19 - this.d(10.0f);
            baseRenderer.round(f20, f11 + (f12 - this.d(22.0f)) / 2.0f, f19, this.d(22.0f), this.d(11.0f), BaseRenderer.white(0.05f + 0.05f * f16));
            baseRenderer.textCentered(string2, f20 + f19 / 2.0f, f11 + (f12 - this.d(11.0f)) / 2.0f - this.d(0.5f), this.d(11.0f), 1, BaseRenderer.white(0.45f + 0.4f * f16));
            Category category2 = category;
            this.hit(f13, f11, f14, f12, arg_0 -> this.lmbd$drawSidebar$1(category2, arg_0));
            f11 += f12 + this.d(6.0f);
        }
        float f21 = this.wy + this.d(450.0f);
        float f22 = this.sideX() + this.d(18.0f);
        float f23 = this.d(200.0f);
        baseRenderer.round(f22, f21, f23, this.d(32.0f), this.d(10.0f), BaseRenderer.white(0.045f));
        baseRenderer.icon(SpeakerOff.LAYOUT, f22 + this.d(10.0f), f21 + this.d(9.0f), this.d(14.0f), BaseRenderer.white(0.65f));
        baseRenderer.text("Client Settings", f22 + this.d(33.0f), f21 + this.d(10.0f), this.d(11.5f), 0, BaseRenderer.white(0.8f));
        this.hit(f22, f21, f23, this.d(32.0f), this::lmbd$drawSidebar$2);
    }

    private void selectTab(Category category) {
        boolean bl = category != this.tab || !this.query.isEmpty() || this.page != null;
        this.tab = category;
        this.query = "";
        this.searchFocus = false;
        this.page = null;
        if (!bl) return;
        this.tabT = 0.0f;
        this.gridScroll[0] = 0.0f;
        this.gridScroll[1] = 0.0f;
        GuiAudio.play(GuiSoundType.TAB);
    }

    private static SpeakerOff iconFor(Category category) {
        SpeakerOff speakerOff;
        switch (CategorySwitchMap.$SwitchMap$kryzex$module$Category[category.ordinal()]) {
            default: {
                throw new MatchException(null, null);
            }
            case 1: {
                speakerOff = SpeakerOff.SWORD;
                return speakerOff;
            }
            case 2: {
                speakerOff = SpeakerOff.GRID;
                return speakerOff;
            }
            case 3: {
                speakerOff = SpeakerOff.BOLT;
                return speakerOff;
            }
            case 4: {
                speakerOff = SpeakerOff.DONUT;
                return speakerOff;
            }
            case 5: {
                speakerOff = SpeakerOff.EYE;
                return speakerOff;
            }
            case 6: {
                speakerOff = SpeakerOff.MONITOR;
            }
        }
        return speakerOff;
    }

    private void drawPlayer(BaseRenderer baseRenderer) {
        float f = this.sideX();
        float f2 = this.d(108.0f);
        float f3 = this.wy + this.d(624.0f) - f2;
        float f4 = this.d(236.0f);
        this.glass(baseRenderer, f, f3, f4, f2, this.d(22.0f), 2.2f);
        float f5 = this.d(52.0f);
        float f6 = f + this.d(18.0f);
        float f7 = f3 + (f2 - f5) / 2.0f;
        baseRenderer.round(f6, f7, f5, f5, this.d(16.0f), BaseRenderer.white(0.07f));
        baseRenderer.outline(f6, f7, f5, f5, this.d(16.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.1f));
        float f8 = this.d(32.0f);
        baseRenderer.head(f6 + (f5 - f8) / 2.0f, f7 + (f5 - f8) / 2.0f, f8);
        float f9 = f6 + f5 + this.d(14.0f);
        float f10 = f + f4 - f9 - this.d(14.0f);
        baseRenderer.text(baseRenderer.ellipsize(this.host.playerName(), f10, this.d(15.0f), 1), f9, f3 + this.d(25.0f), this.d(15.0f), 1, TEXT);
        baseRenderer.text(baseRenderer.ellipsize(this.host.serverLine(), f10, this.d(11.5f), 0), f9, f3 + this.d(47.0f), this.d(11.5f), 0, SUB);
        int n = 0;
        for (Module module : this.allModules()) {
            if (!module.isEnabled()) continue;
            ++n;
        }
        float f11 = 0.55f + 0.45f * (float)Math.sin(this.time * 2.2f);
        float f12 = f3 + this.d(71.0f);
        baseRenderer.glow(f9 + this.d(3.5f), f12 + this.d(3.5f), this.d(9.0f), Theme.accent(0.22f * f11));
        baseRenderer.circle(f9 + this.d(3.5f), f12 + this.d(3.5f), this.d(3.0f), Theme.accent(0.9f));
        baseRenderer.text(n + (n == 1 ? " module active" : " modules active"), f9 + this.d(13.0f), f12 - this.d(2.0f), this.d(11.0f), 0, FAINT);
    }

    private void drawMain(BaseRenderer baseRenderer) {
        float f = this.mainX();
        float f2 = this.wy;
        float f3 = this.mainW();
        float f4 = this.mainH();
        this.glass(baseRenderer, f, f2, f3, f4, this.d(22.0f), 4.1f);
        this.halloween.panelWeb(baseRenderer, f, f2, f3, f4, this.u, this.time, this.hw * 0.8f, false);
        float f5 = this.configs.visibility();
        if (f5 >= 0.995f) return;
        baseRenderer.pushAlpha(1.0f - f5);
        float f6 = this.an("page", this.page != null ? 1.0f : 0.0f, 10.0f);
        if (this.page != null) {
            this.pageShown = this.page;
        }
        float f7 = this.d(36.0f);
        if (f6 < 0.995f) {
            baseRenderer.pushAlpha(1.0f - f6);
            baseRenderer.pushTransform(-f7 * Easing.inOut(f6), 0.0f, 1.0f);
            this.drawGridPage(baseRenderer, f, f2, f3, f4, f6 < 0.5f);
            baseRenderer.popTransform();
            baseRenderer.popAlpha();
        }
        if (f6 > 0.005f && this.pageShown != null) {
            baseRenderer.pushAlpha(f6);
            baseRenderer.pushTransform(f7 * (1.0f - Easing.inOut(f6)), 0.0f, 1.0f);
            this.drawSettingsPage(baseRenderer, this.pageShown, f, f2, f3, f4, f6 >= 0.5f);
            baseRenderer.popTransform();
            baseRenderer.popAlpha();
        }
        baseRenderer.popAlpha();
    }

    private void header(BaseRenderer baseRenderer, float f, float f2, float f3, SpeakerOff speakerOff, String string, String string2, boolean bl) {
        if (bl) {
            this.hit(f, f2, f3, this.d(78.0f), this::lmbd$header$0);
        }
        float f4 = this.d(44.0f);
        float f5 = f + this.d(22.0f);
        float f6 = f2 + this.d(18.0f);
        baseRenderer.round(f5, f6, f4, f4, this.d(14.0f), BaseRenderer.white(0.07f));
        baseRenderer.outline(f5, f6, f4, f4, this.d(14.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.09f));
        float f7 = this.d(21.0f);
        baseRenderer.icon(speakerOff, f5 + (f4 - f7) / 2.0f, f6 + (f4 - f7) / 2.0f, f7, TEXT);
        baseRenderer.text(string, f5 + f4 + this.d(16.0f), f6 + this.d(1.0f), this.d(21.0f), 1, TEXT);
        baseRenderer.text(baseRenderer.ellipsize(string2, f3 - this.d(260.0f), this.d(12.0f), 0), f5 + f4 + this.d(17.0f), f6 + this.d(27.0f), this.d(12.0f), 0, SUB);
        float f8 = this.d(18.0f);
        baseRenderer.icon(SpeakerOff.GRIP, f + f3 - this.d(22.0f) - f8, f2 + this.d(30.0f), f8, BaseRenderer.white(0.22f));
        baseRenderer.rect(f + this.d(20.0f), f2 + this.d(78.0f), f3 - this.d(40.0f), Math.max(1.0f, this.u), BaseRenderer.white(0.055f));
    }

    private void drawGridPage(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, boolean bl) {
        Object object;
        boolean bl2 = !this.query.isEmpty();
        List<Module> list = bl2 ? this.searchResults() : this.modules(this.tab);
        int n = 0;
        java.util.Iterator<Module> iterator = list.iterator();
        while (iterator.hasNext()) {
            object = iterator.next();
            if (!((Module)object).isEnabled()) continue;
            ++n;
        }
        String object2 = bl2 ? "Search" : this.tab.name.toString();
        Object object3 = object2;
        object = bl2 ? list.size() + (list.size() == 1 ? " result for \"" : " results for \"") + this.query + "\"" : list.size() + (list.size() == 1 ? " module" : " modules") + "  \u00b7  " + n + " enabled";
        this.header(baseRenderer, f, f2, f3, bl2 ? SpeakerOff.SEARCH : GuiDrawer.iconFor(this.tab), (String)object2, (String)object, bl);
        float f5 = f + this.d(18.0f);
        float f6 = f2 + this.d(92.0f);
        float f7 = f3 - this.d(36.0f);
        float f8 = f4 - this.d(92.0f) - this.d(14.0f);
        this.gridRect[0] = f5;
        this.gridRect[1] = f6;
        this.gridRect[2] = f7;
        this.gridRect[3] = f8;
        int n2 = f7 >= this.d(600.0f) ? 2 : 1;
        float f9 = (f7 - this.d(12.0f) * (float)(n2 - 1)) / (float)n2;
        float f10 = this.d(90.0f);
        int n3 = (list.size() + n2 - 1) / n2;
        float f11 = (float)n3 * f10 + (float)Math.max(0, n3 - 1) * this.d(12.0f);
        this.gridMax = Math.max(0.0f, f11 - f8);
        float f12 = this.scroll(this.gridScroll, this.gridMax);
        if (list.isEmpty()) {
            baseRenderer.icon(bl2 ? SpeakerOff.SEARCH : GuiDrawer.iconFor(this.tab), f5 + f7 / 2.0f - this.d(16.0f), f6 + f8 / 2.0f - this.d(46.0f), this.d(32.0f), BaseRenderer.white(0.22f));
            baseRenderer.textCentered(bl2 ? "No modules match" : "Nothing here yet", f5 + f7 / 2.0f, f6 + f8 / 2.0f, this.d(15.0f), 1, SUB);
            return;
        } else {
            baseRenderer.pushClip(f5 - this.d(10.0f), f6, f7 + this.d(20.0f), f8);
            this.hitClip = new float[]{f5, f6, f7, f8};
            for (int i = 0; i < list.size(); ++i) {
                Module module = list.get(i);
                int n4 = i % n2;
                int n5 = i / n2;
                float f13 = f5 + (float)n4 * (f9 + this.d(12.0f));
                float f14 = f6 + (float)n5 * (f10 + this.d(12.0f)) - f12;
                if (f14 + f10 < f6 - this.d(20.0f) || f14 > f6 + f8 + this.d(20.0f)) continue;
                float f15 = Easing.out((this.tabT - (float)i * 0.028f) / 0.34f);
                baseRenderer.pushAlpha(f15);
                baseRenderer.pushTransform(0.0f, (1.0f - f15) * this.d(12.0f), 1.0f);
                this.drawCard(baseRenderer, module, f13, f14, f9, f10, bl && f15 > 0.9f);
                baseRenderer.popTransform();
                baseRenderer.popAlpha();
            }
            this.hitClip = null;
            baseRenderer.popClip();
            this.scrollbar(baseRenderer, f5 + f7 + this.d(4.0f), f6, f8, f12, this.gridMax, f11);
        }
    }

    private void drawCard(BaseRenderer baseRenderer, Module module, float f, float f2, float f3, float f4, boolean bl) {
        int n;
        String string = module.getName().toString();
        String string2 = "card:" + string;
        boolean bl2 = bl && this.hot(f, f2, f3, f4);
        float f5 = this.an(string2 + ":h", bl2 ? 1.0f : 0.0f, 13.0f);
        float f6 = this.an(string2 + ":on", module.isEnabled() ? 1.0f : 0.0f, 10.0f);
        if (f5 > 0.01f) {
            baseRenderer.shadow(f, f2, f3, f4, this.d(18.0f), this.d(16.0f), BaseRenderer.white(0.035f * f5));
        }
        baseRenderer.round(f, f2, f3, f4, this.d(18.0f), BaseRenderer.white(0.035f + 0.03f * f5));
        if (f6 > 0.01f) {
            baseRenderer.round(f, f2, f3, f4, this.d(18.0f), Easing.mix(BaseRenderer.white(0.035f * f6), Theme.accent(0.05f * f6), 0.6f));
        }
        if (f5 > 0.01f) {
            baseRenderer.pushClip(f, f2, f3, f4);
            baseRenderer.glow(Easing.clamp((float)this.mx, f, f + f3), f2 + f4 * 0.15f, f3 * 0.45f, BaseRenderer.white(0.045f * f5));
            baseRenderer.popClip();
        }
        baseRenderer.outline(f, f2, f3, f4, this.d(18.0f), Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.06f + 0.08f * f5 + 0.06f * f6), Theme.accent(0.06f + 0.08f * f5 + 0.1f * f6), 0.5f * f6));
        float f7 = this.d(20.0f);
        float f8 = this.d(44.0f);
        float f9 = this.d(24.0f);
        float f10 = f + f3 - f7 - f8;
        float f11 = f2 + (f4 - f9) / 2.0f;
        float f12 = this.d(32.0f);
        float f13 = f10 - this.d(12.0f) - f12;
        float f14 = f2 + (f4 - f12) / 2.0f;
        float f15 = f13 - this.d(10.0f) - (f + f7);
        int n2 = Easing.mix(BaseRenderer.white(0.86f), TEXT, f6);
        if (f6 > 0.01f) {
            baseRenderer.glow(f + f7 + this.d(4.0f), f2 + this.d(29.0f), this.d(16.0f), Theme.accent(0.26f * f6));
            baseRenderer.circle(f + f7 + this.d(3.0f), f2 + this.d(29.0f), this.d(3.0f) * (0.6f + 0.4f * f6), Theme.accent(0.97f * f6));
        }
        float f16 = f + f7 + this.d(13.0f) * f6;
        String string3 = baseRenderer.ellipsize(string, f15 - this.d(13.0f) * f6, this.d(15.0f), 1);
        float f17 = baseRenderer.text(string3, f16, f2 + this.d(20.0f), this.d(15.0f), 1, n2);
        List<String> list = this.wrap(baseRenderer, module.getDescription() == null ? "" : module.getDescription().toString(), f15, this.d(11.8f), 2);
        for (n = 0; n < list.size(); ++n) {
            baseRenderer.text(list.get(n), f + f7, f2 + this.d(45.0f) + (float)n * this.d(16.0f), this.d(11.8f), 0, SUB);
        }
        n = bl && this.hot(f13, f14, f12, f12) ? 1 : 0;
        float f18 = this.an(string2 + ":g", n != 0 ? 1.0f : 0.0f, 16.0f);
        baseRenderer.round(f13, f14, f12, f12, this.d(11.0f), BaseRenderer.white(0.035f + 0.03f * f5 + 0.07f * f18));
        float f19 = this.d(17.0f);
        baseRenderer.icon(SpeakerOff.GEAR, f13 + (f12 - f19) / 2.0f, f14 + (f12 - f19) / 2.0f, f19, BaseRenderer.white(0.42f + 0.25f * f5 + 0.33f * f18));
        this.toggle(baseRenderer, f10, f11, f8, f9, f6, f5);
        if (!bl) return;
        this.hit(f, f2, f3, f4, arg_0 -> this.lmbd$drawCard$0(module, arg_0));
        this.hit(f13, f14, f12, f12, arg_0 -> this.lmbd$drawCard$1(module, arg_0));
    }

    private void toggle(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = Easing.inOut(f5);
        int n = Easing.mix(BaseRenderer.white(0.1f + 0.05f * f6), Theme.accent(0.93f), f7);
        baseRenderer.round(f, f2, f3, f4, f4 / 2.0f, n);
        if (f7 < 0.98f) {
            baseRenderer.outline(f, f2, f3, f4, f4 / 2.0f, Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.1f * (1.0f - f7)));
        }
        float f8 = f4 - this.d(6.0f);
        float f9 = Easing.lerp(f + this.d(3.0f), f + f3 - this.d(3.0f) - f8, f7);
        float f10 = f2 + this.d(3.0f);
        if (f7 > 0.02f) {
            baseRenderer.glow(f + f3 / 2.0f, f2 + f4 / 2.0f, f3 * 0.9f, Theme.accent(0.08f * f7));
        }
        baseRenderer.shadow(f9, f10, f8, f8, f8 / 2.0f, this.d(4.0f), BaseRenderer.argb(0.35f, 0, 0, 0));
        baseRenderer.round(f9, f10, f8, f8, f8 / 2.0f, Easing.mix(BaseRenderer.white(0.92f), INK, f7));
    }

    private void toggleModule(Module module) {
        module.toggle();
        GuiAudio.play(module.isEnabled() ? GuiSoundType.ON : GuiSoundType.OFF);
    }

    private void openPage(Module module) {
        this.page = module;
        this.pageScroll[0] = 0.0f;
        this.pageScroll[1] = 0.0f;
        this.editing = null;
        this.listening = null;
        GuiAudio.play(GuiSoundType.OPEN);
    }

    private void closePage() {
        this.page = null;
        this.editing = null;
        this.listening = null;
        GuiAudio.play(GuiSoundType.BACK);
    }

    private void drawSettingsPage(BaseRenderer baseRenderer, Module module, float f, float f2, float f3, float f4, boolean bl) {
        float f5;
        float f6;
        String string;
        String string2 = string = module.getDescription() == null ? "" : module.getDescription().toString();
        if (bl) {
            this.hit(f, f2, f3, this.d(78.0f), this::lmbd$drawSettingsPage$0);
        }
        float f7 = this.d(44.0f);
        float f8 = f + this.d(22.0f);
        float f9 = f2 + this.d(18.0f);
        boolean bl2 = bl && this.hot(f8, f9, f7, f7);
        float f10 = this.an("back", bl2 ? 1.0f : 0.0f, 15.0f);
        baseRenderer.round(f8, f9, f7, f7, this.d(14.0f), BaseRenderer.white(0.07f + 0.07f * f10));
        baseRenderer.outline(f8, f9, f7, f7, this.d(14.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.09f + 0.08f * f10));
        float f11 = this.d(22.0f);
        baseRenderer.icon(SpeakerOff.CHEVRON_LEFT, f8 + (f7 - f11) / 2.0f - this.d(2.0f) * f10, f9 + (f7 - f11) / 2.0f, f11, TEXT);
        if (bl) {
            this.hit(f8, f9, f7, f7, this::lmbd$drawSettingsPage$1);
        }
        String string3 = module.getName().toString();
        boolean bl3 = this.isClient(module);
        String string4 = bl3 ? "Client settings" : string3;
        String string5 = bl3 ? "Themes, sound and interface" : string;
        float f12 = baseRenderer.text(string4, f8 + f7 + this.d(16.0f), f9 + this.d(1.0f), this.d(21.0f), 1, TEXT);
        baseRenderer.text(baseRenderer.ellipsize(string5, f3 - this.d(300.0f), this.d(12.0f), 0), f8 + f7 + this.d(17.0f), f9 + this.d(27.0f), this.d(12.0f), 0, SUB);
        float f13 = this.d(52.0f);
        float f14 = this.d(28.0f);
        float f15 = f + f3 - this.d(24.0f) - f13;
        float f16 = f9 + (f7 - f14) / 2.0f;
        if (bl3) {
            f6 = this.d(18.0f);
            baseRenderer.icon(SpeakerOff.GRIP, f + f3 - this.d(22.0f) - f6, f2 + this.d(30.0f), f6, BaseRenderer.white(0.22f));
        } else {
            boolean bl4 = bl && this.hot(f15, f16, f13, f14);
            f5 = this.an("page:on:" + string3, module.isEnabled() ? 1.0f : 0.0f, 10.0f);
            this.toggle(baseRenderer, f15, f16, f13, f14, f5, this.an("page:toh", bl4 ? 1.0f : 0.0f, 15.0f));
            baseRenderer.textRight(module.isEnabled() ? "Enabled" : "Disabled", f15 - this.d(12.0f), f16 + (f14 - this.d(12.0f)) / 2.0f - this.d(1.0f), this.d(12.0f), 0, SUB);
            if (bl) {
                this.hit(f15, f16, f13, f14, arg_0 -> this.lmbd$drawSettingsPage$2(module, arg_0));
            }
        }
        baseRenderer.rect(f + this.d(20.0f), f2 + this.d(78.0f), f3 - this.d(40.0f), Math.max(1.0f, this.u), BaseRenderer.white(0.055f));
        f6 = f + this.d(18.0f);
        f5 = f2 + this.d(92.0f);
        float f17 = f3 - this.d(36.0f);
        float f18 = f4 - this.d(92.0f) - this.d(14.0f);
        this.pageRect[0] = f6;
        this.pageRect[1] = f5;
        this.pageRect[2] = f17;
        this.pageRect[3] = f18;
        List<Object> list = this.pageItems(module);
        float f19 = 0.0f;
        for (Object object : list) {
            f19 += this.itemHeight(object, f17) + this.d(8.0f);
        }
        f19 = Math.max(0.0f, f19 - this.d(8.0f));
        this.pageMax = Math.max(0.0f, f19 - f18);
        float f20 = this.scroll(this.pageScroll, this.pageMax);
        baseRenderer.pushClip(f6 - this.d(10.0f), f5, f17 + this.d(20.0f), f18);
        this.hitClip = new float[]{f6, f5, f17, f18};
        float f21 = f5 - f20;
        for (Object object : list) {
            float f22 = this.itemHeight(object, f17);
            if (!(f21 + f22 < f5 - this.d(20.0f)) && !(f21 > f5 + f18 + this.d(20.0f))) {
                if (object instanceof Setting) {
                    Setting setting = (Setting)object;
                    this.drawRow(baseRenderer, module, setting, f6, f21, f17, f22, bl);
                } else if (object == THEME_GRID) {
                    this.drawThemes(baseRenderer, f6, f21, f17, bl);
                } else {
                    this.section(baseRenderer, (String)object, f6, f21, f17);
                }
            }
            f21 += f22 + this.d(8.0f);
        }
        this.hitClip = null;
        baseRenderer.popClip();
        this.scrollbar(baseRenderer, f6 + f17 + this.d(4.0f), f5, f18, f20, this.pageMax, f19);
    }

    private boolean isClient(Module module) {
        return module instanceof KryzexPlus;
    }

    private List<Object> pageItems(Module module) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        if (!this.isClient(module)) {
            for (Setting setting : module.getSettings()) {
                if (!SettingGroup.visible(setting)) continue;
                arrayList.add(setting);
            }
            return arrayList;
        }
        Setting[] settingArray = new Setting[]{KryzexPlus.uiSounds, KryzexPlus.uiVolume};
        Setting[] settingArray2 = new Setting[]{KryzexPlus.halloweenMusic, KryzexPlus.halloweenVolume, KryzexPlus.beatShake, KryzexPlus.shakeStrength};
        arrayList.add("Colors");
        arrayList.add(THEME_GRID);
        arrayList.add("Sound");
        arrayList.addAll(List.of(settingArray));
        arrayList.add("Halloween");
        arrayList.addAll(List.of(settingArray2));
        arrayList.add("Interface");
        for (Setting setting : module.getSettings()) {
            if (setting == KryzexPlus.theme || List.of(settingArray).contains(setting) || List.of(settingArray2).contains(setting)) continue;
            arrayList.add(setting);
        }
        return arrayList;
    }

    private float itemHeight(Object object, float f) {
        if (object instanceof Setting) {
            return this.d(62.0f);
        }
        if (object != THEME_GRID) return this.d(26.0f);
        int n = (Theme.values().length + 3) / 4;
        return (float)n * this.d(108.0f) + (float)(n - 1) * this.d(12.0f);
    }

    private void section(BaseRenderer baseRenderer, String string, float f, float f2, float f3) {
        float f4 = f2 + this.d(8.0f);
        baseRenderer.text(string.toUpperCase(Locale.ROOT), f + this.d(6.0f), f4, this.d(10.5f), 1, BaseRenderer.white(0.42f));
        float f5 = baseRenderer.textWidth(string.toUpperCase(Locale.ROOT), this.d(10.5f), 1);
        baseRenderer.rect(f + this.d(16.0f) + f5, f4 + this.d(7.0f), f3 - f5 - this.d(22.0f), Math.max(1.0f, this.u), BaseRenderer.white(0.06f));
    }

    @Override
    public void openStyleSettings() {
        this.pageShown = this.page = this.clientModule();
        this.pageScroll[1] = 0.0f;
        this.pageScroll[0] = 0.0f;
        this.query = "";
        this.editing = null;
        this.listening = null;
        this.sliding = null;
        this.dragging = false;
    }

    @Override
    public boolean styleSettingsOpen() {
        if (this.page == null) return false;
        if (!this.isClient(this.page)) return false;
        return true;
    }

    @Override
    public void cancelInteractions() {
        this.dragging = false;
        this.sliding = null;
        this.listening = null;
        this.editing = null;
        this.searchFocus = false;
        if (this.configs.isOpen()) {
            this.configs.close();
        }
        this.selector.reset();
        this.coloring = null;
        this.picking = null;
    }

    private void drawThemes(BaseRenderer baseRenderer, float f, float f2, float f3, boolean bl) {
        Theme[] themeArray = Theme.values();
        Theme theme = Theme.selected();
        int n = 4;
        float f4 = this.d(12.0f);
        float f5 = (f3 - f4 * (float)(n - 1)) / (float)n;
        float f6 = this.d(108.0f);
        for (int i = 0; i < themeArray.length; ++i) {
            Theme theme2 = themeArray[i];
            float f7 = f + (float)(i % n) * (f5 + f4);
            float f8 = f2 + (float)(i / n) * (f6 + f4);
            String string = "theme:" + theme2.name();
            boolean bl2 = bl && this.hot(f7, f8, f5, f6);
            float f9 = this.an(string + ":h", bl2 ? 1.0f : 0.0f, 13.0f);
            float f10 = this.an(string + ":s", theme2 == theme ? 1.0f : 0.0f, 9.0f);
            float f11 = this.d(2.0f) * f9;
            f8 -= f11;
            if (f10 > 0.01f) {
                baseRenderer.shadow(f7, f8, f5, f6, this.d(18.0f), this.d(18.0f), theme2.previewAccent() & 0xFFFFFF | Math.round(0.1f * f10 * 255.0f) << 24);
            }
            baseRenderer.round(f7, f8, f5, f6, this.d(18.0f), BaseRenderer.white(0.035f + 0.03f * f9 + 0.03f * f10));
            float f12 = f7 + this.d(10.0f);
            float f13 = f8 + this.d(10.0f);
            float f14 = f5 - this.d(20.0f);
            float f15 = this.d(58.0f);
            int n2 = theme2.previewTop();
            baseRenderer.roundGradient(f12, f13, f14, f15, this.d(12.0f), Easing.mix(n2, -14013648, 0.25f), Easing.mix(n2, -16448250, 0.55f));
            baseRenderer.pushClip(f12, f13, f14, f15);
            baseRenderer.glow(f12 + f14 * 0.72f, f13 + f15 * 0.35f, f14 * 0.55f, theme2.previewLight() & 0xFFFFFF | Math.round(Math.min(1.0f, (0.12f + 0.06f * f9) * theme2.lightAmount) * 255.0f) << 24);
            baseRenderer.popClip();
            baseRenderer.outline(f12, f13, f14, f15, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f));
            float f16 = this.d(26.0f);
            baseRenderer.imageGradient("logo", f12 + this.d(12.0f), f13 + (f15 - f16) / 2.0f, f16, -1, theme2.previewLogo());
            float f17 = this.d(30.0f);
            float f18 = this.d(16.0f);
            float f19 = f12 + f14 - this.d(12.0f) - f17;
            float f20 = f13 + (f15 - f18) / 2.0f;
            baseRenderer.round(f19, f20, f17, f18, f18 / 2.0f, theme2.previewAccent() & 0xFFFFFF | 0xED000000);
            float f21 = f18 - this.d(4.0f);
            baseRenderer.round(f19 + f17 - this.d(2.0f) - f21, f20 + this.d(2.0f), f21, f21, f21 / 2.0f, INK);
            baseRenderer.text(theme2.name(), f7 + this.d(14.0f), f8 + f6 - this.d(31.0f), this.d(13.0f), 1, Easing.mix(BaseRenderer.white(0.78f), TEXT, Math.max(f10, f9)));
            if (f10 > 0.01f) {
                float f22 = this.d(9.0f) * (0.7f + 0.3f * f10);
                float f23 = f7 + f5 - this.d(22.0f);
                float f24 = f8 + f6 - this.d(23.0f);
                baseRenderer.glow(f23, f24, f22 * 2.4f, theme2.previewAccent() & 0xFFFFFF | Math.round(0.25f * f10 * 255.0f) << 24);
                baseRenderer.circle(f23, f24, f22, theme2.previewAccent() & 0xFFFFFF | Math.round(f10 * 255.0f) << 24);
                float f25 = f22 * 1.3f;
                baseRenderer.icon(SpeakerOff.CHECK, f23 - f25 / 2.0f, f24 - f25 / 2.0f, f25, BaseRenderer.argb(f10, 22, 23, 27));
            }
            baseRenderer.outline(f7, f8, f5, f6, this.d(18.0f), Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.06f + 0.08f * f9), theme2.previewAccent() & 0xFFFFFF | Math.round(153.0f) << 24, f10));
            if (!bl) continue;
            int n3 = i;
            this.hit(f7, f8, f5, f6, arg_0 -> GuiDrawer.lmbd$drawThemes$0(n3, arg_0));
        }
    }

    private void drawRow(BaseRenderer baseRenderer, Module module, Setting setting, float f, float f2, float f3, float f4, boolean bl) {
        String string = "row:" + System.identityHashCode(setting);
        boolean bl2 = bl && this.hot(f, f2, f3, f4);
        float f5 = this.an(string + ":h", bl2 ? 1.0f : 0.0f, 13.0f);
        baseRenderer.round(f, f2, f3, f4, this.d(16.0f), BaseRenderer.white(0.03f + 0.025f * f5));
        baseRenderer.outline(f, f2, f3, f4, this.d(16.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.05f + 0.05f * f5));
        String string2 = setting.getName() == null ? "" : setting.getName().toString();
        String string3 = setting.getDescription() == null ? "" : setting.getDescription().toString();
        float f6 = this.d(20.0f);
        float f7 = this.d(300.0f);
        float f8 = f3 - f6 * 2.0f - f7 - this.d(12.0f);
        if (string3.isEmpty()) {
            baseRenderer.text(baseRenderer.ellipsize(string2, f8, this.d(14.0f), 1), f + f6, f2 + (f4 - this.d(14.0f)) / 2.0f - this.d(1.0f), this.d(14.0f), 1, TEXT);
        } else {
            baseRenderer.text(baseRenderer.ellipsize(string2, f8, this.d(14.0f), 1), f + f6, f2 + this.d(14.0f), this.d(14.0f), 1, TEXT);
            baseRenderer.text(baseRenderer.ellipsize(string3, f8, this.d(11.5f), 0), f + f6, f2 + this.d(35.0f), this.d(11.5f), 0, SUB);
        }
        float f9 = f + f3 - f6;
        float f10 = f2 + f4 / 2.0f;
        SelectItem selectItem = Items.forSetting(module, setting);
        if (selectItem != null) {
            float f11 = this.d(232.0f);
            float f12 = this.d(38.0f);
            float f13 = f9 - f11;
            float f14 = f10 - f12 / 2.0f;
            baseRenderer.round(f13, f14, f11, f12, this.d(12.0f), BaseRenderer.white(0.055f + 0.045f * f5));
            baseRenderer.outline(f13, f14, f11, f12, this.d(12.0f), this.d(0.9f), BaseRenderer.white(0.09f));
            Object object = selectItem.icon();
            if (object != null) {
                baseRenderer.item(object, f13 + this.d(9.0f), f14 + this.d(7.0f), this.d(24.0f));
            } else {
                baseRenderer.icon(SpeakerOff.BOX, f13 + this.d(12.0f), f14 + this.d(10.0f), this.d(18.0f), BaseRenderer.white(0.65f));
            }
            baseRenderer.text(baseRenderer.ellipsize(selectItem.summary(), f11 - this.d(67.0f), this.d(12.0f), 0), f13 + this.d(42.0f), f14 + this.d(11.0f), this.d(12.0f), 0, TEXT);
            baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f13 + f11 - this.d(26.0f), f14 + this.d(11.0f), this.d(15.0f), BaseRenderer.white(0.5f));
            if (!bl) return;
            this.hit(f13, f14, f11, f12, arg_0 -> this.lmbd$drawRow$0(setting, selectItem, arg_0));
            return;
        } else if (setting instanceof BoolSetting) {
            BoolSetting boolSetting = (BoolSetting)((Object)setting);
            float f15 = this.d(44.0f);
            float f16 = this.d(24.0f);
            float f17 = this.an(string + ":on", boolSetting.getValue() ? 1.0f : 0.0f, 10.0f);
            this.toggle(baseRenderer, f9 - f15, f10 - f16 / 2.0f, f15, f16, f17, f5);
            if (!bl) return;
            this.hit(f, f2, f3, f4, arg_0 -> GuiDrawer.lmbd$drawRow$1(boolSetting, arg_0));
            return;
        } else if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            float f18 = this.d(66.0f);
            float f19 = this.d(200.0f);
            float f20 = f9 - f18 - this.d(14.0f) - f19;
            double d = numberSetting.getMax() - numberSetting.getMin();
            float f21 = d <= 0.0 ? 0.0f : (float)((numberSetting.getValue() - numberSetting.getMin()) / d);
            float f22 = this.an(string + ":v", f21, 18.0f);
            boolean bl3 = this.sliding == numberSetting;
            float f23 = this.an(string + ":a", !bl3 && !bl2 ? 0.0f : 1.0f, 14.0f);
            this.slider(baseRenderer, numberSetting, f20, f10, f19, f22, -1.0f, f23);
            this.valuePill(baseRenderer, GuiDrawer.format(numberSetting.getValue(), numberSetting.getFormat()), f9 - f18, f10, f18);
            if (!bl) return;
            this.hit(f20 - this.d(8.0f), f10 - this.d(14.0f), f19 + this.d(16.0f), this.d(28.0f), arg_0 -> this.lmbd$drawRow$2(numberSetting, arg_0));
            return;
        } else if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            float f24 = this.d(96.0f);
            float f25 = this.d(170.0f);
            float f26 = f9 - f24 - this.d(14.0f) - f25;
            double d = rangeSetting.getMaxValue() - rangeSetting.getMinValue();
            float f27 = d <= 0.0 ? 0.0f : (float)((rangeSetting.getCurrentMin() - rangeSetting.getMinValue()) / d);
            float f28 = d <= 0.0 ? 1.0f : (float)((rangeSetting.getCurrentMax() - rangeSetting.getMinValue()) / d);
            float f29 = this.an(string + ":v1", f27, 18.0f);
            float f30 = this.an(string + ":v2", f28, 18.0f);
            float f31 = this.an(string + ":a", this.sliding != rangeSetting && !bl2 ? 0.0f : 1.0f, 14.0f);
            this.slider(baseRenderer, rangeSetting, f26, f10, f25, f29, f30, f31);
            this.valuePill(baseRenderer, GuiDrawer.format(rangeSetting.getCurrentMin(), rangeSetting.getStep()) + " \u2013 " + GuiDrawer.format(rangeSetting.getCurrentMax(), rangeSetting.getStep()), f9 - f24, f10, f24);
            if (!bl) return;
            this.hit(f26 - this.d(8.0f), f10 - this.d(14.0f), f25 + this.d(16.0f), this.d(28.0f), arg_0 -> this.lmbd$drawRow$3(rangeSetting, f27, f28, arg_0));
            return;
        } else if (setting instanceof CycleSetting) {
            CycleSetting cycleSetting = (CycleSetting)((Object)setting);
            float f32 = this.d(200.0f);
            float f33 = this.d(34.0f);
            float f34 = f9 - f32;
            float f35 = f10 - f33 / 2.0f;
            boolean bl4 = bl && this.hot(f34, f35, f32, f33);
            float f36 = this.an(string + ":m", bl4 ? 1.0f : 0.0f, 15.0f);
            baseRenderer.round(f34, f35, f32, f33, this.d(12.0f), BaseRenderer.white(0.05f + 0.04f * f36));
            baseRenderer.outline(f34, f35, f32, f33, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.07f * f36));
            float f37 = this.d(16.0f);
            baseRenderer.icon(SpeakerOff.CHEVRON_LEFT, f34 + this.d(8.0f), f10 - f37 / 2.0f, f37, BaseRenderer.white(0.45f + 0.4f * f36));
            baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f34 + f32 - this.d(8.0f) - f37, f10 - f37 / 2.0f, f37, BaseRenderer.white(0.45f + 0.4f * f36));
            String string4 = GuiDrawer.prettyEnum(String.valueOf(cycleSetting.getValue()));
            float f38 = this.an(string + ":idx", cycleSetting.getModeIndex(), 16.0f);
            float f39 = (f38 - (float)cycleSetting.getModeIndex()) * this.d(10.0f);
            baseRenderer.pushClip(f34 + this.d(28.0f), f35, f32 - this.d(56.0f), f33);
            baseRenderer.textCentered(baseRenderer.ellipsize(string4, f32 - this.d(64.0f), this.d(12.5f), 1), f34 + f32 / 2.0f + f39, f10 - this.d(7.5f), this.d(12.5f), 1, TEXT);
            baseRenderer.popClip();
            if (!bl) return;
            this.hit(f34, f35, f32 / 2.0f, f33, arg_0 -> GuiDrawer.lmbd$drawRow$4(cycleSetting, arg_0));
            this.hit(f34 + f32 / 2.0f, f35, f32 / 2.0f, f33, arg_0 -> GuiDrawer.lmbd$drawRow$5(cycleSetting, arg_0));
            return;
        } else if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            float f40 = this.d(200.0f);
            float f41 = this.d(34.0f);
            float f42 = f9 - f40;
            float f43 = f10 - f41 / 2.0f;
            boolean bl5 = bl && this.hot(f42, f43, f40, f41);
            float f44 = this.an(string + ":m", bl5 ? 1.0f : 0.0f, 15.0f);
            baseRenderer.round(f42, f43, f40, f41, this.d(12.0f), BaseRenderer.white(0.05f + 0.04f * f44));
            baseRenderer.outline(f42, f43, f40, f41, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.07f * f44));
            float f45 = this.d(16.0f);
            baseRenderer.icon(SpeakerOff.CHEVRON_LEFT, f42 + this.d(8.0f), f10 - f45 / 2.0f, f45, BaseRenderer.white(0.45f + 0.4f * f44));
            baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f42 + f40 - this.d(8.0f) - f45, f10 - f45 / 2.0f, f45, BaseRenderer.white(0.45f + 0.4f * f44));
            float f46 = this.an(string + ":idx", modeSetting.getIndex(), 16.0f);
            float f47 = (f46 - (float)modeSetting.getIndex()) * this.d(10.0f);
            baseRenderer.pushClip(f42 + this.d(28.0f), f43, f40 - this.d(56.0f), f41);
            baseRenderer.textCentered(baseRenderer.ellipsize(modeSetting.getMode(), f40 - this.d(64.0f), this.d(12.5f), 1), f42 + f40 / 2.0f + f47, f10 - this.d(7.5f), this.d(12.5f), 1, TEXT);
            baseRenderer.popClip();
            if (!bl) return;
            this.hit(f42, f43, f40 / 2.0f, f41, arg_0 -> GuiDrawer.lmbd$drawRow$6(modeSetting, arg_0));
            this.hit(f42 + f40 / 2.0f, f43, f40 / 2.0f, f41, arg_0 -> GuiDrawer.lmbd$drawRow$7(modeSetting, arg_0));
            return;
        } else if (setting instanceof ActionSetting) {
            ActionSetting actionSetting = (ActionSetting)setting;
            float f48 = this.d(150.0f);
            float f49 = this.d(34.0f);
            float f50 = f9 - f48;
            float f51 = f10 - f49 / 2.0f;
            boolean bl6 = bl && this.hot(f50, f51, f48, f49);
            float f52 = this.an(string + ":b", bl6 ? 1.0f : 0.0f, 15.0f);
            float f53 = this.an(string + ":press", 0.0f, 9.0f);
            baseRenderer.round(f50, f51, f48, f49, this.d(12.0f), Easing.mix(BaseRenderer.white(0.06f + 0.06f * f52), Theme.accent(0.3f), f53));
            baseRenderer.outline(f50, f51, f48, f49, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.1f + 0.1f * f52), Theme.accent(0.6f), Math.max(f53, 0.4f * f52)));
            baseRenderer.textCentered("Run", f50 + f48 / 2.0f, f10 - this.d(7.5f), this.d(12.5f), 1, TEXT);
            if (!bl) return;
            String string5 = string + ":press";
            this.hit(f50, f51, f48, f49, arg_0 -> this.lmbd$drawRow$8(string5, actionSetting, arg_0));
            return;
        } else if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            float f54 = this.d(150.0f);
            float f55 = this.d(34.0f);
            float f56 = f9 - f54;
            float f57 = f10 - f55 / 2.0f;
            boolean bl7 = bl && this.hot(f56, f57, f54, f55);
            float f58 = this.an(string + ":c", !bl7 && this.coloring != colorSetting ? 0.0f : 1.0f, 15.0f);
            baseRenderer.round(f56, f57, f54, f55, this.d(12.0f), BaseRenderer.white(0.05f + 0.05f * f58));
            baseRenderer.outline(f56, f57, f54, f55, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.1f * f58));
            float f59 = this.d(20.0f);
            float f60 = f56 + this.d(9.0f);
            this.checker(baseRenderer, f60, f10 - f59 / 2.0f, f59, f59, this.d(5.0f));
            baseRenderer.round(f60, f10 - f59 / 2.0f, f59, f59, this.d(7.0f), colorSetting.getArgb());
            baseRenderer.outline(f60, f10 - f59 / 2.0f, f59, f59, this.d(7.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.3f));
            baseRenderer.text(GuiDrawer.hex(colorSetting.getArgb()), f60 + f59 + this.d(10.0f), f10 - this.d(7.5f), this.d(12.5f), 1, TEXT);
            if (!bl) return;
            this.hit(f56, f57, f54, f55, arg_0 -> this.lmbd$drawRow$9(colorSetting, arg_0));
            return;
        } else if (setting instanceof KeybindSetting) {
            KeybindSetting keybindSetting = (KeybindSetting)((Object)setting);
            float f61 = this.d(150.0f);
            float f62 = this.d(34.0f);
            float f63 = f9 - f61;
            float f64 = f10 - f62 / 2.0f;
            boolean bl8 = this.listening == keybindSetting;
            boolean bl9 = bl && this.hot(f63, f64, f61, f62);
            float f65 = this.an(string + ":k", !bl9 && !bl8 ? 0.0f : 1.0f, 15.0f);
            float f66 = bl8 ? 0.5f + 0.5f * (float)Math.sin(this.time * 6.0f) : 0.0f;
            baseRenderer.round(f63, f64, f61, f62, this.d(12.0f), BaseRenderer.white(0.05f + 0.05f * f65 + 0.05f * f66));
            baseRenderer.outline(f63, f64, f61, f62, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.1f * f65 + 0.12f * f66));
            float f67 = this.d(16.0f);
            baseRenderer.icon(SpeakerOff.KEYBOARD, f63 + this.d(12.0f), f10 - f67 / 2.0f, f67, BaseRenderer.white(0.55f + 0.3f * f65));
            String string6 = bl8 ? "Press a key\u2026" : this.keyLabel(keybindSetting.getValue());
            baseRenderer.text(baseRenderer.ellipsize(string6, f61 - this.d(44.0f), this.d(12.5f), 1), f63 + this.d(36.0f), f10 - this.d(7.5f), this.d(12.5f), 1, bl8 ? SUB : TEXT);
            if (!bl) return;
            this.hit(f63, f64, f61, f62, arg_0 -> this.lmbd$drawRow$10(keybindSetting, module, arg_0));
            return;
        } else if (setting instanceof StringSetting) {
            StringSetting stringSetting = (StringSetting)((Object)setting);
            float f68 = this.d(260.0f);
            float f69 = this.d(34.0f);
            float f70 = f9 - f68;
            float f71 = f10 - f69 / 2.0f;
            boolean bl10 = this.editing == stringSetting;
            boolean bl11 = bl && this.hot(f70, f71, f68, f69);
            float f72 = this.an(string + ":f", bl10 ? 1.0f : (bl11 ? 0.5f : 0.0f), 15.0f);
            this.field(baseRenderer, f70, f71, f68, f69, stringSetting.getValue() == null ? "" : stringSetting.getValue(), "Type here\u2026", bl10, f72, null);
            if (!bl) return;
            this.hit(f70, f71, f68, f69, arg_0 -> this.lmbd$drawRow$11(stringSetting, arg_0));
            return;
        } else if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            float f73 = this.d(220.0f);
            float f74 = this.d(38.0f);
            float f75 = f9 - f73;
            float f76 = f10 - f74 / 2.0f;
            boolean bl12 = bl && this.hot(f75, f76, f73, f74);
            float f77 = this.an(string + ":i", bl12 ? 1.0f : 0.0f, 15.0f);
            baseRenderer.round(f75, f76, f73, f74, this.d(12.0f), BaseRenderer.white(0.05f + 0.06f * f77));
            baseRenderer.outline(f75, f76, f73, f74, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.08f * f77));
            Object object = this.host.itemOf(itemSetting);
            float f78 = this.d(24.0f);
            baseRenderer.item(object, f75 + this.d(9.0f), f10 - f78 / 2.0f, f78);
            baseRenderer.text(baseRenderer.ellipsize(this.host.itemName(object), f73 - this.d(70.0f), this.d(12.5f), 0), f75 + this.d(42.0f), f10 - this.d(7.5f), this.d(12.5f), 0, TEXT);
            float f79 = this.d(16.0f);
            baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f75 + f73 - this.d(10.0f) - f79, f10 - f79 / 2.0f, f79, BaseRenderer.white(0.4f + 0.4f * f77));
            if (!bl) return;
            this.hit(f75, f76, f73, f74, arg_0 -> this.lmbd$drawRow$12(itemSetting, arg_0));
            return;
        } else {
            if (!(setting instanceof ListSetting)) return;
            ListSetting listSetting = (ListSetting)setting;
            float f80 = this.d(170.0f);
            float f81 = this.d(34.0f);
            float f82 = f9 - f80;
            float f83 = f10 - f81 / 2.0f;
            boolean bl13 = bl && this.hot(f82, f83, f80, f81);
            float f84 = this.an(string + ":s", bl13 ? 1.0f : 0.0f, 15.0f);
            baseRenderer.round(f82, f83, f80, f81, this.d(12.0f), BaseRenderer.white(0.05f + 0.06f * f84));
            baseRenderer.outline(f82, f83, f80, f81, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.08f + 0.08f * f84));
            String string7 = listSetting.isColorOnly() ? "Edit color" : listSetting.selectedCount() + " selected";
            float f85 = this.d(16.0f);
            baseRenderer.icon(SpeakerOff.BOX, f82 + this.d(12.0f), f10 - f85 / 2.0f, f85, BaseRenderer.white(0.6f + 0.3f * f84));
            baseRenderer.text(string7, f82 + this.d(36.0f), f10 - this.d(7.5f), this.d(12.5f), 1, TEXT);
            baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f82 + f80 - this.d(10.0f) - f85, f10 - f85 / 2.0f, f85, BaseRenderer.white(0.4f + 0.4f * f84));
            if (!bl) return;
            this.hit(f82, f83, f80, f81, arg_0 -> this.lmbd$drawRow$13(listSetting, arg_0));
        }
    }

    private void slider(BaseRenderer baseRenderer, Setting setting, float f, float f2, float f3, float f4, float f5, float f6) {
        float f7;
        this.tracks.put(setting, new float[]{f, f3});
        float f8 = this.d(6.0f);
        baseRenderer.round(f, f2 - f8 / 2.0f, f3, f8, f8 / 2.0f, BaseRenderer.white(0.12f));
        boolean bl = f5 >= 0.0f;
        float f9 = bl ? Easing.clamp(f4, 0.0f, 1.0f) : 0.0f;
        float f10 = f7 = bl ? Easing.clamp(f5, 0.0f, 1.0f) : Easing.clamp(f4, 0.0f, 1.0f);
        if (f7 - f9 > 0.0f) {
            baseRenderer.round(f + f3 * f9, f2 - f8 / 2.0f, Math.max(f8, f3 * (f7 - f9)), f8, f8 / 2.0f, Theme.accent(0.92f));
        }
        float f11 = this.d(16.0f) + this.d(2.0f) * f6;
        if (bl) {
            this.knob(baseRenderer, f + f3 * f9, f2, f11, f6);
        }
        this.knob(baseRenderer, f + f3 * f7, f2, f11, f6);
    }

    private void knob(BaseRenderer baseRenderer, float f, float f2, float f3, float f4) {
        baseRenderer.glow(f, f2, f3 * 1.4f, Theme.accent(0.14f * f4));
        baseRenderer.shadow(f - f3 / 2.0f, f2 - f3 / 2.0f, f3, f3, f3 / 2.0f, this.d(5.0f), BaseRenderer.argb(0.45f, 0, 0, 0));
        baseRenderer.round(f - f3 / 2.0f, f2 - f3 / 2.0f, f3, f3, f3 / 2.0f, BaseRenderer.white(0.97f));
        baseRenderer.round(f - f3 * 0.18f, f2 - f3 * 0.18f, f3 * 0.36f, f3 * 0.36f, f3 * 0.18f, Easing.mix(BaseRenderer.argb(0.9f, 40, 41, 46), Theme.accent(0.95f), 0.55f));
    }

    private void valuePill(BaseRenderer baseRenderer, String string, float f, float f2, float f3) {
        float f4 = this.d(30.0f);
        baseRenderer.round(f, f2 - f4 / 2.0f, f3, f4, this.d(10.0f), BaseRenderer.white(0.06f));
        baseRenderer.textCentered(baseRenderer.ellipsize(string, f3 - this.d(10.0f), this.d(12.0f), 1), f + f3 / 2.0f, f2 - this.d(7.0f), this.d(12.0f), 1, TEXT);
    }

    private void field(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, String string, String string2, boolean bl, float f5, SpeakerOff speakerOff) {
        float f6;
        float f7;
        baseRenderer.round(f, f2, f3, f4, Math.min(f4 / 2.0f, this.d(12.0f)), BaseRenderer.white(0.04f + 0.04f * f5));
        baseRenderer.outline(f, f2, f3, f4, Math.min(f4 / 2.0f, this.d(12.0f)), Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.08f + 0.16f * f5), Theme.accent(0.1f + 0.3f * f5), f5));
        float f8 = f + this.d(12.0f);
        if (speakerOff != null) {
            f7 = this.d(17.0f);
            baseRenderer.icon(speakerOff, f8, f2 + (f4 - f7) / 2.0f, f7, BaseRenderer.white(0.5f + 0.4f * f5));
            f8 += f7 + this.d(10.0f);
        }
        f7 = f + f3 - f8 - this.d(12.0f);
        float f9 = f2 + (f4 - this.d(13.0f)) / 2.0f - this.d(1.0f);
        baseRenderer.pushClip(f8, f2, f7 + this.d(4.0f), f4);
        float f10 = 0.0f;
        if (string.isEmpty()) {
            baseRenderer.text(string2, f8, f9, this.d(13.0f), 0, FAINT);
        } else {
            f6 = baseRenderer.textWidth(string, this.d(13.0f), 0);
            float f11 = Math.max(0.0f, f6 - f7);
            f10 = baseRenderer.text(string, f8 - f11, f9, this.d(13.0f), 0, TEXT) - f11;
        }
        if (bl) {
            f6 = 0.5f + 0.5f * (float)Math.cos(this.caretT * 6.0f);
            baseRenderer.rect(f8 + f10 + this.d(1.0f), f2 + f4 * 0.26f, Math.max(1.0f, this.u * 1.4f), f4 * 0.48f, BaseRenderer.white(0.9f * f6));
        }
        baseRenderer.popClip();
    }

    private void beginSlide(Setting setting, int n) {
        this.sliding = setting;
        this.slideKnob = n;
        this.applySlide();
    }

    private void applySlide() {
        float[] fArray;
        if (this.sliding == null || (fArray = this.tracks.get(this.sliding)) == null || !(fArray[1] > 0.0f)) return;
        double d = Easing.clamp((float)((this.mx - (double)fArray[0]) / (double)fArray[1]), 0.0f, 1.0f);
        Setting setting = this.sliding;
        if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            double d2 = GuiDrawer.snap(numberSetting.getMin() + d * (numberSetting.getMax() - numberSetting.getMin()), numberSetting.getFormat());
            double d3 = Math.max(numberSetting.getMin(), Math.min(numberSetting.getMax(), d2));
            if (d3 == numberSetting.getValue()) return;
            numberSetting.getValue(d3);
            GuiAudio.play(GuiSoundType.SLIDE);
            return;
        } else {
            setting = this.sliding;
            if (!(setting instanceof RangeSetting)) return;
            RangeSetting rangeSetting = (RangeSetting)setting;
            double d4 = GuiDrawer.snap(rangeSetting.getMinValue() + d * (rangeSetting.getMaxValue() - rangeSetting.getMinValue()), rangeSetting.getStep());
            d4 = Math.max(rangeSetting.getMinValue(), Math.min(rangeSetting.getMaxValue(), d4));
            if (this.slideKnob == 0) {
                rangeSetting.setCurrentMin(Math.min(d4, rangeSetting.getCurrentMax()));
                return;
            } else {
                rangeSetting.setCurrentMax(Math.max(d4, rangeSetting.getCurrentMin()));
            }
        }
    }

    private static double snap(double d, double d2) {
        return d2 > 0.0 ? (double)Math.round(d / d2) * d2 : d;
    }

    static String format(double d, double d2) {
        if (d2 >= 1.0 || d2 <= 0.0) return String.valueOf(Math.round(d));
        int n = Math.max(1, Math.min(4, (int)Math.ceil(-Math.log10(d2) - 1.0E-9)));
        return String.format(Locale.ROOT, "%." + n + "f", d);
    }

    private static String prettyEnum(String string) {
        if (string.isEmpty()) {
            return string;
        }
        String string2 = string.replace('_', ' ').toLowerCase(Locale.ROOT);
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = true;
        for (char c : string2.toCharArray()) {
            stringBuilder.append(bl ? Character.toUpperCase(c) : c);
            bl = c == ' ' || Character.isDigit(c);
        }
        return stringBuilder.toString();
    }

    private String keyLabel(int n) {
        String string = this.host.keyName(n);
        if (n >= 0) return string != null && !string.isBlank() ? string : "Key " + n;
        return "None";
    }

    private void assignBind(KeybindSetting keybindSetting, Module module, int n) {
        keybindSetting.setValue(n);
        if (keybindSetting.isModuleKey() && module != null) {
            module.setKeybind(n);
        }
        keybindSetting.setListening(false);
        this.listening = null;
        GuiAudio.play(GuiSoundType.CONFIRM);
    }

    private void drawSearchBar(BaseRenderer baseRenderer) {
        float f;
        float f2;
        float f3;
        float f4 = this.mainX();
        float f5 = this.wy + this.d(568.0f);
        float f6 = f3 = this.d(56.0f);
        float f7 = this.d(10.0f);
        float f8 = this.mainW() - (f6 + f7) * 3.0f;
        boolean bl = this.hot(f4, f5, f8, f3);
        float f9 = this.an("search:f", this.searchFocus ? 1.0f : (bl ? 0.45f : 0.0f), 13.0f);
        this.glass(baseRenderer, f4, f5, f8, f3, f3 / 2.0f, 6.3f);
        baseRenderer.round(f4, f5, f8, f3, f3 / 2.0f, BaseRenderer.white(0.035f * f9));
        baseRenderer.outline(f4, f5, f8, f3, f3 / 2.0f, Math.max(1.0f, this.u * 0.9f), Easing.mix(BaseRenderer.white(0.14f * f9), Theme.accent(0.32f * f9), f9));
        float f10 = this.d(19.0f);
        baseRenderer.icon(SpeakerOff.SEARCH, f4 + this.d(22.0f), f5 + (f3 - f10) / 2.0f, f10, BaseRenderer.white(0.55f + 0.4f * f9));
        float f11 = f4 + this.d(54.0f);
        float f12 = f5 + (f3 - this.d(14.5f)) / 2.0f - this.d(1.0f);
        float f13 = f8 - this.d(54.0f) - this.d(80.0f);
        baseRenderer.pushClip(f11, f5, f13, f3);
        float f14 = 0.0f;
        if (this.query.isEmpty()) {
            baseRenderer.text("srced by bob", f11, f12, this.d(14.5f), 0, FAINT);
        } else {
            f2 = baseRenderer.textWidth(this.query, this.d(14.5f), 0);
            f = Math.max(0.0f, f2 - f13 + this.d(6.0f));
            f14 = baseRenderer.text(this.query, f11 - f, f12, this.d(14.5f), 0, TEXT) - f;
        }
        if (this.searchFocus) {
            f2 = 0.5f + 0.5f * (float)Math.cos(this.caretT * 6.0f);
            baseRenderer.rect(f11 + f14 + this.d(1.5f), f5 + f3 * 0.3f, Math.max(1.0f, this.u * 1.4f), f3 * 0.4f, BaseRenderer.white(0.9f * f2));
        }
        baseRenderer.popClip();
        if (!this.query.isEmpty()) {
            float f15;
            f2 = this.d(28.0f);
            f = f4 + f8 - this.d(16.0f) - f2;
            boolean bl2 = this.hot(f, f15 = f5 + (f3 - f2) / 2.0f, f2, f2);
            float f16 = this.an("search:clear", bl2 ? 1.0f : 0.0f, 15.0f);
            baseRenderer.round(f, f15, f2, f2, f2 / 2.0f, BaseRenderer.white(0.06f + 0.08f * f16));
            float f17 = this.d(14.0f);
            baseRenderer.icon(SpeakerOff.CLOSE, f + (f2 - f17) / 2.0f, f15 + (f2 - f17) / 2.0f, f17, BaseRenderer.white(0.6f + 0.4f * f16));
            this.hit(f4, f5, f8, f3, this::lmbd$drawSearchBar$0);
            this.hit(f, f15, f2, f2, this::lmbd$drawSearchBar$1);
        } else {
            String string = "CTRL F";
            f = baseRenderer.textWidth(string, this.d(10.0f), 1) + this.d(16.0f);
            float f18 = f4 + f8 - this.d(18.0f) - f;
            baseRenderer.round(f18, f5 + (f3 - this.d(24.0f)) / 2.0f, f, this.d(24.0f), this.d(8.0f), BaseRenderer.white(0.05f * (1.0f - f9)));
            baseRenderer.textCentered(string, f18 + f / 2.0f, f5 + (f3 - this.d(10.0f)) / 2.0f - this.d(0.5f), this.d(10.0f), 1, BaseRenderer.white(0.3f * (1.0f - f9)));
            this.hit(f4, f5, f8, f3, this::lmbd$drawSearchBar$2);
        }
        float f19 = f4 + f8 + f7;
        this.utilityButton(baseRenderer, "profiles", f19, f5, f6, SpeakerOff.FOLDER, "Configs", true, this::lmbd$drawSearchBar$3);
        boolean bl3 = this.host.inWorld();
        this.utilityButton(baseRenderer, "hud", f19 += f6 + f7, f5, f6, SpeakerOff.LAYOUT, bl3 ? "Edit HUD" : "Edit HUD (join a world)", bl3, this::lmbd$drawSearchBar$4);
        this.utilityButton(baseRenderer, "cfg", f19 += f6 + f7, f5, f6, SpeakerOff.GEAR, "Client settings", true, this::lmbd$drawSearchBar$5);
    }

    private void utilityButton(BaseRenderer baseRenderer, String string, float f, float f2, float f3, SpeakerOff speakerOff, String string2, boolean bl, IntSetter mq) {
        boolean bl2 = this.hot(f, f2, f3, f3);
        float f4 = this.an("btn:" + string, bl2 ? 1.0f : 0.0f, 14.0f);
        this.glass(baseRenderer, f, f2, f3, f3, this.d(18.0f), f * 0.01f);
        baseRenderer.round(f, f2, f3, f3, this.d(18.0f), BaseRenderer.white(0.05f * f4));
        baseRenderer.outline(f, f2, f3, f3, this.d(18.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.12f * f4));
        if (f4 > 0.01f) {
            baseRenderer.glow(f + f3 / 2.0f, f2 + f3 / 2.0f, f3 * 0.8f, BaseRenderer.white(0.05f * f4));
        }
        float f5 = this.d(20.0f);
        baseRenderer.icon(speakerOff, f + (f3 - f5) / 2.0f, f2 + (f3 - f5) / 2.0f - this.d(1.0f) * f4, f5, BaseRenderer.white(bl ? 0.7f + 0.3f * f4 : 0.28f));
        if (bl2) {
            this.tip = string2;
            this.tipX = f + f3 / 2.0f;
            this.tipY = f2 - this.d(10.0f);
        }
        if (bl) {
            this.hit(f, f2, f3, f3, mq);
            return;
        } else {
            this.hit(f, f2, f3, f3, GuiDrawer::lmbd$utilityButton$0);
        }
    }

    private void drawTip(BaseRenderer baseRenderer) {
        float f = this.an("tip", 1.0f, 12.0f);
        float f2 = baseRenderer.textWidth(this.tip, this.d(11.5f), 0) + this.d(22.0f);
        float f3 = this.d(28.0f);
        float f4 = Math.min(this.tipX - f2 / 2.0f, this.wx + this.d(1000.0f) - f2);
        float f5 = this.tipY - f3;
        baseRenderer.pushAlpha(f);
        baseRenderer.shadow(f4, f5, f2, f3, this.d(10.0f), this.d(12.0f), BaseRenderer.argb(0.4f, 0, 0, 0));
        baseRenderer.round(f4, f5, f2, f3, this.d(10.0f), BaseRenderer.argb(0.92f, 28, 29, 33));
        baseRenderer.outline(f4, f5, f2, f3, this.d(10.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.1f));
        baseRenderer.textCentered(this.tip, f4 + f2 / 2.0f, f5 + (f3 - this.d(11.5f)) / 2.0f - this.d(1.0f), this.d(11.5f), 0, TEXT);
        baseRenderer.popAlpha();
    }

    @Override
    public void openStorage(ListSetting listSetting) {
        SelectItem selectItem = Items.forSetting(null, listSetting);
        if (listSetting.isColorOnly()) {
            this.openPaletteColor(selectItem.rows().get(0));
            return;
        } else {
            this.selector.open(selectItem);
        }
    }

    private void openPaletteColor(PaletteEntry paletteEntry) {
        this.openColor(new ColorSetting("Color", paletteEntry.palette().color().getRGB()));
        this.paletteColor = paletteEntry.palette();
    }

    private double logicalX(double d) {
        double d2 = (double)this.sw / 2.0 + (double)(this.offX * this.u);
        return d2 + (d - d2) / (double)Math.max(0.2f, this.visualScale);
    }

    private double logicalY(double d) {
        double d2 = (double)this.sh / 2.0 + (double)(this.offY * this.u);
        return d2 + (d - d2) / (double)Math.max(0.2f, this.visualScale);
    }

    private void openColor(ColorSetting colorSetting) {
        this.paletteColor = null;
        this.coloring = colorSetting;
        this.colorDrag = 0;
        int n = colorSetting.getArgb();
        Color.RGBtoHSB(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF, this.hsv);
        this.alphaPick = (float)(n >>> 24) / 255.0f;
        GuiAudio.play(GuiSoundType.OPEN);
    }

    private void closeColor() {
        this.coloring = null;
        this.colorDrag = 0;
        GuiAudio.play(GuiSoundType.BACK);
    }

    private void writeColor() {
        if (this.coloring == null) return;
        int n = Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 0xFFFFFF;
        this.coloring.setArgb(Math.round(Easing.clamp(this.alphaPick, 0.0f, 1.0f) * 255.0f) << 24 | n);
        if (this.paletteColor == null) return;
        this.paletteColor.setColor(new Color(this.coloring.getArgb(), true));
    }

    private void applyColorDrag() {
        if (this.coloring == null || this.colorDrag == 0) return;
        if (this.colorDrag == 1) {
            this.hsv[1] = Easing.clamp((float)((this.mx - (double)this.svRect[0]) / (double)this.svRect[2]), 0.0f, 1.0f);
            this.hsv[2] = 1.0f - Easing.clamp((float)((this.my - (double)this.svRect[1]) / (double)this.svRect[3]), 0.0f, 1.0f);
        } else if (this.colorDrag == 2) {
            this.hsv[0] = Easing.clamp((float)((this.my - (double)this.hueRect[1]) / (double)this.hueRect[3]), 0.0f, 0.999f);
        } else if (this.colorDrag == 3) {
            this.alphaPick = 1.0f - Easing.clamp((float)((this.my - (double)this.alphaRect[1]) / (double)this.alphaRect[3]), 0.0f, 1.0f);
        }
        this.writeColor();
    }

    private static String hex(int n) {
        return n >>> 24 >= 255 ? String.format("#%06X", n & 0xFFFFFF) : String.format("#%08X", n);
    }

    private void checker(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5) {
        baseRenderer.round(f, f2, f3, f4, f5, BaseRenderer.argb(1.0f, 205, 205, 210));
        float f6 = Math.max(2.0f, this.d(5.0f));
        baseRenderer.pushClip(f + f5 * 0.3f, f2 + f5 * 0.3f, f3 - f5 * 0.6f, f4 - f5 * 0.6f);
        for (float f7 = f2; f7 < f2 + f4; f7 += f6) {
            for (float f8 = f; f8 < f + f3; f8 += f6) {
                if (((int)((f8 - f) / f6) + (int)((f7 - f2) / f6)) % 2 != 0) continue;
                baseRenderer.rect(f8, f7, f6, f6, BaseRenderer.argb(1.0f, 150, 150, 158));
            }
        }
        baseRenderer.popClip();
    }

    private void drawColorPicker(BaseRenderer baseRenderer) {
        float f;
        int n;
        float f2;
        float f3 = this.an("colorpicker", this.coloring != null ? 1.0f : 0.0f, 13.0f);
        if (f3 < 0.005f || this.coloring == null && f3 < 0.02f) return;
        ColorSetting colorSetting = this.coloring;
        baseRenderer.pushAlpha(f3);
        float f4 = this.mainX();
        baseRenderer.round(f4, this.wy, this.mainW(), this.mainH(), this.d(22.0f), BaseRenderer.argb(0.45f, 4, 4, 6));
        float f5 = this.d(470.0f);
        float f6 = this.d(284.0f);
        float f7 = f4 + (this.mainW() - f5) / 2.0f;
        float f8 = this.wy + (this.mainH() - f6) / 2.0f;
        float f9 = 0.94f + 0.06f * Easing.out(f3);
        baseRenderer.pushTransform((f7 + f5 / 2.0f) * (1.0f - f9), (f8 + f6 / 2.0f) * (1.0f - f9), f9);
        baseRenderer.shadow(f7, f8, f5, f6, this.d(20.0f), this.d(34.0f), BaseRenderer.argb(0.55f, 0, 0, 0));
        baseRenderer.round(f7, f8, f5, f6, this.d(20.0f), BaseRenderer.argb(0.94f, 24, 25, 29));
        baseRenderer.outline(f7, f8, f5, f6, this.d(20.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.1f));
        String string = colorSetting == null ? "" : colorSetting.getName().toString();
        baseRenderer.text(baseRenderer.ellipsize(string, f5 - this.d(90.0f), this.d(17.0f), 1), f7 + this.d(22.0f), f8 + this.d(20.0f), this.d(17.0f), 1, TEXT);
        float f10 = this.d(30.0f);
        float f11 = f7 + f5 - this.d(18.0f) - f10;
        float f12 = f8 + this.d(16.0f);
        boolean bl = colorSetting != null && this.hot(f11, f12, f10, f10);
        float f13 = this.an("colorpicker:x", bl ? 1.0f : 0.0f, 15.0f);
        baseRenderer.round(f11, f12, f10, f10, f10 / 2.0f, BaseRenderer.white(0.05f + 0.08f * f13));
        float f14 = this.d(14.0f);
        baseRenderer.icon(SpeakerOff.CLOSE, f11 + (f10 - f14) / 2.0f, f12 + (f10 - f14) / 2.0f, f14, BaseRenderer.white(0.6f + 0.4f * f13));
        if (colorSetting != null) {
            this.hit(f7, f8, f5, f6, GuiDrawer::lmbd$drawColorPicker$0);
            this.hit(f11, f12, f10, f10, this::lmbd$drawColorPicker$1);
        }
        float f15 = f7 + this.d(22.0f);
        float f16 = f8 + this.d(62.0f);
        float f17 = this.d(240.0f);
        float f18 = this.d(200.0f);
        this.svRect[0] = f15;
        this.svRect[1] = f16;
        this.svRect[2] = f17;
        this.svRect[3] = f18;
        int n2 = Math.max(24, Math.round(f17 / Math.max(1.0f, this.u * 2.0f)));
        float f19 = f17 / (float)n2;
        for (int i = 0; i < n2; ++i) {
            f2 = ((float)i + 0.5f) / (float)n2;
            int n3 = 0xFF000000 | Color.HSBtoRGB(this.hsv[0], f2, 1.0f) & 0xFFFFFF;
            baseRenderer.gradient(f15 + (float)i * f19, f16, f19 + 1.0f, f18, n3, -16777216);
        }
        baseRenderer.outline(f15, f16, f17, f18, this.d(4.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.14f));
        float f20 = f15 + this.hsv[1] * f17;
        f2 = f16 + (1.0f - this.hsv[2]) * f18;
        baseRenderer.circle(f20, f2, this.d(8.0f), BaseRenderer.argb(0.6f, 0, 0, 0));
        baseRenderer.circle(f20, f2, this.d(7.0f), BaseRenderer.white(1.0f));
        baseRenderer.circle(f20, f2, this.d(5.0f), 0xFF000000 | Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 0xFFFFFF);
        if (colorSetting != null) {
            this.hit(f15, f16, f17, f18, this::lmbd$drawColorPicker$2);
        }
        float f21 = f15 + f17 + this.d(16.0f);
        float f22 = this.d(18.0f);
        this.hueRect[0] = f21;
        this.hueRect[1] = f16;
        this.hueRect[2] = f22;
        this.hueRect[3] = f18;
        for (int i = 0; i < 6; ++i) {
            int n4 = 0xFF000000 | Color.HSBtoRGB((float)i / 6.0f, 1.0f, 1.0f) & 0xFFFFFF;
            n = 0xFF000000 | Color.HSBtoRGB((float)(i + 1) / 6.0f, 1.0f, 1.0f) & 0xFFFFFF;
            baseRenderer.gradient(f21, f16 + f18 * (float)i / 6.0f, f22, f18 / 6.0f + 1.0f, n4, n);
        }
        baseRenderer.outline(f21, f16, f22, f18, this.d(4.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.14f));
        float f23 = f16 + this.hsv[0] * f18;
        baseRenderer.round(f21 - this.d(3.0f), f23 - this.d(3.0f), f22 + this.d(6.0f), this.d(6.0f), this.d(3.0f), BaseRenderer.white(1.0f));
        if (colorSetting != null) {
            this.hit(f21 - this.d(4.0f), f16, f22 + this.d(8.0f), f18, this::lmbd$drawColorPicker$3);
        }
        this.alphaRect[0] = f = f21 + f22 + this.d(14.0f);
        this.alphaRect[1] = f16;
        this.alphaRect[2] = f22;
        this.alphaRect[3] = f18;
        this.checker(baseRenderer, f, f16, f22, f18, this.d(4.0f));
        n = 0xFF000000 | Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 0xFFFFFF;
        baseRenderer.gradient(f, f16, f22, f18, n, n & 0xFFFFFF);
        baseRenderer.outline(f, f16, f22, f18, this.d(4.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.14f));
        float f24 = f16 + (1.0f - this.alphaPick) * f18;
        baseRenderer.round(f - this.d(3.0f), f24 - this.d(3.0f), f22 + this.d(6.0f), this.d(6.0f), this.d(3.0f), BaseRenderer.white(1.0f));
        if (colorSetting != null) {
            this.hit(f - this.d(4.0f), f16, f22 + this.d(8.0f), f18, this::lmbd$drawColorPicker$4);
        }
        float f25 = f + f22 + this.d(20.0f);
        float f26 = f7 + f5 - this.d(22.0f) - f25;
        int n5 = colorSetting != null ? colorSetting.getArgb() : n;
        this.checker(baseRenderer, f25, f16, f26, this.d(54.0f), this.d(12.0f));
        baseRenderer.round(f25, f16, f26, this.d(54.0f), this.d(12.0f), n5);
        baseRenderer.outline(f25, f16, f26, this.d(54.0f), this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.16f));
        baseRenderer.textCentered(GuiDrawer.hex(n5), f25 + f26 / 2.0f, f16 + this.d(66.0f), this.d(12.5f), 1, TEXT);
        baseRenderer.textCentered(Math.round(this.alphaPick * 100.0f) + "% opacity", f25 + f26 / 2.0f, f16 + this.d(86.0f), this.d(11.0f), 0, SUB);
        int[] nArray = new int[]{0xFF000000 | Theme.accent(1.0f) & 0xFFFFFF, -1, -42406, -20898, -8090, -9508952, -10636545, -4809473};
        float f27 = (f26 - this.d(12.0f)) / 4.0f;
        float f28 = this.d(4.0f);
        for (int i = 0; i < nArray.length; ++i) {
            float f29 = f25 + (float)(i % 4) * (f27 + f28);
            float f30 = f16 + this.d(112.0f) + (float)(i / 4) * (f27 + f28);
            boolean bl2 = colorSetting != null && this.hot(f29, f30, f27, f27);
            baseRenderer.round(f29, f30, f27, f27, this.d(8.0f), nArray[i]);
            baseRenderer.outline(f29, f30, f27, f27, this.d(8.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(bl2 ? 0.6f : 0.15f));
            if (colorSetting == null) continue;
            int n6 = nArray[i];
            this.hit(f29, f30, f27, f27, arg_0 -> this.lmbd$drawColorPicker$5(n6, arg_0));
        }
        baseRenderer.popTransform();
        baseRenderer.popAlpha();
    }

    private void openPicker(ItemSetting itemSetting) {
        this.picking = itemSetting;
        this.pickQuery = "";
        this.pickItems = this.host.items();
        this.pickScroll[0] = 0.0f;
        this.pickScroll[1] = 0.0f;
        GuiAudio.play(GuiSoundType.OPEN);
    }

    private void closePicker() {
        this.picking = null;
        GuiAudio.play(GuiSoundType.BACK);
    }

    private void drawPicker(BaseRenderer baseRenderer) {
        float f = this.an("picker", this.picking != null ? 1.0f : 0.0f, 13.0f);
        if (f < 0.005f) return;
        baseRenderer.pushAlpha(f);
        float f2 = this.mainX();
        baseRenderer.round(f2, this.wy, this.mainW(), this.mainH(), this.d(22.0f), BaseRenderer.argb(0.45f, 4, 4, 6));
        float f3 = this.d(560.0f);
        float f4 = this.d(440.0f);
        float f5 = f2 + (this.mainW() - f3) / 2.0f;
        float f6 = this.wy + (this.mainH() - f4) / 2.0f;
        float f7 = 0.94f + 0.06f * Easing.out(f);
        baseRenderer.pushTransform((f5 + f3 / 2.0f) * (1.0f - f7), (f6 + f4 / 2.0f) * (1.0f - f7), f7);
        baseRenderer.shadow(f5, f6, f3, f4, this.d(20.0f), this.d(34.0f), BaseRenderer.argb(0.55f, 0, 0, 0));
        baseRenderer.round(f5, f6, f3, f4, this.d(20.0f), BaseRenderer.argb(0.94f, 24, 25, 29));
        baseRenderer.outline(f5, f6, f3, f4, this.d(20.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.1f));
        baseRenderer.text("Select item", f5 + this.d(22.0f), f6 + this.d(20.0f), this.d(17.0f), 1, TEXT);
        float f8 = this.d(30.0f);
        float f9 = f5 + f3 - this.d(18.0f) - f8;
        float f10 = f6 + this.d(16.0f);
        boolean bl = this.picking != null && this.hot(f9, f10, f8, f8);
        float f11 = this.an("picker:x", bl ? 1.0f : 0.0f, 15.0f);
        baseRenderer.round(f9, f10, f8, f8, f8 / 2.0f, BaseRenderer.white(0.05f + 0.08f * f11));
        float f12 = this.d(14.0f);
        baseRenderer.icon(SpeakerOff.CLOSE, f9 + (f8 - f12) / 2.0f, f10 + (f8 - f12) / 2.0f, f12, BaseRenderer.white(0.6f + 0.4f * f11));
        if (this.picking != null) {
            this.hit(f5, f6, f3, f4, GuiDrawer::lmbd$drawPicker$0);
            this.hit(f9, f10, f8, f8, this::lmbd$drawPicker$1);
        }
        float f13 = f6 + this.d(60.0f);
        this.field(baseRenderer, f5 + this.d(20.0f), f13, f3 - this.d(40.0f), this.d(38.0f), this.pickQuery, "Search items\u2026", true, 1.0f, SpeakerOff.SEARCH);
        float f14 = f5 + this.d(20.0f);
        float f15 = f13 + this.d(52.0f);
        float f16 = f3 - this.d(40.0f);
        float f17 = f6 + f4 - this.d(18.0f) - f15;
        this.pickRect[0] = f14;
        this.pickRect[1] = f15;
        this.pickRect[2] = f16;
        this.pickRect[3] = f17;
        ArrayList arrayList = new ArrayList();
        String string = this.pickQuery.toLowerCase(Locale.ROOT);
        if (this.pickItems != null) {
            for (Object obj : this.pickItems) {
                if (!string.isEmpty() && !this.host.itemName(obj).toLowerCase(Locale.ROOT).contains(string)) continue;
                arrayList.add(obj);
            }
        }
        float f18 = this.d(48.0f);
        float f19 = this.d(8.0f);
        int n = Math.max(1, (int)((f16 + f19) / (f18 + f19)));
        float f20 = (float)n * f18 + (float)(n - 1) * f19;
        float f21 = f14 + (f16 - f20) / 2.0f;
        int n2 = (arrayList.size() + n - 1) / n;
        float f22 = (float)n2 * (f18 + f19) - f19;
        this.pickMax = Math.max(0.0f, f22 - f17);
        float f23 = this.scroll(this.pickScroll, this.pickMax);
        Object object = this.picking != null ? this.host.itemOf(this.picking) : null;
        baseRenderer.pushClip(f14, f15, f16, f17);
        this.hitClip = new float[]{f14, f15, f16, f17};
        String string2 = null;
        for (int i = 0; i < arrayList.size(); ++i) {
            float f24 = f21 + (float)(i % n) * (f18 + f19);
            float f25 = f15 + (float)(i / n) * (f18 + f19) - f23;
            if (f25 + f18 < f15 || f25 > f15 + f17) continue;
            Object e = arrayList.get(i);
            boolean bl2 = this.picking != null && this.hot(f24, f25, f18, f18);
            boolean bl3 = e == object;
            baseRenderer.round(f24, f25, f18, f18, this.d(12.0f), BaseRenderer.white(0.04f + (bl2 ? 0.08f : 0.0f) + (bl3 ? 0.1f : 0.0f)));
            if (bl3) {
                baseRenderer.outline(f24, f25, f18, f18, this.d(12.0f), Math.max(1.0f, this.u * 0.9f), BaseRenderer.white(0.5f));
            }
            float f26 = this.d(30.0f);
            baseRenderer.item(e, f24 + (f18 - f26) / 2.0f, f25 + (f18 - f26) / 2.0f, f26);
            if (bl2) {
                string2 = this.host.itemName(e);
            }
            if (this.picking == null) continue;
            ItemSetting itemSetting = this.picking;
            this.hit(f24, f25, f18, f18, arg_0 -> this.lmbd$drawPicker$2(itemSetting, e, arg_0));
        }
        this.hitClip = null;
        baseRenderer.popClip();
        if (string2 != null) {
            baseRenderer.textRight(string2, f5 + f3 - this.d(22.0f), f6 + this.d(24.0f), this.d(12.0f), 0, SUB);
        }
        baseRenderer.popTransform();
        baseRenderer.popAlpha();
    }

    private void scrollbar(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6) {
        if (!(f5 > 0.5f)) return;
        float f7 = f3 / f6;
        float f8 = Math.max(this.d(30.0f), f3 * f7);
        float f9 = f2 + (f3 - f8) * (f4 / f5);
        baseRenderer.round(f, f9, this.d(4.0f), f8, this.d(2.0f), BaseRenderer.white(0.18f));
    }

    private float scroll(float[] fArray, float f) {
        fArray[1] = Easing.clamp(fArray[1], 0.0f, f);
        fArray[0] = fArray[0] + (fArray[1] - fArray[0]) * (1.0f - (float)Math.exp(-16.0f * this.dt));
        if (!(Math.abs(fArray[1] - fArray[0]) < 0.2f)) return fArray[0];
        fArray[0] = fArray[1];
        return fArray[0];
    }

    private List<String> wrap(BaseRenderer baseRenderer, String string, float f, float f2, int n) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (string == null || string.isBlank()) return arrayList;
        String[] stringArray = string.trim().split("\\s+");
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = 0;
        while (n2 < stringArray.length) {
            String string2;
            String string3 = string2 = stringBuilder.length() == 0 ? stringArray[n2] : String.valueOf(stringBuilder) + " " + stringArray[n2];
            if (!(baseRenderer.textWidth(string2, f2, 0) <= f) && stringBuilder.length() != 0) {
                arrayList.add(stringBuilder.toString());
                stringBuilder.setLength(0);
                if (arrayList.size() != n - 1) continue;
                StringBuilder stringBuilder2 = new StringBuilder();
                for (int i = n2; i < stringArray.length; ++i) {
                    stringBuilder2.append(i == n2 ? "" : " ").append(stringArray[i]);
                }
                arrayList.add(baseRenderer.ellipsize(stringBuilder2.toString(), f, f2, 0));
                return arrayList;
            }
            stringBuilder.setLength(0);
            stringBuilder.append(string2);
            ++n2;
        }
        if (stringBuilder.length() <= 0) return arrayList;
        arrayList.add(baseRenderer.ellipsize(stringBuilder.toString(), f, f2, 0));
        return arrayList;
    }

    private List<Module> modules(Category category) {
        return ModuleLists.category(this, category);
    }

    private List<Module> allModules() {
        try {
            return KryzexClient.INSTANCE.getModuleManager().getAllModules();
        }
        catch (Throwable throwable) {
            return List.of();
        }
    }

    private List<Module> searchResults() {
        return ModuleLists.search(this, this.query);
    }

    private Module clientModule() {
        for (Module module : this.allModules()) {
            if (!(module instanceof KryzexPlus)) continue;
            return module;
        }
        return null;
    }

    private void hit(float f, float f2, float f3, float f4, IntSetter mq) {
        if (this.hitClip != null) {
            float f5 = Math.min(f + f3, this.hitClip[0] + this.hitClip[2]);
            float f6 = Math.min(f2 + f4, this.hitClip[1] + this.hitClip[3]);
            f = Math.max(f, this.hitClip[0]);
            f2 = Math.max(f2, this.hitClip[1]);
            f3 = f5 - f;
            f4 = f6 - f2;
            if (f3 <= 0.0f || f4 <= 0.0f) {
                return;
            }
        }
        this.hits.add(new Layer(f, f2, f3, f4, this.layerNow, mq));
    }

    private int activeLayer() {
        if (this.configs.active()) {
            return 2;
        }
        if (this.picking != null) return 1;
        if (this.coloring != null) return 1;
        return 0;
    }

    private boolean hot(float f, float f2, float f3, float f4) {
        if (this.layerNow < this.activeLayer()) return false;
        if (this.dragging) return false;
        if (this.closing) return false;
        if (this.vis < 0.6f) return false;
        if (this.hitClip != null) {
            if (this.mx < (double)this.hitClip[0]) return false;
            if (this.my < (double)this.hitClip[1]) return false;
            if (this.mx >= (double)(this.hitClip[0] + this.hitClip[2])) return false;
            if (this.my >= (double)(this.hitClip[1] + this.hitClip[3])) return false;
        }
        if (!(this.mx >= (double)f)) return false;
        if (!(this.mx < (double)(f + f3))) return false;
        if (!(this.my >= (double)f2)) return false;
        if (!(this.my < (double)(f2 + f4))) return false;
        return true;
    }

    @Override
    public boolean mouseClicked(double d, double d2, int n) {
        this.rawMx = d;
        this.rawMy = d2;
        d = this.logicalX(d);
        d2 = this.logicalY(d2);
        if (this.selector.active() && this.coloring == null) {
            return this.selector.mouseClicked(d, d2, n);
        }
        if (this.configs.active()) {
            return this.configs.mouseClicked(d, d2, n);
        }
        this.mx = d;
        this.my = d2;
        if (this.closing || this.vis < 0.4f) return true;
        if (this.listening != null) {
            if (n >= 2) {
                this.assignBind(this.listening, this.listeningModule, n);
                return true;
            } else {
                this.listening = null;
            }
            return true;
        }
        this.searchFocus = false;
        this.editing = null;
        int n2 = this.activeLayer();
        for (int i = this.hits.size() - 1; i >= 0; --i) {
            Layer layer = this.hits.get(i);
            if (layer.layer() != n2 || !(d >= (double)layer.x()) || !(d < (double)(layer.x() + layer.w())) || !(d2 >= (double)layer.y()) || !(d2 < (double)(layer.y() + layer.h()))) continue;
            layer.act().on(n);
            return true;
        }
        if (n2 == 1) {
            if (this.coloring != null) {
                this.closeColor();
                return true;
            } else {
                this.closePicker();
            }
            return true;
        } else {
            if (n != 3 || this.page == null) return true;
            this.closePage();
        }
        return true;
    }

    @Override
    public void mouseReleased(double d, double d2, int n) {
        this.rawMx = d;
        this.rawMy = d2;
        d = this.logicalX(d);
        d2 = this.logicalY(d2);
        this.mx = d;
        this.my = d2;
        if (this.dragging) {
            this.dragging = false;
            this.savePosition();
        }
        if (this.sliding != null) {
            this.applySlide();
            this.sliding = null;
        }
        this.colorDrag = 0;
    }

    @Override
    public void mouseDragged(double d, double d2) {
        this.rawMx = d;
        this.rawMy = d2;
        d = this.logicalX(d);
        d2 = this.logicalY(d2);
        this.mx = d;
        this.my = d2;
        this.applySlide();
        this.applyColorDrag();
    }

    @Override
    public void mouseScrolled(double d, double d2, double d3) {
        d = this.logicalX(d);
        d2 = this.logicalY(d2);
        if (this.selector.active() && this.coloring == null) {
            this.selector.scroll(d, d2, d3);
            return;
        } else {
            if (this.configs.active()) return;
            float f = this.d(70.0f) * (float)d3;
            if (this.picking != null) {
                if (!GuiDrawer.inside(d, d2, this.pickRect)) return;
                this.pickScroll[1] = Easing.clamp(this.pickScroll[1] - f, 0.0f, this.pickMax);
                return;
            } else if (this.page != null) {
                if (!GuiDrawer.inside(d, d2, this.pageRect)) return;
                this.pageScroll[1] = Easing.clamp(this.pageScroll[1] - f, 0.0f, this.pageMax);
                return;
            } else {
                if (!GuiDrawer.inside(d, d2, this.gridRect)) return;
                this.gridScroll[1] = Easing.clamp(this.gridScroll[1] - f, 0.0f, this.gridMax);
            }
        }
    }

    private static boolean inside(double d, double d2, float[] fArray) {
        if (!(d >= (double)fArray[0])) return false;
        if (!(d2 >= (double)fArray[1])) return false;
        if (!(d < (double)(fArray[0] + fArray[2]))) return false;
        if (!(d2 < (double)(fArray[1] + fArray[3]))) return false;
        return true;
    }

    @Override
    public boolean keyPressed(int n, int n2) {
        boolean bl;
        if (this.closing) {
            return true;
        }
        if (this.selector.active() && this.coloring == null) {
            return this.selector.keyPressed(n, n2);
        }
        if (this.configs.active()) {
            return this.configs.keyPressed(n, n2);
        }
        boolean bl2 = bl = (n2 & 2) != 0;
        if (this.coloring != null) {
            if (n != 256 && n != 257 && n != 335) return true;
            this.closeColor();
            return true;
        }
        if (this.listening != null) {
            if (n == 256) {
                this.listening = null;
                return true;
            } else if (n != 259 && n != 261) {
                this.assignBind(this.listening, this.listeningModule, n);
                return true;
            } else {
                this.assignBind(this.listening, this.listeningModule, -1);
            }
            return true;
        }
        if (this.picking != null) {
            if (n == 256) {
                this.closePicker();
                return true;
            } else {
                if (n != 259 || this.pickQuery.isEmpty()) return true;
                this.pickQuery = bl ? "" : this.pickQuery.substring(0, this.pickQuery.length() - 1);
                this.pickScroll[1] = 0.0f;
            }
            return true;
        }
        if (this.editing != null) {
            String string;
            String string2 = string = this.editing.getValue() == null ? "" : this.editing.getValue();
            if (n == 256 || n == 257 || n == 335) {
                this.editing = null;
                return true;
            } else {
                if (n != 259 || string.isEmpty()) return true;
                this.editing.setValue(bl ? "" : string.substring(0, string.length() - 1));
                this.caretT = 0.0f;
            }
            return true;
        }
        if (this.searchFocus) {
            if (n == 256) {
                if (this.query.isEmpty()) {
                    this.searchFocus = false;
                    return true;
                } else {
                    this.query = "";
                    this.tabT = 0.0f;
                }
                return true;
            } else if (n == 257 || n == 335) {
                this.searchFocus = false;
                return true;
            } else {
                if (n != 259 || this.query.isEmpty()) return true;
                this.query = bl ? "" : this.query.substring(0, this.query.length() - 1);
                this.gridScroll[1] = 0.0f;
                if (!this.query.isEmpty()) return true;
                this.tabT = 0.0f;
            }
            return true;
        }
        if (!(bl && n == 70 || n == 47)) {
            if (n != 256) return false;
            if (this.page != null) {
                this.closePage();
                return true;
            } else if (!this.query.isEmpty()) {
                this.query = "";
                this.tabT = 0.0f;
                return true;
            } else {
                this.requestClose();
            }
            return true;
        }
        this.searchFocus = true;
        this.page = null;
        this.caretT = 0.0f;
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (this.selector.active() && this.coloring == null) {
            return this.selector.charTyped(c);
        }
        if (this.configs.active()) {
            return this.configs.charTyped(c);
        }
        if (Character.isISOControl(c) || this.closing) {
            return false;
        }
        if (this.picking != null) {
            if (this.pickQuery.length() >= 32) return true;
            this.pickQuery = this.pickQuery + c;
            this.pickScroll[1] = 0.0f;
            return true;
        }
        if (this.editing != null) {
            String string;
            String string2 = string = this.editing.getValue() == null ? "" : this.editing.getValue();
            if (string.length() >= 256) return true;
            this.editing.setValue(string + c);
            this.caretT = 0.0f;
            return true;
        }
        if (!this.searchFocus) return false;
        if (this.query.length() >= 40) return true;
        boolean bl = this.query.isEmpty();
        this.query = this.query + c;
        this.page = null;
        this.gridScroll[1] = 0.0f;
        this.caretT = 0.0f;
        if (!bl) return true;
        this.tabT = 0.0f;
        return true;
    }

    private void startDrag() {
        this.dragging = true;
        this.grabX = this.rawMx;
        this.grabY = this.rawMy;
        this.dragStartX = this.offX;
        this.dragStartY = this.offY;
    }

    private void clampPosition() {
        float f = Math.max(0.0f, ((float)this.sw / this.u - 1000.0f * this.visualScale) / 2.0f - 8.0f);
        float f2 = Math.max(0.0f, ((float)this.sh / this.u - 624.0f * this.visualScale) / 2.0f - 8.0f);
        this.offX = Easing.clamp(this.offX, -f, f);
        this.offY = Easing.clamp(this.offY, -f2, f2);
    }

    private void loadPosition() {
        if (this.posLoaded) return;
        this.posLoaded = true;
        try {
            Path path = this.host.stateFile();
            if (path == null || !Files.isRegularFile(path, new LinkOption[0])) return;
            String[] stringArray = Files.readString(path, StandardCharsets.UTF_8).trim().split(",");
            this.offX = Float.parseFloat(stringArray[0]);
            this.offY = Float.parseFloat(stringArray[1]);
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private void savePosition() {
        try {
            Path path = this.host.stateFile();
            if (path == null) return;
            Files.createDirectories(path.getParent(), new FileAttribute[0]);
            Files.writeString(path, (CharSequence)String.format(Locale.ROOT, "%.2f,%.2f", Float.valueOf(this.offX), Float.valueOf(this.offY)), StandardCharsets.UTF_8, new OpenOption[0]);
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private void lmbd$drawPicker$2(ItemSetting itemSetting, Object object, int n) {
        this.host.setItem(itemSetting, object);
        this.picking = null;
        GuiAudio.play(GuiSoundType.CONFIRM);
    }

    private void lmbd$drawPicker$1(int n) {
        this.closePicker();
    }

    private static void lmbd$drawPicker$0(int n) {
    }

    private void lmbd$drawColorPicker$5(int n, int n2) {
        Color.RGBtoHSB(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF, this.hsv);
        this.writeColor();
        GuiAudio.play(GuiSoundType.TICK);
    }

    private void lmbd$drawColorPicker$4(int n) {
        this.colorDrag = 3;
        this.applyColorDrag();
    }

    private void lmbd$drawColorPicker$3(int n) {
        this.colorDrag = 2;
        this.applyColorDrag();
    }

    private void lmbd$drawColorPicker$2(int n) {
        this.colorDrag = 1;
        this.applyColorDrag();
    }

    private void lmbd$drawColorPicker$1(int n) {
        this.closeColor();
    }

    private static void lmbd$drawColorPicker$0(int n) {
    }

    private static void lmbd$utilityButton$0(int n) {
    }

    private void lmbd$drawSearchBar$5(int n) {
        Module module = this.clientModule();
        if (module == null) return;
        this.query = "";
        this.searchFocus = false;
        this.openPage(module);
    }

    private void lmbd$drawSearchBar$4(int n) {
        this.host.openHudEditor();
    }

    private void lmbd$drawSearchBar$3(int n) {
        this.searchFocus = false;
        this.editing = null;
        this.listening = null;
        this.sliding = null;
        this.configs.open();
    }

    private void lmbd$drawSearchBar$2(int n) {
        this.searchFocus = true;
        this.caretT = 0.0f;
    }

    private void lmbd$drawSearchBar$1(int n) {
        this.query = "";
        this.tabT = 0.0f;
    }

    private void lmbd$drawSearchBar$0(int n) {
        this.searchFocus = true;
        this.caretT = 0.0f;
    }

    private void lmbd$drawRow$13(ListSetting listSetting, int n) {
        this.host.openStorage(listSetting);
    }

    private void lmbd$drawRow$12(ItemSetting itemSetting, int n) {
        this.openPicker(itemSetting);
    }

    private void lmbd$drawRow$11(StringSetting stringSetting, int n) {
        this.editing = stringSetting;
        this.caretT = 0.0f;
    }

    private void lmbd$drawRow$10(KeybindSetting keybindSetting, Module module, int n) {
        if (n == 1) {
            this.assignBind(keybindSetting, module, -1);
            return;
        } else {
            this.listening = keybindSetting;
            this.listeningModule = module;
            GuiAudio.play(GuiSoundType.TICK);
        }
    }

    private void lmbd$drawRow$9(ColorSetting colorSetting, int n) {
        this.openColor(colorSetting);
    }

    private void lmbd$drawRow$8(String string, ActionSetting actionSetting, int n) {
        this.anims.put(string, new float[]{1.0f});
        GuiAudio.play(GuiSoundType.CONFIRM);
        actionSetting.run();
    }

    private static void lmbd$drawRow$7(ModeSetting modeSetting, int n) {
        if (n == 1) {
            modeSetting.cycleDown();
        } else {
            modeSetting.cycleUp();
        }
        GuiAudio.play(GuiSoundType.TICK);
    }

    private static void lmbd$drawRow$6(ModeSetting modeSetting, int n) {
        if (n == 1) {
            modeSetting.cycleUp();
        } else {
            modeSetting.cycleDown();
        }
        GuiAudio.play(GuiSoundType.TICK);
    }

    private static void lmbd$drawRow$5(CycleSetting cycleSetting, int n) {
        if (n == 1) {
            cycleSetting.cycleDown();
        } else {
            cycleSetting.cycleUp();
        }
        GuiAudio.play(GuiSoundType.TICK);
    }

    private static void lmbd$drawRow$4(CycleSetting cycleSetting, int n) {
        if (n == 1) {
            cycleSetting.cycleUp();
        } else {
            cycleSetting.cycleDown();
        }
        GuiAudio.play(GuiSoundType.TICK);
    }

    private void lmbd$drawRow$3(RangeSetting rangeSetting, float f, float f2, int n) {
        float[] fArray = this.tracks.get(rangeSetting);
        float f3 = fArray == null ? 0.0f : (float)((this.mx - (double)fArray[0]) / (double)fArray[1]);
        this.beginSlide(rangeSetting, Math.abs(f3 - f) <= Math.abs(f3 - f2) && !(f3 > f2) ? 0 : 1);
    }

    private void lmbd$drawRow$2(NumberSetting numberSetting, int n) {
        this.beginSlide(numberSetting, 0);
    }

    private static void lmbd$drawRow$1(BoolSetting boolSetting, int n) {
        boolSetting.toggle();
        GuiAudio.play(boolSetting.getValue() ? GuiSoundType.ON : GuiSoundType.OFF);
    }

    private void lmbd$drawRow$0(Setting setting, SelectItem selectItem, int n) {
        ListSetting listSetting;
        if (setting instanceof ListSetting && (listSetting = (ListSetting)setting).isColorOnly()) {
            this.openPaletteColor(selectItem.rows().get(0));
            return;
        } else {
            this.selector.open(selectItem);
        }
    }

    private static void lmbd$drawThemes$0(int n, int n2) {
        if (KryzexPlus.theme.getModeIndex() == n) return;
        KryzexPlus.theme.setModeIndex(n);
        GuiAudio.play(GuiSoundType.THEME);
    }

    private void lmbd$drawSettingsPage$2(Module module, int n) {
        this.toggleModule(module);
    }

    private void lmbd$drawSettingsPage$1(int n) {
        this.closePage();
    }

    private void lmbd$drawSettingsPage$0(int n) {
        this.startDrag();
    }

    private void lmbd$drawCard$1(Module module, int n) {
        this.openPage(module);
    }

    private void lmbd$drawCard$0(Module module, int n) {
        if (n == 1) {
            this.openPage(module);
            return;
        } else {
            if (n != 0) return;
            this.toggleModule(module);
        }
    }

    private void lmbd$header$0(int n) {
        this.startDrag();
    }

    private void lmbd$drawSidebar$2(int n) {
        this.openStyleSettings();
        GuiAudio.play(GuiSoundType.OPEN);
    }

    private void lmbd$drawSidebar$1(Category category, int n) {
        this.selectTab(category);
    }

    private void lmbd$drawSidebar$0(int n) {
        this.startDrag();
    }

    private static float[] lmbd$an$0(float f, String string) {
        return new float[]{f};
    }
}
