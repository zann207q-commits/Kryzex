package kryzex.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import kryzex.gui.BaseRenderer;
import kryzex.gui.ClickRegion;
import kryzex.gui.Easing;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiSoundType;
import kryzex.gui.PaletteEntry;
import kryzex.gui.SelectItem;
import kryzex.gui.SpeakerOff;
import kryzex.gui.Theme;

public final class ModulePanel {
    private final List<ClickRegion> hits = new ArrayList<ClickRegion>();
    private final Map<PaletteEntry, float[]> animations = new HashMap<PaletteEntry, float[]>();
    private final Consumer<PaletteEntry> color;
    private SelectItem binding;
    private List<PaletteEntry> filtered = List.of();
    private String query = "";
    private boolean opened;
    private boolean selectedOnly;
    private float progress;
    private float scroll;
    private float targetScroll;
    private float maxScroll;
    private float unit;
    private float time;
    private float delta;
    private double mouseX;
    private double mouseY;
    private final Map<String, Float> buttonHover = new HashMap<String, Float>();
    private float x;
    private float y;
    private float w;
    private float h;
    private float gridY;
    private float gridH;

    public ModulePanel(Consumer<PaletteEntry> consumer) {
        this.color = consumer;
    }

    public void open(SelectItem selectItem) {
        this.binding = selectItem;
        this.query = "";
        this.selectedOnly = false;
        this.opened = true;
        this.targetScroll = 0.0f;
        this.scroll = 0.0f;
        this.animations.clear();
        this.filter();
        GuiAudio.play(GuiSoundType.OPEN);
    }

    public void close() {
        this.opened = false;
        GuiAudio.play(GuiSoundType.BACK);
    }

    public void reset() {
        this.opened = false;
        this.progress = 0.0f;
        this.binding = null;
        this.hits.clear();
        this.animations.clear();
    }

    public boolean active() {
        if (this.opened) return true;
        if (!(this.progress > 0.005f)) return false;
        return true;
    }

    public float visibility() {
        return this.progress;
    }

    private float d(float f) {
        return f * this.unit;
    }

    private void filter() {
        this.filtered = this.binding.rows().stream().filter(this::lmbd$filter$0).toList();
        this.targetScroll = 0.0f;
    }

    private boolean inside(double d, double d2, float f, float f2, float f3, float f4) {
        if (!(d >= (double)f)) return false;
        if (!(d2 >= (double)f2)) return false;
        if (!(d < (double)(f + f3))) return false;
        if (!(d2 < (double)(f2 + f4))) return false;
        return true;
    }

    private void button(BaseRenderer baseRenderer, String string, float f, float f2, float f3, Runnable runnable) {
        float f4 = this.buttonHover.getOrDefault(string, Float.valueOf(0.0f)).floatValue();
        f4 += ((this.inside(this.mouseX, this.mouseY, f, f2, f3, this.d(32.0f)) ? 1.0f : 0.0f) - f4) * (1.0f - (float)Math.exp(-13.0f * this.delta));
        this.buttonHover.put(string, Float.valueOf(f4));
        baseRenderer.round(f, f2, f3, this.d(32.0f), this.d(12.0f), BaseRenderer.white(0.045f + 0.035f * f4));
        baseRenderer.outline(f, f2, f3, this.d(32.0f), this.d(12.0f), Math.max(1.0f, this.d(0.9f)), BaseRenderer.white(0.075f + 0.07f * f4));
        baseRenderer.textCentered(string, f + f3 / 2.0f, f2 + this.d(8.0f), this.d(12.0f), 0, BaseRenderer.white(0.9f));
        this.hits.add(new ClickRegion(f, f2, f3, this.d(32.0f), null, runnable));
    }

    private void glass(BaseRenderer baseRenderer) {
        float f = this.d(22.0f);
        baseRenderer.shadow(this.x, this.y, this.w, this.h, f, this.d(30.0f), BaseRenderer.argb(0.42f, 0, 0, 0));
        baseRenderer.round(this.x, this.y, this.w, this.h, f, Theme.glass(0.6f));
        baseRenderer.roundGradient(this.x, this.y, this.w, Math.min(this.h, Math.max(this.h * 0.5f, this.d(150.0f))), f, BaseRenderer.white(0.05f), BaseRenderer.white(0.0f));
        baseRenderer.pushClip(this.x, this.y, this.w, this.h);
        float f2 = Math.min(this.w, this.h) * 0.5f;
        float f3 = this.x + f2 + (this.w - 2.0f * f2) * (0.5f + 0.5f * (float)Math.sin(this.time * 0.09f + 4.1f));
        float f4 = this.y + f2 + (this.h - 2.0f * f2) * (0.35f + 0.35f * (float)Math.cos(this.time * 0.07f + 5.33f));
        baseRenderer.popClip();
        baseRenderer.outline(this.x, this.y, this.w, this.h, f, Math.max(1.0f, this.d(0.9f)), BaseRenderer.white(0.085f));
        baseRenderer.rect(this.x + f, this.y + Math.max(1.0f, this.unit), this.w - 2.0f * f, Math.max(1.0f, this.d(0.8f)), BaseRenderer.white(0.05f));
    }

    public void render(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6, double d, double d2) {
        this.progress += ((float)(this.opened ? 1 : 0) - this.progress) * (1.0f - (float)Math.exp(-16.0f * f6));
        if (!this.active() || this.binding == null) {
            return;
        }
        this.unit = f5;
        this.x = f;
        this.y = f2;
        this.w = f3;
        this.h = f4;
        this.delta = f6;
        this.time += f6;
        this.mouseX = d;
        this.mouseY = d2;
        this.hits.clear();
        baseRenderer.pushAlpha(this.progress);
        baseRenderer.pushTransform(0.0f, this.d(9.0f) * (1.0f - this.progress), 1.0f);
        this.glass(baseRenderer);
        baseRenderer.round(f + this.d(22.0f), f2 + this.d(18.0f), this.d(44.0f), this.d(44.0f), this.d(14.0f), BaseRenderer.white(0.07f));
        baseRenderer.outline(f + this.d(22.0f), f2 + this.d(18.0f), this.d(44.0f), this.d(44.0f), this.d(14.0f), Math.max(1.0f, this.d(0.9f)), BaseRenderer.white(0.09f));
        baseRenderer.icon(SpeakerOff.BOX, f + this.d(33.5f), f2 + this.d(29.5f), this.d(21.0f), BaseRenderer.white(0.96f));
        baseRenderer.text("Blocks & items", f + this.d(82.0f), f2 + this.d(19.0f), this.d(21.0f), 1, BaseRenderer.white(0.96f));
        baseRenderer.text(baseRenderer.ellipsize(this.binding.title(), f3 - this.d(220.0f), this.d(12.0f), 0), f + this.d(83.0f), f2 + this.d(45.0f), this.d(12.0f), 0, BaseRenderer.white(0.56f));
        baseRenderer.rect(f + this.d(20.0f), f2 + this.d(78.0f), f3 - this.d(40.0f), Math.max(1.0f, f5), BaseRenderer.white(0.055f));
        this.button(baseRenderer, "Done", f + f3 - this.d(102.0f), f2 + this.d(24.0f), this.d(77.0f), this::close);
        float f7 = f2 + this.d(92.0f);
        float f8 = f3 - this.d(205.0f);
        baseRenderer.round(f + this.d(25.0f), f7, f8, this.d(41.0f), this.d(13.0f), BaseRenderer.white(0.045f));
        baseRenderer.outline(f + this.d(25.0f), f7, f8, this.d(41.0f), this.d(13.0f), this.d(0.9f), BaseRenderer.white(0.105f));
        baseRenderer.icon(SpeakerOff.SEARCH, f + this.d(39.0f), f7 + this.d(12.0f), this.d(17.0f), BaseRenderer.white(0.5f));
        baseRenderer.text(this.query.isEmpty() ? "Search by name\u2026" : this.query, f + this.d(66.0f), f7 + this.d(12.0f), this.d(12.5f), 0, BaseRenderer.white(this.query.isEmpty() ? 0.38f : 0.9f));
        this.button(baseRenderer, this.selectedOnly ? "Show all" : "Selected", f + f3 - this.d(151.0f), f7 + this.d(4.0f), this.d(126.0f), this::lmbd$render$0);
        this.gridY = f7 + this.d(58.0f);
        this.gridH = f4 - this.d(213.0f);
        int n = 4;
        float f9 = this.d(12.0f);
        float f10 = (f3 - this.d(50.0f) - f9 * (float)(n - 1)) / (float)n;
        float f11 = this.d(84.0f);
        this.maxScroll = Math.max(0.0f, (float)((this.filtered.size() + n - 1) / n) * (f11 + f9) - f9 - this.gridH);
        this.targetScroll = Math.max(0.0f, Math.min(this.targetScroll, this.maxScroll));
        this.scroll += (this.targetScroll - this.scroll) * (1.0f - (float)Math.exp(-20.0f * f6));
        baseRenderer.pushClip(f + this.d(23.0f), this.gridY, f3 - this.d(46.0f), this.gridH);
        int n2 = Math.max(0, (int)(this.scroll / (f11 + f9)) * n);
        int n3 = Math.min(this.filtered.size(), n2 + n * ((int)(this.gridH / (f11 + f9)) + 2));
        for (int i = n2; i < n3; ++i) {
            PaletteEntry paletteEntry = this.filtered.get(i);
            float f12 = f + this.d(25.0f) + (float)(i % n) * (f10 + f9);
            float f13 = this.gridY + (float)(i / n) * (f11 + f9) - this.scroll;
            boolean bl = this.binding.selected().test(paletteEntry);
            boolean bl2 = this.inside(d, d2, f12, f13, f10, f11);
            float[] fArray = this.animations.computeIfAbsent(paletteEntry, ModulePanel::lmbd$render$1);
            float f14 = 1.0f - (float)Math.exp(-18.0f * f6);
            fArray[0] = fArray[0] + ((float)(bl2 ? 1 : 0) - fArray[0]) * f14;
            fArray[1] = fArray[1] + ((float)(bl ? 1 : 0) - fArray[1]) * f14;
            baseRenderer.round(f12, f13, f10, f11, this.d(18.0f), BaseRenderer.white(0.035f + 0.03f * fArray[0]));
            if (fArray[1] > 0.01f) {
                baseRenderer.round(f12, f13, f10, f11, this.d(18.0f), Easing.mix(BaseRenderer.white(0.035f * fArray[1]), Theme.accent(0.05f * fArray[1]), 0.6f));
            }
            if (fArray[0] > 0.01f) {
                baseRenderer.pushClip(f12, f13, f10, f11);
                baseRenderer.glow(Easing.clamp((float)d, f12, f12 + f10), f13 + f11 * 0.15f, f10 * 0.45f, BaseRenderer.white(0.045f * fArray[0]));
                baseRenderer.popClip();
            }
            baseRenderer.outline(f12, f13, f10, f11, this.d(18.0f), Math.max(1.0f, this.d(0.9f)), Easing.mix(BaseRenderer.white(0.06f + 0.08f * fArray[0] + 0.06f * fArray[1]), Theme.accent(0.06f + 0.08f * fArray[0] + 0.1f * fArray[1]), 0.5f * fArray[1]));
            baseRenderer.item(paletteEntry.item(), f12 + (f10 - this.d(27.0f)) / 2.0f, f13 + this.d(12.0f), this.d(27.0f));
            if (paletteEntry.item() == null) {
                baseRenderer.icon(SpeakerOff.BOX, f12 + (f10 - this.d(21.0f)) / 2.0f, f13 + this.d(14.0f), this.d(21.0f), BaseRenderer.white(0.4f));
            }
            baseRenderer.textCentered(baseRenderer.ellipsize(paletteEntry.name(), f10 - this.d(15.0f), this.d(12.0f), 0), f12 + f10 / 2.0f, f13 + this.d(55.0f), this.d(12.0f), 0, BaseRenderer.white(0.84f));
            if (fArray[1] > 0.02f) {
                baseRenderer.icon(SpeakerOff.CHECK, f12 + f10 - this.d(21.0f), f13 + this.d(8.0f), this.d(12.0f), Theme.accent(fArray[1]));
            }
            if (paletteEntry.palette() != null) {
                baseRenderer.circle(f12 + this.d(12.0f), f13 + this.d(13.0f), this.d(3.0f), paletteEntry.palette().color().getRGB());
            }
            if (!this.opened || !(f13 + f11 > this.gridY) || !(f13 < this.gridY + this.gridH)) continue;
            this.hits.add(new ClickRegion(f12, Math.max(f13, this.gridY), f10, Math.min(f13 + f11, this.gridY + this.gridH) - Math.max(f13, this.gridY), paletteEntry, null));
        }
        baseRenderer.popClip();
        if (this.maxScroll > 0.0f) {
            float f15 = Math.max(this.d(30.0f), this.gridH * this.gridH / (this.maxScroll + this.gridH));
            float f16 = this.gridY + (this.gridH - f15) * this.scroll / this.maxScroll;
            baseRenderer.round(f + f3 - this.d(16.0f), f16, this.d(3.0f), f15, this.d(1.5f), BaseRenderer.white(0.18f));
        }
        if (this.filtered.isEmpty()) {
            baseRenderer.textCentered("No items found", f + f3 / 2.0f, this.gridY + this.gridH / 2.0f, this.d(13.0f), 0, BaseRenderer.white(0.4f));
        }
        baseRenderer.text(this.binding.count() + " selected" + (this.binding.rows().stream().anyMatch(ModulePanel::lmbd$render$2) ? "  \u00b7  Right-click to change color" : ""), f + this.d(26.0f), f2 + f4 - this.d(39.0f), this.d(11.0f), 0, BaseRenderer.white(0.48f));
        this.button(baseRenderer, "Clear", f + f3 - this.d(102.0f), f2 + f4 - this.d(48.0f), this.d(77.0f), this::lmbd$render$3);
        baseRenderer.popTransform();
        baseRenderer.popAlpha();
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (!this.opened) {
            return this.active();
        }
        for (int i = this.hits.size() - 1; i >= 0; --i) {
            ClickRegion clickRegion = this.hits.get(i);
            if (!this.inside(d, d2, clickRegion.x(), clickRegion.y(), clickRegion.w(), clickRegion.h())) continue;
            if (clickRegion.row() != null) {
                if (n == 1 && clickRegion.row().palette() != null) {
                    this.color.accept(clickRegion.row());
                    return true;
                }
                if (n != 0) return true;
                this.binding.choose().accept(clickRegion.row());
                GuiAudio.play(GuiSoundType.CONFIRM);
                if (!this.binding.multiple()) {
                    this.close();
                    return true;
                } else {
                    if (!this.selectedOnly) return true;
                    this.filter();
                }
                return true;
            } else {
                if (n != 0) return true;
                clickRegion.action().run();
            }
            return true;
        }
        return true;
    }

    public void scroll(double d, double d2, double d3) {
        if (!this.opened || !this.inside(d, d2, this.x, this.gridY, this.w, this.gridH)) return;
        this.targetScroll = Math.max(0.0f, Math.min(this.maxScroll, this.targetScroll - this.d(80.0f) * (float)d3));
    }

    public boolean keyPressed(int n, int n2) {
        if (n == 256 || n == 257) {
            this.close();
            return true;
        }
        if (n != 259 || this.query.isEmpty()) return true;
        this.query = (n2 & 2) != 0 ? "" : this.query.substring(0, this.query.length() - 1);
        this.filter();
        return true;
    }

    public boolean charTyped(char c) {
        if (Character.isISOControl(c) || this.query.length() >= 64) return true;
        this.query = this.query + c;
        this.filter();
        return true;
    }

    private void lmbd$render$3() {
        this.binding.clear().run();
        if (!this.selectedOnly) return;
        this.filter();
    }

    private static boolean lmbd$render$2(PaletteEntry paletteEntry) {
        if (paletteEntry.palette() == null) return false;
        return true;
    }

    private static float[] lmbd$render$1(PaletteEntry paletteEntry) {
        return new float[2];
    }

    private void lmbd$render$0() {
        this.selectedOnly = !this.selectedOnly;
        this.filter();
    }

    private boolean lmbd$filter$0(PaletteEntry paletteEntry) {
        if (this.selectedOnly) {
            if (!this.binding.selected().test(paletteEntry)) return false;
        }
        if (!paletteEntry.search().contains(this.query.trim().toLowerCase(Locale.ROOT))) return false;
        return true;
    }
}
