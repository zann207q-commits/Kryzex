package kryzex.gui;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import kryzex.gui.Action2;
import kryzex.gui.ClipBottom;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiSoundType;
import kryzex.gui.Insampler;
import kryzex.gui.LastSource;
import kryzex.gui.NameCache;
import kryzex.gui.PixelUnit;
import kryzex.gui.Presence3;
import kryzex.gui.DropdownFont;
import kryzex.gui.SpeakerOff;
import kryzex.gui.SquareCorners;
import kryzex.gui.Theme;
import kryzex.modules.client.KryzexPlus;
import net.minecraft.class_11786;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import net.minecraft.class_9296;

public final class FriendsMenu {
    private static final float PANEL_W = 640.0f;
    private static final float PANEL_H = 500.0f;
    private static final float PAD = 26.0f;
    private static final float CARD_H = 60.0f;
    private static final float CARD_GAP = 10.0f;
    private static final float HEAD = 40.0f;
    private static final int GREEN = -9508960;
    private static final int RED = -34166;
    private static DropdownFont atlas;
    private static Insampler BACKDROP;
    private final SquareCorners p = new SquareCorners();
    private final NameCache friends;
    private final Runnable closer;
    private final Map<String, Float> anim = new HashMap<String, Float>();
    private final Map<String, Presence3> cards = new LinkedHashMap<String, Presence3>();
    private final Map<String, Supplier<class_11786.class_11787>> skins = new HashMap<String, Supplier<class_11786.class_11787>>();
    private final List<Action2> hits = new ArrayList<Action2>();
    private final List<ClipBottom> heads = new ArrayList<ClipBottom>();
    private String entry = "";
    private String search = "";
    private String message = "";
    private boolean messageBad;
    private float messageT;
    private int focus;
    private int caret;
    private boolean selectAll;
    private float scroll;
    private float scrollTarget;
    private float maxScroll;
    private String reveal;
    private float k = 1.0f;
    private float sw;
    private float sh;
    private float mx;
    private float my;
    private float dt;
    private float time;
    private long last;
    private float open;
    private boolean closing;
    private float listTop;
    private float listBottom;
    private String hovered = "";

    public FriendsMenu(NameCache nameCache, Runnable runnable) {
        this.friends = nameCache;
        this.closer = runnable;
        for (String string : nameCache.names()) {
            Presence3 presence3 = new Presence3();
            presence3.presence = 1.0f;
            this.cards.put(string.toLowerCase(Locale.ROOT), presence3);
        }
    }

    public void render(class_332 class_3322, int n, int n2, double d, double d2) {
        long l = System.nanoTime();
        this.dt = this.last == 0L ? 0.016f : Math.min(0.05f, (float)(l - this.last) / 1.0E9f);
        this.last = l;
        this.time += this.dt;
        this.messageT += this.dt;
        this.k = Math.max(0.45f, Math.min((float)n / 1500.0f, (float)n2 / 820.0f));
        this.sw = (float)n / this.k;
        this.sh = (float)n2 / this.k;
        this.mx = (float)(d / (double)this.k);
        this.my = (float)(d2 / (double)this.k);
        this.open = this.approach(this.open, this.closing ? 0.0f : 1.0f, this.closing ? 16.0f : 11.0f);
        if (this.closing && this.open < 0.02f) {
            this.closer.run();
            return;
        }
        LastSource.accent(Theme.accent(1.0f) | 0xFF000000);
        FriendsMenu.ensureAtlas(this.k);
        GpuTextureView gpuTextureView = BACKDROP.capture();
        this.hits.clear();
        this.heads.clear();
        float f = FriendsMenu.ease(this.open);
        this.p.begin(atlas, this.k, 1.0f);
        this.p.alpha(f);
        this.p.rect(0.0f, 0.0f, this.sw, this.sh, 0x6A000000);
        float f2 = 0.955f + 0.045f * f;
        float f3 = this.sw / 2.0f;
        float f4 = this.sh / 2.0f;
        this.p.transform(f3 * this.k - f3 * this.k * f2, f4 * this.k - f4 * this.k * f2 + (1.0f - f) * 14.0f * this.k, this.k * f2);
        float f5 = f3 - 320.0f;
        float f6 = f4 - 250.0f;
        float f7 = f5 + 640.0f;
        float f8 = f6 + 500.0f;
        this.p.shadow(f5, f6 + 10.0f, f7, f8 + 10.0f, 18.0f, 34.0f, -2013265920);
        this.p.glass(f5, f6, f7, f8, 16.0f, -771225592);
        this.p.gradient(f5, f6, f7, f6 + 120.0f, 16.0f, LastSource.withAlpha(LastSource.ACCENT, 0.13f), LastSource.withAlpha(LastSource.ACCENT, 0.06f), 0, 0);
        this.header(f5, f6, f7);
        this.p.rect(f5 + 26.0f, f6 + 84.0f, f7 - 26.0f, f6 + 84.0f + this.p.pixel(), 0x10FFFFFF);
        this.addRow(f5, f6 + 100.0f, f7);
        this.listHeader(f5, f6 + 182.0f, f7);
        this.list(f5, f6 + 222.0f, f7, f8 - 50.0f);
        this.p.rect(f5 + 26.0f, f8 - 46.0f, f7 - 26.0f, f8 - 46.0f + this.p.pixel(), 0x10FFFFFF);
        this.p.icon("heart", f5 + 26.0f + 7.0f, f8 - 23.0f, LastSource.ACCENT, 0.85f);
        this.p.smallText("Friends are skipped by Kill Aura, Trigger Bot and Auto Crystal.", f5 + 26.0f + 22.0f, f8 - 23.0f, LastSource.withAlpha(-3553071, 0.7f), 0.78f);
        this.dotted(new String[]{"Enter add", "Esc close"}, f7 - 26.0f, f8 - 23.0f, LastSource.withAlpha(-3553071, 0.45f), 0.74f, true);
        this.p.alpha(1.0f);
        this.p.submit(class_3322, gpuTextureView, BACKDROP.sampler());
        this.drawHeads(class_3322, f);
    }

    private void header(float f, float f2, float f3) {
        float f4 = 44.0f;
        float f5 = f + 26.0f;
        float f6 = f2 + 20.0f;
        this.p.shadow(f5, f6 + 3.0f, f5 + f4, f6 + f4 + 3.0f, 12.0f, 12.0f, LastSource.GLOW);
        this.p.gradient(f5, f6, f5 + f4, f6 + f4, 12.0f, LastSource.mix(LastSource.ACCENT, -1, 0.18f), LastSource.ACCENT, LastSource.mix(LastSource.ACCENT, -16777216, 0.25f), LastSource.ACCENT);
        this.p.icon("user", f5 + f4 / 2.0f, f6 + f4 / 2.0f, -15461348, 1.35f);
        this.p.useTitleFont();
        this.p.text("Friends", f5 + f4 + 16.0f, f6 + 13.0f, -723976);
        this.p.useBodyFont();
        int n = this.friends.names().size();
        int n2 = LastSource.withAlpha(-3553071, 0.72f);
        if (n == 0) {
            this.p.smallText("Nobody yet. Add your first friend below.", f5 + f4 + 16.0f, f6 + 33.0f, n2, 0.82f);
        } else {
            this.dotted(new String[]{n + (n == 1 ? " friend" : " friends"), this.online() + " online"}, f5 + f4 + 16.0f, f6 + 33.0f, n2, 0.82f, false);
        }
        float f7 = 34.0f;
        float f8 = f3 - 26.0f - f7;
        float f9 = f2 + 25.0f;
        float f10 = this.hover("close", f8, f9, f8 + f7, f9 + f7);
        this.p.roundRect(f8, f9, f8 + f7, f9 + f7, 10.0f, LastSource.mix(0xFFFFFFF, LastSource.withAlpha(-34166, 0.22f), f10));
        this.p.stroke(f8, f9, f8 + f7, f9 + f7, 10.0f, this.p.pixel(), LastSource.mix(0x14FFFFFF, LastSource.withAlpha(-34166, 0.5f), f10));
        this.p.icon("close", f8 + f7 / 2.0f, f9 + f7 / 2.0f, LastSource.mix(-3553071, -1, f10), 0.95f);
        this.hits.add(new Action2(f8, f9, f8 + f7, f9 + f7, this::close));
    }

    private void dotted(String[] stringArray, float f, float f2, int n, float f3, boolean bl) {
        float f4 = 16.0f;
        float f5 = 0.0f;
        for (int i = 0; i < stringArray.length; ++i) {
            f5 += this.p.smallWidth(stringArray[i], f3) + (i > 0 ? f4 : 0.0f);
        }
        float f6 = bl ? f - f5 : f;
        for (int i = 0; i < stringArray.length; ++i) {
            if (i > 0) {
                this.p.circle(f6 + f4 / 2.0f, f2, 1.6f, n);
                f6 += f4;
            }
            this.p.smallText(stringArray[i], f6, f2, n, f3);
            f6 += this.p.smallWidth(stringArray[i], f3);
        }
    }

    private int online() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.method_1562() == null) {
            return 0;
        }
        int n = 0;
        for (String string : this.friends.names()) {
            if (class_3102.method_1562().method_2874(string) == null) continue;
            ++n;
        }
        return n;
    }

    private void addRow(float f, float f2, float f3) {
        float f4;
        int n;
        float f5 = 118.0f;
        float f6 = f3 - 26.0f - f5 - 12.0f;
        this.field(f + 26.0f, f2, f6, f2 + 46.0f, 0, this.entry, "Add a player by name", "plus");
        float f7 = f6 + 12.0f;
        float f8 = f3 - 26.0f;
        boolean bl = NameCache.valid(this.entry);
        float f9 = this.hover("add", f7, f2, f8, f2 + 46.0f);
        float f10 = f9 * 1.5f;
        int n2 = n = bl ? LastSource.mix(LastSource.ACCENT, -1, 0.12f * f9) : 0x22FFFFFF;
        if (bl) {
            this.p.shadow(f7, f2 + 4.0f - f10, f8, f2 + 46.0f + 4.0f - f10, 11.0f, 14.0f, LastSource.withAlpha(LastSource.GLOW, 0.6f + 0.4f * f9));
        }
        this.p.gradient(f7, f2 - f10, f8, f2 + 46.0f - f10, 11.0f, LastSource.mix(n, -1, bl ? 0.14f : 0.0f), n, LastSource.mix(n, -16777216, bl ? 0.16f : 0.0f), n);
        int n3 = bl ? -15461348 : LastSource.withAlpha(-3553071, 0.55f);
        float f11 = this.p.textWidth("Add") + 20.0f;
        float f12 = (f7 + f8) / 2.0f - f11 / 2.0f;
        this.p.icon("plus", f12 + 7.0f, f2 + 23.0f - f10, n3, 0.9f);
        this.p.text("Add", f12 + 20.0f, f2 + 23.0f - f10, n3);
        this.hits.add(new Action2(f7, f2, f8, f2 + 46.0f, this::add));
        float f13 = f4 = this.message.isEmpty() ? 0.0f : Math.min(1.0f, this.messageT * 6.0f) * (1.0f - FriendsMenu.smooth((this.messageT - 3.2f) / 0.6f));
        if (!(f4 > 0.01f)) return;
        int n4 = this.messageBad ? -34166 : -9508960;
        this.p.circle(f + 26.0f + 6.0f, f2 + 62.0f, 3.2f, 3.0f, LastSource.withAlpha(n4, f4));
        this.p.smallText(this.message, f + 26.0f + 16.0f, f2 + 62.0f, LastSource.withAlpha(LastSource.mix(n4, -1, 0.25f), f4), 0.82f);
    }

    private void field(float f, float f2, float f3, float f4, int n, String string, String string2, String string3) {
        boolean bl = this.focus == n;
        float f5 = this.anim("focus" + n, bl ? 1.0f : 0.0f, 14.0f);
        float f6 = this.hover("field" + n, f, f2, f3, f4);
        float f7 = 11.0f;
        if (f5 > 0.01f) {
            this.p.shadow(f, f2, f3, f4, f7, 10.0f, LastSource.withAlpha(LastSource.GLOW, 0.8f * f5));
        }
        this.p.roundRect(f, f2, f3, f4, f7, LastSource.mix(0x52000000, 0x66000000, f6 * 0.6f));
        this.p.stroke(f, f2, f3, f4, f7, Math.max(this.p.pixel(), 1.2f * f5), LastSource.mix(LastSource.mix(0x16FFFFFF, 0x26FFFFFF, f6), LastSource.withAlpha(LastSource.ACCENT, 0.85f), f5));
        float f8 = (f2 + f4) / 2.0f;
        this.p.icon(string3, f + 20.0f, f8, LastSource.mix(LastSource.withAlpha(-3553071, 0.55f), LastSource.ACCENT, f5), 0.9f);
        float f9 = f + 38.0f;
        float f10 = f3 - f9 - 14.0f;
        if (string.isEmpty()) {
            this.p.text(string2, f9, f8, -7368810, f10);
        } else {
            String string4 = string;
            int n2 = 0;
            while (this.p.textWidth(string4) > f10 && n2 < string.length() - 1) {
                string4 = string.substring(++n2);
            }
            if (bl && this.selectAll) {
                this.p.roundRect(f9 - 2.0f, f8 - 11.0f, f9 + this.p.textWidth(string4) + 2.0f, f8 + 11.0f, 4.0f, LastSource.withAlpha(LastSource.ACCENT, 0.35f));
            }
            this.p.text(string4, f9, f8, -723976);
            if (bl && this.time % 1.05f < 0.6f && !this.selectAll) {
                int n3 = Math.max(0, Math.min(string.length(), this.caret) - n2);
                float f11 = f9 + this.p.textWidth(string4.substring(0, Math.min(string4.length(), n3))) + 1.0f;
                this.p.roundRect(f11, f8 - 10.0f, f11 + 1.6f, f8 + 10.0f, 0.8f, LastSource.ACCENT);
            }
        }
        if (string.isEmpty() && bl && this.time % 1.05f < 0.6f) {
            this.p.roundRect(f9, f8 - 10.0f, f9 + 1.6f, f8 + 10.0f, 0.8f, LastSource.ACCENT);
        }
        this.hits.add(new Action2(f, f2, f3, f4, () -> this.lmbd$field$0(n)));
    }

    private void listHeader(float f, float f2, float f3) {
        this.p.smallText("YOUR FRIENDS", f + 26.0f, f2 + 18.0f, LastSource.withAlpha(-3553071, 0.6f), 0.74f);
        String string = String.valueOf(this.friends.names().size());
        float f4 = this.p.smallWidth("YOUR FRIENDS", 0.74f);
        float f5 = this.p.smallWidth(string, 0.72f) + 14.0f;
        this.p.roundRect(f + 26.0f + f4 + 8.0f, f2 + 10.0f, f + 26.0f + f4 + 8.0f + f5, f2 + 26.0f, 8.0f, LastSource.withAlpha(LastSource.ACCENT, 0.22f));
        this.p.smallText(string, f + 26.0f + f4 + 15.0f, f2 + 18.0f, LastSource.ACCENT, 0.72f);
        this.field(f3 - 26.0f - 230.0f, f2, f3 - 26.0f, f2 + 36.0f, 1, this.search, "Search friends", "search");
    }

    private void list(float f, float f2, float f3, float f4) {
        float f5;
        float f6;
        this.listTop = f2;
        this.listBottom = f4;
        String string = this.search.toLowerCase(Locale.ROOT);
        List<String> list = this.friends.names();
        for (Presence3 iterator : this.cards.values()) {
            iterator.alive = false;
        }
        ArrayList arrayList = new ArrayList();
        for (String string2 : list) {
            String string3 = string2.toLowerCase(Locale.ROOT);
            Presence3 presence3 = this.cards.computeIfAbsent(string3, FriendsMenu::lmbd$list$0);
            presence3.name = string2;
            presence3.alive = true;
            presence3.match = string3.contains(string);
            arrayList.add(string3);
        }
        for (Map.Entry<String, Presence3> entry : this.cards.entrySet()) {
            if (entry.getValue().alive || arrayList.contains(entry.getKey())) continue;
            arrayList.add(Math.min(arrayList.size(), entry.getValue().index), entry.getKey());
        }
        int n = 2;
        float f7 = 10.0f;
        float f8 = (f3 - f - 52.0f - f7) / (float)n;
        int n2 = 0;
        ArrayList<String> arrayList2 = new ArrayList<String>();
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            String string4 = (String)iterator.next();
            Presence3 presence3 = this.cards.get(string4);
            float f9 = presence3.alive && presence3.match ? 1.0f : 0.0f;
            presence3.presence = FriendsMenu.approachTo(presence3.presence, f9, f9 > presence3.presence ? 10.0f : 14.0f, this.dt);
            if (!presence3.alive && presence3.presence < 0.01f) {
                arrayList2.add(string4);
                continue;
            }
            if (presence3.presence < 0.01f) continue;
            int n3 = n2 % n;
            int n4 = n2 / n;
            f6 = (float)n4 * (60.0f + f7);
            presence3.y = Float.isNaN(presence3.y) ? f6 : presence3.y + (f6 - presence3.y) * (1.0f - (float)Math.exp(-14.0f * this.dt));
            presence3.x = Float.isNaN(presence3.x) ? (float)n3 : presence3.x + ((float)n3 - presence3.x) * (1.0f - (float)Math.exp(-14.0f * this.dt));
            presence3.index = n2;
            if (string4.equals(this.reveal)) {
                f5 = f4 - f2;
                this.scrollTarget = Math.max(Math.min(this.scrollTarget, f6), f6 + 60.0f - f5);
                this.reveal = null;
            }
            if (!presence3.alive || !presence3.match) continue;
            ++n2;
        }
        arrayList2.forEach(this.cards::remove);
        int n5 = (n2 + n - 1) / n;
        float f10 = (float)n5 * (60.0f + f7) - f7;
        this.maxScroll = Math.max(0.0f, f10 - (f4 - f2));
        this.scrollTarget = Math.max(0.0f, Math.min(this.maxScroll, this.scrollTarget));
        this.scroll += (this.scrollTarget - this.scroll) * (1.0f - (float)Math.exp(-16.0f * this.dt));
        int n6 = this.p.clipState();
        this.p.clip(f2, f4 + 2.0f);
        this.hovered = "";
        if (n2 == 0) {
            this.empty(f, f2, f3, f4, string.isEmpty());
        }
        Iterator iterator2 = arrayList.iterator();
        while (iterator2.hasNext()) {
            String string5 = (String)iterator2.next();
            Presence3 presence3 = this.cards.get(string5);
            if (presence3 == null || presence3.presence < 0.01f || Float.isNaN(presence3.y)) continue;
            f6 = f + 26.0f + presence3.x * (f8 + f7);
            f5 = f2 + presence3.y - this.scroll;
            if (f5 > f4 + 4.0f || f5 + 60.0f < f2 - 4.0f) continue;
            this.card(presence3, f6, f5, f6 + f8, f5 + 60.0f);
        }
        this.p.restoreClip(n6);
        if (this.scroll > 0.5f) {
            this.p.gradient(f + 4.0f, f2 - 2.0f, f3 - 4.0f, f2 + 16.0f, 0.0f, 0x50000000, 0x50000000, 0, 0);
        }
        if (this.scroll < this.maxScroll - 0.5f) {
            this.p.gradient(f + 4.0f, f4 - 18.0f, f3 - 4.0f, f4 + 2.0f, 0.0f, 0, 0, 0x50000000, 0x50000000);
        }
        if (!(this.maxScroll > 0.5f)) return;
        float f11 = f4 - f2;
        float f12 = Math.max(30.0f, f11 * f11 / (f10 + 1.0f));
        float f13 = f2 + (f11 - f12) * (this.scroll / this.maxScroll);
        f6 = f3 - 13.0f - 2.0f;
        this.p.roundRect(f6, f2, f6 + 3.0f, f4, 1.5f, 0x10FFFFFF);
        this.p.roundRect(f6, f13, f6 + 3.0f, f13 + f12, 1.5f, LastSource.withAlpha(LastSource.ACCENT, 0.7f));
    }

    private void empty(float f, float f2, float f3, float f4, boolean bl) {
        float f5 = (f + f3) / 2.0f;
        float f6 = (f2 + f4) / 2.0f - 14.0f;
        float f7 = 0.5f + 0.5f * (float)Math.sin(this.time * 2.0f);
        this.p.circle(f5, f6 - 18.0f, 30.0f, 10.0f + 4.0f * f7, LastSource.withAlpha(LastSource.ACCENT, 0.12f));
        this.p.icon(bl ? "user" : "search", f5, f6 - 18.0f, LastSource.withAlpha(LastSource.ACCENT, 0.9f), 1.6f);
        String string = bl ? "No friends yet" : "No matching friends";
        String string2 = bl ? "Type a name above and press Enter." : "Try another name.";
        this.p.text(string, f5 - this.p.textWidth(string) / 2.0f, f6 + 30.0f, -723976);
        this.p.smallText(string2, f5 - this.p.smallWidth(string2, 0.82f) / 2.0f, f6 + 54.0f, LastSource.withAlpha(-3553071, 0.65f), 0.82f);
    }

    private void card(Presence3 presence3, float f, float f2, float f3, float f4) {
        float f5 = FriendsMenu.ease(presence3.presence);
        float f6 = (1.0f - f5) * 8.0f;
        f += f6;
        boolean bl = this.my >= this.listTop && this.my <= this.listBottom;
        float f7 = this.anim("card:" + presence3.name, bl && presence3.alive && this.inside(f, f2 += f6 * 0.5f, f3 -= f6, f4 -= f6 * 0.5f) ? 1.0f : 0.0f, 14.0f);
        if (f7 > 0.5f) {
            this.hovered = presence3.name;
        }
        float f8 = f7 * 2.0f;
        f2 -= f8;
        f4 -= f8;
        float f9 = this.p.alpha();
        this.p.alpha(f9 * f5);
        boolean bl2 = FriendsMenu.isOnline(presence3.name);
        if (f7 > 0.01f) {
            this.p.shadow(f, f2 + 4.0f, f3, f4 + 4.0f, 12.0f, 16.0f, LastSource.withAlpha(LastSource.GLOW, 0.55f * f7));
        }
        this.p.roundRect(f, f2, f3, f4, 12.0f, LastSource.mix(0x1AFFFFFF, 0x26FFFFFF, f7));
        this.p.stroke(f, f2, f3, f4, 12.0f, this.p.pixel(), LastSource.mix(0x14FFFFFF, LastSource.withAlpha(LastSource.ACCENT, 0.75f), f7));
        float f10 = f + 12.0f;
        float f11 = (f2 + f4) / 2.0f - 20.0f;
        this.p.shadow(f10, f11 + 2.0f, f10 + 40.0f, f11 + 40.0f + 2.0f, 8.0f, 6.0f, 0x66000000);
        this.p.roundRect(f10 - 2.0f, f11 - 2.0f, f10 + 40.0f + 2.0f, f11 + 40.0f + 2.0f, 9.0f, LastSource.mix(0x22FFFFFF, LastSource.withAlpha(LastSource.ACCENT, 0.6f), f7));
        this.heads.add(new ClipBottom(presence3.name, this.p.X(f10), this.p.Y(f11), this.p.X(f10 + 40.0f) - this.p.X(f10), this.p.alpha(), this.p.Y(this.listTop), this.p.Y(this.listBottom + 2.0f)));
        float f12 = f10 + 40.0f - 2.0f;
        float f13 = f11 + 40.0f - 2.0f;
        this.p.circle(f12, f13, 6.0f, -15330020);
        this.p.circle(f12, f13, 4.2f, bl2 ? 3.0f : 0.0f, bl2 ? -9508960 : -9737354);
        float f14 = f10 + 40.0f + 14.0f;
        float f15 = 34.0f;
        this.p.text(presence3.name, f14, (f2 + f4) / 2.0f - 9.0f, LastSource.mix(-723976, -1, f7), f3 - f14 - f15 - 16.0f);
        this.p.smallText(bl2 ? "Online now" : "Offline", f14, (f2 + f4) / 2.0f + 12.0f, bl2 ? LastSource.withAlpha(-9508960, 0.9f) : LastSource.withAlpha(-3553071, 0.55f), 0.78f);
        float f16 = f3 - 12.0f;
        float f17 = f16 - f15;
        float f18 = (f2 + f4) / 2.0f - f15 / 2.0f;
        float f19 = this.hover("remove:" + presence3.name, f17, f18, f16, f18 + f15);
        float f20 = Math.max(f7, f19);
        if (f20 > 0.01f) {
            this.p.alpha(f9 * f5 * f20);
            this.p.roundRect(f17, f18, f16, f18 + f15, 10.0f, LastSource.mix(0x14FFFFFF, LastSource.withAlpha(-34166, 0.28f), f19));
            this.p.icon("trash", (f17 + f16) / 2.0f, f18 + f15 / 2.0f, LastSource.mix(-3553071, -34166, f19), 0.9f);
        }
        this.p.alpha(f9);
        if (!presence3.alive || !bl) return;
        String string = presence3.name;
        this.hits.add(new Action2(f17, f18, f16, f18 + f15, () -> this.lmbd$card$0(string)));
    }

    private static boolean isOnline(String string) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.method_1562() == null) return false;
        if (class_3102.method_1562().method_2874(string) == null) return false;
        return true;
    }

    private class_8685 skin(String string) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.method_1562() != null) {
            net.minecraft.class_640 class_6402 = class_3102.method_1562().method_2874(string);
            if (class_6402 != null) {
                return class_6402.method_52810();
            }
        }
        try {
            Supplier<class_11786.class_11787> supplier = this.skins.computeIfAbsent(string.toLowerCase(Locale.ROOT), arg_0 -> FriendsMenu.lmbd$skin$0(class_3102, string, arg_0));
            return supplier.get().method_73503();
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private void drawHeads(class_332 class_3322, float f) {
        if (this.heads.isEmpty()) {
            return;
        }
        class_3322.method_71048();
        for (ClipBottom clipBottom : this.heads) {
            class_8685 class_86852 = this.skin(clipBottom.name());
            if (class_86852 == null) continue;
            int n = Math.max(4, Math.round(clipBottom.size()));
            int n2 = Math.round(clipBottom.x());
            int n3 = Math.round(clipBottom.y());
            int n4 = Math.round(255.0f * Math.max(0.0f, Math.min(1.0f, clipBottom.alpha())));
            if (n4 < 3 || (float)(n3 + n) < clipBottom.clipTop() || (float)n3 > clipBottom.clipBottom()) continue;
            class_3322.method_44379(0, Math.round(clipBottom.clipTop()), Short.MAX_VALUE, Math.round(clipBottom.clipBottom()));
            class_7532.method_44443((class_332)class_3322, (class_8685)class_86852, (int)n2, (int)n3, (int)n, (int)(n4 << 24 | 0xFFFFFF));
            class_3322.method_44380();
        }
    }

    public boolean click(double d, double d2, int n) {
        if (n != 0 || this.closing) {
            return true;
        }
        float f = (float)(d / (double)this.k);
        float f2 = (float)(d2 / (double)this.k);
        for (int i = this.hits.size() - 1; i >= 0; --i) {
            Action2 action2 = this.hits.get(i);
            if (!(f >= action2.x0()) || !(f < action2.x1()) || !(f2 >= action2.y0()) || !(f2 < action2.y1())) continue;
            action2.action().run();
            return true;
        }
        return true;
    }

    public void scroll(double d) {
        this.scrollTarget = Math.max(0.0f, Math.min(this.maxScroll, this.scrollTarget - (float)d * 46.0f));
    }

    public void close() {
        if (this.closing) return;
        this.closing = true;
        GuiAudio.play(GuiSoundType.BACK);
    }

    private void add() {
        String string = this.entry.trim();
        String string2 = this.friends.add(string);
        this.messageT = 0.0f;
        if (string2.isEmpty()) {
            this.message = "Added " + string + ".";
            this.messageBad = false;
            this.entry = "";
            this.caret = 0;
            this.cards.remove(string.toLowerCase(Locale.ROOT));
            GuiAudio.play(GuiSoundType.CONFIRM);
            this.reveal = string.toLowerCase(Locale.ROOT);
        } else {
            this.message = string2;
            this.messageBad = true;
            GuiAudio.play(GuiSoundType.TICK);
        }
        this.focus = 0;
        this.selectAll = false;
    }

    private void remove(String string) {
        this.friends.remove(string);
        this.message = "Removed " + string + ".";
        this.messageBad = false;
        this.messageT = 0.0f;
        GuiAudio.play(GuiSoundType.TICK);
    }

    private String value() {
        return this.focus == 0 ? this.entry : this.search;
    }

    private void value(String string) {
        if (this.focus == 0) {
            this.entry = string;
            return;
        } else {
            this.search = string;
            this.scrollTarget = 0.0f;
        }
    }

    public void insert(String string) {
        int n;
        String string2 = string.replaceAll("[\\p{Cntrl}]", "");
        if (this.focus == 0) {
            string2 = string2.replaceAll("[^A-Za-z0-9_]", "");
        }
        String string3 = this.value();
        if (this.selectAll) {
            string3 = "";
            this.caret = 0;
            this.selectAll = false;
        }
        if ((n = (this.focus == 0 ? 16 : 32) - string3.length()) <= 0 || string2.isEmpty()) return;
        string2 = string2.substring(0, Math.min(string2.length(), n));
        this.caret = Math.max(0, Math.min(this.caret, string3.length()));
        this.value(string3.substring(0, this.caret) + string2 + string3.substring(this.caret));
        this.caret += string2.length();
    }

    public void key(int n, boolean bl) {
        String string = this.value();
        if (n == 256) {
            this.close();
            return;
        } else if (n == 258) {
            this.focus = 1 - this.focus;
            this.caret = this.value().length();
            this.selectAll = false;
            return;
        } else if (n == 257 || n == 335) {
            if (this.focus != 0) return;
            this.add();
            return;
        } else if (bl && n == 65) {
            this.selectAll = true;
            this.caret = string.length();
            return;
        } else if (n == 259 || n == 261) {
            if (this.selectAll) {
                this.value("");
                this.caret = 0;
                this.selectAll = false;
                return;
            } else if (n == 259 && this.caret > 0) {
                if (bl) {
                    this.value(string.substring(this.caret));
                    this.caret = 0;
                    return;
                } else {
                    this.value(string.substring(0, this.caret - 1) + string.substring(this.caret));
                    --this.caret;
                }
                return;
            } else {
                if (n != 261 || this.caret >= string.length()) return;
                this.value(string.substring(0, this.caret) + string.substring(this.caret + 1));
            }
            return;
        } else if (n == 263) {
            this.caret = Math.max(0, this.caret - 1);
            this.selectAll = false;
            return;
        } else if (n == 262) {
            this.caret = Math.min(string.length(), this.caret + 1);
            this.selectAll = false;
            return;
        } else if (n == 268) {
            this.caret = 0;
            this.selectAll = false;
            return;
        } else {
            if (n != 269) return;
            this.caret = string.length();
            this.selectAll = false;
        }
    }

    private boolean inside(float f, float f2, float f3, float f4) {
        if (!(this.mx >= f)) return false;
        if (!(this.mx < f3)) return false;
        if (!(this.my >= f2)) return false;
        if (!(this.my < f4)) return false;
        return true;
    }

    private float hover(String string, float f, float f2, float f3, float f4) {
        boolean bl = !this.closing && this.inside(f, f2, f3, f4);
        float f5 = this.anim(string, bl ? 1.0f : 0.0f, 16.0f);
        if (bl && this.anim.getOrDefault(string + "#was", Float.valueOf(0.0f)).floatValue() < 0.5f) {
            GuiAudio.play(GuiSoundType.TICK);
        }
        this.anim.put(string + "#was", Float.valueOf(bl ? 1.0f : 0.0f));
        return f5;
    }

    private float anim(String string, float f, float f2) {
        float f3 = this.anim.getOrDefault(string, Float.valueOf(f)).floatValue();
        f3 = FriendsMenu.approachTo(f3, f, f2, this.dt);
        this.anim.put(string, Float.valueOf(f3));
        return f3;
    }

    private float approach(float f, float f2, float f3) {
        return FriendsMenu.approachTo(f, f2, f3, this.dt);
    }

    private static float approachTo(float f, float f2, float f3, float f4) {
        return Math.abs(f2 - (f += (f2 - f) * (1.0f - (float)Math.exp(-f3 * f4)))) < 0.002f ? f2 : f;
    }

    private static float ease(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        float f2 = 1.0f - f;
        return 1.0f - f2 * f2 * f2;
    }

    private static float smooth(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * (3.0f - 2.0f * f);
    }

    private static void ensureAtlas(float f) {
        int n;
        try {
            n = KryzexPlus.dropdownFont.getModeIndex();
        }
        catch (Throwable throwable) {
            n = 2;
        }
        int n2 = Math.max(8, Math.round(29.166666f * f));
        int n3 = Math.max(1, Math.round(11.9f * f / 7.0f));
        int n4 = Math.max(8, Math.round(13.0f * f));
        PixelUnit pixelUnit = new PixelUnit(n2, n3, n4, n);
        if (atlas != null && FriendsMenu.atlas.spec.equals(pixelUnit)) return;
        if (atlas != null) {
            atlas.close();
        }
        LinkedHashMap<String, int[]> linkedHashMap = new LinkedHashMap<String, int[]>();
        linkedHashMap.put("user", SpeakerOff.USER.tex((int)n4).argb);
        linkedHashMap.put("search", SpeakerOff.SEARCH.tex((int)n4).argb);
        linkedHashMap.put("trash", SpeakerOff.TRASH.tex((int)n4).argb);
        linkedHashMap.put("close", SpeakerOff.CLOSE.tex((int)n4).argb);
        linkedHashMap.put("plus", SpeakerOff.PLUS.tex((int)n4).argb);
        linkedHashMap.put("heart", SpeakerOff.HEART.tex((int)n4).argb);
        atlas = DropdownFont.create(pixelUnit, linkedHashMap);
    }

    private static Supplier lmbd$skin$0(class_310 class_3102, String string, String string2) {
        return class_3102.method_73362().method_74050(class_9296.method_74889((String)string));
    }

    private void lmbd$card$0(String string) {
        this.remove(string);
    }

    private static Presence3 lmbd$list$0(String string) {
        return new Presence3();
    }

    private void lmbd$field$0(int n) {
        this.focus = n;
        this.caret = (n == 0 ? this.entry : this.search).length();
        this.selectAll = false;
    }

    static {
        BACKDROP = new Insampler();
    }
}
