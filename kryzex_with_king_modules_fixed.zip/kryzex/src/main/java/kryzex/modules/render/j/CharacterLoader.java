package kryzex.modules.render.j;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import kryzex.modules.render.j.Character3D;
import kryzex.modules.render.j.HeadMaterials;
import kryzex.modules.render.j.Height;
import kryzex.modules.render.j.Legs;
import kryzex.modules.render.j.Limbs;
import kryzex.modules.render.j.Source2;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
final class CharacterLoader {
    private static Logger LOGGER;
    private static final long MAX_FILE = 0x10000000L;
    private static final int MAX_TEXTURE = 8192;
    private CharacterLoader() {
    }

    static Path e() {
        return FabricLoader.getInstance().getConfigDir().resolve("kryzex").resolve("characters");
    }

    private static Path k() {
        return CharacterLoader.e().resolve(".baked");
    }

    static List<Source2> T() {
        DirectoryStream<Path> stream;
        ArrayList<Path> arrayList = new ArrayList<Path>();
        try {
            stream = Files.newDirectoryStream(CharacterLoader.e(), "*.{glb,GLB}");
            try {
                for (Path object : stream) {
                    if (!Files.isRegularFile(object, new LinkOption[0])) continue;
                    arrayList.add(object);
                }
            }
            finally {
                if (stream != null) {
                    stream.close();
                }
            }
        }
        catch (IOException iOException) {
            return List.of();
        }
        arrayList.sort(null);
        ArrayList<Source2> sourceList = new ArrayList<Source2>();
        HashSet hashSet = new HashSet();
        for (Path path : arrayList) {
            String string = path.getFileName().toString();
            string = string.substring(0, string.length() - 4);
            try {
                String iOException = string + Files.size(path) + Files.getLastModifiedTime(path, new LinkOption[0]).toMillis() + "3";
                String string2 = "custom_" + CharacterLoader.L(string) + "_" + Integer.toHexString(iOException.hashCode());
                hashSet.add(string2);
                sourceList.add(new Source2(string2, string, () -> CharacterLoader.lmbd$scan$0(path, string2)));
            }
            catch (IOException iOException) {
                LOGGER.warn("[Kryzex] Skipping custom character {}: {}", (Object)path, (Object)iOException.toString());
            }
        }
        CharacterLoader.r(hashSet);
        return sourceList;
    }

    private static String L(String string) {
        String string2 = string.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
        return string2.isEmpty() ? "model" : (string2.length() > 32 ? string2.substring(0, 32) : string2);
    }

    private static void r(Set<String> set) {
        try {
            try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(CharacterLoader.k(), "*.anc");){
                for (Path path : directoryStream) {
                    String string = path.getFileName().toString().replace(".anc", "");
                    if (set.contains(string)) continue;
                    Files.deleteIfExists(path);
                }
                return;
            }
        }
        catch (IOException iOException) {

        }
    }

    private static synchronized InputStream G(Path path, String string) throws IOException {
        Path path2 = CharacterLoader.k().resolve(string + ".anc");
        if (Files.exists(path2, new LinkOption[0])) {
            return Files.newInputStream(path2, new OpenOption[0]);
        }
        if (Files.size(path) > 0x10000000L) {
            throw new IOException("the file is larger than 256 MB");
        }
        String string2 = path.getFileName().toString();
        Character3D.s(string2);
        long l = System.nanoTime();
        Limbs limbs = Legs.d(Files.readAllBytes(path), new HeadMaterials(), CharacterLoader::s);
        LOGGER.info("[Kryzex] Baked custom character {} in {} ms, moving {}", string2, (System.nanoTime() - l) / 1000000L, limbs.limbs());
        if (limbs.limbs().size() < 3) {
            Character3D.Q(string2, limbs.limbs());
        }
        Files.createDirectories(CharacterLoader.k(), new FileAttribute[0]);
        Path path3 = CharacterLoader.k().resolve(string + ".tmp");
        Files.write(path3, limbs.data(), new OpenOption[0]);
        Files.move(path3, path2, StandardCopyOption.REPLACE_EXISTING);
        return new ByteArrayInputStream(limbs.data());
    }

    private static Height s(byte[] byArray) throws IOException {
        ByteBuffer byteBuffer = MemoryUtil.memAlloc((int)byArray.length);
        try (MemoryStack memoryStack = MemoryStack.stackPush();){
            byteBuffer.put(byArray).flip();
            IntBuffer intBuffer = memoryStack.mallocInt(1);
            IntBuffer intBuffer2 = memoryStack.mallocInt(1);
            IntBuffer intBuffer3 = memoryStack.mallocInt(1);
            ByteBuffer byteBuffer2 = STBImage.stbi_load_from_memory((ByteBuffer)byteBuffer, (IntBuffer)intBuffer, (IntBuffer)intBuffer2, (IntBuffer)intBuffer3, 4);
            if (byteBuffer2 == null) {
                throw new IOException("a texture can't be read: " + STBImage.stbi_failure_reason());
            }
            try {
                int n = intBuffer.get(0);
                int n2 = intBuffer2.get(0);
                if (n > 8192 || n2 > 8192) {
                    throw new IOException("a texture is over 8192 px");
                }
                int[] nArray = new int[n * n2];
                for (int i = 0; i < nArray.length; ++i) {
                    int n3 = byteBuffer2.get(i * 4) & 0xFF;
                    int n4 = byteBuffer2.get(i * 4 + 1) & 0xFF;
                    int n5 = byteBuffer2.get(i * 4 + 2) & 0xFF;
                    int n6 = byteBuffer2.get(i * 4 + 3) & 0xFF;
                    nArray[i] = n6 << 24 | n3 << 16 | n4 << 8 | n5;
                }
                Height height = new Height(n, n2, nArray);
                return height;
            }
            finally {
                STBImage.stbi_image_free((ByteBuffer)byteBuffer2);
            }
        }
        finally {
            MemoryUtil.memFree((Buffer)byteBuffer);
        }
    }

    private static InputStream lmbd$scan$0(Path path, String string) throws IOException {
        return CharacterLoader.G(path, string);
    }

    static {
        LOGGER = LoggerFactory.getLogger("Kryzex");
    }
}
