package kryzex.modules.misc;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import kryzex.event.KeyEvent;
import kryzex.event.Subscribe;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

/**
 * Plays real mechanical keyboard sounds when keys are pressed. Selectable model:
 * Cherry MX Blue (cherrymx) or Rainy75 HMX Violet Linear (rainy75).
 * Sound bank: assets/kryzex_keys/<model>.pcm (mono, 32 kHz, 16-bit LE) + <model>.idx
 * (lines of "mechCode byteOffset byteLength"). Uses javax.sound only, no Minecraft sound engine.
 */
public final class KeySounds
extends Module {
    private static final String MODEL_CHERRY = "Cherry MX Blue";
    private static final String MODEL_RAINY = "Rainy75 HMX Violet";
    private static final String BANK_DIR = "/assets/kryzex_keys/";
    private static final AudioFormat FORMAT = new AudioFormat(32000.0f, 16, 1, true, false);
    private static final int MAX_ACTIVE = 10;
    private static final int FALLBACK_CODE = 30;
    private static final int[] GLFW_TO_MECH = new int[349];
    private static final AtomicInteger ACTIVE = new AtomicInteger();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "kryzex-keysounds");
        thread.setDaemon(true);
        return thread;
    });
    private static volatile Bank bank;
    private static volatile String bankFile;

    private static final class Bank {
        final byte[] pcm;
        final Map<Integer, int[]> clips;

        Bank(byte[] pcm, Map<Integer, int[]> clips) {
            this.pcm = pcm;
            this.clips = clips;
        }
    }

    private final ModeSetting model = new ModeSetting(SecureString.of("Model"), MODEL_CHERRY, List.of(MODEL_CHERRY, MODEL_RAINY));
    private final NumberSetting volume = new NumberSetting(SecureString.of("Volume"), 0.0, 100.0, 60.0, 1.0);
    private final BoolSetting allKeys = new BoolSetting(SecureString.of("All Keys"), false)
        .setDescription(SecureString.of("Also play while in game, not only in chat / menus / text boxes"));

    static {
        Arrays.fill(GLFW_TO_MECH, -1);
        map(256, 1);
        for (int i = 0; i < 10; ++i) {
            map(290 + i, 59 + i);
        }
        map(300, 87);
        map(301, 88);
        map(96, 41);
        for (int i = 1; i <= 9; ++i) {
            map(48 + i, 1 + i);
        }
        map(48, 11);
        map(45, 12);
        map(61, 13);
        map(259, 14);
        map(258, 15);
        letters("QWERTYUIOP", 16);
        map(91, 26);
        map(93, 27);
        map(257, 28);
        map(341, 29);
        letters("ASDFGHJKL", 30);
        map(59, 39);
        map(39, 40);
        map(340, 42);
        map(92, 43);
        letters("ZXCVBNM", 44);
        map(44, 51);
        map(46, 52);
        map(47, 53);
        map(344, 54);
        map(332, 55);
        map(342, 56);
        map(32, 57);
        map(280, 58);
        map(282, 69);
        map(281, 70);
        map(327, 71);
        map(328, 72);
        map(329, 73);
        map(333, 74);
        map(324, 75);
        map(325, 76);
        map(326, 77);
        map(334, 78);
        map(321, 79);
        map(322, 80);
        map(323, 81);
        map(320, 82);
        map(330, 83);
        map(161, 86);
        map(336, 3597);
        map(335, 3612);
        map(345, 3613);
        map(331, 3637);
        map(283, 3639);
        map(346, 3640);
        map(284, 3653);
        map(268, 3655);
        map(266, 3657);
        map(269, 3663);
        map(267, 3665);
        map(260, 3666);
        map(261, 3667);
        map(343, 3675);
        map(347, 3676);
        map(348, 3677);
        map(265, 57416);
        map(263, 57419);
        map(262, 57421);
        map(264, 57424);
    }

    public KeySounds() {
        super(SecureString.of("Key Sounds"), SecureString.of("Plays mechanical keyboard sounds when you type."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.model, this.volume, this.allKeys});
    }

    private static void map(int glfwKey, int mechCode) {
        if (glfwKey < 0 || glfwKey >= GLFW_TO_MECH.length) return;
        GLFW_TO_MECH[glfwKey] = mechCode;
    }

    private static void letters(String letters, int firstCode) {
        for (int i = 0; i < letters.length(); ++i) {
            map(letters.charAt(i), firstCode + i);
        }
    }

    private static String fileFor(String modelName) {
        return MODEL_RAINY.equals(modelName) ? "rainy75" : "cherrymx";
    }

    private static synchronized void load(String file) {
        if (bank != null && file.equals(bankFile)) return;
        try (InputStream pcmStream = KeySounds.class.getResourceAsStream(BANK_DIR + file + ".pcm");
             InputStream idxStream = KeySounds.class.getResourceAsStream(BANK_DIR + file + ".idx");){
            if (pcmStream == null || idxStream == null) {
                System.err.println("[KeySounds] sound bank not found: " + file);
                return;
            }
            byte[] data = pcmStream.readAllBytes();
            Map<Integer, int[]> clips = new HashMap<Integer, int[]>();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(idxStream, StandardCharsets.UTF_8));){
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length != 3) continue;
                    int code = Integer.parseInt(parts[0]);
                    int offset = Integer.parseInt(parts[1]);
                    int length = Integer.parseInt(parts[2]);
                    if (offset < 0 || length <= 0 || offset + length > data.length) continue;
                    clips.put(code, new int[]{offset, length});
                }
            }
            if (clips.isEmpty()) return;
            bank = new Bank(data, clips);
            bankFile = file;
        }
        catch (Throwable throwable) {
            System.err.println("[KeySounds] failed to load sound bank: " + throwable);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        String file = fileFor(this.model.getMode());
        POOL.execute(() -> KeySounds.load(file));
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onKey(KeyEvent keyEvent) {
        if (!this.isEnabled()) return;
        if (keyEvent.mode != 1) return;
        String wanted = fileFor(this.model.getMode());
        Bank current = bank;
        if (current == null || !wanted.equals(bankFile)) {
            POOL.execute(() -> KeySounds.load(wanted));
            if (current == null) return;
        }
        if (!this.allKeys.getValue() && this.mc.field_1755 == null) return;
        float gain = this.volume.getFloatValue() / 100.0f;
        if (gain <= 0.0f) return;
        int key = keyEvent.key;
        int mechCode = key >= 0 && key < GLFW_TO_MECH.length ? GLFW_TO_MECH[key] : -1;
        int[] clip = current.clips.get(mechCode);
        if (clip == null) {
            clip = current.clips.get(FALLBACK_CODE);
        }
        if (clip == null) return;
        this.play(current.pcm, clip[0], clip[1], gain);
    }

    private void play(byte[] pcm, int offset, int length, float gain) {
        if (ACTIVE.get() >= MAX_ACTIVE) return;
        ACTIVE.incrementAndGet();
        POOL.execute(() -> {
            AtomicBoolean released = new AtomicBoolean(false);
            try {
                byte[] data = new byte[length];
                for (int i = 0; i + 1 < length; i += 2) {
                    int sample = (short)(pcm[offset + i] & 0xFF | pcm[offset + i + 1] << 8);
                    sample = Math.round((float)sample * gain);
                    sample = Math.max(-32768, Math.min(32767, sample));
                    data[i] = (byte)sample;
                    data[i + 1] = (byte)(sample >> 8);
                }
                AudioInputStream stream = new AudioInputStream(new ByteArrayInputStream(data), FORMAT, length / 2);
                Clip clip = AudioSystem.getClip();
                clip.addLineListener(event -> {
                    if (event.getType() != LineEvent.Type.STOP) return;
                    if (!released.compareAndSet(false, true)) return;
                    clip.close();
                    ACTIVE.decrementAndGet();
                });
                clip.open(stream);
                clip.start();
            }
            catch (Throwable throwable) {
                if (released.compareAndSet(false, true)) {
                    ACTIVE.decrementAndGet();
                }
            }
        });
    }
}
