package kryzex.modules.misc;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import kryzex.event.KeyEvent;
import kryzex.event.Subscribe;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

/**
 * Plays real mechanical keyboard sounds when keys are pressed. Selectable model:
 * Cherry MX Blue (cherrymx), Rainy75 HMX Violet Linear (rainy75), Poppy (poppy) or Keygeek Y2 Linear (keygeek_y2).
 * Sound bank: assets/kryzex_keys/<model>.pcm (mono, 44.1 kHz, 16-bit LE) + <model>.idx
 * (lines of "mechCode byteOffset byteLength"). Uses javax.sound only, no Minecraft sound engine.
 */
public final class KeySounds
extends Module {
    private static final String MODEL_CHERRY = "Cherry MX Blue";
    private static final String MODEL_RAINY = "Rainy75 HMX Violet";
    private static final String MODEL_POPPY = "Poppy";
    private static final String MODEL_Y2 = "Keygeek Y2";
    private static final String BANK_DIR = "/assets/kryzex_keys/";
    private static final float SAMPLE_RATE = 44100.0f;
    private static final AudioFormat FORMAT = new AudioFormat(SAMPLE_RATE, 16, 1, true, false);
    private static final int MAX_VOICES = 24;
    private static final int CHUNK_FRAMES = 256;
    private static final int LINE_FRAMES = 1024;
    private static final int FALLBACK_CODE = 30;
    private static final int[] GLFW_TO_MECH = new int[349];
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "kryzex-keysounds");
        thread.setDaemon(true);
        return thread;
    });
    private static volatile Bank bank;
    private static volatile String bankFile;

    private static final class Bank {
        final short[] pcm;
        final Map<Integer, int[]> clips;

        Bank(short[] pcm, Map<Integer, int[]> clips) {
            this.pcm = pcm;
            this.clips = clips;
        }
    }

    private static final class Voice {
        final short[] data;
        final int end;
        final float gain;
        int pos;

        Voice(short[] data, int start, int end, float gain) {
            this.data = data;
            this.pos = start;
            this.end = end;
            this.gain = gain;
        }
    }

    /** One persistent output line + software mixer: no per-key Clip open, so no lag, cut-offs or resampling artifacts. */
    private static final LinkedBlockingQueue<Voice> INCOMING = new LinkedBlockingQueue<>();
    private static Thread mixerThread;
    private static volatile long mixerFailedAt;

    private static synchronized void ensureMixer() {
        if (mixerThread != null && mixerThread.isAlive()) return;
        if (System.currentTimeMillis() - mixerFailedAt < 5000L) return;
        mixerThread = new Thread(KeySounds::mixLoop, "kryzex-keysounds-mixer");
        mixerThread.setDaemon(true);
        mixerThread.start();
    }

    private static void mixLoop() {
        SourceDataLine line = null;
        java.util.ArrayList<Voice> voices = new java.util.ArrayList<>();
        int[] acc = new int[CHUNK_FRAMES];
        byte[] out = new byte[CHUNK_FRAMES * 2];
        try {
            line = AudioSystem.getSourceDataLine(FORMAT);
            line.open(FORMAT, LINE_FRAMES * 2);
            boolean running = false;
            while (true) {
                if (voices.isEmpty()) {
                    if (running) {
                        line.drain();
                        line.stop();
                        running = false;
                    }
                    voices.add(INCOMING.take());
                }
                Voice extra;
                while (voices.size() < MAX_VOICES && (extra = INCOMING.poll()) != null) {
                    voices.add(extra);
                }
                if (!running) {
                    line.start();
                    running = true;
                }
                java.util.Arrays.fill(acc, 0);
                for (int v = voices.size() - 1; v >= 0; --v) {
                    Voice voice = voices.get(v);
                    int n = Math.min(CHUNK_FRAMES, voice.end - voice.pos);
                    for (int i = 0; i < n; ++i) {
                        acc[i] += Math.round((float)voice.data[voice.pos + i] * voice.gain);
                    }
                    voice.pos += n;
                    if (voice.pos >= voice.end) {
                        voices.remove(v);
                    }
                }
                for (int i = 0; i < CHUNK_FRAMES; ++i) {
                    int sample = acc[i];
                    if (sample > 32767) {
                        sample = 32767;
                    } else if (sample < -32768) {
                        sample = -32768;
                    }
                    out[i * 2] = (byte)sample;
                    out[i * 2 + 1] = (byte)(sample >> 8);
                }
                line.write(out, 0, out.length);
            }
        }
        catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }
        catch (Throwable throwable) {
            System.err.println("[KeySounds] audio output failed: " + throwable);
            mixerFailedAt = System.currentTimeMillis();
        }
        finally {
            if (line != null) {
                try {
                    line.close();
                }
                catch (Throwable ignored) {
                }
            }
            INCOMING.clear();
        }
    }

    private final ModeSetting model = new ModeSetting(SecureString.of("Model"), MODEL_CHERRY, List.of(MODEL_CHERRY, MODEL_RAINY, MODEL_POPPY, MODEL_Y2));
    private final NumberSetting volume = new NumberSetting(SecureString.of("Volume"), 0.0, 100.0, 60.0, 1.0);
    private final BoolSetting allKeys = new BoolSetting(SecureString.of("All Keys"), false)
        .setDescription(SecureString.of("Also play while in game, not only in chat / menus / text boxes"));

    static {
        Arrays.fill(GLFW_TO_MECH, -1);
        map(256, 1);
        for (int i = 0; i < 10; ++i) {
            map(290 + i, 59 + i);
        }
        map(300, 87);
        map(301, 88);
        map(96, 41);
        for (int i = 1; i <= 9; ++i) {
            map(48 + i, 1 + i);
        }
        map(48, 11);
        map(45, 12);
        map(61, 13);
        map(259, 14);
        map(258, 15);
        letters("QWERTYUIOP", 16);
        map(91, 26);
        map(93, 27);
        map(257, 28);
        map(341, 29);
        letters("ASDFGHJKL", 30);
        map(59, 39);
        map(39, 40);
        map(340, 42);
        map(92, 43);
        letters("ZXCVBNM", 44);
        map(44, 51);
        map(46, 52);
        map(47, 53);
        map(344, 54);
        map(332, 55);
        map(342, 56);
        map(32, 57);
        map(280, 58);
        map(282, 69);
        map(281, 70);
        map(327, 71);
        map(328, 72);
        map(329, 73);
        map(333, 74);
        map(324, 75);
        map(325, 76);
        map(326, 77);
        map(334, 78);
        map(321, 79);
        map(322, 80);
        map(323, 81);
        map(320, 82);
        map(330, 83);
        map(161, 86);
        map(336, 3597);
        map(335, 3612);
        map(345, 3613);
        map(331, 3637);
        map(283, 3639);
        map(346, 3640);
        map(284, 3653);
        map(268, 3655);
        map(266, 3657);
        map(269, 3663);
        map(267, 3665);
        map(260, 3666);
        map(261, 3667);
        map(343, 3675);
        map(347, 3676);
        map(348, 3677);
        map(265, 57416);
        map(263, 57419);
        map(262, 57421);
        map(264, 57424);
    }

    public KeySounds() {
        super(SecureString.of("Key Sounds"), SecureString.of("Plays mechanical keyboard sounds when you type."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.model, this.volume, this.allKeys});
    }

    private static void map(int glfwKey, int mechCode) {
        if (glfwKey < 0 || glfwKey >= GLFW_TO_MECH.length) return;
        GLFW_TO_MECH[glfwKey] = mechCode;
    }

    private static void letters(String letters, int firstCode) {
        for (int i = 0; i < letters.length(); ++i) {
            map(letters.charAt(i), firstCode + i);
        }
    }

    private static String fileFor(String modelName) {
        if (MODEL_RAINY.equals(modelName)) return "rainy75";
        if (MODEL_POPPY.equals(modelName)) return "poppy";
        if (MODEL_Y2.equals(modelName)) return "keygeek_y2";
        return "cherrymx";
    }

    private static synchronized void load(String file) {
        if (bank != null && file.equals(bankFile)) return;
        try (InputStream pcmStream = KeySounds.class.getResourceAsStream(BANK_DIR + file + ".pcm");
             InputStream idxStream = KeySounds.class.getResourceAsStream(BANK_DIR + file + ".idx");){
            if (pcmStream == null || idxStream == null) {
                System.err.println("[KeySounds] sound bank not found: " + file);
                return;
            }
            byte[] raw = pcmStream.readAllBytes();
            short[] data = new short[raw.length / 2];
            for (int i = 0; i < data.length; ++i) {
                data[i] = (short)(raw[i * 2] & 0xFF | raw[i * 2 + 1] << 8);
            }
            Map<Integer, int[]> clips = new HashMap<Integer, int[]>();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(idxStream, StandardCharsets.UTF_8));){
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length != 3) continue;
                    int code = Integer.parseInt(parts[0]);
                    int offset = Integer.parseInt(parts[1]);
                    int length = Integer.parseInt(parts[2]);
                    int start = offset / 2;
                    int count = length / 2;
                    if (start < 0 || count <= 0 || start + count > data.length) continue;
                    clips.put(code, new int[]{start, count});
                }
            }
            if (clips.isEmpty()) return;
            Bank loaded = new Bank(data, clips);
            if ("rainy75".equals(file) || "poppy".equals(file) || "keygeek_y2".equals(file)) {
                loaded = retimeToBlue(loaded);
            }
            bank = loaded;
            bankFile = file;
        }
        catch (Throwable throwable) {
            System.err.println("[KeySounds] failed to load sound bank: " + throwable);
        }
    }

    /**
     * Violet (rainy75) timing -> same feel as Blue (cherrymx). Audio content is untouched, only the timing:
     *  - onset is aligned to a fixed ~6 ms after the key press (Blue's median), instead of starting mid-sound
     *  - the near-silent dead tail is cut (Violet clips carry ~70 ms of it, Blue only ~17 ms)
     *  - short fade-in / fade-out so there is no click at the clip edges
     */
    private static Bank retimeToBlue(Bank src) {
        final int pre = (int)(SAMPLE_RATE * 0.006f);
        final int tail = (int)(SAMPLE_RATE * 0.017f);
        final int fadeIn = (int)(SAMPLE_RATE * 0.0005f);
        final int fadeOut = (int)(SAMPLE_RATE * 0.008f);
        Map<Integer, short[]> parts = new HashMap<Integer, short[]>();
        int total = 0;
        for (Map.Entry<Integer, int[]> entry : src.clips.entrySet()) {
            int start = entry.getValue()[0];
            int end = start + entry.getValue()[1];
            int peak = 0;
            for (int i = start; i < end; ++i) {
                peak = Math.max(peak, Math.abs((int)src.pcm[i]));
            }
            int thr = Math.max(peak / 20, 50);
            int first = start;
            while (first < end - 1 && Math.abs((int)src.pcm[first]) <= thr) ++first;
            int last = end - 1;
            while (last > first && Math.abs((int)src.pcm[last]) <= thr) --last;
            int stop = Math.min(end, last + 1 + tail);
            int len = stop - first;
            if (len <= 0) continue;
            short[] part = new short[pre + len];
            System.arraycopy(src.pcm, first, part, pre, len);
            for (int i = 0; i < Math.min(fadeIn, len); ++i) {
                part[pre + i] = (short)(part[pre + i] * (i / (float)fadeIn));
            }
            int fo = Math.min(fadeOut, len);
            for (int i = 0; i < fo; ++i) {
                int idx = part.length - 1 - i;
                part[idx] = (short)(part[idx] * (i / (float)fo));
            }
            parts.put(entry.getKey(), part);
            total += part.length;
        }
        if (parts.isEmpty()) return src;
        short[] out = new short[total];
        Map<Integer, int[]> clips = new HashMap<Integer, int[]>();
        int pos = 0;
        for (Map.Entry<Integer, short[]> entry : parts.entrySet()) {
            short[] part = entry.getValue();
            System.arraycopy(part, 0, out, pos, part.length);
            clips.put(entry.getKey(), new int[]{pos, part.length});
            pos += part.length;
        }
        return new Bank(out, clips);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        String file = fileFor(this.model.getMode());
        POOL.execute(() -> KeySounds.load(file));
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onKey(KeyEvent keyEvent) {
        if (!this.isEnabled()) return;
        if (keyEvent.mode != 1) return;
        String wanted = fileFor(this.model.getMode());
        Bank current = bank;
        if (current == null || !wanted.equals(bankFile)) {
            POOL.execute(() -> KeySounds.load(wanted));
            if (current == null) return;
        }
        if (!this.allKeys.getValue() && this.mc.field_1755 == null) return;
        float gain = this.volume.getFloatValue() / 100.0f;
        if (gain <= 0.0f) return;
        int key = keyEvent.key;
        int mechCode = key >= 0 && key < GLFW_TO_MECH.length ? GLFW_TO_MECH[key] : -1;
        int[] clip = current.clips.get(mechCode);
        if (clip == null) {
            clip = current.clips.get(FALLBACK_CODE);
        }
        if (clip == null) return;
        this.play(current.pcm, clip[0], clip[1], gain);
    }

    private void play(short[] pcm, int start, int count, float gain) {
        ensureMixer();
        if (mixerThread == null || !mixerThread.isAlive()) return;
        if (INCOMING.size() >= MAX_VOICES) return;
        INCOMING.offer(new Voice(pcm, start, start + count, gain));
    }
}
