package kryzex.modules.macros;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroActionSetting;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroColorSetting;
import kryzex.module.settings.MacroModeSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.misc.MacroModule;
import kryzex.util.SecureString;

/**
 * Auto Builder (Corz v3.1) bridge  -  bridge v3.1
 *
 * CHANGELOG v3.1 (on top of v3 fixes):
 *
 *  v3.1-A  [Restock — CHEAPEST FIRST]
 *    v3 called findTopSlot() which returns the FIRST matching slot (top-left).
 *    /ah listings are not sorted by price by default on Donut SMP.
 *    v3.1: scanAllSlots() reads every container slot, extracts the price from
 *    the item's display-name lore (tooltips), picks the slot with the lowest
 *    numeric price, and clicks that one. Falls back to top-slot if no price
 *    is parseable (e.g. different GUI layout).
 *
 *  v3.1-B  [Block obstacle — AUTO CLEAR LITEMATICA CONFLICTS]
 *    When Corz stops placing (stuck for >OBSTACLE_IDLE_MS) but materials are
 *    present and no hazard exists, the bridge scans the 5×5×3 volume around
 *    the player for blocks that are (a) present in the world and (b) NOT part
 *    of the schematic at that position (i.e. they should be air according to
 *    the litematica overlay). These "wrong blocks" block the schematic.
 *    The bridge selects the best tool from the hotbar (pickaxe > axe > shovel >
 *    sword > bare hand, matched to block hardness class), swings to break
 *    the block, waits for it to drop, then resumes Corz.
 *    Setting: "Clear Obstacles" toggle + "Obstacle Tool" mode (Auto / Pickaxe /
 *    Axe / Shovel / Any).
 *
 *  v3.1-C  [Anti-ban — HUMANISED MOVEMENT + JITTER]
 *    Adds a lightweight anti-detection layer that fires between placements:
 *    - Random micro-rotations (yaw ±0–2°, pitch ±0–1°) every JITTER_INTERVAL_MS
 *      to simulate hand tremor. Magnitude is configurable (0 = off).
 *    - Occasional brief sneak pulses (50–150 ms) to break the perfectly-still
 *      signature of a bot standing in one spot.
 *    - Randomised placement delay: Corz "Fast Place Delay" is perturbed by
 *      ±DELAY_JITTER_MS each placement so the inter-packet interval is never
 *      perfectly constant.
 *    These run only while Corz is active (phase == PH_RUN) and are paused
 *    during restock / hazard / restart phases.
 *    Setting: "Anti Ban" toggle, "Rotation Jitter (°)" slider, "Sneak Pulse" toggle,
 *             "Delay Jitter (ms)" slider.
 */
public final class AutoBuilderBridge
extends MacroModule {
    private static final String REGISTRY     = "ai.auth.ModuleRegistry";
    private static final String AUTO_BUILDER = "com.corz.client.categories.bots.AutoBuilder";

    private static final String MODE_STOP       = "Stop";
    private static final String MODE_DISCONNECT = "Disconnect";
    private static final String HZ_STOP         = "Stop";
    private static final String HZ_FILL         = "Fill";
    private static final String HZ_AVOID        = "Avoid";
    private static final String HZ_BOTH         = "Fill+Avoid";
    private static final File   DIR             = new File("config/kryzex");
    private static final File   PROGRESS_FILE   = new File(DIR, "auto-builder-progress.json");
    private static final File   LOG_FILE        = new File(DIR, "auto-builder.log");
    private static final long   RESUME_MAX_AGE_MS = 12L * 60L * 60L * 1_000L;

    private static final int PH_RUN     = 0;
    private static final int PH_RESTART = 1;
    private static final int PH_HAZARD  = 2;
    private static final int PH_RESTOCK = 3;
    private static final int PH_CLEAR   = 4;   // v3.1-B: clearing obstacle blocks

    private static final int RS_NEXT    = 0;
    private static final int RS_LIST    = 1;
    private static final int RS_CONFIRM = 2;
    private static final int RS_BOUGHT  = 3;
    private static final long GUI_DELAY_MS    = 700L;
    private static final long RS_TIMEOUT_MS   = 8_000L;
    private static final int  RS_MAX_ATTEMPTS = 3;

    // v3.1-B
    private static final long OBSTACLE_IDLE_MS  = 8_000L;   // ms without progress before scanning for obstacles
    private static final long OBSTACLE_BREAK_MS = 600L;     // ms to hold LMB per block

    // v3.1-C
    private static final long JITTER_INTERVAL_MS = 1_200L;
    private static final long SNEAK_MIN_MS        = 50L;
    private static final long SNEAK_MAX_MS        = 150L;
    private static final Random RNG               = new Random();

    private Object  corz;
    private boolean mirrored;
    private final List<Mirror> mirrors  = new ArrayList<>();
    private final Set<String>  usedIds  = new HashSet<>();

    // --- safety
    private final MacroBoolSetting   leavePlayer;
    private final MacroNumberSetting playerRadius;
    private final StringSetting      ignoreList;
    private final MacroBoolSetting   leaveTotem;
    private final MacroNumberSetting minHealth;
    private final MacroModeSetting   onTrigger;
    // --- progress
    private final MacroBoolSetting   saveProgress;
    private final MacroNumberSetting autosaveSec;
    private final MacroBoolSetting   resumeSaved;
    private final MacroNumberSetting stuckTimeout;
    private final MacroNumberSetting stuckRetries;
    // --- restock
    private final MacroBoolSetting   autoRestock;
    private final MacroNumberSetting restockIdle;
    private final StringSetting      restockItems;
    private final StringSetting      ahCommand;
    private final StringSetting      confirmItems;
    private final MacroNumberSetting maxBuys;
    // --- hazards
    private final MacroBoolSetting   hazardGuard;
    private final MacroModeSetting   hazardAction;
    private final MacroBoolSetting   hzWater;
    private final MacroBoolSetting   hzHoles;
    private final MacroNumberSetting hazardRadius;
    private final MacroNumberSetting maxDrop;
    private final StringSetting      fillBlocks;
    private final MacroNumberSetting maxFills;
    // --- v3.1-B obstacle clear
    private final MacroBoolSetting   clearObstacles;
    private final MacroModeSetting   obstacleTool;
    // --- v3.1-C anti-ban
    private final MacroBoolSetting   antiBan;
    private final MacroNumberSetting rotJitter;
    private final MacroBoolSetting   sneakPulse;
    private final MacroNumberSetting delayJitter;

    // --- runtime state
    private boolean running;
    private boolean wasInterrupted;
    private int     phase;
    private Object  baseWorld;
    private int     lastTotems = -1;
    private final Map<String, Integer> nearTicks = new HashMap<>();
    private long lastSaveMs;
    private long lastProgressMs;
    private long restartAt;
    private int  retries;
    private String lastSignature;
    private long   signatureAt;
    private String currentSignature = "";
    private boolean warnedNoCounters;
    private long nextRestockCheck;
    // restock
    private int    rsState;
    private long   rsStateAt;
    private long   rsNextAt;
    private int    rsAttempts;
    private int    rsBuys;
    private int    rsHave;
    private String rsItem = "";
    private final List<String> rsQueue = new ArrayList<>();
    // hazards
    private long    lastHazardScan;
    private long    hazardSince;
    private long    nextFillAt;
    private long    avoidUntil;
    private long    nextAvoidAt;
    private boolean keysDown;
    private int     fills;
    private int     fillFails;
    private boolean warnedNoBlockApi;
    private final Map<String, Integer> cellTries = new HashMap<>();
    // v3.1-B obstacle clear
    private long   obstacleSince;         // when we entered PH_CLEAR
    private long   breakUntil;            // hold LMB until this ms
    private int[]  targetObstacle;        // {x,y,z} of block being broken
    private int    obstaclesCleared;
    // v3.1-C anti-ban
    private long   nextJitterAt;
    private long   sneakUntil;
    private long   nextSneakAt;
    private float  baseYaw;
    private float  basePitch;
    private boolean baseCaptured;

    // ═════════════════════════════════════════════════════════════════════
    //  CONSTRUCTOR
    // ═════════════════════════════════════════════════════════════════════

    public AutoBuilderBridge() {
        super("auto-builder", "Auto Builder",
              "Builds schematics automatically (Corz AutoBuilder v3.1)",
              MacroCategories.DONUT_MACROS);

        // safety
        this.leavePlayer  = this.addSetting(this.uniqueId("Leave On Player"),        new MacroBoolSetting("Leave On Player", true));
        this.playerRadius = this.addSetting(this.uniqueId("Player Radius"),          new MacroNumberSetting("Player Radius", 32f, 1f, 128f).step(1f));
        this.ignoreList   = new StringSetting(SecureString.of("Ignore Players (a,b,c)"), "");
        super.addSetting(this.ignoreList);
        this.leaveTotem   = this.addSetting(this.uniqueId("Leave On Totem Pop"),     new MacroBoolSetting("Leave On Totem Pop", true));
        this.minHealth    = this.addSetting(this.uniqueId("Leave At Health"),        new MacroNumberSetting("Leave At Health (0=off)", 6f, 0f, 20f).step(1f));
        this.onTrigger    = this.addSetting(this.uniqueId("On Trigger"),             new MacroModeSetting("On Trigger", MODE_DISCONNECT, MODE_STOP, MODE_DISCONNECT));

        // progress
        this.saveProgress = this.addSetting(this.uniqueId("Save Progress"),          new MacroBoolSetting("Save Progress", true));
        this.autosaveSec  = this.addSetting(this.uniqueId("Autosave Sec"),           new MacroNumberSetting("Autosave (sec)", 15f, 5f, 120f).step(5f));
        this.resumeSaved  = this.addSetting(this.uniqueId("Resume Saved Progress"),  new MacroBoolSetting("Resume Saved Progress", true));
        this.addSetting(this.uniqueId("Clear Saved Progress"),                        new MacroActionSetting("Clear Saved Progress", () -> this.clearSaved()));
        this.stuckTimeout = this.addSetting(this.uniqueId("Stuck Timeout"),          new MacroNumberSetting("Stuck Timeout (sec, 0=off)", 45f, 0f, 300f).step(5f));
        this.stuckRetries = this.addSetting(this.uniqueId("Stuck Retries"),          new MacroNumberSetting("Stuck Retries", 2f, 0f, 10f).step(1f));

        // restock
        this.autoRestock  = this.addSetting(this.uniqueId("Auto Restock /ah"),       new MacroBoolSetting("Auto Restock (/ah)", true));
        this.restockIdle  = this.addSetting(this.uniqueId("Restock Idle"),           new MacroNumberSetting("Restock After Idle (sec)", 20f, 5f, 120f).step(5f));
        this.restockItems = new StringSetting(SecureString.of("Restock Items (fallback, a,b)"), "");
        super.addSetting(this.restockItems);
        this.ahCommand    = new StringSetting(SecureString.of("AH Command ({item})"), "ah {item}");
        super.addSetting(this.ahCommand);
        this.confirmItems = new StringSetting(SecureString.of("AH Confirm Item(s)"), "lime_stained_glass_pane,green_stained_glass_pane");
        super.addSetting(this.confirmItems);
        this.maxBuys      = this.addSetting(this.uniqueId("Max Buys"),               new MacroNumberSetting("Max Buys / Session", 10f, 1f, 64f).step(1f));

        // hazards
        this.hazardGuard  = this.addSetting(this.uniqueId("Hazard Guard"),           new MacroBoolSetting("Hazard Guard", true));
        this.hazardAction = this.addSetting(this.uniqueId("Hazard Action"),          new MacroModeSetting("Hazard Action", HZ_BOTH, HZ_STOP, HZ_FILL, HZ_AVOID, HZ_BOTH));
        this.hzWater      = this.addSetting(this.uniqueId("Hazard Water"),           new MacroBoolSetting("Hazard: Water", true));
        this.hzHoles      = this.addSetting(this.uniqueId("Hazard Holes"),           new MacroBoolSetting("Hazard: Deep Holes", true));
        this.hazardRadius = this.addSetting(this.uniqueId("Hazard Radius"),          new MacroNumberSetting("Hazard Radius", 3f, 1f, 6f).step(1f));
        this.maxDrop      = this.addSetting(this.uniqueId("Hole Depth"),             new MacroNumberSetting("Hole Depth (blocks)", 4f, 2f, 12f).step(1f));
        this.fillBlocks   = new StringSetting(SecureString.of("Fill Blocks (a,b,c)"), "cobblestone,dirt,netherrack,cobbled_deepslate,stone");
        super.addSetting(this.fillBlocks);
        this.maxFills     = this.addSetting(this.uniqueId("Max Fills"),              new MacroNumberSetting("Max Fills / Session", 30f, 1f, 200f).step(1f));

        // v3.1-B obstacle clear
        this.clearObstacles = this.addSetting(this.uniqueId("Clear Obstacles"),
                new MacroBoolSetting("Clear Obstacles (Litematica conflicts)", true));
        this.obstacleTool   = this.addSetting(this.uniqueId("Obstacle Tool"),
                new MacroModeSetting("Obstacle Tool", "Auto", "Auto", "Pickaxe", "Axe", "Shovel", "Any"));

        // v3.1-C anti-ban
        this.antiBan      = this.addSetting(this.uniqueId("Anti Ban"),              new MacroBoolSetting("Anti Ban", true));
        this.rotJitter    = this.addSetting(this.uniqueId("Rotation Jitter"),       new MacroNumberSetting("Rotation Jitter (°, 0=off)", 1.5f, 0f, 5f).step(0.5f));
        this.sneakPulse   = this.addSetting(this.uniqueId("Sneak Pulse"),           new MacroBoolSetting("Sneak Pulse", true));
        this.delayJitter  = this.addSetting(this.uniqueId("Delay Jitter"),          new MacroNumberSetting("Delay Jitter (ms, 0=off)", 30f, 0f, 150f).step(5f));
    }

    // ═════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ═════════════════════════════════════════════════════════════════════

    @Override public boolean persistEnabled() { return false; }

    @Override
    public List<Setting> getSettings() {
        this.ensureMirrored();
        return super.getSettings();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.ensureMirrored();
        if (this.corz == null) {
            System.err.println("Kryzex: Auto Builder - Corz runtime not found (is the embedded corz mod loaded?)");
            this.requestDisable();
            return;
        }
        this.sync();
        this.resetRuntime();
        this.resumeIfSaved();
        this.sync();
        this.setCorz(true);
        this.running = true;
        this.log("Bắt đầu build.");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.releaseKeys();
        this.releaseSneakKey();
        if (this.corz == null) return;
        if (this.running) {
            this.running = false;
            if (this.phase == PH_RESTOCK) this.closeScreen();
            this.saveProgress("Tắt thủ công", "", this.wasInterrupted);
            this.log("Người dùng tắt Auto Builder.");
        }
        this.sync();
        this.setCorz(false);
    }

    @MacroSubscribe
    public void onTick(MacroTickEvent event) {
        this.sync();
        if (this.corz == null) return;
        long now = System.currentTimeMillis();

        if (this.running && this.phase != PH_RUN) {
            if (this.runSafety()) return;
            switch (this.phase) {
                case PH_RESTART:
                    if (now >= this.restartAt) this.resumeCorz(now);
                    break;
                case PH_HAZARD:
                    this.runHazards(now);
                    break;
                case PH_RESTOCK:
                    this.restockTick(now);
                    break;
                case PH_CLEAR:
                    this.clearTick(now);
                    break;
                default: break;
            }
            return;
        }

        Object on    = this.call(this.corz, "isEnabled", new Class<?>[0]);
        boolean corzOn = on instanceof Boolean && (Boolean) on;

        if (this.running && corzOn) {
            if (this.runSafety()) return;
            this.runHazards(now);
            if (this.phase != PH_RUN) return;
            this.runSmart(now);
            if (this.phase == PH_RUN) this.runAntiBan(now);  // v3.1-C
            return;
        }

        if (on instanceof Boolean && !corzOn) {
            if (this.running) {
                this.running = false;
                this.releaseKeys();
                this.releaseSneakKey();
                this.wasInterrupted = false;
                this.saveProgress("Corz tự dừng", "hoàn thành hoặc tự hủy", false);
                this.log("Corz tự dừng (hoàn thành hoặc tự hủy).");
                this.chat("[Auto Builder] Corz đã tự dừng (xong hoặc tự hủy).");
            }
            this.requestDisable();
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  v3.1-C  ANTI-BAN — humanised rotation + sneak pulse + delay jitter
    // ═════════════════════════════════════════════════════════════════════

    private void runAntiBan(long now) {
        if (!this.antiBan.get()) return;
        Object mc     = this.mc();
        Object player = this.field(mc, "field_1724");
        if (player == null) return;

        // Capture base yaw/pitch once per active session
        if (!this.baseCaptured) {
            this.baseYaw   = this.getYaw(player);
            this.basePitch = this.getPitch(player);
            this.baseCaptured = true;
        }

        // Sneak pulse: crouch for 50–150 ms every ~8–20 seconds
        if (this.sneakPulse.get()) {
            if (now >= this.sneakUntil && now >= this.nextSneakAt) {
                long duration = SNEAK_MIN_MS + (long)(RNG.nextFloat() * (SNEAK_MAX_MS - SNEAK_MIN_MS));
                this.sneakUntil = now + duration;
                // next sneak in 8–20 s
                this.nextSneakAt = now + 8_000L + (long)(RNG.nextFloat() * 12_000L);
                this.pressKey("field_1888", true); // sneak / shift key (KeyBinding options.keySneak)
            }
            if (now >= this.sneakUntil) {
                this.releaseSneakKey();
            }
        }

        // Rotation micro-jitter
        float mag = this.rotJitter.get();
        if (mag > 0f && now >= this.nextJitterAt) {
            this.nextJitterAt = now + JITTER_INTERVAL_MS
                              + (long)(RNG.nextFloat() * 400L);
            float dyaw   = (RNG.nextFloat() * 2f - 1f) * mag;
            float dpitch = (RNG.nextFloat() * 2f - 1f) * (mag * 0.5f);
            float newYaw   = this.baseYaw   + dyaw;
            float newPitch = clamp(this.basePitch + dpitch, -90f, 90f);
            this.invoke(player, n("method_36456"), newYaw);  // setYaw
            this.invoke(player, n("method_36459"), newPitch); // setPitch
        }

        // Delay jitter: perturb Corz "Fast Place Delay" mirror if the setting is mirrored
        int jitterMs = this.delayJitter.getInt();
        if (jitterMs > 0) {
            this.applyDelayJitter(jitterMs);
        }
    }

    private void applyDelayJitter(int jitterMs) {
        // Find the mirrored "Fast Place Delay (ms)" setting in Corz and nudge it
        for (Mirror m : this.mirrors) {
            try {
                String val = m.corzGet.get();
                if (val == null) continue;
                double base = Double.parseDouble(val);
                // Only jitter if it looks like a millisecond delay (1–500)
                if (base < 1 || base > 500) continue;
                double nudge = (RNG.nextDouble() * 2.0 - 1.0) * jitterMs;
                double nv = Math.max(1, base + nudge);
                m.corzSet.accept(String.valueOf((int) Math.round(nv)));
            } catch (Throwable ignored) {}
            break; // only the first numeric mirror that looks like a delay
        }
    }

    private void releaseSneakKey() {
        this.pressKey("field_1888", false);
        this.sneakUntil = 0L;
    }

    private float getYaw(Object player) {
        Object v = this.invoke(player, n("method_36454")); // getYaw
        return v instanceof Number ? ((Number) v).floatValue() : 0f;
    }

    private float getPitch(Object player) {
        Object v = this.invoke(player, n("method_36457")); // getPitch
        return v instanceof Number ? ((Number) v).floatValue() : 0f;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  v3.1-A  CHEAPEST-FIRST SLOT FINDER
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Scans all container slots (not player inventory), filters by ids,
     * reads price from lore/name, returns the cheapest slot index.
     * Falls back to findTopSlot() if no price can be parsed.
     */
    private int findCheapestSlot(Object screen, Object player, Set<String> ids) {
        Object handler = this.invoke(screen, n("method_17577")); // getScreenHandler
        Object slots   = this.field(handler, "field_7761");     // slots
        Object pInv    = this.invoke(player, n("method_31548")); // getInventory
        if (!(slots instanceof List)) return -1;

        List<?> list = (List<?>) slots;
        int    bestIdx   = -1;
        double bestPrice = Double.MAX_VALUE;

        for (int i = 0; i < list.size(); i++) {
            Object slot = list.get(i);
            if (slot == null || this.field(slot, "field_7871") == pInv) continue;
            Object stack = this.invoke(slot, n("method_7677")); // getStack
            String id = this.idOf(stack);
            if (id == null || !ids.contains(id)) continue;

            double price = this.extractPrice(stack);
            if (price >= 0 && price < bestPrice) {
                bestPrice = price;
                bestIdx   = i;
            } else if (price < 0 && bestIdx < 0) {
                // No price found yet — keep first valid slot as fallback
                bestIdx = i;
            }
        }
        return bestIdx;
    }

    /**
     * Extracts numeric price from an ItemStack's display name or lore.
     * Handles common Donut SMP /ah formats:
     *   "$1,234"  |  "Price: 1234"  |  "1,234 coins"  |  "1234$"
     * Returns -1 if none found.
     */
    private double extractPrice(Object stack) {
        if (stack == null) return -1;
        // Try getTooltip → list of Text lines
        Object tooltip = this.invokeRaw(stack, n("method_7861", "method_7738")); // getTooltip / getTooltipData
        if (tooltip instanceof List) {
            for (Object line : (List<?>) tooltip) {
                String s = this.textString(line);
                if (s != null) {
                    double p = parsePrice(s);
                    if (p >= 0) return p;
                }
            }
        }
        // Fallback: getName
        Object nameText = this.invoke(stack, n("method_7196")); // getName
        String name = this.textString(nameText);
        if (name != null) {
            double p = parsePrice(name);
            if (p >= 0) return p;
        }
        return -1;
    }

    private static final java.util.regex.Pattern PRICE_PAT =
            java.util.regex.Pattern.compile("[\\$£]?([\\d,\\.]+)[\\$£]?(?:\\s*(?:coins?|$|£|¥|đ|xu))?",
                    java.util.regex.Pattern.CASE_INSENSITIVE);

    private static double parsePrice(String s) {
        if (s == null) return -1;
        // Remove color/format codes (§x)
        s = s.replaceAll("§.", "").replaceAll("\\u00a7.", "").trim();
        java.util.regex.Matcher m = PRICE_PAT.matcher(s);
        if (m.find()) {
            try {
                String num = m.group(1).replace(",", "");
                return Double.parseDouble(num);
            } catch (NumberFormatException ignored) {}
        }
        return -1;
    }

    private String textString(Object text) {
        if (text == null) return null;
        Object s = this.invoke(text, n("method_10851", "getString")); // Text.getString
        return s != null ? s.toString() : null;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  v3.1-B  OBSTACLE CLEARING
    // ═════════════════════════════════════════════════════════════════════

    /** Called from runSmart() after detecting stuck-without-materials. */
    private boolean tryStartObstacleClear(Object player, Object world, long now) {
        if (!this.clearObstacles.get()) return false;
        List<int[]> obstacles = this.scanObstacles(player, world);
        if (obstacles.isEmpty()) return false;

        this.setCorz(false);
        this.phase        = PH_CLEAR;
        this.obstacleSince = now;
        this.targetObstacle = obstacles.get(0);  // nearest first
        this.breakUntil   = now + OBSTACLE_BREAK_MS;
        String msg = "Phát hiện " + obstacles.size() + " block cản litematica -> phá block tại "
                   + targetObstacle[0] + "," + targetObstacle[1] + "," + targetObstacle[2];
        this.log(msg);
        this.chat("[Auto Builder] " + msg);
        this.saveProgress("Phá block cản", "", true);
        return true;
    }

    private void clearTick(long now) {
        Object mc     = this.mc();
        Object player = this.field(mc, "field_1724");
        Object world  = this.field(mc, "field_1687");
        if (player == null || world == null) {
            this.abort("Mất kết nối", "", false);
            return;
        }

        // Timeout: if we can't clear in 20s, give up
        if (now - this.obstacleSince > 20_000L) {
            this.phase = PH_RUN;
            this.resumeCorz(now);
            this.log("Hết thời gian phá block cản - tiếp tục build.");
            return;
        }

        // Check if the target block is already gone
        if (this.targetObstacle != null) {
            String st = this.stateAt(world, targetObstacle[0], targetObstacle[1], targetObstacle[2]);
            if (isAir(st)) {
                // Block cleared — find next obstacle or resume
                this.obstaclesCleared++;
                List<int[]> remaining = this.scanObstacles(player, world);
                if (remaining.isEmpty()) {
                    this.log("Đã phá xong tất cả block cản (" + this.obstaclesCleared + ") - tiếp tục build.");
                    this.chat("[Auto Builder] Đã dọn xong, tiếp tục build.");
                    this.resumeCorz(now);
                    return;
                }
                this.targetObstacle = remaining.get(0);
                this.breakUntil = now + OBSTACLE_BREAK_MS;
            }
        }

        // Look at target and hold LMB
        if (this.targetObstacle != null && now < this.breakUntil) {
            this.lookAt(player, targetObstacle[0] + 0.5, targetObstacle[1] + 0.5, targetObstacle[2] + 0.5);
            this.selectBreakTool(mc, player, world, targetObstacle[0], targetObstacle[1], targetObstacle[2]);
            this.holdLMB(mc, player, world, targetObstacle[0], targetObstacle[1], targetObstacle[2]);
        } else if (now >= this.breakUntil) {
            this.breakUntil = now + OBSTACLE_BREAK_MS;
        }
    }

    /**
     * Scans 5×5×3 around the player for blocks that are solid but should be air
     * according to the schematic (detected by litematica's wrong-block markers if
     * available, otherwise any solid non-air block within reach that Corz would
     * need to place into).
     */
    private List<int[]> scanObstacles(Object player, Object world) {
        List<int[]> out = new ArrayList<>();
        int bx = (int) Math.floor(this.x(player));
        int by = (int) Math.floor(this.y(player));
        int bz = (int) Math.floor(this.z(player));
        double reach = 4.5;

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    int wx = bx + dx, wy = by + dy, wz = bz + dz;
                    // Distance check
                    double ddx = wx + 0.5 - this.x(player);
                    double ddy = wy + 0.5 - (this.y(player) + 1.6);
                    double ddz = wz + 0.5 - this.z(player);
                    if (ddx*ddx + ddy*ddy + ddz*ddz > reach*reach) continue;

                    String state = this.stateAt(world, wx, wy, wz);
                    if (state.isEmpty() || isAir(state)) continue;
                    // Don't break fluids (water/lava)
                    if (isKind(state, "water") || isKind(state, "lava")) continue;
                    // Check if litematica says this should be air (wrong-block position)
                    if (this.isWrongBlock(wx, wy, wz)) {
                        double dist = Math.sqrt(ddx*ddx + ddy*ddy + ddz*ddz);
                        int[] entry = {wx, wy, wz};
                        out.add(entry);
                    }
                }
            }
        }
        // Sort by distance ascending
        out.sort((a, b) -> {
            double da = this.distSq(player, a[0], a[1], a[2]);
            double db = this.distSq(player, b[0], b[1], b[2]);
            return Double.compare(da, db);
        });
        return out;
    }

    private double distSq(Object player, int x, int y, int z) {
        double dx = x + 0.5 - this.x(player);
        double dy = y + 0.5 - this.y(player);
        double dz = z + 0.5 - this.z(player);
        return dx*dx + dy*dy + dz*dz;
    }

    /**
     * Checks litematica's SchematicPlacementManager / LayerRange API to determine
     * if the block at (x,y,z) is a "wrong block" position (should be air per schematic).
     * Attempts multiple known class paths. Falls back to: treat any solid block within
     * the schematic AABB as a potential obstacle (less precise but always works).
     */
    private boolean isWrongBlock(int x, int y, int z) {
        // Try litematica API — class names stable since litematica 0.14+
        try {
            Class<?> spm = Class.forName("fi.dy.masa.litematica.schematic.placement.SchematicPlacementManager");
            Object instance = spm.getMethod("getInstance").invoke(null);
            Object pos = this.blockPos(x, y, z);
            // hasInvalidBlocksAt(BlockPos) or isWrongBlock(BlockPos)
            for (String mname : new String[]{"hasInvalidBlocksAt", "isWrongBlock", "isWrongBlockAt"}) {
                try {
                    Object r = spm.getMethod(mname, pos.getClass()).invoke(instance, pos);
                    if (r instanceof Boolean) return (Boolean) r;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}

        // Fallback: treat as obstacle (the caller already filters by reach + non-air)
        // Safe because we only call this inside runSmart stuck detection
        return true;
    }

    private void selectBreakTool(Object mc, Object player, Object world, int x, int y, int z) {
        String mode = this.obstacleTool.get();
        String state = this.stateAt(world, x, y, z);
        Object inv = this.invoke(player, n("method_31548"));
        if (inv == null) return;

        // Priority: pickaxe > axe > shovel > sword > any
        String[] preferred;
        if ("Pickaxe".equals(mode)) {
            preferred = new String[]{"pickaxe"};
        } else if ("Axe".equals(mode)) {
            preferred = new String[]{"axe"};
        } else if ("Shovel".equals(mode)) {
            preferred = new String[]{"shovel"};
        } else if ("Auto".equals(mode)) {
            // Choose by block type heuristic
            if (state.contains("stone") || state.contains("ore") || state.contains("deepslate")
                    || state.contains("brick") || state.contains("cobble") || state.contains("quartz")) {
                preferred = new String[]{"pickaxe", "axe", "shovel"};
            } else if (state.contains("log") || state.contains("planks") || state.contains("wood")
                    || state.contains("fence") || state.contains("chest")) {
                preferred = new String[]{"axe", "pickaxe", "shovel"};
            } else if (state.contains("dirt") || state.contains("sand") || state.contains("gravel")
                    || state.contains("clay") || state.contains("soul")) {
                preferred = new String[]{"shovel", "pickaxe", "axe"};
            } else {
                preferred = new String[]{"pickaxe", "axe", "shovel"};
            }
        } else { // Any
            preferred = new String[]{"pickaxe", "axe", "shovel", "sword"};
        }

        for (String tool : preferred) {
            for (int slot = 0; slot < 9; slot++) {
                Object stack = this.invoke(inv, n("method_5438"), slot);
                String id = this.idOf(stack);
                if (id != null && id.contains(tool)) {
                    this.setField(inv, "field_7545", slot);
                    return;
                }
            }
        }
        // No preferred tool found — keep whatever is selected
    }

    private void lookAt(Object player, double tx, double ty, double tz) {
        double dx = tx - this.x(player);
        double dy = ty - (this.y(player) + 1.62);
        double dz = tz - this.z(player);
        double horiz = Math.sqrt(dx*dx + dz*dz);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, horiz));
        this.invoke(player, n("method_36456"), yaw);
        this.invoke(player, n("method_36459"), pitch);
    }

    private void holdLMB(Object mc, Object player, Object world, int x, int y, int z) {
        try {
            Object pos   = this.blockPos(x, y, z);
            Object dir   = this.enumConst("net.minecraft.class_2350", "field_11036"); // UP
            Object im    = this.field(mc, "field_1761");
            // attack / startMiningBlock
            this.invokeRaw(im, n("method_2902"), player, world, pos, dir); // attackBlock
        } catch (Throwable ignored) {}
    }

    // ═════════════════════════════════════════════════════════════════════
    //  CORZ / MC HELPERS
    // ═════════════════════════════════════════════════════════════════════

    private void setCorz(boolean on) {
        this.call(this.corz, "setEnabled", new Class<?>[]{Boolean.TYPE}, Boolean.valueOf(on));
    }

    private void resumeCorz(long now) {
        this.phase          = PH_RUN;
        this.restartAt      = 0L;
        this.lastSignature  = null;
        this.signatureAt    = 0L;
        this.lastProgressMs = now;
        this.nextRestockCheck = now + 5_000L;
        this.cellTries.clear();
        this.baseCaptured   = false;  // recapture rotation baseline
        this.setCorz(true);
    }

    private void resetRuntime() {
        long now = System.currentTimeMillis();
        this.phase            = PH_RUN;
        this.baseWorld        = null;
        this.lastTotems       = -1;
        this.nearTicks.clear();
        this.lastSaveMs       = now;
        this.lastProgressMs   = now;
        this.restartAt        = 0L;
        this.retries          = 0;
        this.lastSignature    = null;
        this.signatureAt      = 0L;
        this.currentSignature = "";
        this.warnedNoCounters = false;
        this.nextRestockCheck = now + 5_000L;
        this.rsQueue.clear();
        this.rsBuys           = 0;
        this.rsState          = RS_NEXT;
        this.fills            = 0;
        this.fillFails        = 0;
        this.nextFillAt       = 0L;
        this.cellTries.clear();
        this.wasInterrupted   = false;
        this.obstaclesCleared = 0;
        this.targetObstacle   = null;
        this.baseCaptured     = false;
        this.nextJitterAt     = now + JITTER_INTERVAL_MS;
        this.nextSneakAt      = now + 10_000L;
        this.sneakUntil       = 0L;
        this.releaseKeys();
        this.releaseSneakKey();
    }

    // ═════════════════════════════════════════════════════════════════════
    //  SAFETY CHECKS (unchanged from v3)
    // ═════════════════════════════════════════════════════════════════════

    private boolean runSafety() {
        Object mc     = this.mc();
        Object player = this.field(mc, "field_1724");
        Object world  = this.field(mc, "field_1687");
        if (player == null || world == null) {
            this.abort("Mất kết nối / thoát thế giới", "", false);
            return true;
        }
        if (this.baseWorld == null) {
            this.baseWorld = world;
        } else if (world != this.baseWorld) {
            this.abort("Đổi thế giới / dimension", "build bị dừng để tránh đặt sai chỗ", false);
            return true;
        }
        if (Boolean.TRUE.equals(this.invoke(player, n("method_29504")))) {
            this.abort("Người chơi đã chết", "", false);
            return true;
        }
        int totems = this.countTotems(player);
        if (totems >= 0) {
            int before = this.lastTotems;
            this.lastTotems = totems;
            if (this.leaveTotem.get() && before >= 0 && totems < before) {
                this.abort("Totem vỡ", this.describePop(player, world, totems), true);
                return true;
            }
        }
        int minHp = this.minHealth.getInt();
        if (minHp > 0) {
            double hp = this.num(this.invoke(player, n("method_6032")), 20.0);
            if (hp <= minHp) {
                this.abort("Máu thấp", String.format(Locale.ROOT, "HP %.1f <= %d", hp, minHp), true);
                return true;
            }
        }
        if (this.leavePlayer.get()) {
            List<Hit> hits = this.playersNear(player, world, this.playerRadius.get(), true);
            Set<String> present = new HashSet<>();
            Hit trigger = null;
            for (Hit h : hits) {
                String key = h.name.toLowerCase(Locale.ROOT);
                present.add(key);
                int c = this.nearTicks.merge(key, 1, Integer::sum);
                if (c >= 2 && trigger == null) trigger = h;
            }
            this.nearTicks.keySet().retainAll(present);
            if (trigger != null) {
                this.abort("Có người chơi ở gần",
                    String.format(Locale.ROOT, "\"%s\" cách %.1f block (bán kính %d)",
                        trigger.name, trigger.dist, this.playerRadius.getInt()), true);
                return true;
            }
        }
        return false;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  SMART BUILDER — autosave / stuck / restock / v3.1-B obstacle
    // ═════════════════════════════════════════════════════════════════════

    private void runSmart(long now) {
        Object player = this.field(this.mc(), "field_1724");
        if (player == null) return;
        if (this.saveProgress.get() && now - this.lastSaveMs >= this.autosaveSec.getInt() * 1_000L) {
            this.saveProgress("Autosave", "", true);
        }
        if (now - this.signatureAt >= 500L) {
            this.signatureAt = now;
            String fp = this.fingerprint();
            if (fp.isEmpty() && !this.warnedNoCounters) {
                this.warnedNoCounters = true;
                this.log("Không đọc được bộ đếm tiến trình của Corz -> chỉ dùng inventory để phát hiện kẹt.");
            }
            this.currentSignature = fp + "|" + this.snapshot(player).toString();
        }
        if (this.lastSignature == null || !this.currentSignature.equals(this.lastSignature)) {
            this.lastSignature  = this.currentSignature;
            this.lastProgressMs = now;
            this.retries        = 0;
            return;
        }
        long idle = now - this.lastProgressMs;

        // Restock check
        if (this.autoRestock.get() && idle >= this.restockIdle.getInt() * 1_000L
                && now >= this.nextRestockCheck) {
            this.nextRestockCheck = now + 5_000L;
            List<String> missing = this.missingItems(player);
            if (!missing.isEmpty()) {
                this.startRestock(missing, now);
                return;
            }
        }

        // v3.1-B: obstacle check fires before stuck timeout
        if (this.clearObstacles.get() && idle >= OBSTACLE_IDLE_MS) {
            Object world = this.field(this.mc(), "field_1687");
            if (world != null && this.tryStartObstacleClear(player, world, now)) return;
        }

        // Stuck detection / restart
        int timeout = this.stuckTimeout.getInt();
        if (timeout <= 0 || idle < timeout * 1_000L) return;
        if (this.retries < this.stuckRetries.getInt()) {
            ++this.retries;
            this.lastProgressMs = now;
            String msg = "Builder không tiến triển " + timeout + "s -> khởi động lại (lần " + this.retries + "/" + this.stuckRetries.getInt() + ")";
            this.log(msg);
            this.chat("[Auto Builder] " + msg);
            this.saveProgress("Restart do kẹt", "", true);
            this.setCorz(false);
            this.phase     = PH_RESTART;
            this.restartAt = now + 1_500L;
        } else {
            this.abort("Builder bị kẹt", "không tiến triển " + timeout + "s sau " + this.retries + " lần restart", false);
        }
    }

    private static final Pattern FP_YES  = Pattern.compile("(?i)(place|progress|built|remain|left|queue|index|total|done|step|current|missing|pending)");
    private static final Pattern FP_NO   = Pattern.compile("(?i)(tick|delay|timer|cool|time|last|speed|reach|tps|yaw|pitch|rand|anim)");
    private static final Pattern INFO_YES = Pattern.compile("(?i)(schematic|origin|file)");
    private static final Pattern NEED_YES = Pattern.compile("(?i)(missing|needed|need|shortage|lack|remaining|required|material|supplies)");

    private String fingerprint() {
        StringBuilder sb = new StringBuilder();
        for (Class<?> c = this.corz.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                String name = f.getName();
                if (!FP_YES.matcher(name).find() || FP_NO.matcher(name).find()) continue;
                Class<?> t = f.getType();
                boolean numeric = t == Integer.TYPE || t == Long.TYPE || t == Short.TYPE || t == Double.TYPE || t == Float.TYPE;
                boolean coll    = Collection.class.isAssignableFrom(t) || Map.class.isAssignableFrom(t);
                if (!numeric && !coll) continue;
                try {
                    f.setAccessible(true);
                    Object v = f.get(this.corz);
                    if (v instanceof Collection) v = ((Collection<?>) v).size();
                    else if (v instanceof Map) v = ((Map<?, ?>) v).size();
                    sb.append(name).append('=').append(v).append(';');
                } catch (Throwable ignored) {}
            }
        }
        return sb.toString();
    }

    // ═════════════════════════════════════════════════════════════════════
    //  RESTOCK — v3.1-A: cheapest slot replaces findTopSlot
    // ═════════════════════════════════════════════════════════════════════

    private List<String> missingItems(Object player) {
        Map<String, Integer> need = new LinkedHashMap<>();
        this.corzNeeds(need);
        for (String id : this.parseIds(this.restockItems.getValue())) need.putIfAbsent(id, 1);
        Map<String, Integer> have = this.snapshot(player);
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Integer> e : need.entrySet()) {
            if (e.getValue() > 0 && have.getOrDefault(e.getKey(), 0) == 0) out.add(e.getKey());
        }
        return out;
    }

    private void corzNeeds(Map<String, Integer> out) {
        for (Class<?> c = this.corz.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                if (!NEED_YES.matcher(f.getName()).find()) continue;
                Class<?> t = f.getType();
                if (!Map.class.isAssignableFrom(t) && !Collection.class.isAssignableFrom(t)) continue;
                try {
                    f.setAccessible(true);
                    Object v = f.get(this.corz);
                    if (v instanceof Map) {
                        for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
                            String id     = this.idOf(e.getKey());
                            int    amount = e.getValue() instanceof Number ? ((Number) e.getValue()).intValue() : 1;
                            if (id != null && amount > 0) out.merge(id, amount, Math::max);
                        }
                    } else if (v instanceof Collection) {
                        for (Object o : (Collection<?>) v) {
                            String id = this.idOf(o);
                            if (id != null) out.putIfAbsent(id, 1);
                        }
                    }
                } catch (Throwable ignored) {}
            }
        }
    }

    private void startRestock(List<String> items, long now) {
        this.setCorz(false);
        this.phase = PH_RESTOCK;
        this.rsQueue.clear();
        this.rsQueue.addAll(items);
        this.rsState   = RS_NEXT;
        this.rsNextAt  = now;
        this.rsAttempts = 0;
        String msg = "Hết nguyên liệu: " + String.join(", ", items) + " -> dừng builder, lên /ah mua rẻ nhất.";
        this.log(msg);
        this.chat("[Auto Builder] " + msg);
        this.saveProgress("Hết nguyên liệu", String.join(", ", items), true);
    }

    private void restockTick(long now) {
        Object player = this.field(this.mc(), "field_1724");
        if (player == null) return;
        switch (this.rsState) {
            case RS_NEXT: {
                if (now < this.rsNextAt) return;
                if (this.rsQueue.isEmpty()) { this.finishRestock(now); return; }
                if (this.rsBuys >= this.maxBuys.getInt()) {
                    this.abort("Hết nguyên liệu", "đã đạt giới hạn " + this.maxBuys.getInt() + " lượt mua / phiên", false);
                    return;
                }
                this.rsItem  = this.rsQueue.get(0);
                this.rsHave  = this.snapshot(player).getOrDefault(this.rsItem, 0);
                String cmd   = this.ahCommand.getValue().replace("{item}", this.rsItem.replace('_', ' ')).trim();
                if (cmd.startsWith("/")) cmd = cmd.substring(1);
                if (!this.sendCommand(cmd)) {
                    this.abort("Hết nguyên liệu", "không gửi được lệnh /" + cmd, false);
                    return;
                }
                this.log("Mua '" + this.rsItem + "' bằng lệnh: /" + cmd);
                this.rsState  = RS_LIST;
                this.rsStateAt = now;
                return;
            }
            case RS_LIST: {
                Object screen = this.handledScreen();
                if (screen != null && now - this.rsStateAt >= GUI_DELAY_MS) {
                    // v3.1-A: pick CHEAPEST slot instead of first slot
                    int idx = this.findCheapestSlot(screen, player, Collections.singleton(this.rsItem));
                    if (idx >= 0) {
                        this.clickSlot(screen, idx, 0, "field_7790");
                        this.rsState   = RS_CONFIRM;
                        this.rsStateAt = now;
                        return;
                    }
                }
                if (now - this.rsStateAt > RS_TIMEOUT_MS)
                    this.restockFail("không thấy '" + this.rsItem + "' trong /ah", screen, now);
                return;
            }
            case RS_CONFIRM: {
                Object screen = this.handledScreen();
                if (this.snapshot(player).getOrDefault(this.rsItem, 0) > this.rsHave) {
                    this.restockBought(now); return;
                }
                if (screen != null && now - this.rsStateAt >= GUI_DELAY_MS) {
                    int idx = this.findCheapestSlot(screen, player,
                            new HashSet<>(this.parseIds(this.confirmItems.getValue())));
                    if (idx >= 0) {
                        this.clickSlot(screen, idx, 0, "field_7790");
                        this.rsState   = RS_BOUGHT;
                        this.rsStateAt = now;
                        return;
                    }
                }
                if (now - this.rsStateAt > RS_TIMEOUT_MS)
                    this.restockFail("không thấy nút xác nhận mua", screen, now);
                return;
            }
            case RS_BOUGHT: {
                if (this.snapshot(player).getOrDefault(this.rsItem, 0) > this.rsHave) {
                    this.restockBought(now); return;
                }
                if (now - this.rsStateAt > RS_TIMEOUT_MS)
                    this.restockFail("đã bấm xác nhận nhưng inventory không tăng", this.handledScreen(), now);
                return;
            }
            default: return;
        }
    }

    private void restockBought(long now) {
        this.closeScreen();
        ++this.rsBuys;
        this.rsAttempts = 0;
        if (!this.rsQueue.isEmpty()) this.rsQueue.remove(0);
        this.log("Đã mua '" + this.rsItem + "' (rẻ nhất, lượt " + this.rsBuys + ").");
        this.chat("[Auto Builder] Đã mua " + this.rsItem + " (giá rẻ nhất).");
        this.rsState  = RS_NEXT;
        this.rsNextAt = now + 1_500L;
    }

    private void restockFail(String why, Object screen, long now) {
        this.dumpScreen(screen, player());
        this.closeScreen();
        ++this.rsAttempts;
        this.log("Mua '" + this.rsItem + "' lỗi (lần " + this.rsAttempts + "/" + RS_MAX_ATTEMPTS + "): " + why);
        if (this.rsAttempts >= RS_MAX_ATTEMPTS) {
            this.abort("Hết nguyên liệu, không mua được '" + this.rsItem + "'", why, false);
            return;
        }
        this.rsState  = RS_NEXT;
        this.rsNextAt = now + 2_500L;
    }

    private void finishRestock(long now) {
        this.closeScreen();
        String msg = "Đã mua xong, tiếp tục build.";
        this.log(msg);
        this.chat("[Auto Builder] " + msg);
        this.resumeCorz(now);
    }

    private Object player() { return this.field(this.mc(), "field_1724"); }

    // ═════════════════════════════════════════════════════════════════════
    //  HAZARDS (unchanged from v3, kept in full)
    // ═════════════════════════════════════════════════════════════════════

    private static final class Cell {
        int x, y, z;
        String kind;
        double d;
    }

    private static boolean isKind(String s, String id) { return s.startsWith("Block{minecraft:" + id + "}"); }
    private static boolean isAir(String s) { return isKind(s, "air") || isKind(s, "cave_air") || isKind(s, "void_air"); }

    private Constructor<?> posCtor;

    private Object blockPos(int x, int y, int z) {
        try {
            if (this.posCtor == null) this.posCtor = Class.forName("net.minecraft.class_2338").getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE);
            return this.posCtor.newInstance(x, y, z);
        } catch (Throwable t) { return null; }
    }

    private String stateAt(Object world, int x, int y, int z) {
        Object st = this.invoke(world, n("method_8320"), this.blockPos(x, y, z));
        return st == null ? "" : st.toString();
    }

    private List<Cell> scanHazards(Object world, Object player) {
        List<Cell> out = new ArrayList<>();
        double px = this.x(player), py = this.y(player), pz = this.z(player);
        int bx = (int) Math.floor(px), by = (int) Math.floor(py), bz = (int) Math.floor(pz);
        int r = this.hazardRadius.getInt();
        boolean water = this.hzWater.get();
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                for (int dy = -1; dy <= 2; ++dy) {
                    String s = this.stateAt(world, bx+dx, by+dy, bz+dz);
                    String kind = isKind(s, "lava") ? "lava" : (water && isKind(s, "water") ? "water" : null);
                    if (kind != null) out.add(this.cell(bx+dx, by+dy, bz+dz, kind, px, py, pz));
                }
            }
        }
        if (this.hzHoles.get()) {
            int drop = this.maxDrop.getInt();
            for (int dx = -1; dx <= 1; ++dx) {
                for (int dz = -1; dz <= 1; ++dz) {
                    boolean hole = true;
                    for (int k = 1; k <= drop; ++k) {
                        if (!isAir(this.stateAt(world, bx+dx, by-k, bz+dz))) { hole = false; break; }
                    }
                    if (hole) out.add(this.cell(bx+dx, by-1, bz+dz, "hole", px, py, pz));
                }
            }
        }
        out.sort((a, b) -> {
            int ka = a.kind.equals("lava") ? 0 : (a.kind.equals("water") ? 1 : 2);
            int kb = b.kind.equals("lava") ? 0 : (b.kind.equals("water") ? 1 : 2);
            return ka != kb ? Integer.compare(ka, kb) : Double.compare(a.d, b.d);
        });
        return out;
    }

    private Cell cell(int x, int y, int z, String kind, double px, double py, double pz) {
        Cell c = new Cell(); c.x = x; c.y = y; c.z = z; c.kind = kind;
        double dx = x+0.5-px, dy = y+0.5-py, dz = z+0.5-pz;
        c.d = Math.sqrt(dx*dx + dy*dy + dz*dz);
        return c;
    }

    private String describeHazards(List<Cell> hz, boolean inFluid) {
        int lava = 0, water = 0, holes = 0; double nearest = Double.MAX_VALUE;
        for (Cell c : hz) {
            if (c.kind.equals("lava")) ++lava; else if (c.kind.equals("water")) ++water; else ++holes;
            nearest = Math.min(nearest, c.d);
        }
        List<String> p = new ArrayList<>();
        if (inFluid)  p.add("đang đứng trong chất lỏng");
        if (lava > 0) p.add("lava x" + lava);
        if (water> 0) p.add("nước x" + water);
        if (holes> 0) p.add("hố sâu x" + holes);
        String s = String.join(", ", p);
        if (nearest < Double.MAX_VALUE) s += String.format(Locale.ROOT, " (gần nhất %.1f block)", nearest);
        return s;
    }

    private void runHazards(long now) {
        if (!this.hazardGuard.get()) return;
        if (this.keysDown && now >= this.avoidUntil) this.releaseKeys();
        if (this.phase == PH_RUN && now - this.lastHazardScan < 200L) return;
        this.lastHazardScan = now;
        Object mc = this.mc(), world = this.field(mc, "field_1687"), player = this.field(mc, "field_1724");
        if (world == null || player == null) return;
        int bx = (int) Math.floor(this.x(player)), by = (int) Math.floor(this.y(player)), bz = (int) Math.floor(this.z(player));
        String feet = this.stateAt(world, bx, by, bz);
        if (feet.isEmpty()) {
            if (!this.warnedNoBlockApi) { this.warnedNoBlockApi = true; this.log("Hazard Guard: không đọc được block -> không phát hiện được nguy hiểm."); }
            return;
        }
        boolean inFluid = isKind(feet, "lava") || (this.hzWater.get() && isKind(feet, "water"));
        List<Cell> hz = this.scanHazards(world, player);
        hz.removeIf(c -> this.cellTries.getOrDefault(c.x + "," + c.y + "," + c.z, 0) >= 3);
        if (hz.isEmpty() && !inFluid) {
            if (this.phase == PH_HAZARD) {
                this.releaseKeys();
                String msg = "Đã xử lý xong nguy hiểm (đã lấp " + this.fills + ") - tiếp tục build.";
                this.log(msg); this.chat("[Auto Builder] " + msg);
                this.resumeCorz(now);
            }
            return;
        }
        String mode = this.hazardAction.get();
        String desc = this.describeHazards(hz, inFluid);
        if (this.phase == PH_RUN) {
            if (HZ_STOP.equals(mode)) { this.abort("Phát hiện nguy hiểm", desc, false); return; }
            this.phase = PH_HAZARD; this.hazardSince = now; this.fillFails = 0;
            this.setCorz(false);
            String msg = "Phát hiện nguy hiểm: " + desc + " -> tạm dừng builder.";
            this.log(msg); this.chat("[Auto Builder] " + msg);
        }
        if (now - this.hazardSince > 45_000L) { this.abort("Không xử lý được nguy hiểm", desc, false); return; }
        boolean canFill  = HZ_FILL.equals(mode) || HZ_BOTH.equals(mode);
        boolean canAvoid = HZ_AVOID.equals(mode) || HZ_BOTH.equals(mode);
        if (this.keysDown) return;
        boolean acted = false;
        if (canFill && !inFluid && now >= this.nextFillAt) {
            if (this.fills >= this.maxFills.getInt()) { this.abort("Quá nhiều nguy hiểm", "đã lấp " + this.fills + " ô, còn: " + desc, false); return; }
            for (Cell c : hz) {
                if (this.fill(mc, world, player, c)) {
                    acted = true; ++this.fills; this.fillFails = 0;
                    this.nextFillAt = now + 250L;
                    this.cellTries.merge(c.x + "," + c.y + "," + c.z, 1, Integer::sum);
                    break;
                }
            }
            if (!acted) ++this.fillFails;
        }
        if (!acted && now >= this.nextAvoidAt && (canAvoid && (inFluid || this.fillFails >= 2 || !canFill))) {
            this.avoid(player, hz, inFluid, now); return;
        }
        if (!acted && !canAvoid && this.fillFails >= 6) this.abort("Không lấp được nguy hiểm", desc + " (thiếu block lấp / ngoài tầm với)", false);
    }

    private boolean fill(Object mc, Object world, Object player, Cell c) {
        double ex = this.x(player), ey = this.y(player) + 1.62, ez = this.z(player);
        double dx = c.x+0.5-ex, dy = c.y+0.5-ey, dz = c.z+0.5-ez;
        if (dx*dx + dy*dy + dz*dz > 4.4*4.4) return false;
        if (!this.selectFillBlock(mc, player)) return false;
        try {
            Object pos = this.blockPos(c.x, c.y, c.z);
            Object vec = Class.forName("net.minecraft.class_243").getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(c.x+0.5, c.y+0.5, c.z+0.5);
            Object up  = this.enumConst("net.minecraft.class_2350", "field_11036");
            Class<?> hitCls = Class.forName("net.minecraft.class_3965");
            Object hit = hitCls.getConstructor(vec.getClass(), up.getClass(), pos.getClass(), Boolean.TYPE).newInstance(vec, up, pos, Boolean.FALSE);
            Object hand = this.enumConst("net.minecraft.class_1268", "field_5808");
            Object im = this.field(mc, "field_1761");
            this.invokeRaw(im, n("method_2911"));
            Object r = this.invokeRaw(im, n("method_2896"), player, hand, hit);
            if (r == FAIL) r = this.invokeRaw(im, n("method_2896"), player, world, hand, hit);
            if (r == FAIL) return false;
            this.invoke(player, n("method_6104"), hand);
            return true;
        } catch (Throwable t) { return false; }
    }

    private boolean selectFillBlock(Object mc, Object player) {
        Set<String> ids = new HashSet<>(this.parseIds(this.fillBlocks.getValue()));
        Object inv = this.invoke(player, n("method_31548"));
        if (inv == null || ids.isEmpty()) return false;
        for (int i = 0; i < 9; ++i) {
            if (ids.contains(this.idOf(this.invoke(inv, n("method_5438"), i)))) { this.setField(inv, "field_7545", i); return true; }
        }
        for (int i = 9; i < 36; ++i) {
            if (!ids.contains(this.idOf(this.invoke(inv, n("method_5438"), i)))) continue;
            Object sel = this.field(inv, "field_7545");
            int dst = sel instanceof Number ? ((Number) sel).intValue() : 0;
            if (dst < 0 || dst > 8) dst = 0;
            Object handler = this.field(player, "field_7498");
            Object sync = this.field(handler, "field_7763");
            Object im = this.field(mc, "field_1761");
            Object r = this.invokeRaw(im, n("method_2906"), sync instanceof Number ? ((Number)sync).intValue() : 0, i, dst, this.enumConst("net.minecraft.class_1713", "field_7791"), player);
            if (r == FAIL) return false;
            this.setField(inv, "field_7545", dst);
            return true;
        }
        return false;
    }

    private void avoid(Object player, List<Cell> hz, boolean inFluid, long now) {
        double px = this.x(player), pz = this.z(player), cx = 0, cz = 0;
        for (Cell c : hz) { cx += c.x+0.5; cz += c.z+0.5; }
        double ax = 0, az = 1;
        if (!hz.isEmpty()) {
            cx /= hz.size(); cz /= hz.size(); ax = px-cx; az = pz-cz;
            if (ax*ax + az*az < 1e-4) { ax = 0; az = 1; }
        }
        float yaw = (float) Math.toDegrees(Math.atan2(-ax, az));
        this.invoke(player, n("method_36456"), yaw);
        this.pressKey("field_1894", true);
        if (inFluid) this.pressKey("field_1903", true);
        this.keysDown   = true;
        this.avoidUntil = now + 600L;
        this.nextAvoidAt = now + 1_100L;
    }

    private void pressKey(String optionsField, boolean pressed) {
        Object opts = this.field(this.mc(), "field_1690");
        Object key  = this.field(opts, optionsField);
        this.invoke(key, n("method_23481"), pressed);
    }

    private void releaseKeys() {
        if (!this.keysDown) return;
        this.keysDown = false;
        this.pressKey("field_1894", false);
        this.pressKey("field_1903", false);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  ABORT / SAVE / RESUME (unchanged from v3)
    // ═════════════════════════════════════════════════════════════════════

    private void abort(String title, String detail, boolean leave) {
        String msg = "[Auto Builder] " + title + (detail.isEmpty() ? "" : ": " + detail);
        boolean wasRestock = this.phase == PH_RESTOCK;
        this.running  = false;
        this.phase    = PH_RUN;
        this.restartAt = 0L;
        this.wasInterrupted = true;
        this.releaseKeys();
        this.releaseSneakKey();
        if (wasRestock) this.closeScreen();
        this.log(msg);
        this.chat(msg);
        this.setCorz(false);
        this.saveProgress(title, detail, true);
        this.requestDisable();
        if (leave && MODE_DISCONNECT.equals(this.onTrigger.get())) {
            if (!this.disconnect(msg + "\nTiến trình đã được lưu.")) this.log("Không thể tự thoát server.");
        }
    }

    private Object clearSaved() {
        boolean ok = PROGRESS_FILE.delete();
        this.chat("[Auto Builder] " + (ok ? "Đã xóa tiến trình đã lưu." : "Không có tiến trình nào để xóa."));
        return null;
    }

    private void saveProgress(String reason, String detail, boolean interrupted) {
        if (this.corz == null || !this.saveProgress.get()) return;
        this.lastSaveMs = System.currentTimeMillis();
        try {
            JsonObject root = new JsonObject();
            root.addProperty("savedAt", this.now());
            root.addProperty("savedAtMs", System.currentTimeMillis());
            root.addProperty("reason", reason);
            root.addProperty("detail", detail);
            root.addProperty("interrupted", interrupted);
            Object player = this.field(this.mc(), "field_1724");
            if (player != null) {
                JsonObject pos = new JsonObject();
                pos.addProperty("x", this.x(player)); pos.addProperty("y", this.y(player)); pos.addProperty("z", this.z(player));
                root.add("player", pos);
            }
            JsonObject info = new JsonObject(), progress = new JsonObject();
            for (Class<?> c = this.corz.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    String name = f.getName();
                    try {
                        f.setAccessible(true);
                        Object v = f.get(this.corz);
                        if (v == null) continue;
                        if (INFO_YES.matcher(name).find() && !(v instanceof Collection) && !(v instanceof Map)) {
                            String s = String.valueOf(v);
                            info.addProperty(name, s.length() > 200 ? s.substring(0, 200) : s);
                        } else if (FP_YES.matcher(name).find() && !FP_NO.matcher(name).find()) {
                            if (v instanceof Number) progress.addProperty(name, (Number) v);
                            else if (v instanceof Collection) progress.addProperty(name, ((Collection<?>) v).size());
                            else if (v instanceof Map) progress.addProperty(name, ((Map<?, ?>) v).size());
                        }
                    } catch (Throwable ignored) {}
                }
            }
            root.add("info", info); root.add("progress", progress);
            JsonObject settings = new JsonObject();
            Object list = this.call(this.corz, "getSettings", new Class<?>[0]);
            if (list instanceof List) {
                for (Object s : (List<?>) list) {
                    String kind = kind(s);
                    if (kind.isEmpty() || kind.equals("button")) continue;
                    Object nm = this.call(s, "getSettingName", new Class<?>[0]);
                    JsonElement v = this.json(s);
                    if (nm != null && v != null) settings.add(nm.toString(), v);
                }
            }
            root.add("settings", settings);
            DIR.mkdirs();
            Files.write(PROGRESS_FILE.toPath(), new GsonBuilder().setPrettyPrinting().create().toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (Throwable t) { System.err.println("Kryzex: Auto Builder - save progress failed: " + t); }
    }

    private void resumeIfSaved() {
        if (!this.resumeSaved.get() || !PROGRESS_FILE.isFile()) return;
        try {
            JsonObject root = JsonParser.parseString(new String(Files.readAllBytes(PROGRESS_FILE.toPath()), StandardCharsets.UTF_8)).getAsJsonObject();
            if (!root.has("interrupted") || !root.get("interrupted").getAsBoolean()) return;
            if (root.has("savedAtMs") && System.currentTimeMillis() - root.get("savedAtMs").getAsLong() > RESUME_MAX_AGE_MS) {
                this.log("Tiến trình đã lưu quá 12 giờ -> bỏ qua."); return;
            }
            JsonObject saved = root.getAsJsonObject("settings");
            Object list = this.call(this.corz, "getSettings", new Class<?>[0]);
            int applied = 0;
            if (saved != null && list instanceof List) {
                for (Object s : (List<?>) list) {
                    String kind = kind(s);
                    if (kind.isEmpty() || kind.equals("button")) continue;
                    Object nm = this.call(s, "getSettingName", new Class<?>[0]);
                    if (nm == null || !saved.has(nm.toString())) continue;
                    JsonElement cur = this.json(s), old = saved.get(nm.toString());
                    if (cur != null && !cur.equals(old)) { this.apply(s, old); ++applied; }
                }
            }
            this.wasInterrupted = true;
            String why  = root.has("reason")   ? root.get("reason").getAsString()   : "?";
            String when = root.has("savedAt")   ? root.get("savedAt").getAsString()  : "?";
            String msg  = "[Auto Builder] Tiếp tục tiến trình đã lưu (" + when + ", dừng vì: " + why + "), khôi phục " + applied + " cài đặt.";
            if (root.has("player")) {
                JsonObject p = root.getAsJsonObject("player");
                Object player = this.field(this.mc(), "field_1724");
                if (player != null) {
                    double dx = this.x(player) - p.get("x").getAsDouble();
                    double dy = this.y(player) - p.get("y").getAsDouble();
                    double dz = this.z(player) - p.get("z").getAsDouble();
                    double d  = Math.sqrt(dx*dx + dy*dy + dz*dz);
                    if (d > 8.0) msg += String.format(Locale.ROOT, " Bạn cách vị trí cũ %.0f block.", d);
                }
            }
            this.log(msg); this.chat(msg);
        } catch (Throwable t) { System.err.println("Kryzex: Auto Builder - resume failed: " + t); }
    }

    private String now() { return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()); }

    private void log(String msg) {
        System.out.println("Kryzex: Auto Builder - " + msg);
        try {
            DIR.mkdirs();
            Files.write(LOG_FILE.toPath(), (this.now() + "  " + msg + System.lineSeparator()).getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Throwable ignored) {}
    }

    // ═════════════════════════════════════════════════════════════════════
    //  MC REFLECTION HELPERS (unchanged from v3)
    // ═════════════════════════════════════════════════════════════════════

    private static final Object FAIL = new Object();
    private static Method mcGetter;
    private final Map<String, Method> methodCache = new HashMap<>();

    private static String[] n(String... names) { return names; }

    private Object mc() {
        try {
            if (mcGetter == null) mcGetter = Class.forName("net.minecraft.class_310").getMethod("method_1551");
            return mcGetter.invoke(null);
        } catch (Throwable t) { return null; }
    }

    private Object invokeRaw(Object target, String[] names, Object... args) {
        if (target == null) return FAIL;
        for (String name : names) {
            String key = target.getClass().getName() + "#" + name + "/" + args.length;
            Method cached = this.methodCache.get(key);
            if (cached != null) {
                try { return cached.invoke(target, args); }
                catch (InvocationTargetException ite) { return FAIL; }
                catch (Throwable ignored) {}
            }
            for (Class<?> c = target.getClass(); c != null; c = c.getSuperclass()) {
                for (Method m : c.getDeclaredMethods()) {
                    if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                    try {
                        m.setAccessible(true);
                        Object r = m.invoke(target, args);
                        this.methodCache.put(key, m);
                        return r;
                    } catch (InvocationTargetException ite) { return FAIL; }
                    catch (Throwable ignored) {}
                }
            }
        }
        return FAIL;
    }

    private Object invoke(Object target, String[] names, Object... args) {
        Object r = this.invokeRaw(target, names, args);
        return r == FAIL ? null : r;
    }

    private Object enumConst(String className, String fieldName) {
        try { return Class.forName(className).getField(fieldName).get(null); }
        catch (Throwable t) { return null; }
    }

    private boolean setField(Object target, String name, Object value) {
        if (target == null) return false;
        for (Class<?> c = target.getClass(); c != null; c = c.getSuperclass()) {
            try { Field f = c.getDeclaredField(name); f.setAccessible(true); f.set(target, value); return true; }
            catch (Throwable ignored) {}
        }
        return false;
    }

    private double num(Object o, double fallback) { return o instanceof Number ? ((Number) o).doubleValue() : fallback; }

    private double x(Object e) { return this.num(this.invoke(e, n("method_23317")), 0.0); }
    private double y(Object e) { return this.num(this.invoke(e, n("method_23318")), 0.0); }
    private double z(Object e) { return this.num(this.invoke(e, n("method_23321")), 0.0); }

    private Object text(String msg) {
        try {
            Class<?> t = Class.forName("net.minecraft.class_2561");
            for (String name : n("method_43470", "method_30163")) {
                try { return t.getMethod(name, String.class).invoke(null, msg); }
                catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private void chat(String msg) {
        try {
            Object mc = this.mc(), player = this.field(mc, "field_1724"), text = this.text(msg);
            if (player == null || text == null) return;
            if (this.invokeRaw(player, n("method_7353"), text, Boolean.FALSE) != FAIL) return;
            Object hud = this.invoke(this.field(mc, "field_1705"), n("method_1743"));
            if (this.invokeRaw(hud, n("method_1812"), text) != FAIL) return;
            this.invokeRaw(player, n("method_43496"), text);
        } catch (Throwable ignored) {}
    }

    private boolean disconnect(String reason) {
        Object handler = this.invoke(this.mc(), n("method_1562"));
        Object conn = this.invoke(handler, n("method_48296", "method_2872"));
        Object text = this.text(reason);
        if (conn == null || text == null) return false;
        return this.invokeRaw(conn, n("method_10747"), text) != FAIL;
    }

    private boolean sendCommand(String cmd) {
        Object handler = this.invoke(this.mc(), n("method_1562"));
        if (handler == null) return false;
        if (this.invokeRaw(handler, n("method_45730"), cmd) != FAIL) return true;
        return this.invokeRaw(handler, n("method_45731"), cmd) != FAIL;
    }

    private Object handledScreen() {
        Object s = this.field(this.mc(), "field_1755");
        try { return s != null && Class.forName("net.minecraft.class_465").isInstance(s) ? s : null; }
        catch (Throwable t) { return null; }
    }

    private void closeScreen() {
        Object player = this.player();
        if (this.invokeRaw(player, n("method_7346")) == FAIL) this.invokeRaw(this.mc(), n("method_1507"), (Object) null);
    }

    private int findTopSlot(Object screen, Object player, Set<String> ids) {
        Object handler = this.invoke(screen, n("method_17577"));
        Object slots   = this.field(handler, "field_7761");
        Object pInv    = this.invoke(player, n("method_31548"));
        if (!(slots instanceof List)) return -1;
        List<?> list = (List<?>) slots;
        for (int i = 0; i < list.size(); ++i) {
            Object slot = list.get(i);
            if (slot == null || this.field(slot, "field_7871") == pInv) continue;
            String id = this.idOf(this.invoke(slot, n("method_7677")));
            if (id != null && ids.contains(id)) return i;
        }
        return -1;
    }

    private void clickSlot(Object screen, int slot, int button, String actionField) {
        Object handler = this.invoke(screen, n("method_17577"));
        Object sync    = this.field(handler, "field_7763");
        Object im      = this.field(this.mc(), "field_1761");
        this.invokeRaw(im, n("method_2906"), sync instanceof Number ? ((Number) sync).intValue() : 0, slot, button, this.enumConst("net.minecraft.class_1713", actionField), this.player());
    }

    private void dumpScreen(Object screen, Object player) {
        if (screen == null) { this.log("[dump] không có GUI nào đang mở."); return; }
        try {
            Object handler = this.invoke(screen, n("method_17577")), slots = this.field(handler, "field_7761");
            Object pInv = this.invoke(player, n("method_31548"));
            if (!(slots instanceof List)) return;
            StringBuilder sb = new StringBuilder("[dump] GUI slots: ");
            int shown = 0;
            for (int i = 0; i < ((List<?>) slots).size() && shown < 60; ++i) {
                Object slot = ((List<?>) slots).get(i);
                if (slot == null || this.field(slot, "field_7871") == pInv) continue;
                String id = this.idOf(this.invoke(slot, n("method_7677")));
                if (id == null || id.equals("air")) continue;
                sb.append(i).append('=').append(id).append(' '); ++shown;
            }
            this.log(sb.toString());
        } catch (Throwable ignored) {}
    }

    // --- items / inventory

    private List<String> parseIds(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String s : raw.split("[,;\\s]+")) {
            if (s.isEmpty()) continue;
            String id = s.toLowerCase(Locale.ROOT);
            int c = id.indexOf(':');
            if (c >= 0) id = id.substring(c + 1);
            if (!id.isEmpty()) out.add(id);
        }
        return out;
    }

    private String idOf(Object o) {
        if (o == null) return null;
        String s = String.valueOf(o).trim();
        int b = s.indexOf('{');
        if (b >= 0) { int e = s.indexOf('}', b); if (e > b) s = s.substring(b+1, e); }
        int sp = s.lastIndexOf(' ');
        if (sp >= 0) s = s.substring(sp+1);
        int c = s.indexOf(':');
        if (c >= 0) s = s.substring(c+1);
        s = s.toLowerCase(Locale.ROOT);
        return s.matches("[a-z0-9_]+") && !s.equals("air") ? s : null;
    }

    private Map<String, Integer> snapshot(Object player) {
        Map<String, Integer> out = new TreeMap<>();
        Object inv = this.invoke(player, n("method_31548")), size = this.invoke(inv, n("method_5439"));
        if (!(size instanceof Number)) return out;
        for (int i = 0; i < ((Number) size).intValue(); ++i) {
            Object stack = this.invoke(inv, n("method_5438"), i);
            String id = this.idOf(stack);
            if (id == null) continue;
            Object cnt = this.invoke(stack, n("method_7947"));
            out.merge(id, cnt instanceof Number ? ((Number) cnt).intValue() : 1, Integer::sum);
        }
        return out;
    }

    private int countTotems(Object player) {
        Object inv = this.invoke(player, n("method_31548")), size = this.invoke(inv, n("method_5439"));
        if (!(size instanceof Number)) return -1;
        int total = 0;
        for (int i = 0; i < ((Number) size).intValue(); ++i) {
            Object stack = this.invoke(inv, n("method_5438"), i);
            if (stack == null || !stack.toString().contains("totem_of_undying")) continue;
            Object cnt = this.invoke(stack, n("method_7947"));
            total += cnt instanceof Number ? ((Number) cnt).intValue() : 1;
        }
        return total;
    }

    // --- players

    private String nameOf(Object entity) {
        Object profile = this.invoke(entity, n("method_7334"));
        if (profile != null) { Object nm = this.invoke(profile, n("getName", "name")); if (nm != null) return nm.toString(); }
        Object t = this.invoke(entity, n("method_5477")), s = this.invoke(t, n("method_10851"));
        return s != null ? s.toString() : entity.getClass().getSimpleName();
    }

    private static final class Hit { String name; double dist; }

    private List<Hit> playersNear(Object self, Object world, double radius, boolean useIgnore) {
        List<Hit> out = new ArrayList<>();
        Object players = this.invoke(world, n("method_18456"));
        if (!(players instanceof List)) return out;
        Set<String> skip = useIgnore ? new HashSet<>(this.parseIds(this.ignoreList.getValue())) : new HashSet<>();
        double sx = this.x(self), sy = this.y(self), sz = this.z(self);
        for (Object p : (List<?>) players) {
            if (p == null || p == self) continue;
            if (Boolean.TRUE.equals(this.invoke(p, n("method_7325")))) continue;
            String nm = this.nameOf(p);
            if (skip.contains(nm.toLowerCase(Locale.ROOT))) continue;
            double dx = this.x(p)-sx, dy = this.y(p)-sy, dz = this.z(p)-sz;
            double d = Math.sqrt(dx*dx + dy*dy + dz*dz);
            if (d <= radius) { Hit h = new Hit(); h.name = nm; h.dist = d; out.add(h); }
        }
        out.sort((a, b) -> Double.compare(a.dist, b.dist));
        return out;
    }

    private String describePop(Object player, Object world, int left) {
        List<String> parts = new ArrayList<>();
        String dmg = this.damageCause(player);
        if (dmg != null) parts.add(dmg);
        List<Hit> near = this.playersNear(player, world, 24.0, false);
        if (!near.isEmpty()) parts.add(String.format(Locale.ROOT, "người chơi gần nhất \"%s\" cách %.1f block", near.get(0).name, near.get(0).dist));
        if (Boolean.TRUE.equals(this.invoke(player, n("method_5771")))) parts.add("đang đứng trong dung nham");
        else if (Boolean.TRUE.equals(this.invoke(player, n("method_5809")))) parts.add("đang bị cháy");
        if (this.num(this.field(player, "field_6017"), 0.0) > 3.0) parts.add("vừa rơi từ độ cao");
        if (parts.isEmpty()) parts.add("không xác định");
        double hp = this.num(this.invoke(player, n("method_6032")), -1.0);
        return String.format(Locale.ROOT, "còn %d totem, HP %.1f | %s", left, hp, String.join("; ", parts));
    }

    private String damageCause(Object player) {
        Object src = this.invoke(player, n("method_6081"));
        if (src == null) return null;
        String raw = String.valueOf(src);
        if (!raw.startsWith("DamageSource")) return null;
        int a = raw.indexOf('('), b = raw.lastIndexOf(')');
        String id = a >= 0 && b > a ? raw.substring(a+1, b).trim() : raw;
        String vn;
        switch (id) {
            case "lava": vn = "dung nham"; break; case "inFire": case "onFire": vn = "lửa"; break;
            case "hotFloor": vn = "khối magma"; break; case "drown": vn = "ngạt nước"; break;
            case "fall": vn = "ngã"; break; case "flyIntoWall": vn = "đâm vào tường khi bay"; break;
            case "explosion": case "explosion.player": vn = "vụ nổ"; break;
            case "player": vn = "bị người chơi đánh"; break; case "mob": vn = "bị mob đánh"; break;
            case "arrow": case "trident": case "thrown": vn = "bị bắn/ném trúng"; break;
            case "magic": case "indirectMagic": vn = "ma thuật/potion"; break;
            case "wither": vn = "hiệu ứng Wither"; break; case "starve": vn = "đói"; break;
            case "outOfWorld": vn = "rơi khỏi thế giới"; break; case "generic": vn = "sát thương chung"; break;
            default: vn = id; break;
        }
        Object attacker = this.invoke(src, n("method_5529"));
        if (attacker != null && attacker != player) vn += " - bởi \"" + this.nameOf(attacker) + "\"";
        return "sát thương: " + vn;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  CORZ ACCESS (reflection, unchanged)
    // ═════════════════════════════════════════════════════════════════════

    private Object findCorz() {
        try {
            Class<?> registry = Class.forName(REGISTRY), builder = Class.forName(AUTO_BUILDER);
            return registry.getMethod("getModule", Class.class).invoke(null, builder);
        } catch (Throwable t) { return null; }
    }

    private Object call(Object target, String name, Class<?>[] types, Object... args) {
        try { return target.getClass().getMethod(name, types).invoke(target, args); }
        catch (Throwable t) { return null; }
    }

    private Object field(Object target, String name) {
        if (target == null) return null;
        for (Class<?> clazz = target.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try { Field f = clazz.getDeclaredField(name); f.setAccessible(true); return f.get(target); }
            catch (Throwable ignored) {}
        }
        return null;
    }

    private double dbl(Object target, String name, double fallback) {
        Object v = this.field(target, name);
        return v instanceof Number ? ((Number) v).doubleValue() : fallback;
    }

    private JsonElement json(Object setting) {
        Object v = this.call(setting, "getJsonValue", new Class<?>[0]);
        return v instanceof JsonElement ? (JsonElement) v : null;
    }

    private void apply(Object setting, JsonElement element) {
        this.call(setting, "applyJsonValue", new Class<?>[]{JsonElement.class}, element);
    }

    private static String kind(Object setting) {
        for (Class<?> c = setting.getClass(); c != null; c = c.getSuperclass()) {
            switch (c.getSimpleName()) {
                case "ButtonBase": return "button";   case "BooleanSetting": return "bool";
                case "IntegerSetting": return "int";  case "DoubleSetting": return "double";
                case "EnumSetting": return "enum";    case "RangeSetting": return "range";
                case "StringBase": return "string";   case "ColorSetting": return "color";
            }
        }
        return "";
    }

    // ═════════════════════════════════════════════════════════════════════
    //  SETTINGS MIRROR (unchanged from v3, SHOW list updated)
    // ═════════════════════════════════════════════════════════════════════

    private static final class Mirror {
        Supplier<String> kzGet; Consumer<String> kzSet;
        Supplier<String> corzGet; Consumer<String> corzSet;
        String lastKz, lastCorz;
    }

    private static boolean same(String a, String b) {
        if (a == null || b == null) return a == b;
        if (a.equals(b)) return true;
        try {
            if (a.indexOf('|') >= 0 && b.indexOf('|') >= 0) {
                String[] x = a.split("\\|"), y = b.split("\\|");
                if (x.length != y.length) return false;
                for (int i = 0; i < x.length; ++i) if (Math.abs(Double.parseDouble(x[i]) - Double.parseDouble(y[i])) > 1e-3) return false;
                return true;
            }
            return Math.abs(Double.parseDouble(a) - Double.parseDouble(b)) <= 1e-3;
        } catch (NumberFormatException e) { return false; }
    }

    private String uniqueId(String name) {
        String base = "ab-" + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-");
        String id = base; int n = 2;
        while (!this.usedIds.add(id)) id = base + "-" + n++;
        return id;
    }

    private void ensureMirrored() {
        if (this.mirrored) return;
        this.corz = this.findCorz();
        if (this.corz == null) return;
        Object list = this.call(this.corz, "getSettings", new Class<?>[0]);
        if (!(list instanceof List)) return;
        this.mirrored = true;
        List<Object> ordered = new ArrayList<>((List<?>) list);
        ordered.removeIf(o -> this.priority(o) == Integer.MAX_VALUE);
        ordered.sort((a, b) -> Integer.compare(this.priority(a), this.priority(b)));
        for (Object setting : ordered) {
            try { this.mirrorOne(setting); }
            catch (Throwable t) { System.err.println("Kryzex: Auto Builder - could not mirror: " + t); }
        }
    }

    private static final List<String> SHOW = java.util.Arrays.asList(
        "Open Folder", "Refresh", "Preview Schematic", "Cancel Preview", "Origin: Player", "Origin: Looking",
        "Buy Materials", "Auto-Buy Key", "Buy Mode", "Spending Limit Per Item", "Spending Limit Per Buy", "Max Total Spend",
        "Fast Place (V3)", "Fast Place Delay (ms)", "Places / Tick", "Placement Delay", "Reach", "V2Speed",
        "Human Flow (V3)", "Human Flow Level %",
        "Auto Eat", "Eat At"
    );

    private int priority(Object setting) {
        Object n = this.call(setting, "getSettingName", new Class<?>[0]);
        int i = n == null ? -1 : SHOW.indexOf(n.toString());
        return i < 0 ? Integer.MAX_VALUE : i;
    }

    private void mirrorOne(Object s) {
        String kind = kind(s);
        if (kind.isEmpty()) return;
        Object hidden = this.call(s, "isHiddenFromList", new Class<?>[0]);
        if (hidden instanceof Boolean && (Boolean) hidden) return;
        Object nameObj = this.call(s, "getSettingName", new Class<?>[0]);
        String name = nameObj == null ? "Setting" : nameObj.toString();
        if (kind.equals("button")) {
            this.addSetting(this.uniqueId(name), new MacroActionSetting(name, () -> this.call(s, "updateAction", new Class<?>[0])));
            return;
        }
        JsonElement cur = this.json(s);
        if (cur == null) return;
        Mirror m = new Mirror();
        switch (kind) {
            case "bool": {
                MacroBoolSetting kz = this.addSetting(this.uniqueId(name), new MacroBoolSetting(name, cur.getAsBoolean()));
                m.kzGet = () -> String.valueOf(kz.get()); m.kzSet = v -> kz.set(Boolean.parseBoolean(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsBoolean()); m.corzSet = v -> this.apply(s, new JsonPrimitive(Boolean.parseBoolean(v)));
                break;
            }
            case "int": {
                int min = ((Number) this.call(s, "getMinValue", new Class<?>[0])).intValue();
                int max = ((Number) this.call(s, "getMaxValue", new Class<?>[0])).intValue();
                int step = ((Number) this.call(s, "getStepSize", new Class<?>[0])).intValue();
                MacroNumberSetting kz = this.addSetting(this.uniqueId(name), new MacroNumberSetting(name, cur.getAsInt(), min, max).step(Math.max(1, step)));
                m.kzGet = () -> String.valueOf(kz.getInt()); m.kzSet = v -> kz.set((float) Double.parseDouble(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsInt()); m.corzSet = v -> this.apply(s, new JsonPrimitive((int) Math.round(Double.parseDouble(v))));
                break;
            }
            case "double": {
                double min = this.dbl(s, "minValue", 0.0), max = this.dbl(s, "maxValue", 100.0), step = this.dbl(s, "stepSize", 0.1);
                MacroNumberSetting kz = this.addSetting(this.uniqueId(name), new MacroNumberSetting(name, (float) cur.getAsDouble(), (float) min, (float) max).step((float) step));
                m.kzGet = () -> String.valueOf(kz.get()); m.kzSet = v -> kz.set((float) Double.parseDouble(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsDouble()); m.corzSet = v -> this.apply(s, new JsonPrimitive(Double.parseDouble(v)));
                break;
            }
            case "enum": {
                Object opts = this.call(s, "getOptions", new Class<?>[0]);
                List<String> options = new ArrayList<>();
                if (opts instanceof List) for (Object o : (List<?>) opts) options.add(String.valueOf(o));
                if (options.isEmpty()) return;
                MacroModeSetting kz = this.addSetting(this.uniqueId(name), new MacroModeSetting(name, cur.getAsString(), options.toArray(new String[0])));
                m.kzGet = kz::get; m.kzSet = kz::set;
                m.corzGet = () -> this.json(s).getAsString(); m.corzSet = v -> this.apply(s, new JsonPrimitive(v));
                break;
            }
            case "range": {
                double rMin = this.dbl(s, "rangeMin", 0.0), rMax = this.dbl(s, "rangeMax", 100.0), step = this.dbl(s, "step", 0.1);
                JsonObject o = cur.getAsJsonObject();
                MacroNumberSetting lo = this.addSetting(this.uniqueId(name + " min"), new MacroNumberSetting(name + " (min)", (float) o.get("min").getAsDouble(), (float) rMin, (float) rMax).step((float) step));
                MacroNumberSetting hi = this.addSetting(this.uniqueId(name + " max"), new MacroNumberSetting(name + " (max)", (float) o.get("max").getAsDouble(), (float) rMin, (float) rMax).step((float) step));
                m.kzGet = () -> lo.get() + "|" + hi.get(); m.kzSet = v -> { String[] p = v.split("\\|"); lo.set((float) Double.parseDouble(p[0])); hi.set((float) Double.parseDouble(p[1])); };
                m.corzGet = () -> { JsonObject c = this.json(s).getAsJsonObject(); return c.get("min").getAsDouble() + "|" + c.get("max").getAsDouble(); };
                m.corzSet = v -> { String[] p = v.split("\\|"); JsonObject c = new JsonObject(); c.addProperty("min", Double.parseDouble(p[0])); c.addProperty("max", Double.parseDouble(p[1])); this.apply(s, c); };
                break;
            }
            case "string": {
                StringSetting kz = new StringSetting(SecureString.of(name), cur.getAsString());
                super.addSetting(kz);
                m.kzGet = kz::getValue; m.kzSet = kz::setValue;
                m.corzGet = () -> this.json(s).getAsString(); m.corzSet = v -> this.apply(s, new JsonPrimitive(v));
                break;
            }
            case "color": {
                MacroColorSetting kz = this.addSetting(this.uniqueId(name), new MacroColorSetting(name, cur.getAsInt()));
                m.kzGet = () -> String.valueOf(kz.argb()); m.kzSet = v -> kz.setArgb(Integer.parseInt(v));
                m.corzGet = () -> String.valueOf(this.json(s).getAsInt()); m.corzSet = v -> this.apply(s, new JsonPrimitive(Integer.parseInt(v)));
                break;
            }
            default: return;
        }
        m.lastKz = m.kzGet.get(); m.lastCorz = m.corzGet.get();
        this.mirrors.add(m);
    }

    private void sync() {
        for (Mirror m : this.mirrors) {
            try {
                String kz = m.kzGet.get(), cz = m.corzGet.get();
                if (!same(kz, m.lastKz)) { m.corzSet.accept(kz); cz = m.corzGet.get(); m.lastKz = kz; m.lastCorz = cz; }
                else if (!same(cz, m.lastCorz)) { m.kzSet.accept(cz); m.lastKz = m.kzGet.get(); m.lastCorz = cz; }
            } catch (Throwable ignored) {}
        }
    }
}
