package kryzex.modules.macros;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroActionSetting;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroItemSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.macros.h.Sell;
import kryzex.modules.misc.MacroModule;
import kryzex.util.KryzexClient;
import kryzex.util.SecureString;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2390;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_1735;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Auto Mine Sell.
 *
 * Mines every Target Block inside the area between two corners (or around you), and when the inventory is full it
 * pauses, sells the Sell Items through /order (best price first, /sell as a fallback), then goes back to mining.
 */
@Environment(value=EnvType.CLIENT)
public final class AutoMineSell
extends MacroModule {
    private enum SellState { IDLE, WAIT_LIST, WAIT_PAGE, WAIT_DEPOSIT, HUGO, CONFIRM, FINISH, SETTLE, NEXT }

    private static final Pattern PRICE_PATTERN = Pattern.compile("([0-9][0-9,]*(?:\\.[0-9]+)?)([kKmMbBtT]?)(?![A-Za-z])");
    private static final HttpClient WEBHOOK_CLIENT = HttpClient.newHttpClient();
    private static final long TARGET_SCAN_LIMIT = 8_000_000L;

    // ---------------------------------------------------------------- Mining settings
    private final MacroBoolSetting hugoMode = this.addSetting("hugo-mode", new MacroBoolSetting("Hugo Mode (gold button -> green button)", true));
    private final MacroBoolSetting mineWithoutArea = this.addSetting("mine-without-area", new MacroBoolSetting("Mine Without Area", false));
    private final MacroNumberSetting scanRange = this.addSetting("scan-range", new MacroNumberSetting("Scan Range", 32.0f, 8.0f, 96.0f).step(1.0f));
    private final MacroItemSetting targetBlocks = this.addSetting("target-blocks", new MacroItemSetting("Target Blocks", new String[0]).itemPicker());
    private final MacroNumberSetting reach = this.addSetting("reach", new MacroNumberSetting("Reach", 4.5f, 3.0f, 5.0f).step(0.1f));
    private final MacroNumberSetting toolSlot = this.addSetting("tool-slot", new MacroNumberSetting("Tool Hotbar Slot (0 = off)", 0.0f, 0.0f, 9.0f).step(1.0f));
    private final MacroNumberSetting aimSpeed = this.addSetting("aim-speed", new MacroNumberSetting("Aim Speed", 14.0f, 3.0f, 40.0f).step(1.0f));
    private final MacroBoolSetting nuker = this.addSetting("nuker", new MacroBoolSetting("Nuker (Meteor-style)", true));
    private final MacroNumberSetting nukerBlocksPerTick = this.addSetting("nuker-blocks-per-tick", new MacroNumberSetting("Nuker Blocks Per Tick", 6.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroNumberSetting nukerRange = this.addSetting("nuker-range", new MacroNumberSetting("Nuker Range", 4.5f, 1.0f, 6.0f).step(0.1f));
    private final MacroBoolSetting nukerOnlyExposed = this.addSetting("nuker-only-exposed", new MacroBoolSetting("Nuker Only Exposed", true));
    private final MacroBoolSetting nukerRotate = this.addSetting("nuker-rotate", new MacroBoolSetting("Nuker Rotate", false));
    private final MacroBoolSetting followMining = this.addSetting("follow-mining", new MacroBoolSetting("Look At Mined Block (camera follows mining)", true));
    private final MacroBoolSetting autoLoot = this.addSetting("auto-loot", new MacroBoolSetting("Auto Loot", true));
    private final MacroNumberSetting lootRange = this.addSetting("loot-range", new MacroNumberSetting("Loot Range", 10.0f, 3.0f, 32.0f).step(1.0f));
    private final MacroBoolSetting lootWhileMining = this.addSetting("loot-while-mining", new MacroBoolSetting("Mine While Looting", true));
    private final MacroNumberSetting lootTimeout = this.addSetting("loot-timeout", new MacroNumberSetting("Loot Give Up (s)", 4.0f, 1.0f, 15.0f).step(1.0f));
    private final MacroActionSetting corner1Feet = this.addSetting("corner1-feet", new MacroActionSetting("Corner 1 -> Feet", () -> this.setCornerFromPlayer(1, false)));
    private final MacroActionSetting corner1Looking = this.addSetting("corner1-looking", new MacroActionSetting("Corner 1 -> Looking", () -> this.setCornerFromPlayer(1, true)));
    private final MacroActionSetting corner2Feet = this.addSetting("corner2-feet", new MacroActionSetting("Corner 2 -> Feet", () -> this.setCornerFromPlayer(2, false)));
    private final MacroActionSetting corner2Looking = this.addSetting("corner2-looking", new MacroActionSetting("Corner 2 -> Looking", () -> this.setCornerFromPlayer(2, true)));

    // ---------------------------------------------------------------- Path / hazard settings
    private final MacroBoolSetting drawPath = this.addSetting("draw-path", new MacroBoolSetting("Draw Path", true));
    private final MacroNumberSetting pathLength = this.addSetting("path-length", new MacroNumberSetting("Path Length (blocks)", 20.0f, 5.0f, 60.0f).step(1.0f));
    private final MacroNumberSetting pathSize = this.addSetting("path-size", new MacroNumberSetting("Path Thickness", 0.4f, 0.1f, 1.0f).step(0.05f));
    private final MacroBoolSetting drawDir = this.addSetting("draw-direction", new MacroBoolSetting("Direction Line (thin)", true));
    private final MacroNumberSetting dirLength = this.addSetting("direction-length", new MacroNumberSetting("Direction Line Length", 12.0f, 3.0f, 40.0f).step(1.0f));
    private final MacroNumberSetting dirSize = this.addSetting("direction-thickness", new MacroNumberSetting("Direction Line Thickness", 0.25f, 0.05f, 0.6f).step(0.05f));
    private final MacroBoolSetting avoidHazards = this.addSetting("avoid-hazards", new MacroBoolSetting("Avoid Holes / Fluids (Sneak)", true));
    private final MacroBoolSetting escapeFluids = this.addSetting("escape-fluids", new MacroBoolSetting("Escape Water / Lava", true));
    private final MacroBoolSetting autoLevel = this.addSetting("auto-level", new MacroBoolSetting("Auto Place Blocks (pillar up + fall cushion)", true));
    private final MacroItemSetting levelBlocks = this.addSetting("level-blocks", new MacroItemSetting("Place Blocks (empty = any block in hotbar)", new String[0]).itemPicker());
    private final MacroBoolSetting dropDown = this.addSetting("drop-down", new MacroBoolSetting("Jump Down To Lower Targets", true));
    private final MacroNumberSetting maxDrop = this.addSetting("max-drop", new MacroNumberSetting("Max Drop Height (blocks)", 8.0f, 3.0f, 30.0f).step(1.0f));
    private final MacroNumberSetting cushionCount = this.addSetting("cushion-blocks", new MacroNumberSetting("Cushion Blocks (placed while falling)", 2.0f, 1.0f, 3.0f).step(1.0f));
    private final MacroBoolSetting safeMining = this.addSetting("safe-mining", new MacroBoolSetting("Safe Mining (skip blocks next to fluid)", true));

    // ---------------------------------------------------------------- Auto Sell settings
    private final MacroBoolSetting autoSell = this.addSetting("auto-sell", new MacroBoolSetting("Auto Sell", true));
    private final MacroItemSetting sellItems = this.addSetting("sell-items", new MacroItemSetting("Sell Items", new String[0]).itemPicker());
    private final StringSetting orderCommand = new StringSetting(SecureString.of("Order Command"), "order");
    private final MacroBoolSetting underscoreToSpace = this.addSetting("underscore-to-space", new MacroBoolSetting("Underscore To Space", true));
    private final MacroNumberSetting freeSlotsToSell = this.addSetting("free-slots-to-sell", new MacroNumberSetting("Free Slots To Sell", 0.0f, 0.0f, 10.0f).step(1.0f));
    private final MacroNumberSetting confirmSlot = this.addSetting("confirm-slot", new MacroNumberSetting("Confirm Slot", 53.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting sellDelay = this.addSetting("sell-delay", new MacroNumberSetting("Sell Delay", 350.0f, 100.0f, 3000.0f).step(10.0f));
    private final MacroNumberSetting sellTimeout = this.addSetting("sell-timeout", new MacroNumberSetting("Sell Menu Timeout", 8000.0f, 2000.0f, 30000.0f).step(100.0f));
    private final MacroBoolSetting bestPrice = this.addSetting("best-price", new MacroBoolSetting("Best Price", true));
    private final StringSetting priceKeyword = new StringSetting(SecureString.of("Price Line Contains"), "$");
    private final MacroNumberSetting minPrice = this.addSetting("min-price", new MacroNumberSetting("Min Price", 0.0f, 0.0f, 100000.0f).step(0.5f));
    private final MacroNumberSetting nextPageSlot = this.addSetting("next-page-slot", new MacroNumberSetting("Next Page Slot", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting maxPages = this.addSetting("max-pages", new MacroNumberSetting("Max Pages", 5.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroBoolSetting fallbackSell = this.addSetting("fallback-sell", new MacroBoolSetting("Fallback To Sell", true));
    private final MacroNumberSetting fallbackAfter = this.addSetting("fallback-after", new MacroNumberSetting("Fallback After", 10.0f, 1.0f, 30.0f).step(1.0f));
    private final StringSetting fallbackCommand = new StringSetting(SecureString.of("Sell Command"), "sell");
    private final MacroNumberSetting fallbackConfirmSlot = this.addSetting("fallback-confirm-slot", new MacroNumberSetting("Sell Confirm Slot", 53.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting hugoGoldSlot = this.addSetting("hugo-gold-slot", new MacroNumberSetting("Hugo Gold Slot (-1 = auto)", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting hugoGreenSlot = this.addSetting("hugo-green-slot", new MacroNumberSetting("Hugo Green Slot (-1 = auto)", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroBoolSetting randomDelay = this.addSetting("random-delay", new MacroBoolSetting("Random Delay", true));
    private final MacroNumberSetting delayJitter = this.addSetting("delay-jitter", new MacroNumberSetting("Delay Jitter %", 40.0f, 0.0f, 200.0f).step(5.0f));

    // ---------------------------------------------------------------- Safety / webhook settings
    private final MacroBoolSetting disconnectOnTotem = this.addSetting("leave-on-totem", new MacroBoolSetting("Leave On Totem Pop", true));
    private final MacroBoolSetting disconnectOnPlayer = this.addSetting("leave-on-player", new MacroBoolSetting("Leave On Player Nearby", true));
    private final MacroNumberSetting playerRange = this.addSetting("player-range", new MacroNumberSetting("Player Range", 48.0f, 8.0f, 128.0f).step(1.0f));
    private final StringSetting ignoredPlayers = new StringSetting(SecureString.of("Ignored Players"), "");
    private final StringSetting webhookUrl = new StringSetting(SecureString.of("Webhook URL"), "");
    private final StringSetting webhookPing = new StringSetting(SecureString.of("Webhook Ping"), "");
    private final MacroActionSetting testWebhook = this.addSetting("test-webhook", new MacroActionSetting("Test Webhook", () -> this.sendWebhookTest()));

    // ---------------------------------------------------------------- Auto Repair settings
    private final MacroBoolSetting autoRepair = this.addSetting("auto-repair", new MacroBoolSetting("Auto Repair (Mending + XP Bottles)", true));
    private final MacroNumberSetting repairBelow = this.addSetting("repair-below", new MacroNumberSetting("Repair Below Durability %", 8.0f, 1.0f, 50.0f).step(1.0f));
    private final MacroNumberSetting repairUntil = this.addSetting("repair-until", new MacroNumberSetting("Repair Until Durability %", 90.0f, 30.0f, 100.0f).step(5.0f));
    private final StringSetting shopCommand = new StringSetting(SecureString.of("Shop Command"), "shop");
    private final MacroNumberSetting shopCategorySlot = this.addSetting("shop-category-slot", new MacroNumberSetting("Shop Category Slot (-1 = auto)", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting shopAmountSlot = this.addSetting("shop-amount-slot", new MacroNumberSetting("Shop Amount Slot (-1 = none)", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroBoolSetting autoBuyFood = this.addSetting("auto-buy-food", new MacroBoolSetting("Auto Buy Food (/shop, when hotbar has none)", true));
    private final StringSetting shopFoodItem = new StringSetting(SecureString.of("Shop Food Item (id)"), "cooked_beef");
    private final MacroNumberSetting shopFoodCategorySlot = this.addSetting("shop-food-category-slot", new MacroNumberSetting("Shop Food Category Slot (-1 = auto)", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting shopBuyRepeats = this.addSetting("shop-buy-repeats", new MacroNumberSetting("Shop Buy Repeats", 1.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroNumberSetting repairMaxCycles = this.addSetting("repair-max-cycles", new MacroNumberSetting("Max Buy + Throw Cycles", 3.0f, 1.0f, 10.0f).step(1.0f));
    private final MacroBoolSetting stopWhenBreaking = this.addSetting("stop-when-breaking", new MacroBoolSetting("Stop If Tool Is About To Break", true));

    // ---------------------------------------------------------------- Auto Eat settings
    private final MacroBoolSetting autoEat = this.addSetting("auto-eat", new MacroBoolSetting("Auto Eat", true));
    private final MacroNumberSetting eatHungerBars = this.addSetting("eat-hunger-bars", new MacroNumberSetting("Eat When Hunger Lost (bars)", 2.0f, 1.0f, 10.0f).step(1.0f));
    private final MacroItemSetting foodItems = this.addSetting("food-items", new MacroItemSetting("Food Items (empty = common food)", new String[0]).itemPicker());

    // ---------------------------------------------------------------- Area / miner state
    private class_2338 corner1;
    private class_2338 corner2;
    private int minX, minY, minZ, maxX, maxY, maxZ;
    private boolean areaDefined;
    private class_2338 target;
    private int targetTicks;
    private int aimTicks;
    private int noTargetTicks;
    private int lastScanAge = -1000;
    private int lastMineAge = -1;
    private class_243 stuckCheckPos;
    private class_243 dirLast;
    private int dirLastAge = -1000;
    private int stuckTicks;
    private final Map<class_2338, Integer> skipped = new HashMap<>();
    private int targetTotal;
    private boolean wasMining;
    private int finalSellTries;
    private final Random random = new Random();
    private int blockedTicks;
    private int repositionTicks;
    private int repositions;
    private final Map<Integer, Integer> lootSkipped = new HashMap<>();
    private int lootTargetId = -1;
    private int lootTicks;
    private int lootMovingAge = -1;
    private class_243 lootStuckPos;
    private int lootStuckTicks;
    private double lootProgressDist = Double.MAX_VALUE;
    private int lootProgressTicks;
    private class_2338 nukerSlow;

    // path trail + hazard state
    private final ArrayDeque<class_243> trail = new ArrayDeque<>();
    private class_243 pathGoal;
    private boolean escaping;
    private int escapeTicks;
    private class_2338 escapeSpot;

    // ---------------------------------------------------------------- Sell state
    private SellState sellState = SellState.IDLE;
    private long sellNextActionAt;
    private long sellDeadline;
    private long sellRetryAt;
    private long sellListSeenAt;
    private int sellListSyncId = -1;
    private String sellListFingerprint = "";
    private String sellSearchTerm = "";
    private class_1792 sellTargetItem;
    private int sellPagesScanned;
    private int sellSessionStartCount;
    private int sellFailCount;
    private int sellConfirmClicks;
    private int sellConfirmSyncId = -1;
    private long sellConfirmClickedAt;
    private long sellConfirmDeadline;
    private int sellDepositSyncId = -1;
    private boolean sellClosedDeposit;
    private long sellSettleUntil;
    private long sellLastEndAt;
    private boolean sellFallbackMode;
    private int soldTotal;
    private int soldByFallback;
    private int ordersFilled;
    private boolean sellWarnedNoItems;
    private boolean hugoGoldClicked;
    private int hugoGreenClicks;
    private int hugoSyncId = -1;
    private int hugoRedSlot = -1;
    private String hugoRedPath = "";
    private long hugoClickedAt;
    private long hugoDeadline;
    private boolean safetyTriggered;
    private int lastTotemCount = -1;

    // ---------------------------------------------------------------- Repair / eat state
    private enum RepairState { IDLE, OPEN_SHOP, FIND_BOTTLE, BUY, EQUIP, THROW, FINISH, CHECK, FOOD_STOW }
    private static final Set<String> COMMON_FOODS = Set.of(
        "cooked_beef", "cooked_porkchop", "cooked_mutton", "cooked_chicken", "cooked_rabbit", "cooked_cod", "cooked_salmon",
        "bread", "baked_potato", "golden_carrot", "apple", "pumpkin_pie", "mushroom_stew", "beetroot_soup", "rabbit_stew",
        "golden_apple", "enchanted_golden_apple", "carrot", "melon_slice", "sweet_berries", "glow_berries", "cookie", "dried_kelp", "beef", "porkchop", "mutton");

    private RepairState repairState = RepairState.IDLE;
    private long repairNextAt;
    private long repairDeadline;
    private long repairRetryAt;
    private long repairSeenAt;
    private long repairBuyAt;
    private int repairSyncId = -1;
    private int repairDepth;
    private int repairBottlesBefore;
    private int repairBuysDone;
    private int repairConfirmClicks;
    private int repairCycles;
    private int repairKnownCategory = -1;
    private int repairLastCategory = -1;
    private int repairBottleSlot = -1;
    private int repairThrowTicks;
    private int repairEmptyTicks;
    private boolean repairAmountClicked;
    private boolean repairSwapped;
    private boolean repairPitchChanged;
    private class_1792 repairOldOffhand;
    private float repairPrevPitch;
    private final Set<Integer> repairTried = new HashSet<>();
    private int buyBtnBottle = -1;     // remembered "buy a stack" button slot (kept until the game restarts)
    private int buyBtnFood = -1;
    private int lastBuyClick = -1;
    private final Set<Integer> buyBad = new HashSet<>(); // buttons that bought less than a stack
    private boolean shopFood;          // the shop flow is buying food instead of XP bottles
    private static final Path MEMORY_FILE = Path.of("config", "auto-mine-sell-memory.properties");
    private static final int FAR_WINDOW = 64;
    private static final long FAR_FULL_LIMIT = 6_000_000L;
    private static final int NO_TARGET_LIMIT = 120;
    private int farScanAt;
    private int farHidden;
    private int farUnsafe;
    private int skipRetries;
    private int skipRetryMark = -1;
    private boolean pillaring;
    private int pillarCount;
    private int pillarTicks;
    private boolean levelWarned;
    private boolean cushionDone;
    private final Set<class_2338> placedBlocks = new HashSet<>(); // cushion blocks: mined again after landing
    private int foodKnownCategory = -1;
    private long foodBuyRetryAt;

    private boolean eating;
    private boolean eatSawUse;
    private boolean eatWarned;
    private long eatRetryAt;
    private int eatSlot;
    private int eatPrevSlot = -1;
    private int eatIdleTicks;
    private int eatItems;

    public AutoMineSell() {
        super("auto-mine-sell", "Auto Mine Sell", "Mines the Target Blocks in your area and sells them through /order when the inventory is full.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
        this.addSetting((kryzex.module.settings.Setting) this.orderCommand);
        this.addSetting((kryzex.module.settings.Setting) this.priceKeyword);
        this.addSetting((kryzex.module.settings.Setting) this.fallbackCommand);
        this.addSetting((kryzex.module.settings.Setting) this.ignoredPlayers);
        this.addSetting((kryzex.module.settings.Setting) this.webhookUrl);
        this.addSetting((kryzex.module.settings.Setting) this.webhookPing);
        this.addSetting((kryzex.module.settings.Setting) this.shopCommand);
        this.addSetting((kryzex.module.settings.Setting) this.shopFoodItem);
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    // ================================================================ lifecycle

    @Override
    public void onEnable() {
        this.updateAreaFromCorners();
        if (!this.mineWithoutArea.get() && !this.areaDefined) {
            this.say("Set both corners first (or turn on Mine Without Area).");
            this.requestDisable();
            return;
        }
        if (this.mineWithoutArea.get() && this.targetBlocks.get().isEmpty()) {
            this.say("Pick some Target Blocks before using Mine Without Area.");
            this.requestDisable();
            return;
        }
        this.target = null;
        this.skipped.clear();
        this.targetTotal = 0;
        this.noTargetTicks = 0;
        this.lastScanAge = -1000;
        this.wasMining = false;
        this.finalSellTries = 0;
        this.blockedTicks = 0;
        this.repositionTicks = 0;
        this.repositions = 0;
        this.lootSkipped.clear();
        this.lootTargetId = -1;
        this.lootTicks = 0;
        this.nukerSlow = null;
        this.trail.clear();
        this.pathGoal = null;
        this.dirLast = null;
        this.escaping = false;
        this.escapeTicks = 0;
        this.escapeSpot = null;
        this.resetAutoSell(false);
        this.soldTotal = 0;
        this.soldByFallback = 0;
        this.ordersFilled = 0;
        this.sellRetryAt = 0L;
        this.safetyTriggered = false;
        this.lastTotemCount = -1;
        this.resetRepair(false);
        this.resetEat();
        this.loadMemory();
        this.farScanAt = 0;
        this.farHidden = 0;
        this.farUnsafe = 0;
        this.skipRetries = 0;
        this.skipRetryMark = -1;
        this.foodBuyRetryAt = 0L;
        this.pillaring = false;
        this.pillarCount = 0;
        this.pillarTicks = 0;
        this.levelWarned = false;
        this.cushionDone = false;
        this.placedBlocks.clear();
        this.repairRetryAt = 0L;
        this.eatRetryAt = 0L;
    }

    @Override
    public void onDisable() {
        this.resetRepair(true);
        this.resetEat();
        this.resetAutoSell(true);
        if (this.soldTotal > 0) {
            this.say("Auto Sell: sold " + this.soldTotal + " items (orders: " + this.ordersFilled + ", /sell: " + this.soldByFallback + ").");
        }
        this.lootMovingAge = -1;
        this.releaseKeys();
        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
        this.target = null;
        this.trail.clear();
        this.pathGoal = null;
        this.dirLast = null;
        this.escaping = false;
        this.escapeSpot = null;
    }

    @MacroSubscribe
    public void onMacroTick(MacroTickEvent macroTickEvent) {
        class_310 mc = this.mc;
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.method_1562() == null) {
            return;
        }
        if (this.tickSafety()) {
            return;
        }
        this.tickFallCushion();
        if (this.tickEat()) {
            return;
        }
        if (this.tickRepair()) {
            return;
        }
        if (this.tickAutoSell()) {
            return;
        }
        if (mc.field_1755 != null) {
            this.releaseKeys();
            return;
        }
        this.tickMiner();
    }

    // ================================================================ area

    private void setCornerFromPlayer(int which, boolean looking) {
        class_310 mc = this.mc;
        if (mc.field_1724 == null) {
            return;
        }
        class_2338 pos = mc.field_1724.method_24515().method_10074();
        if (looking) {
            if (!(mc.field_1765 instanceof class_3965) || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
                this.say("Look at a block first.");
                return;
            }
            pos = ((class_3965)mc.field_1765).method_17777();
        }
        if (which == 1) {
            this.corner1 = pos;
        } else {
            this.corner2 = pos;
        }
        this.updateAreaFromCorners();
        if (this.areaDefined) {
            this.say("Area set: " + this.getAreaBlockCount() + " blocks.");
        } else {
            this.say("Corner " + which + " set.");
        }
    }

    private void updateAreaFromCorners() {
        this.areaDefined = this.corner1 != null && this.corner2 != null;
        if (!this.areaDefined) {
            return;
        }
        this.minX = Math.min(this.corner1.method_10263(), this.corner2.method_10263());
        this.minY = Math.min(this.corner1.method_10264(), this.corner2.method_10264());
        this.minZ = Math.min(this.corner1.method_10260(), this.corner2.method_10260());
        this.maxX = Math.max(this.corner1.method_10263(), this.corner2.method_10263());
        this.maxY = Math.max(this.corner1.method_10264(), this.corner2.method_10264());
        this.maxZ = Math.max(this.corner1.method_10260(), this.corner2.method_10260());
    }

    private long getAreaBlockCount() {
        if (!this.areaDefined) {
            return 0L;
        }
        return (long)(this.maxX - this.minX + 1) * (long)(this.maxY - this.minY + 1) * (long)(this.maxZ - this.minZ + 1);
    }

    private boolean useArea() {
        return this.areaDefined && !this.mineWithoutArea.get();
    }

    // ================================================================ miner

    private static String blockKey(class_2248 block) {
        String id = class_7923.field_41175.method_10221(block).toString().toLowerCase(Locale.ROOT);
        return id;
    }

    private boolean matchesTarget(class_2248 block) {
        String id = blockKey(block);
        if (id.equals("minecraft:air") || id.equals("minecraft:cave_air") || id.equals("minecraft:void_air") || id.equals("minecraft:bedrock")) {
            return false;
        }
        List<String> wanted = this.targetBlocks.get();
        if (wanted.isEmpty()) {
            return true; // empty = mine everything inside the area
        }
        String shortId = id.substring(id.indexOf(58) + 1);
        for (String entry : wanted) {
            String e = entry.trim().toLowerCase(Locale.ROOT);
            if (e.isEmpty()) {
                continue;
            }
            if (id.equals(e) || shortId.equals(e)) {
                return true;
            }
            if (e.indexOf(58) < 0 && shortId.contains(e)) {
                return true;
            }
        }
        return false;
    }

    private boolean isInside(int x, int y, int z) {
        if (!this.useArea()) {
            class_2338 p = this.mc.field_1724.method_24515();
            int r = this.scanRange.getInt();
            return Math.abs(x - p.method_10263()) <= r && Math.abs(y - p.method_10264()) <= r && Math.abs(z - p.method_10260()) <= r;
        }
        return x >= this.minX && x <= this.maxX && y >= this.minY && y <= this.maxY && z >= this.minZ && z <= this.maxZ;
    }

    private boolean isValidTarget(class_2338 pos) {
        if (pos == null || !this.isInside(pos.method_10263(), pos.method_10264(), pos.method_10260())) {
            return false;
        }
        return this.isTargetAt(pos);
    }

    private boolean isExposed(class_2338 pos) {
        class_2350[] sides = class_2350.values();
        for (class_2350 side : sides) {
            if (this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                return true;
            }
        }
        return false;
    }

    /** Nearest valid, exposed, not-skipped block. Scans a limited radius around the player to stay cheap. */
    private class_2338 findTarget() {
        class_746 player = this.mc.field_1724;
        class_243 eye = player.method_33571();
        class_2338 base = player.method_24515();
        int age = player.field_6012;
        this.skipped.values().removeIf(until -> until < age);

        int radius = this.useArea() ? 20 : this.scanRange.getInt();
        radius = Math.min(radius, 16);
        class_2338 best = null;
        double bestScore = Double.MAX_VALUE;
        long scanned = 0L;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (++scanned > TARGET_SCAN_LIMIT) {
                        break;
                    }
                    int x = base.method_10263() + dx;
                    int y = base.method_10264() + dy;
                    int z = base.method_10260() + dz;
                    if (!this.isInside(x, y, z)) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    if (!this.isTargetAt(pos)) {
                        continue;
                    }
                    if (this.skipped.containsKey(pos) || !this.isExposed(pos)) {
                        continue;
                    }
                    if (!this.isSafeToBreak(pos)) {
                        continue;
                    }
                    double dist = eye.method_1025(class_243.method_24953(pos));
                    // nearest first, higher blocks slightly preferred so layers are cleared top-down
                    double score = dist - y * 0.05;
                    if (!this.facesEye(pos, eye)) {
                        score += 100.0; // no open face towards us: only pick it when nothing visible is left
                    }
                    if (score < bestScore) {
                        bestScore = score;
                        best = pos;
                    }
                }
            }
        }
        return best;
    }

    private void tickMiner() {
        class_746 player = this.mc.field_1724;
        if (player.method_29504()) {
            this.releaseKeys();
            return;
        }

        if (this.tickHazard()) {
            return; // stuck in water/lava: getting out comes before everything else
        }
        this.updateDirectionLine();
        this.updateTrail();

        boolean looting = this.tickLoot();
        if (looting && !this.lootWhileMining.get()) {
            return; // old behaviour: mining waits while looting
        }

        if (this.nuker.get() && this.tickNuker()) {
            this.noTargetTicks = 0;
            this.wasMining = true;
            return;
        }

        if (this.target == null || !this.isValidTarget(this.target)) {
            if (this.target != null) {
                this.targetTotal++;
            }
            this.target = this.findTarget();
            if (this.target == null) {
                this.target = this.findTargetFar();
            }
            this.targetTicks = 0;
            this.aimTicks = 0;
            this.blockedTicks = 0;
            this.repositionTicks = 0;
            this.repositions = 0;
            this.stuckCheckPos = null;
            this.stuckTicks = 0;
            if (this.target == null) {
                this.releaseKeys();
                if (this.mc.field_1761 != null) {
                    this.mc.field_1761.method_2925();
                }
                if (looting) {
                    this.noTargetTicks = 0; // still collecting drops: not done yet
                    return;
                }
                if (++this.noTargetTicks >= NO_TARGET_LIMIT) {
                    // give blocks that were skipped (unreachable for a moment) another chance before calling it done
                    if (!this.skipped.isEmpty() && (this.targetTotal != this.skipRetryMark || this.skipRetries < 2)) {
                        if (this.targetTotal != this.skipRetryMark) {
                            this.skipRetries = 0;
                            this.skipRetryMark = this.targetTotal;
                        }
                        this.skipRetries++;
                        this.skipped.clear();
                        this.noTargetTicks = 0;
                        this.farScanAt = 0;
                        return;
                    }
                    this.finishedMining();
                }
                return;
            }
        }
        this.noTargetTicks = 0;
        this.wasMining = true;

        if (!this.isSafeToBreak(this.target)) {
            // fluid appeared next to it (or it holds up the floor): leave it alone
            this.skipped.put(this.target, player.field_6012 + 600);
            this.target = null;
            return;
        }

        int slot = this.toolSlot.getInt();
        if (slot >= 1 && slot <= 9) {
            player.method_31548().method_61496(slot - 1);
        }

        if (++this.targetTicks > 600) {
            this.skipped.put(this.target, player.field_6012 + 600);
            this.target = null;
            return;
        }

        class_243 center = class_243.method_24953(this.target);
        double reachSq = (double)this.reach.get() * (double)this.reach.get();
        class_243 eye = player.method_33571();
        boolean inReach = eye.method_1025(center) <= reachSq;

        if (!inReach && this.tickPillar(center)) {
            return; // too low for this block: building up
        }
        if (this.pillaring) {
            this.pillaring = false;
            this.pillarTicks = 0;
            this.pillarCount = 0;
            this.forceReleaseMovement();
        }
        if (this.target == null) {
            return;
        }

        // the block cannot be hit from here: walk to a better spot for a moment
        if (this.repositionTicks > 0) {
            this.repositionTicks--;
            this.mc.field_1761.method_2925();
            class_243 goal = this.approachPoint(this.target, eye);
            if (!this.walkTo(goal != null ? goal : center)) {
                this.skipped.put(this.target, player.field_6012 + 800);
                this.target = null;
                this.repositionTicks = 0;
            }
            if (this.repositionTicks == 0) {
                this.releaseMovement();
            }
            return;
        }

        if (inReach) {
            this.releaseMovement();
            boolean aimed = this.aimAt(center);
            class_3965 hit = this.mc.field_1765 instanceof class_3965 ? (class_3965)this.mc.field_1765 : null;
            if (hit != null && hit.method_17783() == class_239.class_240.field_1332) {
                class_2338 hitPos = hit.method_17777();
                if (hitPos.equals(this.target)) {
                    this.blockedTicks = 0;
                    this.mineBlock(this.target, hit.method_17780());
                    return;
                }
                if (this.isValidTarget(hitPos) && this.isSafeToBreak(hitPos)) {
                    // another target block is in the way: mine it first
                    this.blockedTicks = 0;
                    this.mineBlock(hitPos, hit.method_17780());
                    return;
                }
            }
            if (aimed && ++this.blockedTicks > 15) {
                this.blockedTicks = 0;
                if (++this.repositions > 4) {
                    this.skipped.put(this.target, player.field_6012 + 400);
                    this.target = null;
                    this.repositions = 0;
                    this.releaseKeys();
                    return;
                }
                this.repositionTicks = 25;
                this.stuckCheckPos = null;
            }
            return;
        }

        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
        if (!this.walkTo(center)) {
            this.skipped.put(this.target, player.field_6012 + 800);
            this.target = null;
        }
    }

    // ================================================================ Far target scan

    /** Nothing close: look through the rest of the area (once per second) so the bot walks on instead of stopping. */
    private class_2338 findTargetFar() {
        class_746 player = this.mc.field_1724;
        int age = player.field_6012;
        if (age < this.farScanAt) {
            return null;
        }
        this.farScanAt = age + 20;

        class_2338 base = player.method_24515();
        int r = Math.min(Math.max(this.scanRange.getInt(), 16), FAR_WINDOW);
        int x0 = base.method_10263() - r;
        int x1 = base.method_10263() + r;
        int y0 = base.method_10264() - r;
        int y1 = base.method_10264() + r;
        int z0 = base.method_10260() - r;
        int z1 = base.method_10260() + r;
        if (this.useArea()) {
            x0 = Math.max(x0, this.minX);
            y0 = Math.max(y0, this.minY);
            z0 = Math.max(z0, this.minZ);
            x1 = Math.min(x1, this.maxX);
            y1 = Math.min(y1, this.maxY);
            z1 = Math.min(z1, this.maxZ);
        }
        class_2338 found = this.scanBox(x0, y0, z0, x1, y1, z1, player);
        if (found == null && this.useArea() && this.getAreaBlockCount() <= FAR_FULL_LIMIT) {
            found = this.scanBox(this.minX, this.minY, this.minZ, this.maxX, this.maxY, this.maxZ, player);
        }
        return found;
    }

    private class_2338 scanBox(int x0, int y0, int z0, int x1, int y1, int z1, class_746 player) {
        int age = player.field_6012;
        this.skipped.values().removeIf(until -> until < age);
        Map<class_2248, Boolean> cache = new HashMap<>();
        class_243 eye = player.method_33571();
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        int hidden = 0;
        int unsafe = 0;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y0; y <= y1; y++) {
                    if (!this.isInside(x, y, z)) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = this.mc.field_1687.method_8320(pos);
                    if (state.method_26215()) {
                        continue;
                    }
                    boolean match = this.placedBlocks.contains(pos) || cache.computeIfAbsent(state.method_26204(), this::matchesTarget);
                    if (!match || this.skipped.containsKey(pos)) {
                        continue;
                    }
                    if (!this.isExposed(pos)) {
                        hidden++;
                        continue;
                    }
                    if (!this.isSafeToBreak(pos)) {
                        unsafe++;
                        continue;
                    }
                    double dist = eye.method_1025(class_243.method_24953(pos));
                    if (dist < bestDist) {
                        bestDist = dist;
                        best = pos;
                    }
                }
            }
        }
        this.farHidden = hidden;
        this.farUnsafe = unsafe;
        return best;
    }

    // ================================================================ Saved memory (survives restarts)

    private void loadMemory() {
        try {
            if (!Files.exists(MEMORY_FILE)) {
                return;
            }
            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(MEMORY_FILE)) {
                props.load(in);
            }
            this.buyBtnBottle = memInt(props, "buy-button-bottle");
            this.buyBtnFood = memInt(props, "buy-button-food");
            this.repairKnownCategory = memInt(props, "category-bottle");
            this.foodKnownCategory = memInt(props, "category-food");
        } catch (Exception ignored) {
            // unreadable file: start from scratch
        }
    }

    private static int memInt(Properties props, String key) {
        try {
            return Integer.parseInt(props.getProperty(key, "-1").trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void saveMemory() {
        try {
            Properties props = new Properties();
            props.setProperty("buy-button-bottle", String.valueOf(this.buyBtnBottle));
            props.setProperty("buy-button-food", String.valueOf(this.buyBtnFood));
            props.setProperty("category-bottle", String.valueOf(this.repairKnownCategory));
            props.setProperty("category-food", String.valueOf(this.foodKnownCategory));
            Files.createDirectories(MEMORY_FILE.getParent());
            try (OutputStream out = Files.newOutputStream(MEMORY_FILE)) {
                props.store(out, "Auto Mine Sell: remembered shop slots");
            }
        } catch (Exception ignored) {
            // read-only folder: the memory just lasts until the game closes
        }
    }

    // ================================================================ Auto Place Blocks (pillar up / jump down)

    private boolean isTargetAt(class_2338 pos) {
        class_2680 state = this.mc.field_1687.method_8320(pos);
        if (this.placedBlocks.contains(pos)) {
            if (state.method_26215()) {
                this.placedBlocks.remove(pos);
                return false;
            }
            return true;
        }
        return this.matchesTarget(state.method_26204());
    }

    /** First hotbar slot holding a block that may be placed (never the tool slot, never a target block). */
    private int findPlaceSlot() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int tool = this.toolSlot.getInt();
        List<String> custom = this.levelBlocks.get();
        List<String> targets = this.targetBlocks.get();
        for (int i = 0; i <= 8; i++) {
            if (tool >= 1 && tool <= 9 && i == tool - 1) {
                continue;
            }
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || !(stack.method_7909() instanceof class_1747)) {
                continue;
            }
            if (!custom.isEmpty()) {
                if (Sell.e(stack, custom)) {
                    return i;
                }
                continue;
            }
            if (!targets.isEmpty() && this.matchesTarget(class_2248.method_9503(stack.method_7909()))) {
                continue; // do not place what is being mined
            }
            String path = itemPath(stack);
            if (path.contains("chest") || path.contains("shulker") || path.contains("tnt") || path.contains("barrel")
                || path.contains("furnace") || path.contains("table") || path.contains("anvil") || path.contains("bed")
                || path.contains("button") || path.contains("torch") || path.contains("sign") || path.contains("door")
                || path.contains("rail") || path.contains("pressure_plate") || path.contains("sapling") || path.contains("slab")
                || path.contains("stairs") || path.contains("carpet") || path.contains("banner") || path.contains("head")) {
                continue;
            }
            return i;
        }
        return -1;
    }

    /** Places the block from the given hotbar slot on top of {@code on}. Returns true when the spot above it is now filled. */
    private boolean placeBlock(int slot, class_2338 on) {
        class_746 player = this.mc.field_1724;
        class_2338 result = on.method_10084();
        if (this.stateAt(on.method_10263(), on.method_10264(), on.method_10260()).method_26215()
            || !this.stateAt(result.method_10263(), result.method_10264(), result.method_10260()).method_26215()) {
            return false;
        }
        int previous = this.selectedHotbar();
        player.method_31548().method_61496(slot);
        class_243 hit = new class_243(on.method_10263() + 0.5, on.method_10264() + 1.0, on.method_10260() + 0.5);
        this.mc.field_1761.method_2896(player, class_1268.field_5808, new class_3965(hit, class_2350.field_11036, on, false));
        player.method_6104(class_1268.field_5808);
        player.method_31548().method_61496(previous);
        return !this.stateAt(result.method_10263(), result.method_10264(), result.method_10260()).method_26215();
    }

    private void abandonPillar() {
        class_746 player = this.mc.field_1724;
        if (this.target != null) {
            this.skipped.put(this.target, player.field_6012 + 600);
        }
        this.target = null;
        this.pillaring = false;
        this.pillarTicks = 0;
        this.pillarCount = 0;
        this.forceReleaseMovement();
    }

    /**
     * The block is above reach and we stand right below it: look down, jump and put a block under the feet at the
     * top of every jump. Returns true while it uses the tick.
     */
    private boolean tickPillar(class_243 center) {
        if (!this.autoLevel.get() || this.target == null) {
            return false;
        }
        class_746 player = this.mc.field_1724;
        double px = player.method_23317();
        double py = player.method_23318();
        double pz = player.method_23321();
        int feetY = (int)Math.floor(py + 0.01);
        double dx = center.field_1352 - px;
        double dz = center.field_1350 - pz;
        boolean need = this.target.method_10264() - feetY >= 3 && dx * dx + dz * dz <= 9.0;
        if (!need) {
            return false;
        }

        int slot = this.findPlaceSlot();
        if (slot < 0) {
            if (!this.levelWarned) {
                this.say("The block is too high but there are no placeable blocks in the hotbar.");
                this.levelWarned = true;
            }
            return false;
        }
        int bx = (int)Math.floor(px);
        int bz = (int)Math.floor(pz);
        if (this.pillarCount >= 40 || ++this.pillarTicks > 240 || !this.stateAt(bx, feetY + 2, bz).method_26215()) {
            this.abandonPillar(); // no room above the head, or it takes too long
            return true;
        }

        this.pillaring = true;
        this.mc.field_1761.method_2925();
        this.forceReleaseMovement();
        float pitch = player.method_36455();
        if (pitch < 80.0f) {
            player.method_36457(Math.min(90.0f, pitch + Math.max(10.0f, this.aimSpeed.get() * 1.5f)));
        }
        this.mc.field_1690.field_1903.method_23481(true);
        if (player.method_24828() || pitch < 75.0f) {
            return true;
        }

        // in the air: the block we jumped from is the first solid one below
        int top = (int)Math.floor(py - 0.01);
        int support = Integer.MIN_VALUE;
        for (int d = 0; d <= 2; d++) {
            class_2680 state = this.stateAt(bx, top - d, bz);
            if (!state.method_26215() && state.method_26227().method_15769()) {
                support = top - d;
                break;
            }
        }
        if (support != Integer.MIN_VALUE && py - (support + 1) >= 1.0 && this.placeBlock(slot, new class_2338(bx, support, bz))) {
            this.pillarCount++;
            this.pillarTicks = 0;
        }
        return true;
    }

    /** Walking off an edge towards a lower target is fine when there is a floor to land on and blocks to cushion the fall. */
    private boolean canDropToward(class_243 point) {
        if (!this.autoLevel.get() || !this.dropDown.get()) {
            return false;
        }
        class_746 player = this.mc.field_1724;
        if (!player.method_24828()) {
            return false;
        }
        double px = player.method_23317();
        double py = player.method_23318();
        double pz = player.method_23321();
        if (point.field_1351 > py - 1.5) {
            return false; // only used to get down to blocks that lie lower
        }
        double dx = point.field_1352 - px;
        double dz = point.field_1350 - pz;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.2) {
            return false;
        }
        int fy = (int)Math.floor(py + 0.01);
        int x = (int)Math.floor(px + dx / len);
        int z = (int)Math.floor(pz + dz / len);
        if (!this.stateAt(x, fy, z).method_26215() || !this.stateAt(x, fy + 1, z).method_26215()) {
            return false;
        }
        int limit = this.maxDrop.getInt();
        for (int d = 1; d <= limit + 1; d++) {
            class_2680 state = this.stateAt(x, fy - d, z);
            if (!state.method_26227().method_15769()) {
                return false; // water / lava below
            }
            if (!state.method_26215()) {
                int fall = d - 1;
                if (this.useArea() && !this.isInside(x, fy - d + 1, z)) {
                    return false;
                }
                return fall <= 2 || this.findPlaceSlot() >= 0;
            }
        }
        return false;
    }

    /**
     * While falling, as soon as the ground is within reach, puts blocks on it in the same tick (2 by default), so the
     * player lands on top of them and the fall is shorter. The blocks count as targets and are mined again afterwards.
     */
    private void tickFallCushion() {
        if (!this.autoLevel.get()) {
            return;
        }
        class_746 player = this.mc.field_1724;
        if (player.method_24828() || player.method_5799() || player.method_29504()) {
            this.cushionDone = false;
            return;
        }
        if (this.cushionDone || player.method_18798().field_1351 > -0.6) {
            return;
        }
        double py = player.method_23318();
        int bx = (int)Math.floor(player.method_23317());
        int bz = (int)Math.floor(player.method_23321());
        int startY = (int)Math.floor(py - 0.01);
        int ground = Integer.MIN_VALUE;
        for (int y = startY; y >= startY - 6; y--) {
            class_2680 state = this.stateAt(bx, y, bz);
            if (!state.method_26227().method_15769()) {
                return; // landing in water / lava: nothing to cushion
            }
            if (!state.method_26215()) {
                ground = y;
                break;
            }
        }
        if (ground == Integer.MIN_VALUE) {
            return;
        }
        if (player.method_33571().field_1351 - (ground + 1) > 4.6) {
            return; // not in reach yet
        }
        double fall = player.field_6017;
        if (fall + (py - (ground + 1)) <= 3.5) {
            return; // would not hurt anyway
        }
        int slot = this.findPlaceSlot();
        if (slot < 0) {
            if (!this.levelWarned) {
                this.say("Falling but there are no placeable blocks in the hotbar to cushion it.");
                this.levelWarned = true;
            }
            return;
        }
        this.cushionDone = true;
        player.method_36457(90.0f);
        class_2338 on = new class_2338(bx, ground, bz);
        int count = this.cushionCount.getInt();
        for (int i = 0; i < count; i++) {
            if (!this.placeBlock(slot, on)) {
                break;
            }
            on = on.method_10084();
            this.placedBlocks.add(on);
        }
    }

    // ================================================================ Nuker

    /**
     * Meteor-style nuker: breaks every Target Block within range without walking or aiming at each one.
     * Instant-break blocks are broken several per tick; slower blocks are mined one at a time (the server only
     * tracks one block in progress). Returns true when it did something this tick (the normal miner then waits).
     */
    private boolean tickNuker() {
        class_746 player = this.mc.field_1724;

        int hotbar = this.toolSlot.getInt();
        if (hotbar >= 1 && hotbar <= 9) {
            player.method_31548().method_61496(hotbar - 1);
        }

        class_243 eye = player.method_33571();
        double range = this.nukerRange.get();
        double rangeSq = range * range;
        int r = (int)Math.ceil(range);
        class_2338 base = player.method_24515();
        boolean onlyExposed = this.nukerOnlyExposed.get();

        List<class_2338> candidates = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    int x = base.method_10263() + dx;
                    int y = base.method_10264() + dy;
                    int z = base.method_10260() + dz;
                    if (!this.isInside(x, y, z)) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    if (eye.method_1025(class_243.method_24953(pos)) > rangeSq) {
                        continue;
                    }
                    if (!this.isTargetAt(pos)) {
                        continue;
                    }
                    if (onlyExposed && !this.isExposed(pos)) {
                        continue;
                    }
                    if (!this.isSafeToBreak(pos)) {
                        continue;
                    }
                    candidates.add(pos);
                }
            }
        }

        if (candidates.isEmpty()) {
            this.nukerSlow = null;
            return false;
        }

        // nearest first, higher blocks slightly preferred
        candidates.sort((a, b) -> Double.compare(
            eye.method_1025(class_243.method_24953(a)) - a.method_10264() * 0.05,
            eye.method_1025(class_243.method_24953(b)) - b.method_10264() * 0.05));

        List<class_2338> instant = new ArrayList<>();
        class_2338 slow = null;
        for (class_2338 pos : candidates) {
            float delta = this.mc.field_1687.method_8320(pos).method_26165((class_1657)player, this.mc.field_1687, pos);
            if (delta >= 1.0f) {
                instant.add(pos);
            } else if (slow == null) {
                slow = pos;
            }
            if (this.nukerSlow != null && this.nukerSlow.equals(pos) && delta < 1.0f) {
                slow = pos; // keep mining the block that is already in progress
            }
        }

        class_2338 aim = null;
        boolean did = false;
        List<class_2338> mined = new ArrayList<>();
        if (!instant.isEmpty()) {
            this.mc.field_1761.method_2925();
            this.nukerSlow = null;
            int max = this.nukerBlocksPerTick.getInt();
            int done = 0;
            for (class_2338 pos : instant) {
                if (done >= max) {
                    break;
                }
                this.mc.field_1761.method_2910(pos, this.nukerFace(pos, eye));
                mined.add(pos);
                done++;
            }
            aim = this.pickAimByLook(mined, eye);
            this.targetTotal += done;
            did = done > 0;
        } else if (slow != null) {
            if (this.nukerSlow != null && !this.nukerSlow.equals(slow)) {
                this.targetTotal++;
            }
            this.nukerSlow = slow;
            this.mc.field_1761.method_2902(slow, this.nukerFace(slow, eye));
            aim = slow;
            did = true;
        }

        if (did) {
            if ((this.nukerRotate.get() || this.followMining.get()) && aim != null) {
                this.aimAt(class_243.method_24953(aim));
            }
            player.method_6104(class_1268.field_5808);
        }
        return did;
    }

    /** Side of the block facing the player (prefers an open/air side). */
    /** Of the blocks mined this tick, the one closest to where the camera already points (so the view does not jerk around). */
    private class_2338 pickAimByLook(List<class_2338> blocks, class_243 eye) {
        if (blocks.isEmpty()) {
            return null;
        }
        class_746 player = this.mc.field_1724;
        double yaw = Math.toRadians(player.method_36454());
        double pitch = Math.toRadians(player.method_36455());
        double lx = -Math.sin(yaw) * Math.cos(pitch);
        double ly = -Math.sin(pitch);
        double lz = Math.cos(yaw) * Math.cos(pitch);
        class_2338 best = blocks.get(0);
        double bestDot = -2.0;
        for (class_2338 pos : blocks) {
            double dx = pos.method_10263() + 0.5 - eye.field_1352;
            double dy = pos.method_10264() + 0.5 - eye.field_1351;
            double dz = pos.method_10260() + 0.5 - eye.field_1350;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-4) {
                continue;
            }
            double dot = (dx * lx + dy * ly + dz * lz) / len;
            if (dot > bestDot) {
                bestDot = dot;
                best = pos;
            }
        }
        return best;
    }

    private class_2350 nukerFace(class_2338 pos, class_243 eye) {
        class_2350 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 side : class_2350.values()) {
            if (!this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                continue;
            }
            double fx = pos.method_10263() + 0.5 + side.method_10148() * 0.5;
            double fy = pos.method_10264() + 0.5 + side.method_10164() * 0.5;
            double fz = pos.method_10260() + 0.5 + side.method_10165() * 0.5;
            double d = eye.method_1025(new class_243(fx, fy, fz));
            if (d < bestDist) {
                bestDist = d;
                best = side;
            }
        }
        return best != null ? best : class_2350.values()[1];
    }

    /** True when the block has an open (air) side that the player's eye is on the outside of. */
    private boolean facesEye(class_2338 pos, class_243 eye) {
        for (class_2350 side : class_2350.values()) {
            if (!this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                continue;
            }
            int ox = side.method_10148();
            int oy = side.method_10164();
            int oz = side.method_10165();
            if (ox > 0 && eye.field_1352 > pos.method_10263() + 1) return true;
            if (ox < 0 && eye.field_1352 < pos.method_10263()) return true;
            if (oy > 0 && eye.field_1351 > pos.method_10264() + 1) return true;
            if (oy < 0 && eye.field_1351 < pos.method_10264()) return true;
            if (oz > 0 && eye.field_1350 > pos.method_10260() + 1) return true;
            if (oz < 0 && eye.field_1350 < pos.method_10260()) return true;
        }
        return false;
    }

    /** Centre of the open (air) block next to the target that is closest to the player. */
    private class_243 approachPoint(class_2338 pos, class_243 eye) {
        class_243 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 side : class_2350.values()) {
            class_2338 neighbour = pos.method_10093(side);
            if (!this.mc.field_1687.method_8320(neighbour).method_26215()) {
                continue;
            }
            class_243 c = class_243.method_24953(neighbour);
            double d = eye.method_1025(c);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    // ================================================================ Auto Loot

    /**
     * Walks to the nearest wanted dropped item. With "Mine While Looting" the miner keeps aiming and breaking blocks
     * in the same tick (the player walks sideways/backwards relative to where it looks). Items that cannot be
     * reached are skipped after "Loot Give Up" seconds or as soon as the player stops getting closer.
     * Returns true while it is moving towards an item.
     */
    private boolean tickLoot() {
        if (!this.autoLoot.get()) {
            this.lootTargetId = -1;
            return false;
        }
        class_746 player = this.mc.field_1724;
        class_1542 item = this.findLoot();
        if (item == null) {
            if (this.lootTargetId != -1) {
                this.lootTargetId = -1;
                this.lootTicks = 0;
                this.lootStuckPos = null;
                this.lootMovingAge = -1;
                this.stuckCheckPos = null;
                this.forceReleaseMovement();
            }
            return false;
        }

        class_243 point = new class_243(item.method_23317(), item.method_23318(), item.method_23321());
        double dist = player.method_33571().method_1022(point);

        int id = item.method_5628();
        if (id != this.lootTargetId) {
            this.lootTargetId = id;
            this.lootTicks = 0;
            this.lootStuckPos = null;
            this.lootStuckTicks = 0;
            this.lootProgressDist = dist;
            this.lootProgressTicks = 0;
            this.stuckCheckPos = null;
            this.stuckTicks = 0;
        }

        boolean together = this.lootWhileMining.get();
        if (!together) {
            this.mc.field_1761.method_2925();
        }

        // not getting closer for a second and a half: give up on this item
        boolean noProgress = false;
        if (++this.lootProgressTicks >= 30) {
            noProgress = dist > this.lootProgressDist - 0.4;
            this.lootProgressDist = dist;
            this.lootProgressTicks = 0;
        }

        boolean moving = together ? this.lootWalk(point) : this.walkTo(point);
        if (!moving || noProgress || ++this.lootTicks > this.lootTimeout.getInt() * 20) {
            // cannot reach it (or it is not being picked up): ignore this item for a minute and go on mining
            this.lootSkipped.put(id, player.field_6012 + 1200);
            this.lootTargetId = -1;
            this.lootTicks = 0;
            this.lootStuckPos = null;
            this.lootMovingAge = -1;
            this.stuckCheckPos = null;
            this.forceReleaseMovement();
            return false;
        }

        if (together) {
            this.lootMovingAge = player.field_6012;
        }
        return true;
    }

    /**
     * Moves towards a point with W/A/S/D chosen relative to where the player is looking, without turning the
     * camera, so the miner can keep aiming at its block. Returns false when the player is stuck.
     */
    private boolean lootWalk(class_243 point) {
        class_746 player = this.mc.field_1724;
        double dx = point.field_1352 - player.method_23317();
        double dz = point.field_1350 - player.method_23321();

        if (dx * dx + dz * dz < 0.04) {
            this.forceReleaseMovement(); // standing on it: pickup happens by itself
            return true;
        }

        this.pathGoal = point;
        if (this.avoidHazards.get()) {
            if (this.hazardAhead(point)) {
                this.forceReleaseMovement();
                this.mc.field_1690.field_1832.method_23481(true);
                return false; // the item lies behind a hazard: the loot logic skips it
            }
            this.mc.field_1690.field_1832.method_23481(this.nearHazard());
        }

        float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float rel = class_3532.method_15393(wantYaw - player.method_36454());
        float abs = Math.abs(rel);

        this.mc.field_1690.field_1894.method_23481(abs < 67.5f);
        this.mc.field_1690.field_1881.method_23481(abs > 112.5f);
        this.mc.field_1690.field_1849.method_23481(rel > 22.5f && rel < 157.5f);
        this.mc.field_1690.field_1913.method_23481(rel < -22.5f && rel > -157.5f);
        this.mc.field_1690.field_1903.method_23481(player.field_5976 && player.method_24828());

        if (this.lootStuckPos == null) {
            this.lootStuckPos = player.method_73189();
            this.lootStuckTicks = 0;
            return true;
        }
        if (++this.lootStuckTicks < 40) {
            return true;
        }
        boolean moved = player.method_73189().method_1025(this.lootStuckPos) > 0.09;
        this.lootStuckPos = player.method_73189();
        this.lootStuckTicks = 0;
        return moved;
    }

    private class_1542 findLoot() {
        class_746 player = this.mc.field_1724;
        int age = player.field_6012;
        this.lootSkipped.values().removeIf(until -> until < age);
        double range = this.lootRange.get();
        double rangeSq = range * range;
        class_1542 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1542 item) || item.method_31481()) {
                continue;
            }
            if (item.field_6012 < 10 || this.lootSkipped.containsKey(item.method_5628())) {
                continue; // still popping out of the block, or given up on
            }
            double d = player.method_5858(item);
            if (d > rangeSq || d >= bestDist) {
                continue;
            }
            class_1799 stack = item.method_6983();
            if (!this.isLootWanted(stack) || !this.hasRoomFor(stack)) {
                continue;
            }
            best = item;
            bestDist = d;
        }
        return best;
    }

    /** Dropped items that match Sell Items / Target Blocks (everything when both are empty). */
    private boolean isLootWanted(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        List<String> targets = this.targetBlocks.get();
        if (targets.isEmpty() && this.sellItems.get().isEmpty()) {
            return true;
        }
        if (this.isSellable(stack)) {
            return true;
        }
        return !targets.isEmpty() && this.matchesTarget(class_2248.method_9503(stack.method_7909()));
    }

    private boolean hasRoomFor(class_1799 stack) {
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 35; i++) {
            class_1799 slot = inventory.method_5438(i);
            if (slot.method_7960()) {
                return true;
            }
            if (slot.method_7909() == stack.method_7909() && slot.method_7947() < slot.method_7914()) {
                return true;
            }
        }
        return false;
    }

    private void finishedMining() {
        if (!this.wasMining) {
            this.say("No target blocks found" + (this.useArea() ? " in the area." : " around you."));
            this.requestDisable();
            return;
        }
        // inventory may still hold things to sell
        if (this.autoSell.get() && this.findSellableItem() != null && this.sellState == SellState.IDLE && this.finalSellTries++ < 3) {
            this.sellRetryAt = 0L;
            this.noTargetTicks = 0;
            this.startSellSessionNow();
            return;
        }
        String done = "Done mining! Cleared " + this.targetTotal + " blocks, sold " + this.soldTotal + " items.";
        if (this.farHidden > 0 || this.farUnsafe > 0) {
            done += " Left behind: " + this.farHidden + " buried (not exposed), " + this.farUnsafe + " unsafe (next to fluid / holding the floor).";
        }
        this.say(done);
        this.sendWebhook("**[Auto Mine Sell]** " + done);
        this.requestDisable();
    }

    private void mineBlock(class_2338 pos, class_2350 side) {
        class_746 player = this.mc.field_1724;
        if (player.field_6012 == this.lastMineAge) {
            return;
        }
        this.lastMineAge = player.field_6012;
        if (this.mc.field_1761.method_2902(pos, side)) {
            player.method_6104(class_1268.field_5808);
        }
    }

    /** Turns the camera toward a point a little at a time. Returns true when it is (nearly) on target. */
    private boolean aimAt(class_243 point) {
        class_746 player = this.mc.field_1724;
        class_243 eye = player.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float wantPitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90.0f, 90.0f);
        float curYaw = player.method_36454();
        float curPitch = player.method_36455();
        float dYaw = class_3532.method_15393(wantYaw - curYaw);
        float dPitch = wantPitch - curPitch;
        float dist = (float)Math.sqrt(dYaw * dYaw + dPitch * dPitch);
        if (dist < 0.35f) {
            return true;
        }
        float maxStep = this.aimSpeed.get() * (0.75f + this.random.nextFloat() * 0.5f);
        float scale = dist > maxStep ? maxStep / dist : 1.0f;
        player.method_36456(curYaw + dYaw * scale);
        player.method_36457(class_3532.method_15363(curPitch + dPitch * scale, -90.0f, 90.0f));
        return dist < 3.0f;
    }

    /** Walks toward a point. Returns false when the player is stuck. */
    private boolean walkTo(class_243 point) {
        class_746 player = this.mc.field_1724;
        if (this.lootHasMovement()) {
            return true; // the loot is moving the player right now: wait, keep mining what is in reach
        }
        this.pathGoal = point;
        if (this.avoidHazards.get()) {
            if (this.hazardAhead(point)) {
                if (this.canDropToward(point)) {
                    this.mc.field_1690.field_1832.method_23481(false); // walk off the edge on purpose, the fall cushion handles the landing
                } else {
                    // hole / water / lava on the way: stop, shift, and give this target up
                    this.forceReleaseMovement();
                    this.mc.field_1690.field_1832.method_23481(true);
                    return false;
                }
            } else {
                this.mc.field_1690.field_1832.method_23481(this.nearHazard());
            }
        }
        this.aimAt(new class_243(point.field_1352, player.method_33571().field_1351, point.field_1350));
        this.mc.field_1690.field_1894.method_23481(true);
        this.mc.field_1690.field_1903.method_23481(player.field_5976 && player.method_24828());
        if (this.stuckCheckPos == null) {
            this.stuckCheckPos = player.method_73189();
            this.stuckTicks = 0;
            return true;
        }
        if (++this.stuckTicks < 60) {
            return true;
        }
        boolean moved = player.method_73189().method_1025(this.stuckCheckPos) > 0.09;
        this.stuckCheckPos = player.method_73189();
        this.stuckTicks = 0;
        if (!moved) {
            this.releaseMovement();
        }
        return moved;
    }

    private void releaseMovement() {
        if (this.mc.field_1690 == null || this.lootHasMovement()) {
            return;
        }
        this.forceReleaseMovement();
    }

    private void forceReleaseMovement() {
        if (this.mc.field_1690 == null) {
            return;
        }
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1881.method_23481(false);
        this.mc.field_1690.field_1913.method_23481(false);
        this.mc.field_1690.field_1849.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
    }

    /** True when the loot set the movement keys during this very tick. */
    private boolean lootHasMovement() {
        return this.mc.field_1724 != null && this.lootMovingAge == this.mc.field_1724.field_6012;
    }

    private void releaseKeys() {
        if (this.mc.field_1690 == null) {
            return;
        }
        this.releaseMovement();
        this.mc.field_1690.field_1832.method_23481(false);
        this.mc.field_1690.field_1904.method_23481(false);
    }

    // ================================================================ Direction line

    /**
     * Draws ONE thin red line in front of the bot showing the way it is heading while it mines (no block
     * highlight). Direction = towards the current walk goal, else the way it is moving, else the last known
     * direction for a short moment. Client-side dust particles, only you see it.
     */
    private void updateDirectionLine() {
        if (!this.drawDir.get()) {
            this.dirLast = null;
            return;
        }
        class_746 player = this.mc.field_1724;
        class_243 pos = new class_243(player.method_23317(), player.method_23318() + 0.12, player.method_23321());
        double dx = 0.0;
        double dz = 0.0;
        class_243 goal = this.pathGoal;
        if (goal != null) {
            dx = goal.field_1352 - pos.field_1352;
            dz = goal.field_1350 - pos.field_1350;
        } else {
            class_243 vel = player.method_18798();
            dx = vel.field_1352;
            dz = vel.field_1350;
            if (dx * dx + dz * dz < 0.0004) {
                dx = 0.0;
                dz = 0.0;
            }
        }
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > 0.05) {
            this.dirLast = new class_243(dx / len, 0.0, dz / len);
            this.dirLastAge = player.field_6012;
        }
        if (this.dirLast == null || player.field_6012 - this.dirLastAge > 30) {
            return; // not heading anywhere right now
        }
        if (player.field_6012 % 2 != 0) {
            return;
        }
        class_2390 fx = new class_2390(0xFF2A2A, this.dirSize.get());
        double total = this.dirLength.get();
        int steps = Math.min(100, (int)(total / 0.35));
        for (int i = 1; i <= steps; i++) {
            double d = 0.7 + i * 0.35; // start a little in front of the player so it does not block the view
            if (d > total) {
                break;
            }
            this.mc.field_1687.method_8406(fx, pos.field_1352 + this.dirLast.field_1352 * d, pos.field_1351, pos.field_1350 + this.dirLast.field_1350 * d, 0.0, 0.0, 0.0);
        }
    }

    // ================================================================ Path trail

    /**
     * Remembers where the player walked and draws it, plus the leg towards the current goal, as a thin line of
     * client-side dust particles (only you see it). Cyan = where the bot has been, yellow = where it is heading.
     */
    private void updateTrail() {
        if (!this.drawPath.get()) {
            this.trail.clear();
            this.pathGoal = null;
            return;
        }
        class_746 player = this.mc.field_1724;
        class_243 pos = new class_243(player.method_23317(), player.method_23318() + 0.12, player.method_23321());
        class_243 last = this.trail.peekLast();
        if (last == null || last.method_1025(pos) >= 0.16) {
            this.trail.addLast(pos);
        }
        int max = Math.max(4, (int)(this.pathLength.get() * 2.5f));
        while (this.trail.size() > max) {
            this.trail.pollFirst();
        }

        class_243 goal = this.pathGoal;
        this.pathGoal = null;
        if (player.field_6012 % 2 != 0) {
            return;
        }

        float size = this.pathSize.get();
        class_2390 trailFx = new class_2390(0x00E5FF, size);
        for (class_243 p : this.trail) {
            this.mc.field_1687.method_8406(trailFx, p.field_1352, p.field_1351, p.field_1350, 0.0, 0.0, 0.0);
        }

        if (goal != null) {
            double gx = goal.field_1352 - pos.field_1352;
            double gz = goal.field_1350 - pos.field_1350;
            double len = Math.sqrt(gx * gx + gz * gz);
            int steps = Math.min(40, (int)(len / 0.4));
            class_2390 goalFx = new class_2390(0xFFD400, size);
            for (int i = 1; i <= steps; i++) {
                double t = i / (double)(steps + 1);
                this.mc.field_1687.method_8406(goalFx, pos.field_1352 + gx * t, pos.field_1351, pos.field_1350 + gz * t, 0.0, 0.0, 0.0);
            }
        }
    }

    // ================================================================ Hazards (holes, water, lava)

    private class_2680 stateAt(int x, int y, int z) {
        return this.mc.field_1687.method_8320(new class_2338(x, y, z));
    }

    private boolean isFluidAt(int x, int y, int z) {
        return !this.stateAt(x, y, z).method_26227().method_15769();
    }

    private boolean isFluidAt(class_2338 pos) {
        return this.isFluidAt(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    private boolean isLavaAt(int x, int y, int z) {
        return this.stateAt(x, y, z).method_26227().method_15767(class_3486.field_15518);
    }

    /** True when something solid (and not a fluid) is within 3 blocks below, i.e. a fall of at most 2 blocks. */
    private boolean hasFloorBelow(int x, int y, int z) {
        for (int d = 1; d <= 3; d++) {
            class_2680 state = this.stateAt(x, y - d, z);
            if (!state.method_26227().method_15769()) {
                return false; // water / lava below
            }
            if (!state.method_26215()) {
                return true;
            }
        }
        return false; // a hole / cave
    }

    /** A standing cell (feet at y) that you should not walk into: fluid in it, or nothing to stand on. */
    private boolean isHazardCell(int x, int y, int z) {
        if (this.isFluidAt(x, y, z) || this.isFluidAt(x, y + 1, z)) {
            return true;
        }
        if (!this.stateAt(x, y, z).method_26215()) {
            return false; // a solid block in the way is a wall/step, not a drop
        }
        return !this.hasFloorBelow(x, y, z);
    }

    /** True when walking from the player towards the point would step into a hazard within the next ~1 block. */
    private boolean hazardAhead(class_243 point) {
        class_746 player = this.mc.field_1724;
        double px = player.method_23317();
        double pz = player.method_23321();
        double dx = point.field_1352 - px;
        double dz = point.field_1350 - pz;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.2) {
            return false;
        }
        double ux = dx / len;
        double uz = dz / len;
        int fy = (int)Math.floor(player.method_23318() + 0.01);
        double[] checks = {0.6, 1.2};
        for (double dist : checks) {
            double d = Math.min(dist, len);
            if (this.isHazardCell((int)Math.floor(px + ux * d), fy, (int)Math.floor(pz + uz * d))) {
                return true;
            }
        }
        return false;
    }

    /** True when a hazard is right beside the player (used to hold Shift so the player cannot slip off an edge). */
    private boolean nearHazard() {
        class_746 player = this.mc.field_1724;
        double px = player.method_23317();
        double pz = player.method_23321();
        int fy = (int)Math.floor(player.method_23318() + 0.01);
        double[][] offsets = {{0.5, 0.0}, {-0.5, 0.0}, {0.0, 0.5}, {0.0, -0.5}};
        for (double[] o : offsets) {
            if (this.isHazardCell((int)Math.floor(px + o[0]), fy, (int)Math.floor(pz + o[1]))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Breaking a block is unsafe when a fluid touches it (it would flow in) or when it is the block the player
     * stands on and nothing solid lies right below it (the player would fall into a hole).
     */
    private boolean isSafeToBreak(class_2338 pos) {
        if (!this.safeMining.get()) {
            return true;
        }
        for (class_2350 side : class_2350.values()) {
            if (this.isFluidAt(pos.method_10093(side))) {
                return false;
            }
        }
        class_746 player = this.mc.field_1724;
        if (player.method_24828()) {
            int supportY = (int)Math.floor(player.method_23318() - 0.01) - 1;
            if (pos.method_10264() == supportY) {
                double px = player.method_23317();
                double pz = player.method_23321();
                boolean support = false;
                for (int sx = -1; sx <= 1 && !support; sx += 2) {
                    for (int sz = -1; sz <= 1 && !support; sz += 2) {
                        support = (int)Math.floor(px + sx * 0.3) == pos.method_10263() && (int)Math.floor(pz + sz * 0.3) == pos.method_10260();
                    }
                }
                if (support && !this.hasFloorBelow(pos.method_10263(), pos.method_10264(), pos.method_10260())) {
                    return false;
                }
            }
        }
        return true;
    }

    /** A cell where the player can stand safely: air for the feet and head, solid floor, no lava beside it. */
    private boolean isSafeStand(int x, int y, int z) {
        if (!this.stateAt(x, y, z).method_26215() || this.isFluidAt(x, y, z)) {
            return false;
        }
        if (!this.stateAt(x, y + 1, z).method_26215() || this.isFluidAt(x, y + 1, z)) {
            return false;
        }
        class_2680 floor = this.stateAt(x, y - 1, z);
        if (floor.method_26215() || !floor.method_26227().method_15769()) {
            return false;
        }
        int[][] around = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] a : around) {
            if (this.isLavaAt(x + a[0], y, z + a[1]) || this.isLavaAt(x + a[0], y - 1, z + a[1])) {
                return false;
            }
        }
        return true;
    }

    /** Nearest safe standing cell around the player (a few blocks up or down are fine). */
    private class_2338 findEscapeSpot(class_746 player) {
        class_2338 base = player.method_24515();
        int r = 8;
        class_2338 best = null;
        double bestScore = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -3; dy <= 4; dy++) {
                    int x = base.method_10263() + dx;
                    int y = base.method_10264() + dy;
                    int z = base.method_10260() + dz;
                    double score = dx * dx + dz * dz + dy * dy * 0.5;
                    if (score >= bestScore || !this.isSafeStand(x, y, z)) {
                        continue;
                    }
                    bestScore = score;
                    best = new class_2338(x, y, z);
                }
            }
        }
        return best;
    }

    /**
     * Gets the player out of water or lava: stops mining, holds jump to swim up, and heads for the nearest safe
     * spot. Returns true while it is taking control of the player.
     */
    private boolean tickHazard() {
        if (!this.escapeFluids.get()) {
            return false;
        }
        class_746 player = this.mc.field_1724;
        boolean inLava = player.method_5771();
        boolean inFluid = inLava || player.method_5799();

        if (!inFluid && !this.escaping) {
            return false;
        }
        if (!inFluid && player.method_24828()) {
            // made it out and standing on something: carry on mining
            this.escaping = false;
            this.escapeSpot = null;
            this.forceReleaseMovement();
            this.target = null;
            this.stuckCheckPos = null;
            return false;
        }

        if (!this.escaping) {
            this.escaping = true;
            this.escapeTicks = 0;
            this.escapeSpot = null;
            this.target = null;
            this.nukerSlow = null;
            this.lootMovingAge = -1;
            this.mc.field_1761.method_2925();
            this.say(inLava ? "In lava - getting out!" : "In water - getting out.");
        }

        this.escapeTicks++;
        if (this.escapeSpot == null || this.escapeTicks % 10 == 0) {
            this.escapeSpot = this.findEscapeSpot(player);
        }
        if (this.escapeTicks == 400) {
            this.say("Still stuck in the fluid, no safe spot found nearby.");
        }

        boolean forward = true;
        if (this.escapeSpot != null) {
            double dx = this.escapeSpot.method_10263() + 0.5 - player.method_23317();
            double dz = this.escapeSpot.method_10260() + 0.5 - player.method_23321();
            float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            float diff = class_3532.method_15393(wantYaw - player.method_36454());
            float step = class_3532.method_15363(diff, -45.0f, 45.0f);
            player.method_36456(player.method_36454() + step);
            forward = Math.abs(diff - step) < 25.0f;
        }

        this.mc.field_1690.field_1894.method_23481(forward);
        this.mc.field_1690.field_1881.method_23481(false);
        this.mc.field_1690.field_1913.method_23481(false);
        this.mc.field_1690.field_1849.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(true); // swim up
        return true;
    }

    // ================================================================ Auto Sell

    /** Returns true when the sell routine used this tick (the miner stays paused). */
    private boolean tickAutoSell() {
        class_310 mc = this.mc;
        if (!this.autoSell.get()) {
            return false;
        }

        long now = System.currentTimeMillis();

        if (this.sellState == SellState.IDLE) {
            // a menu the server re-opened right after a sale (order list / deposit menu): close it, don't leave it for the player
            if (mc.field_1724 != null && mc.field_1755 instanceof class_465 && mc.field_1724.field_7512 != mc.field_1724.field_7498
                && now - this.sellLastEndAt < 8000L) {
                mc.field_1724.method_7346();
                return true;
            }
            if (now < this.sellRetryAt || mc.field_1755 != null || !this.isInventoryFullEnough()) {
                return false;
            }
            if (this.findSellableItem() == null) {
                if (!this.sellWarnedNoItems) {
                    this.say("Inventory full but there is nothing to sell, mining continues.");
                    this.sellWarnedNoItems = true;
                }
                this.sellRetryAt = now + 5000L;
                return false;
            }
            this.sellWarnedNoItems = false;
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.releaseKeys();
            mc.field_1761.method_2925();
            this.startSellSession(now);
        }

        this.releaseKeys();
        if (now < this.sellNextActionAt) {
            return true;
        }

        switch (this.sellState) {
            case WAIT_LIST -> this.sellTickWaitList(now);
            case WAIT_PAGE -> this.sellTickWaitPage(now);
            case WAIT_DEPOSIT -> this.sellTickWaitDeposit(now);
            case HUGO -> this.sellTickHugo(now);
            case CONFIRM -> this.sellTickConfirm(now);
            case FINISH -> this.sellTickFinish(now);
            case SETTLE -> this.sellTickSettle(now);
            case NEXT -> this.startSellSession(now);
            default -> this.startSellSession(now);
        }
        return true;
    }

    private void startSellSessionNow() {
        this.releaseKeys();
        this.sellFailCount = 0;
        this.sellFallbackMode = false;
        this.startSellSession(System.currentTimeMillis());
    }

    /** Picks an item from the inventory and opens the order list (or the /sell menu in fallback mode). */
    private void startSellSession(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.sellNextActionAt = now + this.nextSellDelay();
            this.sellState = SellState.NEXT;
            return;
        }

        class_1792 item = this.findSellableItem();
        if (item == null) {
            this.sellState = SellState.IDLE;
            this.sellRetryAt = now + 1000L;
            return;
        }

        this.sellTargetItem = item;
        this.sellPagesScanned = 0;
        this.sellListSeenAt = 0L;
        this.sellListSyncId = -1;
        this.sellSessionStartCount = this.countSellableItems();

        if (this.sellFallbackMode) {
            player.field_3944.method_45730(this.fallbackCommand.getValue().trim());
            this.sellState = SellState.WAIT_DEPOSIT;
        } else {
            String name = class_7923.field_41178.method_10221(item).method_12832();
            this.sellSearchTerm = this.underscoreToSpace.get() ? name.replace('_', ' ') : name;
            player.field_3944.method_45730(this.orderCommand.getValue().trim() + " " + this.sellSearchTerm);
            this.sellState = SellState.WAIT_LIST;
        }

        this.sellDeadline = now + this.sellTimeout.getInt();
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** Waits for the order list, picks the best order, or flips to the next page. */
    private void sellTickWaitList(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        boolean listOpen = handler != player.field_7498 && this.mc.field_1755 instanceof class_465;

        if (listOpen && this.menuStackCount(handler) > 0) {
            if (this.sellListSeenAt == 0L) {
                this.sellListSeenAt = now;
                this.sellNextActionAt = now + this.nextSellDelay();
                return;
            }

            class_1735 best = this.pickBestOrder(handler);
            if (best != null) {
                this.sellListSyncId = handler.field_7763;
                this.mc.field_1761.method_2906(handler.field_7763, best.field_7874, 0, class_1713.field_7790, (class_1657)player);
                this.sellState = SellState.WAIT_DEPOSIT;
                this.sellDeadline = now + this.sellTimeout.getInt();
                this.sellNextActionAt = now + this.nextSellDelay();
                return;
            }

            if (this.sellPagesScanned + 1 < this.maxPages.getInt()) {
                class_1735 next = this.findNextPageSlot(handler);
                if (next != null) {
                    this.sellListFingerprint = this.menuFingerprint(handler);
                    this.sellListSyncId = handler.field_7763;
                    this.mc.field_1761.method_2906(handler.field_7763, next.field_7874, 0, class_1713.field_7790, (class_1657)player);
                    this.sellPagesScanned++;
                    this.sellState = SellState.WAIT_PAGE;
                    this.sellDeadline = now + Math.min(this.sellTimeout.getInt(), 2500);
                    this.sellNextActionAt = now + this.nextSellDelay();
                    return;
                }
            }

            this.onSellFail(now, "no usable order for " + this.sellSearchTerm);
            return;
        }

        if (now > this.sellDeadline) {
            this.onSellFail(now, "the order list did not open");
        }
    }

    /** After clicking "next page": wait until the list changed, then scan it again. */
    private void sellTickWaitPage(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        boolean listOpen = handler != player.field_7498 && this.mc.field_1755 instanceof class_465;

        if (listOpen && this.menuStackCount(handler) > 0
            && (handler.field_7763 != this.sellListSyncId || !this.menuFingerprint(handler).equals(this.sellListFingerprint))) {
            this.sellState = SellState.WAIT_LIST;
            this.sellListSeenAt = now;
            this.sellNextActionAt = now + this.nextSellDelay();
            return;
        }

        if (now > this.sellDeadline) {
            this.onSellFail(now, "no more pages for " + this.sellSearchTerm);
        }
    }

    /** In the deposit menu, shift-clicks the matching items from the inventory into it. */
    private void sellTickWaitDeposit(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;

        boolean isNewMenu = handler != player.field_7498
            && handler.field_7763 != this.sellListSyncId
            && this.mc.field_1755 instanceof class_465;

        if (!isNewMenu) {
            if (now > this.sellDeadline) {
                this.onSellFail(now, this.sellFallbackMode ? "the sell menu did not open" : "the order did not open");
            }
            return;
        }

        if (this.hugoMode.get() && !this.sellFallbackMode) {
            // Hugo: no deposit chest. Gold button -> red turns green -> green button sells everything.
            this.hugoGoldClicked = false;
            this.hugoGreenClicks = 0;
            this.hugoSyncId = handler.field_7763;
            this.hugoRedSlot = -1;
            this.hugoRedPath = "";
            this.hugoClickedAt = 0L;
            this.hugoDeadline = now + 6000L;
            this.sellState = SellState.HUGO;
            this.sellNextActionAt = now + this.nextSellDelay();
            return;
        }

        for (class_1735 slot : handler.field_7761) {
            if (!(slot.field_7871 instanceof class_1661) || !slot.method_7681()) {
                continue;
            }
            int index = slot.method_34266();
            if (index < 9 || index > 35) {
                continue; // hotbar (tools, food, blocks), armor and offhand are never sold
            }
            if (!this.isSellable(slot.method_7677())) {
                continue;
            }
            this.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)player);
        }

        this.sellState = SellState.CONFIRM;
        this.sellDepositSyncId = handler.field_7763;
        this.sellClosedDeposit = false;
        this.sellConfirmClicks = 0;
        this.sellConfirmSyncId = -1;
        this.sellConfirmClickedAt = 0L;
        this.sellConfirmDeadline = now + 6000L;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** Hugo sell menu: click the gold button, wait until the red button turns green, click the green one. */
    private void sellTickHugo(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;

        if (handler == player.field_7498) {
            if (this.hugoGreenClicks > 0) {
                this.sellState = SellState.FINISH; // confirmed and the server closed the menu
            } else if (now > this.hugoDeadline) {
                this.onSellFail(now, "the sell menu closed before the green button");
            }
            return;
        }

        if (handler.field_7763 != this.hugoSyncId) {
            if (this.hugoGreenClicks > 0) {
                this.sellState = SellState.FINISH; // the server re-opened a list after the sale
                return;
            }
            this.hugoSyncId = handler.field_7763; // the click opened another menu: carry on in it
        }

        if (!this.hugoGoldClicked) {
            class_1735 gold = this.findHugoButton(handler, this.hugoGoldSlot.getInt(), false);
            if (gold != null) {
                this.rememberHugoRed(handler);
                this.clickMenu(handler, gold.field_7874);
                this.hugoGoldClicked = true;
                this.hugoClickedAt = now;
                this.hugoDeadline = now + 6000L;
                this.sellNextActionAt = now + this.nextSellDelay();
            } else if (now > this.hugoDeadline) {
                this.onSellFail(now, "the gold button was not found");
            }
            return;
        }

        class_1735 green = this.findHugoGreen(handler);
        if (green != null && (this.hugoGreenClicks == 0 || (this.hugoGreenClicks < 4 && now - this.hugoClickedAt >= 1500L))) {
            this.clickMenu(handler, green.field_7874);
            this.hugoGreenClicks++;
            this.hugoClickedAt = now;
            this.hugoDeadline = now + 2500L;
            this.sellNextActionAt = now + this.nextSellDelay();
            return;
        }

        if (now > this.hugoDeadline) {
            if (this.hugoGreenClicks > 0) {
                this.sellState = SellState.FINISH;
            } else {
                this.onSellFail(now, "the green button never appeared");
            }
        }
    }

    /** Remembers which slot holds the red button before the gold button is clicked. */
    private void rememberHugoRed(class_1703 handler) {
        int menuSize = handler.field_7761.size() - 36;
        for (int i = 0; i < menuSize; i++) {
            class_1735 slot = handler.field_7761.get(i);
            if (!slot.method_7681() || slot.method_7677().method_7909() == this.sellTargetItem) {
                continue;
            }
            String path = itemPath(slot.method_7677());
            if (path.startsWith("red_") || path.equals("barrier")) {
                this.hugoRedSlot = i;
                this.hugoRedPath = path;
                return;
            }
        }
    }

    /** The green button is the slot where the red one was, once its item changed; otherwise any lime/green item. */
    private class_1735 findHugoGreen(class_1703 handler) {
        int fixed = this.hugoGreenSlot.getInt();
        if (fixed < 0 && this.hugoRedSlot >= 0 && this.hugoRedSlot < handler.field_7761.size() - 36) {
            class_1735 slot = handler.field_7761.get(this.hugoRedSlot);
            if (slot.method_7681() && !itemPath(slot.method_7677()).equals(this.hugoRedPath)) {
                return slot;
            }
        }
        return this.findHugoButton(handler, fixed, true);
    }

    /** Gold (or yellow) button when green is false, green/lime button when true. A fixed slot wins over auto detection. */
    private class_1735 findHugoButton(class_1703 handler, int fixedSlot, boolean green) {
        int menuSize = handler.field_7761.size() - 36;
        if (fixedSlot >= 0) {
            if (fixedSlot < menuSize && handler.field_7761.get(fixedSlot).method_7681()) {
                return handler.field_7761.get(fixedSlot);
            }
            return null;
        }
        class_1735 best = null;
        for (int i = 0; i < menuSize; i++) {
            class_1735 slot = handler.field_7761.get(i);
            if (!slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7909() == this.sellTargetItem) {
                continue;
            }
            String path = itemPath(stack);
            boolean match = green
                ? (path.startsWith("lime_") || path.startsWith("green_"))
                : (path.startsWith("gold") || path.startsWith("yellow_") || path.startsWith("orange_") || path.equals("raw_gold"));
            if (match) {
                best = slot; // on ties the later slot wins
            }
        }
        return best;
    }

    /**
     * After the items are in the deposit menu the server wants that menu closed (the E key) so it can show the
     * confirm menu with the green button. So: close the deposit menu once, wait for the confirm menu, click the
     * green button (searched by item/name, retried inside the same menu), then hand over to FINISH.
     */
    private void sellTickConfirm(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;

        // no container open
        if (handler == player.field_7498) {
            if (this.sellConfirmClicks > 0) {
                this.sellState = SellState.FINISH; // confirmed and the server closed the menu
                return;
            }
            if (this.sellClosedDeposit && now <= this.sellConfirmDeadline) {
                return; // deposit menu closed: waiting for the confirm menu to open
            }
            this.onSellFail(now, "the confirm menu did not open");
            return;
        }

        class_1735 button = this.findConfirmButton(handler);
        boolean sameMenu = handler.field_7763 == this.sellConfirmSyncId;

        if (button != null) {
            // first click in any menu, retries only inside the menu that was already clicked
            if (this.sellConfirmClicks == 0 || (sameMenu && this.sellConfirmClicks < 4 && now - this.sellConfirmClickedAt >= 1500L)) {
                this.clickConfirm(handler, button.field_7874, now);
                return;
            }
        } else if (this.sellConfirmClicks == 0 && !this.sellClosedDeposit && handler.field_7763 == this.sellDepositSyncId) {
            // same as pressing E: leave the deposit menu so the server shows the confirm menu
            this.sellClosedDeposit = true;
            player.method_7346();
            this.sellConfirmDeadline = now + 6000L;
            this.sellNextActionAt = now + this.nextSellDelay();
            return;
        }

        if (this.sellConfirmClicks > 0) {
            // clicked already: a different menu opened (the server re-opens the list) or the click did not register
            if (!sameMenu || now > this.sellConfirmDeadline) {
                this.sellState = SellState.FINISH;
            }
            return;
        }

        if (now > this.sellConfirmDeadline) {
            // nothing recognised as a button: try the configured slot, but only if it is inside the menu part
            int slot = this.sellFallbackMode ? this.fallbackConfirmSlot.getInt() : this.confirmSlot.getInt();
            int menuSize = handler.field_7761.size() - 36;
            if (slot >= 0 && slot < menuSize && !handler.field_7761.get(slot).method_7677().method_7960()) {
                this.clickConfirm(handler, slot, now);
                return;
            }
            this.onSellFail(now, "the confirm button was not found");
        }
    }

    private void clickConfirm(class_1703 handler, int slotId, long now) {
        this.mc.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
        this.sellConfirmSyncId = handler.field_7763;
        this.sellConfirmClickedAt = now;
        this.sellConfirmClicks++;
        this.sellConfirmDeadline = now + 2000L;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** Green stained glass pane (lime or green) or a "confirm"-like name in the menu part (never the player inventory). */
    private class_1735 findConfirmButton(class_1703 handler) {
        int menuSize = Math.min(handler.field_7761.size() - 36, handler.field_7761.size());
        class_1735 best = null;
        int bestScore = 0;
        for (int i = 0; i < menuSize; i++) {
            class_1735 slot = handler.field_7761.get(i);
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7909() == this.sellTargetItem) {
                continue; // an item we just deposited
            }
            String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
            String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
            if (name.contains("cancel") || name.contains("decline") || name.contains("deny")
                || name.contains("h\u1ee7y") || name.contains("t\u1eeb ch\u1ed1i")) {
                continue;
            }
            if (path.equals("red_stained_glass_pane")) {
                continue;
            }
            boolean greenItem = path.equals("lime_stained_glass_pane") || path.equals("green_stained_glass_pane");
            boolean keyword = name.contains("confirm") || name.contains("accept") || name.contains("deliver")
                || name.contains("complete") || name.contains("submit") || name.contains("sell")
                || name.contains("x\u00e1c nh\u1eadn") || name.contains("\u0111\u1ed3ng \u00fd");
            int score = (greenItem ? 2 : 0) + (keyword ? 1 : 0);
            if (score > 0 && score >= bestScore) {
                bestScore = score;
                best = slot; // on ties the later (bottom-right) slot wins
            }
        }
        return best;
    }

    /** Closes the menu, then waits a moment and keeps closing menus the server re-opens after a sale. */
    private void sellTickFinish(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellListSyncId = -1;
        this.sellState = SellState.SETTLE;
        this.sellSettleUntil = now + 2000L;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** The server re-opens the deposit menu / order list after a sale: close every one until things are quiet. */
    private void sellTickSettle(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.sellSettleUntil = Math.max(this.sellSettleUntil, now + 1500L);
            this.sellNextActionAt = now + 150L;
            return;
        }
        if (now < this.sellSettleUntil) {
            return;
        }
        this.sellEvaluate(now);
    }

    /** Checks what was really sold and decides what to do next. */
    private void sellEvaluate(long now) {
        this.sellLastEndAt = now;
        this.sellNextActionAt = now + this.nextSellDelay();

        int left = this.countSellableItems();
        int delta = this.sellSessionStartCount - left;

        if (delta > 0) {
            this.soldTotal += delta;
            if (this.sellFallbackMode) {
                this.soldByFallback += delta;
            } else {
                this.ordersFilled++;
            }
        }

        if (left == 0) {
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.sellState = SellState.IDLE;
            this.sellRetryAt = now + 1000L;
            return;
        }

        if (delta > 0) {
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.sellState = SellState.NEXT;
            return;
        }

        this.onSellFail(now, "the items were not accepted");
    }

    /**
     * A failed attempt (no order, menu did not open, items refused). After "Fallback After" failures in a row
     * the /sell command is used instead; if that fails too, mining continues and selling is retried later.
     */
    private void onSellFail(long now, String reason) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellListSyncId = -1;
        this.sellListSeenAt = 0L;

        if (this.sellFallbackMode) {
            this.say("/sell failed (" + reason + "), mining continues.");
            this.sellFallbackMode = false;
            this.sellFailCount = 0;
            this.abortSellSession(now);
            return;
        }

        this.sellFailCount++;
        if (this.sellFailCount >= this.fallbackAfter.getInt()) {
            this.sellFailCount = 0;
            if (this.fallbackSell.get()) {
                this.say(reason + " (" + this.fallbackAfter.getInt() + " tries), switching to /" + this.fallbackCommand.getValue().trim() + ".");
                this.sellFallbackMode = true;
                this.sellState = SellState.NEXT;
                this.sellNextActionAt = now + this.nextSellDelay();
            } else {
                this.say(reason + ", mining continues.");
                this.abortSellSession(now);
            }
            return;
        }

        this.sellState = SellState.NEXT;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    private void abortSellSession(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellListSyncId = -1;
        this.sellState = SellState.IDLE;
        this.sellLastEndAt = now;
        this.sellRetryAt = now + 15000L; // keep mining, try again later
    }

    private void resetAutoSell(boolean closeMenu) {
        class_746 player = this.mc.field_1724;
        if (closeMenu && this.sellState != SellState.IDLE && player != null && player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellState = SellState.IDLE;
        this.sellListSyncId = -1;
        this.sellListSeenAt = 0L;
        this.sellNextActionAt = 0L;
        this.sellWarnedNoItems = false;
        this.sellFailCount = 0;
        this.sellFallbackMode = false;
    }

    /** Sell Delay, plus a random extra amount when Random Delay is on. */
    private long nextSellDelay() {
        long base = this.sellDelay.getInt();
        if (!this.randomDelay.get()) {
            return base;
        }
        long extra = (long)((double)base * (double)this.delayJitter.get() / 100.0);
        return base + ThreadLocalRandom.current().nextLong(extra + 1L);
    }

    // ---------------------------------------------------------------- order list helpers

    /** The order that wants our item with the highest price (or the first one when Best Price is off). */
    private class_1735 pickBestOrder(class_1703 handler) {
        class_1735 best = null;
        double bestValue = -2.0;
        double min = this.minPrice.get();

        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7909() != this.sellTargetItem) {
                continue;
            }

            double price = this.parsePrice(stack); // -1 when no price could be read
            if (min > 0.0 && price < min) {
                continue;
            }
            if (!this.bestPrice.get()) {
                return slot;
            }
            if (price > bestValue) {
                bestValue = price;
                best = slot;
            }
        }
        return best;
    }

    /** Reads a price like "$1,500", "$2.5K" or "$3M" from the item's lore. Returns -1 when none is found. */
    private double parsePrice(class_1799 stack) {
        class_9290 lore = (class_9290)stack.method_58694(class_9334.field_49632);
        if (lore == null) {
            return -1.0;
        }

        String keyword = this.priceKeyword.getValue().trim().toLowerCase(Locale.ROOT);
        for (class_2561 line : lore.comp_2400()) {
            String text = line.getString();
            String tail = text;
            if (!keyword.isEmpty()) {
                int at = text.toLowerCase(Locale.ROOT).indexOf(keyword);
                if (at < 0) {
                    continue;
                }
                tail = text.substring(at + keyword.length());
            }

            Matcher matcher = PRICE_PATTERN.matcher(tail);
            if (matcher.find()) {
                try {
                    double value = Double.parseDouble(matcher.group(1).replace(",", ""));
                    switch (matcher.group(2).toLowerCase(Locale.ROOT)) {
                        case "k" -> value *= 1_000.0;
                        case "m" -> value *= 1_000_000.0;
                        case "b" -> value *= 1_000_000_000.0;
                        case "t" -> value *= 1_000_000_000_000.0;
                        default -> { }
                    }
                    return value;
                } catch (NumberFormatException ignored) {
                    // try the next line
                }
            }
        }
        return -1.0;
    }

    private class_1735 findNextPageSlot(class_1703 handler) {
        int index = this.nextPageSlot.getInt();
        if (index >= 0) {
            if (index < handler.field_7761.size()) {
                class_1735 slot = handler.field_7761.get(index);
                if (!(slot.field_7871 instanceof class_1661) && slot.method_7681()) {
                    return slot;
                }
            }
            return null;
        }

        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            if (slot.method_7677().method_7964().getString().toLowerCase(Locale.ROOT).contains("next")) {
                return slot;
            }
        }
        return null;
    }

    private int menuStackCount(class_1703 handler) {
        int count = 0;
        for (class_1735 slot : handler.field_7761) {
            if (!(slot.field_7871 instanceof class_1661) && slot.method_7681()) {
                count++;
            }
        }
        return count;
    }

    /** Cheap fingerprint of the menu part of a screen, used to notice that the page changed. */
    private String menuFingerprint(class_1703 handler) {
        StringBuilder sb = new StringBuilder();
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            sb.append(slot.field_7874).append(':').append(stack.method_7909()).append('x').append(stack.method_7947())
                .append('#').append(Objects.hashCode(stack.method_58694(class_9334.field_49632))).append(';');
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- inventory helpers

    /** Sell Items, or the Target Blocks if Sell Items is empty. */
    private List<String> sellFilter() {
        List<String> list = this.sellItems.get();
        if (list.isEmpty()) {
            list = this.targetBlocks.get();
        }
        return list;
    }

    private boolean isSellable(class_1799 stack) {
        List<String> filter = this.sellFilter();
        if (filter.isEmpty() || stack.method_7960()) {
            return false;
        }
        return Sell.e(stack, filter);
    }

    /** First sellable item sitting in the main inventory (not the hotbar), or null. */
    private class_1792 findSellableItem() {
        if (this.mc.field_1724 == null) {
            return null;
        }
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 9; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (this.isSellable(stack)) {
                return stack.method_7909();
            }
        }
        return null;
    }

    private int countSellableItems() {
        if (this.mc.field_1724 == null) {
            return 0;
        }
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 9; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (this.isSellable(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private boolean isInventoryFullEnough() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int free = 0;
        for (int i = 0; i <= 35; i++) {
            if (inventory.method_5438(i).method_7960()) {
                free++;
            }
        }
        return free <= this.freeSlotsToSell.getInt();
    }

    // ================================================================ Auto Eat

    private static String itemPath(class_1799 stack) {
        return class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
    }

    private boolean isFood(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        List<String> custom = this.foodItems.get();
        if (!custom.isEmpty()) {
            return Sell.e(stack, custom);
        }
        return COMMON_FOODS.contains(itemPath(stack));
    }

    /** Food only counts when it sits in the hotbar (the hotbar is never sold). */
    private int findFoodSlot() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int golden = -1;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!this.isFood(stack)) {
                continue;
            }
            String path = itemPath(stack);
            if (path.equals("golden_apple") || path.equals("enchanted_golden_apple")) {
                if (golden < 0) {
                    golden = i; // only eaten when there is no normal food left
                }
                continue;
            }
            return i;
        }
        return golden;
    }

    /** Hotbar slot (0-8) that is currently in the main hand. */
    private int selectedHotbar() {
        int tool = this.toolSlot.getInt();
        if (tool >= 1 && tool <= 9) {
            return tool - 1;
        }
        class_746 player = this.mc.field_1724;
        class_1799 held = player.method_6047();
        class_1661 inventory = player.method_31548();
        for (int i = 0; i <= 8; i++) {
            if (inventory.method_5438(i) == held) {
                return i;
            }
        }
        return 0;
    }

    /** Eats when the hunger bar lost "Eat When Hunger Lost" bars (1 bar = 2 food points). Returns true while eating. */
    private boolean tickEat() {
        if (!this.autoEat.get()) {
            return false;
        }
        class_310 mc = this.mc;
        class_746 player = mc.field_1724;
        long now = System.currentTimeMillis();
        int food = player.method_7344().method_7586();

        if (!this.eating) {
            if (now < this.eatRetryAt || mc.field_1755 != null || this.sellState != SellState.IDLE
                || this.repairState != RepairState.IDLE || player.method_29504()) {
                return false;
            }
            if (food > 20 - this.eatHungerBars.getInt() * 2) {
                return false;
            }
            int slot = this.findFoodSlot();
            if (slot < 0) {
                if (this.autoBuyFood.get() && this.repairState == RepairState.IDLE && now >= this.foodBuyRetryAt) {
                    this.startFoodPurchase(now);
                    return true;
                }
                if (!this.eatWarned) {
                    this.say("Hungry but there is no food in the hotbar.");
                    this.eatWarned = true;
                }
                this.eatRetryAt = now + 10000L;
                return false;
            }
            this.eatWarned = false;
            this.releaseKeys();
            mc.field_1761.method_2925();
            this.eatPrevSlot = this.selectedHotbar();
            this.eatSlot = slot;
            this.eatSawUse = false;
            this.eatIdleTicks = 0;
            this.eatItems = 0;
            this.eating = true;
            player.method_31548().method_61496(slot);
            return true;
        }

        if (mc.field_1755 != null || player.method_29504()) {
            this.stopEating(now, 5000L);
            return false;
        }

        this.releaseKeys();
        class_1661 inventory = player.method_31548();
        if (!this.isFood(inventory.method_5438(this.eatSlot))) {
            int next = this.findFoodSlot();
            if (next < 0) {
                this.stopEating(now, 10000L);
                return true;
            }
            this.eatSlot = next;
        }
        inventory.method_61496(this.eatSlot);

        boolean using = player.method_6115();
        if (food >= 19 && !using) {
            this.stopEating(now, 0L); // full enough
            return true;
        }

        mc.field_1690.field_1904.method_23481(true); // hold "use" to eat
        if (using) {
            this.eatSawUse = true;
            this.eatIdleTicks = 0;
        } else if (this.eatSawUse) {
            this.eatSawUse = false; // one item finished
            this.eatIdleTicks = 0;
            if (++this.eatItems >= 10) {
                this.stopEating(now, 5000L);
            }
        } else if (++this.eatIdleTicks > 40) {
            this.say("Could not eat (the server refused or the item cannot be eaten now).");
            this.stopEating(now, 15000L);
        }
        return true;
    }

    private void stopEating(long now, long retryDelay) {
        this.releaseKeys();
        if (this.eating && this.eatPrevSlot >= 0 && this.mc.field_1724 != null) {
            this.mc.field_1724.method_31548().method_61496(this.eatPrevSlot);
        }
        this.eating = false;
        this.eatPrevSlot = -1;
        this.eatRetryAt = now + retryDelay;
    }

    private void resetEat() {
        if (this.eating) {
            this.stopEating(System.currentTimeMillis(), 0L);
        }
        this.eating = false;
        this.eatPrevSlot = -1;
        this.eatWarned = false;
    }

    // ================================================================ Auto Repair (Mending + XP bottles)

    /** The tool that is being used to mine: the Tool Hotbar Slot when set, otherwise the main hand. */
    private class_1799 currentTool() {
        class_746 player = this.mc.field_1724;
        int slot = this.toolSlot.getInt();
        if (slot >= 1 && slot <= 9) {
            return player.method_31548().method_5438(slot - 1);
        }
        return player.method_6047();
    }

    private boolean hasMending(class_1799 stack) {
        // The enchantment component prints its enchantments (with the registry id) in toString().
        Object enchantments = stack.method_58694(class_9334.field_49633);
        return enchantments != null && String.valueOf(enchantments).toLowerCase(Locale.ROOT).contains("mending");
    }

    private boolean isHealthy(class_1799 tool) {
        if (tool.method_7960() || !tool.method_7963()) {
            return true;
        }
        int max = tool.method_7936();
        return (max - tool.method_7919()) >= max * this.repairUntil.get() / 100.0f;
    }

    private static boolean isBottle(class_1799 stack) {
        return !stack.method_7960() && itemPath(stack).equals("experience_bottle");
    }

    private int countBottles() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 0; i <= 40; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (isBottle(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private int findBottleIndex() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 35; i++) {
            if (isBottle(inventory.method_5438(i))) {
                return i;
            }
        }
        return -1;
    }

    private boolean hasRoomForBottles() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || (isBottle(stack) && stack.method_7947() < stack.method_7914())) {
                return true;
            }
        }
        return false;
    }

    private static int playerSlotId(int inventoryIndex) {
        return inventoryIndex < 9 ? inventoryIndex + 36 : inventoryIndex; // hotbar is 36-44 in the player screen handler
    }

    private void clickMenu(class_1703 handler, int slotId) {
        this.mc.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
    }

    /**
     * Watches the durability of the mining tool. When it gets low: with Mending the bot buys XP bottles in /shop,
     * throws them at its feet (from the offhand, so the tool in the main hand is the one that gets repaired) and goes
     * on mining. Without Mending it stops before the tool breaks. Returns true while it uses the tick.
     */
    private boolean tickRepair() {
        if (!this.autoRepair.get() && this.repairState == RepairState.IDLE) {
            return false;
        }
        class_310 mc = this.mc;
        class_746 player = mc.field_1724;
        long now = System.currentTimeMillis();

        if (this.repairState == RepairState.IDLE) {
            if (this.eating || this.sellState != SellState.IDLE || mc.field_1755 != null || player.method_29504()) {
                return false;
            }
            class_1799 tool = this.currentTool();
            if (tool.method_7960() || !tool.method_7963()) {
                return false;
            }
            int max = tool.method_7936();
            int remaining = max - tool.method_7919();
            int threshold = Math.max(8, (int)(max * this.repairBelow.get() / 100.0f));
            if (remaining > threshold) {
                return false;
            }

            boolean mending = this.hasMending(tool);
            if (remaining <= 5 && this.stopWhenBreaking.get() && (!mending || now < this.repairRetryAt)) {
                String msg = "Tool is about to break (" + remaining + " uses left)" + (mending ? " and repairing failed." : " and it has no Mending.");
                this.say(msg + " Stopping.");
                this.sendWebhook("**[Auto Mine Sell]** " + msg);
                this.releaseKeys();
                this.requestDisable();
                return true;
            }
            if (!mending || now < this.repairRetryAt) {
                return false;
            }

            this.releaseKeys();
            mc.field_1761.method_2925();
            this.repairCycles = 0;
            this.say("Tool is almost broken (" + remaining + " uses left), repairing with XP bottles.");
            this.beginRepairCycle(now);
            return true;
        }

        if (this.repairState == RepairState.THROW) {
            this.repairTickThrow(now);
            return true;
        }

        this.releaseKeys();
        if (player.method_29504()) {
            this.failRepair(now, "you died");
            return true;
        }
        if (now < this.repairNextAt) {
            return true;
        }

        switch (this.repairState) {
            case OPEN_SHOP -> this.repairOpenShop(now);
            case FIND_BOTTLE -> this.repairFindBottle(now);
            case BUY -> this.repairTickBuy(now);
            case EQUIP -> this.repairEquip(now);
            case FINISH -> this.repairFinish(now);
            case CHECK -> this.repairCheck(now);
            case FOOD_STOW -> this.foodStow(now);
            default -> { }
        }
        return true;
    }

    /** Starts one buy + throw round. XP bottles that are already in the inventory are used first. */
    private void beginRepairCycle(long now) {
        this.repairTried.clear();
        this.repairBuysDone = 0;
        if (this.countBottles() > 0) {
            this.repairState = RepairState.EQUIP;
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }
        this.startPurchase(now);
    }

    private void startPurchase(long now) {
        if (!this.hasRoomForBottles()) {
            this.failRepair(now, "no free slot for XP bottles (sell or drop something)");
            return;
        }
        this.shopFood = false;
        this.repairBottlesBefore = this.countBottles();
        this.repairState = RepairState.OPEN_SHOP;
        this.repairNextAt = now + this.nextSellDelay();
    }

    private void repairOpenShop(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }
        this.repairSyncId = player.field_7512.field_7763;
        this.repairDepth = 0;
        this.repairSeenAt = 0L;
        player.field_3944.method_45730(this.shopCommand.getValue().trim());
        this.repairState = RepairState.FIND_BOTTLE;
        this.repairDeadline = now + this.sellTimeout.getInt();
        this.repairNextAt = now + this.nextSellDelay();
    }

    /** In the shop: click the XP bottle when it is visible, otherwise open the categories one by one. */
    private void repairFindBottle(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        boolean open = handler != player.field_7498 && this.mc.field_1755 instanceof class_465
            && handler.field_7763 != this.repairSyncId;

        if (!open || this.menuStackCount(handler) == 0) {
            if (now > this.repairDeadline) {
                this.failRepair(now, this.repairDepth == 0 ? "the shop did not open" : "the shop category did not open");
            }
            return;
        }
        if (this.repairSeenAt == 0L) {
            this.repairSeenAt = now; // let the items load
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }

        class_1735 bottle = this.findMenuItem(handler, this.shopWantPath());
        if (bottle != null) {
            if (this.repairDepth == 1) {
                int before = this.shopFood ? this.foodKnownCategory : this.repairKnownCategory;
                if (this.shopFood) {
                    this.foodKnownCategory = this.repairLastCategory;
                } else {
                    this.repairKnownCategory = this.repairLastCategory; // remember where the bottle is
                }
                if (before != this.repairLastCategory) {
                    this.saveMemory();
                }
            }
            this.clickMenu(handler, bottle.field_7874);
            this.repairSyncId = handler.field_7763;
            this.repairConfirmClicks = 0;
            this.repairAmountClicked = false;
            this.lastBuyClick = -1;
            this.repairBuyAt = now;
            this.repairState = RepairState.BUY;
            this.repairDeadline = now + this.sellTimeout.getInt();
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }

        if (this.repairDepth == 0) {
            class_1735 category = this.pickCategory(handler);
            if (category == null) {
                this.dumpMenu(handler);
                this.failRepair(now, "no " + this.shopWantPath() + " found in the shop (set Shop " + (this.shopFood ? "Food " : "") + "Category Slot)");
                return;
            }
            this.repairTried.add(category.field_7874);
            this.repairLastCategory = category.field_7874;
            this.clickMenu(handler, category.field_7874);
            this.repairSyncId = handler.field_7763;
            this.repairDepth = 1;
            this.repairSeenAt = 0L;
            this.repairDeadline = now + this.sellTimeout.getInt();
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }

        // this category has no XP bottle: back to the main shop menu, next category
        player.method_7346();
        this.repairState = RepairState.OPEN_SHOP;
        this.repairNextAt = now + this.nextSellDelay();
    }

    /** After clicking the bottle: click the amount slot / confirm button if a purchase menu opens, until the bottles arrive. */
    private void repairTickBuy(long now) {
        class_746 player = this.mc.field_1724;
        int have = this.countWanted();

        if (have > this.repairBottlesBefore && now - this.repairBuyAt >= 700L) {
            this.learnBuyButton(have - this.repairBottlesBefore);
            this.repairBuysDone++;
            this.repairBottlesBefore = have;
            if (player.field_7512 != player.field_7498) {
                player.method_7346();
            }
            if (this.shopFood) {
                this.repairState = RepairState.FOOD_STOW;
                this.repairNextAt = now + this.nextSellDelay();
                return;
            }
            if (this.repairBuysDone < this.shopBuyRepeats.getInt() && this.hasRoomForBottles()) {
                this.repairTried.clear();
                this.repairState = RepairState.OPEN_SHOP;
            } else {
                this.repairCycles++;
                this.repairState = RepairState.EQUIP;
            }
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }

        class_1703 handler = player.field_7512;
        boolean open = handler != player.field_7498 && this.mc.field_1755 instanceof class_465;
        if (open) {
            if (handler.field_7763 != this.repairSyncId) {
                // a purchase menu opened (or the click led to another shop list)
                int amount = this.shopAmountSlot.getInt();
                int menuSize = handler.field_7761.size() - 36;
                if (!this.repairAmountClicked && amount >= 0 && amount < menuSize && handler.field_7761.get(amount).method_7681()) {
                    this.repairAmountClicked = true;
                    this.clickMenu(handler, amount);
                    this.repairBuyAt = now;
                    this.repairNextAt = now + this.nextSellDelay();
                    return;
                }
                class_1735 button = this.chooseBuyButton(handler);
                if (button != null) {
                    if (this.repairConfirmClicks < 3 && now - this.repairBuyAt >= 900L) {
                        this.repairConfirmClicks++;
                        this.lastBuyClick = button.field_7874;
                        this.clickMenu(handler, button.field_7874);
                        this.repairBuyAt = now;
                        this.repairNextAt = now + this.nextSellDelay();
                        return;
                    }
                } else {
                    class_1735 bottle = this.findMenuItem(handler, this.shopWantPath());
                    if (bottle != null && this.repairConfirmClicks < 3 && now - this.repairBuyAt >= 900L) {
                        this.repairConfirmClicks++;
                        this.clickMenu(handler, bottle.field_7874);
                        this.repairBuyAt = now;
                        this.repairNextAt = now + this.nextSellDelay();
                        return;
                    }
                }
            }
        }

        if (now > this.repairDeadline) {
            this.dumpMenu(handler);
            this.failRepair(now, "the purchase did not go through (not enough money, or the menu layout differs)");
        }
    }

    /** Puts the XP bottles in the offhand (swapping with whatever is there, e.g. a totem) and starts throwing. */
    private void repairEquip(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }

        int tool = this.toolSlot.getInt();
        if (tool >= 1 && tool <= 9) {
            player.method_31548().method_61496(tool - 1); // the tool must be in the main hand
        }

        this.repairSwapped = false;
        if (!isBottle(player.method_6079())) {
            int index = this.findBottleIndex();
            if (index < 0) {
                this.failRepair(now, "no XP bottles to throw");
                return;
            }
            class_1799 off = player.method_6079();
            this.repairOldOffhand = off.method_7960() ? null : off.method_7909();
            this.repairBottleSlot = index;
            this.mc.field_1761.method_2906(player.field_7498.field_7763, playerSlotId(index), 40, class_1713.field_7791, (class_1657)player);
            this.repairSwapped = true;
        }

        this.repairPrevPitch = player.method_36455();
        this.repairPitchChanged = true;
        this.repairThrowTicks = 0;
        this.repairEmptyTicks = 0;
        this.repairState = RepairState.THROW;
    }

    /** Looks down and holds "use": the bottle in the offhand is thrown at the feet, the orbs repair the tool in the main hand. */
    private void repairTickThrow(long now) {
        class_746 player = this.mc.field_1724;
        this.releaseKeys();

        boolean healthy = this.isHealthy(this.currentTool());
        boolean hasBottles = isBottle(player.method_6079());
        this.repairThrowTicks++;

        if (healthy || this.repairThrowTicks > 6000) {
            this.repairState = RepairState.FINISH;
            this.repairNextAt = now + 1200L; // let the last orbs arrive
            return;
        }
        if (!hasBottles) {
            if (++this.repairEmptyTicks > 25) {
                this.repairState = RepairState.FINISH;
                this.repairNextAt = now;
            }
            return;
        }

        player.method_36457(90.0f);
        if (this.repairThrowTicks > 2 && this.mc.field_1755 == null) {
            this.mc.field_1690.field_1904.method_23481(true);
        }
    }

    private void repairFinish(long now) {
        class_746 player = this.mc.field_1724;
        this.releaseKeys();
        this.restoreOffhand();
        if (this.repairPitchChanged) {
            player.method_36457(this.repairPrevPitch);
            this.repairPitchChanged = false;
        }
        this.repairState = RepairState.CHECK;
        this.repairNextAt = now + this.nextSellDelay();
    }

    private void repairCheck(long now) {
        if (this.isHealthy(this.currentTool())) {
            this.say("Tool repaired.");
            this.repairState = RepairState.IDLE;
            this.repairRetryAt = now + 3000L;
            return;
        }
        if (this.repairCycles < this.repairMaxCycles.getInt()) {
            this.beginRepairCycle(now);
            return;
        }
        this.failRepair(now, "the tool is still low after " + this.repairCycles + " cycle(s)");
    }

    private void failRepair(long now, String reason) {
        class_746 player = this.mc.field_1724;
        this.releaseKeys();
        if (player != null && player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.restoreOffhand();
        if (player != null && this.repairPitchChanged) {
            player.method_36457(this.repairPrevPitch);
        }
        this.repairPitchChanged = false;
        String label = this.shopFood ? "Auto Buy Food" : "Auto Repair";
        this.say(label + " failed: " + reason + ". Trying again in 60 s.");
        this.sendWebhook("**[Auto Mine Sell]** " + label + " failed: " + reason);
        this.repairState = RepairState.IDLE;
        if (this.shopFood) {
            this.foodBuyRetryAt = now + 60000L;
        } else {
            this.repairRetryAt = now + 60000L;
        }
        this.shopFood = false;
    }

    /** Swaps the offhand back: remaining bottles return to the slot they came from and the old offhand item (totem) returns. */
    private void restoreOffhand() {
        class_746 player = this.mc.field_1724;
        boolean wasSwapped = this.repairSwapped;
        this.repairSwapped = false;
        if (!wasSwapped || player == null || this.mc.field_1761 == null || this.repairBottleSlot < 0) {
            return;
        }
        if (player.field_7512 != player.field_7498) {
            return;
        }
        class_1799 inSlot = player.method_31548().method_5438(this.repairBottleSlot);
        class_1799 off = player.method_6079();
        boolean unchanged = this.repairOldOffhand == null ? inSlot.method_7960() : inSlot.method_7909() == this.repairOldOffhand;
        if (!unchanged || (off.method_7960() && inSlot.method_7960())) {
            return; // something else moved in meanwhile: do not shuffle the inventory
        }
        this.mc.field_1761.method_2906(player.field_7498.field_7763, playerSlotId(this.repairBottleSlot), 40, class_1713.field_7791, (class_1657)player);
    }

    private void resetRepair(boolean closeMenu) {
        class_746 player = this.mc.field_1724;
        if (this.repairState != RepairState.IDLE && player != null) {
            this.releaseKeys();
            if (closeMenu && player.field_7512 != player.field_7498) {
                player.method_7346();
            }
            this.restoreOffhand();
            if (this.repairPitchChanged) {
                player.method_36457(this.repairPrevPitch);
            }
        }
        this.repairPitchChanged = false;
        this.repairSwapped = false;
        this.repairState = RepairState.IDLE;
        this.shopFood = false;
        this.repairTried.clear();
        this.repairSyncId = -1;
    }

    // ---------------------------------------------------------------- food shopping (same flow as the XP bottles)

    /** Item id the shop flow is looking for right now. */
    private String shopWantPath() {
        if (!this.shopFood) {
            return "experience_bottle";
        }
        String id = this.shopFoodItem.getValue().trim().toLowerCase(Locale.ROOT);
        return id.startsWith("minecraft:") ? id.substring(10) : id;
    }

    private int countWanted() {
        String want = this.shopWantPath();
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 0; i <= 40; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && itemPath(stack).equals(want)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private boolean hasRoomForWanted() {
        String want = this.shopWantPath();
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || (itemPath(stack).equals(want) && stack.method_7947() < stack.method_7914())) {
                return true;
            }
        }
        return false;
    }

    /** No food in the hotbar: /shop -> category -> food -> green button (1 stack), then move it to the hotbar. */
    private void startFoodPurchase(long now) {
        this.shopFood = true;
        if (this.shopWantPath().isEmpty()) {
            this.shopFood = false;
            this.say("Auto Buy Food: set the Shop Food Item (id, e.g. cooked_beef).");
            this.foodBuyRetryAt = now + 30000L;
            return;
        }
        if (!this.hasRoomForWanted()) {
            this.shopFood = false;
            this.say("No food and no free slot to buy some (sell or drop something).");
            this.foodBuyRetryAt = now + 30000L;
            return;
        }
        this.releaseKeys();
        this.mc.field_1761.method_2925();
        this.say("No food in the hotbar, buying " + this.shopWantPath() + " in /shop.");
        this.repairTried.clear();
        this.repairBuysDone = 0;
        this.repairBottlesBefore = this.countWanted();
        this.repairState = RepairState.OPEN_SHOP;
        this.repairNextAt = now + this.nextSellDelay();
    }

    /** Moves the bought food into a free hotbar slot (eating only looks at the hotbar). */
    private void foodStow(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.repairNextAt = now + this.nextSellDelay();
            return;
        }
        String want = this.shopWantPath();
        class_1661 inventory = player.method_31548();
        boolean inHotbar = false;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && itemPath(stack).equals(want)) {
                inHotbar = true;
                break;
            }
        }
        if (!inHotbar) {
            int from = -1;
            for (int i = 9; i <= 35; i++) {
                class_1799 stack = inventory.method_5438(i);
                if (!stack.method_7960() && itemPath(stack).equals(want)) {
                    from = i;
                    break;
                }
            }
            int tool = this.toolSlot.getInt();
            int dest = -1;
            for (int i = 0; i <= 8; i++) {
                if (i != tool - 1 && inventory.method_5438(i).method_7960()) {
                    dest = i;
                    break;
                }
            }
            if (from >= 0 && dest >= 0) {
                this.mc.field_1761.method_2906(player.field_7498.field_7763, from, dest, class_1713.field_7791, (class_1657)player);
            } else if (from >= 0) {
                this.say("Bought food but the hotbar is full: put it in a hotbar slot yourself.");
            }
        }
        this.say("Bought food: " + this.countWanted() + "x " + want + ".");
        this.shopFood = false;
        this.repairState = RepairState.IDLE;
        this.eatRetryAt = now + 500L;
    }

    // ---------------------------------------------------------------- shop menu helpers

    private class_1735 findMenuItem(class_1703 handler, String path) {
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            if (itemPath(slot.method_7677()).equals(path)) {
                return slot;
            }
        }
        return null;
    }

    /** The next shop category to try: the fixed slot, the one that worked before, then every icon that is not a filler/back button. */
    private class_1735 pickCategory(class_1703 handler) {
        int menuSize = handler.field_7761.size() - 36;
        int fixed = this.shopFood ? this.shopFoodCategorySlot.getInt() : this.shopCategorySlot.getInt();
        int prefer = fixed >= 0 ? fixed : (this.shopFood ? this.foodKnownCategory : this.repairKnownCategory);
        if (prefer >= 0 && prefer < menuSize && !this.repairTried.contains(prefer)) {
            class_1735 slot = handler.field_7761.get(prefer);
            if (slot.method_7681()) {
                return slot;
            }
        }
        if (fixed >= 0) {
            return null;
        }
        for (int i = 0; i < menuSize; i++) {
            if (this.repairTried.contains(i)) {
                continue;
            }
            class_1735 slot = handler.field_7761.get(i);
            if (!slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            String path = itemPath(stack);
            String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
            if (path.endsWith("_stained_glass_pane") || path.equals("barrier")) {
                continue;
            }
            if (name.contains("close") || name.contains("back") || name.contains("next") || name.contains("previous") || name.contains("balance")) {
                continue;
            }
            return slot;
        }
        return null;
    }

    /** The remembered "buy a stack" button first, otherwise the best green/confirm button (highest slot wins a tie = bottom right). */
    private class_1735 chooseBuyButton(class_1703 handler) {
        int menuSize = handler.field_7761.size() - 36;
        int mem = this.shopFood ? this.buyBtnFood : this.buyBtnBottle;
        if (mem >= 0 && mem < menuSize) {
            class_1735 slot = handler.field_7761.get(mem);
            if (slot.method_7681()) {
                class_1799 stack = slot.method_7677();
                String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
                if (!itemPath(stack).equals("red_stained_glass_pane") && !name.contains("cancel")) {
                    return slot;
                }
            }
        }
        class_1735 found = this.findBuyButton(handler);
        if (found == null && !this.buyBad.isEmpty()) {
            this.buyBad.clear();
            found = this.findBuyButton(handler);
        }
        return found;
    }

    /** After a purchase: a button that gave a full stack becomes the default, one that gave less is skipped next time. */
    private void learnBuyButton(int gained) {
        int clicked = this.lastBuyClick;
        this.lastBuyClick = -1;
        if (clicked < 0 || gained <= 0) {
            return;
        }
        String want = this.shopWantPath();
        int max = 64;
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 40; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && itemPath(stack).equals(want)) {
                max = stack.method_7914();
                break;
            }
        }
        int mem = this.shopFood ? this.buyBtnFood : this.buyBtnBottle;
        if (gained >= max) {
            if (mem != clicked) {
                if (this.shopFood) {
                    this.buyBtnFood = clicked;
                } else {
                    this.buyBtnBottle = clicked;
                }
                this.say("Remembered buy button: slot " + clicked + " (" + gained + "x " + want + ").");
                this.saveMemory();
            }
            this.buyBad.remove(clicked);
        } else {
            this.buyBad.add(clicked); // bought less than a stack: try another button next time
            if (mem == clicked) {
                if (this.shopFood) {
                    this.buyBtnFood = -1;
                } else {
                    this.buyBtnBottle = -1;
                }
                this.saveMemory();
            }
        }
    }

    /** Green pane or a confirm/buy-like name in the menu part of a purchase menu. */
    private class_1735 findBuyButton(class_1703 handler) {
        int menuSize = Math.min(handler.field_7761.size() - 36, handler.field_7761.size());
        class_1735 best = null;
        int bestScore = 0;
        for (int i = 0; i < menuSize; i++) {
            class_1735 slot = handler.field_7761.get(i);
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681() || this.buyBad.contains(i)) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            String path = itemPath(stack);
            String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
            if (name.contains("cancel") || name.contains("decline") || name.contains("deny")
                || name.contains("h\u1ee7y") || name.contains("t\u1eeb ch\u1ed1i") || path.equals("red_stained_glass_pane")) {
                continue;
            }
            boolean green = path.equals("lime_stained_glass_pane") || path.equals("green_stained_glass_pane");
            boolean keyword = name.contains("confirm") || name.contains("buy") || name.contains("purchase") || name.contains("accept")
                || name.contains("x\u00e1c nh\u1eadn");
            int score = (green ? 2 : 0) + (keyword ? 1 : 0);
            if (score > 0 && score >= bestScore) {
                bestScore = score;
                best = slot;
            }
        }
        return best;
    }

    /** Prints the slots of the open menu so Shop Category Slot / Shop Amount Slot can be set by hand. */
    private void dumpMenu(class_1703 handler) {
        if (handler == null || handler == this.mc.field_1724.field_7498) {
            return;
        }
        StringBuilder sb = new StringBuilder("Shop menu: ");
        int shown = 0;
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            String path = itemPath(stack);
            if (path.endsWith("_stained_glass_pane")) {
                continue;
            }
            sb.append(slot.field_7874).append('=').append(path).append(" | ");
            if (++shown >= 24) {
                break;
            }
        }
        this.say(sb.toString());
    }

    // ================================================================ Safety

    /** Leaves the server when a totem pops or another player gets close. Returns true if it did. */
    private boolean tickSafety() {
        class_310 mc = this.mc;
        if (this.safetyTriggered || mc.field_1724.method_29504()) {
            return false;
        }

        if (this.disconnectOnTotem.get()) {
            int totems = this.countTotems();
            if (this.lastTotemCount >= 0 && totems < this.lastTotemCount) {
                this.safetyDisconnect("Totem popped (" + totems + " left)");
                return true;
            }
            this.lastTotemCount = totems;
        }

        if (this.disconnectOnPlayer.get()) {
            double range = this.playerRange.get();
            double rangeSq = range * range;
            Set<String> ignored = new HashSet<>();
            for (String name : this.ignoredPlayers.getValue().split(",")) {
                if (!name.isBlank()) {
                    ignored.add(name.trim().toLowerCase(Locale.ROOT));
                }
            }

            List<String> found = new ArrayList<>();
            for (class_1657 other : mc.field_1687.method_18456()) {
                if (other == mc.field_1724) {
                    continue;
                }
                double distSq = mc.field_1724.method_5858(other);
                if (distSq > rangeSq) {
                    continue;
                }
                String name = other.method_5477().getString();
                if (ignored.contains(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                found.add(name + " (" + (int)Math.sqrt(distSq) + " blocks)");
            }

            if (!found.isEmpty()) {
                this.safetyDisconnect("Player nearby: " + String.join(", ", found));
                return true;
            }
        }
        return false;
    }

    private int countTotems() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 0; i <= 40; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8288) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private void safetyDisconnect(String reason) {
        if (this.safetyTriggered) {
            return;
        }
        this.safetyTriggered = true;

        class_2338 pos = this.mc.field_1724.method_24515();
        String server = this.mc.method_1558() != null ? this.mc.method_1558().field_3761 : "singleplayer";
        String message = "**[Auto Mine Sell] Disconnected**\n"
            + "Reason: " + reason + "\n"
            + "Server: " + server + "\n"
            + "Position: " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260() + "\n"
            + "Sold this run: " + this.soldTotal + " items (orders: " + this.ordersFilled + ", /sell: " + this.soldByFallback + ")";

        this.sendWebhook(message);
        this.say(reason + " - leaving the server.");
        this.lootMovingAge = -1;
        this.releaseKeys();
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("Auto Mine Sell: " + reason)));
        this.requestDisable();
    }

    // ================================================================ Webhook

    private void sendWebhookTest() {
        if (!this.webhookUrl.getValue().trim().startsWith("https://")) {
            this.say("Set a Webhook URL (https://...) first.");
            return;
        }
        this.sendWebhook("**[Auto Mine Sell]** Webhook test OK.");
        this.say("Webhook test sent.");
    }

    /** Sends a message to the Discord webhook in the background. Does nothing without a valid URL. */
    private void sendWebhook(String content) {
        String url = this.webhookUrl.getValue().trim();
        if (!url.startsWith("https://")) {
            return;
        }

        String ping = this.webhookPing.getValue().trim();
        String body = "{\"content\":\"" + jsonEscape((ping.isEmpty() ? "" : ping + "\n") + content) + "\"}";

        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
            WEBHOOK_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.discarding()).exceptionally(error -> null);
        } catch (Exception ignored) {
            // bad URL: nothing to do
        }
    }

    private static String jsonEscape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int)c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    // ================================================================ misc

    private void say(String text) {
        KryzexClient.send((MacroModule)this, text);
    }
}
