package kryzex.modules.basefinding;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;

/**
 * Base Finding wrapper for one Corz finder (Chunk Finder, Chunk Finder V2, Deep Player Finder).
 *
 * The Corz modules live in the embedded Yarn-mapped library (:corz, jar-in-jar), exactly like the Auto Builder engine.
 * Kryzex itself is written against intermediary names, so it talks to them only through
 * com.corz.client.bridge.CorzFinderApi, whose signatures use JDK types only (reflection, same as KingBridgeModule).
 *
 * Kryzex settings are mirrored from the Corz module's settings (bool/int/double/enum/string/color) and pushed back
 * into it on enable and every tick while enabled.
 */
public final class CorzBridgeModule
extends Module {
    private static final String API = "com.corz.client.bridge.CorzFinderApi";

    private static Method mIds, mTitle, mDescription, mInfo, mSetActive, mSettings, mApply;

    private final String id;
    private final transient List<Bound> bound = new ArrayList<Bound>();
    private transient boolean built;

    private static final class Bound {
        final String key;
        final String type;
        final Setting setting;

        Bound(String key, String type, Setting setting) {
            this.key = key;
            this.type = type;
            this.setting = setting;
        }

        Object value() {
            switch (this.type) {
                case "bool": return ((BoolSetting) this.setting).getValue();
                case "int": return ((NumberSetting) this.setting).getIntValue();
                case "double": return ((NumberSetting) this.setting).getValue();
                case "enum": return ((ModeSetting) this.setting).getMode();
                case "string": return ((StringSetting) this.setting).getValue();
                case "color": return ((ColorSetting) this.setting).getArgb();
                default: return null;
            }
        }
    }

    // ---- reflection plumbing ---------------------------------------------------------------------------------

    private static synchronized void bind() throws Exception {
        if (mIds != null) return;
        Class<?> api = Class.forName(API);
        mTitle = api.getMethod("title", String.class);
        mDescription = api.getMethod("description", String.class);
        mInfo = api.getMethod("info", String.class);
        mSetActive = api.getMethod("setActive", String.class, boolean.class);
        mSettings = api.getMethod("settings", String.class);
        mApply = api.getMethod("apply", String.class, String.class, Object.class);
        mIds = api.getMethod("ids");
    }

    @SuppressWarnings("unchecked")
    public static List<String> ids() throws Exception {
        bind();
        return (List<String>) mIds.invoke(null);
    }

    private static String title(String id) {
        try {
            bind();
            return (String) mTitle.invoke(null, id);
        } catch (Throwable t) {
            return id;
        }
    }

    private static String describe(String id) {
        try {
            bind();
            return (String) mDescription.invoke(null, id);
        } catch (Throwable t) {
            return "";
        }
    }

    // ---- module ---------------------------------------------------------------------------------------------

    public CorzBridgeModule(String id) {
        super(CorzBridgeModule.title(id), CorzBridgeModule.describe(id), -1, Category.BASE_FINDING);
        this.id = id;
        // Settings are built lazily: the :corz registry is only populated by Corz's own client entrypoint, which runs
        // AFTER Kryzex builds its module list (same reason AutoBuilderBridge mirrors lazily).
    }

    @Override
    public List<Setting> getSettings() {
        this.ensureBuilt();
        return super.getSettings();
    }

    private void ensureBuilt() {
        if (this.built) return;
        this.buildSettings();
    }

    @SuppressWarnings("unchecked")
    private void buildSettings() {
        try {
            bind();
            List<Object[]> descs = (List<Object[]>) mSettings.invoke(null, this.id);
            if (descs == null || descs.isEmpty()) return; // Corz registry not ready yet -> retry on next call
            this.built = true;
            for (Object[] d : descs) {
                String key = (String) d[0];
                String type = (String) d[1];
                String name = (String) d[2];
                String desc = d[3] == null ? "" : (String) d[3];
                Setting setting;
                switch (type) {
                    case "bool":
                        setting = new BoolSetting(name, (Boolean) d[6]).setDescription(desc);
                        break;
                    case "int": {
                        double min = ((Number) d[4]).doubleValue(), max = ((Number) d[5]).doubleValue();
                        double cur = Math.max(min, Math.min(max, ((Number) d[6]).doubleValue()));
                        setting = new NumberSetting(name, min, max, cur, 1.0).setDescription(desc);
                        break;
                    }
                    case "double": {
                        double min = ((Number) d[4]).doubleValue(), max = ((Number) d[5]).doubleValue();
                        double cur = Math.max(min, Math.min(max, ((Number) d[6]).doubleValue()));
                        double range = max - min;
                        double step = range <= 10.0 ? 0.01 : (range <= 100.0 ? 0.1 : 1.0);
                        setting = new NumberSetting(name, min, max, cur, step).setDescription(desc);
                        break;
                    }
                    case "enum":
                        setting = new ModeSetting(name, (String) d[6], (List<String>) d[7]).setDescription(desc);
                        break;
                    case "string":
                        setting = new StringSetting(name, (String) d[6]).setDescription(desc);
                        break;
                    case "color":
                        setting = new ColorSetting(name, ((Number) d[6]).intValue()).setDescription(desc);
                        break;
                    default:
                        continue;
                }
                this.bound.add(new Bound(key, type, setting));
                this.addSetting(setting);
            }
        } catch (Throwable t) {
            System.err.println("Kryzex: Corz settings for " + this.id + " unavailable: " + t);
        }
    }

    private void push() {
        try {
            for (Bound b : this.bound) mApply.invoke(null, this.id, b.key, b.value());
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onEnable() {
        try {
            bind();
            this.ensureBuilt();
            this.push();
            mSetActive.invoke(null, this.id, true);
        } catch (Throwable t) {
            System.err.println("Kryzex: failed to enable Corz module " + this.id + ": " + t);
        }
    }

    @Override
    public void onDisable() {
        try {
            bind();
            mSetActive.invoke(null, this.id, false);
        } catch (Throwable ignored) {
        }
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.isEnabled() && this.built) this.push();
    }

    /** Short status text (e.g. counts) provided by the Corz module, or null. */
    public String info() {
        try {
            bind();
            return (String) mInfo.invoke(null, this.id);
        } catch (Throwable t) {
            return null;
        }
    }
}
