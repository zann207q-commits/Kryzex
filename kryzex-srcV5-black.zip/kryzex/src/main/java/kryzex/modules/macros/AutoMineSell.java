package kryzex.modules.macros;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroActionSetting;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroItemSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.macros.h.Sell;
import kryzex.modules.misc.MacroModule;
import kryzex.util.KryzexClient;
import kryzex.util.SecureString;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_1735;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Auto Mine Sell (ported from the Corz client).
 *
 * Mines every Target Block inside the area between two corners (or around you), and when the inventory is full it
 * pauses, sells the Sell Items through /order (best price first, /sell as a fallback), then goes back to mining.
 */
@Environment(value=EnvType.CLIENT)
public final class AutoMineSell
extends MacroModule {
    private enum SellState { IDLE, WAIT_LIST, WAIT_PAGE, WAIT_DEPOSIT, CONFIRM, FINISH, NEXT }

    private static final Pattern PRICE_PATTERN = Pattern.compile("([0-9][0-9,]*(?:\\.[0-9]+)?)([kKmMbBtT]?)(?![A-Za-z])");
    private static final HttpClient WEBHOOK_CLIENT = HttpClient.newHttpClient();
    private static final long TARGET_SCAN_LIMIT = 8_000_000L;

    // ---------------------------------------------------------------- Mining settings
    private final MacroBoolSetting mineWithoutArea = this.addSetting("mine-without-area", new MacroBoolSetting("Mine Without Area", false));
    private final MacroNumberSetting scanRange = this.addSetting("scan-range", new MacroNumberSetting("Scan Range", 32.0f, 8.0f, 96.0f).step(1.0f));
    private final MacroItemSetting targetBlocks = this.addSetting("target-blocks", new MacroItemSetting("Target Blocks", new String[0]).itemPicker());
    private final MacroNumberSetting reach = this.addSetting("reach", new MacroNumberSetting("Reach", 4.5f, 3.0f, 5.0f).step(0.1f));
    private final MacroNumberSetting toolSlot = this.addSetting("tool-slot", new MacroNumberSetting("Tool Hotbar Slot (0 = off)", 0.0f, 0.0f, 9.0f).step(1.0f));
    private final MacroNumberSetting aimSpeed = this.addSetting("aim-speed", new MacroNumberSetting("Aim Speed", 14.0f, 3.0f, 40.0f).step(1.0f));
    private final MacroBoolSetting nuker = this.addSetting("nuker", new MacroBoolSetting("Nuker (Meteor-style)", true));
    private final MacroNumberSetting nukerBlocksPerTick = this.addSetting("nuker-blocks-per-tick", new MacroNumberSetting("Nuker Blocks Per Tick", 6.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroNumberSetting nukerRange = this.addSetting("nuker-range", new MacroNumberSetting("Nuker Range", 4.5f, 1.0f, 6.0f).step(0.1f));
    private final MacroBoolSetting nukerOnlyExposed = this.addSetting("nuker-only-exposed", new MacroBoolSetting("Nuker Only Exposed", true));
    private final MacroBoolSetting nukerRotate = this.addSetting("nuker-rotate", new MacroBoolSetting("Nuker Rotate", false));
    private final MacroBoolSetting autoLoot = this.addSetting("auto-loot", new MacroBoolSetting("Auto Loot", true));
    private final MacroNumberSetting lootRange = this.addSetting("loot-range", new MacroNumberSetting("Loot Range", 10.0f, 3.0f, 32.0f).step(1.0f));
    private final MacroActionSetting corner1Feet = this.addSetting("corner1-feet", new MacroActionSetting("Corner 1 -> Feet", () -> this.setCornerFromPlayer(1, false)));
    private final MacroActionSetting corner1Looking = this.addSetting("corner1-looking", new MacroActionSetting("Corner 1 -> Looking", () -> this.setCornerFromPlayer(1, true)));
    private final MacroActionSetting corner2Feet = this.addSetting("corner2-feet", new MacroActionSetting("Corner 2 -> Feet", () -> this.setCornerFromPlayer(2, false)));
    private final MacroActionSetting corner2Looking = this.addSetting("corner2-looking", new MacroActionSetting("Corner 2 -> Looking", () -> this.setCornerFromPlayer(2, true)));

    // ---------------------------------------------------------------- Auto Sell settings
    private final MacroBoolSetting autoSell = this.addSetting("auto-sell", new MacroBoolSetting("Auto Sell", true));
    private final MacroItemSetting sellItems = this.addSetting("sell-items", new MacroItemSetting("Sell Items", new String[0]).itemPicker());
    private final StringSetting orderCommand = new StringSetting(SecureString.of("Order Command"), "order");
    private final MacroBoolSetting underscoreToSpace = this.addSetting("underscore-to-space", new MacroBoolSetting("Underscore To Space", true));
    private final MacroNumberSetting freeSlotsToSell = this.addSetting("free-slots-to-sell", new MacroNumberSetting("Free Slots To Sell", 0.0f, 0.0f, 10.0f).step(1.0f));
    private final MacroNumberSetting confirmSlot = this.addSetting("confirm-slot", new MacroNumberSetting("Confirm Slot", 53.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting sellDelay = this.addSetting("sell-delay", new MacroNumberSetting("Sell Delay", 350.0f, 100.0f, 3000.0f).step(10.0f));
    private final MacroNumberSetting sellTimeout = this.addSetting("sell-timeout", new MacroNumberSetting("Sell Menu Timeout", 8000.0f, 2000.0f, 30000.0f).step(100.0f));
    private final MacroBoolSetting bestPrice = this.addSetting("best-price", new MacroBoolSetting("Best Price", true));
    private final StringSetting priceKeyword = new StringSetting(SecureString.of("Price Line Contains"), "$");
    private final MacroNumberSetting minPrice = this.addSetting("min-price", new MacroNumberSetting("Min Price", 0.0f, 0.0f, 100000.0f).step(0.5f));
    private final MacroNumberSetting nextPageSlot = this.addSetting("next-page-slot", new MacroNumberSetting("Next Page Slot", -1.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroNumberSetting maxPages = this.addSetting("max-pages", new MacroNumberSetting("Max Pages", 5.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroBoolSetting fallbackSell = this.addSetting("fallback-sell", new MacroBoolSetting("Fallback To Sell", true));
    private final MacroNumberSetting fallbackAfter = this.addSetting("fallback-after", new MacroNumberSetting("Fallback After", 10.0f, 1.0f, 30.0f).step(1.0f));
    private final StringSetting fallbackCommand = new StringSetting(SecureString.of("Sell Command"), "sell");
    private final MacroNumberSetting fallbackConfirmSlot = this.addSetting("fallback-confirm-slot", new MacroNumberSetting("Sell Confirm Slot", 53.0f, -1.0f, 53.0f).step(1.0f));
    private final MacroBoolSetting randomDelay = this.addSetting("random-delay", new MacroBoolSetting("Random Delay", true));
    private final MacroNumberSetting delayJitter = this.addSetting("delay-jitter", new MacroNumberSetting("Delay Jitter %", 40.0f, 0.0f, 200.0f).step(5.0f));

    // ---------------------------------------------------------------- Safety / webhook settings
    private final MacroBoolSetting disconnectOnTotem = this.addSetting("leave-on-totem", new MacroBoolSetting("Leave On Totem Pop", true));
    private final MacroBoolSetting disconnectOnPlayer = this.addSetting("leave-on-player", new MacroBoolSetting("Leave On Player Nearby", true));
    private final MacroNumberSetting playerRange = this.addSetting("player-range", new MacroNumberSetting("Player Range", 48.0f, 8.0f, 128.0f).step(1.0f));
    private final StringSetting ignoredPlayers = new StringSetting(SecureString.of("Ignored Players"), "");
    private final StringSetting webhookUrl = new StringSetting(SecureString.of("Webhook URL"), "");
    private final StringSetting webhookPing = new StringSetting(SecureString.of("Webhook Ping"), "");
    private final MacroActionSetting testWebhook = this.addSetting("test-webhook", new MacroActionSetting("Test Webhook", () -> this.sendWebhookTest()));

    // ---------------------------------------------------------------- Area / miner state
    private class_2338 corner1;
    private class_2338 corner2;
    private int minX, minY, minZ, maxX, maxY, maxZ;
    private boolean areaDefined;
    private class_2338 target;
    private int targetTicks;
    private int aimTicks;
    private int noTargetTicks;
    private int lastScanAge = -1000;
    private int lastMineAge = -1;
    private class_243 stuckCheckPos;
    private int stuckTicks;
    private final Map<class_2338, Integer> skipped = new HashMap<>();
    private int targetTotal;
    private boolean wasMining;
    private int finalSellTries;
    private final Random random = new Random();
    private int blockedTicks;
    private int repositionTicks;
    private int repositions;
    private final Map<Integer, Integer> lootSkipped = new HashMap<>();
    private int lootTargetId = -1;
    private int lootTicks;
    private class_2338 nukerSlow;

    // ---------------------------------------------------------------- Sell state
    private SellState sellState = SellState.IDLE;
    private long sellNextActionAt;
    private long sellDeadline;
    private long sellRetryAt;
    private long sellListSeenAt;
    private int sellListSyncId = -1;
    private String sellListFingerprint = "";
    private String sellSearchTerm = "";
    private class_1792 sellTargetItem;
    private int sellPagesScanned;
    private int sellSessionStartCount;
    private int sellFailCount;
    private int sellConfirmClicks;
    private int sellConfirmSyncId = -1;
    private long sellConfirmClickedAt;
    private long sellConfirmDeadline;
    private boolean sellFallbackMode;
    private int soldTotal;
    private int soldByFallback;
    private int ordersFilled;
    private boolean sellWarnedNoItems;
    private boolean safetyTriggered;
    private int lastTotemCount = -1;

    public AutoMineSell() {
        super("auto-mine-sell", "Auto Mine Sell", "Mines the Target Blocks in your area and sells them through /order when the inventory is full.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
        this.addSetting((kryzex.module.settings.Setting) this.orderCommand);
        this.addSetting((kryzex.module.settings.Setting) this.priceKeyword);
        this.addSetting((kryzex.module.settings.Setting) this.fallbackCommand);
        this.addSetting((kryzex.module.settings.Setting) this.ignoredPlayers);
        this.addSetting((kryzex.module.settings.Setting) this.webhookUrl);
        this.addSetting((kryzex.module.settings.Setting) this.webhookPing);
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    // ================================================================ lifecycle

    @Override
    public void onEnable() {
        this.updateAreaFromCorners();
        if (!this.mineWithoutArea.get() && !this.areaDefined) {
            this.say("Set both corners first (or turn on Mine Without Area).");
            this.requestDisable();
            return;
        }
        if (this.mineWithoutArea.get() && this.targetBlocks.get().isEmpty()) {
            this.say("Pick some Target Blocks before using Mine Without Area.");
            this.requestDisable();
            return;
        }
        this.target = null;
        this.skipped.clear();
        this.targetTotal = 0;
        this.noTargetTicks = 0;
        this.lastScanAge = -1000;
        this.wasMining = false;
        this.finalSellTries = 0;
        this.blockedTicks = 0;
        this.repositionTicks = 0;
        this.repositions = 0;
        this.lootSkipped.clear();
        this.lootTargetId = -1;
        this.lootTicks = 0;
        this.nukerSlow = null;
        this.resetAutoSell(false);
        this.soldTotal = 0;
        this.soldByFallback = 0;
        this.ordersFilled = 0;
        this.sellRetryAt = 0L;
        this.safetyTriggered = false;
        this.lastTotemCount = -1;
    }

    @Override
    public void onDisable() {
        this.resetAutoSell(true);
        if (this.soldTotal > 0) {
            this.say("Auto Sell: sold " + this.soldTotal + " items (orders: " + this.ordersFilled + ", /sell: " + this.soldByFallback + ").");
        }
        this.releaseKeys();
        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
        this.target = null;
    }

    @MacroSubscribe
    public void onMacroTick(MacroTickEvent macroTickEvent) {
        class_310 mc = this.mc;
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.method_1562() == null) {
            return;
        }
        if (this.tickSafety()) {
            return;
        }
        if (this.tickAutoSell()) {
            return;
        }
        if (mc.field_1755 != null) {
            this.releaseKeys();
            return;
        }
        this.tickMiner();
    }

    // ================================================================ area

    private void setCornerFromPlayer(int which, boolean looking) {
        class_310 mc = this.mc;
        if (mc.field_1724 == null) {
            return;
        }
        class_2338 pos = mc.field_1724.method_24515().method_10074();
        if (looking) {
            if (!(mc.field_1765 instanceof class_3965) || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
                this.say("Look at a block first.");
                return;
            }
            pos = ((class_3965)mc.field_1765).method_17777();
        }
        if (which == 1) {
            this.corner1 = pos;
        } else {
            this.corner2 = pos;
        }
        this.updateAreaFromCorners();
        if (this.areaDefined) {
            this.say("Area set: " + this.getAreaBlockCount() + " blocks.");
        } else {
            this.say("Corner " + which + " set.");
        }
    }

    private void updateAreaFromCorners() {
        this.areaDefined = this.corner1 != null && this.corner2 != null;
        if (!this.areaDefined) {
            return;
        }
        this.minX = Math.min(this.corner1.method_10263(), this.corner2.method_10263());
        this.minY = Math.min(this.corner1.method_10264(), this.corner2.method_10264());
        this.minZ = Math.min(this.corner1.method_10260(), this.corner2.method_10260());
        this.maxX = Math.max(this.corner1.method_10263(), this.corner2.method_10263());
        this.maxY = Math.max(this.corner1.method_10264(), this.corner2.method_10264());
        this.maxZ = Math.max(this.corner1.method_10260(), this.corner2.method_10260());
    }

    private long getAreaBlockCount() {
        if (!this.areaDefined) {
            return 0L;
        }
        return (long)(this.maxX - this.minX + 1) * (long)(this.maxY - this.minY + 1) * (long)(this.maxZ - this.minZ + 1);
    }

    private boolean useArea() {
        return this.areaDefined && !this.mineWithoutArea.get();
    }

    // ================================================================ miner

    private static String blockKey(class_2248 block) {
        String id = class_7923.field_41175.method_10221(block).toString().toLowerCase(Locale.ROOT);
        return id;
    }

    private boolean matchesTarget(class_2248 block) {
        String id = blockKey(block);
        if (id.equals("minecraft:air") || id.equals("minecraft:cave_air") || id.equals("minecraft:void_air") || id.equals("minecraft:bedrock")) {
            return false;
        }
        List<String> wanted = this.targetBlocks.get();
        if (wanted.isEmpty()) {
            return true; // empty = mine everything inside the area
        }
        String shortId = id.substring(id.indexOf(58) + 1);
        for (String entry : wanted) {
            String e = entry.trim().toLowerCase(Locale.ROOT);
            if (e.isEmpty()) {
                continue;
            }
            if (id.equals(e) || shortId.equals(e)) {
                return true;
            }
            if (e.indexOf(58) < 0 && shortId.contains(e)) {
                return true;
            }
        }
        return false;
    }

    private boolean isInside(int x, int y, int z) {
        if (!this.useArea()) {
            class_2338 p = this.mc.field_1724.method_24515();
            int r = this.scanRange.getInt();
            return Math.abs(x - p.method_10263()) <= r && Math.abs(y - p.method_10264()) <= r && Math.abs(z - p.method_10260()) <= r;
        }
        return x >= this.minX && x <= this.maxX && y >= this.minY && y <= this.maxY && z >= this.minZ && z <= this.maxZ;
    }

    private boolean isValidTarget(class_2338 pos) {
        if (pos == null || !this.isInside(pos.method_10263(), pos.method_10264(), pos.method_10260())) {
            return false;
        }
        return this.matchesTarget(this.mc.field_1687.method_8320(pos).method_26204());
    }

    private boolean isExposed(class_2338 pos) {
        class_2350[] sides = class_2350.values();
        for (class_2350 side : sides) {
            if (this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                return true;
            }
        }
        return false;
    }

    /** Nearest valid, exposed, not-skipped block. Scans a limited radius around the player to stay cheap. */
    private class_2338 findTarget() {
        class_746 player = this.mc.field_1724;
        class_243 eye = player.method_33571();
        class_2338 base = player.method_24515();
        int age = player.field_6012;
        this.skipped.values().removeIf(until -> until < age);

        int radius = this.useArea() ? 20 : this.scanRange.getInt();
        radius = Math.min(radius, 16);
        class_2338 best = null;
        double bestScore = Double.MAX_VALUE;
        long scanned = 0L;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (++scanned > TARGET_SCAN_LIMIT) {
                        break;
                    }
                    int x = base.method_10263() + dx;
                    int y = base.method_10264() + dy;
                    int z = base.method_10260() + dz;
                    if (!this.isInside(x, y, z)) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    if (!this.matchesTarget(this.mc.field_1687.method_8320(pos).method_26204())) {
                        continue;
                    }
                    if (this.skipped.containsKey(pos) || !this.isExposed(pos)) {
                        continue;
                    }
                    double dist = eye.method_1025(class_243.method_24953(pos));
                    // nearest first, higher blocks slightly preferred so layers are cleared top-down
                    double score = dist - y * 0.05;
                    if (!this.facesEye(pos, eye)) {
                        score += 100.0; // no open face towards us: only pick it when nothing visible is left
                    }
                    if (score < bestScore) {
                        bestScore = score;
                        best = pos;
                    }
                }
            }
        }
        return best;
    }

    private void tickMiner() {
        class_746 player = this.mc.field_1724;
        if (player.method_29504()) {
            this.releaseKeys();
            return;
        }

        if (this.tickLoot()) {
            return;
        }

        if (this.nuker.get() && this.tickNuker()) {
            this.noTargetTicks = 0;
            this.wasMining = true;
            return;
        }

        if (this.target == null || !this.isValidTarget(this.target)) {
            if (this.target != null) {
                this.targetTotal++;
            }
            this.target = this.findTarget();
            this.targetTicks = 0;
            this.aimTicks = 0;
            this.blockedTicks = 0;
            this.repositionTicks = 0;
            this.repositions = 0;
            this.stuckCheckPos = null;
            this.stuckTicks = 0;
            if (this.target == null) {
                this.releaseKeys();
                if (this.mc.field_1761 != null) {
                    this.mc.field_1761.method_2925();
                }
                if (++this.noTargetTicks >= 60) {
                    this.finishedMining();
                }
                return;
            }
        }
        this.noTargetTicks = 0;
        this.wasMining = true;

        int slot = this.toolSlot.getInt();
        if (slot >= 1 && slot <= 9) {
            player.method_31548().method_61496(slot - 1);
        }

        if (++this.targetTicks > 600) {
            this.skipped.put(this.target, player.field_6012 + 600);
            this.target = null;
            return;
        }

        class_243 center = class_243.method_24953(this.target);
        double reachSq = (double)this.reach.get() * (double)this.reach.get();
        class_243 eye = player.method_33571();
        boolean inReach = eye.method_1025(center) <= reachSq;

        // the block cannot be hit from here: walk to a better spot for a moment
        if (this.repositionTicks > 0) {
            this.repositionTicks--;
            this.mc.field_1761.method_2925();
            class_243 goal = this.approachPoint(this.target, eye);
            if (!this.walkTo(goal != null ? goal : center)) {
                this.skipped.put(this.target, player.field_6012 + 800);
                this.target = null;
                this.repositionTicks = 0;
            }
            if (this.repositionTicks == 0) {
                this.releaseMovement();
            }
            return;
        }

        if (inReach) {
            this.releaseMovement();
            boolean aimed = this.aimAt(center);
            class_3965 hit = this.mc.field_1765 instanceof class_3965 ? (class_3965)this.mc.field_1765 : null;
            if (hit != null && hit.method_17783() == class_239.class_240.field_1332) {
                class_2338 hitPos = hit.method_17777();
                if (hitPos.equals(this.target)) {
                    this.blockedTicks = 0;
                    this.mineBlock(this.target, hit.method_17780());
                    return;
                }
                if (this.isValidTarget(hitPos)) {
                    // another target block is in the way: mine it first
                    this.blockedTicks = 0;
                    this.mineBlock(hitPos, hit.method_17780());
                    return;
                }
            }
            if (aimed && ++this.blockedTicks > 15) {
                this.blockedTicks = 0;
                if (++this.repositions > 4) {
                    this.skipped.put(this.target, player.field_6012 + 400);
                    this.target = null;
                    this.repositions = 0;
                    this.releaseKeys();
                    return;
                }
                this.repositionTicks = 25;
                this.stuckCheckPos = null;
            }
            return;
        }

        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
        if (!this.walkTo(center)) {
            this.skipped.put(this.target, player.field_6012 + 800);
            this.target = null;
        }
    }

    // ================================================================ Nuker

    /**
     * Meteor-style nuker: breaks every Target Block within range without walking or aiming at each one.
     * Instant-break blocks are broken several per tick; slower blocks are mined one at a time (the server only
     * tracks one block in progress). Returns true when it did something this tick (the normal miner then waits).
     */
    private boolean tickNuker() {
        class_746 player = this.mc.field_1724;

        int hotbar = this.toolSlot.getInt();
        if (hotbar >= 1 && hotbar <= 9) {
            player.method_31548().method_61496(hotbar - 1);
        }

        class_243 eye = player.method_33571();
        double range = this.nukerRange.get();
        double rangeSq = range * range;
        int r = (int)Math.ceil(range);
        class_2338 base = player.method_24515();
        boolean onlyExposed = this.nukerOnlyExposed.get();

        List<class_2338> candidates = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    int x = base.method_10263() + dx;
                    int y = base.method_10264() + dy;
                    int z = base.method_10260() + dz;
                    if (!this.isInside(x, y, z)) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    if (eye.method_1025(class_243.method_24953(pos)) > rangeSq) {
                        continue;
                    }
                    if (!this.matchesTarget(this.mc.field_1687.method_8320(pos).method_26204())) {
                        continue;
                    }
                    if (onlyExposed && !this.isExposed(pos)) {
                        continue;
                    }
                    candidates.add(pos);
                }
            }
        }

        if (candidates.isEmpty()) {
            this.nukerSlow = null;
            return false;
        }

        // nearest first, higher blocks slightly preferred
        candidates.sort((a, b) -> Double.compare(
            eye.method_1025(class_243.method_24953(a)) - a.method_10264() * 0.05,
            eye.method_1025(class_243.method_24953(b)) - b.method_10264() * 0.05));

        List<class_2338> instant = new ArrayList<>();
        class_2338 slow = null;
        for (class_2338 pos : candidates) {
            float delta = this.mc.field_1687.method_8320(pos).method_26165((class_1657)player, this.mc.field_1687, pos);
            if (delta >= 1.0f) {
                instant.add(pos);
            } else if (slow == null) {
                slow = pos;
            }
            if (this.nukerSlow != null && this.nukerSlow.equals(pos) && delta < 1.0f) {
                slow = pos; // keep mining the block that is already in progress
            }
        }

        class_2338 aim = null;
        boolean did = false;
        if (!instant.isEmpty()) {
            this.mc.field_1761.method_2925();
            this.nukerSlow = null;
            int max = this.nukerBlocksPerTick.getInt();
            int done = 0;
            for (class_2338 pos : instant) {
                if (done >= max) {
                    break;
                }
                this.mc.field_1761.method_2910(pos, this.nukerFace(pos, eye));
                if (aim == null) {
                    aim = pos;
                }
                done++;
            }
            this.targetTotal += done;
            did = done > 0;
        } else if (slow != null) {
            if (this.nukerSlow != null && !this.nukerSlow.equals(slow)) {
                this.targetTotal++;
            }
            this.nukerSlow = slow;
            this.mc.field_1761.method_2902(slow, this.nukerFace(slow, eye));
            aim = slow;
            did = true;
        }

        if (did) {
            if (this.nukerRotate.get() && aim != null) {
                this.aimAt(class_243.method_24953(aim));
            }
            player.method_6104(class_1268.field_5808);
        }
        return did;
    }

    /** Side of the block facing the player (prefers an open/air side). */
    private class_2350 nukerFace(class_2338 pos, class_243 eye) {
        class_2350 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 side : class_2350.values()) {
            if (!this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                continue;
            }
            double fx = pos.method_10263() + 0.5 + side.method_10148() * 0.5;
            double fy = pos.method_10264() + 0.5 + side.method_10164() * 0.5;
            double fz = pos.method_10260() + 0.5 + side.method_10165() * 0.5;
            double d = eye.method_1025(new class_243(fx, fy, fz));
            if (d < bestDist) {
                bestDist = d;
                best = side;
            }
        }
        return best != null ? best : class_2350.values()[1];
    }

    /** True when the block has an open (air) side that the player's eye is on the outside of. */
    private boolean facesEye(class_2338 pos, class_243 eye) {
        for (class_2350 side : class_2350.values()) {
            if (!this.mc.field_1687.method_8320(pos.method_10093(side)).method_26215()) {
                continue;
            }
            int ox = side.method_10148();
            int oy = side.method_10164();
            int oz = side.method_10165();
            if (ox > 0 && eye.field_1352 > pos.method_10263() + 1) return true;
            if (ox < 0 && eye.field_1352 < pos.method_10263()) return true;
            if (oy > 0 && eye.field_1351 > pos.method_10264() + 1) return true;
            if (oy < 0 && eye.field_1351 < pos.method_10264()) return true;
            if (oz > 0 && eye.field_1350 > pos.method_10260() + 1) return true;
            if (oz < 0 && eye.field_1350 < pos.method_10260()) return true;
        }
        return false;
    }

    /** Centre of the open (air) block next to the target that is closest to the player. */
    private class_243 approachPoint(class_2338 pos, class_243 eye) {
        class_243 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 side : class_2350.values()) {
            class_2338 neighbour = pos.method_10093(side);
            if (!this.mc.field_1687.method_8320(neighbour).method_26215()) {
                continue;
            }
            class_243 c = class_243.method_24953(neighbour);
            double d = eye.method_1025(c);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    // ================================================================ Auto Loot

    /** Walks to the nearest wanted dropped item. Returns true while it is busy looting (the miner waits). */
    private boolean tickLoot() {
        if (!this.autoLoot.get()) {
            this.lootTargetId = -1;
            return false;
        }
        class_746 player = this.mc.field_1724;
        class_1542 item = this.findLoot();
        if (item == null) {
            if (this.lootTargetId != -1) {
                this.lootTargetId = -1;
                this.lootTicks = 0;
                this.stuckCheckPos = null;
                this.releaseMovement();
            }
            return false;
        }

        int id = item.method_5628();
        if (id != this.lootTargetId) {
            this.lootTargetId = id;
            this.lootTicks = 0;
            this.stuckCheckPos = null;
            this.stuckTicks = 0;
        }
        this.mc.field_1761.method_2925();

        class_243 point = new class_243(item.method_23317(), item.method_23318(), item.method_23321());
        boolean moving = this.walkTo(point);
        if (!moving || ++this.lootTicks > 160) {
            // cannot reach it (or it is not being picked up): ignore this item for a minute
            this.lootSkipped.put(id, player.field_6012 + 1200);
            this.lootTargetId = -1;
            this.lootTicks = 0;
            this.stuckCheckPos = null;
            this.releaseMovement();
            return false;
        }
        return true;
    }

    private class_1542 findLoot() {
        class_746 player = this.mc.field_1724;
        int age = player.field_6012;
        this.lootSkipped.values().removeIf(until -> until < age);
        double range = this.lootRange.get();
        double rangeSq = range * range;
        class_1542 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1542 item) || item.method_31481()) {
                continue;
            }
            if (item.field_6012 < 10 || this.lootSkipped.containsKey(item.method_5628())) {
                continue; // still popping out of the block, or given up on
            }
            double d = player.method_5858(item);
            if (d > rangeSq || d >= bestDist) {
                continue;
            }
            class_1799 stack = item.method_6983();
            if (!this.isLootWanted(stack) || !this.hasRoomFor(stack)) {
                continue;
            }
            best = item;
            bestDist = d;
        }
        return best;
    }

    /** Dropped items that match Sell Items / Target Blocks (everything when both are empty). */
    private boolean isLootWanted(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        List<String> targets = this.targetBlocks.get();
        if (targets.isEmpty() && this.sellItems.get().isEmpty()) {
            return true;
        }
        if (this.isSellable(stack)) {
            return true;
        }
        return !targets.isEmpty() && this.matchesTarget(class_2248.method_9503(stack.method_7909()));
    }

    private boolean hasRoomFor(class_1799 stack) {
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 0; i <= 35; i++) {
            class_1799 slot = inventory.method_5438(i);
            if (slot.method_7960()) {
                return true;
            }
            if (slot.method_7909() == stack.method_7909() && slot.method_7947() < slot.method_7914()) {
                return true;
            }
        }
        return false;
    }

    private void finishedMining() {
        if (!this.wasMining) {
            this.say("No target blocks found" + (this.useArea() ? " in the area." : " around you."));
            this.requestDisable();
            return;
        }
        // inventory may still hold things to sell
        if (this.autoSell.get() && this.findSellableItem() != null && this.sellState == SellState.IDLE && this.finalSellTries++ < 3) {
            this.sellRetryAt = 0L;
            this.noTargetTicks = 0;
            this.startSellSessionNow();
            return;
        }
        String done = "Done mining! Cleared " + this.targetTotal + " blocks, sold " + this.soldTotal + " items.";
        this.say(done);
        this.sendWebhook("**[Auto Mine Sell]** " + done);
        this.requestDisable();
    }

    private void mineBlock(class_2338 pos, class_2350 side) {
        class_746 player = this.mc.field_1724;
        if (player.field_6012 == this.lastMineAge) {
            return;
        }
        this.lastMineAge = player.field_6012;
        if (this.mc.field_1761.method_2902(pos, side)) {
            player.method_6104(class_1268.field_5808);
        }
    }

    /** Turns the camera toward a point a little at a time. Returns true when it is (nearly) on target. */
    private boolean aimAt(class_243 point) {
        class_746 player = this.mc.field_1724;
        class_243 eye = player.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float wantPitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90.0f, 90.0f);
        float curYaw = player.method_36454();
        float curPitch = player.method_36455();
        float dYaw = class_3532.method_15393(wantYaw - curYaw);
        float dPitch = wantPitch - curPitch;
        float dist = (float)Math.sqrt(dYaw * dYaw + dPitch * dPitch);
        if (dist < 0.35f) {
            return true;
        }
        float maxStep = this.aimSpeed.get() * (0.75f + this.random.nextFloat() * 0.5f);
        float scale = dist > maxStep ? maxStep / dist : 1.0f;
        player.method_36456(curYaw + dYaw * scale);
        player.method_36457(class_3532.method_15363(curPitch + dPitch * scale, -90.0f, 90.0f));
        return dist < 3.0f;
    }

    /** Walks toward a point. Returns false when the player is stuck. */
    private boolean walkTo(class_243 point) {
        class_746 player = this.mc.field_1724;
        this.aimAt(new class_243(point.field_1352, player.method_33571().field_1351, point.field_1350));
        this.mc.field_1690.field_1894.method_23481(true);
        this.mc.field_1690.field_1903.method_23481(player.field_5976 && player.method_24828());
        if (this.stuckCheckPos == null) {
            this.stuckCheckPos = player.method_73189();
            this.stuckTicks = 0;
            return true;
        }
        if (++this.stuckTicks < 60) {
            return true;
        }
        boolean moved = player.method_73189().method_1025(this.stuckCheckPos) > 0.09;
        this.stuckCheckPos = player.method_73189();
        this.stuckTicks = 0;
        if (!moved) {
            this.releaseMovement();
        }
        return moved;
    }

    private void releaseMovement() {
        if (this.mc.field_1690 == null) {
            return;
        }
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
    }

    private void releaseKeys() {
        if (this.mc.field_1690 == null) {
            return;
        }
        this.releaseMovement();
        this.mc.field_1690.field_1832.method_23481(false);
        this.mc.field_1690.field_1904.method_23481(false);
    }

    // ================================================================ Auto Sell

    /** Returns true when the sell routine used this tick (the miner stays paused). */
    private boolean tickAutoSell() {
        class_310 mc = this.mc;
        if (!this.autoSell.get()) {
            return false;
        }

        long now = System.currentTimeMillis();

        if (this.sellState == SellState.IDLE) {
            if (now < this.sellRetryAt || mc.field_1755 != null || !this.isInventoryFullEnough()) {
                return false;
            }
            if (this.findSellableItem() == null) {
                if (!this.sellWarnedNoItems) {
                    this.say("Inventory full but there is nothing to sell, mining continues.");
                    this.sellWarnedNoItems = true;
                }
                this.sellRetryAt = now + 5000L;
                return false;
            }
            this.sellWarnedNoItems = false;
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.releaseKeys();
            mc.field_1761.method_2925();
            this.startSellSession(now);
        }

        this.releaseKeys();
        if (now < this.sellNextActionAt) {
            return true;
        }

        switch (this.sellState) {
            case WAIT_LIST -> this.sellTickWaitList(now);
            case WAIT_PAGE -> this.sellTickWaitPage(now);
            case WAIT_DEPOSIT -> this.sellTickWaitDeposit(now);
            case CONFIRM -> this.sellTickConfirm(now);
            case FINISH -> this.sellTickFinish(now);
            case NEXT -> this.startSellSession(now);
            default -> this.startSellSession(now);
        }
        return true;
    }

    private void startSellSessionNow() {
        this.releaseKeys();
        this.sellFailCount = 0;
        this.sellFallbackMode = false;
        this.startSellSession(System.currentTimeMillis());
    }

    /** Picks an item from the inventory and opens the order list (or the /sell menu in fallback mode). */
    private void startSellSession(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
            this.sellNextActionAt = now + this.nextSellDelay();
            this.sellState = SellState.NEXT;
            return;
        }

        class_1792 item = this.findSellableItem();
        if (item == null) {
            this.sellState = SellState.IDLE;
            this.sellRetryAt = now + 1000L;
            return;
        }

        this.sellTargetItem = item;
        this.sellPagesScanned = 0;
        this.sellListSeenAt = 0L;
        this.sellListSyncId = -1;
        this.sellSessionStartCount = this.countSellableItems();

        if (this.sellFallbackMode) {
            player.field_3944.method_45730(this.fallbackCommand.getValue().trim());
            this.sellState = SellState.WAIT_DEPOSIT;
        } else {
            String name = class_7923.field_41178.method_10221(item).method_12832();
            this.sellSearchTerm = this.underscoreToSpace.get() ? name.replace('_', ' ') : name;
            player.field_3944.method_45730(this.orderCommand.getValue().trim() + " " + this.sellSearchTerm);
            this.sellState = SellState.WAIT_LIST;
        }

        this.sellDeadline = now + this.sellTimeout.getInt();
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** Waits for the order list, picks the best order, or flips to the next page. */
    private void sellTickWaitList(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        boolean listOpen = handler != player.field_7498 && this.mc.field_1755 instanceof class_465;

        if (listOpen && this.menuStackCount(handler) > 0) {
            if (this.sellListSeenAt == 0L) {
                this.sellListSeenAt = now;
                this.sellNextActionAt = now + this.nextSellDelay();
                return;
            }

            class_1735 best = this.pickBestOrder(handler);
            if (best != null) {
                this.sellListSyncId = handler.field_7763;
                this.mc.field_1761.method_2906(handler.field_7763, best.field_7874, 0, class_1713.field_7790, (class_1657)player);
                this.sellState = SellState.WAIT_DEPOSIT;
                this.sellDeadline = now + this.sellTimeout.getInt();
                this.sellNextActionAt = now + this.nextSellDelay();
                return;
            }

            if (this.sellPagesScanned + 1 < this.maxPages.getInt()) {
                class_1735 next = this.findNextPageSlot(handler);
                if (next != null) {
                    this.sellListFingerprint = this.menuFingerprint(handler);
                    this.sellListSyncId = handler.field_7763;
                    this.mc.field_1761.method_2906(handler.field_7763, next.field_7874, 0, class_1713.field_7790, (class_1657)player);
                    this.sellPagesScanned++;
                    this.sellState = SellState.WAIT_PAGE;
                    this.sellDeadline = now + Math.min(this.sellTimeout.getInt(), 2500);
                    this.sellNextActionAt = now + this.nextSellDelay();
                    return;
                }
            }

            this.onSellFail(now, "no usable order for " + this.sellSearchTerm);
            return;
        }

        if (now > this.sellDeadline) {
            this.onSellFail(now, "the order list did not open");
        }
    }

    /** After clicking "next page": wait until the list changed, then scan it again. */
    private void sellTickWaitPage(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        boolean listOpen = handler != player.field_7498 && this.mc.field_1755 instanceof class_465;

        if (listOpen && this.menuStackCount(handler) > 0
            && (handler.field_7763 != this.sellListSyncId || !this.menuFingerprint(handler).equals(this.sellListFingerprint))) {
            this.sellState = SellState.WAIT_LIST;
            this.sellListSeenAt = now;
            this.sellNextActionAt = now + this.nextSellDelay();
            return;
        }

        if (now > this.sellDeadline) {
            this.onSellFail(now, "no more pages for " + this.sellSearchTerm);
        }
    }

    /** In the deposit menu, shift-clicks the matching items from the inventory into it. */
    private void sellTickWaitDeposit(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;

        boolean isNewMenu = handler != player.field_7498
            && handler.field_7763 != this.sellListSyncId
            && this.mc.field_1755 instanceof class_465;

        if (!isNewMenu) {
            if (now > this.sellDeadline) {
                this.onSellFail(now, this.sellFallbackMode ? "the sell menu did not open" : "the order did not open");
            }
            return;
        }

        for (class_1735 slot : handler.field_7761) {
            if (!(slot.field_7871 instanceof class_1661) || !slot.method_7681()) {
                continue;
            }
            int index = slot.method_34266();
            if (index < 9 || index > 35) {
                continue; // hotbar (tools, food, blocks), armor and offhand are never sold
            }
            if (!this.isSellable(slot.method_7677())) {
                continue;
            }
            this.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)player);
        }

        this.sellState = SellState.CONFIRM;
        this.sellConfirmClicks = 0;
        this.sellConfirmSyncId = -1;
        this.sellConfirmClickedAt = 0L;
        this.sellConfirmDeadline = now + 5000L;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /**
     * Finds the green confirm button in the open menu and clicks it. The button is searched by item/name instead of
     * a fixed slot, it is retried until it shows up, and a second confirmation screen is handled too.
     */
    private void sellTickConfirm(long now) {
        class_746 player = this.mc.field_1724;
        class_1703 handler = player.field_7512;
        if (handler == player.field_7498) {
            this.sellState = SellState.FINISH; // menu already closed by the server
            return;
        }

        class_1735 button = this.findConfirmButton(handler);
        boolean sameMenu = handler.field_7763 == this.sellConfirmSyncId;

        if (button != null && this.sellConfirmClicks < 4 && (!sameMenu || now - this.sellConfirmClickedAt >= 1500L)) {
            this.clickConfirm(handler, button.field_7874, now);
            return;
        }

        if (this.sellConfirmClicks > 0) {
            // clicked at least once: wait for the server to close the menu / open the next one
            if (now > this.sellConfirmDeadline && (button == null || this.sellConfirmClicks >= 4)) {
                this.sellState = SellState.FINISH;
            }
            return;
        }

        if (now > this.sellConfirmDeadline) {
            // nothing recognised as a button: try the configured slot, but only if it is inside the menu part
            int slot = this.sellFallbackMode ? this.fallbackConfirmSlot.getInt() : this.confirmSlot.getInt();
            int menuSize = handler.field_7761.size() - 36;
            if (slot >= 0 && slot < menuSize && !handler.field_7761.get(slot).method_7677().method_7960()) {
                this.clickConfirm(handler, slot, now);
                return;
            }
            this.onSellFail(now, "the confirm button was not found");
        }
    }

    private void clickConfirm(class_1703 handler, int slotId, long now) {
        this.mc.field_1761.method_2906(handler.field_7763, slotId, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
        this.sellConfirmSyncId = handler.field_7763;
        this.sellConfirmClickedAt = now;
        this.sellConfirmClicks++;
        this.sellConfirmDeadline = now + 2000L;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    /** Green stained glass pane (lime or green) or a "confirm"-like name in the menu part (never the player inventory). */
    private class_1735 findConfirmButton(class_1703 handler) {
        int menuSize = Math.min(handler.field_7761.size() - 36, handler.field_7761.size());
        class_1735 best = null;
        int bestScore = 0;
        for (int i = 0; i < menuSize; i++) {
            class_1735 slot = handler.field_7761.get(i);
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7909() == this.sellTargetItem) {
                continue; // an item we just deposited
            }
            String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
            String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
            if (name.contains("cancel") || name.contains("decline") || name.contains("deny")) {
                continue;
            }
            boolean greenItem = path.equals("lime_stained_glass_pane") || path.equals("green_stained_glass_pane");
            boolean keyword = name.contains("confirm") || name.contains("accept") || name.contains("deliver")
                || name.contains("complete") || name.contains("submit") || name.contains("sell");
            int score = (greenItem ? 2 : 0) + (keyword ? 1 : 0);
            if (score > 0 && score >= bestScore) {
                bestScore = score;
                best = slot; // on ties the later (bottom-right) slot wins
            }
        }
        return best;
    }

    /** Closes the menu and checks what was really sold. */
    private void sellTickFinish(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }

        this.sellListSyncId = -1;
        this.sellNextActionAt = now + this.nextSellDelay();

        int left = this.countSellableItems();
        int delta = this.sellSessionStartCount - left;

        if (delta > 0) {
            this.soldTotal += delta;
            if (this.sellFallbackMode) {
                this.soldByFallback += delta;
            } else {
                this.ordersFilled++;
            }
        }

        if (left == 0) {
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.sellState = SellState.IDLE;
            this.sellRetryAt = now + 1000L;
            return;
        }

        if (delta > 0) {
            this.sellFailCount = 0;
            this.sellFallbackMode = false;
            this.sellState = SellState.NEXT;
            return;
        }

        this.onSellFail(now, "the items were not accepted");
    }

    /**
     * A failed attempt (no order, menu did not open, items refused). After "Fallback After" failures in a row
     * the /sell command is used instead; if that fails too, mining continues and selling is retried later.
     */
    private void onSellFail(long now, String reason) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellListSyncId = -1;
        this.sellListSeenAt = 0L;

        if (this.sellFallbackMode) {
            this.say("/sell failed (" + reason + "), mining continues.");
            this.sellFallbackMode = false;
            this.sellFailCount = 0;
            this.abortSellSession(now);
            return;
        }

        this.sellFailCount++;
        if (this.sellFailCount >= this.fallbackAfter.getInt()) {
            this.sellFailCount = 0;
            if (this.fallbackSell.get()) {
                this.say(reason + " (" + this.fallbackAfter.getInt() + " tries), switching to /" + this.fallbackCommand.getValue().trim() + ".");
                this.sellFallbackMode = true;
                this.sellState = SellState.NEXT;
                this.sellNextActionAt = now + this.nextSellDelay();
            } else {
                this.say(reason + ", mining continues.");
                this.abortSellSession(now);
            }
            return;
        }

        this.sellState = SellState.NEXT;
        this.sellNextActionAt = now + this.nextSellDelay();
    }

    private void abortSellSession(long now) {
        class_746 player = this.mc.field_1724;
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellListSyncId = -1;
        this.sellState = SellState.IDLE;
        this.sellRetryAt = now + 15000L; // keep mining, try again later
    }

    private void resetAutoSell(boolean closeMenu) {
        class_746 player = this.mc.field_1724;
        if (closeMenu && this.sellState != SellState.IDLE && player != null && player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        this.sellState = SellState.IDLE;
        this.sellListSyncId = -1;
        this.sellListSeenAt = 0L;
        this.sellNextActionAt = 0L;
        this.sellWarnedNoItems = false;
        this.sellFailCount = 0;
        this.sellFallbackMode = false;
    }

    /** Sell Delay, plus a random extra amount when Random Delay is on. */
    private long nextSellDelay() {
        long base = this.sellDelay.getInt();
        if (!this.randomDelay.get()) {
            return base;
        }
        long extra = (long)((double)base * (double)this.delayJitter.get() / 100.0);
        return base + ThreadLocalRandom.current().nextLong(extra + 1L);
    }

    // ---------------------------------------------------------------- order list helpers

    /** The order that wants our item with the highest price (or the first one when Best Price is off). */
    private class_1735 pickBestOrder(class_1703 handler) {
        class_1735 best = null;
        double bestValue = -2.0;
        double min = this.minPrice.get();

        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7909() != this.sellTargetItem) {
                continue;
            }

            double price = this.parsePrice(stack); // -1 when no price could be read
            if (min > 0.0 && price < min) {
                continue;
            }
            if (!this.bestPrice.get()) {
                return slot;
            }
            if (price > bestValue) {
                bestValue = price;
                best = slot;
            }
        }
        return best;
    }

    /** Reads a price like "$1,500", "$2.5K" or "$3M" from the item's lore. Returns -1 when none is found. */
    private double parsePrice(class_1799 stack) {
        class_9290 lore = (class_9290)stack.method_58694(class_9334.field_49632);
        if (lore == null) {
            return -1.0;
        }

        String keyword = this.priceKeyword.getValue().trim().toLowerCase(Locale.ROOT);
        for (class_2561 line : lore.comp_2400()) {
            String text = line.getString();
            String tail = text;
            if (!keyword.isEmpty()) {
                int at = text.toLowerCase(Locale.ROOT).indexOf(keyword);
                if (at < 0) {
                    continue;
                }
                tail = text.substring(at + keyword.length());
            }

            Matcher matcher = PRICE_PATTERN.matcher(tail);
            if (matcher.find()) {
                try {
                    double value = Double.parseDouble(matcher.group(1).replace(",", ""));
                    switch (matcher.group(2).toLowerCase(Locale.ROOT)) {
                        case "k" -> value *= 1_000.0;
                        case "m" -> value *= 1_000_000.0;
                        case "b" -> value *= 1_000_000_000.0;
                        case "t" -> value *= 1_000_000_000_000.0;
                        default -> { }
                    }
                    return value;
                } catch (NumberFormatException ignored) {
                    // try the next line
                }
            }
        }
        return -1.0;
    }

    private class_1735 findNextPageSlot(class_1703 handler) {
        int index = this.nextPageSlot.getInt();
        if (index >= 0) {
            if (index < handler.field_7761.size()) {
                class_1735 slot = handler.field_7761.get(index);
                if (!(slot.field_7871 instanceof class_1661) && slot.method_7681()) {
                    return slot;
                }
            }
            return null;
        }

        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            if (slot.method_7677().method_7964().getString().toLowerCase(Locale.ROOT).contains("next")) {
                return slot;
            }
        }
        return null;
    }

    private int menuStackCount(class_1703 handler) {
        int count = 0;
        for (class_1735 slot : handler.field_7761) {
            if (!(slot.field_7871 instanceof class_1661) && slot.method_7681()) {
                count++;
            }
        }
        return count;
    }

    /** Cheap fingerprint of the menu part of a screen, used to notice that the page changed. */
    private String menuFingerprint(class_1703 handler) {
        StringBuilder sb = new StringBuilder();
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            sb.append(slot.field_7874).append(':').append(stack.method_7909()).append('x').append(stack.method_7947())
                .append('#').append(Objects.hashCode(stack.method_58694(class_9334.field_49632))).append(';');
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- inventory helpers

    /** Sell Items, or the Target Blocks if Sell Items is empty. */
    private List<String> sellFilter() {
        List<String> list = this.sellItems.get();
        if (list.isEmpty()) {
            list = this.targetBlocks.get();
        }
        return list;
    }

    private boolean isSellable(class_1799 stack) {
        List<String> filter = this.sellFilter();
        if (filter.isEmpty() || stack.method_7960()) {
            return false;
        }
        return Sell.e(stack, filter);
    }

    /** First sellable item sitting in the main inventory (not the hotbar), or null. */
    private class_1792 findSellableItem() {
        if (this.mc.field_1724 == null) {
            return null;
        }
        class_1661 inventory = this.mc.field_1724.method_31548();
        for (int i = 9; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (this.isSellable(stack)) {
                return stack.method_7909();
            }
        }
        return null;
    }

    private int countSellableItems() {
        if (this.mc.field_1724 == null) {
            return 0;
        }
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 9; i <= 35; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (this.isSellable(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private boolean isInventoryFullEnough() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int free = 0;
        for (int i = 0; i <= 35; i++) {
            if (inventory.method_5438(i).method_7960()) {
                free++;
            }
        }
        return free <= this.freeSlotsToSell.getInt();
    }

    // ================================================================ Safety

    /** Leaves the server when a totem pops or another player gets close. Returns true if it did. */
    private boolean tickSafety() {
        class_310 mc = this.mc;
        if (this.safetyTriggered || mc.field_1724.method_29504()) {
            return false;
        }

        if (this.disconnectOnTotem.get()) {
            int totems = this.countTotems();
            if (this.lastTotemCount >= 0 && totems < this.lastTotemCount) {
                this.safetyDisconnect("Totem popped (" + totems + " left)");
                return true;
            }
            this.lastTotemCount = totems;
        }

        if (this.disconnectOnPlayer.get()) {
            double range = this.playerRange.get();
            double rangeSq = range * range;
            Set<String> ignored = new HashSet<>();
            for (String name : this.ignoredPlayers.getValue().split(",")) {
                if (!name.isBlank()) {
                    ignored.add(name.trim().toLowerCase(Locale.ROOT));
                }
            }

            List<String> found = new ArrayList<>();
            for (class_1657 other : mc.field_1687.method_18456()) {
                if (other == mc.field_1724) {
                    continue;
                }
                double distSq = mc.field_1724.method_5858(other);
                if (distSq > rangeSq) {
                    continue;
                }
                String name = other.method_5477().getString();
                if (ignored.contains(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                found.add(name + " (" + (int)Math.sqrt(distSq) + " blocks)");
            }

            if (!found.isEmpty()) {
                this.safetyDisconnect("Player nearby: " + String.join(", ", found));
                return true;
            }
        }
        return false;
    }

    private int countTotems() {
        class_1661 inventory = this.mc.field_1724.method_31548();
        int total = 0;
        for (int i = 0; i <= 40; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8288) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private void safetyDisconnect(String reason) {
        if (this.safetyTriggered) {
            return;
        }
        this.safetyTriggered = true;

        class_2338 pos = this.mc.field_1724.method_24515();
        String server = this.mc.method_1558() != null ? this.mc.method_1558().field_3761 : "singleplayer";
        String message = "**[Auto Mine Sell] Disconnected**\n"
            + "Reason: " + reason + "\n"
            + "Server: " + server + "\n"
            + "Position: " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260() + "\n"
            + "Sold this run: " + this.soldTotal + " items (orders: " + this.ordersFilled + ", /sell: " + this.soldByFallback + ")";

        this.sendWebhook(message);
        this.say(reason + " - leaving the server.");
        this.releaseKeys();
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("Auto Mine Sell: " + reason)));
        this.requestDisable();
    }

    // ================================================================ Webhook

    private void sendWebhookTest() {
        if (!this.webhookUrl.getValue().trim().startsWith("https://")) {
            this.say("Set a Webhook URL (https://...) first.");
            return;
        }
        this.sendWebhook("**[Auto Mine Sell]** Webhook test OK.");
        this.say("Webhook test sent.");
    }

    /** Sends a message to the Discord webhook in the background. Does nothing without a valid URL. */
    private void sendWebhook(String content) {
        String url = this.webhookUrl.getValue().trim();
        if (!url.startsWith("https://")) {
            return;
        }

        String ping = this.webhookPing.getValue().trim();
        String body = "{\"content\":\"" + jsonEscape((ping.isEmpty() ? "" : ping + "\n") + content) + "\"}";

        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
            WEBHOOK_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.discarding()).exceptionally(error -> null);
        } catch (Exception ignored) {
            // bad URL: nothing to do
        }
    }

    private static String jsonEscape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int)c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    // ================================================================ misc

    private void say(String text) {
        KryzexClient.send((MacroModule)this, text);
    }
}
