package kryzex.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
enum PaymentState {
    PAID,
    POOR,
    RETRY,
    FAILED;

}
