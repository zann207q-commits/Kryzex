package kryzex.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class MacroAbort
extends RuntimeException {
    MacroAbort() {
        super(null, null, false, false);
    }
}
