package kryzex.modules.macros.h;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import kryzex.modules.macros.h.BeatTopOrder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class LastPriceCheck {
    final BeatTopOrder product;
    final boolean fixedPrice;
    long price = -1L;
    long lastPriceCheck;
    int inAh;
    final AtomicInteger listed = new AtomicInteger();
    final AtomicInteger sold = new AtomicInteger();
    final AtomicInteger chatSales = new AtomicInteger();
    final AtomicLong earned = new AtomicLong();
    private static final String vJA6ULhtf = "-WnYPigZggE";

    LastPriceCheck(BeatTopOrder beatTopOrder, boolean bl) {
        this.product = beatTopOrder;
        this.fixedPrice = bl;
        if (!bl) return;
        this.price = beatTopOrder.minPrice();
    }
}
