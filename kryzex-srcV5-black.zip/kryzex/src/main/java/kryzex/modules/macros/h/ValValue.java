package kryzex.modules.macros.h;

import net.minecraft.class_11437;
import net.minecraft.class_11521;
import net.minecraft.class_2481;
import net.minecraft.class_2520;

class ValValue
implements class_11521.class_11522 {
    final boolean val$value;
    final class_11437 val$input;

    ValValue(boolean bl, class_11437 class_114372) {
        this.val$value = bl;
        this.val$input = class_114372;
    }

    public String method_72069() {
        return this.val$value ? this.val$input.comp_4334() : this.val$input.comp_4335();
    }

    public class_2520 method_72073() {
        return class_2481.method_23234((boolean)this.val$value);
    }
}
