package kryzex.modules.macros.h;

import java.util.List;
import kryzex.module.MacroCategories;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.modules.macros.h.CouldNotOpen;
import kryzex.modules.macros.h.Thread;
import kryzex.modules.macros.h.Worker;
import kryzex.modules.macros.h.MacroException;
import kryzex.modules.misc.MacroModule;
import kryzex.util.KryzexClient;
import kryzex.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public final class OrderDropper
extends MacroModule {
    private static Logger LOGGER;
    private static final int ITEM_SLOTS = 45;
    private static final int DEFAULT_COLLECT_BUTTON = 13;
    private static final int DEFAULT_DROP_BUTTON = 52;
    private static final int DEFAULT_NEXT_BUTTON = 53;
    private static final int MAX_EMPTY_FLIPS = 2;
    private static final long NEXT_PAGE_SETTLE_MS = 250L;
    private static final long OPEN_TIMEOUT_MS = 5000L;
    private static final long PAGE_TIMEOUT_MS = 4000L;
    private final MacroNumberSetting orderSlot = this.addSetting("order-slot", new MacroNumberSetting("Order Slot (0 = first)", 0.0f, 0.0f, 44.0f).step(1.0f));
    private final MacroNumberSetting pages = this.addSetting("pages", new MacroNumberSetting("Pages To Drop", 1.0f, 1.0f, 100.0f).step(1.0f));
    private final MacroNumberSetting delay = this.addSetting("delay", new MacroNumberSetting("Drop Delay (s)", 0.5f, 0.25f, 5.0f).step(0.25f));
    private final Thread worker = new Thread("Kryzex Order Dropper");
    private volatile boolean running;
    private static String[] a;

    public OrderDropper() {
        super("order-dropper", "Order Dropper", "Opens one of your orders, collects it and drops the chosen number of pages, then turns off.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public void onEnable() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 != null && class_3102.method_1562() != null) {
            int n = this.orderSlot.getInt();
            int n2 = this.pages.getInt();
            long l = (long)(this.delay.get() * 1000.0f);
            this.running = true;
            this.worker.X(() -> this.lmbd$onEnable$0(n, n2, l, class_3102), arg_0 -> this.lmbd$onEnable$1(class_3102, arg_0));
            return;
        } else {
            this.r(KryzexClient.body().warn("Join a server first."));
            this.requestDisable();
        }
    }

    private void H(class_310 class_3102) {
        class_3102.execute(this::lmbd$finish$0);
    }

    @Override
    public void onDisable() {
        boolean bl = this.running;
        this.running = false;
        this.worker.i();
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (!bl || class_7462 == null || class_7462.field_7512 == class_7462.field_7498) return;
        class_7462.method_7346();
    }

    private void S(Worker worker, int n, int n2, long l) {
        String string;
        String[] stringArray;
        String string2 = this.d(worker, n);
        int n3 = 0;
        int n4 = 0;
        for (int i = 0; i < n2; ++i) {
            if (!this.worker.c(Worker::J).booleanValue()) {
                string2 = this.d(worker, n);
            }
            int[] nArray = this.worker.c(OrderDropper::n);
            for (int j = 0; nArray[0] == 0 && nArray[2] >= 0 && j < 2; ++j) {
                String string3 = worker.u();
                worker.P(nArray[2], 0, class_1713.field_7790);
                worker.h(string3, 4000L);
                this.worker.p(250L);
                nArray = this.worker.c(OrderDropper::n);
            }
            if (nArray[0] == 0) {
                stringArray = a;
                this.r(KryzexClient.body().text("The order is empty."));
                break;
            }
            if (nArray[1] < 0) {
                String[] stringArray2 = a;
                throw new MacroException("No Drop button in the collect menu");
            }
            String string4 = worker.u();
            worker.P(nArray[1], 0, class_1713.field_7790);
            ++n3;
            n4 += nArray[0];
            if (i >= n2 - 1) continue;
            worker.h(string4, 4000L);
            this.worker.p(l);
        }
        this.worker.p(300L);
        worker.k();
        Root root = KryzexClient.body();
        if (n3 == 1) {
            stringArray = a;
            string = " page";
        } else {
            stringArray = a;
            string = " pages";
        }
        String string5 = string;
        int n5 = n3;
        this.r(root.good("Dropped " + n5 + string5).text(" (").value(n4).text(" items) from ").name(string2).text("."));
    }

    private String d(Worker worker, int n) {
        if (!CouldNotOpen.o(this.worker, worker, this::r)) {
            String[] stringArray = a;
            throw new MacroException("Could not open Your Orders");
        }
        class_1799 class_17992 = this.worker.c(() -> OrderDropper.lmbd$openCollect$0(n));
        if (CouldNotOpen.m(class_17992)) {
            String[] stringArray = a;
            throw new MacroException("There is no order in slot " + n);
        }
        String string = class_17992.method_7964().getString();
        String string2 = worker.u();
        worker.P(n, 0, class_1713.field_7790);
        if (!this.worker.K(() -> OrderDropper.lmbd$openCollect$1(string2), 5000L)) {
            String[] stringArray = a;
            throw new MacroException("The order in slot " + n + " did not open");
        }
        this.worker.p(300L);
        int n2 = this.worker.c(OrderDropper::lmbd$openCollect$2);
        if (n2 < 0) {
            throw new MacroException("No Collect button in the order");
        }
        String string3 = worker.u();
        worker.P(n2, 0, class_1713.field_7790);
        if (!this.worker.K(() -> OrderDropper.lmbd$openCollect$3(string3), 5000L)) {
            throw new MacroException("The collect menu did not open");
        }
        this.worker.p(300L);
        return string;
    }

    private static int[] n() {
        List<class_1799> list = Worker.Q();
        int n = 0;
        for (int i = 0; i < 45 && i < list.size(); ++i) {
            n += list.get(i).method_7947();
        }
        return new int[]{n, OrderDropper.u(list), OrderDropper.v(list)};
    }

    private static int v(List<class_1799> list) {
        for (int i = 45; i < list.size(); ++i) {
            class_1799 class_17992 = list.get(i);
            if (class_17992.method_7960() || !Worker.B(class_17992).contains("next")) continue;
            return i;
        }
        if (list.size() <= 53) return -1;
        if (!list.get(53).method_31574(class_1802.field_8107)) return -1;
        return 53;
    }

    private static int u(List<class_1799> list) {
        for (int i = 45; i < list.size(); ++i) {
            class_1799 class_17992 = list.get(i);
            if (class_17992.method_7960()) continue;
            if (class_17992.method_31574(class_1802.field_8878)) return i;
            if (!Worker.B(class_17992).equals("drop")) continue;
            return i;
        }
        if (list.size() <= 52) return -1;
        if (!list.get(52).method_31574(class_1802.field_8878)) return -1;
        return 52;
    }

    private void r(Root root) {
        KryzexClient.send((MacroModule)this, root);
    }

    private static boolean lmbd$openCollect$3(String string) {
        if (!Worker.J()) return false;
        if (Worker.V().equals(string)) return false;
        if (OrderDropper.u(Worker.Q()) < 0) return false;
        return true;
    }

    private static Integer lmbd$openCollect$2() {
        List<class_1799> list = Worker.Q();
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i).method_7960() || !Worker.B(list.get(i)).contains("collect")) continue;
            return i;
        }
        return list.size() > 13 && !list.get(13).method_7960() ? 13 : -1;
    }

    private static boolean lmbd$openCollect$1(String string) {
        if (!Worker.J()) return false;
        if (CouldNotOpen.b()) return false;
        if (Worker.V().equals(string)) return false;
        return true;
    }

    private static class_1799 lmbd$openCollect$0(int n) {
        return Worker.S(n);
    }

    private void lmbd$finish$0() {
        if (!this.running || !this.isEnabled()) return;
        this.toggle(false);
    }

    private void lmbd$onEnable$1(class_310 class_3102, Throwable throwable) {
        LOGGER.error("[Kryzex] Order Dropper stopped", throwable);
        this.r(KryzexClient.body().danger("Stopped").text(": " + String.valueOf(throwable)));
        this.H(class_3102);
    }

    private void lmbd$onEnable$0(int n, int n2, long l, class_310 class_3102) {
        try {
            this.S(new Worker(this.worker), n, n2, l);
            return;
        }
        catch (MacroException c2) {
            this.r(KryzexClient.body().warn(c2.getMessage()).text("."));
            return;
        }
        finally {
            this.H(class_3102);
        }
    }

    static {
        a = new String[]{" (", "Join a server first.", "Dropped ", "pages", "The order is empty.", "delay", "[Kryzex] Order Dropper stopped", "No Drop button in the collect menu", "next", "Opens one of your orders, collects it and drops the chosen number of pages, then turns off.", "Drop Delay (s)", "The collect menu did not open", "Stopped", "order-slot", "The order in slot ", "drop", "Could not open Your Orders", "Order Slot (0 = first)", "Kryzex Order Dropper", "collect", "Order Dropper", " page", "There is no order in slot ", "No Collect button in the order", "order-dropper", " pages", " items) from ", ": ", " did not open", "Kryzex", "Pages To Drop"};
        LOGGER = LoggerFactory.getLogger("Kryzex");
    }
}
