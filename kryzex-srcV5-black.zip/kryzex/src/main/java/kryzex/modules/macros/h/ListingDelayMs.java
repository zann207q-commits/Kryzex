package kryzex.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class ListingDelayMs {
    public final long undercut;
    public final long priceCheckMs;
    public final long salesCheckMs;
    public final int perListing;
    public final int maxListings;
    public final long listingDelayMs;
    public final double relistGap;
    public final double ignoreDrops;
    public final int collectSlots;
    public final long orderCheckMs;

    public ListingDelayMs(long undercut, long priceCheckMs, long salesCheckMs, int perListing, int maxListings, long listingDelayMs, double relistGap, double ignoreDrops, int collectSlots, long orderCheckMs) {
        this.undercut = undercut;
        this.priceCheckMs = priceCheckMs;
        this.salesCheckMs = salesCheckMs;
        this.perListing = perListing;
        this.maxListings = maxListings;
        this.listingDelayMs = listingDelayMs;
        this.relistGap = relistGap;
        this.ignoreDrops = ignoreDrops;
        this.collectSlots = collectSlots;
        this.orderCheckMs = orderCheckMs;
    }

    public long undercut() {
        return this.undercut;
    }

    public long priceCheckMs() {
        return this.priceCheckMs;
    }

    public long salesCheckMs() {
        return this.salesCheckMs;
    }

    public int perListing() {
        return this.perListing;
    }

    public int maxListings() {
        return this.maxListings;
    }

    public long listingDelayMs() {
        return this.listingDelayMs;
    }

    public double relistGap() {
        return this.relistGap;
    }

    public double ignoreDrops() {
        return this.ignoreDrops;
    }

    public int collectSlots() {
        return this.collectSlots;
    }

    public long orderCheckMs() {
        return this.orderCheckMs;
    }
}
