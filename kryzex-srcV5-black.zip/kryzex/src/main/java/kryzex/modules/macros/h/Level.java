package kryzex.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class Level {
    public final String key;
    public final String name;
    public final int level;

    public Level(String key, String name, int level) {
        this.key = key;
        this.name = name;
        this.level = level;
    }

    public String key() {
        return this.key;
    }

    public String name() {
        return this.name;
    }

    public int level() {
        return this.level;
    }
    String label() {
        return this.name + (String)(this.level > 1 ? " " + this.level : "");
    }
}
