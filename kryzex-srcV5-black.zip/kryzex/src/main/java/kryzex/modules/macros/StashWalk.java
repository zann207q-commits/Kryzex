package kryzex.modules.macros;

enum StashWalk {
    IDLE,
    MINING,
    STASH_WALK,
    STASH_OPEN,
    STASH_DEPOSIT,
    DONE;

}
