package kryzex.modules.macros.h;

import net.minecraft.class_1792;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kryzex.modules.macros.h.BeatTopOrder;
import kryzex.modules.macros.h.Component;
import kryzex.modules.macros.h.Each;
import kryzex.modules.macros.h.ListingState;
import kryzex.modules.macros.h.LastPriceCheck;
import kryzex.modules.macros.h.ListingDelayMs;
import kryzex.modules.macros.h.TextInputs;
import kryzex.modules.macros.h.Thread;
import kryzex.modules.macros.h.Worker;
import kryzex.modules.macros.h.MacroException;
import kryzex.modules.macros.h.DialogReader;
import kryzex.modules.misc.MacroModule;
import kryzex.util.KryzexClient;
import kryzex.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_418;
import net.minecraft.class_746;
import net.minecraft.class_7923;

@Environment(value=EnvType.CLIENT)
final class Order {
    private static final int INVENTORY_SLOTS = 36;
    private static final int AH_SCAN_SLOTS = 45;
    private static final int AH_ROOT_BUTTON = 51;
    private static final int CHEST_CONFIRM_SLOT = 15;
    private static final int INVENTORY_SETTLE_TICKS = 4;
    private static final int COLLECT_LIMIT = 50;
    private static final int VERIFY_LIMIT = 15;
    private static final long OPEN_TIMEOUT_MS = 10000L;
    private static final long NAV_TIMEOUT_MS = 4000L;
    private static final long SELL_TIMEOUT_MS = 15000L;
    final MacroModule module;
    final Thread worker;
    final Worker gui;
    final ListingDelayMs config;
    private final String ign;
    private final String ignKey;
    private volatile long tooManyAt;
    private volatile long alreadyBoughtAt;
    private volatile long listedAt;
    private volatile long errorAt;
    private static final String[] a = new String[]{"Listing timed out", ": no other listings, selling at $", "confirm", "don't have enough", " ah ", ").", ", earned ~$", "yes", "Listed ", " (inventory full?).", "sure", " listing of ", ", ~$", "you listed", " for ", "Sold ", "ignoring a deep undercut", ": cheapest is $", " each.", "Listed ", "ah sell ", "lime", "you cannot do this", " for $", "could not read AH prices", "order", "Could not open Your Items.", " to $", "ah", "already bought", "order", "undercut", ", relisting at $", ", respawning.", " listings of ", " at $", " each.", ": price went up to $", "ah ", "auction", "Respawned", ", relisting at $", ", selling at $", " to $", " (in AH: ", "trapped_chest", ").", "sell", ": ", "confirm", ": ", " bought your ", " (total ", "Could not prepare a hotbar slot", "chest", "The AH says you have too many listings.", " (total ", ", sold ", "Took back ", " bought your ", "Sold", "market", "too many listed items", " (drop $", ", waiting.", "You died", "you need to wait another"};

    Order(MacroModule macroModule, Thread thread, ListingDelayMs listingDelayMs, String string) {
        this.module = macroModule;
        this.worker = thread;
        this.gui = new Worker(thread);
        this.config = listingDelayMs;
        this.ign = string;
        this.ignKey = Each.p(string);
    }

    void C(Root root) {
        KryzexClient.send(this.module, root);
    }

    boolean t() {
        return this.worker.c(Order::lmbd$inWorld$0);
    }

    void X(LastPriceCheck lastPriceCheck) {
        if (lastPriceCheck.fixedPrice) {
            lastPriceCheck.price = lastPriceCheck.product.minPrice();
            return;
        } else {
            if (lastPriceCheck.price > 0L && System.currentTimeMillis() - lastPriceCheck.lastPriceCheck < this.config.priceCheckMs()) return;
            this.Y(lastPriceCheck);
        }
    }

    private void Y(LastPriceCheck lastPriceCheck) {
        BeatTopOrder beatTopOrder = lastPriceCheck.product;
        double[] dArray = this.k(lastPriceCheck);
        lastPriceCheck.lastPriceCheck = System.currentTimeMillis();
        boolean bl = dArray[0] > 0.0;
        boolean bl2 = dArray[1] > 0.0;
        double d = dArray[2];
        long l = this.config.undercut();
        String string = beatTopOrder.displayName();
        if (d > 0.0) {
            long l2 = Math.round(d);
            long l3 = Math.max(l2 - l, beatTopOrder.minPrice());
            if (lastPriceCheck.price > 0L && l2 < lastPriceCheck.price) {
                long l4 = lastPriceCheck.price - l2;
                if ((double)l4 > (double)l * this.config.ignoreDrops()) {
                    String[] stringArray = a;
                    this.C(KryzexClient.body().name(string).text(": ").warn("ignoring a deep undercut").text(" to $").value(Each.t(l2)).text(" (drop $").value(Each.t(l4)).text(")."));
                    return;
                } else {
                    if (l3 >= lastPriceCheck.price) return;
                    String[] stringArray = a;
                    this.C(KryzexClient.body().name(string).text(": ").warn("undercut").text(" to $").value(Each.t(l2)).text(", relisting at $").value(Each.t(l3)).text("."));
                    this.d(lastPriceCheck, l3);
                }
                return;
            } else if (lastPriceCheck.price > 0L && (double)l3 > (double)lastPriceCheck.price + (double)l * this.config.relistGap() && lastPriceCheck.inAh > 0) {
                String[] stringArray = a;
                this.C(KryzexClient.body().name(string).text(": price went up to $").value(Each.t(l2)).text(", relisting at $").value(Each.t(l3)).text("."));
                this.d(lastPriceCheck, l3);
                return;
            } else {
                if (lastPriceCheck.price <= 0L) {
                    String[] stringArray = a;
                    this.C(KryzexClient.body().name(string).text(": cheapest is $").value(Each.t(l2)).text(", selling at $").value(Each.t(l3)).text(" each."));
                }
                lastPriceCheck.price = l3;
            }
            return;
        } else if (lastPriceCheck.price <= 0L && bl && !bl2) {
            lastPriceCheck.price = beatTopOrder.minPrice() * 2L;
            String[] stringArray = a;
            this.C(KryzexClient.body().name(string).text(": no other listings, selling at $").value(Each.t(lastPriceCheck.price)).text(" each."));
            return;
        } else {
            if (lastPriceCheck.price > 0L) return;
            this.C(KryzexClient.body().name(string).text(": ").warn("could not read AH prices").text(", waiting."));
        }
    }

    private double[] k(LastPriceCheck lastPriceCheck) {
        BeatTopOrder beatTopOrder = lastPriceCheck.product;
        this.gui.k();
        this.worker.p(200L);
        this.gui.T("ah " + beatTopOrder.search());
        boolean bl = this.worker.K(this::lmbd$scan$0, 10000L);
        if (!bl) {
            this.gui.k();
            return new double[]{0.0, 0.0, -1.0};
        }
        this.worker.p(600L);
        if (!this.worker.c(this::r).booleanValue()) {
            this.gui.k();
            return new double[]{0.0, 0.0, -1.0};
        }
        double[] dArray = this.worker.c(() -> this.lmbd$scan$1(beatTopOrder, lastPriceCheck));
        this.gui.k();
        this.worker.p(200L);
        return dArray;
    }

    private boolean T(LastPriceCheck lastPriceCheck, class_1799 class_17992, double d) {
        for (String string : Each.R(class_17992)) {
            if (this.ignKey.isEmpty() || !Each.p(string).contains(this.ignKey)) continue;
            return true;
        }
        if (lastPriceCheck.inAh <= 0) return false;
        if (lastPriceCheck.price <= 0L) return false;
        if (!(Math.abs(d - (double)lastPriceCheck.price) < 1.0)) return false;
        return true;
    }

    private boolean R() {
        List<class_1799> list = Worker.Q();
        if (list.size() > 49 && !list.get(49).method_7960()) {
            return true;
        }
        for (int i = 0; i <= 10 && i < list.size(); ++i) {
            if (list.get(i).method_7960()) continue;
            return true;
        }
        return false;
    }

    private boolean r() {
        if (!Worker.J()) {
            return false;
        }
        String string = Each.v(Worker.m().field_1755.method_25440());
        String[] stringArray = a;
        if (string.contains("order")) {
            return false;
        }
        if (string.contains("auction")) return true;
        if (string.contains("market")) return true;
        if (string.equals("ah")) return true;
        if (string.contains(" ah ")) return true;
        boolean bl = Order.H(Worker.S(51));
        return bl;
    }

    private boolean h() {
        if (!Worker.J()) {
            return false;
        }
        if (Each.v(Worker.m().field_1755.method_25440()).contains("order")) {
            return false;
        }
        boolean bl = Order.H(Worker.S(51));
        return bl;
    }

    private static boolean H(class_1799 class_17992) {
        if (class_17992.method_7960()) {
            return false;
        }
        String string = class_7923.field_41178.method_10221(class_17992.method_7909()).method_12832();
        if (string.equals("chest")) return true;
        if (!string.equals("trapped_chest")) return false;
        return true;
    }

    private boolean N() {
        this.gui.k();
        this.worker.p(200L);
        this.gui.T("ah " + this.ign);
        if (!this.worker.K(this::h, 10000L)) {
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            String string = this.gui.u();
            this.gui.P(51, 0, class_1713.field_7790);
            if (!this.gui.h(string, 4000L)) continue;
            this.worker.p(200L);
            return this.worker.c(Worker::J);
        }
        return false;
    }

    boolean V(List<LastPriceCheck> list) {
        if (!this.N()) {
            this.gui.k();
            return false;
        }
        int[] nArray = this.worker.c(() -> Order.lmbd$refreshListings$0(list));
        this.gui.k();
        this.worker.p(200L);
        for (int i = 0; i < list.size(); ++i) {
            LastPriceCheck lastPriceCheck = list.get(i);
            int n = lastPriceCheck.inAh - nArray[i];
            if (n > 0 && lastPriceCheck.chatSales.getAndSet(0) == 0) {
                lastPriceCheck.sold.addAndGet(n);
                lastPriceCheck.earned.addAndGet((long)n * Math.max(0L, lastPriceCheck.price) * (long)this.config.perListing());
                this.C(KryzexClient.body().good("Sold " + n + "x").text(" ").name(lastPriceCheck.product.displayName()).text(" (total ").value(lastPriceCheck.sold.get()).text(")."));
            }
            lastPriceCheck.chatSales.set(0);
            lastPriceCheck.inAh = nArray[i];
        }
        return true;
    }

    private int p(LastPriceCheck lastPriceCheck) {
        if (!this.N()) {
            String[] stringArray = a;
            this.C(KryzexClient.body().warn("Could not open Your Items."));
            this.gui.k();
            return 0;
        }
        int n = this.L(lastPriceCheck.product, 50);
        if (n > 0) {
            this.gui.k();
            this.worker.p(500L);
            if (this.N()) {
                n += this.L(lastPriceCheck.product, 15);
            }
        }
        this.gui.k();
        this.worker.p(200L);
        if (n <= 0) return n;
        this.C(KryzexClient.body().text("Took back ").value(n).text(n == 1 ? " listing of " : " listings of ").name(lastPriceCheck.product.displayName()).text("."));
        return n;
    }

    private int L(BeatTopOrder beatTopOrder, int n) {
        int n2;
        int n3 = 0;
        HashSet<Integer> hashSet = new HashSet<Integer>();
        while (n3 < n && this.worker.c(Worker::J).booleanValue() && (n2 = this.worker.c(() -> Order.lmbd$collectPass$0(hashSet, beatTopOrder)).intValue()) >= 0) {
            long l = System.currentTimeMillis();
            this.gui.P(n2, 0, class_1713.field_7790);
            this.worker.S(3);
            if (this.alreadyBoughtAt >= l) {
                hashSet.add(n2);
                continue;
            }
            ++n3;
        }
        return n3;
    }

    private void d(LastPriceCheck lastPriceCheck, long l) {
        this.V(List.of(lastPriceCheck));
        lastPriceCheck.price = l;
        this.p(lastPriceCheck);
        lastPriceCheck.inAh = 0;
    }

    int M(LastPriceCheck lastPriceCheck, int n, int[] nArray) {
        if (n <= 0) {
            return 0;
        }
        this.gui.k();
        this.gui.F();
        int n2 = this.worker.c(Order::lmbd$listSome$0);
        int n3 = 0;
        int n4 = 0;
        try {
            for (int i = 0; i < n; ++i) {
                this.m();
                int n5 = this.c(lastPriceCheck.product);
                if (n5 < 0) {
                    String[] stringArray = a;
                    this.C(KryzexClient.body().warn("Could not prepare a hotbar slot").text(" (inventory full?)."));
                    break;
                }
                ListingState eg = this.D(lastPriceCheck, n5);
                if (eg == ListingState.FULL) {
                    nArray[0] = Math.max(nArray[0], this.config.maxListings());
                    String[] stringArray = a;
                    this.C(KryzexClient.body().warn("The AH says you have too many listings."));
                    break;
                }
                if (eg == ListingState.FAILED) {
                    if (++n4 < 2) continue;
                    break;
                }
                ++n3;
                ++lastPriceCheck.inAh;
                nArray[0] = nArray[0] + 1;
                lastPriceCheck.listed.incrementAndGet();
                if (this.config.listingDelayMs() <= 0L || i >= n - 1) continue;
                this.worker.p(this.config.listingDelayMs());
            }
        }
        finally {
            this.worker.q(() -> Order.lmbd$listSome$1(n2));
        }
        if (n3 <= 0) return n3;
        this.C(KryzexClient.body().text("Listed ").value(n3 + "x").text(" ").name(lastPriceCheck.product.displayName()).text(" at $").value(Each.t(lastPriceCheck.price * (long)this.config.perListing())).text(" (in AH: ").value(nArray[0]).text(")."));
        return n3;
    }

    private ListingState D(LastPriceCheck lastPriceCheck, int n) {
        BeatTopOrder beatTopOrder = lastPriceCheck.product;
        this.worker.q(() -> Order.lmbd$listFrom$0(n));
        this.worker.S(2);
        int n2 = this.worker.c(() -> Order.lmbd$listFrom$1(n));
        long l = System.currentTimeMillis();
        this.gui.T("ah sell " + Each.J(lastPriceCheck.price * (long)this.config.perListing()));
        long l2 = l + 15000L;
        boolean[] blArray = new boolean[]{false};
        Object[] objectArray = new Object[]{null};
        int[] nArray = new int[]{-1};
        while (System.currentTimeMillis() < l2) {
            if (this.tooManyAt >= l) {
                this.gui.k();
                return ListingState.FULL;
            }
            if (this.listedAt >= l) {
                this.worker.p(150L);
                this.gui.k();
                return ListingState.LISTED;
            }
            if (this.errorAt >= l) {
                this.gui.k();
                return ListingState.FAILED;
            }
            long l3 = System.currentTimeMillis() - l;
            int n3 = this.worker.c(() -> Order.lmbd$listFrom$2(objectArray, blArray, nArray, n, beatTopOrder, n2, l3));
            if (n3 == 2) {
                this.gui.k();
                return ListingState.LISTED;
            }
            this.worker.p(n3 == 1 ? 250L : 50L);
        }
        this.gui.k();
        this.C(KryzexClient.body().warn("Listing timed out").text("."));
        return ListingState.FAILED;
    }

    private int c(BeatTopOrder beatTopOrder) {
        int n = this.config.perListing();
        boolean bl = false;
        try {
            int n2;
            for (n2 = 0; n2 < 12; ++n2) {
                int n3;
                int[] nArray = this.worker.c(() -> Order.lmbd$stage$0(beatTopOrder, n));
                if (nArray[0] == 0) {
                    n3 = nArray[1];
                    return n3;
                }
                if (nArray[0] < 0) {
                    n3 = -1;
                    return n3;
                }
                for (n3 = 2; n3 < nArray.length; n3 += 2) {
                    this.gui.U(nArray[n3] >> 1, nArray[n3] & 1, nArray[n3 + 1] == 1 ? class_1713.field_7794 : class_1713.field_7790);
                    bl = true;
                    this.worker.S(1);
                }
            }
            n2 = -1;
            return n2;
        }
        finally {
            if (bl) {
                this.gui.F();
                this.worker.S(4);
            }
        }
    }

    private static int[] U(BeatTopOrder beatTopOrder, int n) {
        Object object;
        int n2;
        int n3;
        int n4;
        class_746 class_7462 = Worker.f();
        class_1661 class_16612 = class_7462.method_31548();
        class_1799 class_17992 = class_7462.field_7498.method_34255();
        if (!class_17992.method_7960()) {
            int[] nArray;
            int n5 = Order.Z(class_16612);
            if (n5 < 0) {
                int[] nArray2 = new int[1];
                nArray = nArray2;
                nArray2[0] = -1;
                return nArray;
            } else {
                int[] nArray3 = new int[4];
                nArray3[0] = 1;
                nArray3[1] = 0;
                nArray3[2] = Order.l(Order.f(n5), 0);
                nArray = nArray3;
                nArray3[3] = 0;
            }
            return nArray;
        }
        for (n4 = 0; n4 < 9; ++n4) {
            class_1799 class_17993 = class_16612.method_5438(n4);
            if (!beatTopOrder.matches(class_17993) || class_17993.method_7947() != n) continue;
            return new int[]{0, n4};
        }
        n4 = -1;
        for (n3 = 0; n3 < 9; ++n3) {
            class_1799 class_17994 = class_16612.method_5438(n3);
            if (!beatTopOrder.matches(class_17994) || class_17994.method_7947() >= n) continue;
            n4 = n3;
            break;
        }
        if (n4 < 0) {
            for (n3 = 0; n3 < 9; ++n3) {
                if (!class_16612.method_5438(n3).method_7960()) continue;
                n4 = n3;
                break;
            }
        }
        if (n4 < 0) {
            int[] nArray;
            n3 = -1;
            for (int i = 8; i >= 0; --i) {
                if (beatTopOrder.matches(class_16612.method_5438(i))) continue;
                n3 = i;
                break;
            }
            if (n3 < 0) {
                n3 = 8;
            }
            if (Order.Z(class_16612) < 0) {
                int[] nArray4 = new int[1];
                nArray = nArray4;
                nArray4[0] = -1;
                return nArray;
            } else {
                int[] nArray5 = new int[4];
                nArray5[0] = 1;
                nArray5[1] = 0;
                nArray5[2] = Order.l(Order.f(n3), 0);
                nArray = nArray5;
                nArray5[3] = 1;
            }
            return nArray;
        }
        n3 = beatTopOrder.matches(class_16612.method_5438(n4)) ? class_16612.method_5438(n4).method_7947() : 0;
        int n6 = -1;
        int n7 = 0;
        class_1799 class_17995;
        for (n2 = 0; n2 < 36; ++n2) {
            if (n2 == n4 || !beatTopOrder.matches(class_17995 = class_16612.method_5438(n2)) || class_17995.method_7947() <= n7) continue;
            n7 = class_17995.method_7947();
            n6 = n2;
        }
        if (n6 < 0) {
            return new int[]{-1};
        }
        n2 = n - n3;
        int[] object2 = new int[2 + 2 * (n2 + 2)];
        int n8 = 2;
        object2[0] = 1;
        object2[n8++] = Order.l(Order.f(n6), 0);
        object2[n8++] = 0;
        if (n7 <= n2) {
            object2[n8++] = Order.l(Order.f(n4), 0);
            object2[n8++] = 0;
            return Arrays.copyOf(object2, n8);
        } else {
            for (int i = 0; i < n2; ++i) {
                object2[n8++] = Order.l(Order.f(n4), 1);
                object2[n8++] = 0;
            }
            object2[n8++] = Order.l(Order.f(n6), 0);
            object2[n8++] = 0;
        }
        return Arrays.copyOf(object2, n8);
    }

    private static int l(int n, int n2) {
        return n << 1 | n2;
    }

    private static int f(int n) {
        return n < 9 ? 36 + n : n;
    }

    private static int Z(class_1661 class_16612) {
        for (int i = 9; i < 36; ++i) {
            if (!class_16612.method_5438(i).method_7960()) continue;
            return i;
        }
        return -1;
    }

    int O(BeatTopOrder beatTopOrder) {
        return this.worker.c(() -> Order.lmbd$countInventory$0(beatTopOrder));
    }

    boolean S(BeatTopOrder beatTopOrder) {
        return this.worker.c(() -> this.lmbd$inventoryCapReached$0(beatTopOrder));
    }

    void m() {
        boolean bl;
        if (!this.worker.c(Order::lmbd$ensureAlive$0).booleanValue()) return;
        this.C(KryzexClient.body().danger("You died").text(", respawning."));
        long l = System.currentTimeMillis() + 30000L;
        long l2 = System.currentTimeMillis() + 700L;
        while (System.currentTimeMillis() < l && (bl = this.worker.c(Order::lmbd$ensureAlive$1).booleanValue())) {
            if (System.currentTimeMillis() >= l2) {
                this.worker.q(Order::lmbd$ensureAlive$2);
                l2 = System.currentTimeMillis() + 1500L;
            }
            this.worker.p(100L);
        }
        this.worker.q(Order::lmbd$ensureAlive$3);
        throw new MacroException("Respawned");
    }

    void v() {
        long l = System.currentTimeMillis() + this.config.salesCheckMs();
        while (System.currentTimeMillis() < l) {
            this.worker.p(Math.min(1000L, l - System.currentTimeMillis()));
        }
    }

    String E(String string, List<LastPriceCheck> list) {
        long l = System.currentTimeMillis();
        String[] stringArray = a;
        if (string.contains("too many listed items")) {
            this.tooManyAt = l;
        }
        stringArray = a;
        if (string.contains("already bought")) {
            this.alreadyBoughtAt = l;
        }
        stringArray = a;
        if (string.startsWith("you listed")) {
            this.listedAt = l;
        }
        stringArray = a;
        if (string.contains("you cannot do this") || string.contains("you need to wait another") || string.contains("don't have enough")) {
            this.errorAt = l;
        }
        stringArray = a;
        int n = string.indexOf(" bought your ");
        if (n <= 0) {
            return null;
        }
        stringArray = a;
        String string2 = string.substring(n + " bought your ".length());
        int n2 = string2.lastIndexOf(" for ");
        String string3 = n2 > 0 ? string2.substring(0, n2) : string2;
        LastPriceCheck lastPriceCheck = null;
        for (LastPriceCheck lastPriceCheck2 : list) {
            if (!lastPriceCheck2.product.nameMatches(string3, false)) continue;
            lastPriceCheck = lastPriceCheck2;
            break;
        }
        if (lastPriceCheck == null) {
            for (LastPriceCheck lastPriceCheck2 : list) {
                if (!lastPriceCheck2.product.nameMatches(string3, true)) continue;
                lastPriceCheck = lastPriceCheck2;
                break;
            }
        }
        if (lastPriceCheck == null) {
            return null;
        }
        List<Double> list2 = n2 > 0 ? Each.a(string2.substring(n2)) : List.of();
        long l2 = list2.isEmpty() ? 0L : Math.round((Double)list2.get(0));
        lastPriceCheck.sold.incrementAndGet();
        lastPriceCheck.chatSales.incrementAndGet();
        lastPriceCheck.earned.addAndGet(l2);
        stringArray = a;
        this.C(KryzexClient.body().good("Sold").text(" ").name(lastPriceCheck.product.displayName()).text((String)(l2 > 0L ? " for $" + Each.t(l2) : "")).text(" (total ").value(lastPriceCheck.sold.get()).text(", ~$").value(Each.t(lastPriceCheck.earned.get())).text(")."));
        return lastPriceCheck.product.displayName();
    }

    static String g(List<LastPriceCheck> list) {
        int n = 0;
        int n2 = 0;
        long l = 0L;
        for (LastPriceCheck lastPriceCheck : list) {
            n += lastPriceCheck.listed.get();
            n2 += lastPriceCheck.sold.get();
            l += lastPriceCheck.earned.get();
        }
        String string = Each.t(l);
        int n3 = n2;
        int n4 = n;
        return "Listed " + n4 + ", sold " + n3 + ", earned ~$" + string + ".";
    }

    private static void lmbd$ensureAlive$3() {
        if (!(Worker.m().field_1755 instanceof class_418)) return;
        Worker.m().method_1507(null);
    }

    private static void lmbd$ensureAlive$2() {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) return;
        class_7462.method_7331();
    }

    private static Boolean lmbd$ensureAlive$1() {
        return Worker.m().field_1724 != null && Worker.m().field_1724.method_29504();
    }

    private static Boolean lmbd$ensureAlive$0() {
        return Worker.m().field_1724 != null && Worker.m().field_1724.method_29504();
    }

    private Boolean lmbd$inventoryCapReached$0(BeatTopOrder beatTopOrder) {
        class_1661 class_16612 = Worker.f().method_31548();
        int n = 0;
        int n2 = 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (class_17992.method_7960()) {
                ++n2;
                continue;
            }
            if (!class_17992.method_31574(beatTopOrder.item())) continue;
            ++n;
        }
        return n >= this.config.collectSlots() || n2 <= 0;
    }

    private static Integer lmbd$countInventory$0(BeatTopOrder beatTopOrder) {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) {
            return 0;
        }
        int n = 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 class_17992 = class_7462.method_31548().method_5438(i);
            if (!beatTopOrder.matches(class_17992)) continue;
            n += class_17992.method_7947();
        }
        return n;
    }

    private static int[] lmbd$stage$0(BeatTopOrder beatTopOrder, int n) {
        return Order.U(beatTopOrder, n);
    }

    private static Integer lmbd$listFrom$2(Object[] objectArray, boolean[] blArray, int[] nArray, int n, BeatTopOrder beatTopOrder, int n2, long l) {
        TextInputs textInputs = DialogReader.C(Worker.m());
        if (textInputs != null) {
            Component component;
            if (textInputs.dialog() == objectArray[0]) return 0;
            String[] stringArray = a;
            if (!textInputs.titled("sure") && !textInputs.titled("confirm") && !textInputs.titled("sell") || (component = textInputs.labelled("yes", "confirm")) == null || !DialogReader.N(Worker.m(), textInputs, component, Map.of())) return 0;
            objectArray[0] = textInputs.dialog();
            blArray[0] = true;
            return 1;
        }
        if (Worker.J()) {
            class_746 class_7462 = Worker.f();
            int n3 = class_7462.field_7512.field_7763;
            class_1799 class_17992 = Worker.S(15);
            if (n3 == nArray[0] || class_17992.method_7960() || !class_7923.field_41178.method_10221(class_17992.method_7909()).method_12832().contains("lime")) return 0;
            Worker.m().field_1761.method_2906(n3, 15, 0, class_1713.field_7790, (class_1657)class_7462);
            nArray[0] = n3;
            blArray[0] = true;
            return 1;
        }
        class_1799 class_17993 = Worker.f().method_31548().method_5438(n);
        boolean bl = !beatTopOrder.matches(class_17993) || class_17993.method_7947() < n2;
        return !bl || !blArray[0] && l <= 2000L ? 0 : 2;
    }

    private static Integer lmbd$listFrom$1(int n) {
        return Worker.f().method_31548().method_5438(n).method_7947();
    }

    private static void lmbd$listFrom$0(int n) {
        Worker.f().method_31548().method_61496(n);
    }

    private static void lmbd$listSome$1(int n) {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) return;
        class_7462.method_31548().method_61496(n);
    }

    private static Integer lmbd$listSome$0() {
        return Worker.f().method_31548().method_67532();
    }

    private static Integer lmbd$collectPass$0(Set set, BeatTopOrder beatTopOrder) {
        List<class_1799> list = Worker.Q();
        for (int i = 0; i < list.size(); ++i) {
            if (set.contains(i) || !beatTopOrder.matches(list.get(i))) continue;
            return i;
        }
        return -1;
    }

    private static int[] lmbd$refreshListings$0(List list) {
        int[] nArray = new int[list.size()];
        block0: for (class_1799 class_17992 : Worker.Q()) {
            for (int i = 0; i < list.size(); ++i) {
                if (!((LastPriceCheck)list.get((int)i)).product.matches(class_17992)) continue;
                int n = i;
                nArray[n] = nArray[n] + 1;
                continue block0;
            }
        }
        return nArray;
    }

    private double[] lmbd$scan$1(BeatTopOrder beatTopOrder, LastPriceCheck lastPriceCheck) {
        List<class_1799> list = Worker.Q();
        boolean bl = false;
        double d = -1.0;
        for (int i = 0; i < list.size() && i < 45; ++i) {
            double d2;
            class_1799 class_17992 = list.get(i);
            if (!beatTopOrder.matches(class_17992)) continue;
            bl = true;
            double d3 = Each.Q(class_17992);
            if (d3 <= 0.0 || this.T(lastPriceCheck, class_17992, d2 = d3 / (double)Math.max(1, class_17992.method_7947())) || !(d < 0.0) && !(d2 < d)) continue;
            d = d2;
        }
        return new double[]{1.0, bl ? 1.0 : 0.0, d};
    }

    private boolean lmbd$scan$0() {
        if (!this.r()) return false;
        if (!this.R()) return false;
        return true;
    }

    private static Boolean lmbd$inWorld$0() {
        return Worker.m().field_1724 != null && Worker.m().method_1562() != null;
    }
}
