package kryzex.modules.macros.h;

import java.util.Map;
import kryzex.modules.macros.h.Component;
import kryzex.modules.macros.h.TextInputs;
import kryzex.modules.macros.h.DialogReader;
import kryzex.modules.misc.MacroModule;
import kryzex.util.KryzexClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(value=EnvType.CLIENT)
final class Teleport {
    private final MacroModule owner;
    private Object pressed;
    private boolean warned;

    Teleport(MacroModule macroModule) {
        this.owner = macroModule;
    }

    void E() {
        this.pressed = null;
        this.warned = false;
    }

    boolean X(class_310 class_3102) {
        TextInputs textInputs = DialogReader.C(class_3102);
        if (textInputs == null || !textInputs.titled("teleport")) return false;
        if (textInputs.dialog() == this.pressed) {
            return true;
        }
        Component component = textInputs.labelled("confirm", "yes", "accept");
        if (component == null) {
            return false;
        }
        if (!this.warned) {
            this.warned = true;
            KryzexClient.send(this.owner, KryzexClient.body().warn("Your teleport confirm menu is on").text(". Turn it off in /settings so requests go out faster. Confirming each one for now."));
        }
        this.pressed = textInputs.dialog();
        DialogReader.N(class_3102, textInputs, component, Map.of());
        return true;
    }
}
