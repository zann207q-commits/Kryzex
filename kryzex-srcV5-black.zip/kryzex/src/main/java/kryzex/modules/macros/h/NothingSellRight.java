package kryzex.modules.macros.h;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;
import kryzex.modules.macros.h.AHSell;
import kryzex.modules.macros.h.BeatTopOrder;
import kryzex.modules.macros.h.Each;
import kryzex.modules.macros.h.LastPriceCheck;
import kryzex.modules.macros.h.ListingDelayMs;
import kryzex.modules.macros.h.Order;
import kryzex.modules.macros.h.Thread;
import kryzex.modules.macros.h.MacroAbort;
import kryzex.util.KryzexClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class NothingSellRight {
    private static final int MAX_LISTINGS_PER_PASS = 9;
    private static final long RECOVERY_MS = 3000L;
    private final Order ah;
    private final Thread worker;
    private final ListingDelayMs config;
    private final List<LastPriceCheck> stocks;
    private final int[] inAh = new int[]{0};
    private boolean warnedFull;
    private boolean warnedEmpty;
    private static final String[] a = new String[]{", trying again.", "Selling ", " ($", ", ", "), waiting for sales.", "Nothing to sell right now, waiting for items.", "AH full ("};

    NothingSellRight(AHSell autoBeatCheapest, Thread thread, List<BeatTopOrder> list, boolean bl, ListingDelayMs listingDelayMs, String string) {
        this.ah = new Order(autoBeatCheapest, thread, listingDelayMs, string);
        this.worker = thread;
        this.config = listingDelayMs;
        ArrayList<LastPriceCheck> arrayList = new ArrayList<LastPriceCheck>();
        for (BeatTopOrder beatTopOrder : list) {
            arrayList.add(new LastPriceCheck(beatTopOrder, bl));
        }
        this.stocks = List.copyOf(arrayList);
    }

    void c() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (LastPriceCheck object : this.stocks) {
            Object object2;
            String string = object.product.displayName();
            if (object.fixedPrice) {
                String[] stringArray = a;
                object2 = " ($" + Each.t(object.price) + ")";
            } else {
                object2 = "";
            }
            arrayList.add(string + (String)object2);
        }
        this.ah.C(KryzexClient.body().text("Selling ").name(String.join((CharSequence)", ", arrayList)).text("."));
        try {
            this.ah.gui.k();
            if (this.ah.V(this.stocks)) {
                this.inAh[0] = this.M();
            }
        }
        catch (MacroAbort d32) {
            throw d32;
        }
        catch (RuntimeException runtimeException) {
            this.ah.gui.k();
        }
        while (true) {
            this.worker.n();
            try {
                this.n();
                continue;
            }
            catch (MacroAbort d33) {
                throw d33;
            }
            catch (RuntimeException runtimeException) {
                String string = runtimeException.getMessage() == null ? runtimeException.getClass().getSimpleName() : runtimeException.getMessage();
                this.ah.C(KryzexClient.body().warn(string).text(", trying again."));
                this.worker.n();
                this.ah.gui.k();
                this.worker.p(3000L);
            }
        }
    }

    private void n() {
        if (!this.ah.t()) {
            this.worker.p(2000L);
            return;
        } else {
            this.ah.m();
            boolean bl = false;
            boolean bl2 = false;
            for (LastPriceCheck lastPriceCheck : this.stocks) {
                this.worker.n();
                int n = this.ah.O(lastPriceCheck.product);
                if (n < this.config.perListing() && lastPriceCheck.inAh == 0) continue;
                this.ah.X(lastPriceCheck);
                if (lastPriceCheck.price <= 0L || n < this.config.perListing()) continue;
                bl2 = true;
                this.inAh[0] = this.M();
                int n2 = this.config.maxListings() - this.inAh[0];
                if (n2 <= 0) {
                    if (!this.warnedFull) {
                        this.ah.C(KryzexClient.body().text("AH full (").value(this.inAh[0] + "/" + this.config.maxListings()).text("), waiting for sales."));
                    }
                    this.warnedFull = true;
                    break;
                }
                this.warnedFull = false;
                int n3 = Math.min(Math.min(n / this.config.perListing(), n2), 9);
                if (this.ah.M(lastPriceCheck, n3, this.inAh) <= 0) continue;
                bl = true;
            }
            if (!bl2 && this.M() == 0) {
                if (!this.warnedEmpty) {
                    this.ah.C(KryzexClient.body().text("Nothing to sell right now, waiting for items."));
                }
                this.warnedEmpty = true;
            } else {
                this.warnedEmpty = false;
            }
            if (bl && this.M() < this.config.maxListings() && this.F()) {
                this.worker.p(500L);
                return;
            } else {
                this.ah.v();
                if (!this.ah.V(this.stocks)) return;
                this.inAh[0] = this.M();
            }
        }
    }

    private boolean F() {
        for (LastPriceCheck lastPriceCheck : this.stocks) {
            if (lastPriceCheck.price <= 0L || this.ah.O(lastPriceCheck.product) < this.config.perListing()) continue;
            return true;
        }
        return false;
    }

    private int M() {
        int n = 0;
        for (LastPriceCheck lastPriceCheck : this.stocks) {
            n += lastPriceCheck.inAh;
        }
        return n;
    }

    void a(String string) {
        String string2 = Each.B(string);
        if (string2.isEmpty()) return;
        this.ah.E(string2, this.stocks);
    }

    String P() {
        return Order.g(this.stocks);
    }
}
