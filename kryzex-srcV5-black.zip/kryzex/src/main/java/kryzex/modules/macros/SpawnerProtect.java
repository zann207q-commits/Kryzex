package kryzex.modules.macros;

import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.macros.StashWalk;
import kryzex.modules.macros.SwitchMapNetMinecraftUtilMathDirectionAxis;
import kryzex.util.EnchantmentUtil;
import kryzex.util.SecureString;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2611;
import net.minecraft.class_2636;
import net.minecraft.class_2818;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_742;

public final class SpawnerProtect
extends Module {
    private static final double REACH = 4.3;
    private static final int TARGET_TIMEOUT_TICKS = 400;
    private static final int STUCK_CHECK_TICKS = 60;
    private static final int NO_TARGET_GRACE_TICKS = 30;
    private static final int OFFHAND_SLOT = 40;
    private final NumberSetting detectRange = new NumberSetting(SecureString.of("Detect Range"), 8.0, 128.0, 48.0, 1.0).getValue(SecureString.of("Starts protecting when another player comes within this many blocks"));
    private final NumberSetting emergencyDistance = new NumberSetting(SecureString.of("Emergency Distance"), 0.0, 32.0, 5.0, 1.0).getValue(SecureString.of("Logs out if a player gets this close (0 = off)"));
    private final NumberSetting mineRadius = new NumberSetting(SecureString.of("Mine Radius"), 4.0, 32.0, 12.0, 1.0).getValue(SecureString.of("Spawners within this many blocks of where you stood get collected"));
    private final BoolSetting useEnderChest = new BoolSetting(SecureString.of("Use Ender Chest"), true).setDescription(SecureString.of("Stores the spawners in the ender chest placed next to them"));
    private final NumberSetting stashStacks = new NumberSetting(SecureString.of("Stash After Stacks"), 1.0, 27.0, 4.0, 1.0).getValue(SecureString.of("Stores spawners in the ender chest once you carry this many stacks"));
    private final StringSetting whitelist = new StringSetting(SecureString.of("Whitelist"), "").setDescription(SecureString.of("Player names that won't trigger it, separated by commas"));
    private final BoolSetting chatAlerts = new BoolSetting(SecureString.of("Chat Alerts"), true);
    private final Random random = new Random();
    private final Set<class_2338> skipped = new HashSet<class_2338>();
    private StashWalk state = StashWalk.IDLE;
    private class_2338 origin;
    private class_2338 target;
    private class_2338 chestPos;
    private int targetTicks;
    private int stateTicks;
    private int actionDelay;
    private int noTargetTicks;
    private int nextOpenAttempt;
    private class_243 stuckCheckPos;
    private int stuckTicks;
    private boolean chestFull;
    private boolean stashFailed;
    private boolean warnedNoPickaxe;
    private boolean warnedNoChest;
    private int aimTicks;
    private int stashCooldown;
    private int stashFailures;
    private class_2338 jitterFor;
    private double jitterA;
    private double jitterB;
    private boolean aimActive;
    private boolean aimOvershoot;
    private long aimStart;
    private long aimDuration;
    private float aimStartYaw;
    private float aimStartPitch;
    private float aimEndYaw;
    private float aimEndPitch;
    private float aimFinalYaw;
    private float aimFinalPitch;
    private float aimCurve;
    private float tremorYaw;
    private float tremorPitch;
    private float tremorTargetYaw;
    private float tremorTargetPitch;
    private long nextTremorChange;
    private long lastAimUpdate;
    private int lastMineAge = Integer.MIN_VALUE;
    private static final String[] a = new String[]{"\u00a7c[Spawner Protect] \u00a7fNot holding a silk touch pickaxe", "Player names that won't trigger it, separated by commas", "Spawners within this many blocks of where you stood get collected", "Chat Alerts", " came within ", "Done - ", "Detect Range", " (", " spawner(s) could not be reached", " and stored in the ender chest - logged out", "Starts protecting when another player comes within this many blocks", "Stash After Stacks", " \u00a7fdetected - mining your spawners", " blocks", "Mines and stashes your spawners when a player shows up, and logs out if they get too close", "Mine Radius", "\u00a76[Spawner Protect] \u00a7f", "\u00a7cEnder chest stash failed (", "Whitelist", "\u00a7e", " spawners", ") - trying again in a few seconds", "\u00a7c[Spawner Protect] \u00a7fNo ender chest placed nearby - will mine everything and log out when done", "[Spawner Protect] ", "\u00a7cSkipped spawner at ", "[Spawner Protect] Logged out - ", "Spawner Protect", "All spawners mined", "\u00a7cNot holding a silk touch pickaxe", "Use Ender Chest", "Emergency Distance", "\u00a7cNo ender chest placed nearby", "Logs out if a player gets this close (0 = off)", "Stores spawners in the ender chest once you carry this many stacks", "Stores the spawners in the ender chest placed next to them", " - logged out holding ", "[Spawner Protect] ", ") - keeping spawners in your inventory", "\u00a7cEnder chest stash failed ("};

    public SpawnerProtect() {
        super(SecureString.of("Spawner Protect"), SecureString.of("Mines and stashes your spawners when a player shows up, and logs out if they get too close"), -1, Category.MACROS);
        this.addSettings(new Setting[]{this.detectRange, this.emergencyDistance, this.mineRadius, this.useEnderChest, this.stashStacks, this.whitelist, this.chatAlerts});
    }

    @Override
    public void onEnable() {
        this.v();
        if (this.mc.field_1724 != null && this.s() == -1) {
            this.b();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.v();
        super.onDisable();
    }

    private void v() {
        this.H();
        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
        this.state = StashWalk.IDLE;
        this.skipped.clear();
        this.origin = null;
        this.target = null;
        this.chestPos = null;
        this.targetTicks = 0;
        this.stateTicks = 0;
        this.actionDelay = 0;
        this.noTargetTicks = 0;
        this.nextOpenAttempt = 0;
        this.stuckCheckPos = null;
        this.stuckTicks = 0;
        this.chestFull = false;
        this.stashFailed = false;
        this.warnedNoPickaxe = false;
        this.warnedNoChest = false;
        this.aimTicks = 0;
        this.stashCooldown = 0;
        this.stashFailures = 0;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        double d;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null) return;
        class_742 class_7422 = this.A();
        double d2 = d = class_7422 == null ? Double.MAX_VALUE : Math.sqrt(this.mc.field_1724.method_5858((class_1297)class_7422));
        if (class_7422 != null && this.emergencyDistance.getValue() > 0.0 && d <= this.emergencyDistance.getValue()) {
            this.t(class_7422, d);
            return;
        } else {
            boolean bl = class_7422 != null && d <= this.detectRange.getValue();
            switch (this.state.ordinal()) {
                case 0: {
                    if (!bl) {
                        this.warnedNoPickaxe = false;
                        return;
                    } else if (this.s() == -1) {
                        if (this.warnedNoPickaxe) return;
                        this.b();
                        return;
                    } else {
                        this.l(class_7422);
                    }
                    return;
                }
                case 5: {
                    this.H();
                    if (bl) return;
                    this.state = StashWalk.IDLE;
                    this.warnedNoPickaxe = false;
                    return;
                }
            }
            ++this.stateTicks;
            if (this.actionDelay > 0) {
                --this.actionDelay;
                return;
            } else {
                switch (this.state.ordinal()) {
                    case 1: {
                        this.m();
                        return;
                    }
                    case 2: {
                        this.U();
                        return;
                    }
                    case 3: {
                        this.W();
                        return;
                    }
                    case 4: {
                        this.N();
                    }
                }
            }
        }
    }

    private void l(class_742 class_7422) {
        this.origin = this.mc.field_1724.method_24515();
        this.skipped.clear();
        this.chestFull = false;
        this.stashFailed = false;
        this.stashFailures = 0;
        this.stashCooldown = 0;
        this.warnedNoChest = false;
        this.target = null;
        this.h(StashWalk.MINING);
        this.q("\u00a7e" + class_7422.method_5477().getString() + " \u00a7fdetected - mining your spawners");
        if (!this.useEnderChest.getValue() || this.k() != null) return;
        this.p();
    }

    private void m() {
        this.mc.field_1690.field_1832.method_23481(true);
        if (this.stashCooldown > 0) {
            --this.stashCooldown;
        }
        if (this.Y(false)) {
            this.R();
            return;
        } else {
            if (this.target == null || !this.O(this.target)) {
                this.target = this.V();
                this.targetTicks = 0;
                this.aimTicks = 0;
                this.stuckCheckPos = null;
                this.stuckTicks = 0;
                if (this.target == null) {
                    this.P();
                    if (++this.noTargetTicks < 30) {
                        return;
                    }
                    if (this.Y(true)) {
                        this.R();
                        return;
                    }
                    if (this.stashCooldown > 0 && this.G() && this.E(class_1802.field_8849) > 0) {
                        return;
                    }
                    this.T();
                    return;
                }
            }
            this.noTargetTicks = 0;
            int n = this.s();
            if (n == -1) {
                this.b();
                this.T();
                return;
            } else {
                this.mc.field_1724.method_31548().method_61496(n);
                if (++this.targetTicks > 400) {
                    this.L("took too long");
                    return;
                } else {
                    class_243 class_2432 = class_243.method_24953((class_2382)this.target);
                    if (this.mc.field_1724.method_33571().method_1025(class_2432) <= 18.49) {
                        this.P();
                        boolean bl = this.g(this.e(this.target));
                        class_3965 class_39652 = this.K();
                        if (class_39652 != null && !class_39652.method_17777().equals((Object)this.target) && this.n(class_39652.method_17777())) {
                            this.target = class_39652.method_17777().method_10062();
                        }
                        if (class_39652 != null && class_39652.method_17777().equals((Object)this.target)) {
                            this.aimTicks = 0;
                            this.I(this.target, class_39652.method_17780());
                            return;
                        } else {
                            if (!bl || ++this.aimTicks <= 40) return;
                            this.L("blocked from view");
                        }
                        return;
                    } else {
                        if (this.i(class_2432)) return;
                        this.L("can't walk there");
                    }
                }
            }
        }
    }

    private boolean n(class_2338 class_23382) {
        double d = this.mineRadius.getValue();
        if (!this.O(class_23382)) return false;
        if (this.skipped.contains(class_23382)) return false;
        if (!(class_23382.method_10262((class_2382)this.origin) <= d * d)) return false;
        return true;
    }

    private class_243 e(class_2338 class_23382) {
        if (!class_23382.equals((Object)this.jitterFor)) {
            this.jitterFor = class_23382;
            this.jitterA = (this.random.nextDouble() - 0.5) * 0.5;
            this.jitterB = (this.random.nextDouble() - 0.5) * 0.5;
        }
        class_243 class_2432 = this.mc.field_1724.method_33571();
        class_243 class_2433 = class_243.method_24953((class_2382)class_23382);
        class_2350 class_23502 = class_2350.method_10147((float)((float)(class_2432.field_1352 - class_2433.field_1352)), (float)((float)(class_2432.field_1351 - class_2433.field_1351)), (float)((float)(class_2432.field_1350 - class_2433.field_1350)));
        class_243 class_2434 = class_2433.method_1031((double)class_23502.method_10148() * 0.45, (double)class_23502.method_10164() * 0.45, (double)class_23502.method_10165() * 0.45);
        switch (SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_23502.method_10166().ordinal()]) {
            case 1: {
                class_243 class_2435 = class_2434.method_1031(0.0, this.jitterA, this.jitterB);
                return class_2435;
            }
            case 2: {
                class_243 class_2435 = class_2434.method_1031(this.jitterA, 0.0, this.jitterB);
                return class_2435;
            }
            case 3: {
                class_243 class_2435 = class_2434.method_1031(this.jitterA, this.jitterB, 0.0);
                return class_2435;
            }
            default: {
                throw new MatchException(null, null);
            }
        }
    }

    private class_3965 K() {
        class_239 class_2392 = this.mc.field_1765;
        if (!(class_2392 instanceof class_3965)) return null;
        class_3965 class_39652 = (class_3965)class_2392;
        if (class_39652.method_17783() != class_239.class_240.field_1332) return null;
        class_3965 class_39653 = class_39652;
        return class_39653;
    }

    private class_2338 V() {
        double d = this.mineRadius.getValue() * this.mineRadius.getValue();
        int n = (int)Math.ceil(this.mineRadius.getValue() / 16.0) + 1;
        class_1923 class_19232 = new class_1923(this.origin);
        class_2338 class_23382 = null;
        double d2 = Double.MAX_VALUE;
        for (int i = class_19232.field_9181 - n; i <= class_19232.field_9181 + n; ++i) {
            for (int j = class_19232.field_9180 - n; j <= class_19232.field_9180 + n; ++j) {
                if (!this.mc.field_1687.method_8393(i, j)) continue;
                class_2818 class_28182 = this.mc.field_1687.method_8497(i, j);
                for (class_2586 class_25862 : class_28182.method_12214().values()) {
                    double d3;
                    class_2338 class_23383;
                    if (!(class_25862 instanceof class_2636) || this.skipped.contains(class_23383 = class_25862.method_11016()) || !(class_23383.method_10262((class_2382)this.origin) <= d) || !this.O(class_23383) || !((d3 = this.mc.field_1724.method_33571().method_1025(class_243.method_24953((class_2382)class_23383))) < d2)) continue;
                    d2 = d3;
                    class_23382 = class_23383.method_10062();
                }
            }
        }
        return class_23382;
    }

    private boolean O(class_2338 class_23382) {
        return this.mc.field_1687.method_8320(class_23382).method_27852(class_2246.field_10260);
    }

    private void L(String string) {
        this.q("\u00a7cSkipped spawner at " + this.target.method_23854() + " (" + string + ")");
        this.skipped.add(this.target);
        this.target = null;
        this.mc.field_1761.method_2925();
    }

    private void T() {
        String string;
        String[] stringArray;
        this.H();
        this.mc.field_1761.method_2925();
        if (this.skipped.isEmpty()) {
            stringArray = a;
            string = "All spawners mined";
        } else {
            stringArray = a;
            string = "Done - " + this.skipped.size() + " spawner(s) could not be reached";
        }
        String string2 = string;
        int n = this.E(class_1802.field_8849);
        if (n > 0) {
            stringArray = a;
            string = "[Spawner Protect] " + string2 + " - logged out holding " + n + " spawners";
        } else {
            string = "[Spawner Protect] " + string2 + " and stored in the ender chest - logged out";
        }
        if (this.isEnabled()) {
            this.toggle();
        }
        if (this.mc.method_1562() == null) return;
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)string));
    }

    private void I(class_2338 class_23382, class_2350 class_23502) {
        if (this.mc.field_1724.field_6012 == this.lastMineAge) {
            return;
        }
        this.lastMineAge = this.mc.field_1724.field_6012;
        if (!this.mc.field_1761.method_2902(class_23382, class_23502)) return;
        this.mc.field_1724.method_6104(class_1268.field_5808);
    }

    private boolean i(class_243 class_2432) {
        this.g(class_2432);
        this.mc.field_1690.field_1894.method_23481(true);
        this.mc.field_1690.field_1903.method_23481(this.mc.field_1724.field_5976 && this.mc.field_1724.method_24828());
        if (this.stuckCheckPos == null) {
            this.stuckCheckPos = this.mc.field_1724.method_73189();
            this.stuckTicks = 0;
            return true;
        } else {
            if (++this.stuckTicks < 60) return true;
            boolean bl = this.mc.field_1724.method_73189().method_1025(this.stuckCheckPos) > 0.09;
            this.stuckCheckPos = this.mc.field_1724.method_73189();
            this.stuckTicks = 0;
            if (bl) return true;
            this.P();
            return false;
        }
    }

    private void P() {
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
    }

    private void H() {
        if (this.mc.field_1690 == null) return;
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        if (this.mc.field_1724 == null || this.state == StashWalk.IDLE || this.state == StashWalk.DONE) return;
        this.d(System.nanoTime());
    }

    private boolean g(class_243 class_2432) {
        float[] fArray;
        float f;
        long l = System.nanoTime();
        float f2 = this.aimActive ? this.aimFinalYaw : this.mc.field_1724.method_36454();
        float f3 = SpawnerProtect.M(f2, f = this.aimActive ? this.aimFinalPitch : this.mc.field_1724.method_36455(), (fArray = this.u(class_2432))[0], fArray[1]);
        if (f3 > 6.0f) {
            this.F(fArray[0], fArray[1], l + (long)(60 + this.random.nextInt(100)) * 1000000L, true);
        } else if (f3 > 0.4f) {
            if (this.aimActive) {
                this.aimFinalYaw = this.aimStartYaw + class_3532.method_15393((float)(fArray[0] - this.aimStartYaw));
                this.aimFinalPitch = fArray[1];
                if (!this.aimOvershoot) {
                    this.aimEndYaw = this.aimFinalYaw;
                    this.aimEndPitch = this.aimFinalPitch;
                }
            } else {
                this.F(fArray[0], fArray[1], l, false);
            }
        }
        this.d(l);
        if (this.aimActive) return false;
        if (!(SpawnerProtect.M(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455(), fArray[0], fArray[1]) < 3.0f)) return false;
        return true;
    }

    private void F(float f, float f2, long l, boolean bl) {
        float f3 = this.mc.field_1724.method_36454();
        float f4 = this.mc.field_1724.method_36455();
        float f5 = class_3532.method_15393((float)(f - f3));
        float f6 = f2 - f4;
        float f7 = (float)Math.sqrt(f5 * f5 + f6 * f6);
        this.aimFinalYaw = f3 + f5;
        this.aimFinalPitch = f2;
        this.aimOvershoot = bl && f7 > 20.0f && this.random.nextFloat() < 0.35f;
        float f8 = this.aimOvershoot ? 1.04f + this.random.nextFloat() * 0.06f : 1.0f;
        this.aimStartYaw = f3;
        this.aimStartPitch = f4;
        this.aimEndYaw = f3 + f5 * f8;
        this.aimEndPitch = class_3532.method_15363((float)(f4 + f6 * f8), -90.0f, 90.0f);
        double d = (90.0 + 110.0 * (Math.log(1.0 + (double)f7 / 4.0) / Math.log(2.0))) * (0.85 + this.random.nextDouble() * 0.35);
        this.aimDuration = (long)(d * 1000000.0);
        this.aimCurve = (this.random.nextFloat() - 0.5f) * 0.24f;
        this.aimStart = l;
        this.aimActive = true;
    }

    private void d(long l) {
        if (this.mc.field_1724 != null && this.mc.field_1755 == null) {
            double d = this.lastAimUpdate == 0L ? 0.0 : Math.min(0.1, (double)(l - this.lastAimUpdate) / 1.0E9);
            this.lastAimUpdate = l;
            if (this.aimActive) {
                if (l < this.aimStart) {
                    return;
                }
                if (l - this.aimStart > this.aimDuration + 500000000L) {
                    this.aimActive = false;
                    return;
                }
                double d2 = Math.min(1.0, (double)(l - this.aimStart) / (double)this.aimDuration);
                double d3 = d2 * d2 * d2 * (10.0 - 15.0 * d2 + 6.0 * d2 * d2);
                float f = this.aimEndYaw - this.aimStartYaw;
                float f2 = this.aimEndPitch - this.aimStartPitch;
                double d4 = Math.sqrt(f * f + f2 * f2);
                double d5 = Math.sin(Math.PI * d3) * (double)this.aimCurve * d4;
                double d6 = d4 > 0.001 ? (double)(-f2) / d4 : 0.0;
                double d7 = d4 > 0.001 ? (double)f / d4 : 0.0;
                this.c((float)((double)this.aimStartYaw + (double)f * d3 + d6 * d5), (float)((double)this.aimStartPitch + (double)f2 * d3 + d7 * d5));
                if (!(d2 >= 1.0)) return;
                if (this.aimOvershoot) {
                    this.aimOvershoot = false;
                    this.aimStartYaw = this.mc.field_1724.method_36454();
                    this.aimStartPitch = this.mc.field_1724.method_36455();
                    this.aimEndYaw = this.aimFinalYaw;
                    this.aimEndPitch = this.aimFinalPitch;
                    float f3 = SpawnerProtect.M(this.aimStartYaw, this.aimStartPitch, this.aimEndYaw, this.aimEndPitch);
                    this.aimDuration = (long)((60.0 + (double)this.random.nextInt(60) + (double)f3 * 4.0) * 1000000.0);
                    this.aimCurve = 0.0f;
                    this.aimStart = l + (long)(20 + this.random.nextInt(40)) * 1000000L;
                    return;
                } else {
                    this.aimActive = false;
                }
                return;
            } else {
                if (!(d > 0.0)) return;
                if (l >= this.nextTremorChange) {
                    this.tremorTargetYaw = (this.random.nextFloat() - 0.5f) * 0.6f;
                    this.tremorTargetPitch = (this.random.nextFloat() - 0.5f) * 0.4f;
                    this.nextTremorChange = l + (long)(180 + this.random.nextInt(260)) * 1000000L;
                }
                float f = (float)(1.0 - Math.exp(-d / 0.25));
                float f4 = (this.tremorTargetYaw - this.tremorYaw) * f;
                float f5 = (this.tremorTargetPitch - this.tremorPitch) * f;
                this.tremorYaw += f4;
                this.tremorPitch += f5;
                this.c(this.mc.field_1724.method_36454() + f4, this.mc.field_1724.method_36455() + f5);
            }
            return;
        } else {
            this.lastAimUpdate = l;
        }
    }

    private void c(float f, float f2) {
        double d = f - this.mc.field_1724.method_36454();
        double d2 = f2 - this.mc.field_1724.method_36455();
        if (!(Math.abs(d) > 1.0E-4) && !(Math.abs(d2) > 1.0E-4)) return;
        this.mc.field_1724.method_5872(d / 0.15, d2 / 0.15);
    }

    private float[] u(class_243 class_2432) {
        class_243 class_2433 = this.mc.field_1724.method_33571();
        double d = class_2432.field_1352 - class_2433.field_1352;
        double d2 = class_2432.field_1351 - class_2433.field_1351;
        double d3 = class_2432.field_1350 - class_2433.field_1350;
        float f = (float)Math.toDegrees(Math.atan2(d3, d)) - 90.0f;
        float f2 = (float)(-Math.toDegrees(Math.atan2(d2, Math.sqrt(d * d + d3 * d3))));
        return new float[]{f, class_3532.method_15363((float)f2, -90.0f, 90.0f)};
    }

    private static float M(float f, float f2, float f3, float f4) {
        float f5 = class_3532.method_15393((float)(f3 - f));
        float f6 = f4 - f2;
        return (float)Math.sqrt(f5 * f5 + f6 * f6);
    }

    private boolean G() {
        if (!this.useEnderChest.getValue()) return false;
        if (this.chestFull) return false;
        if (this.stashFailed) return false;
        if (this.k() == null) return false;
        return true;
    }

    private boolean Y(boolean bl) {
        if (!this.useEnderChest.getValue()) return false;
        if (this.chestFull) return false;
        if (this.stashFailed) return false;
        if (this.stashCooldown > 0) return false;
        int n = this.E(class_1802.field_8849);
        if (n == 0) {
            return false;
        }
        if (!bl && n < this.stashStacks.getIntValue() * 64) {
            if (this.mc.field_1724.method_31548().method_7376() != -1) return false;
        }
        boolean bl2 = true;
        boolean bl3 = bl2;
        if (!bl3) {
            return false;
        }
        if (this.k() != null) return true;
        if (this.warnedNoChest) return false;
        this.p();
        return false;
    }

    private class_2338 k() {
        double d = Math.max(8.0, this.mineRadius.getValue());
        double d2 = d * d;
        int n = (int)Math.ceil(d / 16.0) + 1;
        class_2338 class_23382 = this.origin != null ? this.origin : this.mc.field_1724.method_24515();
        class_1923 class_19232 = new class_1923(class_23382);
        class_2338 class_23383 = null;
        double d3 = Double.MAX_VALUE;
        for (int i = class_19232.field_9181 - n; i <= class_19232.field_9181 + n; ++i) {
            for (int j = class_19232.field_9180 - n; j <= class_19232.field_9180 + n; ++j) {
                if (!this.mc.field_1687.method_8393(i, j)) continue;
                for (class_2586 class_25862 : this.mc.field_1687.method_8497(i, j).method_12214().values()) {
                    double d4;
                    class_2338 class_23384;
                    if (!(class_25862 instanceof class_2611) || !((class_23384 = class_25862.method_11016()).method_10262((class_2382)class_23382) <= d2) || !this.mc.field_1687.method_8320(class_23384).method_27852(class_2246.field_10443) || !((d4 = this.mc.field_1724.method_33571().method_1025(class_243.method_24953((class_2382)class_23384))) < d3)) continue;
                    d3 = d4;
                    class_23383 = class_23384.method_10062();
                }
            }
        }
        return class_23383;
    }

    private void R() {
        this.P();
        this.mc.field_1761.method_2925();
        this.chestPos = this.k();
        this.stuckCheckPos = null;
        this.stuckTicks = 0;
        this.h(StashWalk.STASH_WALK);
    }

    private void Q(String string) {
        if (this.mc.field_1724.field_7512 instanceof class_1707) {
            this.mc.field_1724.method_7346();
        }
        if (++this.stashFailures >= 3) {
            String[] stringArray = a;
            this.q("\u00a7cEnder chest stash failed (" + string + ") - keeping spawners in your inventory");
            this.stashFailed = true;
        } else {
            this.q("\u00a7cEnder chest stash failed (" + string + ") - trying again in a few seconds");
            this.stashCooldown = 100;
        }
        this.chestPos = null;
        this.P();
        this.h(StashWalk.MINING);
    }

    private void U() {
        this.mc.field_1690.field_1832.method_23481(true);
        if (this.chestPos != null && this.mc.field_1687.method_8320(this.chestPos).method_27852(class_2246.field_10443)) {
            class_243 class_2432 = class_243.method_24953((class_2382)this.chestPos);
            if (this.mc.field_1724.method_33571().method_1025(class_2432) <= 18.49) {
                this.P();
                this.h(StashWalk.STASH_OPEN);
                return;
            } else {
                if (this.stateTicks <= 400 && this.i(class_2432)) return;
                this.Q("could not walk to the ender chest");
            }
            return;
        } else {
            this.Q("the ender chest is gone");
        }
    }

    private void W() {
        this.mc.field_1690.field_1832.method_23481(false);
        if (this.mc.field_1724.field_7512 instanceof class_1707) {
            this.h(StashWalk.STASH_DEPOSIT);
            this.actionDelay = 3;
            return;
        } else if (this.chestPos == null || !this.mc.field_1687.method_8320(this.chestPos).method_27852(class_2246.field_10443)) {
            this.Q("the ender chest is gone");
            return;
        } else {
            if (this.mc.field_1724.method_5715()) return;
            if (this.stateTicks > 60) {
                this.Q("could not open the ender chest");
                return;
            } else {
                boolean bl = this.g(class_243.method_24953((class_2382)this.chestPos));
                class_3965 class_39652 = this.K();
                if (!bl || class_39652 == null || !class_39652.method_17777().equals((Object)this.chestPos) || this.stateTicks < this.nextOpenAttempt) return;
                this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, class_39652);
                this.mc.field_1724.method_6104(class_1268.field_5808);
                this.nextOpenAttempt = this.stateTicks + 20;
            }
        }
    }

    private void N() {
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            this.h(StashWalk.MINING);
            return;
        } else {
            int n;
            class_1707 class_17072 = (class_1707)class_17032;
            for (int i = n = class_17072.method_17388() * 9; i < class_17072.field_7761.size(); ++i) {
                class_1799 class_17992 = class_17072.method_7611(i).method_7677();
                if (!class_17992.method_31574(class_1802.field_8849)) continue;
                if (this.D(class_17072, n, class_17992)) {
                    this.mc.field_1761.method_2906(class_17072.field_7763, i, 0, class_1713.field_7794, (class_1657)this.mc.field_1724);
                    this.actionDelay = 2 + this.random.nextInt(2);
                    return;
                }
                this.chestFull = true;
                this.q("\u00a7eEnder chest is full, keeping the rest in your inventory");
                break;
            }
            this.mc.field_1724.method_7346();
            this.q("\u00a7aStored spawners in the ender chest");
            this.chestPos = null;
            this.h(StashWalk.MINING);
            this.actionDelay = 2;
        }
    }

    private boolean D(class_1707 class_17072, int n, class_1799 class_17992) {
        for (int i = 0; i < n; ++i) {
            class_1799 class_17993 = class_17072.method_7611(i).method_7677();
            if (!class_17993.method_7960() && (!class_1799.method_31577((class_1799)class_17993, (class_1799)class_17992) || class_17993.method_7947() >= class_17993.method_7914())) continue;
            return true;
        }
        return false;
    }

    private class_742 A() {
        HashSet<String> hashSet = new HashSet<String>();
        for (Object object : this.whitelist.getValue().split(",")) {
            if (((String)object).isBlank()) continue;
            hashSet.add(((String)object).trim().toLowerCase(Locale.ROOT));
        }
        class_742 class_7422 = null;
        double d = Double.MAX_VALUE;
        for (class_742 class_7423 : this.mc.field_1687.method_18456()) {
            double d2;
            if (class_7423 == this.mc.field_1724 || class_7423.method_7325() || !SpawnerProtect.o(class_7423.method_5667()) || hashSet.contains(class_7423.method_5477().getString().toLowerCase(Locale.ROOT)) || !((d2 = this.mc.field_1724.method_5858((class_1297)class_7423)) < d)) continue;
            d = d2;
            class_7422 = class_7423;
        }
        return class_7422;
    }

    private static boolean o(UUID uUID) {
        if (uUID.version() != 4) return false;
        return true;
    }

    private void t(class_742 class_7422, double d) {
        String string = class_7422.method_5477().getString();
        this.v();
        if (this.mc.method_1562() == null) return;
        long l = Math.round(d);
        String string2 = string;
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("[Spawner Protect] Logged out - " + string2 + " came within " + l + " blocks")));
    }

    private int s() {
        class_1661 class_16612 = this.mc.field_1724.method_31548();
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (!class_17992.method_31573(class_3489.field_42614) || !EnchantmentUtil.hasEnchantment(class_17992, class_1893.field_9099)) continue;
            return i;
        }
        return -1;
    }

    private int E(class_1792 class_17922) {
        int n = 0;
        class_1661 class_16612 = this.mc.field_1724.method_31548();
        for (int i = 0; i < 36; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (!class_17992.method_31574(class_17922)) continue;
            n += class_17992.method_7947();
        }
        return n;
    }

    private void b() {
        this.warnedNoPickaxe = true;
        this.mc.field_1724.method_5783((class_3414)class_3417.field_14624.comp_349(), 1.0f, 0.5f);
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7c[Spawner Protect] \u00a7fNot holding a silk touch pickaxe"), false);
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7cNot holding a silk touch pickaxe"), true);
    }

    private void p() {
        this.warnedNoChest = true;
        this.mc.field_1724.method_5783((class_3414)class_3417.field_14624.comp_349(), 1.0f, 0.5f);
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7c[Spawner Protect] \u00a7fNo ender chest placed nearby - will mine everything and log out when done"), false);
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7cNo ender chest placed nearby"), true);
    }

    private void q(String string) {
        if (!this.chatAlerts.getValue() || this.mc.field_1724 == null) return;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a76[Spawner Protect] \u00a7f" + string)), false);
    }

    private void h(StashWalk stashWalk) {
        this.state = stashWalk;
        this.stateTicks = 0;
        this.nextOpenAttempt = 0;
    }
}
