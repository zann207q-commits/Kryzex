package kryzex.modules.combat;

import kryzex.event.AttackEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.util.ArmorUtil;
import kryzex.util.HotbarUtil;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_3489;
import net.minecraft.class_5321;

public final class SpearSwap
extends Module {
    private static String[] a;
    private static class_1792[] SPEARS;
    private final BoolSetting lunge = new BoolSetting("Lunge", true);
    private final BoolSetting sharpness = new BoolSetting("Sharpness", false);
    private final BoolSetting onlySword = new BoolSetting("Only Sword", false);
    private final BoolSetting onlyAxe = new BoolSetting("Only Axe", false);
    private final BoolSetting switchBack = new BoolSetting("Switch Back", true);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 20.0, 1.0, 1.0);
    private boolean restoring;
    private int previousSlot = -1;
    private int restoreTicks;

    public SpearSwap() {
        super("Spear Swap", "Switches to a preferred spear when attacking.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.lunge, this.sharpness, this.onlySword, this.onlyAxe, this.switchBack, this.switchDelay});
        SettingGroup.set(this.switchDelay, this.switchBack::getValue);
    }

    @Override
    public void onEnable() {
        this.w();
    }

    private void w() {
        this.previousSlot = -1;
        this.restoreTicks = 0;
        this.restoring = false;
    }

    private boolean m() {
        for (class_1792 class_17922 : SPEARS) {
            if (!this.mc.field_1724.method_6047().method_31574(class_17922)) continue;
            return true;
        }
        return false;
    }

    @Override
    public void onDisable() {
        this.w();
    }

    @Subscribe
    public void onAttack(AttackEvent attackEvent) {
        boolean bl;
        if (this.mc.field_1724 == null || this.m()) {
            return;
        }
        class_1799 class_17992 = this.mc.field_1724.method_6047();
        boolean bl2 = class_17992.method_31573(class_3489.field_42611);
        boolean bl3 = class_17992.method_31573(class_3489.field_42612);
        if (this.onlySword.getValue() && this.onlyAxe.getValue() ? !bl2 && !bl3 : this.onlySword.getValue() && !bl2 || this.onlyAxe.getValue() && !bl3) {
            return;
        }
        if (this.previousSlot == -1) {
            this.previousSlot = this.mc.field_1724.method_31548().method_67532();
        }
        boolean bl4 = bl = this.lunge.getValue() && this.W((class_5321<class_1887>)class_1893.field_63420);
        if (!bl && this.sharpness.getValue()) {
            bl = this.W((class_5321<class_1887>)class_1893.field_9118);
        }
        if (!bl) {
            for (class_1792 class_17922 : SPEARS) {
                if (HotbarUtil.selectHotbarItem(class_17922)) break;
            }
        }
        this.restoring = this.m();
        if (this.restoring) return;
        this.w();
    }

    private boolean W(class_5321<class_1887> class_53212) {
        return HotbarUtil.selectMatchingStack(new Object[]{(java.util.function.Predicate<net.minecraft.class_1799>)(arg_0 -> SpearSwap.lmbd$selectEnchanted$0(class_53212, arg_0)), 0L});
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null) {
            this.w();
            return;
        }
        if (this.mc.field_1755 != null || !this.restoring) {
            return;
        }
        if (this.switchBack.getValue()) {
            if (this.restoreTicks < this.switchDelay.getIntValue()) {
                ++this.restoreTicks;
                return;
            }
            HotbarUtil.selectHotbarSlot(this.previousSlot);
        }
        this.w();
    }

    private static boolean lmbd$selectEnchanted$0(class_5321 class_53212, class_1799 class_17992) {
        boolean bl = false;
        for (class_1792 class_17922 : SPEARS) {
            if (!class_17992.method_31574(class_17922)) continue;
            bl = true;
            break;
        }
        if (!bl) return false;
        if (!ArmorUtil.hasEnchantment(class_17992, (class_5321<class_1887>)class_53212)) return false;
        return true;
    }

    static {
        a = new String[]{"Only Sword", "Switch Delay", "Spear Swap", "Switches to a preferred spear when attacking.", "Sharpness", "Switch Back", "Lunge", "Only Axe"};
        SPEARS = new class_1792[]{class_1802.field_63390, class_1802.field_63389, class_1802.field_63387, class_1802.field_63388, class_1802.field_63386, class_1802.field_63385, class_1802.field_63384};
    }
}
