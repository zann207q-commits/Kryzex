package kryzex.modules.combat;

import kryzex.event.AttackEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.util.ArmorUtil;
import kryzex.util.HotbarUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_3489;
import net.minecraft.class_5321;

public final class MaceSwap
extends Module {
    private static String[] a;
    private final BoolSetting windBurst = new BoolSetting("Wind Burst", true);
    private final BoolSetting breach = new BoolSetting("Breach", true);
    private final BoolSetting onlySword = new BoolSetting("Only Sword", false);
    private final BoolSetting onlyAxe = new BoolSetting("Only Axe", false);
    private final BoolSetting switchBack = new BoolSetting("Switch Back", true);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 20.0, 0.0, 1.0);
    private boolean restoring;
    private int previousSlot = -1;
    private int restoreTicks;

    public MaceSwap() {
        super("Mace Swap", "Switches to a mace when attacking.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.windBurst, this.breach, this.onlySword, this.onlyAxe, this.switchBack, this.switchDelay});
        SettingGroup.set(this.switchDelay, this.switchBack::getValue);
    }

    @Override
    public void onEnable() {
        this.g();
    }

    private void g() {
        this.previousSlot = -1;
        this.restoreTicks = 0;
        this.restoring = false;
    }

    @Override
    public void onDisable() {
        this.g();
    }

    @Subscribe
    public void onAttack(AttackEvent attackEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1755 != null || this.mc.field_1724.method_6047().method_31574(class_1802.field_49814)) {
            return;
        }
        class_1799 class_17992 = this.mc.field_1724.method_6047();
        boolean bl = class_17992.method_31573(class_3489.field_42611);
        boolean bl2 = class_17992.method_31573(class_3489.field_42612);
        if (this.onlySword.getValue() && this.onlyAxe.getValue() ? !bl && !bl2 : this.onlySword.getValue() && !bl || this.onlyAxe.getValue() && !bl2) {
            return;
        }
        if (this.previousSlot == -1) {
            this.previousSlot = this.mc.field_1724.method_31548().method_67532();
        }
        if (this.windBurst.getValue() == this.breach.getValue()) {
            HotbarUtil.selectHotbarItem(class_1802.field_49814);
        } else if (this.windBurst.getValue()) {
            HotbarUtil.selectMatchingStack(new Object[]{(java.util.function.Predicate<net.minecraft.class_1799>)(MaceSwap::lmbd$onAttack$0), 0L});
        } else {
            HotbarUtil.selectMatchingStack(new Object[]{(java.util.function.Predicate<net.minecraft.class_1799>)(MaceSwap::lmbd$onAttack$1), 0L});
        }
        this.restoring = this.mc.field_1724.method_6047().method_31574(class_1802.field_49814);
        if (this.restoring) return;
        this.g();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null) {
            this.g();
            return;
        }
        if (this.mc.field_1755 != null || !this.restoring) {
            return;
        }
        if (this.switchBack.getValue()) {
            if (this.restoreTicks < this.switchDelay.getIntValue()) {
                ++this.restoreTicks;
                return;
            }
            HotbarUtil.selectHotbarSlot(this.previousSlot);
        }
        this.g();
    }

    private static boolean lmbd$onAttack$1(class_1799 class_17992) {
        if (!class_17992.method_31574(class_1802.field_49814)) return false;
        if (!ArmorUtil.hasEnchantment(class_17992, (class_5321<class_1887>)class_1893.field_50158)) return false;
        return true;
    }

    private static boolean lmbd$onAttack$0(class_1799 class_17992) {
        if (!class_17992.method_31574(class_1802.field_49814)) return false;
        if (!ArmorUtil.hasEnchantment(class_17992, (class_5321<class_1887>)class_1893.field_50159)) return false;
        return true;
    }

    static {
        a = new String[]{"Switch Delay", "Switch Back", "Switches to a mace when attacking.", "Mace Swap", "Only Axe", "Only Sword", "Breach", "Wind Burst"};
    }
}
