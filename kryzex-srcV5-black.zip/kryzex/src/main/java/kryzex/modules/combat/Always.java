package kryzex.modules.combat;

public enum Always {
    ALWAYS("Always"),
    ON_POP("On Pop");

    private final String label;

    private Always(String string2) {
        this.label = string2;
    }

    public String toString() {
        return this.label;
    }
}
