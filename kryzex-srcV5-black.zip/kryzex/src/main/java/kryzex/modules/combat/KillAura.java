package kryzex.modules.combat;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import kryzex.client.KryzexClient;
import kryzex.event.AttackEvent;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.modules.combat.TargetPriority;
import kryzex.modules.misc.Values;
import kryzex.util.FriendUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3959;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_6862;
import net.minecraft.class_746;

public class KillAura
extends Values {
    private static volatile KillAura instance;
    private static long time;
    private static long time2;
    private static long time3;
    private final Random random;
    private long time4;
    private boolean flag;
    private class_1309 livingEntity;
    private final double[] doubleArray;
    private final double[] doubleArray2;
    private final double[] doubleArray3;
    private long time5;
    private long time6;
    private float factor;
    private float factor2;
    private double amount;
    private double amount2;
    private long time7;
    private final double[] doubleArray4;
    private volatile class_1309 livingEntity2;
    private boolean flag2;
    private long time8;
    private long nextTargetCheck;
    private class_638 selectedWorld;
    private class_1309 cachedTarget;
    private static String[] a;
    private static int xaikG63x;

    public KillAura() {
        super("Kill Aura", Category.COMBAT, "Automatically aims and attacks eligible nearby players.");
        Random random;
        this.O();
        this.random = random = new Random();
        this.time4 = -1L;
        this.flag = false;
        this.livingEntity = null;
        double[] dArray = new double[]{0.5, 0.65, 0.5};
        this.doubleArray = dArray;
        double[] dArray2 = new double[]{0.5, 0.65, 0.5};
        this.doubleArray2 = dArray2;
        double[] dArray3 = new double[]{0.0, 0.0, 0.0};
        this.doubleArray3 = dArray3;
        this.time5 = 0L;
        this.time6 = -1L;
        this.factor = 0.0f;
        this.factor2 = 0.0f;
        this.amount = 1.0;
        this.amount2 = 1.0;
        this.time7 = 0L;
        double[] dArray4 = new double[24];
        this.doubleArray4 = dArray4;
        this.livingEntity2 = null;
        this.flag2 = false;
        this.time8 = -1L;
        instance = this;
        int n = 0;
        int n2;
        int n3;
        while ((n3 = n) < (n2 = this.doubleArray4.length)) {
            double d;
            double[] dArray5 = this.doubleArray4;
            int n4 = n++;
            double d2 = this.random.nextDouble();
            double d3 = d2 * Math.PI;
            dArray5[n4] = d = d3 * 2.0;
        }
        return;
    }

    public static boolean L() {
        boolean bl;
        KillAura maxTurnSpeed = instance;
        return maxTurnSpeed != null && (bl = maxTurnSpeed.isEnabled());
    }

    public static class_1309 G() {
        KillAura maxTurnSpeed = instance;
        if (maxTurnSpeed != null) return maxTurnSpeed.livingEntity2;
        return null;
    }

    @Override
    public void onEnable() {
        this.time4 = -1L;
        this.flag = false;
        this.livingEntity = null;
        this.livingEntity2 = null;
        this.factor2 = 0.0f;
        this.factor = 0.0f;
        this.l();
    }

    @Override
    public void onDisable() {
        this.livingEntity2 = null;
        this.livingEntity = null;
        this.flag = false;
        this.factor2 = 0.0f;
        this.factor = 0.0f;
        this.l();
    }

    private void w() {
        long l;
        long l2;
        class_310 class_3102 = class_310.method_1551();
        long l3 = System.currentTimeMillis();
        long l4 = this.time4;
        if (l4 < 0L) {
            l2 = 1L;
        } else {
            l = this.time4;
            long l5 = l3 - l;
            l2 = Math.min(l5, 100L);
        }
        l = l2;
        this.time4 = l3;
        if (class_3102.field_1724 != null && class_3102.field_1687 != null) {
            boolean bl;
            float f;
            float f2;
            float f3;
            float f4;
            block33: {
                float f5;
                float f6;
                float f7;
                float f8;
                float f9;
                float f10;
                float f11;
                float f12;
                float f13;
                float f14;
                class_243 class_2432;
                long l6;
                class_1309 class_13092;
                boolean bl2 = this.isEnabled();
                if (!bl2) {
                    this.livingEntity2 = null;
                    this.livingEntity = null;
                    boolean bl3 = this.flag;
                    if (!bl3) return;
                    this.e(class_3102, l);
                    return;
                }
                boolean bl4 = this.P(class_3102);
                if (!bl4) {
                    this.livingEntity2 = null;
                    this.livingEntity = null;
                    boolean bl5 = this.flag;
                    if (!bl5) return;
                    this.e(class_3102, l);
                    return;
                }
                this.livingEntity2 = class_13092 = this.f(class_3102);
                if (class_13092 == null) {
                    this.livingEntity = null;
                    boolean bl6 = this.flag;
                    if (!bl6) return;
                    this.e(class_3102, l);
                    return;
                }
                Boolean bl7 = true;
                String[] stringArray = a;
                boolean bl8 = this.getSetting("Humanize", bl7);
                String string = this.getSetting("Aim At", "Dynamic");
                long l7 = Math.min(l, 50L);
                double d = l7;
                double d2 = d / 1000.0;
                long l8 = System.nanoTime();
                double d3 = l8;
                double d4 = d3 / 1.0E9;
                class_1309 class_13093 = this.livingEntity;
                if (class_13092 != class_13093) {
                    long l9;
                    boolean bl9;
                    boolean bl10 = this.livingEntity != null && (bl9 = this.flag);
                    bl9 = bl10;
                    this.livingEntity = class_13092;
                    this.I(string);
                    stringArray = a;
                    long l10 = this.V("Point Change", 500, 1400);
                    this.time5 = l9 = l3 + l10;
                    if (bl8) {
                        long l11;
                        long l12 = this.V("Reaction Delay", 60, 180);
                        long l13 = bl9 ? l12 / 2L : l12;
                        this.time6 = l11 = l3 + l13;
                    } else {
                        this.time6 = -1L;
                    }
                    if (!bl9) {
                        this.factor = 0.0f;
                        this.factor2 = 0.0f;
                    }
                }
                if (bl8 && l3 < (l6 = this.time6)) {
                    boolean bl11 = this.flag;
                    if (!bl11) return;
                    float f15 = TargetPriority.X();
                    float f16 = TargetPriority.D();
                    TargetPriority.j(f15, f16);
                    return;
                }
                class_2432 = class_3102.field_1724.method_33571();
                class_243 class_2433 = bl8 ? this.N(class_13092, class_2432, string, l3, d2, d4) : this.X(class_13092, class_2432);
                class_243 class_2434 = class_2433.method_1020(class_2432);
                double d5 = class_2434.method_1027();
                if (d5 < 1.0E-6) return;
                double d6 = class_2434.field_1352;
                double d7 = class_2434.field_1352;
                double d8 = d6 * d7;
                double d9 = class_2434.field_1350;
                double d10 = class_2434.field_1350;
                double d11 = d9 * d10;
                double d12 = d8 + d11;
                double d13 = Math.sqrt(d12);
                boolean bl12 = this.flag;
                if (bl12) {
                    f14 = TargetPriority.X();
                    f12 = f13 = TargetPriority.D();
                } else {
                    f14 = class_3102.field_1724.method_36454();
                    f12 = f13 = class_3102.field_1724.method_36455();
                }
                Float f17 = Float.valueOf(90.0f);
                stringArray = a;
                f13 = this.getSetting("Max Pitch", f17).floatValue();
                if (d13 < 0.05) {
                    f11 = f14;
                } else {
                    double d14 = class_2434.field_1352;
                    double d15 = d14 * -1.0;
                    double d16 = class_2434.field_1350;
                    double d17 = Math.atan2(d15, d16);
                    double d18 = d17 * 180.0;
                    double d19 = d18 / Math.PI;
                    f11 = (float)d19;
                }
                float f18 = f11;
                double d20 = class_2434.field_1351;
                double d21 = Math.max(d13, 1.0E-4);
                double d22 = Math.atan2(d20, d21);
                double d23 = d22 * -1.0;
                double d24 = d23 * 180.0;
                double d25 = d24 / Math.PI;
                float f19 = (float)d25;
                float f20 = f13 * -1.0f;
                float f21 = Math.min(f13, f19);
                float f22 = f10 = (f9 = Math.max(f20, f21));
                boolean bl13 = Float.isFinite(f22);
                if (!bl13) return;
                Integer n = 15;
                stringArray = a;
                int n2 = this.getSetting("Horizontal Speed", n);
                Integer n3 = 15;
                int n4 = this.getSetting("Vertical Speed", n3);
                Boolean bl14 = true;
                boolean bl15 = this.getSetting("Aim Horizontally", bl14);
                Boolean bl16 = true;
                boolean bl17 = this.getSetting("Aim Vertically", bl16);
                if (bl8) {
                    double d26;
                    double d27;
                    double d28;
                    double d29;
                    double d30;
                    double d31;
                    double d32;
                    double d33;
                    double d34;
                    double d35;
                    double d36;
                    float f23;
                    float f24;
                    Integer n5 = 30;
                    int n6 = this.getSetting("Jitter", n5);
                    f4 = n6;
                    f3 = f4 / 100.0f;
                    f8 = f3 * 0.8f;
                    f7 = f18;
                    double d37 = this.W(d4, 0);
                    double d38 = f8;
                    double d39 = d37 * d38;
                    float f25 = (float)d39;
                    f18 = f24 = f7 + f25;
                    float f26 = f10;
                    double d40 = this.W(d4, 1);
                    double d41 = f8;
                    double d42 = d40 * d41;
                    double d43 = d42 * (double)0.6f;
                    float f27 = (float)d43;
                    f10 = f23 = f26 + f27;
                    Integer n7 = 30;
                    int n8 = this.getSetting("Speed Variation", n7);
                    long l14 = this.time7;
                    if (l3 >= l14) {
                        double d44;
                        long l15;
                        long l16 = l3 + 250L;
                        float f28 = this.random.nextFloat();
                        float f29 = f28 * 700.0f;
                        long l17 = (long)f29;
                        this.time7 = l15 = l16 + l17;
                        d36 = this.random.nextDouble();
                        d35 = d36 * 2.0;
                        d34 = d35 - 1.0;
                        d33 = n8;
                        double d45 = d33 / 100.0;
                        double d46 = d34 * d45;
                        double d47 = d46 * 0.5;
                        this.amount2 = d44 = 1.0 + d47;
                    }
                    double d48 = this.amount;
                    double d49 = this.amount2;
                    double d50 = this.amount;
                    double d51 = d49 - d50;
                    d36 = d2 * 3.0;
                    d35 = Math.min(1.0, d36);
                    d34 = d51 * d35;
                    this.amount = d33 = d48 + d34;
                    float f30 = f18;
                    float f31 = f14;
                    float f32 = f30 - f31;
                    float f33 = KillAura.g(f32);
                    float f34 = f10;
                    float f35 = f12;
                    float f36 = f34 - f35;
                    double d52 = f33;
                    double d53 = f33;
                    double d54 = d52 * d53;
                    double d55 = f36;
                    double d56 = f36;
                    double d57 = d55 * d56;
                    double d58 = d54 + d57;
                    double d59 = Math.sqrt(d58);
                    Integer n9 = 25;
                    int n10 = this.getSetting("Overshoot", n9);
                    double d60 = n10;
                    double d61 = d60 / 100.0;
                    double d62 = d61 * 0.45;
                    double d63 = d32 = 1.0 - d62;
                    if (d59 < 1.5) {
                        d63 = 1.0;
                    } else if (d59 > 35.0) {
                        double d64 = d63;
                        d31 = d64 - 0.08;
                        d63 = d30 = Math.max(0.5, d31);
                    }
                    Integer n11 = 800;
                    int n12 = this.getSetting("Max Turn Speed", n11);
                    d31 = n12;
                    d30 = d4 * 0.35;
                    double d65 = this.W(d30, 2);
                    double d66 = Math.abs(d65);
                    double d67 = 0.3 * d66;
                    double d68 = 0.85 + d67;
                    double d69 = d31 * d68;
                    double d70 = n2;
                    double d71 = d70 * 1.1;
                    double d72 = this.amount;
                    double d73 = d71 * d72;
                    double d74 = n4;
                    double d75 = d74 * 1.1;
                    double d76 = this.amount;
                    double d77 = d75 * d76;
                    double d78 = d2 / 0.008;
                    double d79 = Math.ceil(d78);
                    int n13 = (int)d79;
                    int n14 = Math.max(1, n13);
                    double d80 = n14;
                    double d81 = d2 / d80;
                    double d82 = d29 = (double)f33;
                    double d83 = d28 = (double)f36;
                    float f37 = this.factor;
                    double d84 = d27 = (double)f37;
                    float f38 = this.factor2;
                    double d85 = d26 = (double)f38;
                    double d86 = d69 * -1.0;
                    int n15 = 0;
                    while (true) {
                        double d87;
                        double d88;
                        double d89;
                        double d90;
                        double d91;
                        double d92;
                        double d93;
                        double d94;
                        double d95;
                        double d96;
                        double d97;
                        double d98;
                        double d99;
                        double d100;
                        double d101;
                        double d102;
                        double d103;
                        double d104;
                        int n16;
                        if ((n16 = ++n15) >= n14) {
                            float f39;
                            float f40;
                            float f41;
                            float f42;
                            d104 = d84;
                            this.factor = f42 = (float)d104;
                            double d105 = d85;
                            this.factor2 = f41 = (float)d105;
                            if (bl15) {
                                f40 = f18;
                                d103 = f40;
                                d102 = d82;
                                d101 = d103 - d102;
                                f39 = (float)d101;
                            } else {
                                f39 = f14;
                            }
                            f2 = f39;
                            if (bl17) {
                                float f43 = f10;
                                double d106 = f43;
                                double d107 = d83;
                                double d108 = d106 - d107;
                                f40 = (float)d108;
                            } else {
                                f40 = f12;
                            }
                            f = f40;
                            break block33;
                        }
                        if (bl15) {
                            d104 = d84;
                            d100 = d73 * d73;
                            d99 = d82;
                            d98 = d100 * d99;
                            d103 = d63;
                            d102 = 2.0 * d103;
                            d101 = d102 * d73;
                            d97 = d84;
                            d96 = d101 * d97;
                            d95 = d98 - d96;
                            d94 = d95 * d81;
                            d93 = d104 + d94;
                            d92 = Math.min(d69, d93);
                            d84 = d91 = Math.max(d86, d92);
                            d90 = d82;
                            d89 = d84;
                            d88 = d89 * d81;
                            d82 = d87 = d90 - d88;
                        } else {
                            d84 = 0.0;
                        }
                        if (bl17) {
                            d104 = d85;
                            d100 = d77 * d77;
                            d99 = d83;
                            d98 = d100 * d99;
                            d103 = d63;
                            d102 = 2.0 * d103;
                            d101 = d102 * d77;
                            d97 = d85;
                            d96 = d101 * d97;
                            d95 = d98 - d96;
                            d94 = d95 * d81;
                            d93 = d104 + d94;
                            d92 = Math.min(d69, d93);
                            d85 = d91 = Math.max(d86, d92);
                            d90 = d83;
                            d89 = d85;
                            d88 = d89 * d81;
                            d83 = d87 = d90 - d88;
                            continue;
                        }
                        d85 = 0.0;
                    }
                }
                float f44 = f18;
                float f45 = f14;
                f4 = f44 - f45;
                f3 = KillAura.g(f4);
                f8 = f10;
                f7 = f12;
                float f46 = f8 - f7;
                float f47 = KillAura.g(f46);
                float f48 = n2;
                float f49 = f48 / 20.0f;
                float f50 = f3 * f49;
                float f51 = l;
                float f52 = f51 / 50.0f;
                float f53 = f50 * f52;
                float f54 = Math.abs(f3);
                float f55 = KillAura.Z(f53, f54);
                float f56 = n4;
                float f57 = f56 / 20.0f;
                float f58 = f47 * f57;
                float f59 = l;
                float f60 = f59 / 50.0f;
                float f61 = f58 * f60;
                float f62 = Math.abs(f47);
                float f63 = KillAura.Z(f61, f62);
                if (bl15) {
                    f6 = f14;
                    f5 = f6 + f55;
                } else {
                    f5 = f14;
                }
                f2 = f5;
                if (bl17) {
                    float f64 = f12;
                    f6 = f64 + f63;
                } else {
                    f6 = f12;
                }
                f = f6;
            }
            float f65 = f;
            float f66 = Math.min(90.0f, f65);
            f4 = Math.max(-90.0f, f66);
            f3 = f2;
            boolean bl18 = Float.isFinite(f3);
            if (!bl18 || !(bl = Float.isFinite(f4))) return;
            float f67 = f2;
            TargetPriority.j(f67, f4);
            this.flag = true;
            return;
        }
        this.flag = false;
        this.livingEntity2 = null;
    }

    private long V(String string, int n, int n2) {
        Integer n3;
        String string2 = string + "_lo";
        Integer n4 = n;
        int n5 = this.getSetting(string2, n4);
        String string3 = string + "_hi";
        int n6 = this.getSetting(string3, n3 = Integer.valueOf(n2));
        if (n6 <= n5) {
            int n7 = Math.max(0, n5);
            return n7;
        }
        long l = n5;
        float f = this.random.nextFloat();
        int n8 = n6 - n5;
        float f2 = n8;
        float f3 = f * f2;
        long l2 = (long)f3;
        return l + l2;
    }

    private double W(double d, int n) {
        int n2 = n * 3;
        int n3 = this.doubleArray4.length;
        int n4 = n3 - 2;
        int n5 = n2 % n4;
        double d2 = 1.7 * d;
        double d3 = this.doubleArray4[n5];
        double d4 = d2 + d3;
        double d5 = Math.sin(d4);
        double d6 = 0.5 * d5;
        double d7 = 3.1 * d;
        double[] dArray = this.doubleArray4;
        int n6 = n5 + 1;
        double d8 = dArray[n6];
        double d9 = d7 + d8;
        double d10 = Math.sin(d9);
        double d11 = 0.3 * d10;
        double d12 = d6 + d11;
        double d13 = 7.3 * d;
        double[] dArray2 = this.doubleArray4;
        int n7 = n5 + 2;
        double d14 = dArray2[n7];
        double d15 = d13 + d14;
        double d16 = Math.sin(d15);
        double d17 = 0.2 * d16;
        return d12 + d17;
    }

    private static double d(double d, double d2, double d3) {
        double d4 = Math.min(d3, d);
        return Math.max(d2, d4);
    }

    private void I(String string) {
        double d;
        double d2;
        double d3;
        double d4;
        double d5;
        double d6;
        Integer n = 40;
        String[] stringArray = a;
        int n2 = this.getSetting("Randomization", n);
        Integer n3 = 15;
        int n4 = this.getSetting("Hitbox Margin", n3);
        double d7 = n4;
        double d8 = d7 / 100.0;
        double d9 = Math.max(0.03, d8);
        double d10 = d9 * 0.4;
        double d11 = Math.max(0.04, d10);
        double d12 = n2;
        double d13 = d12 / 100.0;
        double d14 = 0.14 * d13;
        double d15 = 0.1 + d14;
        double d16 = 0.5;
        double d17 = 0.5;
        boolean bl = "Center".equals(string);
        if (bl) {
            d6 = 0.5;
        } else {
            double d18;
            double d19 = this.random.nextGaussian();
            double d20 = d19 * d15;
            d16 = d18 = 0.5 + d20;
            double d21 = this.random.nextGaussian();
            d5 = d21 * d15;
            d17 = d4 = 0.5 + d5;
            stringArray = a;
            boolean bl2 = "Head".equals(string);
            if (bl2) {
                double d22;
                double d23 = this.random.nextDouble();
                double d24 = d23 * 0.17;
                d6 = d22 = 0.8 + d24;
            } else {
                stringArray = a;
                boolean bl3 = "Chest".equals(string);
                if (bl3) {
                    double d25;
                    double d26 = this.random.nextDouble();
                    double d27 = d26 * 0.25;
                    d6 = d25 = 0.55 + d27;
                } else {
                    stringArray = a;
                    boolean bl4 = "Legs".equals(string);
                    if (bl4) {
                        double d28 = this.random.nextDouble();
                        double d29 = d28 * 0.37;
                        d6 = d3 = 0.08 + d29;
                    } else {
                        stringArray = a;
                        boolean bl5 = "Random".equals(string);
                        if (bl5) {
                            double d30;
                            double d31 = this.random.nextDouble();
                            double d32 = d31 * 0.87;
                            d6 = d30 = 0.08 + d32;
                        } else {
                            Integer n5;
                            int n6;
                            int n7;
                            Integer n8;
                            int n9;
                            int n10;
                            Integer n11 = 30;
                            int n12 = this.getSetting("Head Weight", n11);
                            int n13 = Math.max(0, n12);
                            int n14 = n13 + (n10 = Math.max(0, n9 = this.getSetting("Body Weight", n8 = Integer.valueOf(50)).intValue()));
                            int n15 = n14 + (n7 = Math.max(0, n6 = this.getSetting("Legs Weight", n5 = Integer.valueOf(20)).intValue()));
                            int n16 = n15 <= 0 ? 0 : this.random.nextInt(n15);
                            int n17 = n16;
                            if (n15 <= 0) {
                                double d33;
                                double d34 = this.random.nextDouble();
                                double d35 = d34 * 0.25;
                                d6 = d33 = 0.55 + d35;
                            } else if (n17 < n13) {
                                double d36;
                                double d37 = this.random.nextDouble();
                                double d38 = d37 * 0.17;
                                d6 = d36 = 0.8 + d38;
                            } else {
                                int n18 = n13 + n10;
                                if (n17 < n18) {
                                    double d39;
                                    double d40 = this.random.nextDouble();
                                    double d41 = d40 * 0.3;
                                    d6 = d39 = 0.5 + d41;
                                } else {
                                    double d42;
                                    double d43 = this.random.nextDouble();
                                    double d44 = d43 * 0.4;
                                    d6 = d42 = 0.08 + d44;
                                }
                            }
                        }
                    }
                }
            }
        }
        double[] dArray = this.doubleArray;
        double d45 = d16;
        double d46 = 1.0 - d9;
        dArray[0] = d2 = KillAura.d(d45, d9, d46);
        double[] dArray2 = this.doubleArray;
        d5 = d6;
        d4 = 1.0 - d11;
        dArray2[1] = d = KillAura.d(d5, d11, d4);
        double[] dArray3 = this.doubleArray;
        double d47 = d17;
        double d48 = 1.0 - d9;
        dArray3[2] = d3 = KillAura.d(d47, d9, d48);
    }

    private class_243 N(class_1309 class_13092, class_243 class_2432, String string, long l, double d, double d2) {
        String[] stringArray;
        class_238 class_2382 = class_13092.method_5829();
        long l2 = this.time5;
        if (l >= l2) {
            long l3;
            this.I(string);
            stringArray = a;
            long l4 = this.V("Point Change", 500, 1400);
            this.time5 = l3 = l + l4;
        }
        Integer n = 40;
        stringArray = a;
        int n2 = this.getSetting("Point Drift", n);
        double d3 = n2;
        double d4 = d3 / 100.0;
        double d5 = d4 * 9.0;
        double d6 = 1.5 + d5;
        double d7 = d / 0.008;
        double d8 = Math.ceil(d7);
        int n3 = (int)d8;
        int n4 = Math.max(1, n3);
        double d9 = n4;
        double d10 = d / d9;
        int n5 = 0;
        block0: while (true) {
            double d11;
            double d12;
            double d13;
            double d14;
            double d15;
            double d16;
            double d17;
            double d18;
            double d19;
            double d20;
            double d21;
            double d22;
            double d23;
            double d24;
            double d25;
            int n6;
            int n7;
            if ((n7 = ++n5) >= 3) {
                Integer n8 = 40;
                n6 = this.getSetting("Randomization", n8);
                double d26 = n6;
                d25 = d26 / 100.0;
                d24 = 0.035 * d25;
                double d27 = this.doubleArray2[0];
                d23 = d2 * 0.6;
                double d28 = this.W(d23, 2);
                d22 = d28 * d24;
                d21 = d27 + d22;
                d20 = this.doubleArray2[1];
                d19 = d2 * 0.6;
                double d29 = this.W(d19, 3);
                d18 = d29 * d24;
                d17 = d20 + d18;
                d16 = this.doubleArray2[2];
                d15 = d2 * 0.6;
                d14 = this.W(d15, 4);
                double d30 = d14 * d24;
                d13 = d16 + d30;
                double d31 = KillAura.d(d21, 0.02, 0.98);
                d12 = KillAura.d(d17, 0.02, 0.98);
                d11 = KillAura.d(d13, 0.02, 0.98);
                boolean bl = "Closest".equals(string);
                if (bl) {
                    class_243 class_2433 = this.X(class_13092, class_2432);
                    double d32 = d31 - 0.5;
                    double d33 = class_2382.field_1320;
                    double d34 = class_2382.field_1323;
                    double d35 = d33 - d34;
                    double d36 = d32 * d35;
                    double d37 = d36 * 0.5;
                    double d38 = d12 - 0.5;
                    double d39 = class_2382.field_1325;
                    double d40 = class_2382.field_1322;
                    double d41 = d39 - d40;
                    double d42 = d38 * d41;
                    double d43 = d42 * 0.25;
                    double d44 = d11 - 0.5;
                    double d45 = class_2382.field_1324;
                    double d46 = class_2382.field_1321;
                    double d47 = d45 - d46;
                    double d48 = d44 * d47;
                    double d49 = d48 * 0.5;
                    double d50 = class_2433.field_1352;
                    double d51 = d50 + d37;
                    double d52 = class_2382.field_1323;
                    double d53 = class_2382.field_1320;
                    double d54 = KillAura.d(d51, d52, d53);
                    double d55 = class_2433.field_1351;
                    double d56 = d55 + d43;
                    double d57 = class_2382.field_1322;
                    double d58 = class_2382.field_1325;
                    double d59 = KillAura.d(d56, d57, d58);
                    double d60 = class_2433.field_1350;
                    double d61 = d60 + d49;
                    double d62 = class_2382.field_1321;
                    double d63 = class_2382.field_1324;
                    double d64 = KillAura.d(d61, d62, d63);
                    return new class_243(d54, d59, d64);
                }
                double d65 = class_2382.field_1323;
                double d66 = class_2382.field_1320;
                double d67 = class_2382.field_1323;
                double d68 = d66 - d67;
                double d69 = d31 * d68;
                double d70 = d65 + d69;
                double d71 = class_2382.field_1322;
                double d72 = class_2382.field_1325;
                double d73 = class_2382.field_1322;
                double d74 = d72 - d73;
                double d75 = d12 * d74;
                double d76 = d71 + d75;
                double d77 = class_2382.field_1321;
                double d78 = class_2382.field_1324;
                double d79 = class_2382.field_1321;
                double d80 = d78 - d79;
                double d81 = d11 * d80;
                double d82 = d77 + d81;
                return new class_243(d70, d76, d82);
            }
            int n9 = 0;
            while (true) {
                double d83;
                if ((n6 = n9++) >= n4) continue block0;
                double[] dArray = this.doubleArray3;
                int n10 = n5;
                d25 = dArray[n10];
                d24 = d6 * d6;
                double[] dArray2 = this.doubleArray;
                int n11 = n5;
                d23 = dArray2[n11];
                double[] dArray3 = this.doubleArray2;
                int n12 = n5;
                d22 = dArray3[n12];
                d21 = d23 - d22;
                d20 = d24 * d21;
                d19 = 2.0 * d6;
                double[] dArray4 = this.doubleArray3;
                int n13 = n5;
                d18 = dArray4[n13];
                d17 = d19 * d18;
                d16 = d20 - d17;
                d15 = d16 * d10;
                dArray[n10] = d14 = d25 + d15;
                double[] dArray5 = this.doubleArray2;
                int n14 = n5;
                d13 = dArray5[n14];
                double[] dArray6 = this.doubleArray3;
                int n15 = n5;
                d12 = dArray6[n15];
                d11 = d12 * d10;
                dArray5[n14] = d83 = d13 + d11;
            }
        }
    }

    private void e(class_310 class_3102, long l) {
        float f;
        float f2 = class_3102.field_1724.method_36454();
        float f3 = class_3102.field_1724.method_36455();
        float f4 = TargetPriority.X();
        float f5 = TargetPriority.D();
        float f6 = f2 - f4;
        float f7 = KillAura.g(f6);
        float f8 = f3 - f5;
        float f9 = KillAura.g(f8);
        float f10 = Math.abs(f7);
        if (f10 < 0.5f && (f = Math.abs(f9)) < 0.5f) {
            this.flag = false;
            this.factor = 0.0f;
            this.factor2 = 0.0f;
            return;
        }
        Integer n = 15;
        int n2 = this.getSetting("Horizontal Speed", n);
        Integer n3 = 15;
        int n4 = this.getSetting("Vertical Speed", n3);
        float f11 = n2;
        float f12 = f11 / 20.0f;
        float f13 = f7 * f12;
        float f14 = l;
        float f15 = f14 / 50.0f;
        float f16 = f13 * f15;
        float f17 = Math.abs(f7);
        float f18 = KillAura.Z(f16, f17);
        float f19 = n4;
        float f20 = f19 / 20.0f;
        float f21 = f9 * f20;
        float f22 = l;
        float f23 = f22 / 50.0f;
        float f24 = f21 * f23;
        float f25 = Math.abs(f9);
        float f26 = KillAura.Z(f24, f25);
        float f27 = f4 + f18;
        float f28 = f5 + f26;
        TargetPriority.j(f27, f28);
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        this.onTick();
    }

    @Subscribe
    public void onHudRender(HudRenderEvent hudRenderEvent) {
        this.w();
    }

    @Override
    public void onTick() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 != null && class_3102.field_1687 != null && class_3102.field_1761 != null) {
            boolean bl = this.P(class_3102);
            if (!bl) {
                this.l();
                return;
            } else {
                boolean bl2;
                boolean bl3;
                class_1309 class_13092 = this.livingEntity2;
                if (class_13092 != null && (bl3 = class_13092.method_5805()) && !(bl2 = class_13092.method_31481())) {
                    long l;
                    boolean bl4;
                    boolean bl5;
                    Boolean bl6 = true;
                    boolean bl7 = this.getSetting("Check Shielding", bl6);
                    if (bl7 && (bl5 = class_13092.method_6039())) {
                        this.l();
                        return;
                    }
                    Float f = Float.valueOf(0.9f);
                    float f2 = this.getSetting("Cooldown Threshold_lo", f).floatValue();
                    Float f3 = Float.valueOf(1.0f);
                    float f4 = this.getSetting("Cooldown Threshold_hi", f3).floatValue();
                    float f5 = this.random.nextFloat();
                    float f6 = f4 - f2;
                    float f7 = Math.max(0.0f, f6);
                    float f8 = f5 * f7;
                    float f9 = f2 + f8;
                    float f10 = class_3102.field_1724.method_7261(0.0f);
                    if (f10 < f9) {
                        this.l();
                        return;
                    }
                    Boolean bl8 = true;
                    boolean bl9 = this.getSetting("Prioritize Criticals", bl8);
                    if (bl9 && !(bl4 = this.U(class_3102))) {
                        this.l();
                        return;
                    }
                    bl4 = this.A(class_3102, class_13092);
                    if (!bl4) {
                        this.l();
                        return;
                    }
                    Integer n = 0;
                    int n2 = this.getSetting("Extra Delay_lo", n);
                    Integer n3 = 0;
                    int n4 = this.getSetting("Extra Delay_hi", n3);
                    long l2 = System.currentTimeMillis();
                    boolean bl10 = this.flag2;
                    if (!bl10) {
                        long l3;
                        if (n4 > n2) {
                            float f11 = this.random.nextFloat();
                            int n5 = n4 - n2;
                            float f12 = n5;
                            float f13 = f11 * f12;
                            long l4 = (long)f13;
                            long l5 = n2;
                            l = l4 + l5;
                        } else {
                            l = n2;
                        }
                        long l6 = l;
                        this.time8 = l3 = l2 + l6;
                        this.flag2 = true;
                    }
                    if (l2 < (l = this.time8)) {
                        return;
                    }
                    this.Q(class_3102, class_13092);
                    this.l();
                    return;
                }
                this.l();
            }
            return;
        } else {
            this.l();
        }
    }

    private boolean P(class_310 class_3102) {
        boolean bl;
        if (class_3102.field_1724 == null || class_3102.field_1687 == null) return false;
        Boolean bl2 = true;
        String[] stringArray = a;
        boolean bl3 = this.getSetting("Not in GUI", bl2);
        if (bl3 && class_3102.field_1755 != null) {
            return false;
        }
        Boolean bl4 = true;
        boolean bl5 = this.getSetting("Not While Using", bl4);
        if (!bl5 || !(bl = class_3102.field_1724.method_6115())) {
            Boolean bl7;
            boolean bl8;
            boolean bl6;
            return !(bl8 = this.getSetting("Only Weapon", bl7 = Boolean.valueOf(false)).booleanValue()) || (bl6 = KillAura.m(class_3102.field_1724.method_6047()));
        }
        return false;
    }

    private boolean S(class_1309 class_13092, class_243 class_2432, float f, float f2, int n) {
        float f3;
        float f4;
        double d;
        float f5;
        float f6;
        float f7;
        class_243 class_2433 = this.X(class_13092, class_2432).method_1020(class_2432);
        double d2 = class_2433.field_1352;
        double d3 = class_2433.field_1352;
        double d4 = d2 * d3;
        double d5 = class_2433.field_1350;
        double d6 = class_2433.field_1350;
        double d7 = d5 * d6;
        double d8 = d4 + d7;
        double d9 = Math.sqrt(d8);
        double d10 = class_2433.field_1352;
        double d11 = d10 * -1.0;
        double d12 = class_2433.field_1350;
        double d13 = Math.atan2(d11, d12);
        double d14 = d13 * 180.0;
        double d15 = d14 / Math.PI;
        float f8 = (float)d15;
        double d16 = class_2433.field_1351;
        double d17 = Math.atan2(d16, d9);
        double d18 = d17 * -1.0;
        double d19 = d18 * 180.0;
        double d20 = d19 / Math.PI;
        float f9 = (float)d20;
        float f10 = f8 - f;
        float f11 = KillAura.g(f10);
        float f12 = f11 * f11;
        float f13 = f12 + (f7 = (f6 = KillAura.g(f5 = f9 - f2)) * f6);
        double d21 = f13;
        double d22 = Math.sqrt(d21);
        if (!(d22 <= (d = (double)(f4 = (f3 = (float)n) / 2.0f)))) return false;
        return true;
    }

    private class_243 X(class_1309 class_13092, class_243 class_2432) {
        double d;
        double d2;
        double d3;
        double d4;
        double d5;
        double d6;
        double d7;
        double d8;
        double d9;
        class_238 class_2382 = class_13092.method_5829();
        String string = this.getSetting("Aim At", "Closest");
        boolean bl = "Center".equals(string);
        if (bl) {
            double d10 = class_2382.field_1323;
            double d11 = class_2382.field_1320;
            double d12 = d10 + d11;
            double d13 = d12 / 2.0;
            double d14 = class_2382.field_1322;
            double d15 = class_2382.field_1325;
            double d16 = d14 + d15;
            double d17 = d16 / 2.0;
            double d18 = class_2382.field_1321;
            double d19 = class_2382.field_1324;
            double d20 = d18 + d19;
            double d21 = d20 / 2.0;
            return new class_243(d13, d17, d21);
        }
        double d22 = class_2432.field_1352;
        double d23 = class_2382.field_1323;
        double d24 = d23 - 0.25;
        if (d22 > d24 && (d9 = class_2432.field_1352) < (d8 = (d7 = class_2382.field_1320) + 0.25) && (d6 = class_2432.field_1350) > (d5 = (d4 = class_2382.field_1321) - 0.25) && (d3 = class_2432.field_1350) < (d2 = (d = class_2382.field_1324) + 0.25)) {
            double d25 = class_2382.field_1323;
            double d26 = class_2382.field_1320;
            double d27 = d25 + d26;
            double d28 = d27 / 2.0;
            double d29 = class_2382.field_1322;
            double d30 = class_2382.field_1325;
            double d31 = class_2382.field_1322;
            double d32 = d30 - d31;
            double d33 = d32 * 0.6;
            double d34 = d29 + d33;
            double d35 = class_2382.field_1321;
            double d36 = class_2382.field_1324;
            double d37 = d35 + d36;
            double d38 = d37 / 2.0;
            return new class_243(d28, d34, d38);
        }
        d9 = class_2382.field_1320;
        d7 = class_2382.field_1323;
        d8 = d9 - d7;
        d6 = d8 * 0.25;
        d4 = Math.min(0.08, d6);
        d5 = class_2382.field_1325;
        d3 = class_2382.field_1322;
        d = d5 - d3;
        d2 = d * 0.25;
        double d39 = Math.min(0.08, d2);
        double d40 = class_2382.field_1324;
        double d41 = class_2382.field_1321;
        double d42 = d40 - d41;
        double d43 = d42 * 0.25;
        double d44 = Math.min(0.08, d43);
        double d45 = class_2382.field_1323;
        double d46 = d45 + d4;
        double d47 = class_2432.field_1352;
        double d48 = class_2382.field_1320;
        double d49 = d48 - d4;
        double d50 = Math.min(d47, d49);
        double d51 = Math.max(d46, d50);
        double d52 = class_2382.field_1322;
        double d53 = d52 + d39;
        double d54 = class_2432.field_1351;
        double d55 = class_2382.field_1325;
        double d56 = d55 - d39;
        double d57 = Math.min(d54, d56);
        double d58 = Math.max(d53, d57);
        double d59 = class_2382.field_1321;
        double d60 = d59 + d44;
        double d61 = class_2432.field_1350;
        double d62 = class_2382.field_1324;
        double d63 = d62 - d44;
        double d64 = Math.min(d61, d63);
        double d65 = Math.max(d60, d64);
        return new class_243(d51, d58, d65);
    }

    private static class_243 i(class_238 class_2382, class_243 class_2432) {
        double d = class_2382.field_1323;
        double d2 = class_2432.field_1352;
        double d3 = class_2382.field_1320;
        double d4 = Math.min(d2, d3);
        double d5 = Math.max(d, d4);
        double d6 = class_2382.field_1322;
        double d7 = class_2432.field_1351;
        double d8 = class_2382.field_1325;
        double d9 = Math.min(d7, d8);
        double d10 = Math.max(d6, d9);
        double d11 = class_2382.field_1321;
        double d12 = class_2432.field_1350;
        double d13 = class_2382.field_1324;
        double d14 = Math.min(d12, d13);
        double d15 = Math.max(d11, d14);
        return new class_243(d5, d10, d15);
    }

    private boolean U(class_310 class_3102) {
        boolean bl = class_3102.field_1724.method_24828();
        if (bl) {
            return true;
        }
        boolean bl2 = class_3102.field_1724.method_5799();
        if (bl2) return false;
        boolean bl3 = class_3102.field_1724.method_5771();
        if (bl3) return false;
        boolean bl4 = class_3102.field_1724.method_5765();
        if (bl4) {
            return false;
        }
        double d = class_3102.field_1724.method_18798().field_1351;
        if (!(d <= -0.1)) return false;
        return true;
    }

    private static boolean m(class_1799 class_17992) {
        boolean bl = class_17992.method_7960();
        if (!bl) {
            class_6862 class_68622;
            boolean bl2;
            class_6862 class_68623;
            boolean bl3;
            class_6862 class_68624;
            boolean bl4;
            boolean bl5;
            return (bl5 = class_17992.method_7909() instanceof class_1835) || (bl4 = class_17992.method_31573(class_68624 = class_3489.field_42611)) || (bl3 = class_17992.method_31573(class_68623 = class_3489.field_42612)) || (bl2 = class_17992.method_31573(class_68622 = class_3489.field_50109));
        }
        return false;
    }

    private void l() {
        this.flag2 = false;
        this.time8 = -1L;
    }

    private static float g(float f) {
        float f2;
        float f3;
        float f4 = f % 360.0f;
        float f5 = f4;
        float f6 = f5;
        if (f6 >= 180.0f) {
            f3 = f5;
            f5 = f2 = f3 - 360.0f;
        }
        if (!((f3 = f5) < -180.0f)) return f5;
        f2 = f5;
        float f7 = f2 + 360.0f;
        return f7;
    }

    private static float Z(float f, float f2) {
        float f3 = f2 * -1.0f;
        if (!(f > f2)) return f < f3 ? f3 : f;
        return f2;
    }

    private static class_1309 lmbd$getLivingEntity$1(class_1297 class_12972) {
        return (class_1309)class_12972;
    }

    static {
        a = new String[]{"Legs", "Dynamic", "Head", "Head", "Only When Aimed", "Randomization", "FOV", "Chest", "Legs", "Attack Range", "Aim At", "Jitter", "Randomization", "Head Weight", "Legs Weight", "Not While Using", "Center", "Head Weight", "Horizontal Speed", "Hitbox Margin", "Point Change", "Aim Vertically", "Horizontal Speed", "Nearest", "Aim At", "Random", "Random", "Extra Delay", "Humanize", "Automatically aims and attacks eligible nearby players.", "Nearest", "_hi", "FOV", "Kill Aura", "Hitbox Margin", "Max Pitch", "Vertical Speed", "Range", "Aim Horizontally", "Humanize", "Vertical Speed", "Speed Variation", "Point Drift", "Legs Weight", "Max Turn Speed", "Cooldown Threshold", "Ignore Friends", "Center", "Chest", "Only Weapon", "Max Turn Speed", "Closest", "Body Weight", "Only When Aimed", "Range", "Aim Horizontally", "Not While Using", "Only Weapon", "Lowest Health", "Point Change", "Aim Vertically", "Not in GUI", "Jitter", "Overshoot", "Reaction Delay", "Attack Range", "_lo", "Speed Variation", "Not in GUI", "Point Drift", "Reaction Delay", "Ignore Friends", "Body Weight", "Overshoot", "Check Shielding", "Prioritize Criticals", "Dynamic", "Closest", "Target Priority", "Max Pitch"};
        time = 0L;
        time2 = 0L;
        time3 = 0L;
    }

    private boolean A(class_310 class_3102, class_1309 class_13092) {
        class_243 class_2432;
        Object object;
        class_243 class_2433;
        class_243 class_2434;
        class_3959.class_3960 class_39602;
        if (this.p((class_1297)class_13092)) {
            return false;
        }
        Float f = Float.valueOf(3.0f);
        float f2 = this.getSetting("Attack Range", f).floatValue();
        double d = f2;
        double d2 = d - 0.05;
        double d3 = Math.max(1.0, d2);
        class_243 class_2435 = class_3102.field_1724.method_33571();
        class_238 class_2382 = class_13092.method_5829();
        Boolean bl = true;
        boolean bl2 = this.getSetting("Only When Aimed", bl);
        if (bl2) {
            float f3;
            float f4;
            float f5;
            float f6;
            boolean bl3 = this.flag;
            if (!bl3) {
                return false;
            }
            int n = -1;
            int n2 = class_3102.field_1724.field_6012;
            if (n == n2) {
                f5 = f6 = class_3102.field_1724.method_36454();
                f3 = f4 = class_3102.field_1724.method_36455();
            } else {
                f5 = f6 = TargetPriority.X();
                f3 = f4 = TargetPriority.D();
            }
            f6 = f3;
            f4 = f5;
            class_243 class_2438 = TargetPriority.k(f6, f4);
            double d4 = d3 + 1.0;
            class_2434 = class_2438.method_1021(d4);
            class_2433 = class_2435.method_1019(class_2434);
            object = class_2382.method_992(class_2435, class_2433);
            boolean bl4 = ((Optional)object).isEmpty();
            if (bl4) {
                return false;
            }
            class_2432 = (class_243)((Optional)object).get();
        } else {
            class_2432 = KillAura.i(class_2382, class_2435);
        }
        class_243 class_2436 = class_2432;
        double d5 = class_2435.method_1025(class_2436);
        double d6 = d3 * d3;
        if (d5 > d6) {
            return false;
        }
        class_638 class_6382 = class_3102.field_1687;
        class_243 class_2437 = class_2432;
        class_39602 = class_3959.class_3960.field_17559;
        class_3959.class_242 class_2422 = class_3959.class_242.field_1348;
        class_746 class_7462 = class_3102.field_1724;
        class_3959 class_39592 = new class_3959(class_2435, class_2437, class_39602, class_2422, (class_1297)class_7462);
        class_239.class_240 class_2402 = class_6382.method_17742(class_39592).method_17783();
        if (class_2402 != class_239.class_240.field_1333) return false;
        return true;
    }

    private void Q(class_310 class_3102, class_1309 class_13092) {
        if (this.p((class_1297)class_13092)) {
            return;
        }
        class_746 class_7462 = class_3102.field_1724;
        AttackEvent attackEvent = new AttackEvent();
        KryzexClient.INSTANCE.getEventBus().a(attackEvent);
        if (attackEvent.isCancelled() || class_3102.field_1724 == null || class_3102.field_1761 == null || !class_13092.method_5805() || this.p((class_1297)class_13092)) return;
        class_636 class_6362 = class_3102.field_1761;
        class_746 class_7463 = class_3102.field_1724;
        class_6362.method_2918((class_1657)class_7463, (class_1297)class_13092);
        class_746 class_7464 = class_3102.field_1724;
        class_1268 class_12682 = class_1268.field_5808;
        class_7464.method_6104(class_12682);
    }

    private class_1309 f(class_310 class_3102) {
        class_1309 class_13092;
        Predicate<class_1297> predicate;
        long l = System.nanoTime();
        if (!this.p((class_1297)this.cachedTarget) && this.selectedWorld == class_3102.field_1687 && l < this.nextTargetCheck && (this.cachedTarget == null || this.cachedTarget.method_5805() && !this.cachedTarget.method_31481())) return this.cachedTarget;
        this.selectedWorld = class_3102.field_1687;
        this.nextTargetCheck = l + 50000000L;
        Integer n = 6;
        int n2 = this.getSetting("Range", n);
        double d = n2;
        double d2 = n2;
        double d3 = d * d2;
        Integer n3 = 360;
        int n4 = this.getSetting("FOV", n3);
        float f = class_3102.field_1724.method_36454();
        float f2 = class_3102.field_1724.method_36455();
        class_243 class_2432 = class_3102.field_1724.method_33571();
        Stream<class_1297> stream = StreamSupport.stream(class_3102.field_1687.method_18112().spliterator(), false);
        Stream<class_1309> stream2 = stream.filter(predicate = arg_0 -> this.lmbd$getLivingEntity$0(class_3102, d3, n4, class_2432, f, f2, arg_0)).map(KillAura::lmbd$getLivingEntity$1);
        List<class_1309> list = stream2.collect(Collectors.toList());
        boolean bl = list.isEmpty();
        if (bl) {
            class_13092 = null;
        } else {
            class_746 class_7462 = class_3102.field_1724;
            class_13092 = TargetPriority.u(list, (class_1657)class_7462);
        }
        this.cachedTarget = class_13092;
        return class_13092;
    }

    private void O() {
        this.bool("Ignore Friends", true);
        this.number("Range", 6.0, 1.0, 12.0, 1.0);
        this.number("Attack Range", 3.0, 1.0, 6.0, 0.1);
        this.number("FOV", 360.0, 10.0, 360.0, 5.0);
        this.choice("Target Priority", "Nearest", "Nearest", "Lowest Health");
        this.choice("Aim At", "Dynamic", "Dynamic", "Closest", "Center", "Head", "Chest", "Legs", "Random");
        this.bool("Humanize", true);
        this.number("Horizontal Speed", 15.0, 1.0, 40.0, 1.0);
        this.number("Vertical Speed", 15.0, 1.0, 40.0, 1.0);
        this.bool("Aim Horizontally", true);
        this.bool("Aim Vertically", true);
        this.number("Max Pitch", 90.0, 10.0, 90.0, 1.0);
        this.number("Jitter", 30.0, 0.0, 100.0, 1.0);
        this.number("Speed Variation", 30.0, 0.0, 100.0, 1.0);
        this.number("Overshoot", 25.0, 0.0, 100.0, 1.0);
        this.number("Max Turn Speed", 800.0, 30.0, 1200.0, 10.0);
        this.range("Reaction Delay", 0.0, 1000.0, 5.0, 60.0, 180.0);
        this.range("Point Change", 0.0, 3000.0, 20.0, 500.0, 1400.0);
        this.number("Randomization", 40.0, 0.0, 100.0, 1.0);
        this.number("Hitbox Margin", 15.0, 3.0, 45.0, 1.0);
        this.number("Point Drift", 40.0, 0.0, 100.0, 1.0);
        this.number("Head Weight", 30.0, 0.0, 100.0, 1.0);
        this.number("Body Weight", 50.0, 0.0, 100.0, 1.0);
        this.number("Legs Weight", 20.0, 0.0, 100.0, 1.0);
        this.bool("Check Shielding", true);
        this.range("Cooldown Threshold", 0.0, 1.0, 0.05, 0.9, 1.0);
        this.bool("Prioritize Criticals", true);
        this.range("Extra Delay", 0.0, 500.0, 5.0, 0.0, 0.0);
        this.bool("Only When Aimed", true);
        this.bool("Not in GUI", true);
        this.bool("Not While Using", true);
        this.bool("Only Weapon", false);
    }

    private boolean p(class_1297 class_12972) {
        if (this.getSetting("Ignore Friends", true) == false) return false;
        if (!FriendUtil.isFriend(class_12972)) return false;
        return true;
    }

    private boolean lmbd$getLivingEntity$0(class_310 class_3102, double d, int n, class_243 class_2432, float f, float f2, class_1297 class_12972) {
        boolean bl;
        class_746 class_7462;
        double d2;
        boolean bl2;
        boolean bl3;
        boolean bl4;
        if (this.p(class_12972)) {
            return false;
        }
        boolean bl5 = class_12972 instanceof class_1657;
        if (!bl5 || (bl4 = TargetPriority.E(class_12972)) || !(bl3 = class_12972.method_5805()) || (bl2 = class_12972.method_7325()) || !((d2 = class_12972.method_5858((class_1297)(class_7462 = class_3102.field_1724))) <= d) || (bl = TargetPriority.L((class_1309)class_12972))) return false;
        if (n >= 360) {
            return true;
        }
        class_1309 class_13092 = (class_1309)class_12972;
        boolean bl6 = this.S(class_13092, class_2432, f, f2, n);
        if (!bl6) return false;
        return true;
    }
}
