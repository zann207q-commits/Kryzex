package kryzex.modules.combat;

import net.minecraft.class_1735;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.mixin.GetFOCUseDSLOTMixin;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_490;

public final class HoverTotem
extends Module {
    private static String[] a;
    private final NumberSetting tickDelay = new NumberSetting("Tick Delay", 0.0, 20.0, 0.0, 1.0);
    private final BoolSetting hotbarTotem = new BoolSetting("Hotbar Totem", true);
    private final NumberSetting hotbarSlot = new NumberSetting("Hotbar Slot", 1.0, 9.0, 1.0, 1.0);
    private final BoolSetting autoSwitch = new BoolSetting("Auto Switch", false);
    private int remainingTicks;

    public HoverTotem() {
        super("Hover Totem", "Equips totems when hovering over them in your inventory.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.tickDelay, this.hotbarTotem, this.hotbarSlot, this.autoSwitch});
        SettingGroup.set(this.hotbarSlot, this.hotbarTotem::getValue);
        SettingGroup.set((Setting)((Object)this.autoSwitch), this.hotbarTotem::getValue);
    }

    @Override
    public void onEnable() {
        this.K();
    }

    private void K() {
        this.remainingTicks = this.tickDelay.getIntValue();
    }

    @Override
    public void onDisable() {
        this.K();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        int n;
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }
        class_437 class_4372 = this.mc.field_1755;
        if (!(class_4372 instanceof class_490)) {
            this.K();
            return;
        }
        class_490 class_4902 = (class_490)class_4372;
        class_1735 class_17352 = ((GetFOCUseDSLOTMixin)class_4902).getFocusedSlot();
        if (class_17352 == null || class_17352.field_7871 != this.mc.field_1724.method_31548() || class_17352.method_34266() > 35) {
            return;
        }
        int n2 = this.hotbarSlot.getIntValue() - 1;
        if (this.autoSwitch.getValue()) {
            this.mc.field_1724.method_31548().method_61496(n2);
        }
        if (!class_17352.method_7677().method_31574(class_1802.field_8288)) {
            return;
        }
        if (this.remainingTicks > 0) {
            --this.remainingTicks;
            return;
        }
        if (!this.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            n = 40;
        } else {
            if (!this.hotbarTotem.getValue() || this.mc.field_1724.method_31548().method_5438(n2).method_31574(class_1802.field_8288)) {
                return;
            }
            n = n2;
        }
        this.mc.field_1761.method_2906(((class_1723)class_4902.method_17577()).field_7763, class_17352.field_7874, n, class_1713.field_7791, (class_1657)this.mc.field_1724);
        this.K();
    }

    static {
        a = new String[]{"Tick Delay", "Hotbar Slot", "Equips totems when hovering over them in your inventory.", "Hover Totem", "Hotbar Totem", "Auto Switch"};
    }
}
