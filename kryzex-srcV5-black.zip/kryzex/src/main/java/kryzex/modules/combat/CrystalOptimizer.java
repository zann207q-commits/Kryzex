package kryzex.modules.combat;

import kryzex.event.PacketSendEvent;
import kryzex.event.Subscribe;
import kryzex.mixin.GetEntityIDMixin;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.modules.combat.EntityID;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_310;

public final class CrystalOptimizer
extends Module {
    private static String[] a;
    public CrystalOptimizer() {
        super("Crystal Optimizer", "Removes attacked crystal visuals after an attack is sent.", -1, Category.COMBAT);
    }

    @Subscribe
    public void onPacketSend(PacketSendEvent packetSendEvent) {
        class_2596<?> class_25962;
        if (packetSendEvent.isCancelled() || !((class_25962 = packetSendEvent.packet) instanceof class_2824)) return;
        class_2824 class_28242 = (class_2824)class_25962;
        class_28242.method_34209((class_2824.class_5908)new EntityID(this, ((GetEntityIDMixin)class_28242).kryzex$getEntityId()));
    }

    class_310 I() {
        return this.mc;
    }

    static class_310 B(Object[] objectArray) {
        return ((CrystalOptimizer)objectArray[1]).mc;
    }

    static class_310 l(Object[] objectArray) {
        return ((CrystalOptimizer)objectArray[1]).mc;
    }

    static class_310 q(Object[] objectArray) {
        return ((CrystalOptimizer)objectArray[1]).mc;
    }

    static {
        a = new String[]{"Removes attacked crystal visuals after an attack is sent.", "Crystal Optimizer"};
    }
}
