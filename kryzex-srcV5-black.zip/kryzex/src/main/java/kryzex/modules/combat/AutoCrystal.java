package kryzex.modules.combat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import kryzex.event.EventPriority;
import kryzex.event.ItemUseHeadEvent;
import kryzex.event.PacketReceiveEvent;
import kryzex.event.PacketSendEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.mixin.GetEntityIDMixin;
import kryzex.mixin.GetStatusEntityIDMixin;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.modules.combat.Generation;
import kryzex.modules.combat.Generation2;
import kryzex.modules.combat.ValEvent;
import kryzex.util.ChunkUtil;
import kryzex.util.SecureString;
import kryzex.util.Unknown2;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_2824;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_8143;

public final class AutoCrystal
extends Module {
    private static String[] a;
    private static AutoCrystal instance;
    private final KeybindSetting activateKey = new KeybindSetting(SecureString.of("Activate Key"), 1, false).setDescription(SecureString.of("Key that does the crystalling"));
    private final NumberSetting placeDelay = new NumberSetting(SecureString.of("Place Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting breakDelay = new NumberSetting(SecureString.of("Break Delay"), 0.0, 20.0, 0.0, 1.0);
    private final BoolSetting stopAfterKill = new BoolSetting("Stop Crystaling After Kill", false).setDescription("Temporarily blocks crystal placement and attacks after your kill.");
    private final NumberSetting blockSeconds = new NumberSetting("Block Seconds", 1.0, 30.0, 3.0, 0.5);
    private final Generation killPause = new Generation();
    private class_638 combatWorld;
    private class_1657 combatPlayer;
    private volatile Generation2 combatSnapshot;
    private int placeDelayCounter;
    private int breakDelayCounter;
    public boolean isActive;

    public AutoCrystal() {
        super(SecureString.of("Auto Crystal"), SecureString.of("Automatically crystals fast for you"), -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.activateKey, this.placeDelay, this.breakDelay, this.stopAfterKill, this.blockSeconds});
        SettingGroup.set(this.blockSeconds, this.stopAfterKill::getValue);
        instance = this;
    }

    @Override
    public void onEnable() {
        this.e();
        this.isActive = false;
        this.t();
        this.V();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.isActive = false;
        this.e();
        this.t();
        super.onDisable();
    }

    private void t() {
        this.combatSnapshot = null;
        this.killPause.m();
        this.combatWorld = null;
        this.combatPlayer = null;
    }

    private boolean V() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || !this.stopAfterKill.getValue()) {
            this.t();
            return false;
        }
        if (this.combatWorld == this.mc.field_1687 && this.combatPlayer == this.mc.field_1724) return true;
        this.killPause.m();
        this.combatWorld = this.mc.field_1687;
        this.combatPlayer = this.mc.field_1724;
        this.N();
        return true;
    }

    private void N() {
        if (this.combatWorld == null || this.combatPlayer == null) {
            return;
        }
        HashMap<Integer, UUID> hashMap = new HashMap<Integer, UUID>();
        for (class_1657 class_16572 : this.combatWorld.method_18456()) {
            if (class_16572 == this.combatPlayer) continue;
            hashMap.put(class_16572.method_5628(), class_16572.method_5667());
        }
        this.combatSnapshot = new Generation2(this.combatWorld, this.combatPlayer, this.combatPlayer.method_5628(), Map.copyOf(hashMap), this.killPause.c(), this.blockSeconds.getValue());
    }

    public boolean w() {
        if (!this.isEnabled()) return false;
        if (!this.V()) return false;
        if (!this.killPause.k()) return false;
        return true;
    }

    public static boolean X(class_1268 class_12682) {
        AutoCrystal autoCrystal = instance;
        if (autoCrystal == null) return false;
        if (!autoCrystal.w()) return false;
        if (!autoCrystal.mc.field_1724.method_5998(class_12682).method_31574(class_1802.field_8301)) return false;
        return true;
    }

    public static boolean r(class_1297 class_12972) {
        AutoCrystal autoCrystal = instance;
        if (!(class_12972 instanceof class_1511)) return false;
        if (autoCrystal == null) return false;
        if (!autoCrystal.w()) return false;
        return true;
    }

    public static boolean U(class_2596<?> class_25962) {
        if (!(class_25962 instanceof class_8143) && !(class_25962 instanceof class_2663)) {
            return false;
        }
        AutoCrystal autoCrystal = instance;
        if (autoCrystal == null) return false;
        if (!autoCrystal.isEnabled()) return false;
        if (!autoCrystal.stopAfterKill.getValue()) return false;
        if (!autoCrystal.R(class_25962)) return false;
        return true;
    }

    private boolean R(class_2596<?> class_25962) {
        class_638 class_6382 = this.mc.field_1687;
        if (class_6382 == null) {
            return false;
        }
        Generation2 generation2 = this.combatSnapshot;
        if (generation2 == null || generation2.world != class_6382 || generation2.player != this.mc.field_1724) return false;
        if (class_25962 instanceof class_8143) {
            class_8143 class_81432 = (class_8143)class_25962;
            UUID uUID = generation2.opponents.get(class_81432.comp_1267());
            if (uUID == null) return false;
            this.killPause.B(generation2.generation, uUID, class_81432.comp_1269() == generation2.localId || class_81432.comp_1270() == generation2.localId);
            return true;
        }
        if (!(class_25962 instanceof class_2663)) return false;
        class_2663 class_26632 = (class_2663)class_25962;
        if (class_26632.method_11470() != 3) {
            return true;
        }
        if (!(class_26632 instanceof GetStatusEntityIDMixin)) return false;
        GetStatusEntityIDMixin getStatusEntityIDMixin = (GetStatusEntityIDMixin)class_26632;
        int n = getStatusEntityIDMixin.kryzex$getStatusEntityId();
        if (n == generation2.localId) {
            this.killPause.r(generation2.generation);
            return true;
        }
        UUID uUID = generation2.opponents.get(n);
        if (uUID == null) return false;
        this.killPause.u(generation2.generation, uUID, generation2.seconds);
        return true;
    }

    @Subscribe(priority=EventPriority.HIGHEST)
    public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
        if (packetReceiveEvent.isCancelled() || packetReceiveEvent.crystalFastHandled || !this.isEnabled() || !this.stopAfterKill.getValue() || !(packetReceiveEvent.packet instanceof class_8143) && !(packetReceiveEvent.packet instanceof class_2663)) {
            return;
        }
        if (this.R(packetReceiveEvent.packet)) {
            return;
        }
        class_638 class_6382 = this.mc.field_1687;
        if (class_6382 == null) {
            return;
        }
        class_2596<?> class_25962 = packetReceiveEvent.packet;
        long l = this.killPause.c();
        this.mc.execute(() -> this.lmbd$onPacketReceive$0(class_6382, l, class_25962));
    }

    private void L(class_2596<?> class_25962) {
        if (class_25962 instanceof class_8143) {
            class_8143 class_81432 = (class_8143)class_25962;
            class_1297 class_12972 = this.mc.field_1687.method_8469(class_81432.comp_1267());
            if (!(class_12972 instanceof class_1657) || class_12972 == this.mc.field_1724) return;
            int n = this.mc.field_1724.method_5628();
            this.killPause.E(class_12972.method_5667(), class_81432.comp_1269() == n || class_81432.comp_1270() == n);
            return;
        } else {
            class_2663 class_26632;
            if (!(class_25962 instanceof class_2663) || (class_26632 = (class_2663)class_25962).method_11470() != 3) return;
            class_1297 class_12973 = class_26632.method_11469((class_1937)this.mc.field_1687);
            if (class_12973 == this.mc.field_1724) {
                this.killPause.m();
                return;
            } else {
                if (!(class_12973 instanceof class_1657) || !this.killPause.D(class_12973.method_5667(), this.blockSeconds.getValue())) return;
                this.isActive = false;
                this.e();
            }
        }
    }

    @Subscribe(priority=EventPriority.HIGHEST)
    public void onPacketSend(PacketSendEvent packetSendEvent) {
        if (packetSendEvent.isCancelled() || !this.w()) {
            return;
        }
        class_2596<?> class_25962 = packetSendEvent.packet;
        if (class_25962 instanceof class_2885) {
            class_2885 class_28852 = (class_2885)class_25962;
            if (!AutoCrystal.X(class_28852.method_12546())) return;
            packetSendEvent.cancel();
            return;
        } else {
            class_25962 = packetSendEvent.packet;
            if (class_25962 instanceof class_2886) {
                class_2886 class_28862 = (class_2886)class_25962;
                if (!AutoCrystal.X(class_28862.method_12551())) return;
                packetSendEvent.cancel();
                return;
            } else {
                class_25962 = packetSendEvent.packet;
                if (!(class_25962 instanceof class_2824)) return;
                class_2824 class_28242 = (class_2824)class_25962;
                int n = ((GetEntityIDMixin)class_28242).kryzex$getEntityId();
                if (!AutoCrystal.r(this.mc.field_1687.method_8469(n))) {
                    return;
                }
                class_28242.method_34209((class_2824.class_5908)new ValEvent(this, packetSendEvent));
            }
        }
    }

    private void e() {
        this.placeDelayCounter = 0;
        this.breakDelayCounter = 0;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            this.isActive = false;
            this.t();
            return;
        }
        if (this.V()) {
            this.N();
        }
        if (this.w()) {
            this.isActive = false;
            this.e();
            return;
        }
        if (this.mc.field_1755 != null) return;
        this.m();
        if (this.mc.field_1724.method_6115() || !this.q() || this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301) return;
        this.l();
    }

    private void m() {
        if (this.placeDelayCounter > 0) {
            --this.placeDelayCounter;
        }
        if (this.breakDelayCounter <= 0) return;
        --this.breakDelayCounter;
    }

    private boolean q() {
        int n = this.activateKey.getValue();
        if (n != -1 && !Unknown2.isKeyPressed(n)) {
            this.e();
            this.isActive = false;
            return false;
        }
        this.isActive = true;
        return true;
    }

    private void l() {
        class_239 class_2392 = this.mc.field_1765;
        if (this.mc.field_1765 instanceof class_3965) {
            this.S((class_3965)class_2392);
            return;
        } else {
            class_239 class_2393 = this.mc.field_1765;
            if (!(class_2393 instanceof class_3966)) return;
            class_3966 class_39662 = (class_3966)class_2393;
            this.F(class_39662);
        }
    }

    private void S(class_3965 class_39652) {
        class_2338 class_23382;
        if (this.w()) {
            return;
        }
        if (class_39652.method_17783() != class_239.class_240.field_1332 || this.placeDelayCounter > 0 || !ChunkUtil.isBlockAtPosition(class_23382 = class_39652.method_17777(), class_2246.field_10540) && !ChunkUtil.isBlockAtPosition(class_23382, class_2246.field_9987) || !this.k(class_23382)) return;
        ChunkUtil.interactWithBlock(class_39652, true);
        this.placeDelayCounter = this.placeDelay.getIntValue();
    }

    private void F(class_3966 class_39662) {
        class_1297 class_12972;
        if (this.w()) {
            return;
        }
        if (this.breakDelayCounter > 0 || !((class_12972 = class_39662.method_17782()) instanceof class_1511) && !(class_12972 instanceof class_1621)) return;
        this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, class_12972);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.breakDelayCounter = this.breakDelay.getIntValue();
    }

    @Subscribe
    public void onItemUseHead(ItemUseHeadEvent itemUseHeadEvent) {
        class_239 class_2392;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.w() && this.mc.field_1724.method_6047().method_31574(class_1802.field_8301)) {
            itemUseHeadEvent.cancel();
            return;
        }
        if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301 || !((class_2392 = this.mc.field_1765) instanceof class_3965)) return;
        class_3965 class_39652 = (class_3965)class_2392;
        class_2338 class_23382 = class_39652.method_17777();
        if (this.mc.field_1765.method_17783() != class_239.class_240.field_1332 || !ChunkUtil.isBlockAtPosition(class_23382, class_2246.field_10540) && !ChunkUtil.isBlockAtPosition(class_23382, class_2246.field_9987)) return;
        itemUseHeadEvent.cancel();
    }

    private boolean k(class_2338 class_23382) {
        class_2338 class_23383 = class_23382.method_10084();
        if (!this.mc.field_1687.method_22347(class_23383)) {
            return false;
        }
        int n = class_23383.method_10263();
        int n2 = class_23383.method_10264();
        int n3 = class_23383.method_10260();
        return this.mc.field_1687.method_8335(null, new class_238((double)n, (double)n2, (double)n3, (double)n + 1.0, (double)n2 + 2.0, (double)n3 + 1.0)).isEmpty();
    }

    private void lmbd$onPacketReceive$0(class_638 class_6382, long l, class_2596 class_25962) {
        if (!this.isEnabled() || this.mc.field_1687 != class_6382 || this.killPause.c() != l || !this.V()) return;
        this.L(class_25962);
    }

    static {
        a = new String[]{"Key that does the crystalling", "Automatically crystals fast for you", "Block Seconds", "Place Delay", "Activate Key", "Temporarily blocks crystal placement and attacks after your kill.", "Stop Crystaling After Kill", "Break Delay", "Auto Crystal"};
    }
}
