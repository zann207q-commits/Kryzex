package kryzex.modules.combat;

public enum Always2 {
    Always,
    OnPop;

}
