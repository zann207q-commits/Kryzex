package kryzex.modules.combat;

public enum Automatic {
    Automatic,
    Manual;

}
