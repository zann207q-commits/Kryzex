package kryzex.modules.combat;

import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.NumberSetting;
import kryzex.util.ChunkUtil;
import kryzex.util.SecureString;
import kryzex.util.Unknown2;
import kryzex.util.InventoryUtil;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class AnchorMacro
extends Module {
    private static String[] a;
    private final NumberSetting switchDelay = new NumberSetting(SecureString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting glowstoneDelay = new NumberSetting(SecureString.of("Glowstone Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting explodeDelay = new NumberSetting(SecureString.of("Explode Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting totemSlot = new NumberSetting(SecureString.of("Totem Slot"), 1.0, 9.0, 1.0, 1.0);
    private int keybind = 0;
    private int glowstoneDelayCounter = 0;
    private int explodeDelayCounter = 0;

    public AnchorMacro() {
        super(SecureString.of("Anchor Macro"), SecureString.of("Automatically blows up respawn anchors for you"), -1, Category.COMBAT);
        this.addSettings(this.switchDelay, this.glowstoneDelay, this.explodeDelay, this.totemSlot);
    }

    @Override
    public void onEnable() {
        this.G();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1755 != null || this.T() || !Unknown2.isKeyPressed(1)) return;
        this.o();
    }

    private boolean T() {
        boolean bl;
        boolean bl2 = this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) || this.mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075);
        boolean bl3 = this.mc.field_1724.method_6047().method_7909() instanceof class_1819 || this.mc.field_1724.method_6079().method_7909() instanceof class_1819;
        boolean bl4 = bl = GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), 1) == 1;
        if (!bl2) {
            if (!bl3) return false;
        }
        if (!bl) return false;
        return true;
    }

    private void o() {
        class_3965 class_39652;
        class_239 class_2392 = this.mc.field_1765;
        if (!(class_2392 instanceof class_3965) || !ChunkUtil.isBlockAtPosition((class_39652 = (class_3965)class_2392).method_17777(), class_2246.field_23152)) return;
        this.mc.field_1690.field_1904.method_23481(false);
        if (ChunkUtil.isRespawnAnchorUncharged(class_39652.method_17777())) {
            this.w(class_39652);
            return;
        } else {
            if (!ChunkUtil.isRespawnAnchorCharged(class_39652.method_17777())) return;
            this.n(class_39652);
        }
    }

    private void w(class_3965 class_39652) {
        if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
            if (this.keybind < this.switchDelay.getIntValue()) {
                ++this.keybind;
                return;
            }
            this.keybind = 0;
            InventoryUtil.swap(class_1802.field_8801);
        }
        if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) return;
        if (this.glowstoneDelayCounter < this.glowstoneDelay.getIntValue()) {
            ++this.glowstoneDelayCounter;
            return;
        }
        this.glowstoneDelayCounter = 0;
        ChunkUtil.interactWithBlock(class_39652, true);
    }

    private void n(class_3965 class_39652) {
        int n = this.totemSlot.getIntValue() - 1;
        if (this.mc.field_1724.method_31548().method_67532() != n) {
            if (this.keybind < this.switchDelay.getIntValue()) {
                ++this.keybind;
                return;
            }
            this.keybind = 0;
            this.mc.field_1724.method_31548().method_61496(n);
        }
        if (this.mc.field_1724.method_31548().method_67532() != n) return;
        if (this.explodeDelayCounter < this.explodeDelay.getIntValue()) {
            ++this.explodeDelayCounter;
            return;
        }
        this.explodeDelayCounter = 0;
        ChunkUtil.interactWithBlock(class_39652, true);
    }

    private void G() {
        this.keybind = 0;
        this.glowstoneDelayCounter = 0;
        this.explodeDelayCounter = 0;
    }

    static {
        a = new String[]{"Explode Delay", "Automatically blows up respawn anchors for you", "Anchor Macro", "Switch Delay", "Totem Slot", "Glowstone Delay"};
    }
}
