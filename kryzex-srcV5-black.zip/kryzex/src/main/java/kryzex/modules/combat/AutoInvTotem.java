package kryzex.modules.combat;

import java.util.Random;
import kryzex.event.EntityStatusEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.combat.Always2;
import kryzex.util.DummyScreenHandler;
import kryzex.util.SecureString;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_490;

public final class AutoInvTotem
extends Module {
    private static String[] a;
    private static final int OFFHAND_BUTTON = 40;
    private final CycleSetting<Always2> equipMode = new CycleSetting<Always2>(SecureString.of("Equip Mode"), Always2.Always, Always2.class).setDescription(SecureString.of("Always keeps totems equipped, or only refills after your totem pops"));
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 0.0, 20.0, 2.0, 1.0).getValue(SecureString.of("Ticks to wait before each inventory click"));
    private final NumberSetting randomDelay = new NumberSetting(SecureString.of("Random Delay"), 0.0, 10.0, 2.0, 1.0).getValue(SecureString.of("Adds up to this many extra ticks to each click so the timing varies"));
    private final BoolSetting hotbar = new BoolSetting(SecureString.of("Hotbar"), true).setDescription(SecureString.of("Also keeps a totem in your Totem Slot"));
    private final NumberSetting totemSlot = new NumberSetting(SecureString.of("Totem Slot"), 1.0, 9.0, 1.0, 1.0).getValue(SecureString.of("Your preferred totem slot"));
    private final BoolSetting autoSwitch = new BoolSetting(SecureString.of("Auto Switch"), false).setDescription(SecureString.of("Selects the totem slot after the inventory closes"));
    private final BoolSetting forceTotem = new BoolSetting(SecureString.of("Force Totem"), false).setDescription(SecureString.of("Puts the totem in the slot, regardless if its space is taken up by something else"));
    private final BoolSetting autoOpen = new BoolSetting(SecureString.of("Auto Open"), false).setDescription(SecureString.of("Automatically opens and closes the inventory for you"));
    private final NumberSetting stayOpenDuration = new NumberSetting(SecureString.of("Stay Open For"), 0.0, 20.0, 0.0, 1.0);
    private final Random random = new Random();
    private int clickCooldown = -1;
    private int stayOpenCounter = -1;
    private boolean pendingPop;
    private boolean openedByModule;
    private boolean switchAfterClose;

    public AutoInvTotem() {
        super(SecureString.of("Auto Inv Totem"), SecureString.of("Automatically equips a totem in your offhand and main hand if empty"), -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.equipMode, this.delay, this.randomDelay, this.hotbar, this.totemSlot, this.autoSwitch, this.forceTotem, this.autoOpen, this.stayOpenDuration});
    }

    @Override
    public void onEnable() {
        this.clickCooldown = -1;
        this.stayOpenCounter = -1;
        this.pendingPop = false;
        this.openedByModule = false;
        this.switchAfterClose = false;
        super.onEnable();
    }

    @Subscribe
    public void onEntityStatus(EntityStatusEvent entityStatusEvent) {
        this.pendingPop = true;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        boolean bl;
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }
        boolean bl2 = this.mc.field_1755 instanceof class_490;
        if (!bl2) {
            this.clickCooldown = -1;
            this.stayOpenCounter = -1;
            this.openedByModule = false;
            if (this.mc.field_1755 == null && this.switchAfterClose) {
                this.switchAfterClose = false;
                this.Q();
            }
        }
        boolean bl3 = this.F();
        if (this.pendingPop && !bl3) {
            this.pendingPop = false;
        }
        boolean bl4 = bl = this.equipMode.isMode(Always2.Always) || this.pendingPop;
        if (!bl2) {
            if (!bl || !bl3 || !this.autoOpen.getValue() || this.mc.field_1755 != null) return;
            this.mc.method_1507((class_437)new DummyScreenHandler((class_1657)this.mc.field_1724));
            this.openedByModule = true;
            this.Z(true);
            return;
        }
        if (this.clickCooldown < 0) {
            this.Z(true);
        }
        if (bl && bl3) {
            this.stayOpenCounter = -1;
            if (this.clickCooldown > 0) {
                --this.clickCooldown;
                return;
            }
            if (this.mc.field_1724.method_5624() || this.mc.field_1724.method_6115()) {
                return;
            }
            if (!this.S()) return;
            this.switchAfterClose = this.autoSwitch.getValue();
            this.Z(false);
            return;
        }
        if (!this.openedByModule || !(this.mc.field_1755 instanceof DummyScreenHandler)) return;
        if (this.stayOpenCounter < 0) {
            this.stayOpenCounter = this.stayOpenDuration.getIntValue();
        }
        if (this.stayOpenCounter > 0) {
            --this.stayOpenCounter;
            return;
        }
        this.openedByModule = false;
        this.mc.field_1755.method_25419();
    }

    private void Z(boolean bl) {
        int n = this.randomDelay.getIntValue() > 0 ? this.random.nextInt(this.randomDelay.getIntValue() + 1) : 0;
        int n2 = this.delay.getIntValue() + n;
        this.clickCooldown = bl ? Math.max(1, n2) : n2;
    }

    private boolean S() {
        int n;
        int n2 = ((class_1723)((class_490)this.mc.field_1755).method_17577()).field_7763;
        int n3 = this.totemSlot.getIntValue() - 1;
        if (this.e() && (n = this.v(this.hotbar.getValue() ? n3 : -1, true)) != -1) {
            this.mc.field_1761.method_2906(n2, AutoInvTotem.r(n), 40, class_1713.field_7791, (class_1657)this.mc.field_1724);
            return true;
        }
        if (!this.f() || (n = this.v(n3, false)) == -1) return false;
        this.mc.field_1761.method_2906(n2, AutoInvTotem.r(n), n3, class_1713.field_7791, (class_1657)this.mc.field_1724);
        return true;
    }

    private boolean F() {
        int n = this.totemSlot.getIntValue() - 1;
        if (this.e()) {
            if (this.v(this.hotbar.getValue() ? n : -1, true) != -1) return true;
        }
        if (!this.f()) return false;
        if (this.v(n, false) == -1) return false;
        return true;
    }

    private boolean e() {
        if (this.mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return false;
        return true;
    }

    private boolean f() {
        if (!this.hotbar.getValue()) {
            return false;
        }
        class_1799 class_17992 = this.mc.field_1724.method_31548().method_5438(this.totemSlot.getIntValue() - 1);
        if (class_17992.method_7909() == class_1802.field_8288) return false;
        if (class_17992.method_7960()) return true;
        if (!this.forceTotem.getValue()) return false;
        return true;
    }

    private int v(int n, boolean bl) {
        int n2;
        class_1661 class_16612 = this.mc.field_1724.method_31548();
        for (n2 = 9; n2 < 36; ++n2) {
            if (class_16612.method_5438(n2).method_7909() != class_1802.field_8288) continue;
            return n2;
        }
        for (n2 = 0; n2 < 9; ++n2) {
            if (n2 == n || class_16612.method_5438(n2).method_7909() != class_1802.field_8288) continue;
            return n2;
        }
        if (!bl) return -1;
        if (n < 0) return -1;
        if (class_16612.method_5438(n).method_7909() != class_1802.field_8288) return -1;
        int n3 = n;
        return n3;
    }

    private static int r(int n) {
        return n < 9 ? 36 + n : n;
    }

    private void Q() {
        int n = this.totemSlot.getIntValue() - 1;
        class_1661 class_16612 = this.mc.field_1724.method_31548();
        if (class_16612.method_5438(n).method_7909() != class_1802.field_8288) return;
        class_16612.method_61496(n);
    }

    static {
        a = new String[]{"Your preferred totem slot", "Stay Open For", "Auto Switch", "Delay", "Totem Slot", "Automatically opens and closes the inventory for you", "Random Delay", "Also keeps a totem in your Totem Slot", "Auto Inv Totem", "Force Totem", "Hotbar", "Selects the totem slot after the inventory closes", "Auto Open", "Ticks to wait before each inventory click", "Equip Mode", "Always keeps totems equipped, or only refills after your totem pops", "Automatically equips a totem in your offhand and main hand if empty", "Adds up to this many extra ticks to each click so the timing varies", "Puts the totem in the slot, regardless if its space is taken up by something else"};
    }
}
