package kryzex.modules.combat;

import net.minecraft.class_239;

class SwitchMapNetMinecraftUtilHitHitResultType {
    static final int[] $SwitchMap$net$minecraft$util$hit$HitResult$Type = new int[class_239.class_240.values().length];

    static {
        try {
            SwitchMapNetMinecraftUtilHitHitResultType.$SwitchMap$net$minecraft$util$hit$HitResult$Type[class_239.class_240.field_1333.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilHitHitResultType.$SwitchMap$net$minecraft$util$hit$HitResult$Type[class_239.class_240.field_1332.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
    }
}
