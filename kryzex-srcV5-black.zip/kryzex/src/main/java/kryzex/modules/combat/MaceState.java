package kryzex.modules.combat;

public enum MaceState {
    IDLE,
    CIRCLING,
    STRIKING;

}
