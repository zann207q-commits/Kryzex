package kryzex.modules.combat;

import java.util.function.Predicate;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.util.ArmorUtil;
import kryzex.util.PressedState;
import kryzex.util.HotbarUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class ElytraSwap
extends Module {
    private static String[] a;
    private final KeybindSetting activateKey = new KeybindSetting("Activate Key", 71, false);
    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting switchDelay;
    private final NumberSetting elytraSlot;
    private final BoolSetting switchBack = new BoolSetting("Switch Back", true);
    private final BoolSetting moveToSlot;
    private boolean active;
    private boolean used;
    private boolean selected;
    private boolean keyHeld;
    private int ticks;
    private int restoreTicks;
    private int activationCooldown;
    private int previousSlot = -1;

    public ElytraSwap() {
        super("Elytra Swap", "Swaps between elytra and chest armor with a configurable key.", -1, Category.COMBAT);
        this.switchDelay = new NumberSetting("Switch Delay", 0.0, 20.0, 0.0, 1.0);
        this.moveToSlot = new BoolSetting("Move To Slot", true);
        this.elytraSlot = new NumberSetting("Elytra Slot", 1.0, 9.0, 9.0, 1.0);
        this.addSettings(new Setting[]{this.activateKey, this.delay, this.switchBack, this.switchDelay, this.moveToSlot, this.elytraSlot});
        SettingGroup.set(this.switchDelay, this.switchBack::getValue);
        SettingGroup.set(this.elytraSlot, this.moveToSlot::getValue);
    }

    @Override
    public void onEnable() {
        this.U();
        this.keyHeld = false;
        this.activationCooldown = 0;
    }

    private void U() {
        this.previousSlot = -1;
        this.ticks = 0;
        this.restoreTicks = 0;
        this.selected = false;
        this.used = false;
        this.active = false;
    }

    @Override
    public void onDisable() {
        this.U();
        this.keyHeld = false;
        this.activationCooldown = 0;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        Predicate<class_1792> predicate;
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            this.U();
            this.keyHeld = false;
            return;
        }
        if (this.mc.field_1755 != null) {
            return;
        }
        if (this.activationCooldown > 0) {
            --this.activationCooldown;
        } else if (!this.active && PressedState.isPressed(this.activateKey.getValue()) && !this.keyHeld) {
            this.active = true;
            this.activationCooldown = 4;
        }
        this.keyHeld = PressedState.isPressed(this.activateKey.getValue());
        if (!this.active) {
            return;
        }
        if (this.previousSlot == -1) {
            this.previousSlot = this.mc.field_1724.method_31548().method_67532();
        }
        if (this.ticks < this.delay.getIntValue()) {
            ++this.ticks;
            return;
        }
        Predicate<class_1792> predicate2 = predicate = this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833) ? ElytraSwap::V : ElytraSwap::lmbd$tick$0;
        if (!this.selected) {
            if (!HotbarUtil.selectMatchingItem(new Object[]{predicate, 0L})) {
                if (!this.moveToSlot.getValue()) {
                    this.U();
                    return;
                }
                int n = -1;
                for (int i = 9; i < 36; ++i) {
                    if (!predicate.test(this.mc.field_1724.method_31548().method_5438(i).method_7909())) continue;
                    n = i;
                    break;
                }
                if (n == -1) {
                    this.U();
                    return;
                }
                this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, n, this.elytraSlot.getIntValue() - 1, class_1713.field_7791, (class_1657)this.mc.field_1724);
                this.ticks = 0;
                return;
            }
            this.selected = true;
        }
        if (!this.used) {
            this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
            this.mc.field_1724.method_6104(class_1268.field_5808);
            this.used = true;
        }
        if (this.switchBack.getValue()) {
            if (this.restoreTicks < this.switchDelay.getIntValue()) {
                ++this.restoreTicks;
                return;
            }
            HotbarUtil.selectHotbarSlot(this.previousSlot);
        }
        this.U();
    }

    private static boolean V(class_1792 class_17922) {
        return ArmorUtil.isChestArmor(class_17922);
    }

    private static boolean lmbd$tick$0(class_1792 class_17922) {
        if (class_17922 != class_1802.field_8833) return false;
        return true;
    }

    static {
        a = new String[]{"Elytra Slot", "Switch Back", "Switch Delay", "Activate Key", "Delay", "Move To Slot", "Elytra Swap", "Swaps between elytra and chest armor with a configurable key."};
    }
}
