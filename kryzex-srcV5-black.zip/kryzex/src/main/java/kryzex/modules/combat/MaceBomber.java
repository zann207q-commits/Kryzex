package kryzex.modules.combat;

import java.util.Comparator;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.combat.Nearest;
import kryzex.modules.combat.MaceState;
import kryzex.util.ArmorUtil;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.HotbarUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_742;
import net.minecraft.class_746;

public final class MaceBomber
extends Module {
    private static String[] a;
    private final CycleSetting priority;
    private final StringSetting targetName;
    private MaceState phase = MaceState.IDLE;
    private class_1657 target;
    private class_243 lastTargetPosition;
    private class_243 targetVelocity = class_243.field_1353;
    private int ticks;
    private float desiredYaw;
    private float desiredPitch;
    private float smoothing = 0.5f;
    private boolean rotating;

    public MaceBomber() {
        super("Mace Bomber", "Tracks a target while gliding and swaps to a mace for landing attacks.", -1, Category.COMBAT);
        this.priority = new CycleSetting<Nearest>("Priority", Nearest.Nearest, Nearest.class);
        this.targetName = new StringSetting("Target Name", "");
        this.addSettings(new Setting[]{this.priority, this.targetName});
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.f();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.f();
    }

    private void f() {
        this.phase = MaceState.IDLE;
        this.target = null;
        this.lastTargetPosition = null;
        this.targetVelocity = class_243.field_1353;
        this.ticks = 0;
        this.rotating = false;
    }

    private void a(MaceState ug) {
        this.phase = ug;
        this.ticks = 0;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            this.f();
            return;
        }
        if (this.mc.field_1755 != null) {
            return;
        }
        ++this.ticks;
        switch (this.phase.ordinal()) {
            case 0: {
                this.v();
                return;
            }
            case 1: {
                this.Q();
                return;
            }
            case 2: {
                this.c();
            }
        }
    }

    @Subscribe
    public void onHudRender(HudRenderEvent hudRenderEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || !this.rotating) {
            return;
        }
        float f = (float)(1.0 - Math.exp(-Math.min(0.1, InverseProjectionScratch.deltaTime()) * 60.0 * (double)this.smoothing));
        this.mc.field_1724.method_36456(this.mc.field_1724.method_36454() + class_3532.method_15393((float)(this.desiredYaw - this.mc.field_1724.method_36454())) * f);
        this.mc.field_1724.method_36457(this.mc.field_1724.method_36455() + class_3532.method_15393((float)(this.desiredPitch - this.mc.field_1724.method_36455())) * f);
    }

    private void v() {
        this.rotating = false;
        if (this.mc.field_1724.method_24828() || !this.mc.field_1724.method_6128()) return;
        class_1657 class_16572 = this.g();
        if (class_16572 != this.target) {
            this.lastTargetPosition = null;
            this.targetVelocity = class_243.field_1353;
        }
        this.target = class_16572;
        if (this.target == null) return;
        this.a(MaceState.CIRCLING);
    }

    private void Q() {
        float f = 50.0f;
        float f2 = 0.0f;
        if (this.mc.field_1724.method_24828()) {
            this.f();
            return;
        }
        if (!this.mc.field_1724.method_6128()) {
            this.a(MaceState.STRIKING);
            return;
        }
        class_1657 class_16572 = this.g();
        if (class_16572 != this.target) {
            this.lastTargetPosition = null;
            this.targetVelocity = class_243.field_1353;
        }
        this.target = class_16572;
        if (this.target == null) {
            this.a(MaceState.IDLE);
            return;
        }
        this.K();
        class_243 class_2432 = this.mc.field_1724.method_73189();
        class_243 class_2433 = this.target.method_73189();
        class_243 class_2434 = this.mc.field_1724.method_18798();
        double d = class_2432.field_1351 - class_2433.field_1351;
        double d2 = MaceBomber.q(class_2432, class_2433);
        double d3 = class_2434.method_37267();
        double d4 = Math.sqrt(2.0 * Math.max(d, 1.0) / 0.08);
        class_243 class_2435 = new class_243(class_2432.field_1352 + class_2434.field_1352 * d4 * 0.7, class_2433.field_1351, class_2432.field_1350 + class_2434.field_1350 * d4 * 0.7);
        class_243 class_2436 = class_2433.method_1031(this.targetVelocity.field_1352 * d4, 0.0, this.targetVelocity.field_1350 * d4);
        double d5 = MaceBomber.q(class_2435, class_2436);
        if (d5 < 2.5 && d > 5.0 && d < 14.0) {
            this.S();
            this.J();
            this.a(MaceState.STRIKING);
            return;
        }
        if (d2 > 15.0 || d2 > 8.0 && d3 < 0.5) {
            double d6 = Math.min(d3 > 0.2 ? d2 / d3 : 40.0, 50.0);
            class_243 class_2437 = class_2433.method_1031(this.targetVelocity.field_1352 * d6, 0.0, this.targetVelocity.field_1350 * d6);
            f2 = (float)Math.toDegrees(Math.atan2(class_2437.field_1350 - class_2432.field_1350, class_2437.field_1352 - class_2432.field_1352)) - 90.0f;
            double d7 = MaceBomber.q(class_2432, class_2437);
            f = d7 > 40.0 ? 20.0f : (d7 > 25.0 ? 30.0f : (d7 > 15.0 ? 40.0f : 50.0f));
        } else {
            f2 = (float)Math.toDegrees(Math.atan2(class_2436.field_1350 - class_2435.field_1350, class_2436.field_1352 - class_2435.field_1352)) - 90.0f;
            f = d3 > 1.0 ? 75.0f : (d3 > 0.6 ? 65.0f : d3 > 0.3 ? 55.0f : 45.0f);
            if (d5 > 8.0 && d3 < 0.4) {
                f = 35.0f;
            }
        }
        this.smoothing = (float)class_3532.method_15350((double)(0.3 + d3 * 0.2), 0.3, 0.6);
        this.desiredYaw = f2;
        this.desiredPitch = f;
        this.rotating = true;
        if (this.ticks <= 400) return;
        this.S();
        this.a(MaceState.STRIKING);
    }

    private void c() {
        class_239 class_2392;
        class_243 class_2432;
        class_1657 class_16572;
        if (this.mc.field_1724.method_6128()) {
            this.S();
        }
        if ((class_16572 = this.g()) != this.target) {
            this.lastTargetPosition = null;
            this.targetVelocity = class_243.field_1353;
        }
        this.target = class_16572;
        this.J();
        this.K();
        if (this.target != null && !this.target.method_29504() && !this.target.method_31481()) {
            class_2432 = this.mc.field_1724.method_73189();
            class_243 class_2433 = this.target.method_73189();
            double d = Math.min((class_2432.field_1351 - class_2433.field_1351) / Math.max(Math.abs(this.mc.field_1724.method_18798().field_1351), 0.5), 20.0);
            this.O(class_2433.method_1031(this.targetVelocity.field_1352 * d, (double)(this.target.method_17682() / 2.0f), this.targetVelocity.field_1350 * d));
        }
        class_239 object2 = this.mc.field_1765;
        if (this.target != null && this.J() && this.mc.field_1761 != null && object2 instanceof class_3966 && ((class_3966)object2).method_17782() == this.target && this.mc.field_1724.method_7261(0.0f) >= 1.0f) {
            this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, (class_1297)this.target);
            this.mc.field_1724.method_6104(class_1268.field_5808);
        }
        if (!this.mc.field_1724.method_24828()) return;
        this.f();
    }

    private void O(class_243 class_2432) {
        class_243 class_2433 = class_2432.method_1020(this.mc.field_1724.method_33571());
        this.desiredYaw = (float)Math.toDegrees(Math.atan2(class_2433.field_1350, class_2433.field_1352)) - 90.0f;
        this.desiredPitch = class_3532.method_15363((float)((float)(-Math.toDegrees(Math.atan2(class_2433.field_1351, Math.sqrt(class_2433.field_1352 * class_2433.field_1352 + class_2433.field_1350 * class_2433.field_1350))))), -90.0f, 90.0f);
        this.smoothing = class_2433.method_1033() < 5.0 ? 0.7f : 0.5f;
        this.rotating = true;
    }

    private void S() {
        int n;
        if (!this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833) || this.mc.field_1761 == null) {
            return;
        }
        int n2 = -1;
        for (n = 0; n < 9; ++n) {
            if (!ArmorUtil.isChestArmor(this.mc.field_1724.method_31548().method_5438(n).method_7909())) continue;
            n2 = n;
            break;
        }
        if (n2 == -1) {
            return;
        }
        n = this.mc.field_1724.method_31548().method_67532();
        this.mc.field_1724.method_31548().method_61496(n2);
        try {
            this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
            return;
        }
        finally {
            this.mc.field_1724.method_31548().method_61496(n);
        }
    }

    private boolean J() {
        if (this.mc.field_1724.method_6047().method_31574(class_1802.field_49814)) return true;
        if (!HotbarUtil.selectHotbarItem(class_1802.field_49814)) return false;
        return true;
    }

    private void K() {
        if (this.target == null) {
            return;
        }
        class_243 class_2432 = this.target.method_73189();
        if (this.lastTargetPosition != null) {
            this.targetVelocity = class_2432.method_1020(this.lastTargetPosition);
        }
        this.lastTargetPosition = class_2432;
    }

    private boolean h(class_1657 class_16572) {
        return class_16572 != this.mc.field_1724 && !class_16572.method_29504() && !class_16572.method_31481();
    }

    private class_1657 g() {
        if (this.priority.getValue() != Nearest.Named) return this.mc.field_1687.method_18456().stream().filter(this::h).min(Comparator.comparingDouble(arg_0 -> ((class_746)this.mc.field_1724).method_5739(arg_0))).orElse(null);
        String string = this.targetName.getValue();
        if (string != null && !string.isEmpty()) return this.mc.field_1687.method_18456().stream().filter(this::h).filter(arg_0 -> MaceBomber.lmbd$findTarget$0(string, arg_0)).findFirst().orElse(null);
        return null;
    }

    private static double q(class_243 class_2432, class_243 class_2433) {
        double d = class_2432.field_1352 - class_2433.field_1352;
        double d2 = class_2432.field_1350 - class_2433.field_1350;
        return Math.sqrt(d * d + d2 * d2);
    }

    private static boolean lmbd$findTarget$0(String string, class_742 class_7422) {
        return class_7422.method_5477().getString().equalsIgnoreCase(string);
    }

    static {
        a = new String[]{"Target Name", "Mace Bomber", "Priority", "Tracks a target while gliding and swaps to a mace for landing attacks."};
    }
}
