package kryzex.modules.combat;

public enum Nearest {
    Nearest,
    Named;

}
