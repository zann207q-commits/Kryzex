package kryzex.modules.combat;

import kryzex.event.AttackEvent;
import kryzex.event.BlockBreakingEvent;
import kryzex.event.Subscribe;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.modules.combat.SwitchMapNetMinecraftUtilHitHitResultType;
import kryzex.util.BlockListSetting;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public final class NoHitDelay
extends Module {
    private static String[] a;
    private final BoolSetting onlyItem = new BoolSetting("Only Item", true);
    private final ItemSetting item = new ItemSetting("Item", class_1802.field_8162);
    private final BoolSetting air = new BoolSetting("Air", true);
    private final BoolSetting blocks = new BoolSetting("Blocks", false);
    private final ListSetting whitelist = BlockListSetting.create("Allowed Blocks");

    public NoHitDelay() {
        super("No Hit Delay", "Prevents unwanted air and block attacks with a configurable item filter.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.onlyItem, this.item, this.air, this.blocks, this.whitelist});
        SettingGroup.set(this.item, this.onlyItem::getValue);
    }

    private boolean n() {
        if (this.mc.field_1724 == null) return false;
        if (!this.onlyItem.getValue()) return true;
        if (this.mc.field_1724.method_6047().method_7909() != this.item.getItem()) return false;
        return true;
    }

    private boolean f() {
        if (!this.blocks.getValue()) {
            return false;
        }
        if (BlockListSetting.getBlocks(this.whitelist).isEmpty()) {
            return true;
        }
        if (this.mc.field_1687 == null) return true;
        class_239 class_2392 = this.mc.field_1765;
        if (!(class_2392 instanceof class_3965)) return true;
        class_3965 class_39652 = (class_3965)class_2392;
        if (BlockListSetting.getBlocks(this.whitelist).contains(this.mc.field_1687.method_8320(class_39652.method_17777()).method_26204())) return false;
        return true;
    }

    @Subscribe
    public void onAttack(AttackEvent attackEvent) {
        if (!this.n() || this.mc.field_1765 == null) {
            return;
        }
        switch (SwitchMapNetMinecraftUtilHitHitResultType.$SwitchMap$net$minecraft$util$hit$HitResult$Type[this.mc.field_1765.method_17783().ordinal()]) {
            case 1: {
                if (!this.air.getValue()) return;
                attackEvent.cancel();
                return;
            }
            case 2: {
                if (!this.f()) return;
                attackEvent.cancel();
                return;
            }
        }
    }

    @Subscribe
    public void onBlockBreaking(BlockBreakingEvent blockBreakingEvent) {
        if (!this.n() || this.mc.field_1765 == null || this.mc.field_1765.method_17783() != class_239.class_240.field_1332 || !this.f()) return;
        blockBreakingEvent.cancel();
    }

    static {
        a = new String[]{"Item", "Only Item", "Prevents unwanted air and block attacks with a configurable item filter.", "Blocks", "Allowed Blocks", "Air", "No Hit Delay"};
    }
}
