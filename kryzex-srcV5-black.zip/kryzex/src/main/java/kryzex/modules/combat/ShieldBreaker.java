package kryzex.modules.combat;

import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.modules.combat.Automatic;
import kryzex.util.PressedState;
import kryzex.util.HotbarUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_243;

public final class ShieldBreaker
extends Module {
    private static String[] a;
    private final CycleSetting mode = new CycleSetting<Automatic>("Mode", Automatic.Automatic, Automatic.class);
    private final KeybindSetting activateKey = new KeybindSetting("Activate Key", -1, false);
    private final BoolSetting switchBack = new BoolSetting("Switch Back", true);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 3.0, 0.0, 1.0);
    private int previousSlot = -1;
    private int ticks;
    private boolean restoring;
    private static final long vFxCI8HQQP3DW2wK = 2127791500323246436L;

    public ShieldBreaker() {
        super("Shield Breaker", "Uses an axe against players facing you with a raised shield.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.mode, this.activateKey, this.switchBack, this.switchDelay});
        SettingGroup.set((Setting)((Object)this.activateKey), this::lmbd$new$0);
        SettingGroup.set(this.switchDelay, this.switchBack::getValue);
    }

    @Override
    public void onEnable() {
        this.s();
    }

    @Override
    public void onDisable() {
        this.s();
    }

    private void s() {
        this.previousSlot = -1;
        this.ticks = 0;
        this.restoring = false;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        class_1657 class_16572;
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            this.s();
            return;
        }
        if (this.mc.field_1755 != null || this.mc.field_1724.method_7261(0.0f) < 1.0f) {
            return;
        }
        if (this.restoring && this.switchBack.getValue()) {
            if (this.ticks < this.switchDelay.getIntValue()) {
                ++this.ticks;
                return;
            }
            if (this.previousSlot != -1) {
                HotbarUtil.selectHotbarSlot(this.previousSlot);
            }
            this.s();
            return;
        }
        if (this.mode.getValue() != Automatic.Automatic && !PressedState.isPressed(this.activateKey.getValue())) {
            return;
        }
        class_1297 class_12972 = this.mc.field_1692;
        if (!(class_12972 instanceof class_1657) || !(class_16572 = (class_1657)class_12972).method_6039() || this.W(class_16572)) {
            return;
        }
        if (this.switchBack.getValue() && this.previousSlot == -1) {
            this.previousSlot = this.mc.field_1724.method_31548().method_67532();
        }
        if (!HotbarUtil.selectMatchingItem(new Object[]{(java.util.function.Predicate<net.minecraft.class_1792>)(ShieldBreaker::lmbd$tick$0), 0L})) {
            return;
        }
        this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, (class_1297)class_16572);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        if (!this.switchBack.getValue() || this.previousSlot == -1) return;
        this.restoring = true;
        this.ticks = 0;
    }

    private boolean W(class_1657 class_16572) {
        class_243 class_2432 = this.mc.field_1724.method_73189().method_1020(class_16572.method_73189()).method_1029();
        double d = Math.toRadians(class_16572.method_36454());
        double d2 = Math.toRadians(class_16572.method_36455());
        class_243 class_2433 = new class_243(-Math.sin(d) * Math.cos(d2), -Math.sin(d2), Math.cos(d) * Math.cos(d2)).method_1029();
        if (!(class_2433.method_1026(class_2432) < 0.0)) return false;
        return true;
    }

    private static boolean lmbd$tick$0(class_1792 class_17922) {
        return class_17922 instanceof class_1743;
    }

    private boolean lmbd$new$0() {
        if (this.mode.getValue() != Automatic.Manual) return false;
        return true;
    }

    static {
        a = new String[]{"Shield Breaker", "Switch Delay", "Mode", "Switch Back", "Activate Key", "Uses an axe against players facing you with a raised shield."};
    }
}
