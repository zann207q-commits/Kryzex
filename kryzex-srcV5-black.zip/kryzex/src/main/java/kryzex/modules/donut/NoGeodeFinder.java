package kryzex.modules.donut;

import it.unimi.dsi.fastutil.longs.Long2BooleanOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.ArrayList;
import java.util.List;
import java.util.function.LongConsumer;
import kryzex.event.MacroPacketAppliedEvent;
import kryzex.event.MacroRender3DEvent;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroColorSetting;
import kryzex.module.settings.MacroModeSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.modules.donut.Budding;
import kryzex.modules.donut.Budding2;
import kryzex.modules.donut.HasUngrown2;
import kryzex.modules.misc.MacroModule;
import kryzex.util.AreasSize;
import kryzex.util.Layers;
import kryzex.util.WorldUtil2;
import kryzex.util.Visible;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2596;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_5543;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_9848;

@Environment(value=EnvType.CLIENT)
public final class NoGeodeFinder
extends MacroModule {
    private static final long SCAN_BUDGET_NANOS = 3000000L;
    private static final int MIN_SCANNED_NEIGHBOURS = 3;
    private static final int NO_PACKET_SENSITIVITY = 1;
    private static final int VISIBLE_REFRESH_TICKS = 20;
    private static final int PACKET_MIN_Y = -16;
    private static final int PACKET_MAX_Y = 30;
    private static String METHOD_CLASSIC;
    private static String METHOD_ANBS;
    private static final int GLOW_CELLS_PER_POINT = 12;
    private static final int GEODE_TOP_Y = 47;
    private static final int MIN_EXPOSED_BUDDING = 10;
    private static final int MIN_EXPOSED_LINING = 160;
    private static final int GEODE_SETTLE_TICKS = 40;
    private static final int GEODE_CELL_SHIFT = 2;
    private static final int TORCH_LIGHT = 14;
    private static class_2350[] SIDES;
    private final MacroModeSetting method = this.addSetting("method", new MacroModeSetting("Method", "Classic", "Classic", "Advanced Scan"));
    private final MacroNumberSetting spreadRadius = this.addSetting("spread-radius", new MacroNumberSetting("Simulation Distance", 5.0f, 2.0f, 16.0f).step(1.0f));
    private final MacroNumberSetting sensitivity = this.addSetting("packet-sensitivity", new MacroNumberSetting("Sensitivity", 6.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroColorSetting chunkColor = this.addSetting("chunk-color", new MacroColorSetting("Geode Color", 1287169012));
    private final MacroBoolSetting tracers = this.addSetting("tracers", new MacroBoolSetting("Tracers", true));
    private final MacroBoolSetting detectMined = this.addSetting("detect-mined-clusters", new MacroBoolSetting("Detect Mined Clusters", true));
    private final MacroColorSetting minedColor = this.addSetting("mined-color", new MacroColorSetting("Mined Color", 1559286405));
    private final AreasSize chunkAreas = new AreasSize();
    private final Visible chunkOverlay = new Visible();
    private final AreasSize minedAreas = new AreasSize();
    private final Visible minedOverlay = new Visible();
    private final Layers glow = new Layers();
    private final Long2IntOpenHashMap heat = new Long2IntOpenHashMap();
    private final Long2IntOpenHashMap vetoes = new Long2IntOpenHashMap();
    private final Long2IntOpenHashMap chunkScore = new Long2IntOpenHashMap();
    private final Long2BooleanOpenHashMap chunkUngrown = new Long2BooleanOpenHashMap();
    private final Long2BooleanOpenHashMap chunkHasPacket = new Long2BooleanOpenHashMap();
    private final LongOpenHashSet scannedChunks = new LongOpenHashSet();
    private final LongArrayFIFOQueue queue = new LongArrayFIFOQueue();
    private final LongOpenHashSet queued = new LongOpenHashSet();
    private Long2IntOpenHashMap visible = new Long2IntOpenHashMap();
    private boolean visibleDirty = true;
    private int visibleAge;
    private class_638 lastLevel;
    private int appliedRadius;
    private final Long2ObjectOpenHashMap<Budding> geodeSlices = new Long2ObjectOpenHashMap();
    private final Long2IntOpenHashMap geodeWaiting = new Long2IntOpenHashMap();
    private final Long2IntOpenHashMap geodeScanTicks = new Long2IntOpenHashMap();
    private List<Budding2> geodeClusters = List.of();
    private boolean geodeClustersDirty;
    private LongOpenHashSet minedChunks = new LongOpenHashSet();
    private int minedAge;
    private int ticks;
    private static String[] a;

    public NoGeodeFinder() {
        super("no-geode-finder", "No Geode Finder", "Finds grown or mined-out geodes, including servers that hide amethyst growth.", MacroCategories.BASE_RAID);
        this.method.onChange(this::P);
        this.sensitivity.onChange(this::lmbd$new$0);
        this.detectMined.onChange(this::v);
        this.minedColor.visibleWhen(this.detectMined::get);
    }

    private void P() {
        this.o();
        this.c();
    }

    private void v() {
        this.Y();
        if (!this.detectMined.get()) return;
        this.c();
    }

    @Override
    public void onEnable() {
        this.o();
        this.lastLevel = class_310.method_1551().field_1687;
        this.c();
    }

    @Override
    public void onDisable() {
        this.o();
        this.lastLevel = null;
    }

    private void o() {
        this.heat.clear();
        this.vetoes.clear();
        this.chunkScore.clear();
        this.chunkUngrown.clear();
        this.chunkHasPacket.clear();
        this.scannedChunks.clear();
        this.queue.clear();
        this.queued.clear();
        this.visible = new Long2IntOpenHashMap();
        this.visibleDirty = true;
        this.appliedRadius = this.spreadRadius.getInt();
        this.Y();
    }

    private void Y() {
        this.geodeSlices.clear();
        this.geodeWaiting.clear();
        this.geodeScanTicks.clear();
        this.geodeClusters = List.of();
        this.geodeClustersDirty = false;
        this.minedChunks = new LongOpenHashSet();
        this.minedAge = 0;
    }

    private void c() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_3102.field_1724 == null) return;
        int n = (Integer)class_3102.field_1690.method_42503().method_41753() + 1;
        class_1923 class_19232 = class_3102.field_1724.method_31476();
        for (int i = class_19232.field_9181 - n; i <= class_19232.field_9181 + n; ++i) {
            for (int j = class_19232.field_9180 - n; j <= class_19232.field_9180 + n; ++j) {
                if (!WorldUtil2.isLoaded(class_3102.field_1687, i, j)) continue;
                this.N(class_1923.method_8331((int)i, (int)j));
            }
        }
    }

    private void N(long l) {
        if (!this.queued.add(l)) return;
        this.queue.enqueue(l);
    }

    @MacroSubscribe
    public void onMacroPacketApplied(MacroPacketAppliedEvent macroPacketAppliedEvent) {
        class_2596<?> class_25962 = macroPacketAppliedEvent.packet;
        if (class_25962 instanceof class_2672) {
            class_2672 class_26722 = (class_2672)class_25962;
            this.N(class_1923.method_8331((int)class_26722.method_11523(), (int)class_26722.method_11524()));
            return;
        } else {
            class_25962 = macroPacketAppliedEvent.packet;
            if (!(class_25962 instanceof class_2676)) return;
            class_2676 class_26762 = (class_2676)class_25962;
            if (!this.method.is("Advanced Scan")) return;
            this.N(class_1923.method_8331((int)class_26762.method_11558(), (int)class_26762.method_11554()));
        }
    }

    @MacroSubscribe
    public void onMacroTick(MacroTickEvent macroTickEvent) {
        class_310 class_3102 = class_310.method_1551();
        class_638 class_6382 = class_3102.field_1687;
        if (class_6382 != this.lastLevel) {
            this.o();
            this.lastLevel = class_6382;
            this.c();
        }
        if (class_6382 == null) return;
        ++this.ticks;
        if (this.spreadRadius.getInt() != this.appliedRadius) {
            this.o();
            this.c();
        }
        long l = System.nanoTime() + 3000000L;
        while (!this.queue.isEmpty() && System.nanoTime() < l) {
            int n;
            long l2 = this.queue.dequeueLong();
            this.queued.remove(l2);
            int n2 = class_1923.method_8325((long)l2);
            if (!WorldUtil2.isLoaded(class_6382, n2, n = class_1923.method_8332((long)l2))) continue;
            this.i(l2, class_6382.method_8497(n2, n), class_6382);
            this.scannedChunks.add(l2);
            this.visibleDirty = true;
        }
        if (this.visibleDirty || ++this.visibleAge >= 20) {
            this.visible = this.p(class_6382);
            this.visibleDirty = false;
            this.visibleAge = 0;
        }
        if (!this.detectMined.get() || ++this.minedAge < 20) return;
        this.minedChunks = this.L(class_6382);
        this.minedAge = 0;
    }

    private void i(long l, class_2818 class_28182, class_638 class_6382) {
        int n = this.spreadRadius.getInt();
        int n2 = class_1923.method_8325((long)l);
        int n3 = class_1923.method_8332((long)l);
        int n4 = this.chunkScore.getOrDefault(l, 0);
        boolean bl = this.chunkUngrown.getOrDefault(l, false);
        if (n4 > 0) {
            NoGeodeFinder.h(n2, n3, n, arg_0 -> this.lmbd$updateChunk$0(n4, arg_0));
        }
        if (bl) {
            NoGeodeFinder.h(n2, n3, n, this::lmbd$updateChunk$1);
        }
        this.chunkHasPacket.put(l, NoGeodeFinder.F(class_28182, -16, 30));
        HasUngrown2 hasUngrown2 = this.A(class_28182, class_6382);
        this.chunkScore.put(l, hasUngrown2.selfHeat());
        this.chunkUngrown.put(l, hasUngrown2.hasUngrown());
        if (hasUngrown2.hasUngrown()) {
            NoGeodeFinder.h(n2, n3, n, this::lmbd$updateChunk$2);
        }
        if (hasUngrown2.selfHeat() > 0) {
            NoGeodeFinder.h(n2, n3, n, arg_0 -> this.lmbd$updateChunk$3(hasUngrown2, arg_0));
        }
        if (!this.detectMined.get()) return;
        this.j(l, class_28182, class_6382);
    }

    private static void h(int n, int n2, int n3, LongConsumer longConsumer) {
        for (int i = -n3; i <= n3; ++i) {
            for (int j = -n3; j <= n3; ++j) {
                longConsumer.accept(class_1923.method_8331((int)(n + i), (int)(n2 + j)));
            }
        }
    }

    private static void k(Long2IntOpenHashMap long2IntOpenHashMap, long l, int n) {
        int n2 = long2IntOpenHashMap.get(l) - n;
        if (n2 > 0) {
            long2IntOpenHashMap.put(l, n2);
            return;
        } else {
            long2IntOpenHashMap.remove(l);
        }
    }

    private static boolean F(class_2818 class_28182, int n, int n2) {
        class_2826[] class_2826Array = class_28182.method_12006();
        int n3 = class_28182.method_32891();
        for (int i = 0; i < class_2826Array.length; ++i) {
            int n4;
            class_2826 class_28262 = class_2826Array[i];
            if (class_28262 == null || class_28262.method_38292() || (n4 = n3 + i << 4) + 15 < n || n4 > n2) continue;
            for (int j = 0; j < 16; ++j) {
                int n5 = n4 + j;
                if (n5 < n || n5 > n2) continue;
                for (int k = 0; k < 16; ++k) {
                    for (int i2 = 0; i2 < 16; ++i2) {
                        if (class_28262.method_12254(k, j, i2).method_26215()) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private HasUngrown2 A(class_2818 class_28182, class_638 class_6382) {
        if (this.method.is("Advanced Scan")) {
            return new HasUngrown2(this.glow.scan(class_6382, class_28182, null) / 12, false);
        }
        class_2826[] class_2826Array = class_28182.method_12006();
        int n = class_28182.method_32891();
        class_1923 class_19232 = class_28182.method_12004();
        boolean bl = NoGeodeFinder.a();
        int n2 = 0;
        int n3 = 0;
        boolean bl2 = false;
        boolean bl3 = false;
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        for (int i = 0; i < class_2826Array.length; ++i) {
            class_2826 class_28262 = class_2826Array[i];
            if (class_28262 == null || class_28262.method_38292()) continue;
            if (bl) {
                if (!bl2 && class_28262.method_19523(NoGeodeFinder::q)) {
                    bl2 = true;
                }
                if (bl3 || !class_28262.method_19523(NoGeodeFinder::lmbd$scoreChunk$0)) continue;
                bl3 = true;
                continue;
            }
            if (!class_28262.method_19523(NoGeodeFinder::n)) continue;
            int n4 = n + i << 4;
            for (int j = 0; j < 16; ++j) {
                for (int k = 0; k < 16; ++k) {
                    for (int i2 = 0; i2 < 16; ++i2) {
                        class_2680 class_26802 = class_28262.method_12254(j, k, i2);
                        if (class_26802.method_27852(class_2246.field_27161)) {
                            ++n2;
                            continue;
                        }
                        if (!NoGeodeFinder.q(class_26802) || !class_26802.method_28498((class_2769)class_2741.field_12525)) continue;
                        class_2350 class_23502 = (class_2350)class_26802.method_11654((class_2769)class_2741.field_12525);
                        class_23392.method_10103(class_19232.method_8326() + j, n4 + k, class_19232.method_8328() + i2).method_10098(class_23502.method_10153());
                        if (class_6382.method_8320((class_2338)class_23392).method_27852(class_2246.field_27160)) {
                            ++n3;
                            continue;
                        }
                        ++n2;
                    }
                }
            }
        }
        if (!bl) return new HasUngrown2(n2, n3 > 0);
        if (bl2) {
            ++n3;
            return new HasUngrown2(n2, n3 > 0);
        } else {
            if (!bl3) return new HasUngrown2(n2, n3 > 0);
            ++n2;
        }
        return new HasUngrown2(n2, n3 > 0);
    }

    private void j(long l, class_2818 class_28182, class_638 class_6382) {
        int n;
        int n2;
        this.geodeScanTicks.put(l, this.ticks);
        if (this.geodeSlices.remove(l) != null) {
            this.geodeClustersDirty = true;
        }
        this.geodeWaiting.remove(l);
        int n3 = class_1923.method_8325((long)l);
        int n4 = class_1923.method_8332((long)l);
        for (int i = -1; i <= 1; ++i) {
            for (n2 = -1; n2 <= 1; ++n2) {
                long l2 = class_1923.method_8331((int)(n3 + i), (int)(n4 + n2));
                if (i == 0 && n2 == 0 || (this.geodeWaiting.get(l2) & NoGeodeFinder.S(-i, -n2)) == 0) continue;
                this.N(l2);
            }
        }
        if (!WorldUtil2.isOverworld(class_6382)) return;
        class_2826[] class_2826Array = class_28182.method_12006();
        n2 = class_28182.method_32891();
        int n5 = n3 << 4;
        int n6 = n4 << 4;
        LongArrayList longArrayList = new LongArrayList();
        LongArrayList longArrayList2 = new LongArrayList();
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        int n7 = 0;
        for (int i = 0; i < class_2826Array.length && (n = n2 + i << 4) <= 47; ++i) {
            class_2826 class_28262 = class_2826Array[i];
            if (class_28262 == null || class_28262.method_38292() || !class_28262.method_19523(NoGeodeFinder::u)) continue;
            for (int j = 0; j < 16; ++j) {
                for (int k = 0; k < 16; ++k) {
                    for (int i2 = 0; i2 < 16; ++i2) {
                        class_2680 class_26802 = class_28262.method_12254(i2, j, k);
                        if (!NoGeodeFinder.u(class_26802)) continue;
                        int n8 = n5 + i2;
                        int n9 = n + j;
                        int n10 = n6 + k;
                        boolean bl = false;
                        int n11 = 0;
                        for (class_2350 class_23502 : SIDES) {
                            boolean bl2;
                            int n12 = n8 + class_23502.method_10148();
                            int n13 = n9 + class_23502.method_10164();
                            int n14 = n10 + class_23502.method_10165();
                            if (class_6382.method_31601(n13)) continue;
                            int n15 = n12 >> 4;
                            int n16 = n14 >> 4;
                            boolean bl3 = bl2 = n15 == n3 && n16 == n4;
                            if (!bl2 && !WorldUtil2.isLoaded(class_6382, n15, n16)) {
                                n11 |= NoGeodeFinder.S(n15 - n3, n16 - n4);
                                continue;
                            }
                            class_23392.method_10103(n12, n13, n14);
                            if (!NoGeodeFinder.J(bl2 ? class_28182.method_8320((class_2338)class_23392) : class_6382.method_8320((class_2338)class_23392))) continue;
                            bl = true;
                            break;
                        }
                        if (!bl) {
                            n7 |= n11;
                            continue;
                        }
                        long l3 = class_2338.method_10064((int)n8, (int)n9, (int)n10);
                        longArrayList.add(l3);
                        if (!class_26802.method_27852(class_2246.field_27160)) continue;
                        longArrayList2.add(l3);
                    }
                }
            }
        }
        if (n7 != 0) {
            this.geodeWaiting.put(l, n7);
        }
        if (longArrayList.isEmpty()) return;
        this.geodeSlices.put(l, new Budding(longArrayList.toLongArray(), longArrayList2.toLongArray()));
        this.geodeClustersDirty = true;
    }

    private static int S(int n, int n2) {
        return 1 << (n + 1) * 3 + n2 + 1;
    }

    private LongOpenHashSet L(class_638 class_6382) {
        if (this.geodeSlices.keySet().removeIf(arg_0 -> NoGeodeFinder.lmbd$computeMined$0(class_6382, arg_0))) {
            this.geodeClustersDirty = true;
        }
        this.geodeWaiting.keySet().removeIf(arg_0 -> NoGeodeFinder.lmbd$computeMined$1(class_6382, arg_0));
        this.geodeScanTicks.keySet().removeIf(arg_0 -> NoGeodeFinder.lmbd$computeMined$2(class_6382, arg_0));
        if (this.geodeClustersDirty) {
            this.geodeClusters = this.C();
            this.geodeClustersDirty = false;
        }
        LongOpenHashSet longOpenHashSet = new LongOpenHashSet();
        for (Budding2 budding2 : this.geodeClusters) {
            boolean bl = budding2.budding() > 0 ? budding2.budding() >= 10 : budding2.lining().length >= 160;
            boolean bl2 = bl;
            if (!bl2 || !this.D(class_6382, budding2) || !NoGeodeFinder.f(class_6382, budding2.lining())) continue;
            longOpenHashSet.add(budding2.chunk());
        }
        return longOpenHashSet;
    }

    private List<Budding2> C() {
        List<Budding2> object22;
        Long2ObjectOpenHashMap long2ObjectOpenHashMap = new Long2ObjectOpenHashMap();
        LongOpenHashSet longOpenHashSet = new LongOpenHashSet();
        for (Budding budding3 : this.geodeSlices.values()) {
            for (long l : budding3.lining()) {
                long l2 = class_2338.method_10064((int)(class_2338.method_10061((long)l) >> 2), (int)(class_2338.method_10071((long)l) >> 2), (int)(class_2338.method_10083((long)l) >> 2));
                LongArrayList longArrayList = (LongArrayList)long2ObjectOpenHashMap.get(l2);
                if (longArrayList == null) {
                    longArrayList = new LongArrayList();
                    long2ObjectOpenHashMap.put(l2, (Object)longArrayList);
                }
                longArrayList.add(l);
            }
            for (long l : budding3.budding()) {
                longOpenHashSet.add(l);
            }
        }
        object22 = new ArrayList<Budding2>();
        LongOpenHashSet longOpenHashSet2 = new LongOpenHashSet();
        LongArrayFIFOQueue longArrayFIFOQueue = new LongArrayFIFOQueue();
        LongIterator longIterator = long2ObjectOpenHashMap.keySet().iterator();
        while (longIterator.hasNext()) {
            long l;
            l = longIterator.next();
            if (!longOpenHashSet2.add(l)) continue;
            LongArrayList longArrayList = new LongArrayList();
            longArrayFIFOQueue.enqueue(l);
            while (!longArrayFIFOQueue.isEmpty()) {
                long l3 = longArrayFIFOQueue.dequeueLong();
                longArrayList.addAll((LongList)long2ObjectOpenHashMap.get(l3));
                int n = class_2338.method_10061((long)l3);
                int n2 = class_2338.method_10071((long)l3);
                int n3 = class_2338.method_10083((long)l3);
                for (int i = -1; i <= 1; ++i) {
                    for (int j = -1; j <= 1; ++j) {
                        for (int k = -1; k <= 1; ++k) {
                            long l4 = class_2338.method_10064((int)(n + i), (int)(n2 + j), (int)(n3 + k));
                            if (!long2ObjectOpenHashMap.containsKey(l4) || !longOpenHashSet2.add(l4)) continue;
                            longArrayFIFOQueue.enqueue(l4);
                        }
                    }
                }
            }
            object22.add(NoGeodeFinder.E(longArrayList.toLongArray(), longOpenHashSet));
        }
        return object22;
    }

    private static Budding2 E(long[] lArray, LongOpenHashSet longOpenHashSet) {
        int n = 0;
        int n2 = Integer.MAX_VALUE;
        int n3 = Integer.MAX_VALUE;
        int n4 = Integer.MIN_VALUE;
        int n5 = Integer.MIN_VALUE;
        long l = 0L;
        long l2 = 0L;
        for (long l3 : lArray) {
            if (longOpenHashSet.contains(l3)) {
                ++n;
            }
            int n6 = class_2338.method_10061((long)l3);
            int n7 = class_2338.method_10083((long)l3);
            n2 = Math.min(n2, n6);
            n3 = Math.min(n3, n7);
            n4 = Math.max(n4, n6);
            n5 = Math.max(n5, n7);
            l += (long)n6;
            l2 += (long)n7;
        }
        int n8 = (int)Math.floorDiv(l, lArray.length);
        int n9 = (int)Math.floorDiv(l2, lArray.length);
        return new Budding2(lArray, n, n2, n3, n4, n5, class_1923.method_8331((int)(n8 >> 4), (int)(n9 >> 4)));
    }

    private boolean D(class_638 class_6382, Budding2 budding2) {
        for (int i = budding2.minX() - 1 >> 4; i <= budding2.maxX() + 1 >> 4; ++i) {
            for (int j = budding2.minZ() - 1 >> 4; j <= budding2.maxZ() + 1 >> 4; ++j) {
                long l = class_1923.method_8331((int)i, (int)j);
                if (!WorldUtil2.isLoaded(class_6382, i, j) || !this.geodeScanTicks.containsKey(l)) {
                    return false;
                }
                if (this.ticks - this.geodeScanTicks.get(l) >= 40) continue;
                return false;
            }
        }
        return true;
    }

    private static boolean f(class_638 class_6382, long[] lArray) {
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        Long2IntOpenHashMap long2IntOpenHashMap = new Long2IntOpenHashMap();
        for (long l : lArray) {
            int n = class_2338.method_10061((long)l);
            int n2 = class_2338.method_10071((long)l);
            int n3 = class_2338.method_10083((long)l);
            for (class_2350 class_23502 : SIDES) {
                class_23392.method_10103(n + class_23502.method_10148(), n2 + class_23502.method_10164(), n3 + class_23502.method_10165());
                if (NoGeodeFinder.n(class_6382.method_8320((class_2338)class_23392))) {
                    return false;
                }
                int n4 = class_6382.method_8314(class_1944.field_9282, (class_2338)class_23392);
                if (n4 <= 0 || NoGeodeFinder.H(class_6382, (class_2338)class_23392, n4, long2IntOpenHashMap) == 14) continue;
                return false;
            }
        }
        return true;
    }

    private static int H(class_638 class_6382, class_2338 class_23382, int n, Long2IntOpenHashMap long2IntOpenHashMap) {
        int n2;
        LongArrayList longArrayList = new LongArrayList();
        class_2338.class_2339 class_23392 = class_23382.method_25503();
        class_2338.class_2339 class_23393 = new class_2338.class_2339();
        while (true) {
            long l;
            if (long2IntOpenHashMap.containsKey(l = class_23392.method_10063())) {
                n2 = long2IntOpenHashMap.get(l);
                break;
            }
            longArrayList.add(l);
            class_2350 class_23502 = null;
            int n3 = n;
            for (class_2350 class_23503 : SIDES) {
                int n4 = class_6382.method_8314(class_1944.field_9282, (class_2338)class_23393.method_25505((class_2382)class_23392, class_23503));
                if (n4 <= n3) continue;
                n3 = n4;
                class_23502 = class_23503;
            }
            if (class_23502 == null) {
                n2 = n;
                break;
            }
            class_23392.method_10098(class_23502);
            n = n3;
        }
        for (int i = 0; i < longArrayList.size(); ++i) {
            long2IntOpenHashMap.put(longArrayList.getLong(i), n2);
        }
        return n2;
    }

    private static boolean u(class_2680 class_26802) {
        if (class_26802.method_27852(class_2246.field_27159)) return true;
        if (!class_26802.method_27852(class_2246.field_27160)) return false;
        return true;
    }

    private static boolean J(class_2680 class_26802) {
        if (class_5543.method_31626((class_2680)class_26802)) return true;
        if (!NoGeodeFinder.n(class_26802)) return false;
        return true;
    }

    private static boolean q(class_2680 class_26802) {
        class_2248 class_22482 = class_26802.method_26204();
        if (class_22482 == class_2246.field_27164) return true;
        if (class_22482 == class_2246.field_27163) return true;
        if (class_22482 != class_2246.field_27162) return false;
        return true;
    }

    private static boolean n(class_2680 class_26802) {
        if (class_26802.method_27852(class_2246.field_27161)) return true;
        if (!NoGeodeFinder.q(class_26802)) return false;
        return true;
    }

    private static boolean a() {
        class_634 class_6342 = class_310.method_1551().method_1562();
        if (class_6342 == null) {
            return false;
        }
        String string = class_6342.method_52790();
        if (string == null) return false;
        if (!string.contains("DonutFolia")) return false;
        return true;
    }

    private Long2IntOpenHashMap p(class_638 class_6382) {
        Long2IntOpenHashMap long2IntOpenHashMap = new Long2IntOpenHashMap();
        for (Long2IntMap.Entry entry : this.heat.long2IntEntrySet()) {
            int n;
            int n2;
            long l = entry.getLongKey();
            if (this.vetoes.containsKey(l) || !WorldUtil2.isLoaded(class_6382, n2 = class_1923.method_8325((long)l), n = class_1923.method_8332((long)l)) || this.t(n2, n) < 3) continue;
            long2IntOpenHashMap.put(l, entry.getIntValue());
        }
        int n = this.sensitivity.getInt();
        int n3 = this.appliedRadius;
        Long2IntOpenHashMap long2IntOpenHashMap2 = new Long2IntOpenHashMap();
        for (Long2IntMap.Entry entry : long2IntOpenHashMap.long2IntEntrySet()) {
            int n4;
            long l = entry.getLongKey();
            int n5 = entry.getIntValue();
            if (n5 < (n4 = this.chunkHasPacket.getOrDefault(l, true) ? n : 1) || !NoGeodeFinder.Q(long2IntOpenHashMap, l, n5, n3)) continue;
            long2IntOpenHashMap2.put(l, n5);
        }
        return long2IntOpenHashMap2;
    }

    private static boolean Q(Long2IntOpenHashMap long2IntOpenHashMap, long l, int n, int n2) {
        int n3 = class_1923.method_8325((long)l);
        int n4 = class_1923.method_8332((long)l);
        for (int i = -n2; i <= n2; ++i) {
            for (int j = -n2; j <= n2; ++j) {
                if (i == 0 && j == 0 || long2IntOpenHashMap.get(class_1923.method_8331((int)(n3 + i), (int)(n4 + j))) <= n) continue;
                return false;
            }
        }
        return true;
    }

    private int t(int n, int n2) {
        int n3 = 0;
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                if (i == 0 && j == 0 || !this.scannedChunks.contains(class_1923.method_8331((int)(n + i), (int)(n2 + j)))) continue;
                ++n3;
            }
        }
        return n3;
    }

    @MacroSubscribe
    public void onMacroRender3D(MacroRender3DEvent macroRender3DEvent) {
        if (class_310.method_1551().field_1687 == null) return;
        this.chunkOverlay.draw(this.visible.keySet(), this.chunkColor.argb(), macroRender3DEvent.partialTick);
        if (this.tracers.get()) {
            this.chunkAreas.drawTracers(this.visible.keySet(), 63.0, class_9848.method_61334((int)this.chunkColor.argb()));
        }
        this.minedOverlay.draw((LongSet)this.minedChunks, this.minedColor.argb(), macroRender3DEvent.partialTick);
        if (!this.tracers.get()) return;
        this.minedAreas.drawTracers((LongSet)this.minedChunks, 63.0, class_9848.method_61334((int)this.minedColor.argb()));
    }

    private static boolean lmbd$computeMined$2(class_638 class_6382, long l) {
        if (WorldUtil2.isLoaded(class_6382, class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }

    private static boolean lmbd$computeMined$1(class_638 class_6382, long l) {
        if (WorldUtil2.isLoaded(class_6382, class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }

    private static boolean lmbd$computeMined$0(class_638 class_6382, long l) {
        if (WorldUtil2.isLoaded(class_6382, class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }

    private static boolean lmbd$scoreChunk$0(class_2680 class_26802) {
        return class_26802.method_27852(class_2246.field_27161);
    }

    private void lmbd$updateChunk$3(HasUngrown2 hasUngrown2, long l) {
        this.heat.addTo(l, hasUngrown2.selfHeat());
    }

    private void lmbd$updateChunk$2(long l) {
        this.vetoes.addTo(l, 1);
    }

    private void lmbd$updateChunk$1(long l) {
        NoGeodeFinder.k(this.vetoes, l, 1);
    }

    private void lmbd$updateChunk$0(int n, long l) {
        NoGeodeFinder.k(this.heat, l, n);
    }

    private void lmbd$new$0() {
        this.visibleDirty = true;
    }

    static {
        a = new String[]{"Tracers", "detect-mined-clusters", "Finds grown or mined-out geodes, including servers that hide amethyst growth.", "mined-color", "Simulation Distance", "tracers", "Classic", "Mined Color", "Advanced Scan", "Geode Color", "no-geode-finder", "DonutFolia", "Classic", "No Geode Finder", "method", "spread-radius", "Advanced Scan", "chunk-color", "packet-sensitivity", "Sensitivity", "Detect Mined Clusters", "Method"};
        METHOD_CLASSIC = a[6];
        METHOD_ANBS = a[8];
        SIDES = class_2350.values();
    }
}
