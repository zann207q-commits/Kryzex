package kryzex.modules.donut;

import java.util.List;
import net.minecraft.class_1923;
import net.minecraft.class_2338;

class ChunkCluster {
    public final class_1923 pos;
    public final int hits;
    public final List<class_2338> clusterPositions;

    public ChunkCluster(class_1923 pos, int hits, List<class_2338> clusterPositions) {
        this.pos = pos;
        this.hits = hits;
        this.clusterPositions = clusterPositions;
    }

    public class_1923 pos() {
        return this.pos;
    }

    public int hits() {
        return this.hits;
    }

    public List<class_2338> clusterPositions() {
        return this.clusterPositions;
    }
    private static final String SxFyOw7E2eAuhsxyFvs = "53926c696f25b289";
}
