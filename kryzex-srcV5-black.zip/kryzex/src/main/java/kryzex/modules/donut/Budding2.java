package kryzex.modules.donut;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class Budding2 {
    public final long[] lining;
    public final int budding;
    public final int minX;
    public final int minZ;
    public final int maxX;
    public final int maxZ;
    public final long chunk;

    public Budding2(long[] lining, int budding, int minX, int minZ, int maxX, int maxZ, long chunk) {
        this.lining = lining;
        this.budding = budding;
        this.minX = minX;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxZ = maxZ;
        this.chunk = chunk;
    }

    public long[] lining() {
        return this.lining;
    }

    public int budding() {
        return this.budding;
    }

    public int minX() {
        return this.minX;
    }

    public int minZ() {
        return this.minZ;
    }

    public int maxX() {
        return this.maxX;
    }

    public int maxZ() {
        return this.maxZ;
    }

    public long chunk() {
        return this.chunk;
    }
}
