package kryzex.modules.donut;

import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.NumberSetting;
import kryzex.util.SecureString;
import kryzex.util.InventoryUtil;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class AutoSpawnerSell
extends Module {
    private static String[] a;
    private final NumberSetting dropDelay = new NumberSetting(SecureString.of("Drop Delay"), 0.0, 120.0, 30.0, 1.0).getValue(SecureString.of("How often it should start dropping bones in minutes"));
    private final NumberSetting pageAmount = new NumberSetting(SecureString.of("Page Amount"), 1.0, 10.0, 2.0, 1.0).getValue(SecureString.of("How many pages should it drop before selling"));
    private final NumberSetting pageSwitchDelay = new NumberSetting(SecureString.of("Page Switch Delay"), 0.0, 720.0, 4.0, 1.0).getValue(SecureString.of("How often it should switch pages in seconds"));
    private final NumberSetting delay = new NumberSetting(SecureString.of("delay"), 0.0, 20.0, 1.0, 1.0).getValue(SecureString.of("What should be delay in ticks"));
    private int delayCounter;
    private int pageCounter;
    private boolean isProcessing;
    private boolean isSelling;
    private boolean isPageSwitching;

    public AutoSpawnerSell() {
        super(SecureString.of("Auto Spawner Sell"), SecureString.of("Automatically drops bones from spawner and sells them"), -1, Category.MISC);
        this.addSettings(this.dropDelay, this.pageAmount, this.pageSwitchDelay, this.delay);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.delayCounter = 20;
        this.isProcessing = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.delayCounter > 0) {
            --this.delayCounter;
            return;
        } else {
            if (this.mc.field_1724 == null) return;
            if (this.pageCounter >= this.pageAmount.getIntValue()) {
                this.isSelling = true;
                this.pageCounter = 0;
                this.delayCounter = 40;
                return;
            } else if (!this.isSelling) {
                class_1703 class_17032 = this.mc.field_1724.field_7512;
                if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
                    class_304.method_1420((class_3675.class_306)class_3675.class_307.field_1672.method_1447(1));
                    this.delayCounter = 20;
                    return;
                }
                if (class_17032.method_7611(15).method_7677().method_31574(class_1802.field_8581)) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 15, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                    this.delayCounter = 10;
                    return;
                }
                if (this.mc.field_1724.field_7512.method_7611(13).method_7677().method_31574(class_1802.field_8398)) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 11, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
                    this.delayCounter = 20;
                    return;
                }
                if (!this.mc.field_1724.field_7512.method_7611(53).method_7677().method_31574(class_1802.field_8695)) {
                    this.mc.field_1724.method_7346();
                    this.delayCounter = 20;
                    return;
                }
                if (this.mc.field_1724.field_7512.method_7611(48).method_7677().method_31574(class_1802.field_8107)) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 48, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
                    this.delayCounter = 20;
                    return;
                }
                boolean bl = true;
                for (int i = 0; i < 45; ++i) {
                    if (this.mc.field_1724.field_7512.method_7611(i).method_7677().method_31574(class_1802.field_8606)) continue;
                    bl = false;
                    break;
                }
                if (bl) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 52, 1, class_1713.field_7795, (class_1657)this.mc.field_1724);
                    this.isProcessing = true;
                    this.delayCounter = this.pageSwitchDelay.getIntValue() * 20;
                    ++this.pageCounter;
                    return;
                } else if (this.isProcessing) {
                    this.isProcessing = false;
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 50, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
                    this.delayCounter = 20;
                    return;
                } else {
                    this.isProcessing = false;
                    if (this.pageCounter != 0) {
                        this.pageCounter = 0;
                        this.isSelling = true;
                        this.delayCounter = 40;
                        return;
                    }
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 45, 1, class_1713.field_7795, (class_1657)this.mc.field_1724);
                    this.delayCounter = 1200 * this.dropDelay.getIntValue();
                }
                return;
            } else {
                class_1703 class_17033 = this.mc.field_1724.field_7512;
                if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
                    this.mc.method_1562().method_45730("order " + this.C());
                    this.delayCounter = 20;
                    return;
                }
                if (((class_1707)class_17033).method_17388() != 6) {
                    if (((class_1707)class_17033).method_17388() == 4) {
                        int n = InventoryUtil.getSlot(class_1802.field_8162);
                        if (n <= 0) {
                            this.mc.field_1724.method_7346();
                            this.delayCounter = 10;
                            return;
                        }
                        if (this.isPageSwitching && n == 36) {
                            this.isPageSwitching = false;
                            this.mc.field_1724.method_7346();
                            return;
                        }
                        class_1792 class_17922 = this.w();
                        while (true) {
                            int n2 = 36;
                            class_1792 class_17923 = ((class_1799)this.mc.field_1724.field_7512.method_7602().get(36)).method_7909();
                            if (class_17923 == class_1802.field_8162 || class_17923 != class_17922) continue;
                            this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 36, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                            this.delayCounter = this.delay.getIntValue();
                            if (this.delay.getIntValue() != 0) return;
                        }
                    }
                    if (((class_1707)class_17033).method_17388() != 3) return;
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 15, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                    this.isPageSwitching = true;
                    this.delayCounter = 10;
                    return;
                } else {
                    class_1799 class_17992 = class_17033.method_7611(47).method_7677();
                    if (class_17992.method_31574(class_1802.field_8162)) {
                        this.delayCounter = 2;
                        this.mc.field_1724.method_7346();
                        return;
                    }
                    for (Object e : class_17992.method_7950(class_1792.class_9635.method_59528((class_1937)this.mc.field_1687), (class_1657)this.mc.field_1724, (class_1836)class_1836.field_41070)) {
                        String string = e.toString();
                        if (!string.contains("Most Money Per Item") || !((class_2561)e).method_10866().toString().contains("white") && !string.contains("white")) continue;
                        this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 47, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                        this.delayCounter = 5;
                        return;
                    }
                    for (int i = 0; i < 44; ++i) {
                        if (!class_17033.method_7611(i).method_7677().method_31574(this.w())) continue;
                        this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, i, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                        this.delayCounter = 10;
                        return;
                    }
                    this.delayCounter = 40;
                    this.mc.field_1724.method_7346();
                }
            }
        }
    }

    private class_1792 w() {
        for (int i = 0; i < 35; ++i) {
            class_1799 class_17992 = this.mc.field_1724.method_31548().method_5438(i);
            if (class_17992.method_31574(class_1802.field_8162)) continue;
            return class_17992.method_7909();
        }
        return class_1802.field_8162;
    }

    private String C() {
        class_1792 class_17922 = this.w();
        if (class_17922.equals(class_1802.field_8606)) {
            return "Bones";
        }
        String string = class_17922.method_63680().getString();
        return string;
    }

    static {
        a = new String[]{"Auto Spawner Sell", "delay", "Bones", "Automatically drops bones from spawner and sells them", "Page Switch Delay", "Drop Delay", "What should be delay in ticks", "How many pages should it drop before selling", "How often it should switch pages in seconds", "Page Amount", "How often it should start dropping bones in minutes"};
    }
}
