package kryzex.modules.donut;

public enum AuctionMode {
    API("API", 0),
    MANUAL("MANUAL", 1);

    private AuctionMode(String string2, int n2) {
    }
}
