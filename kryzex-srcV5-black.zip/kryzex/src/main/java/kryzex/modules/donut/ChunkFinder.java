package kryzex.modules.donut;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kryzex.client.KryzexClient;
import kryzex.event.BlockStateChangeEvent;
import kryzex.event.ChunkDataEvent;
import kryzex.event.LightUpdateEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.gui.UpdateToast;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.donut.AutoRTP;
import kryzex.modules.donut.Chunk;
import kryzex.util.ChunkLightClassifier;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_368;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class ChunkFinder
extends Module {
    private static final int MAX_FLAGS = 512;
    private static final long DIG_IGNORE_MS = 4000L;
    private static final double DIG_RANGE_SQ = 64.0;
    private static class_3414 FLAG_SOUND;
    private final NumberSetting plateSize = new NumberSetting(SecureString.of("Plate Size"), 1.0, 64.0, 16.0, 0.5);
    private final BoolSetting outline = new BoolSetting(SecureString.of("Outline"), true);
    private final NumberSetting plateThickness = new NumberSetting(SecureString.of("Plate Thickness"), 0.01, 4.0, 0.15, 0.01);
    private final BoolSetting advancementNotifications = new BoolSetting(SecureString.of("Advancement Notifications"), true).setDescription(SecureString.of("Shows a Chunk Finder advancement popup for every new flagged chunk"));
    private final BoolSetting soundPing = new BoolSetting(SecureString.of("Sound Ping"), true).setDescription(SecureString.of("Plays the original Nexus chunk flag sound"));
    private final NumberSetting soundVolume = new NumberSetting(SecureString.of("Sound Volume"), 0.0, 100.0, 100.0, 1.0);
    private final BoolSetting kickOnFlag = new BoolSetting(SecureString.of("Kick On Flag"), false).setDescription(SecureString.of("Disconnects on the next flag, then turns this setting and Auto RTP off"));
    private final ChunkLightClassifier lightCache = new ChunkLightClassifier(this::o);
    private final Map<Long, Chunk> flags = new LinkedHashMap<Long, Chunk>();
    private final Map<Long, Long> recentDigs = new HashMap<Long, Long>();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private Object trackedWorld;
    private static String[] a;

    public ChunkFinder() {
        super(SecureString.of("Chunk Finder"), SecureString.of("detects bases underground [ Only works on DonutSMP]"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.plateSize, this.plateThickness, this.outline, this.advancementNotifications, this.soundPing, this.soundVolume, this.kickOnFlag});
    }

    @Override
    public void onEnable() {
        this.h();
        this.trackedWorld = this.mc.field_1687;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.h();
        super.onDisable();
    }

    private void h() {
        this.lightCache.e();
        this.flags.clear();
        this.recentDigs.clear();
        this.renderBoxes.clear();
        this.renderLines.clear();
        this.trackedWorld = null;
    }

    private void B() {
        if (this.trackedWorld == this.mc.field_1687) return;
        this.h();
        this.trackedWorld = this.mc.field_1687;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.B();
        if (this.mc.field_1687 == null) return;
        this.lightCache.T(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524(), chunkDataEvent.packet.method_38599());
    }

    @Subscribe
    public void onLightUpdate(LightUpdateEvent lightUpdateEvent) {
        this.B();
        if (this.mc.field_1687 == null) return;
        this.lightCache.T(lightUpdateEvent.packet.method_11558(), lightUpdateEvent.packet.method_11554(), lightUpdateEvent.packet.method_38600());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        this.B();
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) return;
        this.lightCache.C(this.mc.field_1687.method_32890(), this.mc.field_1687.method_32891());
    }

    @Subscribe
    public void onBlockStateChange(BlockStateChangeEvent blockStateChangeEvent) {
        if (this.mc.field_1724 == null || blockStateChangeEvent.pos == null || !(this.mc.field_1724.method_5707(class_243.method_24953((class_2382)blockStateChangeEvent.pos)) <= 64.0)) return;
        this.recentDigs.put(class_1923.method_8331((int)(blockStateChangeEvent.pos.method_10263() >> 4), (int)(blockStateChangeEvent.pos.method_10260() >> 4)), System.currentTimeMillis());
    }

    private boolean V(int n, int n2) {
        long l = System.currentTimeMillis();
        this.recentDigs.values().removeIf(arg_0 -> ChunkFinder.lmbd$nearRecentDig$0(l, arg_0));
        for (long l2 : this.recentDigs.keySet()) {
            if (Math.abs(class_1923.method_8325((long)l2) - n) > 1 || Math.abs(class_1923.method_8332((long)l2) - n2) > 1) continue;
            return true;
        }
        return false;
    }

    private void o(int n, int n2, int n3) {
        if (this.V(n, n2)) return;
        int n4 = (n << 4) + 8;
        int n5 = (n2 << 4) + 8;
        int n6 = this.mc.field_1687 != null && this.mc.field_1687.method_8393(n, n2) ? Math.max(21, this.mc.field_1687.method_8624(class_2902.class_2903.field_13202, n4, n5)) : 21;
        this.E(new class_2338(n4, n6, n5));
    }

    private void E(class_2338 class_23382) {
        class_1923 class_19232 = new class_1923(class_23382);
        Chunk chunk = new Chunk(class_19232, Math.max(21, class_23382.method_10264()), class_23382.method_10263(), class_23382.method_10260());
        if (this.flags.putIfAbsent(class_19232.method_8324(), chunk) != null) return;
        if (this.flags.size() > 512) {
            this.flags.remove(this.flags.keySet().iterator().next());
        }
        if (this.advancementNotifications.getValue()) {
            this.r(chunk);
        }
        if (this.soundPing.getValue()) {
            float f = (float)this.soundVolume.getIntValue() / 100.0f;
            this.mc.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)FLAG_SOUND, 1.0f, (float)f));
        }
        if (!this.kickOnFlag.getValue() || this.mc.method_1562() == null) return;
        this.kickOnFlag.setValue(false);
        AutoRTP autoRTP = (AutoRTP)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(AutoRTP.class);
        if (autoRTP != null) {
            autoRTP.toggle(false);
        }
        KryzexClient.INSTANCE.getSettingsManager().saveNow();
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("Kicked - Chunk Finder flagged X: " + chunk.x() + " Z: " + chunk.z() + "\nKick On Flag was automatically turned OFF.")));
    }

    private void r(Chunk chunk) {
        this.mc.method_1566().method_1999((class_368)new UpdateToast(chunk.x(), chunk.z()));
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.flags.isEmpty() || this.mc.field_1724 == null || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        this.renderBoxes.clear();
        this.renderLines.clear();
        double d = this.plateSize.getValue() / 2.0;
        double d2 = this.plateThickness.getValue();
        Color color = new Color(0, 255, 70, 75);
        Color color2 = new Color(0, 255, 70, 220);
        class_1923 class_19232 = this.mc.field_1724.method_31476();
        for (Chunk chunk : this.flags.values()) {
            if (Math.abs(chunk.chunk().field_9181 - class_19232.field_9181) > 24 || Math.abs(chunk.chunk().field_9180 - class_19232.field_9180) > 24) continue;
            double d3 = chunk.chunk().method_33940();
            double d4 = chunk.chunk().method_33942();
            double d5 = (double)chunk.y() + 1.002;
            this.renderBoxes.add(new kryzex.util.Color(d3 - d, d5, d4 - d, d3 + d, d5 + d2, d4 + d, color));
            if (!this.outline.getValue()) continue;
            InverseProjectionScratch.addBoxOutline(this.renderLines, d3 - d, d5, d4 - d, d3 + d, d5 + d2, d4 + d, color2, 1.5f);
        }
        if (this.renderBoxes.isEmpty()) return;
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        if (!this.renderLines.isEmpty()) {
            InverseProjectionScratch.renderLines(class_45872, this.renderLines);
        }
        class_45872.method_22909();
    }

    private static boolean lmbd$nearRecentDig$0(long l, Long l2) {
        if (l - l2 <= 4000L) return false;
        return true;
    }

    static {
        String[] stringArray = a = new String[]{"Sound Volume", "Kick On Flag", "Plate Thickness", "chunk_flag", "Shows a Chunk Finder advancement popup for every new flagged chunk", "Disconnects on the next flag, then turns this setting and Auto RTP off", "r87f4560b4c09f4", "Advancement Notifications", "Sound Ping", " Z: ", "Plays the original Nexus chunk flag sound", "detects bases underground [ Only works on DonutSMP]", "Chunk Finder", "Plate Size", "Kicked - Chunk Finder flagged X: ", "Outline", "\nKick On Flag was automatically turned OFF."};
        FLAG_SOUND = class_3414.method_47908((class_2960)class_2960.method_60655((String)stringArray[6], (String)stringArray[3]));
    }
}
