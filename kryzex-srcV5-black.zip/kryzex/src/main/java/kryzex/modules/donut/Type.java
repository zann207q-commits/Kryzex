package kryzex.modules.donut;

class Type {
    public final int col;
    public final int row;
    public final int type;

    public Type(int col, int row, int type) {
        this.col = col;
        this.row = row;
        this.type = type;
    }

    public int col() {
        return this.col;
    }

    public int row() {
        return this.row;
    }

    public int type() {
        return this.type;
    }
}
