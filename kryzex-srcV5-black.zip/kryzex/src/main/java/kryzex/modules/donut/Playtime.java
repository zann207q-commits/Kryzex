package kryzex.modules.donut;

final class Playtime {
    public String money = "0";
    public String shards = "0";
    public String kills = "0";
    public String deaths = "0";
    public String playtime = "0";
    public String ping = "0";

    public Playtime() {
    }
}
