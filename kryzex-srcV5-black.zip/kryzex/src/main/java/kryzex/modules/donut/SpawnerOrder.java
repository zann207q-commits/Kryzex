package kryzex.modules.donut;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.modules.donut.InventoryCheck;
import kryzex.util.SecureString;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

public final class SpawnerOrder
extends Module {
    private static String[] a;
    private final StringSetting dropDelayMinutes = new StringSetting(SecureString.of("Drop Delay Minutes"), "5");
    private final NumberSetting actionDelay = new NumberSetting(SecureString.of("Action Delay Ticks"), 1.0, 200.0, 20.0, 1.0);
    private final BoolSetting notifications = new BoolSetting(SecureString.of("Notifications"), true);
    private final NumberSetting pagesToProcess = new NumberSetting(SecureString.of("Spawner Pages"), 1.0, 10.0, 1.0, 1.0);
    private final List<class_2338> spawners = new ArrayList<class_2338>();
    private InventoryCheck state = InventoryCheck.INVENTORY_CHECK;
    private class_2338 target;
    private int actionTimer;
    private int page;
    private boolean secondPageClick;
    private long lastCycle;
    private boolean movingNotice;

    public SpawnerOrder() {
        super(SecureString.of("Spawner Order"), SecureString.of("Drops nearby spawner loot and sells bones and arrows"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.dropDelayMinutes, this.actionDelay, this.notifications, this.pagesToProcess});
    }

    @Override
    public void onEnable() {
        this.state = InventoryCheck.INVENTORY_CHECK;
        this.actionTimer = 0;
        this.page = 0;
        this.secondPageClick = false;
        this.target = null;
        this.spawners.clear();
        this.lastCycle = 0L;
        this.movingNotice = false;
        this.Y("Spawner Order activated.");
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.spawners.clear();
        this.target = null;
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null || this.mc.method_1562() == null) {
            return;
        }
        if (this.state == InventoryCheck.WAITING_CYCLE) {
            if (System.currentTimeMillis() - this.lastCycle < (long)this.L() * 60000L) return;
            this.state = InventoryCheck.INVENTORY_CHECK;
        }
        if (this.actionTimer-- > 0) {
            return;
        }
        this.actionTimer = this.actionDelay.getIntValue();
        switch (this.state.ordinal()) {
            case 0: {
                this.state = this.P() ? InventoryCheck.OPENING_SELL : InventoryCheck.SCANNING;
                return;
            }
            case 1: {
                this.R();
                return;
            }
            case 2: {
                this.O();
                return;
            }
            case 3: {
                this.a();
                return;
            }
            case 4: {
                this.k();
                return;
            }
            case 5: {
                this.w();
                return;
            }
            case 6: {
                this.E();
                return;
            }
        }
    }

    private void R() {
        this.spawners.clear();
        class_2338 class_23382 = this.mc.field_1724.method_24515();
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        for (int i = -5; i <= 5; ++i) {
            for (int j = -5; j <= 5; ++j) {
                for (int k = -5; k <= 5; ++k) {
                    class_23392.method_10103(class_23382.method_10263() + i, class_23382.method_10264() + j, class_23382.method_10260() + k);
                    if (!this.mc.field_1687.method_8320((class_2338)class_23392).method_27852(class_2246.field_10260)) continue;
                    this.spawners.add(class_23392.method_10062());
                }
            }
        }
        this.spawners.sort(Comparator.comparingDouble(this::lmbd$scan$0));
        if (this.spawners.isEmpty()) {
            this.Y("No nearby spawner found; waiting for the next cycle.");
            this.g();
            return;
        }
        this.target = this.spawners.get(0);
        this.state = InventoryCheck.MOVING;
        this.movingNotice = false;
    }

    private void O() {
        if (this.target == null || !this.mc.field_1687.method_8320(this.target).method_27852(class_2246.field_10260)) {
            this.state = InventoryCheck.SCANNING;
            return;
        }
        if (this.mc.field_1724.method_5707(class_243.method_24953((class_2382)this.target)) <= 20.25) {
            this.state = InventoryCheck.OPENING;
            return;
        } else {
            if (this.movingNotice) return;
            this.Y("Move within 4 blocks of the detected spawner.");
            this.movingNotice = true;
        }
    }

    private void a() {
        class_3965 class_39652 = new class_3965(class_243.method_24953((class_2382)this.target), class_2350.field_11036, this.target, false);
        this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, class_39652);
        this.page = 0;
        this.secondPageClick = false;
        this.state = InventoryCheck.DROPPING;
    }

    private void k() {
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) return;
        class_1707 class_17072 = (class_1707)class_17032;
        if (class_17072.field_7761.size() <= 53) {
            return;
        }
        if (!this.secondPageClick) {
            this.G(class_17072, 50, class_1713.field_7790);
            this.secondPageClick = true;
            return;
        }
        this.G(class_17072, 53, class_1713.field_7790);
        this.secondPageClick = false;
        if (++this.page < this.pagesToProcess.getIntValue()) return;
        this.mc.field_1724.method_7346();
        this.state = InventoryCheck.OPENING_SELL;
    }

    private void w() {
        if (this.mc.field_1724.field_7512 instanceof class_1707) {
            this.mc.field_1724.method_7346();
        }
        this.mc.method_1562().method_45730("sell");
        this.state = InventoryCheck.DEPOSITING;
        this.actionTimer = Math.max(20, this.actionDelay.getIntValue());
    }

    private void E() {
        class_1799 class_17992;
        int n;
        int n2;
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            return;
        }
        class_1707 class_17072 = (class_1707)class_17032;
        for (n2 = n = class_17072.method_17388() * 9; n2 < class_17072.field_7761.size(); ++n2) {
            class_17992 = class_17072.method_7611(n2).method_7677();
            if (!class_17992.method_31574(class_1802.field_8606) && !class_17992.method_31574(class_1802.field_8107)) continue;
            this.G(class_17072, n2, class_1713.field_7794);
            return;
        }
        for (n2 = 0; n2 < n; ++n2) {
            class_17992 = class_17072.method_7611(n2).method_7677();
            if (!class_17992.method_31574(class_1802.field_8581) && !class_17992.method_31574(class_1802.field_8656)) continue;
            this.G(class_17072, n2, class_1713.field_7790);
            this.mc.field_1724.method_7346();
            this.Y("Cycle completed. Next cycle in " + this.L() + " minutes.");
            this.g();
            return;
        }
        this.mc.field_1724.method_7346();
        this.g();
    }

    private boolean P() {
        for (class_1799 class_17992 : this.mc.field_1724.method_31548().method_67533()) {
            if (!class_17992.method_31574(class_1802.field_8606) && !class_17992.method_31574(class_1802.field_8107)) continue;
            return true;
        }
        return false;
    }

    private int L() {
        try {
            return Math.max(1, Integer.parseInt(this.dropDelayMinutes.getValue().trim()));
        }
        catch (NumberFormatException numberFormatException) {
            return 5;
        }
    }

    private void g() {
        this.lastCycle = System.currentTimeMillis();
        this.state = InventoryCheck.WAITING_CYCLE;
        this.target = null;
    }

    private void G(class_1707 class_17072, int n, class_1713 class_17132) {
        this.mc.field_1761.method_2906(class_17072.field_7763, n, 0, class_17132, (class_1657)this.mc.field_1724);
    }

    private void Y(String string) {
        if (!this.notifications.getValue() || this.mc.field_1724 == null) return;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7b[Spawner Order] \u00a7f" + string)), false);
    }

    private double lmbd$scan$0(class_2338 class_23382) {
        return this.mc.field_1724.method_5707(class_243.method_24953((class_2382)class_23382));
    }

    static {
        a = new String[]{"Drop Delay Minutes", "Notifications", "Spawner Pages", "\u00a7b[Spawner Order] \u00a7f", "Move within 4 blocks of the detected spawner.", " minutes.", "Drops nearby spawner loot and sells bones and arrows", "Spawner Order", "Cycle completed. Next cycle in ", "Action Delay Ticks", "Spawner Order activated.", "sell"};
    }
}
