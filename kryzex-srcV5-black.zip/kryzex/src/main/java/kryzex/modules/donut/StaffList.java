package kryzex.modules.donut;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.gui.BaseRenderer;
import kryzex.gui.ClickGuiScreen;
import kryzex.gui.Filename;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiRenderer;
import kryzex.gui.GuiSoundType;
import kryzex.gui.Name;
import kryzex.gui.SpeakerOff;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.donut.Drdonutt;
import net.minecraft.class_1041;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import org.lwjgl.glfw.GLFW;

public final class StaffList
extends Module {
    private final BoolSetting showEmpty = new BoolSetting("Show When Empty", true);
    private final BoolSetting avatars = new BoolSetting("Head Avatars", true);
    private final BoolSetting notify = new BoolSetting("Chat Notifications", false);
    private final BoolSetting sound = new BoolSetting("Alert Sound", false);
    private final NumberSetting scale = new NumberSetting("Scale", 0.5, 2.5, 1.0, 0.05);
    private final NumberSetting width = new NumberSetting("Width", 140.0, 450.0, 210.0, 5.0);
    private final NumberSetting opacity = new NumberSetting("Opacity", 0.0, 1.0, 0.62, 0.05);
    private final Filename position = new Filename("kryzex-staff-position.json", 0.013f, 0.13f);
    private final kryzex.gui.StaffList panel = new kryzex.gui.StaffList();
    private Map<String, Name> staff = Map.of();
    private Object world;
    private int ticks;
    private boolean initialized;
    private long lastRender;

    public StaffList() {
        super("Staff List", "Shows staff from player names and scoreboard ranks.", -1, Category.DONUT);
        this.addSettings(new Setting[]{this.showEmpty, this.avatars, this.notify, this.sound, this.scale, this.width, this.opacity});
    }

    @Override
    public void onEnable() {
        this.n();
    }

    @Override
    public void onDisable() {
        this.n();
    }

    private void n() {
        this.staff = Map.of();
        this.panel.reset();
        this.world = null;
        this.ticks = 0;
        this.initialized = false;
        this.lastRender = 0L;
    }

    private static String s(class_2561 class_25612) {
        if (class_25612 == null) {
            return "";
        }
        String string = class_25612.getString();
        return string;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 != null && this.mc.field_1724 != null && this.mc.method_1562() != null) {
            if (this.world != this.mc.field_1687) {
                this.n();
                this.world = this.mc.field_1687;
            }
            if (this.ticks++ % 5 != 0) return;
            TreeMap<String, Name> treeMap = new TreeMap<String, Name>();
            for (net.minecraft.class_640 object2 : this.mc.method_1562().method_2880()) {
                String object3;
                if (object2 == null || object2.method_2966() == null || (object3 = object2.method_2966().name()) == null || object3.isEmpty()) continue;
                class_268 class_2682 = object2.method_2955();
                if (!Drdonutt.n(object3, StaffList.s(object2.method_2971()), class_2682 == null ? "" : class_2682.method_1197(), class_2682 == null ? "" : StaffList.s(class_2682.method_1144()), class_2682 == null ? "" : StaffList.s(class_2682.method_1136()))) continue;
                treeMap.put(object3.toLowerCase(Locale.ROOT), new Name(object3, object2.method_2966().id()));
            }
            for (net.minecraft.class_742 object2 : this.mc.field_1687.method_18456()) {
                String string = object2.method_7334().name();
                if (!Drdonutt.b(string)) continue;
                treeMap.putIfAbsent(string.toLowerCase(Locale.ROOT), new Name(string, object2.method_5667()));
            }
            if (this.initialized) {
                boolean bl = false;
                for (Map.Entry entry : treeMap.entrySet()) {
                    if (this.staff.containsKey(entry.getKey())) continue;
                    bl = true;
                    if (!this.notify.getValue()) continue;
                    this.q(((Name)entry.getValue()).name() + " is now online.");
                }
                if (bl && this.sound.getValue()) {
                    GuiAudio.play(GuiSoundType.CONFIRM);
                }
                if (this.notify.getValue()) {
                    for (Map.Entry entry : this.staff.entrySet()) {
                        if (treeMap.containsKey(entry.getKey())) continue;
                        this.q(((Name)entry.getValue()).name() + " left or vanished.");
                    }
                }
            }
            this.initialized = true;
            if (treeMap.equals(this.staff)) return;
            this.staff = treeMap;
            this.panel.setMembers(List.copyOf(treeMap.values()));
            return;
        } else {
            if (this.world == null) return;
            this.n();
        }
    }

    private void q(String string) {
        if (this.mc.field_1705 == null) return;
        this.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470((String)"Kryzex \u00b7 Staff List  ").method_10852((class_2561)class_2561.method_43470((String)string)));
    }

    @Subscribe
    public void onHudRender(HudRenderEvent hudRenderEvent) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.mc.field_1690.field_1842 || hudRenderEvent.context == null) return;
        class_1041 class_10412 = this.mc.method_22683();
        long l = System.nanoTime();
        float f = this.lastRender == 0L ? 0.016f : Math.min(0.1f, (float)(l - this.lastRender) / 1.0E9f);
        this.lastRender = l;
        float f2 = Math.max(0.45f, (float)class_10412.method_4506() / 1080.0f) * this.scale.getFloatValue();
        float f3 = Math.min(this.width.getFloatValue() * f2, (float)Math.max(1, class_10412.method_4489() - 16));
        float f4 = Math.max(8.0f, Math.min(this.position.x(class_10412.method_4489()), (float)class_10412.method_4489() - f3 - 8.0f));
        float f5 = Math.max(8.0f, Math.min(this.position.y(class_10412.method_4506()), (float)class_10412.method_4506() - 108.0f * f2));
        boolean bl = this.mc.field_1755 instanceof class_408;
        float f6 = Math.min((float)class_10412.method_4506() - f5 - 8.0f, (float)Math.max(78, 54 + 30 * this.staff.size()) * f2);
        this.position.update(bl, GLFW.glfwGetMouseButton((long)class_10412.method_4490(), 0) == 1, this.mc.field_1729.method_1603(), this.mc.field_1729.method_1604(), f4, f5, f3, f6, class_10412.method_4489(), class_10412.method_4506());
        if (this.position.dragging()) {
            f4 = this.position.x(class_10412.method_4489());
            f5 = this.position.y(class_10412.method_4506());
        }
        float f7 = class_10412.method_4495();
        hudRenderEvent.context.method_51448().pushMatrix();
        hudRenderEvent.context.method_51448().scale(1.0f / f7, 1.0f / f7);
        try {
            this.panel.render(new GuiRenderer(hudRenderEvent.context, f7), f4, f5, f3, f2, this.opacity.getFloatValue(), f, !(this.mc.field_1755 instanceof ClickGuiScreen), this.showEmpty.getValue() || bl, this.avatars.getValue(), class_10412.method_4506(), (arg_0, arg_1, arg_2, arg_3, arg_4) -> this.lmbd$onRender$0(hudRenderEvent, arg_0, arg_1, arg_2, arg_3, arg_4));
            return;
        }
        finally {
            hudRenderEvent.context.method_51448().popMatrix();
        }
    }

    private void b(class_332 class_3322, Name name, float f, float f2, float f3, float f4) {
        class_640 class_6402;
        class_640 class_6403 = class_6402 = this.mc.method_1562() == null ? null : this.mc.method_1562().method_2871(name.uuid());
        if (class_6402 == null) {
            new GuiRenderer(class_3322, this.mc.method_22683().method_4495()).icon(SpeakerOff.USER, f, f2, f3, BaseRenderer.white(f4 * 0.5f));
            return;
        } else {
            class_7532.method_44443((class_332)class_3322, (class_8685)class_6402.method_52810(), (int)Math.round(f), (int)Math.round(f2), (int)Math.max(1, Math.round(f3)), (int)BaseRenderer.white(f4));
        }
    }

    private void lmbd$onRender$0(HudRenderEvent hudRenderEvent, Name name, float f, float f2, float f3, float f4) {
        this.b(hudRenderEvent.context, name, f, f2, f3, f4);
    }
}
