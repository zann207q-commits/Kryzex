package kryzex.modules.donut;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_638;

class Source {
    public final String source;
    public final class_2338 pos;
    public final String type;
    public final class_2487 nbt;
    public final class_638 world;

    public Source(String source, class_2338 pos, String type, class_2487 nbt, class_638 world) {
        this.source = source;
        this.pos = pos;
        this.type = type;
        this.nbt = nbt;
        this.world = world;
    }

    public String source() {
        return this.source;
    }

    public class_2338 pos() {
        return this.pos;
    }

    public String type() {
        return this.type;
    }

    public class_2487 nbt() {
        return this.nbt;
    }

    public class_638 world() {
        return this.world;
    }
}
