package kryzex.modules.donut;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.util.SecureString;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.class_9020;
import net.minecraft.class_9022;

public final class FakeScoreboard
extends Module {
    private static String OBJECTIVE;
    private static String TEAM_PREFIX;
    private final StringSetting title = new StringSetting(SecureString.of("Title"), "Kryzex");
    private final BoolSetting showMoney = new BoolSetting(SecureString.of("Money"), true);
    private final StringSetting money = new StringSetting(SecureString.of("Money Amount"), "1M");
    private final BoolSetting showShards = new BoolSetting(SecureString.of("Shards"), true);
    private final StringSetting shards = new StringSetting(SecureString.of("Shards Amount"), "0");
    private final BoolSetting showKills = new BoolSetting(SecureString.of("Kills"), true);
    private final StringSetting kills = new StringSetting(SecureString.of("Kills Amount"), "0");
    private final BoolSetting showDeaths = new BoolSetting(SecureString.of("Deaths"), true);
    private final StringSetting deaths = new StringSetting(SecureString.of("Deaths Amount"), "0");
    private final BoolSetting showPlaytime = new BoolSetting(SecureString.of("Playtime"), true);
    private final StringSetting playtime = new StringSetting(SecureString.of("Playtime Amount"), "0h");
    private final List<String> teamNames = new ArrayList<String>();
    private class_266 ours;
    private class_266 serverObjective;
    private Object trackedWorld;
    private long lastRefresh;
    private static String[] a;

    public FakeScoreboard() {
        super(SecureString.of("Fake Scoreboard"), SecureString.of("Replaces the sidebar with your own configurable scoreboard"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.title, this.showMoney, this.money, this.showShards, this.shards, this.showKills, this.kills, this.showDeaths, this.deaths, this.showPlaytime, this.playtime});
    }

    @Override
    public void onEnable() {
        this.lastRefresh = 0L;
        this.trackedWorld = this.mc.field_1687;
        this.W();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.j();
        this.trackedWorld = null;
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        long l;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        if (this.trackedWorld != this.mc.field_1687) {
            this.ours = null;
            this.serverObjective = null;
            this.teamNames.clear();
            this.trackedWorld = this.mc.field_1687;
            this.lastRefresh = 0L;
        }
        if ((l = System.currentTimeMillis()) - this.lastRefresh < 1000L) {
            return;
        }
        this.lastRefresh = l;
        this.W();
    }

    private void W() {
        String[] stringArray;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        class_269 class_2692 = this.mc.field_1687.method_8428();
        class_266 class_2662 = class_2692.method_1189(class_8646.field_45157);
        if (class_2662 != null) {
            stringArray = a;
            if (!"kryzex_fake_scoreboard".equals(class_2662.method_1113())) {
                this.serverObjective = class_2662;
            }
        }
        this.o(class_2692);
        stringArray = a;
        class_266 class_2663 = class_2692.method_1170("kryzex_fake_scoreboard");
        if (class_2663 != null) {
            class_2692.method_1194(class_2663);
        }
        this.ours = class_2692.method_1168("kryzex_fake_scoreboard", class_274.field_1468, (class_2561)class_2561.method_43470((String)this.title.getValue()), class_274.class_275.field_1472, false, (class_9022)class_9020.field_47557);
        class_2692.method_1158(class_8646.field_45157, this.ours);
        List<class_5250> list = this.v();
        for (int i = 0; i < list.size(); ++i) {
            String string = "kryzex_sb_" + i;
            this.teamNames.add(string);
            class_268 class_2682 = class_2692.method_1153(string);
            if (class_2682 != null) {
                class_2692.method_1191(class_2682);
            }
            class_268 class_2683 = class_2692.method_1171(string);
            class_2683.method_1138((class_2561)list.get(i));
            String string2 = "\u00a7" + Integer.toHexString(i);
            class_9015 class_90152 = class_9015.method_55422((String)string2);
            class_2692.method_1155(class_90152, this.ours);
            class_9014 class_90142 = class_2692.method_1180(class_90152, this.ours);
            class_90142.method_55410(list.size() - i);
            class_2692.method_1172(string2, class_2683);
        }
    }

    private List<class_5250> v() {
        String[] stringArray;
        ArrayList<class_5250> arrayList = new ArrayList<class_5250>();
        if (this.showMoney.getValue()) {
            stringArray = a;
            arrayList.add(this.N("$ ", class_124.field_1060, this.money.getValue()));
        }
        if (this.showShards.getValue()) {
            stringArray = a;
            arrayList.add(this.N("\u2726 ", class_124.field_1076, this.shards.getValue()));
        }
        if (this.showKills.getValue()) {
            stringArray = a;
            arrayList.add(this.N("\u2694 ", class_124.field_1061, this.kills.getValue()));
        }
        if (this.showDeaths.getValue()) {
            arrayList.add(this.N("\u2620 ", class_124.field_1065, this.deaths.getValue()));
        }
        if (this.showPlaytime.getValue()) {
            arrayList.add(this.N("\u25f7 ", class_124.field_1054, this.playtime.getValue()));
        }
        if (!arrayList.isEmpty()) return arrayList;
        arrayList.add(class_2561.method_43470((String)" "));
        return arrayList;
    }

    private class_5250 N(String string, class_124 class_1242, String string2) {
        return class_2561.method_43470((String)string).method_27692(class_1242).method_10852((class_2561)class_2561.method_43470((String)string2).method_27692(class_124.field_1068));
    }

    public void b(double d) {
        String string = this.money.getValue().trim().replace(",", "").replace("$", "").toUpperCase(Locale.ROOT);
        double d2 = 1.0;
        if (string.endsWith("K")) {
            d2 = 1000.0;
            string = string.substring(0, string.length() - 1);
        } else if (string.endsWith("M")) {
            d2 = 1000000.0;
            string = string.substring(0, string.length() - 1);
        } else if (string.endsWith("B")) {
            d2 = 1.0E9;
            string = string.substring(0, string.length() - 1);
        } else if (string.endsWith("T")) {
            d2 = 1.0E12;
            string = string.substring(0, string.length() - 1);
        }
        try {
            double d3 = Math.max(0.0, Double.parseDouble(string) * d2 - d);
            if (d3 >= 1.0E12) {
                this.money.setValue(FakeScoreboard.B(d3 / 1.0E12) + "T");
            } else if (d3 >= 1.0E9) {
                this.money.setValue(FakeScoreboard.B(d3 / 1.0E9) + "B");
            } else if (d3 >= 1000000.0) {
                this.money.setValue(FakeScoreboard.B(d3 / 1000000.0) + "M");
            } else if (d3 >= 1000.0) {
                this.money.setValue(FakeScoreboard.B(d3 / 1000.0) + "K");
            } else {
                this.money.setValue(FakeScoreboard.B(d3));
            }
            this.lastRefresh = 0L;
            if (!this.isEnabled()) return;
            this.W();
            return;
        }
        catch (NumberFormatException numberFormatException) {

        }
    }

    private static String B(double d) {
        if (Math.rint(d) != d) return String.format(Locale.ROOT, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
        return Long.toString((long)d);
    }

    private void j() {
        if (this.mc.field_1687 == null) {
            this.ours = null;
            this.teamNames.clear();
            return;
        }
        class_269 class_2692 = this.mc.field_1687.method_8428();
        this.o(class_2692);
        class_266 class_2662 = class_2692.method_1170("kryzex_fake_scoreboard");
        if (class_2662 != null) {
            class_2692.method_1194(class_2662);
        }
        class_266 class_2663 = null;
        if (this.serverObjective != null && class_2692.method_1170(this.serverObjective.method_1113()) != null) {
            class_2663 = this.serverObjective;
        }
        class_2692.method_1158(class_8646.field_45157, class_2663);
        this.ours = null;
        this.serverObjective = null;
    }

    private void o(class_269 class_2692) {
        for (String string : this.teamNames) {
            class_268 class_2682 = class_2692.method_1153(string);
            if (class_2682 == null) continue;
            class_2692.method_1191(class_2682);
        }
        this.teamNames.clear();
    }

    static {
        a = new String[]{"0+$", "Money Amount", "Shards", "Shards Amount", "kryzex_sb_", "%.2f", "kryzex_fake_scoreboard", "Kryzex", "Fake Scoreboard", "Replaces the sidebar with your own configurable scoreboard", "$ ", "\\.$", "Kills", "Kills Amount", "Playtime", "Deaths", "Playtime Amount", "1M", "\u2726 ", "Money", "\u2694 ", "\u2620 ", "Deaths Amount", "0h", "Title", "kryzex_fake_scoreboard", "kryzex_sb_", "\u25f7 "};
        OBJECTIVE = a[6];
        TEAM_PREFIX = a[26];
    }
}
