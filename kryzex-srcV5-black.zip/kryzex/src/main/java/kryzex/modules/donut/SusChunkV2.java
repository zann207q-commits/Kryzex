package kryzex.modules.donut;

import net.minecraft.class_2596;
import it.unimi.dsi.fastutil.longs.Long2BooleanOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.LongConsumer;
import kryzex.event.ChunkDataEvent;
import kryzex.event.ItemUseHeadEvent;
import kryzex.event.LightUpdateEvent;
import kryzex.event.PacketSendEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.MacroCategories;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.modules.donut.HasUngrown;
import kryzex.modules.misc.MacroModule;
import kryzex.util.CachedThickness;
import kryzex.util.Horizontal;
import kryzex.util.Layers2;
import kryzex.util.WorldUtil2;
import kryzex.util.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_638;

@Environment(value=EnvType.CLIENT)
public final class SusChunkV2
extends MacroModule {
    private static String[] a;
    private static final long SCAN_BUDGET_NANOS = 3000000L;
    private static final int MIN_SCANNED_NEIGHBOURS = 3;
    private static final int NO_PACKET_SENSITIVITY = 1;
    private static final int VISIBLE_REFRESH_TICKS = 20;
    private static final int PACKET_MIN_Y = -16;
    private static final int PACKET_MAX_Y = 30;
    private static final int GLOW_CELLS_PER_POINT = 12;
    private final MacroBoolSetting devTest = this.addSetting("dev-test", new MacroBoolSetting("Dev Test", false));
    private boolean appliedDevTest;
    private final LinkedHashMap<Long, Integer> pendingTests = new LinkedHashMap();
    private final LinkedHashMap<Long, Pattern> testPlates = new LinkedHashMap();
    private final LongOpenHashSet testRegion = new LongOpenHashSet();
    private final MacroNumberSetting spreadRadius = this.addSetting("spread-radius", new MacroNumberSetting("Simulation Distance", 5.0f, 2.0f, 16.0f).step(1.0f));
    private final MacroNumberSetting sensitivity = this.addSetting("packet-sensitivity", new MacroNumberSetting("Sensitivity", 6.0f, 1.0f, 20.0f).step(1.0f));
    private final MacroBoolSetting outline = this.addSetting("outline", new MacroBoolSetting("Outline", true));
    private final MacroNumberSetting alpha = this.addSetting("alpha", new MacroNumberSetting("Alpha", 100.0f, 0.0f, 255.0f).step(1.0f));
    private final Layers2 glow = new Layers2();
    private final CachedThickness plates = new CachedThickness();
    private final Long2IntOpenHashMap heat = new Long2IntOpenHashMap();
    private final Long2IntOpenHashMap vetoes = new Long2IntOpenHashMap();
    private final Long2IntOpenHashMap chunkScore = new Long2IntOpenHashMap();
    private final Long2BooleanOpenHashMap chunkUngrown = new Long2BooleanOpenHashMap();
    private final Long2BooleanOpenHashMap chunkHasPacket = new Long2BooleanOpenHashMap();
    private final LongOpenHashSet scannedChunks = new LongOpenHashSet();
    private final LongArrayFIFOQueue queue = new LongArrayFIFOQueue();
    private final LongOpenHashSet queued = new LongOpenHashSet();
    private Long2IntOpenHashMap visible = new Long2IntOpenHashMap();
    private boolean visibleDirty = true;
    private final Horizontal peakFinder = new Horizontal();
    private int visibleAge;
    private class_638 lastLevel;
    private int appliedRadius;
    private int ticks;
    private final Long2IntOpenHashMap settling = new Long2IntOpenHashMap();

    public SusChunkV2() {
        super("sus-chunk-v2", "Sus Chunk V2", "Detects suspicious underground activity from geode light patterns.", MacroCategories.DONUT);
        this.sensitivity.onChange(this::lmbd$new$0);
    }

    @Override
    public void onEnable() {
        this.Q();
        this.lastLevel = class_310.method_1551().field_1687;
        this.R();
    }

    @Override
    public void onDisable() {
        this.Q();
        this.lastLevel = null;
    }

    private void Q() {
        this.pendingTests.clear();
        this.testPlates.clear();
        this.testRegion.clear();
        this.appliedDevTest = this.devTest.get();
        this.heat.clear();
        this.vetoes.clear();
        this.chunkScore.clear();
        this.chunkUngrown.clear();
        this.chunkHasPacket.clear();
        this.scannedChunks.clear();
        this.queue.clear();
        this.queued.clear();
        this.settling.clear();
        this.ticks = 0;
        this.visible = new Long2IntOpenHashMap();
        this.visibleDirty = true;
        this.visibleAge = 0;
        this.appliedRadius = this.spreadRadius.getInt();
    }

    private void P(class_638 class_6382) {
        if (class_6382 == this.lastLevel && this.appliedDevTest == this.devTest.get()) return;
        this.Q();
        this.lastLevel = class_6382;
        this.R();
    }

    private void R() {
        if (this.devTest.get()) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_3102.field_1724 == null) return;
        int n = (Integer)class_3102.field_1690.method_42503().method_41753() + 1;
        class_1923 class_19232 = class_3102.field_1724.method_31476();
        for (int i = class_19232.field_9181 - n; i <= class_19232.field_9181 + n; ++i) {
            for (int j = class_19232.field_9180 - n; j <= class_19232.field_9180 + n; ++j) {
                if (!WorldUtil2.isLoaded(class_3102.field_1687, i, j)) continue;
                this.E(class_1923.method_8331((int)i, (int)j));
            }
        }
    }

    private void E(long l) {
        if (this.devTest.get() || !this.queued.add(l)) return;
        this.queue.enqueue(l);
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.P(class_310.method_1551().field_1687);
        if (this.devTest.get()) {
            return;
        }
        this.E(class_1923.method_8331((int)chunkDataEvent.packet.method_11523(), (int)chunkDataEvent.packet.method_11524()));
        this.p(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524());
    }

    @Subscribe
    public void onLightUpdate(LightUpdateEvent lightUpdateEvent) {
        this.P(class_310.method_1551().field_1687);
        if (this.devTest.get()) {
            return;
        }
        this.p(lightUpdateEvent.packet.method_11558(), lightUpdateEvent.packet.method_11554());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        class_310 class_3102 = class_310.method_1551();
        class_638 class_6382 = class_3102.field_1687;
        this.P(class_6382);
        if (this.devTest.get()) {
            ++this.ticks;
            this.H(class_3102);
            return;
        }
        if (class_6382 == null) return;
        ++this.ticks;
        this.l();
        if (this.spreadRadius.getInt() != this.appliedRadius) {
            this.Q();
            this.R();
        }
        long l = System.nanoTime() + 3000000L;
        while (!this.queue.isEmpty() && System.nanoTime() < l) {
            int n;
            long l2 = this.queue.dequeueLong();
            this.queued.remove(l2);
            int n2 = class_1923.method_8325((long)l2);
            if (!WorldUtil2.isLoaded(class_6382, n2, n = class_1923.method_8332((long)l2))) continue;
            this.U(l2, class_6382.method_8497(n2, n), class_6382);
            if (!this.scannedChunks.add(l2)) continue;
            this.visibleDirty = true;
        }
        if (!this.visibleDirty && ++this.visibleAge < 20) return;
        this.visible = this.o(class_6382);
        this.visibleDirty = false;
        this.visibleAge = 0;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_638 class_6382 = class_310.method_1551().field_1687;
        this.P(class_6382);
        if (this.devTest.get()) {
            this.a(worldRenderEvent);
            return;
        }
        if (class_6382 == null) return;
        int n = this.alpha.getInt();
        Color color = this.outline.get() ? new Color(255, 242, 75, Math.min(220, n + 45)) : null;
        this.plates.draw(worldRenderEvent, this.visible.keySet(), new Color(255, 235, 0, n), color, 1.0f);
    }

    @Subscribe
    public void onItemUseHead(ItemUseHeadEvent itemUseHeadEvent) {
        class_239 class_2392;
        if (!this.isEnabled() || !this.devTest.get()) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_3102.field_1724 == null || !((class_2392 = class_3102.field_1765) instanceof class_3965)) {
            return;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        boolean bl = false;
        for (class_1268 class_12682 : class_1268.values()) {
            if (!class_3102.field_1724.method_5998(class_12682).method_31574(class_1802.field_8394)) continue;
            bl = true;
            break;
        }
        if (!bl) {
            return;
        }
        this.P(class_3102.field_1687);
        class_2338 class_23382 = class_39652.method_17777();
        class_2338 class_23383 = class_3102.field_1687.method_8320(class_23382).method_45474() ? class_23382 : class_23382.method_10093(class_39652.method_17780());
        this.Y(class_3102, class_23383);
    }

    @Subscribe
    public void onPacketSend(PacketSendEvent packetSendEvent) {
        class_2596<?> packet = packetSendEvent.packet;
        if (!this.devTest.get() || !(packet instanceof class_2885)) {
            return;
        }
        class_2885 class_28852 = (class_2885)packet;
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.method_18854()) {
            this.A(class_3102, class_28852);
            return;
        } else {
            class_3102.execute(() -> this.lmbd$onTestInteract$0(class_3102, class_28852));
        }
    }

    private void A(class_310 class_3102, class_2885 class_28852) {
        if (!this.isEnabled() || !this.devTest.get() || class_3102.field_1687 == null || class_3102.field_1724 == null) {
            return;
        }
        this.P(class_3102.field_1687);
        if (!class_3102.field_1724.method_5998(class_28852.method_12546()).method_31574(class_1802.field_8394)) {
            return;
        }
        class_3965 class_39652 = class_28852.method_12543();
        class_2338 class_23382 = class_39652.method_17777();
        class_2338 class_23383 = class_3102.field_1687.method_8320(class_23382).method_45474() ? class_23382 : class_23382.method_10093(class_39652.method_17780());
        this.Y(class_3102, class_23383);
    }

    private void Y(class_310 class_3102, class_2338 class_23382) {
        if (class_3102.field_1724.method_5707(class_243.method_24953((class_2382)class_23382)) > 100.0) {
            return;
        }
        this.pendingTests.put(class_23382.method_10063(), this.ticks + 40);
        while (this.pendingTests.size() > 32) {
            this.pendingTests.remove(this.pendingTests.keySet().iterator().next());
        }
    }

    private void H(class_310 class_3102) {
        if (class_3102.field_1687 == null) {
            return;
        }
        Iterator<Map.Entry<Long, Integer>> iterator = this.pendingTests.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Long, Integer> entry = iterator.next();
            class_2338 class_23382 = class_2338.method_10092((long)entry.getKey());
            if (!WorldUtil2.isLoaded(class_3102.field_1687, class_23382.method_10263() >> 4, class_23382.method_10260() >> 4) || this.ticks > entry.getValue()) {
                iterator.remove();
                continue;
            }
            if (!class_3102.field_1687.method_8320(class_23382).method_27852(class_2246.field_10004)) continue;
            this.testPlates.computeIfAbsent(entry.getKey(), arg_0 -> SusChunkV2.lmbd$tickTests$0(class_23382, arg_0));
            iterator.remove();
        }
        while (this.testPlates.size() > 24) {
            this.testPlates.remove(this.testPlates.keySet().iterator().next());
        }
        this.testPlates.entrySet().removeIf(arg_0 -> SusChunkV2.lmbd$tickTests$1(class_3102, arg_0));
    }

    private void a(WorldRenderEvent worldRenderEvent) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_3102.field_1724 == null) {
            return;
        }
        int n = this.alpha.getInt();
        if (n <= 0) {
            return;
        }
        this.testRegion.clear();
        int n2 = class_3102.field_1690.method_38521() + 1;
        int n3 = class_3102.field_1724.method_31477() >> 4;
        int n4 = class_3102.field_1724.method_31479() >> 4;
        for (Pattern pattern : this.testPlates.values()) {
            LongIterator longIterator = pattern.chunks.iterator();
            while (longIterator.hasNext()) {
                long l = (Long)longIterator.next();
                int n5 = class_1923.method_8325((long)l);
                int n6 = class_1923.method_8332((long)l);
                if (Math.abs(n5 - n3) > n2 || Math.abs(n6 - n4) > n2 || !WorldUtil2.isLoaded(class_3102.field_1687, n5, n6)) continue;
                this.testRegion.add(l);
            }
        }
        Color color = this.outline.get() ? new Color(255, 242, 75, Math.min(220, n + 45)) : null;
        this.plates.draw(worldRenderEvent, (LongSet)this.testRegion, new Color(255, 235, 0, n), color, 1.0f);
    }

    private static boolean lmbd$tickTests$1(class_310 class_3102, Map.Entry entry) {
        class_2338 class_23382 = ((Pattern)entry.getValue()).anchor;
        if (!WorldUtil2.isLoaded(class_3102.field_1687, class_23382.method_10263() >> 4, class_23382.method_10260() >> 4)) return true;
        if (class_3102.field_1687.method_8320(class_23382).method_27852(class_2246.field_10004)) return false;
        return true;
    }

    private static Pattern lmbd$tickTests$0(class_2338 class_23382, Long l) {
        return new Pattern(class_23382);
    }

    private void lmbd$onTestInteract$0(class_310 class_3102, class_2885 class_28852) {
        this.A(class_3102, class_28852);
    }

    private void lmbd$new$0() {
        this.visibleDirty = true;
    }

    private void p(int n, int n2) {
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                long l = class_1923.method_8331((int)(n + i), (int)(n2 + j));
                this.settling.put(l, Math.min(this.settling.getOrDefault(l, this.ticks + 2), this.ticks + 2));
            }
        }
    }

    private void l() {
        ObjectIterator objectIterator = this.settling.long2IntEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            Long2IntMap.Entry entry = (Long2IntMap.Entry)objectIterator.next();
            if (entry.getIntValue() > this.ticks) continue;
            this.E(entry.getLongKey());
            objectIterator.remove();
        }
    }

    private void U(long l, class_2818 class_28182, class_638 class_6382) {
        int n = this.spreadRadius.getInt();
        int n2 = class_1923.method_8325((long)l);
        int n3 = class_1923.method_8332((long)l);
        int n4 = this.chunkScore.getOrDefault(l, 0);
        boolean bl = this.chunkUngrown.getOrDefault(l, false);
        boolean bl2 = SusChunkV2.q(class_28182, -16, 30);
        HasUngrown hasUngrown = this.j(class_28182, class_6382);
        if (!this.chunkHasPacket.containsKey(l) || this.chunkHasPacket.get(l) != bl2) {
            this.visibleDirty = true;
        }
        this.chunkHasPacket.put(l, bl2);
        if (n4 == hasUngrown.selfHeat() && bl == hasUngrown.hasUngrown() && this.chunkScore.containsKey(l)) {
            return;
        }
        if (n4 > 0) {
            SusChunkV2.G(n2, n3, n, arg_0 -> this.lmbd$updateChunk$0(n4, arg_0));
        }
        if (bl) {
            SusChunkV2.G(n2, n3, n, this::lmbd$updateChunk$1);
        }
        this.chunkScore.put(l, hasUngrown.selfHeat());
        this.chunkUngrown.put(l, hasUngrown.hasUngrown());
        if (hasUngrown.hasUngrown()) {
            SusChunkV2.G(n2, n3, n, this::lmbd$updateChunk$2);
        }
        if (hasUngrown.selfHeat() > 0) {
            SusChunkV2.G(n2, n3, n, arg_0 -> this.lmbd$updateChunk$3(hasUngrown, arg_0));
        }
        this.visibleDirty = true;
    }

    private static void G(int n, int n2, int n3, LongConsumer longConsumer) {
        for (int i = -n3; i <= n3; ++i) {
            for (int j = -n3; j <= n3; ++j) {
                longConsumer.accept(class_1923.method_8331((int)(n + i), (int)(n2 + j)));
            }
        }
    }

    private static void N(Long2IntOpenHashMap long2IntOpenHashMap, long l, int n) {
        int n2 = long2IntOpenHashMap.get(l) - n;
        if (n2 > 0) {
            long2IntOpenHashMap.put(l, n2);
            return;
        } else {
            long2IntOpenHashMap.remove(l);
        }
    }

    private static boolean q(class_2818 class_28182, int n, int n2) {
        class_2826[] class_2826Array = class_28182.method_12006();
        int n3 = class_28182.method_32891();
        for (int i = 0; i < class_2826Array.length; ++i) {
            class_2826 class_28262 = class_2826Array[i];
            if (class_28262 == null || class_28262.method_38292()) continue;
            int n4 = n3 + i << 4;
            if (n4 >= n && n4 + 15 <= n2) {
                return true;
            }
            if (n4 + 15 < n || n4 > n2) continue;
            for (int j = 0; j < 16; ++j) {
                int n5 = n4 + j;
                if (n5 < n || n5 > n2) continue;
                for (int k = 0; k < 16; ++k) {
                    for (int i2 = 0; i2 < 16; ++i2) {
                        if (class_28262.method_12254(k, j, i2).method_26215()) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private HasUngrown j(class_2818 class_28182, class_638 class_6382) {
        return new HasUngrown(this.glow.scan(class_6382, class_28182, null) / 12, false);
    }

    private Long2IntOpenHashMap o(class_638 class_6382) {
        Long2IntOpenHashMap long2IntOpenHashMap = new Long2IntOpenHashMap();
        for (Long2IntMap.Entry entry : this.heat.long2IntEntrySet()) {
            int n;
            int n2;
            long l = entry.getLongKey();
            if (this.vetoes.containsKey(l) || !WorldUtil2.isLoaded(class_6382, n2 = class_1923.method_8325((long)l), n = class_1923.method_8332((long)l)) || this.v(n2, n) < 3) continue;
            long2IntOpenHashMap.put(l, entry.getIntValue());
        }
        int n = this.sensitivity.getInt();
        int n3 = this.appliedRadius;
        Long2IntOpenHashMap long2IntOpenHashMap2 = new Long2IntOpenHashMap();
        LongOpenHashSet longOpenHashSet = this.peakFinder.find(long2IntOpenHashMap, n3);
        for (Long2IntMap.Entry entry : long2IntOpenHashMap.long2IntEntrySet()) {
            int n4;
            long l = entry.getLongKey();
            int n5 = entry.getIntValue();
            if (n5 < (n4 = this.chunkHasPacket.getOrDefault(l, true) ? n : 1) || !longOpenHashSet.contains(l)) continue;
            long2IntOpenHashMap2.put(l, n5);
        }
        return long2IntOpenHashMap2;
    }

    private int v(int n, int n2) {
        int n3 = 0;
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                if (i == 0 && j == 0 || !this.scannedChunks.contains(class_1923.method_8331((int)(n + i), (int)(n2 + j)))) continue;
                ++n3;
            }
        }
        return n3;
    }

    private void lmbd$updateChunk$3(HasUngrown hasUngrown, long l) {
        this.heat.addTo(l, hasUngrown.selfHeat());
    }

    private void lmbd$updateChunk$2(long l) {
        this.vetoes.addTo(l, 1);
    }

    private void lmbd$updateChunk$1(long l) {
        SusChunkV2.N(this.vetoes, l, 1);
    }

    private void lmbd$updateChunk$0(int n, long l) {
        SusChunkV2.N(this.heat, l, n);
    }

    static {
        a = new String[]{"Alpha", "packet-sensitivity", "Detects suspicious underground activity from geode light patterns.", "sus-chunk-v2", "spread-radius", "outline", "dev-test", "Simulation Distance", "Sus Chunk V2", "alpha", "Sensitivity", "Dev Test", "Outline"};
    }
}
