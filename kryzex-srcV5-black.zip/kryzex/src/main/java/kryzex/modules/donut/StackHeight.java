package kryzex.modules.donut;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class StackHeight {
    public final int minY;
    public final int maxY;
    public final int stackHeight;

    public StackHeight(int minY, int maxY, int stackHeight) {
        this.minY = minY;
        this.maxY = maxY;
        this.stackHeight = stackHeight;
    }

    public int minY() {
        return this.minY;
    }

    public int maxY() {
        return this.maxY;
    }

    public int stackHeight() {
        return this.stackHeight;
    }
}
