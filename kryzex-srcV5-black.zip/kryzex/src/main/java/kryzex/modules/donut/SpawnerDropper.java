package kryzex.modules.donut;

import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

public final class SpawnerDropper
extends Module {
    private static String[] a;
    private static final int CHECK_DELAY = 3;
    private final BoolSetting notifications = new BoolSetting(SecureString.of("Notifications"), true);
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 1.0, 20.0, 5.0, 1.0);
    private final BoolSetting boneOnly = new BoolSetting(SecureString.of("Bone Only"), true);
    private final NumberSetting autoReopenInterval = new NumberSetting(SecureString.of("Auto Reopen Interval"), 1.0, 600.0, 10.0, 1.0);
    private int tickCounter;
    private int currentStep;
    private int checkDelayCounter;
    private int reopenTimer;
    private class_2338 spawnerPos;
    private boolean waitingForInterval;

    public SpawnerDropper() {
        super(SecureString.of("Spawner Dropper"), SecureString.of("Drops all items from nearby spawners"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.notifications, this.delay, this.boneOnly, this.autoReopenInterval});
    }

    @Override
    public void onEnable() {
        this.T();
        this.N("Spawner Dropper activated - looking for a nearby spawner.");
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.T();
        if (this.mc.field_1724 != null && this.mc.field_1724.field_7512 instanceof class_1707) {
            this.mc.field_1724.method_7346();
        }
        super.onDisable();
    }

    private void T() {
        this.tickCounter = 0;
        this.currentStep = 0;
        this.checkDelayCounter = 0;
        this.reopenTimer = 0;
        this.spawnerPos = null;
        this.waitingForInterval = false;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null) {
            return;
        }
        if (this.spawnerPos == null || !this.mc.field_1687.method_8320(this.spawnerPos).method_27852(class_2246.field_10260)) {
            this.spawnerPos = this.k();
            if (this.spawnerPos != null) {
                this.N("Spawner detected nearby.");
            }
        }
        ++this.reopenTimer;
        int n = this.autoReopenInterval.getIntValue() * 60 * 20;
        if (this.waitingForInterval) {
            if (this.reopenTimer < n) return;
            this.e();
            return;
        }
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            if (this.spawnerPos == null || this.reopenTimer < n && this.reopenTimer != 20) return;
            this.e();
            return;
        }
        class_1707 class_17072 = (class_1707)class_17032;
        if (class_17072.field_7761.size() <= 53) {
            return;
        }
        if (this.boneOnly.getValue() && this.R(class_17072)) {
            this.N("Arrows detected - waiting for the next interval.");
            this.mc.field_1724.method_7346();
            this.waitingForInterval = true;
            this.reopenTimer = 0;
            return;
        }
        if (this.currentStep == 2 || this.currentStep == 5) {
            if (++this.checkDelayCounter < 3) return;
            if (class_17072.method_7611(0).method_7677().method_7960()) {
                this.N("Spawner emptied - waiting for the next interval.");
                this.mc.field_1724.method_7346();
                this.waitingForInterval = true;
                this.reopenTimer = 0;
                return;
            } else {
                this.currentStep = this.currentStep == 2 ? 3 : 0;
                this.checkDelayCounter = 0;
            }
            return;
        }
        if (++this.tickCounter < this.delay.getIntValue()) {
            return;
        }
        this.tickCounter = 0;
        switch (this.currentStep) {
            case 0: {
                this.t(class_17072, 50);
                this.currentStep = 1;
                return;
            }
            case 1: {
                this.t(class_17072, 53);
                this.currentStep = 2;
                this.checkDelayCounter = 0;
                return;
            }
            case 3: {
                this.t(class_17072, 50);
                this.currentStep = 4;
                return;
            }
            case 4: {
                this.t(class_17072, 53);
                this.currentStep = 5;
                this.checkDelayCounter = 0;
                return;
            }
        }
    }

    private boolean R(class_1707 class_17072) {
        for (int i = 0; i <= 44 && i < class_17072.field_7761.size(); ++i) {
            if (!class_17072.method_7611(i).method_7677().method_31574(class_1802.field_8107)) continue;
            return true;
        }
        return false;
    }

    private class_2338 k() {
        class_2338 class_23382 = this.mc.field_1724.method_24515();
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        for (int i = -6; i <= 6; ++i) {
            for (int j = -6; j <= 6; ++j) {
                for (int k = -6; k <= 6; ++k) {
                    class_23392.method_10103(class_23382.method_10263() + i, class_23382.method_10264() + j, class_23382.method_10260() + k);
                    if (!this.mc.field_1687.method_8320((class_2338)class_23392).method_27852(class_2246.field_10260)) continue;
                    return class_23392.method_10062();
                }
            }
        }
        return null;
    }

    private void e() {
        if (this.spawnerPos == null) {
            return;
        }
        class_3965 class_39652 = new class_3965(class_243.method_24953((class_2382)this.spawnerPos), class_2350.field_11036, this.spawnerPos, false);
        this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, class_39652);
        this.currentStep = 0;
        this.checkDelayCounter = 0;
        this.tickCounter = 0;
        this.waitingForInterval = false;
        this.reopenTimer = 0;
    }

    private void t(class_1707 class_17072, int n) {
        this.mc.field_1761.method_2906(class_17072.field_7763, n, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
    }

    private void N(String string) {
        if (!this.notifications.getValue() || this.mc.field_1724 == null) return;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7b[Spawner Dropper] \u00a7f" + string)), false);
    }

    static {
        a = new String[]{"\u00a7b[Spawner Dropper] \u00a7f", "Notifications", "Auto Reopen Interval", "Spawner Dropper", "Spawner Dropper activated - looking for a nearby spawner.", "Bone Only", "Drops all items from nearby spawners", "Delay"};
    }
}
