package kryzex.modules.donut;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.donut.Type;
import kryzex.util.FontRenderer;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.SecureString;
import net.minecraft.class_332;

public final class RegionMap
extends Module {
    private static final int MAP_SIZE = 9;
    private static final double CELL_WORLD_SIZE = 50000.0;
    private static final double MAP_OFFSET = 225000.0;
    private static int[] REGION_IDS;
    private static int[] REGION_TYPES;
    private static Color[] REGION_COLORS;
    private static String[] REGION_NAMES;
    private final NumberSetting mapX = new NumberSetting(SecureString.of("Position X"), 0.0, 4000.0, 15.0, 1.0);
    private final NumberSetting mapY = new NumberSetting(SecureString.of("Position Y"), 0.0, 4000.0, 70.0, 1.0);
    private final NumberSetting cellSize = new NumberSetting(SecureString.of("Cell Size"), 14.0, 56.0, 26.0, 1.0);
    private final NumberSetting transparency = new NumberSetting(SecureString.of("Transparency"), 0.1, 1.0, 0.78, 0.05);
    private final BoolSetting purple = new BoolSetting(SecureString.of("Purple"), false).setDescription(SecureString.of("Uses the supplied RTP-map spot-zone style"));
    private final BoolSetting coordinates = new BoolSetting(SecureString.of("Coordinates"), true);
    private final BoolSetting legend = new BoolSetting(SecureString.of("Legend"), true);
    private final BoolSetting grid = new BoolSetting(SecureString.of("Grid"), true);
    private final BoolSetting playerIndicator = new BoolSetting(SecureString.of("Player Indicator"), true);
    private final List<Type> spots = RegionMap.P();
    private static String[] a;

    public RegionMap() {
        super(SecureString.of("Region Map"), SecureString.of("Shows the DonutSMP 50k region grid and your position"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.mapX, this.mapY, this.cellSize, this.transparency, this.purple, this.coordinates, this.legend, this.grid, this.playerIndicator});
    }

    @Subscribe
    public void onHudRender(HudRenderEvent hudRenderEvent) {
        int n;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        class_332 class_3322 = hudRenderEvent.context;
        InverseProjectionScratch.unscaledProjection();
        int n2 = this.mapX.getIntValue();
        int n3 = this.mapY.getIntValue();
        int n4 = this.cellSize.getIntValue();
        int n5 = n4 * 9;
        int n6 = (int)(this.transparency.getValue() * 255.0);
        class_3322.method_25294(n2 - 2, n3 - 2, n2 + n5 + 2, n3 + n5 + 2, new Color(8, 10, 16, Math.max(30, n6)).getRGB());
        for (n = 0; n < 9; ++n) {
            for (int i = 0; i < 9; ++i) {
                int n7 = n * 9 + i;
                Color color = this.purple.getValue() ? new Color(18, 19, 28, Math.max(45, n6)) : RegionMap.k(REGION_COLORS[REGION_TYPES[n7]], n6);
                class_3322.method_25294(n2 + i * n4 + 1, n3 + n * n4 + 1, n2 + (i + 1) * n4, n3 + (n + 1) * n4, color.getRGB());
            }
        }
        if (this.purple.getValue()) {
            for (Type type : this.spots) {
                Color color = switch (type.type()) {
                    case 3 -> new Color(186, 110, 255, 205);
                    case 2 -> new Color(64, 140, 255, 215);
                    default -> new Color(176, 188, 208, 195);
                };
                class_3322.method_25294(n2 + type.col() * n4 + 2, n3 + type.row() * n4 + 2, n2 + (type.col() + 1) * n4 - 1, n3 + (type.row() + 1) * n4 - 1, color.getRGB());
            }
        }
        if (this.grid.getValue()) {
            n = new Color(25, 28, 38, 230).getRGB();
            for (int i = 0; i <= 9; ++i) {
                class_3322.method_25294(n2 + i * n4, n3, n2 + i * n4 + 1, n3 + n5, n);
                class_3322.method_25294(n2, n3 + i * n4, n2 + n5, n3 + i * n4 + 1, n);
            }
        }
        for (n = 0; n < 9; ++n) {
            for (int i = 0; i < 9; ++i) {
                String string = Integer.toString(REGION_IDS[n * 9 + i]);
                int n8 = FontRenderer.getWidth(string);
                FontRenderer.drawString(string, class_3322, n2 + i * n4 + Math.max(2, (n4 - n8) / 2), n3 + n * n4 + Math.max(2, (n4 - 10) / 2), new Color(238, 241, 250, 235).getRGB());
            }
        }
        if (this.playerIndicator.getValue()) {
            double d = (this.mc.field_1724.method_23317() + 225000.0) / 50000.0;
            double d2 = (this.mc.field_1724.method_23321() + 225000.0) / 50000.0;
            if (d >= 0.0 && d < 9.0 && d2 >= 0.0 && d2 < 9.0) {
                int n9 = n2 + (int)Math.round(d * (double)n4);
                int n10 = n3 + (int)Math.round(d2 * (double)n4);
                class_3322.method_25294(n9 - 3, n10 - 3, n9 + 4, n10 + 4, new Color(255, 55, 70, 255).getRGB());
                class_3322.method_25294(n9 - 1, n10 - 6, n9 + 2, n10 - 3, new Color(255, 210, 215, 255).getRGB());
            }
        }
        int n11 = n3 + n5 + 7;
        if (this.coordinates.getValue()) {
            String string = "Position: X: " + (int)this.mc.field_1724.method_23317() + ", Z: " + (int)this.mc.field_1724.method_23321();
            FontRenderer.drawString(string, class_3322, n2, n11, Color.WHITE.getRGB());
            n11 += 16;
        }
        if (this.legend.getValue()) {
            if (this.purple.getValue()) {
                n11 = this.t(class_3322, n2, n11, new Color(186, 110, 255), "Glitched / no RTP spots");
                n11 = this.t(class_3322, n2, n11, new Color(64, 140, 255), "Media / baltop");
                this.t(class_3322, n2, n11, new Color(176, 188, 208), "Other base spots");
            } else {
                for (int i = 0; i < REGION_NAMES.length; ++i) {
                    n11 = this.t(class_3322, n2, n11, REGION_COLORS[i], REGION_NAMES[i]);
                }
            }
        }
        InverseProjectionScratch.scaledProjection();
    }

    private int t(class_332 class_3322, int n, int n2, Color color, String string) {
        class_3322.method_25294(n, n2, n + 12, n2 + 12, color.getRGB());
        FontRenderer.drawString(string, class_3322, n + 17, n2, Color.WHITE.getRGB());
        return n2 + 16;
    }

    private static Color k(Color color, int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
    }

    private static List<Type> P() {
        int[][] nArrayArray;
        ArrayList<Type> arrayList = new ArrayList<Type>();
        RegionMap.F(arrayList, 3, -200000.0, 200000.0);
        RegionMap.F(arrayList, 3, -200000.0, 150000.0);
        RegionMap.F(arrayList, 3, -100000.0, -200000.0);
        RegionMap.F(arrayList, 3, 0.0, -200000.0);
        RegionMap.F(arrayList, 3, 50000.0, -200000.0);
        RegionMap.F(arrayList, 3, 200000.0, 100000.0);
        RegionMap.F(arrayList, 2, 0.0, 0.0);
        RegionMap.F(arrayList, 2, 50000.0, 0.0);
        RegionMap.F(arrayList, 2, 0.0, 50000.0);
        RegionMap.F(arrayList, 2, 50000.0, 150000.0);
        for (int[] nArray : nArrayArray = new int[][]{{-200000, 0}, {-200000, 100000}, {0, -50000}, {50000, 50000}, {150000, 50000}, {-50000, 150000}, {0, 150000}, {100000, 150000}, {150000, 150000}, {200000, 150000}, {-50000, 200000}, {100000, 200000}, {150000, 200000}, {200000, 200000}}) {
            RegionMap.F(arrayList, 1, nArray[0], nArray[1]);
        }
        return arrayList;
    }

    private static void F(List<Type> list, int n, double d, double d2) {
        int n2 = (int)Math.floor((d + 225000.0) / 50000.0);
        int n3 = (int)Math.floor((d2 + 225000.0) / 50000.0);
        if (n2 < 0 || n2 >= 9 || n3 < 0 || n3 >= 9) {
            return;
        }
        list.removeIf(arg_0 -> RegionMap.lmbd$addSpot$0(n2, n3, n, arg_0));
        boolean bl = list.stream().anyMatch(arg_0 -> RegionMap.lmbd$addSpot$1(n2, n3, n, arg_0));
        if (bl) return;
        list.add(new Type(n2, n3, n));
    }

    private static boolean lmbd$addSpot$1(int n, int n2, int n3, Type type) {
        if (type.col() != n) return false;
        if (type.row() != n2) return false;
        if (type.type() <= n3) return false;
        return true;
    }

    private static boolean lmbd$addSpot$0(int n, int n2, int n3, Type type) {
        if (type.col() != n) return false;
        if (type.row() != n2) return false;
        if (type.type() > n3) return false;
        return true;
    }

    static {
        REGION_NAMES = new String[]{"EU Central", "EU West", "NA East", "NA West", "Asia", "Oceania"};
        a = new String[]{"Uses the supplied RTP-map spot-zone style", "Coordinates", "Asia", "Shows the DonutSMP 50k region grid and your position", "EU West", "NA East", "Purple", "Player Indicator", "Grid", "EU Central", "Position X", "Position Y", "Oceania", "Region Map", "Legend", "Transparency", "NA West", "Cell Size"};
        REGION_IDS = new int[]{82, 100, 101, 102, 103, 104, 105, 106, 91, 83, 44, 75, 42, 41, 40, 39, 38, 92, 84, 45, 14, 13, 12, 11, 10, 37, 93, 85, 46, 74, 3, 2, 1, 25, 36, 94, 86, 47, 72, 71, 5, 4, 24, 35, 95, 87, 51, 17, 9, 8, 7, 23, 34, 96, 88, 54, 18, 61, 62, 21, 22, 33, 97, 89, 26, 27, 28, 29, 30, 59, 32, 98, 90, 107, 108, 109, 110, 111, 112, 113, 99};
        REGION_TYPES = new int[]{5, 3, 3, 3, 2, 2, 2, 2, 2, 5, 3, 3, 3, 2, 2, 2, 2, 2, 5, 3, 3, 3, 2, 2, 2, 2, 2, 5, 5, 5, 3, 2, 2, 2, 2, 2, 4, 4, 4, 4, 2, 2, 2, 2, 2, 4, 1, 1, 0, 0, 0, 0, 0, 2, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0};
        REGION_COLORS = new Color[]{new Color(159, 206, 99), new Color(0, 166, 99), new Color(79, 173, 234), new Color(47, 110, 186), new Color(245, 194, 66), new Color(252, 136, 3)};
    }
}
