package kryzex.modules.render.j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import kryzex.modules.render.j.Active;
import kryzex.modules.render.j.AtlasTruncated;
import kryzex.modules.render.j.Count2;
import kryzex.modules.render.j.DecalSizeMust;
import kryzex.modules.render.j.FirstPersonArms;
import kryzex.modules.render.j.FlatMode;
import kryzex.modules.render.j.FollowAmount;
import kryzex.modules.render.j.Height2;
import kryzex.modules.render.j.Height3;
import kryzex.modules.render.j.Medium;
import kryzex.modules.render.j.MotionSlot;
import kryzex.modules.render.j.Paints;
import kryzex.modules.render.j.Name;
import kryzex.modules.render.j.OcclusionWeight;
import kryzex.modules.render.j.OutlineColorSet;
import kryzex.modules.render.j.Paint;
import kryzex.modules.render.j.QuadCount;
import kryzex.modules.render.j.RightArm;
import kryzex.modules.render.j.MeshDecimator;
import kryzex.modules.render.j.ScaleMustBetween;
import kryzex.modules.render.j.Source2;
import kryzex.modules.render.j.Triangles;
import kryzex.modules.render.j.VertexCount;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class CharacterMesh {
    private static final float DECAL_RESERVE = 0.1f;
    private static final float AO_STEP = 0.38f;
    private static final int MIN_TRIANGLES = 24;
    private static final float MAX_EXTENT = 160.0f;
    private static final float OUTLINE_SHARE = 0.5f;
    private static final float BURIED = 0.02f;
    private static final float SINK = 0.12f;
    private static final int CORNER = 10;
    private static final String[] a = new String[]{": the design defines no parts", ": shape is larger than 160.0 units", ": shape is unbounded; intersect planes with a box"};

    private CharacterMesh() {
    }

    public static FirstPersonArms H(Name name, Medium medium) {
        Object object;
        Object object2;
        Paint[] paintArray;
        if (name instanceof Source2) {
            Source2 source2 = (Source2)name;
            return AtlasTruncated.B(source2, medium);
        }
        long l = System.nanoTime();
        ScaleMustBetween scaleMustBetween = name.G();
        List<OutlineColorSet> list = CharacterMesh.R(scaleMustBetween);
        int n = list.size();
        if (n == 0) {
            String[] stringArray = a;
            throw new IllegalStateException(name.C() + ": the design defines no parts");
        }
        IdentityHashMap<OutlineColorSet, Integer> identityHashMap = new IdentityHashMap<OutlineColorSet, Integer>();
        for (int i = 0; i < n; ++i) {
            identityHashMap.put(list.get(i), i);
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        ArrayList<Height2> arrayList2 = new ArrayList<Height2>();
        Paint[] paintArray2 = new Paint[n];
        float[] fArray = new float[n];
        for (int i = 0; i < n; ++i) {
            OutlineColorSet outlineColorSet = list.get(i);
            if (outlineColorSet.shape != null) {
                object2 = outlineColorSet.shape;
                if (!((Paint)object2).M()) {
                    throw new IllegalStateException(outlineColorSet.name + ": shape is unbounded; intersect planes with a box");
                }
                if (((Paint)object2).maxX - ((Paint)object2).minX > 160.0f || ((Paint)object2).maxY - ((Paint)object2).minY > 160.0f || ((Paint)object2).maxZ - ((Paint)object2).minZ > 160.0f) {
                    throw new IllegalStateException(outlineColorSet.name + ": shape is larger than 160.0 units");
                }
                fArray[i] = Active.B(((Paint)object2).maxX - ((Paint)object2).minX, ((Paint)object2).maxY - ((Paint)object2).minY, ((Paint)object2).maxZ - ((Paint)object2).minZ, medium.step * outlineColorSet.resolution);
                float f = fArray[i] * 0.75f;
                Paint paintVar = ((Paint)object2).h(arg_0 -> CharacterMesh.lmbd$build$0(f, arg_0));
                paintArray2[i] = paintVar;
                arrayList.add(paintVar);
            }
            for (DecalSizeMust decalSizeMust : outlineColorSet.decals) {
                arrayList2.add(decalSizeMust.canvas);
            }
        }
        Paint paint = arrayList.isEmpty() ? null : Paints.j(arrayList.toArray(new Paint[0]));
        paintArray = CharacterMesh.K(list, paintArray2);
        object2 = Height3.L(arrayList2);
        final Height3 height3 = (Height3)object2;
        float[] fArray2 = new float[n];
        for (int i = 0; i < n; ++i) {
            object = list.get(i);
            fArray2[i] = ((OutlineColorSet)object).outline >= 0.0f ? ((OutlineColorSet)object).outline : scaleMustBetween.outline;
        }
        VertexCount[] vertexCountArray = new VertexCount[n];
        object = new float[n];
        final float[] objectF = (float[])object;
        IntStream.range(0, n).parallel().forEach(arg_0 -> CharacterMesh.lmbd$build$1(paintArray2, vertexCountArray, fArray, objectF, paintArray, arg_0));
        int[] nArray = new int[n];
        CharacterMesh.k(list, vertexCountArray, objectF, medium, nArray, fArray2);
        VertexCount[] vertexCountArray2 = new VertexCount[n];
        IntStream.range(0, n).parallel().forEach(arg_0 -> CharacterMesh.lmbd$build$2(vertexCountArray, nArray, vertexCountArray2, arg_0));
        MotionSlot[] motionSlotArray = new MotionSlot[n];
        float[] fArray3 = new float[]{Float.MAX_VALUE, -3.4028235E38f};
        int[] nArray2 = new int[n];
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            OutlineColorSet outlineColorSet = list.get(i);
            nArray2[i] = outlineColorSet.extra && outlineColorSet.motion != null ? n2++ : -1;
        }
        IntStream.range(0, n).parallel().forEach(arg_0 -> CharacterMesh.lmbd$build$3(list, vertexCountArray2, scaleMustBetween, paintArray2, paint, fArray, paintArray, height3, fArray2, fArray3, identityHashMap, motionSlotArray, nArray2, arg_0));
        long l2 = System.nanoTime();
        float f = 12.0f;
        OutlineColorSet outlineColorSet = scaleMustBetween.bones[RightArm.RIGHT_LEG.ordinal()];
        OutlineColorSet outlineColorSet2 = scaleMustBetween.bones[RightArm.LEFT_LEG.ordinal()];
        if (outlineColorSet != null && outlineColorSet2 != null) {
            f = (outlineColorSet.pivotY + outlineColorSet2.pivotY) * 0.5f;
        } else if (outlineColorSet != null) {
            f = outlineColorSet.pivotY;
        } else if (outlineColorSet2 != null) {
            f = outlineColorSet2.pivotY;
        }
        float f2 = fArray3[0] == Float.MAX_VALUE ? 0.0f : fArray3[0];
        float f3 = fArray3[1] == -3.4028235E38f ? 32.0f : fArray3[1];
        long l3 = (l2 - l) / 1000000L;
        return new FirstPersonArms(name.C(), name.B(), medium, scaleMustBetween.scale, motionSlotArray, n2, ((Height3)object2).width, ((Height3)object2).height, ((Height3)object2).mips, ((Height3)object2).w(), ((Height3)object2).v(), f2, f3, f, scaleMustBetween.firstPersonArms, l3);
    }

    private static List<OutlineColorSet> R(ScaleMustBetween scaleMustBetween) {
        ArrayList<OutlineColorSet> arrayList = new ArrayList<OutlineColorSet>();
        for (OutlineColorSet outlineColorSet : scaleMustBetween.bones) {
            if (outlineColorSet == null) continue;
            arrayList.add(outlineColorSet);
        }
        arrayList.addAll(scaleMustBetween.extras);
        return arrayList;
    }

    private static Paint[] K(List<OutlineColorSet> list, Paint[] paintArray) {
        int n = list.size();
        OutlineColorSet[] outlineColorSetArray = new OutlineColorSet[n];
        for (int i = 0; i < n; ++i) {
            OutlineColorSet outlineColorSet = list.get(i);
            while (outlineColorSet.extra && outlineColorSet.motion == null && outlineColorSet.parent != null) {
                outlineColorSet = outlineColorSet.parent;
            }
            outlineColorSetArray[i] = outlineColorSet;
        }
        Paint[] paintArray2 = new Paint[n];
        for (int i = 0; i < n; ++i) {
            if (paintArray[i] == null) continue;
            ArrayList<Paint> arrayList = new ArrayList<Paint>();
            for (int j = 0; j < n; ++j) {
                if (j == i || paintArray[j] == null || outlineColorSetArray[j] != outlineColorSetArray[i] || !CharacterMesh.j(paintArray[i], paintArray[j])) continue;
                arrayList.add(paintArray[j]);
            }
            if (arrayList.isEmpty()) continue;
            paintArray2[i] = Paints.j(arrayList.toArray(new Paint[0]));
        }
        return paintArray2;
    }

    private static boolean j(Paint paint, Paint paint2) {
        if (!(paint.minX <= paint2.maxX)) return false;
        if (!(paint2.minX <= paint.maxX)) return false;
        if (!(paint.minY <= paint2.maxY)) return false;
        if (!(paint2.minY <= paint.maxY)) return false;
        if (!(paint.minZ <= paint2.maxZ)) return false;
        if (!(paint2.minZ <= paint.maxZ)) return false;
        return true;
    }

    private static float I(VertexCount vertexCount, Paint paint) {
        int n;
        if (paint == null || vertexCount.triCount == 0) return 1.0f;
        boolean[] blArray = new boolean[vertexCount.vertexCount];
        for (n = 0; n < vertexCount.vertexCount; ++n) {
            blArray[n] = paint.Q(vertexCount.pos[n * 3], vertexCount.pos[n * 3 + 1], vertexCount.pos[n * 3 + 2]) < -0.02f;
        }
        n = 0;
        for (int i = 0; i < vertexCount.triCount; ++i) {
            if (!blArray[vertexCount.tris[i * 3]] || !blArray[vertexCount.tris[i * 3 + 1]] || !blArray[vertexCount.tris[i * 3 + 2]]) continue;
            ++n;
        }
        return Math.max(0.05f, 1.0f - (float)n / (float)vertexCount.triCount);
    }

    private static void k(List<OutlineColorSet> list, VertexCount[] vertexCountArray, float[] fArray, Medium medium, int[] nArray, float[] fArray2) {
        int n = list.size();
        float f = 0.0f;
        float f2 = 0.0f;
        float[] fArray3 = new float[n];
        for (int i = 0; i < n; ++i) {
            OutlineColorSet outlineColorSet = list.get(i);
            if (vertexCountArray[i] == null) continue;
            fArray3[i] = (float)vertexCountArray[i].triCount * fArray[i] * outlineColorSet.detail;
            f += fArray3[i];
            if (!(fArray2[i] > 0.0f)) continue;
            f2 += fArray3[i];
        }
        if (f <= 0.0f) return;
        float f3 = (float)medium.budget * 0.9f;
        float f4 = f3 / (1.0f + f2 / f);
        for (int i = 0; i < n; ++i) {
            if (vertexCountArray[i] == null) continue;
            int n2 = Math.max(24, Math.round(f4 * fArray3[i] / f / fArray[i]));
            nArray[i] = Math.min(n2, vertexCountArray[i].triCount);
        }
    }

    private static Count2 E(Paint paint, Paint paint2, VertexCount vertexCount, float f, float f2, float f3) {
        Count2 count2 = new Count2(vertexCount.vertexCount);
        int n = (vertexCount.vertexCount + 255) / 256;
        IntStream.range(0, n).parallel().forEach(arg_0 -> CharacterMesh.lmbd$shade$0(vertexCount, paint, f, count2, paint2, f2, f3, arg_0));
        return count2;
    }

    private static VertexCount p(Count2 count2, VertexCount vertexCount, Paint paint, float f) {
        if (paint == null) {
            return vertexCount;
        }
        float[] fArray = new float[count2.count];
        int n = (count2.count + 255) / 256;
        IntStream.range(0, n).parallel().forEach(arg_0 -> CharacterMesh.lmbd$bury$0(count2, paint, fArray, f, arg_0));
        count2.cover = fArray;
        int[] nArray = new int[vertexCount.triCount * 3];
        int n2 = 0;
        for (int i = 0; i < vertexCount.triCount; ++i) {
            float f2;
            float f3;
            float f4;
            int n3 = vertexCount.tris[i * 3];
            int n4 = vertexCount.tris[i * 3 + 1];
            int n5 = vertexCount.tris[i * 3 + 2];
            if (fArray[n3] < -0.02f && fArray[n4] < -0.02f && fArray[n5] < -0.02f && paint.Q(f4 = (vertexCount.pos[n3 * 3] + vertexCount.pos[n4 * 3] + vertexCount.pos[n5 * 3]) / 3.0f, f3 = (vertexCount.pos[n3 * 3 + 1] + vertexCount.pos[n4 * 3 + 1] + vertexCount.pos[n5 * 3 + 1]) / 3.0f, f2 = (vertexCount.pos[n3 * 3 + 2] + vertexCount.pos[n4 * 3 + 2] + vertexCount.pos[n5 * 3 + 2]) / 3.0f) < -0.02f) continue;
            nArray[n2 * 3] = n3;
            nArray[n2 * 3 + 1] = n4;
            nArray[n2 * 3 + 2] = n5;
            ++n2;
        }
        return n2 == vertexCount.triCount ? vertexCount : new VertexCount(vertexCount.pos, vertexCount.vertexCount, Arrays.copyOf(nArray, n2 * 3), n2);
    }

    static void X(Paint paint, float[] fArray, float[] fArray2, float f) {
        CharacterMesh.B(paint, fArray, fArray2, f, 0.0f);
    }

    static void B(Paint paint, float[] fArray, float[] fArray2, float f, float f2) {
        float f3 = Math.max(0.01f, f * 0.3f);
        float f4 = f * 0.01f;
        float f5 = paint.Q(fArray[0], fArray[1], fArray[2]) - f2;
        CharacterMesh.w(paint, fArray, f3, fArray2);
        for (int i = 0; i < 2 && Math.abs(f5) > f4; ++i) {
            float f6 = Math.max(-f, Math.min(f, f5));
            fArray[0] = fArray[0] - fArray2[0] * f6;
            fArray[1] = fArray[1] - fArray2[1] * f6;
            fArray[2] = fArray[2] - fArray2[2] * f6;
            f5 = paint.Q(fArray[0], fArray[1], fArray[2]) - f2;
            CharacterMesh.w(paint, fArray, f3, fArray2);
        }
    }

    static void w(Paint paint, float[] fArray, float f, float[] fArray2) {
        float f2;
        float f3;
        float f4 = fArray[0];
        float f5 = fArray[1];
        float f6 = fArray[2];
        float f7 = paint.Q(f4 + f, f5, f6) - paint.Q(f4 - f, f5, f6);
        float f8 = (float)Math.sqrt(f7 * f7 + (f3 = paint.Q(f4, f5 + f, f6) - paint.Q(f4, f5 - f, f6)) * f3 + (f2 = paint.Q(f4, f5, f6 + f) - paint.Q(f4, f5, f6 - f)) * f2);
        if (f8 < 1.0E-12f) {
            fArray2[0] = 0.0f;
            fArray2[1] = 1.0f;
            fArray2[2] = 0.0f;
            return;
        } else {
            fArray2[0] = f7 / f8;
            fArray2[1] = f3 / f8;
            fArray2[2] = f2 / f8;
        }
    }

    private static float s(Paint paint, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (paint == null || f7 <= 0.0f) return 1.0f;
        float f8 = 0.0f;
        float f9 = 0.0f;
        float f10 = 1.0f;
        for (int i = 1; i <= 5; ++i) {
            float f11 = 0.38f * (float)i;
            float f12 = paint.Q(f + f4 * f11, f2 + f5 * f11, f3 + f6 * f11);
            f8 += Math.max(0.0f, f11 - f12) * f10;
            f9 += f11 * f10;
            f10 *= 0.72f;
        }
        float f13 = Math.min(1.0f, f8 / f9 * 1.6f);
        return 1.0f - f7 * f13 * (1.4f - 0.4f * f13);
    }

    private static Triangles o(Count2 count2, VertexCount vertexCount, OutlineColorSet outlineColorSet, Height3 height3) {
        if (vertexCount.triCount == 0) {
            return null;
        }
        QuadCount quadCount = new QuadCount();
        float f = height3.w();
        float f2 = height3.v();
        for (int i = 0; i < count2.count; ++i) {
            quadCount.G(count2.pos[i * 3] - outlineColorSet.pivotX, count2.pos[i * 3 + 1] - outlineColorSet.pivotY, count2.pos[i * 3 + 2] - outlineColorSet.pivotZ, count2.nrm[i * 3], count2.nrm[i * 3 + 1], count2.nrm[i * 3 + 2], f, f2, count2.color[i], count2.glow[i] != 0, count2.flat[i]);
        }
        CharacterMesh.A(vertexCount.tris, vertexCount.triCount, vertexCount.vertexCount, quadCount);
        return quadCount.i();
    }

    private static Triangles Y(Paint paint, Count2 count2, Triangles triangles, OutlineColorSet outlineColorSet, float f, float f2, int n, Height3 height3) {
        float[] fArray = new float[count2.count * 3];
        float[] fArray2 = new float[count2.count];
        float f3 = f / 0.5f * 1.5f;
        int n2 = (count2.count + 255) / 256;
        IntStream.range(0, n2).parallel().forEach(arg_0 -> CharacterMesh.lmbd$hullSurface$0(count2, f, f3, paint, f2, fArray, fArray2, arg_0));
        QuadCount quadCount = new QuadCount();
        float f4 = height3.w();
        float f5 = height3.v();
        for (int i = 0; i < count2.count; ++i) {
            quadCount.f(fArray[i * 3] - outlineColorSet.pivotX, fArray[i * 3 + 1] - outlineColorSet.pivotY, fArray[i * 3 + 2] - outlineColorSet.pivotZ, 0.0f, 1.0f, 0.0f, f4, f5, n | 0xFF000000, false);
        }
        int[] nArray = triangles.quads;
        for (int i = 0; i < nArray.length; i += 4) {
            int n3 = nArray[i];
            int n4 = nArray[i + 1];
            int n5 = nArray[i + 2];
            int n6 = nArray[i + 3];
            if (fArray2[n3] <= 0.0f && fArray2[n4] <= 0.0f && fArray2[n5] <= 0.0f && fArray2[n6] <= 0.0f) continue;
            quadCount.Y(n3, n6, n5, n4, n5 == n6 ? 1 : 2);
        }
        return quadCount.i();
    }

    static void A(int[] nArray, int n, int n2, QuadCount quadCount) {
        int n3;
        int n4;
        long[] lArray = new long[n * 3];
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < 3; ++j) {
                int n5 = nArray[i * 3 + j];
                n4 = nArray[i * 3 + (j + 1) % 3];
                long l = (long)Math.min(n5, n4) * (long)n2 + (long)Math.max(n5, n4);
                lArray[i * 3 + j] = l << 21 | (long)i * 3L + (long)j;
            }
        }
        Arrays.sort(lArray);
        int[] nArray2 = new int[n * 3];
        Arrays.fill(nArray2, -1);
        long l = 0x1FFFFFL;
        n4 = 0;
        while (n4 + 1 < lArray.length) {
            if (lArray[n4] >>> 21 == lArray[n4 + 1] >>> 21) {
                if (n4 + 2 < lArray.length && lArray[n4 + 2] >>> 21 == lArray[n4] >>> 21) {
                    while (n4 + 1 < lArray.length && lArray[n4 + 1] >>> 21 == lArray[n4] >>> 21) {
                        ++n4;
                    }
                } else {
                    int n6 = (int)(lArray[n4] & l);
                    nArray2[n6] = n3 = (int)(lArray[n4 + 1] & l);
                    nArray2[n3] = n6;
                    ++n4;
                }
            }
            ++n4;
        }
        boolean[] blArray = new boolean[n];
        for (int i = 0; i < n; ++i) {
            int n7;
            int n8;
            if (blArray[i]) continue;
            n3 = -1;
            for (n8 = 0; n8 < 3 && n3 < 0; ++n8) {
                n7 = nArray2[i * 3 + n8];
                if (n7 < 0 || blArray[n7 / 3] || n7 / 3 == i) continue;
                n3 = n8;
            }
            n8 = nArray[i * 3];
            n7 = nArray[i * 3 + 1];
            int n9 = nArray[i * 3 + 2];
            if (n3 < 0) {
                blArray[i] = true;
                quadCount.Y(n8, n7, n9, n9, 1);
                continue;
            }
            int n10 = nArray2[i * 3 + n3];
            int n11 = n10 / 3;
            blArray[i] = true;
            blArray[n11] = true;
            int n12 = nArray[i * 3 + n3];
            int n13 = nArray[i * 3 + (n3 + 1) % 3];
            int n14 = nArray[i * 3 + (n3 + 2) % 3];
            int n15 = nArray[n11 * 3 + (n10 % 3 + 2) % 3];
            quadCount.Y(n12, n15, n13, n14, 2);
        }
    }

    private static Triangles G(OutlineColorSet outlineColorSet, Count2 count2, VertexCount vertexCount, Height3 height3) {
        QuadCount quadCount = new QuadCount();
        float[] fArray = new float[200];
        float[] fArray2 = new float[200];
        for (DecalSizeMust decalSizeMust : outlineColorSet.decals) {
            for (int i = 0; i < vertexCount.triCount; ++i) {
                int n = vertexCount.tris[i * 3];
                int n2 = vertexCount.tris[i * 3 + 1];
                int n3 = vertexCount.tris[i * 3 + 2];
                if (!CharacterMesh.C(decalSizeMust, count2, n, n2, n3)) continue;
                int[] nArray = new int[]{n, n2, n3};
                float f = 0.0f;
                for (int j = 0; j < 3; ++j) {
                    int n4 = nArray[j];
                    int n5 = j * 10;
                    fArray[n5] = count2.pos[n4 * 3];
                    fArray[n5 + 1] = count2.pos[n4 * 3 + 1];
                    fArray[n5 + 2] = count2.pos[n4 * 3 + 2];
                    fArray[n5 + 3] = count2.nrm[n4 * 3];
                    fArray[n5 + 4] = count2.nrm[n4 * 3 + 1];
                    fArray[n5 + 5] = count2.nrm[n4 * 3 + 2];
                    fArray[n5 + 8] = count2.ao[n4];
                    fArray[n5 + 9] = count2.flat[n4];
                    float f2 = fArray[n5] - decalSizeMust.cx;
                    float f3 = fArray[n5 + 1] - decalSizeMust.cy;
                    float f4 = fArray[n5 + 2] - decalSizeMust.cz;
                    if (!decalSizeMust.wrap) {
                        fArray[n5 + 6] = 0.5f + (f2 * decalSizeMust.rx + f3 * decalSizeMust.ry + f4 * decalSizeMust.rz) / decalSizeMust.width;
                        fArray[n5 + 7] = 0.5f - (f2 * decalSizeMust.ux + f3 * decalSizeMust.uy + f4 * decalSizeMust.uz) / decalSizeMust.height;
                        continue;
                    }
                    float f5 = f2 * decalSizeMust.dx + f3 * decalSizeMust.dy + f4 * decalSizeMust.dz;
                    float f6 = f2 - f5 * decalSizeMust.dx;
                    float f7 = f3 - f5 * decalSizeMust.dy;
                    float f8 = f4 - f5 * decalSizeMust.dz;
                    float f9 = (float)Math.toDegrees(Math.atan2(f6 * decalSizeMust.rx + f7 * decalSizeMust.ry + f8 * decalSizeMust.rz, f6 * decalSizeMust.ux + f7 * decalSizeMust.uy + f8 * decalSizeMust.uz));
                    if (j == 0) {
                        f = f9;
                    } else {
                        float f10;
                        for (f10 = f9 - f; f10 > 180.0f; f10 -= 360.0f) {
                        }
                        while (f10 < -180.0f) {
                            f10 += 360.0f;
                        }
                        f9 = f + f10;
                    }
                    fArray[n5 + 6] = 0.5f + f9 / decalSizeMust.width;
                    fArray[n5 + 7] = 0.5f - f5 / decalSizeMust.height;
                }
                CharacterMesh.L(decalSizeMust, fArray, fArray2, 0.0f, outlineColorSet, height3, quadCount);
                if (!decalSizeMust.wrap || !(decalSizeMust.width >= 359.9f)) continue;
                CharacterMesh.L(decalSizeMust, fArray, fArray2, 1.0f, outlineColorSet, height3, quadCount);
                CharacterMesh.L(decalSizeMust, fArray, fArray2, -1.0f, outlineColorSet, height3, quadCount);
            }
        }
        return quadCount.i();
    }

    private static boolean C(DecalSizeMust decalSizeMust, Count2 count2, int n, int n2, int n3) {
        float f = count2.pos[n * 3 + 1];
        float f2 = count2.pos[n2 * 3 + 1] - f;
        float f3 = count2.pos[n * 3 + 2];
        float f4 = count2.pos[n3 * 3 + 2] - f3;
        float f5 = count2.pos[n2 * 3 + 2] - f3;
        float f6 = count2.pos[n3 * 3 + 1] - f;
        float f7 = f2 * f4 - f5 * f6;
        float f8 = count2.pos[n * 3];
        float f9 = count2.pos[n3 * 3] - f8;
        float f10 = count2.pos[n2 * 3] - f8;
        float f11 = f5 * f9 - f10 * f4;
        float f12 = f10 * f6 - f2 * f9;
        float f13 = (float)Math.sqrt(f7 * f7 + f11 * f11 + f12 * f12);
        if (f13 < 1.0E-10f) {
            return false;
        }
        f7 /= f13;
        f11 /= f13;
        f12 /= f13;
        int[] nArray = new int[]{n, n2, n3};
        if (!decalSizeMust.wrap) {
            if (f7 * decalSizeMust.dx + f11 * decalSizeMust.dy + f12 * decalSizeMust.dz < decalSizeMust.cosLimit) {
                return false;
            }
            int[] nArray2 = nArray;
            int n4 = nArray2.length;
            int n5 = 0;
            while (n5 < n4) {
                int n6 = nArray2[n5];
                float f14 = (count2.pos[n6 * 3] - decalSizeMust.cx) * decalSizeMust.dx + (count2.pos[n6 * 3 + 1] - decalSizeMust.cy) * decalSizeMust.dy + (count2.pos[n6 * 3 + 2] - decalSizeMust.cz) * decalSizeMust.dz;
                if (f14 < decalSizeMust.near) return false;
                if (f14 > decalSizeMust.far) {
                    return false;
                }
                ++n5;
            }
            return true;
        }
        float f15 = (count2.pos[n * 3] + count2.pos[n2 * 3] + count2.pos[n3 * 3]) / 3.0f - decalSizeMust.cx;
        float f16 = (count2.pos[n * 3 + 1] + count2.pos[n2 * 3 + 1] + count2.pos[n3 * 3 + 1]) / 3.0f - decalSizeMust.cy;
        float f17 = (count2.pos[n * 3 + 2] + count2.pos[n2 * 3 + 2] + count2.pos[n3 * 3 + 2]) / 3.0f - decalSizeMust.cz;
        float f18 = f15 * decalSizeMust.dx + f16 * decalSizeMust.dy + f17 * decalSizeMust.dz;
        float f19 = f15 - f18 * decalSizeMust.dx;
        float f20 = f16 - f18 * decalSizeMust.dy;
        float f21 = f17 - f18 * decalSizeMust.dz;
        float f22 = (float)Math.sqrt(f19 * f19 + f20 * f20 + f21 * f21);
        if (f22 < 1.0E-5f) {
            return false;
        }
        if ((f7 * f19 + f11 * f20 + f12 * f21) / f22 < decalSizeMust.cosLimit) {
            return false;
        }
        float f23 = decalSizeMust.near == -3.4028235E38f ? 0.0f : decalSizeMust.near;
        if (!(f22 >= f23)) return false;
        if (!(f22 <= decalSizeMust.far)) return false;
        return true;
    }

    private static void L(DecalSizeMust decalSizeMust, float[] fArray, float[] fArray2, float f, OutlineColorSet outlineColorSet, Height3 height3, QuadCount quadCount) {
        int n;
        int n2;
        float[] fArray3 = new float[200];
        System.arraycopy(fArray, 0, fArray3, 0, 30);
        if (f != 0.0f) {
            for (n2 = 0; n2 < 3; ++n2) {
                fArray3[n2 * 10 + 6] = fArray3[n2 * 10 + 6] + f;
            }
        }
        n2 = 3;
        n2 = CharacterMesh.i(fArray3, n2, fArray2, 6, 0.0f, true);
        n2 = CharacterMesh.i(fArray2, n2, fArray3, 6, 1.0f, false);
        n2 = CharacterMesh.i(fArray3, n2, fArray2, 7, 0.0f, true);
        if ((n2 = CharacterMesh.i(fArray2, n2, fArray3, 7, 1.0f, false)) < 3) return;
        int n3 = -1;
        for (n = 0; n < n2; ++n) {
            int n4 = n * 10;
            float f2 = fArray3[n4 + 3];
            float f3 = fArray3[n4 + 4];
            float f4 = fArray3[n4 + 5];
            float f5 = (float)Math.sqrt(f2 * f2 + f3 * f3 + f4 * f4);
            if (f5 > 1.0E-8f) {
                f2 /= f5;
                f3 /= f5;
                f4 /= f5;
            }
            int n5 = OcclusionWeight.G(1.0f - decalSizeMust.occlusion * (1.0f - fArray3[n4 + 8]));
            int n6 = 0xFF000000 | n5 << 16 | n5 << 8 | n5;
            float f6 = decalSizeMust.flat == decalSizeMust.flat ? decalSizeMust.flat : fArray3[n4 + 9];
            int n7 = quadCount.G(fArray3[n4] + f2 * decalSizeMust.offset - outlineColorSet.pivotX, fArray3[n4 + 1] + f3 * decalSizeMust.offset - outlineColorSet.pivotY, fArray3[n4 + 2] + f4 * decalSizeMust.offset - outlineColorSet.pivotZ, f2, f3, f4, height3.j(decalSizeMust.canvas, fArray3[n4 + 6]), height3.B(decalSizeMust.canvas, fArray3[n4 + 7]), n6, decalSizeMust.glow, f6);
            if (n3 >= 0) continue;
            n3 = n7;
        }
        n = 1;
        while (n + 2 < n2) {
            quadCount.Y(n3, n3 + n, n3 + n + 1, n3 + n + 2, 2);
            n += 2;
        }
        if (n + 1 >= n2) return;
        quadCount.Y(n3, n3 + n, n3 + n + 1, n3 + n + 1, 1);
    }

    private static int i(float[] fArray, int n, float[] fArray2, int n2, float f, boolean bl) {
        int n3 = 0;
        for (int i = 0; i < n; ++i) {
            float f2;
            int n4 = i * 10;
            int n5 = (i + n - 1) % n * 10;
            float f3 = bl ? fArray[n4 + n2] - f : f - fArray[n4 + n2];
            float f4 = f2 = bl ? fArray[n5 + n2] - f : f - fArray[n5 + n2];
            if (f3 >= 0.0f) {
                if (f2 < 0.0f) {
                    n3 = CharacterMesh.P(fArray, n5, n4, f2, f3, fArray2, n3);
                }
                System.arraycopy(fArray, n4, fArray2, n3 * 10, 10);
                ++n3;
            } else if (f2 >= 0.0f) {
                n3 = CharacterMesh.P(fArray, n5, n4, f2, f3, fArray2, n3);
            }
            if (n3 >= 19) return n3;
        }
        return n3;
    }

    private static int P(float[] fArray, int n, int n2, float f, float f2, float[] fArray2, int n3) {
        float f3 = f / (f - f2);
        for (int i = 0; i < 10; ++i) {
            fArray2[n3 * 10 + i] = fArray[n + i] + (fArray[n2 + i] - fArray[n + i]) * f3;
        }
        return n3 + 1;
    }

    private static float J(Triangles triangles) {
        if (triangles == null) {
            return 1.0f;
        }
        float f = 0.0f;
        for (int i = 0; i < triangles.M(); ++i) {
            float f2 = triangles.pos[i * 3];
            float f3 = triangles.pos[i * 3 + 1];
            float f4 = triangles.pos[i * 3 + 2];
            f = Math.max(f, f2 * f2 + f3 * f3 + f4 * f4);
        }
        return Math.max(0.5f, (float)Math.sqrt(f));
    }

    private static void M(Triangles triangles, OutlineColorSet outlineColorSet, OutlineColorSet outlineColorSet2) {
        if (triangles == null) return;
        float[] fArray = new float[triangles.M()];
        float f = outlineColorSet2.jointX - outlineColorSet.pivotX;
        float f2 = outlineColorSet2.jointY - outlineColorSet.pivotY;
        float f3 = outlineColorSet2.jointZ - outlineColorSet.pivotZ;
        float f4 = outlineColorSet2.jointBlend;
        boolean bl = false;
        for (int i = 0; i < fArray.length; ++i) {
            float f5 = (triangles.pos[i * 3] - f) * outlineColorSet2.jointDirX + (triangles.pos[i * 3 + 1] - f2) * outlineColorSet2.jointDirY + (triangles.pos[i * 3 + 2] - f3) * outlineColorSet2.jointDirZ;
            float f6 = Math.max(0.0f, Math.min(1.0f, (f5 + f4) / (2.0f * f4)));
            fArray[i] = f6 * f6 * (3.0f - 2.0f * f6);
            bl |= fArray[i] > 0.0f;
        }
        if (!bl) return;
        triangles.joint = fArray;
    }

    private static void b(Triangles triangles, float f, float f2) {
        if (triangles == null) return;
        float[] fArray = new float[triangles.M()];
        for (int i = 0; i < fArray.length; ++i) {
            float f3 = triangles.pos[i * 3];
            float f4 = triangles.pos[i * 3 + 1];
            float f5 = triangles.pos[i * 3 + 2];
            float f6 = Math.min(1.0f, (float)Math.sqrt(f3 * f3 + f4 * f4 + f5 * f5) / f);
            fArray[i] = (float)Math.pow(f6, f2);
        }
        triangles.weight = fArray;
    }

    private static void lmbd$hullSurface$0(Count2 count2, float f, float f2, Paint paint, float f3, float[] fArray, float[] fArray2, int n) {
        float[] fArray3 = new float[3];
        float[] fArray4 = new float[3];
        int n2 = Math.min(count2.count, (n + 1) * 256);
        for (int i = n * 256; i < n2; ++i) {
            float f4;
            float f5 = count2.pos[i * 3];
            float f6 = count2.pos[i * 3 + 1];
            float f7 = count2.pos[i * 3 + 2];
            float f8 = count2.nrm[i * 3];
            float f9 = count2.nrm[i * 3 + 1];
            float f10 = count2.nrm[i * 3 + 2];
            float f11 = f4 = count2.cover != null && count2.cover[i] < 0.0f ? 0.0f : f;
            if (f4 > 0.0f) {
                float f12 = 0.0f;
                for (int j = 1; j <= 5; ++j) {
                    float f13 = f2 * (float)j / 5.0f;
                    f12 = Math.max(f12, -paint.Q(f5 - f8 * f13, f6 - f9 * f13, f7 - f10 * f13));
                }
                f4 = Math.min(f4, 0.5f * f12);
            }
            fArray3[0] = f5 + f8 * f4;
            fArray3[1] = f6 + f9 * f4;
            fArray3[2] = f7 + f10 * f4;
            if (f4 > 0.0f) {
                CharacterMesh.B(paint, fArray3, fArray4, f3, f4);
            }
            fArray[i * 3] = fArray3[0];
            fArray[i * 3 + 1] = fArray3[1];
            fArray[i * 3 + 2] = fArray3[2];
            fArray2[i] = f4;
        }
    }

    private static void lmbd$bury$0(Count2 count2, Paint paint, float[] fArray, float f, int n) {
        float[] fArray2 = new float[3];
        float[] fArray3 = new float[3];
        int n2 = Math.min(count2.count, (n + 1) * 256);
        for (int i = n * 256; i < n2; ++i) {
            float f2;
            fArray2[0] = count2.pos[i * 3];
            fArray2[1] = count2.pos[i * 3 + 1];
            fArray2[2] = count2.pos[i * 3 + 2];
            fArray[i] = f2 = paint.Q(fArray2[0], fArray2[1], fArray2[2]);
            if (!(f2 < 0.0f)) continue;
            CharacterMesh.w(paint, fArray2, Math.max(0.01f, f * 0.3f), fArray3);
            float f3 = Math.min(0.12f, -2.0f * f2);
            count2.pos[i * 3] = fArray2[0] - fArray3[0] * f3;
            count2.pos[i * 3 + 1] = fArray2[1] - fArray3[1] * f3;
            count2.pos[i * 3 + 2] = fArray2[2] - fArray3[2] * f3;
        }
    }

    private static void lmbd$shade$0(VertexCount vertexCount, Paint paint, float f, Count2 count2, Paint paint2, float f2, float f3, int n) {
        float[] fArray = new float[3];
        float[] fArray2 = new float[3];
        OcclusionWeight occlusionWeight = new OcclusionWeight();
        int n2 = Math.min(vertexCount.vertexCount, (n + 1) * 256);
        for (int i = n * 256; i < n2; ++i) {
            fArray[0] = vertexCount.pos[i * 3];
            fArray[1] = vertexCount.pos[i * 3 + 1];
            fArray[2] = vertexCount.pos[i * 3 + 2];
            CharacterMesh.X(paint, fArray, fArray2, f);
            System.arraycopy(fArray, 0, count2.pos, i * 3, 3);
            System.arraycopy(fArray2, 0, count2.nrm, i * 3, 3);
            paint.I(fArray[0], fArray[1], fArray[2], occlusionWeight);
            float f4 = CharacterMesh.s(paint2, fArray[0], fArray[1], fArray[2], fArray2[0], fArray2[1], fArray2[2], occlusionWeight.p(f2));
            f4 += (1.0f - f4) * Math.min(1.0f, occlusionWeight.glow);
            count2.ao[i] = f4;
            count2.flat[i] = occlusionWeight.X(f3);
            count2.glow[i] = (byte)(occlusionWeight.glow >= 0.5f ? 1 : 0);
            count2.color[i] = 0xFF000000 | OcclusionWeight.G(occlusionWeight.r * f4) << 16 | OcclusionWeight.G(occlusionWeight.g * f4) << 8 | OcclusionWeight.G(occlusionWeight.b * f4);
        }
    }

    private static void lmbd$build$3(List list, VertexCount[] vertexCountArray, ScaleMustBetween scaleMustBetween, Paint[] paintArray, Paint paint, float[] fArray, Paint[] paintArray2, Height3 height3, float[] fArray2, float[] fArray3, Map map, MotionSlot[] motionSlotArray, int[] nArray, int n) {
        boolean bl;
        FollowAmount followAmount;
        Object object;
        OutlineColorSet outlineColorSet = (OutlineColorSet)list.get(n);
        Triangles triangles = null;
        Triangles triangles2 = null;
        Triangles triangles3 = null;
        if (vertexCountArray[n] != null && vertexCountArray[n].triCount > 0) {
            float f;
            float f2 = outlineColorSet.occlusion >= 0.0f ? outlineColorSet.occlusion : scaleMustBetween.occlusion;
            Count2 count2 = CharacterMesh.E(paintArray[n], paint, vertexCountArray[n], fArray[n], f2, f = outlineColorSet.flat >= 0.0f ? outlineColorSet.flat : scaleMustBetween.flat);
            triangles = CharacterMesh.o(count2, (VertexCount)(object = CharacterMesh.p(count2, vertexCountArray[n], paintArray2[n], fArray[n])), outlineColorSet, height3);
            if (triangles != null && fArray2[n] > 0.0f) {
                int n2 = outlineColorSet.outlineColorSet ? outlineColorSet.outlineColor : scaleMustBetween.outlineColor;
                triangles2 = CharacterMesh.Y(paintArray[n], count2, triangles, outlineColorSet, fArray2[n], fArray[n], n2, height3);
            }
            if (!outlineColorSet.decals.isEmpty()) {
                triangles3 = CharacterMesh.G(outlineColorSet, count2, (VertexCount)object, height3);
            }
            float[] fArray4 = fArray3;

            for (int i = 0; i < count2.count; ++i) {
                fArray3[0] = Math.min(fArray3[0], count2.pos[i * 3 + 1]);
                fArray3[1] = Math.max(fArray3[1], count2.pos[i * 3 + 1]);
            }

        }
        int n3 = outlineColorSet.parent == null ? -1 : (Integer)map.get(outlineColorSet.parent);
        FollowAmount followAmount2 = followAmount = outlineColorSet.extra ? outlineColorSet.motion : null;
        if (followAmount != null && followAmount.a() > 0.0f) {
            float f = CharacterMesh.J(triangles);
            CharacterMesh.b(triangles, f, followAmount.a());
            if (triangles2 != null && triangles != null) {
                triangles2.weight = triangles.weight;
            }
            CharacterMesh.b(triangles3, f, followAmount.a());
        }
        boolean bl2 = !outlineColorSet.extra && (outlineColorSet.bone.arm() || outlineColorSet.bone.leg());
        object = outlineColorSet;
        while (object != null && !((OutlineColorSet)object).jointSet) {
            object = ((OutlineColorSet)object).parent;
        }
        boolean bl3 = bl = object != null;
        if (bl) {
            CharacterMesh.M(triangles, outlineColorSet, (OutlineColorSet)object);
            CharacterMesh.M(triangles3, outlineColorSet, (OutlineColorSet)object);
            if (triangles2 != null && triangles != null) {
                triangles2.joint = triangles.joint;
            }
        }
        motionSlotArray[n] = new MotionSlot(outlineColorSet.name, outlineColorSet.bone, n3, outlineColorSet.extra, outlineColorSet.pivotX, outlineColorSet.pivotY, outlineColorSet.pivotZ, outlineColorSet.e(), outlineColorSet.T(), outlineColorSet.k(), followAmount, triangles, triangles2, triangles3, nArray[n], bl2 ? outlineColorSet.swing : 1.0f, bl2 ? outlineColorSet.swingLimit : 0.0f, bl, bl ? ((OutlineColorSet)object).jointX - outlineColorSet.pivotX : 0.0f, bl ? ((OutlineColorSet)object).jointY - outlineColorSet.pivotY : 0.0f, bl ? ((OutlineColorSet)object).jointZ - outlineColorSet.pivotZ : 0.0f, bl && ((OutlineColorSet)object).neck, bl ? ((OutlineColorSet)object).lookPitch : 0.0f, bl ? ((OutlineColorSet)object).lookYaw : 0.0f, bl ? ((OutlineColorSet)object).lookLimit : 0.0f);
    }

    private static void lmbd$build$2(VertexCount[] vertexCountArray, int[] nArray, VertexCount[] vertexCountArray2, int n) {
        if (vertexCountArray[n] == null || vertexCountArray[n].triCount == 0) return;
        MeshDecimator rpTWtydngo9fnatLv = new MeshDecimator(vertexCountArray[n]);
        rpTWtydngo9fnatLv.t(nArray[n]);
        vertexCountArray2[n] = rpTWtydngo9fnatLv.J();
    }

    private static void lmbd$build$1(Paint[] paintArray, VertexCount[] vertexCountArray, float[] fArray, float[] fArray2, Paint[] paintArray2, int n) {
        Paint paint = paintArray[n];
        if (paint == null) return;
        vertexCountArray[n] = Active.n(paint, paint.minX, paint.minY, paint.minZ, paint.maxX, paint.maxY, paint.maxZ, fArray[n]);
        fArray2[n] = CharacterMesh.I(vertexCountArray[n], paintArray2[n]);
    }

    private static Paint lmbd$build$0(float f, Paint paint) {
        Paint paint2;
        if (paint instanceof FlatMode) {
            FlatMode flatMode = (FlatMode)paint;
            paint2 = flatMode.v(f);
            return paint2;
        } else {
            paint2 = paint;
        }
        return paint2;
    }
}
