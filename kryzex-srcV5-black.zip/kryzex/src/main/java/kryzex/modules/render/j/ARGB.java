package kryzex.modules.render.j;

import kryzex.modules.render.j.OcclusionWeight;
import kryzex.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class ARGB
extends Fill {
    private final int argb;

    ARGB(int n) {
        this.argb = n;
    }

    @Override
    public void B(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        occlusionWeight.i(this.argb);
    }
}
