package kryzex.modules.render.j;

import java.util.function.UnaryOperator;
import kryzex.modules.render.j.OcclusionWeight;
import kryzex.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child9
extends Paint {
    private final Paint child;
    private final float dx;
    private final float dy;
    private final float dz;

    Child9(Paint paint, float f, float f2, float f3) {
        this.child = paint;
        this.dx = f;
        this.dy = f2;
        this.dz = f3;
        if (!paint.M()) return;
        this.c(paint.minX + f, paint.minY + f2, paint.minZ + f3, paint.maxX + f, paint.maxY + f2, paint.maxZ + f3);
    }

    @Override
    Paint N(float f, float f2, float f3, float f4, float f5, float f6) {
        Paint paint = this.child.N(f - this.dx, f2 - this.dy, f3 - this.dz, f4 - this.dx, f5 - this.dy, f6 - this.dz);
        return paint == this.child ? this : new Child9(paint, this.dx, this.dy, this.dz);
    }

    @Override
    Paint h(UnaryOperator<Paint> unaryOperator) {
        Paint paint = this.child.h(unaryOperator);
        return (Paint)unaryOperator.apply(paint == this.child ? this : new Child9(paint, this.dx, this.dy, this.dz).t(this));
    }

    @Override
    public float Q(float f, float f2, float f3) {
        return this.child.Q(f - this.dx, f2 - this.dy, f3 - this.dz);
    }

    @Override
    float R(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        return this.child.I(f - this.dx, f2 - this.dy, f3 - this.dz, occlusionWeight);
    }
}
