package kryzex.modules.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import java.util.function.Supplier;
import kryzex.modules.render.DownConfig;
import kryzex.util.Iris;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import org.lwjgl.BufferUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
final class KryzexHandAura {
    private static Logger LOGGER;
    private static RenderPipeline PIPELINE;
    private static Supplier<String> PASS_LABEL;
    private static Supplier<String> CONFIG_LABEL;
    private static final int CONFIG_SIZE = 48;
    private static class_6367 hand;
    private static DownConfig blur;
    private static GpuBuffer config;
    private static GpuBufferSlice configSlice;
    private static ByteBuffer configData;
    private static boolean capturing;
    private static boolean invalidShaderLogged;
    private static String[] a;

    private KryzexHandAura() {
    }

    static boolean M() {
        if (capturing || RenderSystem.outputColorTextureOverride != null || RenderSystem.outputDepthTextureOverride != null) return false;
        class_310 class_3102 = class_310.method_1551();
        class_276 class_2762 = class_3102.method_1522();
        if (class_3102.field_1687 == null || class_3102.field_1773.method_35765() || class_2762.method_30277() == null || class_2762.field_1482 <= 0 || class_2762.field_1481 <= 0 || Iris.shaderPackInUse()) return false;
        GpuDevice gpuDevice = RenderSystem.getDevice();
        if (!KryzexHandAura.e(gpuDevice)) {
            return false;
        }
        if (hand == null) {
            KryzexHandAura.U(class_2762.field_1482, class_2762.field_1481);
        } else if (KryzexHandAura.hand.field_1482 != class_2762.field_1482 || KryzexHandAura.hand.field_1481 != class_2762.field_1481) {
            hand.method_1234(class_2762.field_1482, class_2762.field_1481);
        }
        gpuDevice.createCommandEncoder().clearColorAndDepthTextures(hand.method_30277(), 0, hand.method_30278(), 1.0);
        RenderSystem.outputColorTextureOverride = hand.method_71639();
        RenderSystem.outputDepthTextureOverride = hand.method_71640();
        capturing = true;
        return true;
    }

    static boolean a() {
        if (!capturing) {
            return false;
        }
        capturing = false;
        RenderSystem.outputColorTextureOverride = null;
        RenderSystem.outputDepthTextureOverride = null;
        return true;
    }

    static void Z(int n, float f, float f2, float f3, float f4, int n2, float f5, float f6) {
        class_276 class_2762 = class_310.method_1551().method_1522();
        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        GpuTextureView gpuTextureView = f > 0.0f ? blur.L(commandEncoder, hand.method_71639(), KryzexHandAura.hand.field_1482, KryzexHandAura.hand.field_1481, f2) : hand.method_71639();
        KryzexHandAura.A(0, n, f);
        KryzexHandAura.A(16, n2, f5);
        configData.putFloat(32, f3);
        configData.putFloat(36, f4);
        configData.putFloat(40, f6);
        configData.putFloat(44, 0.0f);
        commandEncoder.writeToBuffer(configSlice, configData);
        try (RenderPass renderPass = commandEncoder.createRenderPass(PASS_LABEL, class_2762.method_71639(), OptionalInt.empty());){
            renderPass.setPipeline(PIPELINE);
            renderPass.setUniform("HandAuraConfig", configSlice);
            renderPass.bindTexture("CaptureSampler", hand.method_71639(), RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
            renderPass.bindTexture("HaloSampler", gpuTextureView, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
            renderPass.draw(0, 3);
            return;
        }
    }

    private static void A(int n, int n2, float f) {
        configData.putFloat(n, (float)(n2 >> 16 & 0xFF) / 255.0f);
        configData.putFloat(n + 4, (float)(n2 >> 8 & 0xFF) / 255.0f);
        configData.putFloat(n + 8, (float)(n2 & 0xFF) / 255.0f);
        configData.putFloat(n + 12, f);
    }

    private static boolean e(GpuDevice gpuDevice) {
        if (gpuDevice.precompilePipeline(PIPELINE).isValid() && DownConfig.A(gpuDevice)) {
            invalidShaderLogged = false;
            return true;
        }
        if (invalidShaderLogged) return false;
        invalidShaderLogged = true;
        LOGGER.warn("Hand Aura shaders did not compile; the hand is drawn as usual");
        return false;
    }

    private static void U(int n, int n2) {
        hand = new class_6367("Kryzex hand aura", n, n2, true);
        blur = new DownConfig("Kryzex hand aura");
        config = RenderSystem.getDevice().createBuffer(CONFIG_LABEL, 136, 48L);
        configSlice = config.slice();
        configData = BufferUtils.createByteBuffer(48);
    }

    static void S() {
        if (capturing) {
            KryzexHandAura.a();
        }
        if (hand != null) {
            hand.method_1238();
            hand = null;
        }
        if (blur != null) {
            blur.I();
            blur = null;
        }
        if (config != null) {
            config.close();
            config = null;
        }
        configSlice = null;
        configData = null;
    }

    private static String lmbd$static$1() {
        return "Kryzex hand aura config";
    }

    private static String lmbd$static$0() {
        return "Kryzex hand aura";
    }

    static {
        String[] stringArray = a = new String[]{"r87f4560b4c09f4", "HandAuraConfig", "r87f4560b4c09f4", "Hand Aura shaders did not compile; the hand is drawn as usual", "Kryzex hand aura", "HaloSampler", "HandAuraConfig", "CaptureSampler", "core/screenquad", "Kryzex", "core/hand_aura", "CaptureSampler", "pipeline/hand_aura", "Kryzex hand aura", "HaloSampler", "Kryzex hand aura config"};
        LOGGER = LoggerFactory.getLogger(stringArray[9]);
        PIPELINE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)stringArray[2], (String)stringArray[12])).withVertexShader(stringArray[8]).withFragmentShader(class_2960.method_60655((String)stringArray[0], (String)stringArray[10])).withSampler(stringArray[11]).withSampler(stringArray[5]).withUniform(stringArray[6], class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withColorWrite(true, false).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
        PASS_LABEL = KryzexHandAura::lmbd$static$0;
        CONFIG_LABEL = KryzexHandAura::lmbd$static$1;
    }
}
