package kryzex.modules.render.j;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class Limbs {
    public final byte[] data;
    public final List<String> limbs;

    public Limbs(byte[] data, List<String> limbs) {
        this.data = data;
        this.limbs = limbs;
    }

    public byte[] data() {
        return this.data;
    }

    public List<String> limbs() {
        return this.limbs;
    }
}
