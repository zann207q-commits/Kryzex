package kryzex.modules.render.j;

import kryzex.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Kids
extends MinX {
    private final MinX[] kids;
    private final float k;

    Kids(float f, MinX[] minXArray) {
        this.kids = (MinX[])minXArray.clone();
        this.k = Math.max(0.0f, f);
        float f2 = 100000.0f;
        float f3 = 100000.0f;
        float f4 = -100000.0f;
        float f5 = -100000.0f;
        for (MinX minX : this.kids) {
            f2 = Math.min(f2, minX.minX);
            f3 = Math.min(f3, minX.minY);
            f4 = Math.max(f4, minX.maxX);
            f5 = Math.max(f5, minX.maxY);
        }
        this.L(f2 - this.k, f3 - this.k, f4 + this.k, f5 + this.k);
    }

    @Override
    public float d(float f, float f2) {
        float f3 = this.kids[0].d(f, f2);
        for (int i = 1; i < this.kids.length; ++i) {
            float f4 = this.kids[i].d(f, f2);
            if (this.k > 0.0f) {
                float f5 = Kids.N(0.5f + 0.5f * (f4 - f3) / this.k);
                f3 = f4 + (f3 - f4) * f5 - this.k * f5 * (1.0f - f5);
                continue;
            }
            if (!(f4 < f3)) continue;
            f3 = f4;
        }
        return f3;
    }
}
