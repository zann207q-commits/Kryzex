package kryzex.modules.render.j;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import kryzex.modules.render.j.BaZtINibCYq;
import kryzex.modules.render.j.HasTriangles;
import kryzex.modules.render.j.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Version {
    private final float[] pos;
    private final int[] tri;
    private final boolean[] dead;
    private final int[] corner;
    private final List<List<Integer>> around = new ArrayList<List<Integer>>();
    private final boolean[] locked;
    private final double[] quad;
    private final int[] version;
    private int live;

    Version(HasTriangles hasTriangles, List<Integer> list, boolean bl) {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        HashMap<Long, Integer> hashMap = new HashMap<Long, Integer>();
        HashMap<CallSite, Integer> hashMap2 = new HashMap<CallSite, Integer>();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        this.tri = new int[list.size() * 3];
        for (n6 = 0; n6 < list.size(); ++n6) {
            n5 = list.get(n6);
            n4 = n5 < 0 ? 1 : 0;
            n3 = n4 != 0 ? ~n5 : n5;
            for (n2 = 0; n2 < 3; ++n2) {
                n = hasTriangles.tris[n3 * 3 + (n4 != 0 ? 2 - n2 : n2)];
                int n7 = n4 != 0 ? ~n : n;
                Integer n8 = (Integer)hashMap.get(n7);
                if (n8 == null && bl) {
                    String string = Float.floatToIntBits(hasTriangles.pos[n * 3]) + "," + Float.floatToIntBits(hasTriangles.pos[n * 3 + 1]) + "," + Float.floatToIntBits(hasTriangles.pos[n * 3 + 2]) + "," + Float.floatToIntBits(hasTriangles.uv[n * 2]) + "," + Float.floatToIntBits(hasTriangles.uv[n * 2 + 1]) + "," + hasTriangles.material[n] + (n4 != 0 ? "b" : "");
                    n8 = (Integer)hashMap2.get(string);
                    if (n8 == null) {
                        hashMap2.put((CallSite)((Object)string), arrayList.size());
                    }
                    if (n8 != null) {
                        hashMap.put(Long.valueOf(n7), n8);
                    }
                }
                if (n8 == null) {
                    n8 = arrayList.size();
                    hashMap.put(Long.valueOf(n7), n8);
                    arrayList.add(n7);
                }
                this.tri[n6 * 3 + n2] = n8;
            }
        }
        n6 = arrayList.size();
        this.corner = new int[n6];
        this.pos = new float[n6 * 3];
        for (n5 = 0; n5 < n6; ++n5) {
            this.corner[n5] = (Integer)arrayList.get(n5);
            n4 = this.corner[n5] < 0 ? ~this.corner[n5] : this.corner[n5];
            System.arraycopy(hasTriangles.pos, n4 * 3, this.pos, n5 * 3, 3);
        }
        this.dead = new boolean[list.size()];
        this.live = list.size();
        for (n5 = 0; n5 < n6; ++n5) {
            this.around.add(new ArrayList());
        }
        for (n5 = 0; n5 < list.size(); ++n5) {
            n4 = this.tri[n5 * 3];
            n3 = this.tri[n5 * 3 + 1];
            n2 = this.tri[n5 * 3 + 2];
            if (n4 != n3 && n3 != n2 && n4 != n2) {
                for (n = 0; n < 3; ++n) {
                    this.around.get(this.tri[n5 * 3 + n]).add(n5);
                }
                continue;
            }
            this.dead[n5] = true;
            --this.live;
        }
        this.locked = new boolean[n6];
        HashMap<Long, Integer> hashMap3 = new HashMap<Long, Integer>();
        for (n4 = 0; n4 < list.size(); ++n4) {
            if (this.dead[n4]) continue;
            for (n3 = 0; n3 < 3; ++n3) {
                hashMap3.merge(Version.V(this.tri[n4 * 3 + n3], this.tri[n4 * 3 + (n3 + 1) % 3]), 1, Integer::sum);
            }
        }
        for (Map.Entry entry : hashMap3.entrySet()) {
            if ((Integer)entry.getValue() == 2) continue;
            this.locked[(int)(((Long)entry.getKey()).longValue() >> 32)] = true;
            this.locked[(int)(((Long)entry.getKey()).longValue() & 0xFFFFFFFFL)] = true;
        }
        this.quad = new double[n6 * 10];
        for (int i = 0; i < list.size(); ++i) {
            int n9;
            float[] fArray;
            double d;
            if (this.dead[i] || (d = Math.sqrt((fArray = Rotation.k(this.pos, n9 = this.tri[i * 3], n2 = this.tri[i * 3 + 1], n = this.tri[i * 3 + 2]))[0] * fArray[0] + fArray[1] * fArray[1] + fArray[2] * fArray[2])) < 1.0E-12) continue;
            double d2 = (double)fArray[0] / d;
            double d3 = (double)fArray[1] / d;
            double d4 = (double)fArray[2] / d;
            double d5 = -(d2 * (double)this.pos[n9 * 3] + d3 * (double)this.pos[n9 * 3 + 1] + d4 * (double)this.pos[n9 * 3 + 2]);
            for (int n10 : new int[]{n9, n2, n}) {
                this.s(n10, d2, d3, d4, d5, d * 0.5);
            }
        }
        this.version = new int[n6];
    }

    private static long V(int n, int n2) {
        return (long)Math.min(n, n2) << 32 | (long)Math.max(n, n2);
    }

    private void s(int n, double d, double d2, double d3, double d4, double d5) {
        int n2 = n * 10;
        this.quad[n2] = this.quad[n2] + d5 * d * d;
        this.quad[n2 + 1] = this.quad[n2 + 1] + d5 * d * d2;
        this.quad[n2 + 2] = this.quad[n2 + 2] + d5 * d * d3;
        this.quad[n2 + 3] = this.quad[n2 + 3] + d5 * d * d4;
        this.quad[n2 + 4] = this.quad[n2 + 4] + d5 * d2 * d2;
        this.quad[n2 + 5] = this.quad[n2 + 5] + d5 * d2 * d3;
        this.quad[n2 + 6] = this.quad[n2 + 6] + d5 * d2 * d4;
        this.quad[n2 + 7] = this.quad[n2 + 7] + d5 * d3 * d3;
        this.quad[n2 + 8] = this.quad[n2 + 8] + d5 * d3 * d4;
        this.quad[n2 + 9] = this.quad[n2 + 9] + d5 * d4 * d4;
    }

    private double c(int n, double d, double d2, double d3) {
        double[] dArray = this.quad;
        int n2 = n * 10;
        return dArray[n2] * d * d + 2.0 * dArray[n2 + 1] * d * d2 + 2.0 * dArray[n2 + 2] * d * d3 + 2.0 * dArray[n2 + 3] * d + dArray[n2 + 4] * d2 * d2 + 2.0 * dArray[n2 + 5] * d2 * d3 + 2.0 * dArray[n2 + 6] * d2 + dArray[n2 + 7] * d3 * d3 + 2.0 * dArray[n2 + 8] * d3 + dArray[n2 + 9];
    }

    int[][] j(int[] nArray) {
        PriorityQueue<BaZtINibCYq> priorityQueue = new PriorityQueue<BaZtINibCYq>(Version::lmbd$reduce$0);
        for (int i = 0; i < this.locked.length; ++i) {
            this.C(priorityQueue, i);
        }
        int[][] nArrayArray = new int[nArray.length][];
        Integer[] integerArray = new Integer[nArray.length];
        for (int i = 0; i < integerArray.length; ++i) {
            integerArray[i] = i;
        }
        Arrays.sort(integerArray, (arg_0, arg_1) -> Version.lmbd$reduce$1(nArray, arg_0, arg_1));
        Integer[] integerArray2 = integerArray;
        int n = integerArray2.length;
        for (int i = 0; i < n; ++i) {
            int n2 = integerArray2[i];
            while (this.live > nArray[n2] && !priorityQueue.isEmpty()) {
                BaZtINibCYq baZtINibCYq = priorityQueue.poll();
                if (this.version[baZtINibCYq.from()] != baZtINibCYq.vf() || this.version[baZtINibCYq.to()] != baZtINibCYq.vt() || this.locked[baZtINibCYq.from()] || !this.Q(baZtINibCYq.from(), baZtINibCYq.to())) continue;
                HashSet<Integer> hashSet = new HashSet<Integer>();
                hashSet.add(baZtINibCYq.to());
                for (int n3 : this.around.get(baZtINibCYq.to())) {
                    if (this.dead[n3]) continue;
                    for (int j = 0; j < 3; ++j) {
                        hashSet.add(this.tri[n3 * 3 + j]);
                    }
                }
                for (int n3 : hashSet) {
                    this.C(priorityQueue, n3);
                }
            }
            nArrayArray[n2] = this.H();
        }
        return nArrayArray;
    }

    private void C(PriorityQueue<BaZtINibCYq> priorityQueue, int n) {
        if (this.locked[n]) return;
        for (int n2 : this.G(n)) {
            double d = this.pos[n2 * 3] - this.pos[n * 3];
            double d2 = this.pos[n2 * 3 + 1] - this.pos[n * 3 + 1];
            double d3 = this.pos[n2 * 3 + 2] - this.pos[n * 3 + 2];
            double d4 = this.c(n, this.pos[n2 * 3], this.pos[n2 * 3 + 1], this.pos[n2 * 3 + 2]) + 1.0E-4 * (d * d + d2 * d2 + d3 * d3);
            priorityQueue.add(new BaZtINibCYq(d4, n, n2, this.version[n], this.version[n2]));
        }
    }

    private List<Integer> G(int n) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (int n2 : this.around.get(n)) {
            if (this.dead[n2]) continue;
            for (int i = 0; i < 3; ++i) {
                int n3 = this.tri[n2 * 3 + i];
                if (n3 == n || arrayList.contains(n3)) continue;
                arrayList.add(n3);
            }
        }
        return arrayList;
    }

    private boolean Q(int n, int n2) {
        List<Integer> list = this.G(n);
        List<Integer> list2 = this.G(n2);
        if (!list.contains(n2)) {
            return false;
        }
        int n3 = 0;
        int n4 = 0;
        for (int n5 : this.around.get(n)) {
            if (this.dead[n5] || !this.g(n5, n2)) continue;
            ++n3;
        }
        for (int n5 : list) {
            if (!list2.contains(n5)) continue;
            ++n4;
        }
        if (n4 != n3) {
            return false;
        }
        for (int n5 : this.around.get(n)) {
            if (this.dead[n5] || this.g(n5, n2)) continue;
            float[] fArray = Rotation.k(this.pos, this.tri[n5 * 3], this.tri[n5 * 3 + 1], this.tri[n5 * 3 + 2]);
            int[] nArray = new int[]{this.tri[n5 * 3], this.tri[n5 * 3 + 1], this.tri[n5 * 3 + 2]};
            for (int i = 0; i < 3; ++i) {
                if (nArray[i] != n) continue;
                nArray[i] = n2;
            }
            float[] fArray2 = Rotation.k(this.pos, nArray[0], nArray[1], nArray[2]);
            double d = Math.sqrt(fArray[0] * fArray[0] + fArray[1] * fArray[1] + fArray[2] * fArray[2]);
            double d2 = Math.sqrt(fArray2[0] * fArray2[0] + fArray2[1] * fArray2[1] + fArray2[2] * fArray2[2]);
            if (d2 < 1.0E-12 || d < 1.0E-12) {
                return false;
            }
            if (!((double)(fArray[0] * fArray2[0] + fArray[1] * fArray2[1] + fArray[2] * fArray2[2]) / (d2 * d) < 0.5)) continue;
            return false;
        }
        for (int n5 : this.around.get(n)) {
            if (this.dead[n5]) continue;
            if (this.g(n5, n2)) {
                this.dead[n5] = true;
                --this.live;
                continue;
            }
            for (int i = 0; i < 3; ++i) {
                if (this.tri[n5 * 3 + i] != n) continue;
                this.tri[n5 * 3 + i] = n2;
            }
            this.around.get(n2).add(n5);
        }
        this.around.get(n).clear();
        for (int i = 0; i < 10; ++i) {
            this.quad[n2 * 10 + i] = this.quad[n2 * 10 + i] + this.quad[n * 10 + i];
        }
        int n6 = n;
        this.version[n6] = this.version[n6] + 1;
        int n7 = n2;
        this.version[n7] = this.version[n7] + 1;
        this.locked[n] = true;
        return true;
    }

    private boolean g(int n, int n2) {
        if (this.tri[n * 3] == n2) return true;
        if (this.tri[n * 3 + 1] == n2) return true;
        if (this.tri[n * 3 + 2] != n2) return false;
        return true;
    }

    private int[] H() {
        int[] nArray = new int[this.live * 3];
        int n = 0;
        for (int i = 0; i < this.dead.length; ++i) {
            if (this.dead[i]) continue;
            for (int j = 0; j < 3; ++j) {
                nArray[n++] = this.corner[this.tri[i * 3 + j]];
            }
        }
        return Arrays.copyOf(nArray, n);
    }

    private static int lmbd$reduce$1(int[] nArray, Integer n, Integer n2) {
        return Integer.compare(nArray[n2], nArray[n]);
    }

    private static int lmbd$reduce$0(BaZtINibCYq baZtINibCYq, BaZtINibCYq baZtINibCYq2) {
        return Double.compare(baZtINibCYq.cost(), baZtINibCYq2.cost());
    }
}
