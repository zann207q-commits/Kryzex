package kryzex.modules.render.j;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import kryzex.modules.render.j.FirstPersonArms;
import kryzex.modules.render.j.MotionSlot;
import kryzex.modules.render.j.RightArm;
import kryzex.modules.render.j.TurnRate;
import kryzex.modules.render.j.WalkSpeed;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_3532;
import net.minecraft.class_591;
import net.minecraft.class_630;

@Environment(value=EnvType.CLIENT)
final class PrunedAt {
    private static final long FORGET_NANOS = 20000000000L;
    private static final Int2ObjectOpenHashMap<TurnRate> STATES = new Int2ObjectOpenHashMap();
    private static final WalkSpeed INPUT = new WalkSpeed();
    private static final float[] TARGET = new float[3];
    private static long prunedAt;

    private PrunedAt() {
    }

    static float[] p(class_10055 class_100552, FirstPersonArms firstPersonArms, class_591 class_5912, float[] fArray) {
        float f;
        if (firstPersonArms.motionSlots == 0) {
            return null;
        }
        long l = System.nanoTime();
        PrunedAt.N(l);
        TurnRate turnRate = (TurnRate)STATES.get(class_100552.field_53528);
        if (turnRate == null || turnRate.model != firstPersonArms) {
            turnRate = new TurnRate(firstPersonArms);
            turnRate.bodyRot = class_100552.field_53446;
            STATES.put(class_100552.field_53528, turnRate);
        }
        float f2 = f = turnRate.nanos == 0L ? 0.0f : (float)(l - turnRate.nanos) / 1.0E9f;
        if (turnRate.nanos != 0L && f < 5.0E-4f) {
            return turnRate.angles;
        }
        turnRate.nanos = l;
        float f3 = class_3532.method_15393((float)(class_100552.field_53446 - turnRate.bodyRot));
        turnRate.bodyRot = class_100552.field_53446;
        turnRate.turnRate = f > 0.0f && f < 0.25f ? (turnRate.turnRate += (f3 / f - turnRate.turnRate) * Math.min(1.0f, f * 12.0f)) : 0.0f;
        WalkSpeed walkSpeed = INPUT;
        walkSpeed.time = class_100552.field_53328 / 20.0f;
        walkSpeed.walkPos = class_100552.field_53450;
        walkSpeed.walkSpeed = class_100552.field_53451;
        walkSpeed.turnRate = turnRate.turnRate;
        PrunedAt.r(walkSpeed, RightArm.HEAD, class_5912.field_3398, fArray);
        PrunedAt.r(walkSpeed, RightArm.BODY, class_5912.field_3391, fArray);
        PrunedAt.r(walkSpeed, RightArm.RIGHT_ARM, class_5912.field_3401, fArray);
        PrunedAt.r(walkSpeed, RightArm.LEFT_ARM, class_5912.field_27433, fArray);
        PrunedAt.r(walkSpeed, RightArm.RIGHT_LEG, class_5912.field_3392, fArray);
        PrunedAt.r(walkSpeed, RightArm.LEFT_LEG, class_5912.field_3397, fArray);
        for (MotionSlot motionSlot : firstPersonArms.parts) {
            if (motionSlot.motionSlot < 0 || motionSlot.motion == null) continue;
            motionSlot.motion.k(walkSpeed, motionSlot.bone, TARGET);
            motionSlot.motion.Y(turnRate.spring, motionSlot.motionSlot * 6, TARGET, f);
            System.arraycopy(turnRate.spring, motionSlot.motionSlot * 6, turnRate.angles, motionSlot.motionSlot * 3, 3);
        }
        return turnRate.angles;
    }

    private static void r(WalkSpeed walkSpeed, RightArm rightArm, class_630 class_6302, float[] fArray) {
        int n = rightArm.ordinal();
        walkSpeed.pitch[n] = fArray[n];
        walkSpeed.yaw[n] = -class_6302.field_3675;
        walkSpeed.roll[n] = -class_6302.field_3674;
    }

    private static void N(long l) {
        if (l - prunedAt < 5000000000L) return;
        prunedAt = l;
        STATES.values().removeIf(arg_0 -> PrunedAt.lmbd$prune$0(l, arg_0));
    }

    static void e() {
        STATES.clear();
    }

    private static boolean lmbd$prune$0(long l, TurnRate turnRate) {
        if (l - turnRate.nanos <= 20000000000L) return false;
        return true;
    }
}
