package kryzex.modules.render.j;

import java.util.function.UnaryOperator;
import kryzex.modules.render.j.OcclusionWeight;
import kryzex.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child11
extends Paint {
    private final Paint child;
    private final float k;
    private final float cx;
    private final float cz;

    Child11(Paint paint, float f, float f2, float f3) {
        this.child = paint;
        this.k = (float)Math.toRadians(f);
        this.cx = f2;
        this.cz = f3;
        if (!paint.M()) return;
        float f4 = 0.0f;
        for (int i = 0; i < 4; ++i) {
            float f5 = ((i & 1) == 0 ? paint.minX : paint.maxX) - f2;
            float f6 = ((i & 2) == 0 ? paint.minZ : paint.maxZ) - f3;
            f4 = Math.max(f4, (float)Math.sqrt(f5 * f5 + f6 * f6));
        }
        this.c(f2 - f4, paint.minY, f3 - f4, f2 + f4, paint.maxY, f3 + f4);
    }

    @Override
    Paint h(UnaryOperator<Paint> unaryOperator) {
        Paint paint = this.child.h(unaryOperator);
        return (Paint)unaryOperator.apply(paint == this.child ? this : new Child11(paint, (float)Math.toDegrees(this.k), this.cx, this.cz).t(this));
    }

    @Override
    public float Q(float f, float f2, float f3) {
        float f4 = -this.k * f2;
        float f5 = (float)Math.cos(f4);
        float f6 = (float)Math.sin(f4);
        float f7 = f - this.cx;
        float f8 = f3 - this.cz;
        return this.child.Q(f5 * f7 + f6 * f8 + this.cx, f2, -f6 * f7 + f5 * f8 + this.cz);
    }

    @Override
    float R(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        float f4 = -this.k * f2;
        float f5 = (float)Math.cos(f4);
        float f6 = (float)Math.sin(f4);
        float f7 = f - this.cx;
        float f8 = f3 - this.cz;
        return this.child.I(f5 * f7 + f6 * f8 + this.cx, f2, -f6 * f7 + f5 * f8 + this.cz, occlusionWeight);
    }
}
