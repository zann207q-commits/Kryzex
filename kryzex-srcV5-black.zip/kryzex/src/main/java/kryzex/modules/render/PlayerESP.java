package kryzex.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import kryzex.event.Subscribe;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import kryzex.util.FileUtil;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class PlayerESP
extends Module {
    private static String[] a;
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
    private final NumberSetting lineWidth = new NumberSetting(SecureString.of("Line width"), 1.0, 10.0, 1.0, 1.0);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false).setDescription(SecureString.of("Draws a line from the camera to each player"));
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();

    public PlayerESP() {
        super(SecureString.of("Player ESP"), SecureString.of("Renders players through walls"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.alpha, this.lineWidth, this.tracers});
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        class_243 class_2432 = class_41842.method_71156();
        float f = class_41842.method_55437();
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        this.renderBoxes.clear();
        this.renderLines.clear();
        class_243 class_2433 = this.M(class_41842, class_2432);
        int n = 0;
        for (class_1657 class_16572 : this.mc.field_1687.method_18456()) {
            if (class_16572 == this.mc.field_1724 || class_16572.method_31481() || !class_16572.method_5805()) continue;
            class_243 class_2434 = class_16572.method_30950(f);
            float f2 = class_16572.method_17681() * 0.5f;
            if (!this.tracers.getValue() && !OriginX.box(class_2434.field_1352 - (double)f2, class_2434.field_1351, class_2434.field_1350 - (double)f2, class_2434.field_1352 + (double)f2, class_2434.field_1351 + (double)class_16572.method_17682(), class_2434.field_1350 + (double)f2)) {
                ++n;
                continue;
            }
            Color color = FileUtil.getMainColor(this.alpha.getIntValue(), n++).brighter();
            this.renderBoxes.add(new kryzex.util.Color(class_2434.field_1352 - (double)f2, class_2434.field_1351, class_2434.field_1350 - (double)f2, class_2434.field_1352 + (double)f2, class_2434.field_1351 + (double)class_16572.method_17682(), class_2434.field_1350 + (double)f2, color));
            if (!this.tracers.getValue()) continue;
            this.renderLines.add(new Start(class_2433, class_2434.method_1031(0.0, (double)class_16572.method_17682() * 0.5, 0.0), FileUtil.getMainColor(255, n), this.lineWidth.getIntValue()));
        }
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        if (this.tracers.getValue()) {
            InverseProjectionScratch.renderLines(class_45872, this.renderLines);
        }
        class_45872.method_22909();
    }

    private class_243 M(class_4184 class_41842, class_243 class_2432) {
        return InverseProjectionScratch.getTracerStart(class_41842);
    }

    static {
        a = new String[]{"Player ESP", "Alpha", "Line width", "Tracers", "Renders players through walls", "Draws a line from the camera to each player"};
    }
}
