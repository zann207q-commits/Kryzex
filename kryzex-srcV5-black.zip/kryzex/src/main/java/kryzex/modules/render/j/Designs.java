package kryzex.modules.render.j;

import java.util.ArrayList;
import java.util.List;
import kryzex.modules.render.j.Sakura;
import kryzex.modules.render.j.Miku;
import kryzex.modules.render.j.Name;
import kryzex.modules.render.j.Mika;
import kryzex.modules.render.j.Aoi;
import kryzex.modules.render.j.TralaleroTralala;
import kryzex.modules.render.j.Source2;
import kryzex.modules.render.j.Luna;
import kryzex.modules.render.j.TungTungSahur;
import kryzex.modules.render.j.CharacterLoader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Designs {
    private static List<Name> BUILT_IN;
    private static volatile List<Name> designs;

    private Designs() {
    }

    public static List<Name> w() {
        return designs;
    }

    static boolean S() {
        ArrayList<Name> arrayList = new ArrayList<Name>(BUILT_IN);
        ArrayList<String> arrayList2 = new ArrayList<String>(Designs.o(BUILT_IN));
        for (Source2 source2 : CharacterLoader.T()) {
            if (arrayList2.contains(source2.B())) continue;
            arrayList2.add(source2.B());
            arrayList.add(source2);
        }
        List<Name> list = designs;
        designs = List.copyOf(arrayList);
        if (list.size() != arrayList.size()) {
            return true;
        }
        for (int i = 0; i < arrayList.size(); ++i) {
            if (((Name)list.get(i)).C().equals(((Name)arrayList.get(i)).C())) continue;
            return true;
        }
        return false;
    }

    static List<String> W() {
        return Designs.o(designs);
    }

    private static List<String> o(List<Name> list) {
        ArrayList<String> arrayList = new ArrayList<String>(list.size());
        for (Name name : list) {
            arrayList.add(name.B());
        }
        return arrayList;
    }

    static Name Q(String string) {
        List<Name> list = designs;
        for (Name name : list) {
            if (!name.B().equals(string)) continue;
            return name;
        }
        return list.get(0);
    }

    static {
        Designs.BUILT_IN = List.of(new Sakura(), new Luna(), new Mika(), new Aoi(), new Miku(), Source2.E("cj", "CJ", "/assets/r87f4560b4c09f4/r4fe4cc3679ade9/cj.anc"), Source2.E("neighbor", "Neighbor", "/assets/r87f4560b4c09f4/r4fe4cc3679ade9/neighbor.anc"), new TungTungSahur(), new TralaleroTralala());
        Designs.designs = Designs.BUILT_IN;
    }

}
