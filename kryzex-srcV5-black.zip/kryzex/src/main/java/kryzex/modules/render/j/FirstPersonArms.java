package kryzex.modules.render.j;

import kryzex.modules.render.j.Medium;
import kryzex.modules.render.j.MotionSlot;
import kryzex.modules.render.j.RightArm;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class FirstPersonArms {
    public final String id;
    public final String name;
    public final Medium detail;
    public final float scale;
    public final MotionSlot[] parts;
    public final int motionSlots;
    public final int atlasWidth;
    public final int atlasHeight;
    public final int[][] atlasMips;
    public final float whiteU;
    public final float whiteV;
    public final float minY;
    public final float maxY;
    public final float hipY;
    public final boolean firstPersonArms;
    public final long buildMillis;

    FirstPersonArms(String string, String string2, Medium medium, float f, MotionSlot[] motionSlotArray, int n, int n2, int n3, int[][] nArray, float f2, float f3, float f4, float f5, float f6, boolean bl, long l) {
        this.id = string;
        this.name = string2;
        this.detail = medium;
        this.scale = f;
        this.parts = motionSlotArray;
        this.motionSlots = n;
        this.atlasWidth = n2;
        this.atlasHeight = n3;
        this.atlasMips = nArray;
        this.whiteU = f2;
        this.whiteV = f3;
        this.minY = f4;
        this.maxY = f5;
        this.hipY = f6;
        this.firstPersonArms = bl;
        this.buildMillis = l;
    }

    public int c() {
        int n = 0;
        for (MotionSlot motionSlot : this.parts) {
            n += motionSlot.l();
        }
        return n;
    }

    public MotionSlot f(RightArm rightArm) {
        for (MotionSlot motionSlot : this.parts) {
            if (motionSlot.extra || motionSlot.bone != rightArm) continue;
            return motionSlot;
        }
        return null;
    }
}
