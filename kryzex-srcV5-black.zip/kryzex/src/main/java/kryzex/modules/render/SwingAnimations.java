package kryzex.modules.render;

import kryzex.misc.Rotation;
import kryzex.misc.Smooth;
import kryzex.misc.UnknownSwingStyle;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;
import kryzex.weapon.KnifeManager;
import net.minecraft.class_1306;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.joml.Quaternionfc;

public final class SwingAnimations
extends Module {
    public static CycleSetting<Smooth> style;
    private static Rotation pose;
    private static SwingAnimations instance;
    private static String[] a;

    public SwingAnimations() {
        super(SecureString.of("Swing Animations"), SecureString.of("Custom held-item swing styles"), -1, Category.RENDER);
        this.addSettings(new Setting[]{style});
        instance = this;
    }

    public static boolean j(class_4587 class_45872, class_1306 class_13062, float f) {
        if (instance == null || !instance.isEnabled()) {
            return false;
        }
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null || class_3102.field_1724 == null || class_3102.field_1724.method_6115() || class_13062 != class_3102.field_1724.method_6068() || KnifeManager.ownsMainHand(class_3102.field_1724.method_6047())) {
            return false;
        }
        UnknownSwingStyle.sample((Smooth)style.getValue(), f, class_13062 == class_1306.field_6183 ? 1 : -1, pose);
        class_45872.method_46416(SwingAnimations.pose.x, SwingAnimations.pose.y, SwingAnimations.pose.z);
        class_45872.method_22907((Quaternionfc)SwingAnimations.pose.rotation);
        return true;
    }

    static {
        String[] stringArray = a = new String[]{"Style", "Choose the first-person swing animation", "Swing Animations", "Custom held-item swing styles"};
        style = new CycleSetting<Smooth>(SecureString.of(stringArray[0]), Smooth.Smooth, Smooth.class).setDescription(SecureString.of(stringArray[1]));
        pose = new Rotation();
    }
}
