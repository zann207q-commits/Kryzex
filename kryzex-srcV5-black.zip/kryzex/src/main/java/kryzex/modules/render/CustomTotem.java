package kryzex.modules.render;

import kryzex.fx.TotemUndying;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.render.Spooky;
import kryzex.util.SecureString;

public final class CustomTotem
extends Module {
    public static CycleSetting<Spooky> design;
    public static BoolSetting animations;
    public static BoolSetting particles;
    public static NumberSetting glow;
    public static BoolSetting popEffects;
    private static CustomTotem instance;
    private static String[] a;

    public CustomTotem() {
        super(SecureString.of("Custom Totem"), SecureString.of(a[10]), -1, Category.RENDER);
        String[] stringArray = a;
        this.addSettings(new Setting[]{design, animations, particles, glow, popEffects});
        instance = this;
    }

    public static boolean C() {
        if (instance == null) return false;
        if (!instance.isEnabled()) return false;
        return true;
    }

    public static int b() {
        return design.getModeIndex();
    }

    public static boolean R() {
        if (!CustomTotem.C()) return false;
        if (CustomTotem.b() != 1) {
            if (CustomTotem.b() != 3) return false;
        }
        if (!animations.getValue()) return false;
        return true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        TotemUndying.moduleOff();
    }

    static {
        String[] stringArray = a = new String[]{"Design", "The design's own burst when a totem pops (replaces the green particles)", "Minecraft-style Spooky or Chrome Liquid, or the sculpted 3D versions", "Custom Totem", "Particles", "Animations", "Orbiting glow, embers, runes, smoke and glints around the totem", "Glow Strength", "Pop Effects", "How bright the glowing parts and their bloom are", "Halloween totem designs with animated glow shaders (Minecraft style or 3D)", "Floating, swaying cloth, flowing chrome and drips"};
        design = new CycleSetting<Spooky>(SecureString.of(stringArray[0]), Spooky.Spooky, Spooky.class).setDescription(SecureString.of(stringArray[2]));
        animations = new BoolSetting(SecureString.of(stringArray[5]), true).setDescription(SecureString.of(stringArray[11]));
        particles = new BoolSetting(SecureString.of(stringArray[4]), true).setDescription(SecureString.of(stringArray[6]));
        glow = new NumberSetting(SecureString.of(stringArray[7]), 0.0, 100.0, 75.0, 1.0).getValue(SecureString.of(stringArray[9]));
        popEffects = new BoolSetting(SecureString.of(stringArray[8]), true).setDescription(SecureString.of(stringArray[1]));
    }
}
