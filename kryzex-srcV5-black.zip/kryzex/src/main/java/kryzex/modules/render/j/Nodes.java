package kryzex.modules.render.j;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Nodes {
    private static final int GLTF = 1179937895;
    private static final int JSON = 1313821514;
    private static final int BIN = 5130562;
    private static final int MAX_ELEMENTS = 0x2000000;
    final JsonObject json;
    private final ByteBuffer bin;
    private static final String[] a = new String[]{"source", "uri", "byteOffset", "buffer", "pbrMetallicRoughness", "componentType", "unknown accessor type ", "bufferViews", "only glTF 2.0 files are supported", "alphaMode", "name", "sparse accessors aren't supported", "BLEND", "the file has no glTF data", "count", "textures", "images", "index", "OPAQUE", "byteLength", "VEC4", "materials", "bufferView", "extensionsRequired", "componentType", "sparse", "unknown component type ", "bufferView", "accessors", "data:", "MAT4", "VEC3", "byteStride", "material", "not a .glb file", "its textures are separate files, export it as a single .glb", "node", "bufferViews", "type", "its data is split over several files", "a mesh is far too large", "SCALAR", "name", "it needs ", "count", "texCoord", "the file is cut short", "doubleSided", "unknown index type ", "nodes", "index", "normalized", "pbrMetallicRoughness", "the file is cut short", "byteOffset", "MASK", "type", "nodes", "baseColorFactor", ", export it without compression", "baseColorTexture", "VEC2"};

    private Nodes(JsonObject jsonObject, ByteBuffer byteBuffer) {
        this.json = jsonObject;
        this.bin = byteBuffer;
    }

    static Nodes Q(byte[] byArray) throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.wrap(byArray).order(ByteOrder.LITTLE_ENDIAN);
        if (byArray.length < 20 || byteBuffer.getInt(0) != 1179937895) {
            String[] stringArray = a;
            throw new IOException("not a .glb file");
        }
        if (byteBuffer.getInt(4) != 2) {
            String[] stringArray = a;
            throw new IOException("only glTF 2.0 files are supported");
        }
        int n = Math.min(byteBuffer.getInt(8), byArray.length);
        int n2 = 12;
        JsonObject jsonObject = null;
        ByteBuffer byteBuffer2 = ByteBuffer.allocate(0);
        while (n2 + 8 <= n) {
            int n3 = byteBuffer.getInt(n2);
            int n4 = byteBuffer.getInt(n2 + 4);
            if (n3 < 0 || n3 > n - n2 - 8) {
                String[] stringArray = a;
                throw new IOException("the file is cut short");
            }
            if (n4 == 1313821514) {
                jsonObject = JsonParser.parseString(new String(byArray, n2 + 8, n3, StandardCharsets.UTF_8)).getAsJsonObject();
            } else if (n4 == 5130562) {
                byteBuffer2 = ByteBuffer.wrap(byArray, n2 + 8, n3).slice().order(ByteOrder.LITTLE_ENDIAN);
            }
            n2 += 8 + n3;
        }
        if (jsonObject == null) {
            String[] stringArray = a;
            throw new IOException("the file has no glTF data");
        }
        JsonArray jsonArray = Nodes.A(jsonObject, "extensionsRequired");
        if (jsonArray.isEmpty()) return new Nodes(jsonObject, byteBuffer2);
        throw new IOException("it needs " + String.valueOf(jsonArray) + ", export it without compression");
    }

    static JsonArray A(JsonObject jsonObject, String string) {
        JsonElement jsonElement = jsonObject.get(string);
        return jsonElement != null && jsonElement.isJsonArray() ? jsonElement.getAsJsonArray() : new JsonArray();
    }

    static JsonObject j(JsonObject jsonObject, String string) {
        JsonElement jsonElement = jsonObject.get(string);
        return jsonElement != null && jsonElement.isJsonObject() ? jsonElement.getAsJsonObject() : new JsonObject();
    }

    static int L(JsonObject jsonObject, String string, int n) {
        JsonElement jsonElement = jsonObject.get(string);
        return jsonElement != null && jsonElement.isJsonPrimitive() ? jsonElement.getAsInt() : n;
    }

    private static String Y(JsonObject jsonObject, String string, String string2) {
        JsonElement jsonElement = jsonObject.get(string);
        return jsonElement != null && jsonElement.isJsonPrimitive() ? jsonElement.getAsString() : string2;
    }

    int k() {
        return Nodes.A(this.json, "nodes").size();
    }

    JsonObject O(int n) {
        return Nodes.A(this.json, "nodes").get(n).getAsJsonObject();
    }

    String t(int n) {
        return Nodes.Y(this.O(n), "name", "node" + n);
    }

    private JsonObject M(int n) {
        return n < 0 ? new JsonObject() : Nodes.A(this.json, "materials").get(n).getAsJsonObject();
    }

    String X(int n) {
        return Nodes.Y(this.M(n), "name", "material" + n);
    }

    boolean E(int n) {
        String string = Nodes.Y(this.M(n), "alphaMode", "OPAQUE");
        if (string.equals("BLEND")) return true;
        if (!string.equals("MASK")) return false;
        return true;
    }

    boolean h(int n) {
        JsonElement jsonElement = this.M(n).get("doubleSided");
        if (jsonElement == null) return false;
        if (!jsonElement.getAsBoolean()) return false;
        return true;
    }

    private JsonObject s(int n) {
        return Nodes.j(Nodes.j(this.M(n), "pbrMetallicRoughness"), "baseColorTexture");
    }

    int g(int n) {
        return Nodes.L(this.s(n), "texCoord", 0);
    }

    float[] U(int n) {
        float[] fArray;
        JsonArray jsonArray = Nodes.A(Nodes.j(this.M(n), "pbrMetallicRoughness"), "baseColorFactor");
        if (jsonArray.size() != 4) {
            float[] fArray2 = new float[4];
            fArray2[0] = 1.0f;
            fArray2[1] = 1.0f;
            fArray2[2] = 1.0f;
            fArray = fArray2;
            fArray2[3] = 1.0f;
            return fArray;
        } else {
            float[] fArray3 = new float[4];
            fArray3[0] = jsonArray.get(0).getAsFloat();
            fArray3[1] = jsonArray.get(1).getAsFloat();
            fArray3[2] = jsonArray.get(2).getAsFloat();
            fArray = fArray3;
            fArray3[3] = jsonArray.get(3).getAsFloat();
        }
        return fArray;
    }

    byte[] d(int n) throws IOException {
        JsonObject jsonObject = this.s(n);
        String[] stringArray = a;
        if (!jsonObject.has("index")) {
            return null;
        }
        stringArray = a;
        JsonObject jsonObject2 = Nodes.A(this.json, "textures").get(jsonObject.get("index").getAsInt()).getAsJsonObject();
        int n2 = Nodes.L(jsonObject2, "source", -1);
        if (n2 < 0) {
            return null;
        }
        stringArray = a;
        JsonObject jsonObject3 = Nodes.A(this.json, "images").get(n2).getAsJsonObject();
        if (jsonObject3.has("bufferView")) {
            ByteBuffer byteBuffer = this.m(jsonObject3.get("bufferView").getAsInt(), 0);
            byte[] byArray = new byte[byteBuffer.remaining()];
            byteBuffer.get(byArray);
            return byArray;
        }
        String string = Nodes.Y(jsonObject3, "uri", "");
        if (!string.startsWith("data:")) throw new IOException("its textures are separate files, export it as a single .glb");
        return Base64.getDecoder().decode(string.substring(string.indexOf(44) + 1));
    }

    float[] I(int n) throws IOException {
        JsonObject jsonObject = this.n(n);
        String[] stringArray = a;
        int n2 = jsonObject.get("count").getAsInt();
        int n3 = Nodes.C(jsonObject.get("type").getAsString());
        int n4 = jsonObject.get("componentType").getAsInt();
        JsonElement jsonElement = jsonObject.get("normalized");
        boolean bl = jsonElement != null && jsonElement.getAsBoolean();
        float[] fArray = new float[n2 * n3];
        stringArray = a;
        if (!jsonObject.has("bufferView")) {
            return fArray;
        }
        ByteBuffer byteBuffer = this.m(jsonObject.get("bufferView").getAsInt(), Nodes.L(jsonObject, "byteOffset", 0));
        int n5 = this.b(jsonObject, n3, n4);
        int n6 = Nodes.K(n4);
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n3; ++j) {
                int n7 = i * n5 + j * n6;
                fArray[i * n3 + j] = switch (n4) {
                    case 5120 -> {
                        if (bl) {
                            yield Math.max((float)byteBuffer.get(n7) / 127.0f, -1.0f);
                        }
                        yield byteBuffer.get(n7);
                    }
                    case 5121 -> (float)(byteBuffer.get(n7) & 0xFF) / (bl ? 255.0f : 1.0f);
                    case 5122 -> {
                        if (bl) {
                            yield Math.max((float)byteBuffer.getShort(n7) / 32767.0f, -1.0f);
                        }
                        yield byteBuffer.getShort(n7);
                    }
                    case 5123 -> (float)(byteBuffer.getShort(n7) & 0xFFFF) / (bl ? 65535.0f : 1.0f);
                    default -> throw new IOException("unknown component type " + n4);
                    case 5125 -> byteBuffer.getInt(n7);
                    case 5126 -> byteBuffer.getFloat(n7);
                };
            }
        }
        return fArray;
    }

    int[] c(int n) throws IOException {
        JsonObject jsonObject = this.n(n);
        int n2 = jsonObject.get("count").getAsInt();
        int n3 = Nodes.C(jsonObject.get("type").getAsString());
        int n4 = jsonObject.get("componentType").getAsInt();
        ByteBuffer byteBuffer = this.m(jsonObject.get("bufferView").getAsInt(), Nodes.L(jsonObject, "byteOffset", 0));
        int n5 = this.b(jsonObject, n3, n4);
        int n6 = Nodes.K(n4);
        int[] nArray = new int[n2 * n3];
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n3; ++j) {
                int n7 = i * n5 + j * n6;
                nArray[i * n3 + j] = switch (n4) {
                    case 5121 -> byteBuffer.get(n7) & 0xFF;
                    default -> throw new IOException("unknown index type " + n4);
                    case 5123 -> byteBuffer.getShort(n7) & 0xFFFF;
                    case 5125 -> byteBuffer.getInt(n7);
                };
            }
        }
        return nArray;
    }

    private JsonObject n(int n) throws IOException {
        String[] stringArray = a;
        JsonObject jsonObject = Nodes.A(this.json, "accessors").get(n).getAsJsonObject();
        if (jsonObject.has("sparse")) {
            throw new IOException("sparse accessors aren't supported");
        }
        long l = (long)jsonObject.get("count").getAsInt() * (long)Nodes.C(jsonObject.get("type").getAsString());
        if (l < 0L || l > 0x2000000L) throw new IOException("a mesh is far too large");
        return jsonObject;
    }

    private ByteBuffer m(int n, int n2) throws IOException {
        String[] stringArray = a;
        JsonObject jsonObject = Nodes.A(this.json, "bufferViews").get(n).getAsJsonObject();
        if (Nodes.L(jsonObject, "buffer", 0) != 0) {
            throw new IOException("its data is split over several files");
        }
        int n3 = Nodes.L(jsonObject, "byteOffset", 0) + n2;
        int n4 = jsonObject.get("byteLength").getAsInt() - n2;
        if (n3 < 0 || n4 < 0 || n3 + n4 > this.bin.capacity()) throw new IOException("the file is cut short");
        return this.bin.slice(n3, n4).order(ByteOrder.LITTLE_ENDIAN);
    }

    private int b(JsonObject jsonObject, int n, int n2) {
        JsonObject jsonObject2 = Nodes.A(this.json, "bufferViews").get(jsonObject.get("bufferView").getAsInt()).getAsJsonObject();
        return Nodes.L(jsonObject2, "byteStride", n * Nodes.K(n2));
    }

    private static int K(int n) {
        switch (n) {
            case 5120:
            case 5121: {
                return 1;
            }
            case 5122:
            case 5123: {
                return 2;
            }
            default: {
                return 4;
            }
        }
    }

    private static int C(String string) throws IOException {
        String string2 = string;
        int n = -1;
        switch (string2.hashCode()) {
            case -1854860308: {
                String[] stringArray = a;
                if (!string2.equals("SCALAR")) break;
                n = 0;
                break;
            }
            case 2630462: {
                String[] stringArray = a;
                if (!string2.equals("VEC2")) break;
                n = 1;
                break;
            }
            case 2630463: {
                String[] stringArray = a;
                if (!string2.equals("VEC3")) break;
                n = 2;
                break;
            }
            case 2630464: {
                String[] stringArray = a;
                if (!string2.equals("VEC4")) break;
                n = 3;
                break;
            }
            case 2359028: {
                if (!string2.equals("MAT4")) break;
                n = 4;
            }
        }
        switch (n) {
            case 0: {
                return 1;
            }
            case 1: {
                return 2;
            }
            case 2: {
                return 3;
            }
            case 3: {
                return 4;
            }
            case 4: {
                return 16;
            }
            default: {
                throw new IOException("unknown accessor type " + string);
            }
        }
    }
}
