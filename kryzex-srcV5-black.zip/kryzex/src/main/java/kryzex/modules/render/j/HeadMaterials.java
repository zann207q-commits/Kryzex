package kryzex.modules.render.j;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class HeadMaterials {
    public float height = 30.0f;
    public float flat;
    public final Map<String, String> bones = new HashMap<String, String>();
    public final Set<String> headMaterials = new HashSet<String>();
    public float neck = -1.0f;
    public float hip = -1.0f;
    public float floor = -1.0f;
}
