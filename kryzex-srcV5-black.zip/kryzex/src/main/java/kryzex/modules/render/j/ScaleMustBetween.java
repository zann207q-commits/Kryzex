package kryzex.modules.render.j;

import java.util.ArrayList;
import java.util.List;
import kryzex.modules.render.j.OutlineColorSet;
import kryzex.modules.render.j.RightArm;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class ScaleMustBetween {
    float scale = 1.0f;
    int outlineColor = -14017512;
    float outline = 0.2f;
    float occlusion = 0.55f;
    float flat;
    boolean firstPersonArms = true;
    final OutlineColorSet[] bones = new OutlineColorSet[RightArm.values().length];
    final List<OutlineColorSet> extras = new ArrayList<OutlineColorSet>();
    private static final String[] a = new String[]{"duplicate extra name: ", "scale must be between 0.05 and 8", "extra needs a name", "extra name clashes with a bone: "};

    public ScaleMustBetween v(float f) {
        if (!(f > 0.05f) || !(f < 8.0f)) throw new IllegalArgumentException("scale must be between 0.05 and 8");
        this.scale = f;
        return this;
    }

    public ScaleMustBetween H(int n, float f) {
        this.outlineColor = n;
        this.outline = Math.max(0.0f, f);
        return this;
    }

    public ScaleMustBetween A(float f) {
        this.occlusion = Math.max(0.0f, Math.min(1.0f, f));
        return this;
    }

    public ScaleMustBetween N(float f) {
        this.flat = Math.max(0.0f, Math.min(1.0f, f));
        return this;
    }

    public ScaleMustBetween q(boolean bl) {
        this.firstPersonArms = bl;
        return this;
    }

    public OutlineColorSet T(RightArm rightArm) {
        OutlineColorSet outlineColorSet = this.bones[rightArm.ordinal()];
        if (outlineColorSet != null) return outlineColorSet;
        this.bones[rightArm.ordinal()] = outlineColorSet = new OutlineColorSet(rightArm.name(), rightArm, null, false);
        return outlineColorSet;
    }

    public OutlineColorSet d(String string, RightArm rightArm) {
        return this.D(string, this.T(rightArm));
    }

    public OutlineColorSet D(String string, OutlineColorSet outlineColorSet) {
        if (string == null || string.isEmpty()) throw new IllegalArgumentException("extra needs a name");
        for (OutlineColorSet outlineColorSet2 : this.extras) {
            if (!outlineColorSet2.name.equals(string)) continue;
            String[] stringArray = a;
            throw new IllegalArgumentException("duplicate extra name: " + string);
        }
        for (RightArm rightArm : RightArm.values()) {
            if (!rightArm.name().equals(string)) continue;
            throw new IllegalArgumentException("extra name clashes with a bone: " + string);
        }
        OutlineColorSet outlineColorSet3 = new OutlineColorSet(string, outlineColorSet.bone, outlineColorSet, true);
        this.extras.add(outlineColorSet3);
        return outlineColorSet3;
    }

    public float f() {
        return this.scale;
    }
}
