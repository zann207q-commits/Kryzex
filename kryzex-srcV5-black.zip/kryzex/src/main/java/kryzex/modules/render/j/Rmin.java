package kryzex.modules.render.j;

import kryzex.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Rmin
extends MinX {
    private final float cx;
    private final float cy;
    private final float ix;
    private final float iy;
    private final float iix;
    private final float iiy;
    private final float rmin;

    Rmin(float f, float f2, float f3, float f4) {
        this.cx = f;
        this.cy = f2;
        this.ix = 1.0f / f3;
        this.iy = 1.0f / f4;
        this.iix = this.ix * this.ix;
        this.iiy = this.iy * this.iy;
        this.rmin = Math.min(f3, f4);
        this.L(f - f3, f2 - f4, f + f3, f2 + f4);
    }

    @Override
    public float d(float f, float f2) {
        float f3 = f - this.cx;
        float f4 = f2 - this.cy;
        float f5 = f3 * this.ix;
        float f6 = f4 * this.iy;
        float f7 = (float)Math.sqrt(f5 * f5 + f6 * f6);
        float f8 = f3 * this.iix;
        float f9 = f4 * this.iiy;
        float f10 = (float)Math.sqrt(f8 * f8 + f9 * f9);
        return f10 < 1.0E-9f ? -this.rmin : f7 * (f7 - 1.0f) / f10;
    }
}
