package kryzex.modules.render;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import kryzex.modules.render.Block2;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2826;

final class Overridden {
    final long key;
    final class_2826[] sections;
    final int bottom;
    final int x;
    final int z;
    final List<Block2> found = new ArrayList<Block2>();
    int section;
    int cell;
    final Set<class_2338> overridden = new HashSet<class_2338>();

    Overridden(long l, class_2818 class_28182) {
        this.key = l;
        this.sections = class_28182.method_12006();
        this.bottom = class_28182.method_32891();
        this.x = class_28182.method_12004().method_8326();
        this.z = class_28182.method_12004().method_8328();
    }
}
