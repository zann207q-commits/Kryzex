package kryzex.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kryzex.event.BlockStateChangeEvent;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.render.Chest;
import kryzex.modules.render.y.Chunks;
import kryzex.modules.render.y.Selected;
import kryzex.util.Cache;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.OriginX;
import kryzex.util.StorageBloom;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;

public final class StorageESP
extends Module {
    private static String[] a;
    private static ExecutorService SCANNER;
    private static Chest[] STORAGE_TYPES;
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 53.0, 1.0);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false);
    private final BoolSetting glow = new BoolSetting("Glow", true);
    private final NumberSetting glowStrength = new NumberSetting("Glow Strength", 0.0, 100.0, 65.0, 1.0);
    private final NumberSetting glowSpread = new NumberSetting("Glow Spread", 6.0, 28.0, 18.0, 1.0);
    private final ListSetting storages = new ListSetting(SecureString.of("Storages")).add("chest", "Chest", class_1802.field_8106, true, new Color(156, 91, 0)).add("trapped_chest", "Trapped Chest", class_1802.field_8247, true, new Color(255, 205, 64)).add("ender_chest", "Ender Chest", class_1802.field_8466, true, new Color(127, 91, 255)).add("shulker", "Shulker Box", class_1802.field_8545, true, new Color(236, 85, 204)).add("spawner", "Spawner", class_1802.field_8849, true, new Color(255, 76, 98)).add("barrel", "Barrel", class_1802.field_16307, true, new Color(232, 151, 70)).add("trial_spawner", "Trial Spawner", class_1802.field_47314, true, new Color(95, 188, 255)).add("vault", "Vault", class_1802.field_48847, true, new Color(151, 224, 88)).add("PCDXWUS", "Furnace", class_1802.field_8732, true, new Color(102, 168, 255)).add("blast_furnace", "Blast Furnace", class_1802.field_16306, true, new Color(102, 168, 255)).add("smoker", "Smoker", class_1802.field_16309, true, new Color(102, 168, 255)).add("hopper", "Hopper", class_1802.field_8239, true, new Color(0, 0, 255)).add("R_EFSXESD", "Dispenser", class_1802.field_8357, true, new Color(95, 188, 255)).add("dropper", "Dropper", class_1802.field_8878, true, new Color(118, 134, 162)).add("chiseled_bookshelf", "Chiseled Bookshelf", class_1802.field_40215, true, new Color(189, 126, 255)).add("brewing_stand", "Brewing Stand", class_1802.field_8740, true, new Color(249, 115, 140)).add("crafter", "Crafter", class_1802.field_46791, true, new Color(255, 195, 72)).add("decorated_pot", "Decorated Pot", class_1802.field_42699, true, new Color(223, 119, 92));
    private final Cache glowMesh = new Cache();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private final List<Start> glowLines = new ArrayList<Start>();
    private final List<Start> glowMask = new ArrayList<Start>();
    private final Color[] renderColors = new Color[STORAGE_TYPES.length];
    private Selected detector;
    private class_638 scannedWorld;
    private Set<class_2248> selected = Set.of();

    public StorageESP() {
        super(SecureString.of("Storage ESP"), SecureString.of("Highlights selected storage block states in loaded chunks"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.alpha, this.glow, this.glowStrength, this.glowSpread, this.tracers, this.storages});
        SettingGroup.set(this.glowStrength, this.glow::getValue);
        SettingGroup.set(this.glowSpread, this.glow::getValue);
    }

    @Override
    public void onEnable() {
        this.P();
        if (this.mc.field_1687 != null) {
            this.N();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.P();
        super.onDisable();
    }

    private void P() {
        if (this.detector != null) {
            this.detector.Y();
        }
        this.detector = null;
        this.scannedWorld = null;
        this.selected = Set.of();
        StorageBloom.release();
        this.glowMesh.clear();
        this.renderBoxes.clear();
        this.renderLines.clear();
        this.glowLines.clear();
        this.glowMask.clear();
    }

    private Set<class_2248> f() {
        HashSet<class_2248> hashSet = new HashSet<class_2248>();
        for (Chest chest : STORAGE_TYPES) {
            ToggleEntry toggleEntry = this.storages.get(chest.id);
            if (toggleEntry == null || !toggleEntry.enabled()) continue;
            hashSet.add(chest.block);
        }
        return Set.copyOf(hashSet);
    }

    private void N() {
        if (this.detector != null) {
            this.detector.Y();
        }
        this.scannedWorld = this.mc.field_1687;
        this.selected = this.f();
        this.detector = new Selected(this.selected, SCANNER);
        if (this.scannedWorld == null) {
            return;
        }
        for (class_2818 class_28182 : Chunks.u(this.scannedWorld.method_2935())) {
            this.detector.G(class_28182);
        }
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 == null) {
            if (this.detector == null) return;
            this.P();
            return;
        }
        if (this.scannedWorld == this.mc.field_1687 && this.selected.equals(this.f())) return;
        this.N();
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        class_2818 class_28182;
        if (this.mc.field_1687 == null) {
            return;
        }
        if (this.scannedWorld != this.mc.field_1687 || this.detector == null) {
            this.N();
        }
        if ((class_28182 = this.mc.field_1687.method_2935().method_2857(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524(), class_2806.field_12803, false)) == null) return;
        this.detector.G(class_28182);
    }

    @Subscribe
    public void onBlockStateChange(BlockStateChangeEvent blockStateChangeEvent) {
        if (this.detector == null || this.scannedWorld != this.mc.field_1687) return;
        this.detector.M(blockStateChangeEvent.pos, blockStateChangeEvent.newState);
    }

    private static Chest q(class_2248 class_22482) {
        class_2248 class_22483 = Selected.S(class_22482);
        for (Chest chest : STORAGE_TYPES) {
            if (chest.block != class_22483) continue;
            return chest;
        }
        return null;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.detector == null || this.scannedWorld != this.mc.field_1687) {
            return;
        }
        class_4184 class_41842 = InverseProjectionScratch.getCamera();
        if (class_41842 == null || !class_41842.method_19332()) {
            return;
        }
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        try {
            InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
            this.renderBoxes.clear();
            this.renderLines.clear();
            this.glowLines.clear();
            this.glowMask.clear();
            boolean bl = this.tracers.getValue();
            boolean bl2 = this.glow.getValue() && this.glowStrength.getIntValue() > 0;
            int n = this.alpha.getIntValue();
            int n2 = this.glowStrength.getIntValue();
            class_243 class_2432 = bl ? InverseProjectionScratch.getTracerStart(class_41842) : null;
            Iterator<Map.Entry<Long, Set<class_2338>>> iterator = this.detector.X().entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Long, Set<class_2338>> entry = iterator.next();
                long l = entry.getKey();
                if (!this.mc.field_1687.method_2935().method_12123(class_1923.method_8325((long)l), class_1923.method_8332((long)l))) {
                    iterator.remove();
                    continue;
                }
                for (class_2338 class_23382 : entry.getValue()) {
                    double d;
                    double d2;
                    double d3;
                    double d4;
                    double d5;
                    double d6;
                    boolean bl3;
                    ToggleEntry toggleEntry;
                    Chest chest = StorageESP.q(this.mc.field_1687.method_8320(class_23382).method_26204());
                    if (chest == null || (toggleEntry = this.storages.get(chest.id)) == null || !toggleEntry.enabled() || !(bl3 = OriginX.box(d6 = (double)class_23382.method_10263(), d5 = (double)class_23382.method_10264(), d4 = (double)class_23382.method_10260(), d3 = d6 + 1.0, d2 = d5 + 1.0, d = d4 + 1.0)) && !bl) continue;
                    int n3 = n << 24 | toggleEntry.color().getRGB() & 0xFFFFFF;
                    Color color = this.renderColors[chest.ordinal()];
                    if (color == null || color.getRGB() != n3) {
                        this.renderColors[chest.ordinal()] = color = new Color(n3, true);
                    }
                    double d7 = d6 + 0.08;
                    double d8 = d5 + 0.08;
                    double d9 = d4 + 0.08;
                    double d10 = d3 - 0.08;
                    double d11 = d2 - 0.08;
                    double d12 = d - 0.08;
                    if (n > 0) {
                        this.renderBoxes.add(new kryzex.util.Color(d7, d8, d9, d10, d11, d12, color));
                    }
                    if (bl2 && bl3) {
                        this.glowMesh.append(this.glowMask, this.glowLines, d7, d8, d9, d10, d11, d12, color, n2);
                    }
                    if (!bl) continue;
                    this.renderLines.add(new Start(class_2432, class_23382.method_46558(), color, 1.5f));
                }
            }
            InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
            StorageBloom.render(class_45872, this.glowMask, n2, this.glowSpread.getIntValue());
            InverseProjectionScratch.renderLines(class_45872, this.glowLines);
            InverseProjectionScratch.renderLines(class_45872, this.renderLines);
            return;
        }
        finally {
            class_45872.method_22909();
        }
    }

    private static Thread lmbd$static$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "Kryzex-Storage-Scan");
        thread.setDaemon(true);
        return thread;
    }

    static {
        a = new String[]{"Brewing Stand", "Hopper", "dropper", "hopper", "Dropper", "Highlights selected storage block states in loaded chunks", "Tracers", "chest", "spawner", "decorated_pot", "Shulker Box", "Decorated Pot", "Crafter", "vault", "Trial Spawner", "Furnace", "blast_furnace", "Vault", "Barrel", "crafter", "shulker", "brewing_stand", "Blast Furnace", "Smoker", "Glow Spread", "Glow Strength", "Dispenser", "barrel", "Kryzex-Storage-Scan", "Glow", "Trapped Chest", "Chiseled Bookshelf", "Storages", "Spawner", "trial_spawner", "trapped_chest", "chiseled_bookshelf", "Ender Chest", "ender_chest", "Alpha", "smoker", "Storage ESP", "Chest", "PCDXWUS", "R_EFSXESD"};
        SCANNER = Executors.newFixedThreadPool(2, StorageESP::lmbd$static$0);
        STORAGE_TYPES = Chest.values();
    }
}
