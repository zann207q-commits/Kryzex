package kryzex.modules.render.j;

import kryzex.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Disc
extends MinX {
    private final float cx;
    private final float cy;
    private final float r;

    Disc(float f, float f2, float f3) {
        this.cx = f;
        this.cy = f2;
        this.r = f3;
        this.L(f - f3, f2 - f3, f + f3, f2 + f3);
    }

    @Override
    public float d(float f, float f2) {
        float f3 = f - this.cx;
        float f4 = f2 - this.cy;
        return (float)Math.sqrt(f3 * f3 + f4 * f4) - this.r;
    }
}
