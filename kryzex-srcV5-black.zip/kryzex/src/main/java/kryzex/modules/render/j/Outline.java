package kryzex.modules.render.j;

import kryzex.modules.render.j.MinX;
import kryzex.modules.render.j.Paints;
import kryzex.modules.render.j.Paint;
import kryzex.modules.render.j.Luna;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Outline {
    private static final float REF = 2.6f;
    private final float rad;
    private final float top;
    private final float tip;
    private final float width;
    private final float hook;
    private final float g0;
    private final float lift;
    private final float g1;
    private final float t0;
    private final float t1;
    private final float[] ys;
    private final float[] rs;
    private final float[] poly;
    private final MinX outline;

    Outline(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float[] fArray, float[] fArray2) {
        float f11;
        int n;
        this.rad = (float)Math.toRadians(f);
        this.top = f2;
        this.tip = f3;
        this.width = f4;
        this.hook = f5;
        this.g0 = f6;
        this.lift = f7;
        this.g1 = f8;
        this.t0 = f9;
        this.t1 = f10;
        this.ys = fArray;
        this.rs = fArray2;
        int n2 = 7;
        float f12 = f5 > 0.0f ? -1.0f : 1.0f;
        this.poly = new float[(2 * n2 + 3) * 2];
        int n3 = 0;
        this.poly[n3++] = f12 * f4;
        this.poly[n3++] = f2 + 0.5f;
        for (n = 0; n <= n2; ++n) {
            f11 = 1.0f - (float)Math.pow(1.0f - (float)n / (float)n2, 1.4f);
            this.poly[n3++] = f5 * f11 * f11 + f12 * f4 * (float)Math.pow(1.0f - f11, 0.8f);
            this.poly[n3++] = f2 + (f3 - f2) * f11;
        }
        for (n = n2 - 1; n >= 0; --n) {
            f11 = 1.0f - (float)Math.pow(1.0f - (float)n / (float)n2, 1.4f);
            this.poly[n3++] = f5 * f11 * f11 - f12 * f4 * (float)Math.pow(1.0f - f11, 1.25);
            this.poly[n3++] = f2 + (f3 - f2) * f11;
        }
        this.poly[n3++] = -f12 * f4;
        this.poly[n3] = f2 + 0.5f;
        this.outline = MinX.c(this.poly);
    }

    private float X(float f) {
        float f2 = 1.0f - f;
        return this.g0 * f2 * f2 + 2.0f * this.lift * f * f2 + this.g1 * f * f;
    }

    float D(float f, float f2, float f3) {
        float f4;
        float f5 = f3 - -0.3f;
        float f6 = (float)Math.sqrt(f * f + f5 * f5);
        float f7 = Luna.M((this.top - f2) / (this.top - this.tip));
        float f8 = Luna.R(this.ys, this.rs, f2) + this.X(f7);
        float f9 = Math.max(f8 - f6, f6 - f8 - (f4 = this.t0 + (this.t1 - this.t0) * f7));
        if (f9 > 0.8f) {
            return f9;
        }
        float f10 = 2.6f * ((float)Math.atan2(f, f5) - this.rad);
        float f11 = this.outline.d(f10, f2);
        if (f11 > 0.8f) {
            return f11;
        }
        float f12 = Math.min(1.0f, Math.abs(f10 - this.hook * f7 * f7) / (this.width * (1.0f - f7) + 0.05f));
        f9 = Math.max(f8 - f6, f6 - f8 - f4 * (1.0f - 0.35f * f12 * f12));
        float f13 = Luna.M(0.5f - 0.5f * (f9 - f11) / 0.07f);
        return f9 + (f11 - f9) * f13 + 0.07f * f13 * (1.0f - f13);
    }

    Paint t() {
        float f6;
        float f2 = Float.MAX_VALUE;
        float f3 = -3.4028235E38f;
        float f4 = Float.MAX_VALUE;
        float f5 = 0.0f;
        for (int i = 0; i < this.poly.length; i += 2) {
            f2 = Math.min(f2, this.poly[i]);
            f3 = Math.max(f3, this.poly[i]);
        }
        for (float f60 : this.rs) {
            f4 = Math.min(f4, f60);
            f5 = Math.max(f5, f60);
        }
        f4 = Math.max(0.2f, f4 + Math.min(this.g0, this.g1) - 0.15f);
        f5 += Math.max(this.g0, Math.max(this.lift, this.g1)) + this.t0 + 0.15f;
        float f7 = Float.MAX_VALUE;
        float f8 = -3.4028235E38f;
        float f9 = Float.MAX_VALUE;
        f6 = -3.4028235E38f;
        for (int i = 0; i <= 12; ++i) {
            double d = this.rad + (f2 + (f3 - f2) * (float)i / 12.0f) / 2.6f;
            for (float f10 : new float[]{f4, f5}) {
                f7 = Math.min(f7, f10 * (float)Math.sin(d));
                f8 = Math.max(f8, f10 * (float)Math.sin(d));
                f9 = Math.min(f9, -0.3f + f10 * (float)Math.cos(d));
                f6 = Math.max(f6, -0.3f + f10 * (float)Math.cos(d));
            }
        }
        return Paints.A(this::D, f7 - 0.1f, this.tip - 0.15f, f9 - 0.1f, f8 + 0.1f, this.top + 0.6f, f6 + 0.1f);
    }

    MinX k(float f) {
        float[] fArray = (float[])this.poly.clone();
        for (int i = 0; i < fArray.length; i += 2) {
            float f2 = fArray[i + 1];
            float f3 = Luna.R(this.ys, this.rs, f2) + this.X(Luna.M((this.top - f2) / (this.top - this.tip))) + this.t0 * 0.5f;
            fArray[i] = (f3 * (float)Math.sin(this.rad + fArray[i] / 2.6f) - -2.3142858f) * 41.48148f;
            fArray[i + 1] = (28.810715f - f2 + f) * 41.48148f;
        }
        return MinX.c(fArray);
    }
}
