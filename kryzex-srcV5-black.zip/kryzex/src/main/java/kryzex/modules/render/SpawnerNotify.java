package kryzex.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.mixin.GetSpawnEntryMixin;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.ChunkUtil;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2636;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_7923;

public final class SpawnerNotify
extends Module {
    private static String[] a;
    private final NumberSetting range = new NumberSetting(SecureString.of("Range"), 8.0, 512.0, 256.0, 8.0);
    private final BoolSetting pillar = new BoolSetting(SecureString.of("3x3 Pillar"), true);
    private final NumberSetting pillarAlpha = new NumberSetting(SecureString.of("Pillar Alpha"), 0.0, 255.0, 80.0, 1.0);
    private final BoolSetting spawnerBox = new BoolSetting(SecureString.of("Spawner Box"), true);
    private final NumberSetting boxAlpha = new NumberSetting(SecureString.of("Box Alpha"), 0.0, 255.0, 150.0, 1.0);
    private final BoolSetting chatAlerts = new BoolSetting(SecureString.of("Chat Alerts"), true);
    private final BoolSetting soundAlerts = new BoolSetting(SecureString.of("Sound Alerts"), true);
    private final Map<class_2338, String> trackedSpawners = new HashMap<class_2338, String>();
    private final Set<Long> alertedSpawners = new HashSet<Long>();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private class_638 trackedWorld;
    private int scanDelay;

    public SpawnerNotify() {
        super(SecureString.of("Spawner Notify"), SecureString.of("Highlights nearby spawners and alerts when one is found"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.range, this.pillar, this.pillarAlpha, this.spawnerBox, this.boxAlpha, this.chatAlerts, this.soundAlerts});
    }

    @Override
    public void onEnable() {
        this.X();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.X();
        super.onDisable();
    }

    private void X() {
        this.trackedSpawners.clear();
        this.alertedSpawners.clear();
        this.renderBoxes.clear();
        this.trackedWorld = null;
        this.scanDelay = 0;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
            if (this.trackedWorld != this.mc.field_1687) {
                this.trackedWorld = this.mc.field_1687;
                this.trackedSpawners.clear();
                this.alertedSpawners.clear();
                this.scanDelay = 0;
            }
            if (this.scanDelay++ > 0 && this.scanDelay < 40) return;
            this.scanDelay = 0;
            this.H();
            return;
        } else {
            this.X();
        }
    }

    private void H() {
        double d = this.range.getValue() * this.range.getValue();
        HashMap<class_2338, String> hashMap = new HashMap<class_2338, String>();
        HashSet<Long> hashSet = new HashSet<Long>();
        for (class_2818 class_28182 : ChunkUtil.getLoadedChunksList()) {
            for (class_2338 class_23382 : class_28182.method_12021()) {
                class_2586 class_25862 = this.mc.field_1687.method_8321(class_23382);
                if (!(class_25862 instanceof class_2636)) continue;
                class_2636 class_26362 = (class_2636)class_25862;
                if (class_25862.method_11015() || class_25862.method_10997() != this.mc.field_1687 || this.mc.field_1724.method_5707(class_243.method_24953((class_2382)class_23382)) > d) continue;
                class_2338 class_23383 = class_23382.method_10062();
                String string = this.V(class_26362);
                hashMap.put(class_23383, string);
                hashSet.add(class_23383.method_10063());
                if (!this.alertedSpawners.add(class_23383.method_10063())) continue;
                this.n(string, class_23383);
            }
        }
        this.alertedSpawners.removeIf(arg_0 -> SpawnerNotify.lmbd$scanLoadedSpawners$0(hashSet, arg_0));
        this.trackedSpawners.clear();
        this.trackedSpawners.putAll(hashMap);
    }

    private String V(class_2636 class_26362) {
        try {
            class_1299 class_12992;
            String string = ((GetSpawnEntryMixin)class_26362.method_11390()).getSpawnEntry().method_38093().method_10558("id").orElse("");
            class_2960 class_29602 = class_2960.method_12829((String)string);
            if (class_29602 != null && (class_12992 = (class_1299)class_7923.field_41177.method_63535(class_29602)) != null) {
                return class_12992.method_5897().getString();
            }
            if (string.isBlank()) return "Unknown";
            int n = string.indexOf(58);
            String string2 = n >= 0 ? string.substring(n + 1) : string;
            return Character.toUpperCase(string2.charAt(0)) + string2.substring(1).replace('_', ' ');
        }
        catch (RuntimeException runtimeException) {

        }
        return "Unknown";
    }

    private void n(String string, class_2338 class_23382) {
        if (this.soundAlerts.getValue()) {
            this.mc.field_1724.method_5783((class_3414)class_3417.field_14793.comp_349(), 1.0f, 0.8f);
        }
        if (!this.chatAlerts.getValue()) return;
        int n = class_23382.method_10260();
        int n2 = class_23382.method_10264();
        int n3 = class_23382.method_10263();
        String string2 = string;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7c[Spawner Notify] \u00a7f" + string2 + " Spawner at X: " + n3 + " Y: " + n2 + " Z: " + n)), false);
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.trackedSpawners.isEmpty() || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        this.renderBoxes.clear();
        double d = this.mc.field_1687.method_31607();
        double d2 = (double)this.mc.field_1687.method_31600() + 1.0;
        Color color = new Color(255, 0, 0, this.pillarAlpha.getIntValue());
        Color color2 = new Color(255, 0, 0, this.boxAlpha.getIntValue());
        for (class_2338 class_23382 : this.trackedSpawners.keySet()) {
            double d3 = class_23382.method_10263();
            double d4 = class_23382.method_10264();
            double d5 = class_23382.method_10260();
            if (this.pillar.getValue() && this.pillarAlpha.getIntValue() > 0 && OriginX.box(d3 - 1.0, d, d5 - 1.0, d3 + 2.0, d2, d5 + 2.0)) {
                this.renderBoxes.add(new kryzex.util.Color(d3 - 1.0, d, d5 - 1.0, d3 + 2.0, d2, d5 + 2.0, color));
            }
            if (!this.spawnerBox.getValue() || this.boxAlpha.getIntValue() <= 0 || !OriginX.box(d3, d4, d5, d3 + 1.0, d4 + 1.0, d5 + 1.0)) continue;
            this.renderBoxes.add(new kryzex.util.Color(d3, d4, d5, d3 + 1.0, d4 + 1.0, d5 + 1.0, color2));
        }
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        class_45872.method_22909();
    }

    private static boolean lmbd$scanLoadedSpawners$0(Set set, Long l) {
        if (set.contains(l)) return false;
        return true;
    }

    static {
        a = new String[]{"Sound Alerts", "Spawner Box", "Highlights nearby spawners and alerts when one is found", "Spawner Notify", " Spawner at X: ", "3x3 Pillar", "Pillar Alpha", "\u00a7c[Spawner Notify] \u00a7f", " Y: ", "Unknown", "Box Alpha", "id", "Range", " Z: ", "Chat Alerts"};
    }
}
