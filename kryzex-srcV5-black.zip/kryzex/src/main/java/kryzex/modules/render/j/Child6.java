package kryzex.modules.render.j;

import java.util.function.UnaryOperator;
import kryzex.modules.render.j.Paints;
import kryzex.modules.render.j.OcclusionWeight;
import kryzex.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child6
extends Paint {
    private final Paint child;
    private final boolean keep;

    Child6(Paint paint, boolean bl) {
        this.child = paint;
        this.keep = bl;
        if (!paint.M()) return;
        if (bl) {
            this.c(Math.min(paint.minX, -paint.maxX), paint.minY, paint.minZ, Math.max(paint.maxX, -paint.minX), paint.maxY, paint.maxZ);
            return;
        } else {
            this.c(-paint.maxX, paint.minY, paint.minZ, -paint.minX, paint.maxY, paint.maxZ);
        }
    }

    @Override
    Paint N(float f, float f2, float f3, float f4, float f5, float f6) {
        Paint paint = this.keep ? this.child.N(Math.min(f, -f4), f2, f3, Math.max(f4, -f), f5, f6) : this.child.N(-f4, f2, f3, -f, f5, f6);
        return paint == this.child ? this : new Child6(paint, this.keep);
    }

    @Override
    Paint h(UnaryOperator<Paint> unaryOperator) {
        Paint paint = this.child.h(unaryOperator);
        return (Paint)unaryOperator.apply(paint == this.child ? this : new Child6(paint, this.keep).t(this));
    }

    @Override
    public float Q(float f, float f2, float f3) {
        if (!this.keep) {
            return this.child.Q(-f, f2, f3);
        }
        float f4 = this.child.Q(f, f2, f3);
        return Paints.l(this.child, -f, f2, f3) >= f4 ? f4 : Math.min(f4, this.child.Q(-f, f2, f3));
    }

    @Override
    float R(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        if (!this.keep) {
            return this.child.I(-f, f2, f3, occlusionWeight);
        }
        float f4 = this.child.Q(f, f2, f3);
        float f5 = Paints.l(this.child, -f, f2, f3) >= f4 ? Float.MAX_VALUE : this.child.Q(-f, f2, f3);
        return f5 < f4 ? this.child.I(-f, f2, f3, occlusionWeight) : this.child.I(f, f2, f3, occlusionWeight);
    }
}
