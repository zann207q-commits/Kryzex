package kryzex.modules.render.j;

import kryzex.modules.render.j.FirstPersonArms;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class TurnRate {
    final FirstPersonArms model;
    final float[] spring;
    final float[] angles;
    float bodyRot;
    float turnRate;
    long nanos;

    TurnRate(FirstPersonArms firstPersonArms) {
        this.model = firstPersonArms;
        this.spring = new float[firstPersonArms.motionSlots * 6];
        this.angles = new float[firstPersonArms.motionSlots * 3];
        for (int i = 0; i < firstPersonArms.motionSlots; ++i) {
            this.spring[i * 6] = Float.NaN;
        }
    }
}
