package kryzex.modules.render;

public enum NotifyMode {
    CHAT,
    TOAST,
    BOTH;

}
