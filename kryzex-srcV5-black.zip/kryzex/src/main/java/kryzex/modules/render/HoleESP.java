package kryzex.modules.render;

import java.util.BitSet;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Predicate;
import kryzex.event.BlockStateChangeEvent;
import kryzex.event.ChunkDataEvent;
import kryzex.event.MacroRender3DEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.misc.MacroModule;
import kryzex.modules.render.Bottom;
import kryzex.modules.render.Generation;
import kryzex.modules.render.BlockAccess;
import kryzex.modules.render.BottomFinder;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2841;
import net.minecraft.class_638;

public final class HoleESP
extends MacroModule {
    private static String[] a;
    private final NumberSetting minDepth = new NumberSetting("Minimum Depth", 1.0, 20.0, 4.0, 1.0);
    private final NumberSetting alpha = new NumberSetting("Alpha", 1.0, 255.0, 120.0, 1.0);
    private final BoolSetting singleHoles = new BoolSetting("Single Holes", true);
    private final BoolSetting wideHoles = new BoolSetting("Wide Holes", true);
    private final Set<Long> waiting = new HashSet<Long>();
    private final Set<Long> scanned = new HashSet<Long>();
    private final Map<Long, List<Bottom>> results = new HashMap<Long, List<Bottom>>();
    private final ConcurrentLinkedQueue<Generation> completed = new ConcurrentLinkedQueue();
    private class_638 world;
    private ExecutorService executor;
    private long generation;
    private int ticks;
    private int lastDepth;
    private boolean lastSingle;
    private boolean lastWide;
    private boolean busy;
    private BlockAccess capture;

    public HoleESP() {
        super("hole-esp", "Hole ESP", "Highlights deep enclosed shafts in loaded chunks.", MacroCategories.RENDER);
        super.addSettings(new Setting[]{this.minDepth, this.singleHoles, this.wideHoles, this.alpha});
    }

    private void C() {
        ++this.generation;
        this.waiting.clear();
        this.scanned.clear();
        this.results.clear();
        this.completed.clear();
        this.capture = null;
        this.busy = false;
        this.ticks = 0;
    }

    @Override
    public void onEnable() {
        this.C();
        this.world = this.mc.field_1687;
        this.executor = Executors.newSingleThreadExecutor(HoleESP::lmbd$onEnable$0);
        this.X();
    }

    @Override
    public void onDisable() {
        this.C();
        this.world = null;
        if (this.executor != null) {
            this.executor.shutdownNow();
        }
        this.executor = null;
    }

    private void X() {
        this.lastDepth = this.minDepth.getIntValue();
        this.lastSingle = this.singleHoles.getValue();
        this.lastWide = this.wideHoles.getValue();
    }

    private class_2818 l(int n, int n2) {
        return this.world.method_2935().method_2857(n, n2, class_2806.field_12803, false);
    }

    private void O(int n, int n2) {
        if (this.world == null || this.l(n, n2) == null || this.scanned.contains(class_1923.method_8331((int)n, (int)n2)) || this.waiting.size() >= 4096) return;
        this.waiting.add(class_1923.method_8331((int)n, (int)n2));
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        class_638 class_6382 = this.mc.field_1687;
        int n = chunkDataEvent.packet.method_11523();
        int n2 = chunkDataEvent.packet.method_11524();
        this.mc.execute(() -> this.lmbd$onChunk$0(class_6382, n, n2));
    }

    @Subscribe
    public void onBlockStateChange(BlockStateChangeEvent blockStateChangeEvent) {
        if (this.mc.field_1687 == null) {
            return;
        }
        int n = blockStateChangeEvent.pos.method_10263() >> 4;
        int n2 = blockStateChangeEvent.pos.method_10260() >> 4;
        class_638 class_6382 = this.mc.field_1687;
        this.mc.execute(() -> this.lmbd$onBlock$0(class_6382, n, n2));
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        boolean bl;
        int n;
        int n2;
        Generation generation;
        if (this.world != this.mc.field_1687) {
            this.C();
            this.world = this.mc.field_1687;
        }
        if (this.world == null || this.mc.field_1724 == null || this.executor == null) {
            return;
        }
        if (this.lastDepth != this.minDepth.getIntValue() || this.lastSingle != this.singleHoles.getValue() || this.lastWide != this.wideHoles.getValue()) {
            this.C();
            this.X();
        }
        while ((generation = this.completed.poll()) != null) {
            if (generation.generation != this.generation) continue;
            this.busy = false;
            this.results.put(generation.chunk, generation.shafts);
        }
        int n3 = this.mc.field_1724.method_31477() >> 4;
        int n4 = this.mc.field_1724.method_31479() >> 4;
        int n5 = this.mc.field_1690.method_38521();
        if (this.ticks++ % 20 == 0) {
            Predicate<Long> predicate = arg_0 -> this.lmbd$onTick$0(n3, n5, n4, arg_0);
            this.results.keySet().removeIf(predicate);
            this.scanned.removeIf(predicate);
            this.waiting.removeIf(predicate);
            for (int i = 0; i <= n5; ++i) {
                for (n2 = -i; n2 <= i; ++n2) {
                    for (n = -i; n <= i; ++n) {
                        if (Math.max(Math.abs(n2), Math.abs(n)) != i) continue;
                        this.O(n3 + n2, n4 + n);
                    }
                }
            }
        }
        if (this.busy) {
            return;
        }
        if (this.capture == null && !this.waiting.isEmpty()) {
            long l = this.waiting.stream().min(Comparator.comparingLong(arg_0 -> HoleESP.lmbd$onTick$1(n3, n4, arg_0))).orElseThrow();
            this.waiting.remove(l);
            this.scanned.add(l);
            this.capture = new BlockAccess(l, this.world.method_31607(), this.world.method_31605());
        }
        if (this.capture == null) {
            return;
        }
        long l = System.nanoTime() + 1500000L;
        do {
            class_2818 class_28182;
            if ((class_28182 = this.l(n2 = class_1923.method_8325((long)this.capture.key) + this.capture.next % 3 - 1, n = class_1923.method_8332((long)this.capture.key) + this.capture.next / 3 - 1)) != null) {
                class_2826[] class_2826Array = class_28182.method_12006();
                class_2841[] class_2841Array = new class_2841[class_2826Array.length];
                for (int n6 = 0; n6 < class_2841Array.length; ++n6) {
                    if (class_2826Array[n6].method_38292()) continue;
                    class_2841Array[n6] = class_2826Array[n6].method_12265().method_39957();
                }
                this.capture.sections.put(class_1923.method_8331((int)n2, (int)n), class_2841Array);
            }
            ++this.capture.next;
        } while (this.capture.next < 9 && System.nanoTime() < l);
        if (this.capture.next < 9) {
            return;
        }
        BlockAccess xgu1TSlkNzGvbwYdUKz = this.capture;
        this.capture = null;
        long l2 = this.generation;
        int n6 = this.lastDepth;
        boolean bl2 = this.lastSingle;
        bl = this.lastWide;
        this.busy = true;
        this.executor.submit(() -> {
            List<Bottom> list = List.of();
            try {
                list = HoleESP.E(xgu1TSlkNzGvbwYdUKz, n6, bl2, bl);
            }
            catch (RuntimeException runtimeException) {
                System.err.println("Kryzex: Hole ESP scan failed: " + runtimeException.getClass().getSimpleName());
            }
            if (Thread.currentThread().isInterrupted()) return;
            this.completed.offer(new Generation(l2, xgu1TSlkNzGvbwYdUKz.key, list));
        });
    }

    private static List<Bottom> E(BlockAccess xgu1TSlkNzGvbwYdUKz, int n, boolean bl, boolean bl2) {
        int n2 = class_1923.method_8325((long)xgu1TSlkNzGvbwYdUKz.key) * 16;
        int n3 = class_1923.method_8332((long)xgu1TSlkNzGvbwYdUKz.key) * 16;
        BitSet bitSet = new BitSet(400 * xgu1TSlkNzGvbwYdUKz.height);
        class_2338.class_2339 class_23392 = new class_2338.class_2339();
        for (int i = 0; i < xgu1TSlkNzGvbwYdUKz.height; ++i) {
            if (Thread.currentThread().isInterrupted()) {
                return List.of();
            }
            for (int j = 0; j < 20; ++j) {
                for (int k = 0; k < 20; ++k) {
                    class_23392.method_10103(n2 + j - 1, xgu1TSlkNzGvbwYdUKz.bottom + i, n3 + k - 1);
                    class_2680 class_26802 = xgu1TSlkNzGvbwYdUKz.method_8320((class_2338)class_23392);
                    if (class_26802.method_26215() || class_26802.method_26220((class_1922)xgu1TSlkNzGvbwYdUKz, (class_2338)class_23392).method_1110()) continue;
                    bitSet.set((i * 20 + j) * 20 + k);
                }
            }
        }
        return BottomFinder.V(bitSet, xgu1TSlkNzGvbwYdUKz.height, xgu1TSlkNzGvbwYdUKz.bottom, n2, n3, n, bl, bl2);
    }

    @MacroSubscribe
    public void onMacroRender3D(MacroRender3DEvent macroRender3DEvent) {
        if (this.mc.field_1724 == null || this.world == null) {
            return;
        }
        int n = this.mc.field_1724.method_31477() >> 4;
        int n2 = this.mc.field_1724.method_31479() >> 4;
        int n3 = this.mc.field_1690.method_38521();
        int n4 = 0;
        for (Map.Entry<Long, List<Bottom>> entry : this.results.entrySet()) {
            if (Math.abs(class_1923.method_8325((long)entry.getKey()) - n) > n3 || Math.abs(class_1923.method_8332((long)entry.getKey()) - n2) > n3) continue;
            for (Bottom bottom : entry.getValue()) {
                boolean bl;
                boolean bl2 = bl = bottom.width() == 1 && bottom.length() == 1;
                if (bl ? !this.singleHoles.getValue() : !this.wideHoles.getValue()) continue;
                class_238 class_2382 = new class_238((double)bottom.x(), (double)bottom.bottom(), (double)bottom.z(), (double)(bottom.x() + bottom.width()), (double)bottom.top(), (double)(bottom.z() + bottom.length()));
                if (macroRender3DEvent.frustum != null && !macroRender3DEvent.frustum.method_23093(class_2382)) continue;
                class_12180.method_75541((class_238)class_2382, (class_12179)class_12179.method_75539((int)(this.alpha.getIntValue() << 24 | (bl ? 0xFF0000 : 16753920)))).method_75533();
                if (++n4 < 1024) continue;
                return;
            }
        }
    }

    private static long lmbd$onTick$1(int n, int n2, Long l) {
        long l2 = class_1923.method_8325((long)l) - n;
        long l3 = class_1923.method_8332((long)l) - n2;
        return l2 * l2 + l3 * l3;
    }

    private boolean lmbd$onTick$0(int n, int n2, int n3, Long l) {
        if (Math.abs(class_1923.method_8325((long)l) - n) > n2) return true;
        if (Math.abs(class_1923.method_8332((long)l) - n3) > n2) return true;
        if (this.l(class_1923.method_8325((long)l), class_1923.method_8332((long)l)) != null) return false;
        return true;
    }

    private void lmbd$onBlock$0(class_638 class_6382, int n, int n2) {
        if (!this.isEnabled() || this.world != class_6382) {
            return;
        }
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                long l = class_1923.method_8331((int)(n + i), (int)(n2 + j));
                this.scanned.remove(l);
                this.O(n + i, n2 + j);
            }
        }
    }

    private void lmbd$onChunk$0(class_638 class_6382, int n, int n2) {
        if (!this.isEnabled() || this.world != class_6382) return;
        this.O(n, n2);
    }

    private static Thread lmbd$onEnable$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "Kryzex-Hole-Scan");
        thread.setDaemon(true);
        return thread;
    }

    static {
        a = new String[]{"Wide Holes", "Alpha", "Hole ESP", "hole-esp", "Minimum Depth", "Highlights deep enclosed shafts in loaded chunks.", "Kryzex-Hole-Scan", "Single Holes"};
    }
}
