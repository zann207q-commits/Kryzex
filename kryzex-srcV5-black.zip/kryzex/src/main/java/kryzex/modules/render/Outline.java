package kryzex.modules.render;

public enum Outline {
    Box,
    Outline,
    Both;

}
