package kryzex.modules.misc;

import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.NumberSetting;
import kryzex.util.SecureString;

public final class SwingSpeed
extends Module {
    public static SwingSpeed INSTANCE;
    private final NumberSetting level = new NumberSetting(SecureString.of("Swing Speed"), 1.0, 10.0, 5.0, 1.0);
    private static int MFDaJ1ushKqLPmMAW7A4r9;
    private static String[] a;

    public SwingSpeed() {
        super(SecureString.of("Swing Speed"), SecureString.of("Adjusts how quickly the held item swing animation plays"), -1, Category.MISC);
        this.level.getValue(SecureString.of("1 = very fast, 10 = very slow"));
        this.addSettings(this.level);
        INSTANCE = this;
    }

    public int j() {
        return this.level.getIntValue();
    }

    public static float q(float f) {
        SwingSpeed adjustshowquicklythehelditemswinganimationplays = INSTANCE;
        if (adjustshowquicklythehelditemswinganimationplays == null || !adjustshowquicklythehelditemswinganimationplays.isEnabled()) {
            return f;
        }
        int n = Math.max(1, Math.min(10, adjustshowquicklythehelditemswinganimationplays.j()));
        float f2 = 0.25f + (float)(n - 1) * 0.30555555f;
        return (float)Math.pow(Math.min(1.0f, Math.max(0.0f, f)), f2);
    }

    public static int R(int n) {
        SwingSpeed adjustshowquicklythehelditemswinganimationplays = INSTANCE;
        if (adjustshowquicklythehelditemswinganimationplays == null || !adjustshowquicklythehelditemswinganimationplays.isEnabled()) {
            return n;
        }
        int n2 = Math.max(1, Math.min(10, adjustshowquicklythehelditemswinganimationplays.j()));
        float f = 0.25f + (float)(n2 - 1) * 0.30555555f;
        return Math.max(1, Math.round((float)n * f));
    }

    static {
        a = new String[]{"Adjusts how quickly the held item swing animation plays", "1 = very fast, 10 = very slow", "Swing Speed", "Swing Speed"};
    }
}
