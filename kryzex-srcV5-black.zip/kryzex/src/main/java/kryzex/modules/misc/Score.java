package kryzex.modules.misc;

class Score {
    public final int slot;
    public final double score;

    public Score(int slot, double score) {
        this.slot = slot;
        this.score = score;
    }

    public int slot() {
        return this.slot;
    }

    public double score() {
        return this.score;
    }
}
