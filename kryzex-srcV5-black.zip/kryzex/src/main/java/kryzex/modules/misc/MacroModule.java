package kryzex.modules.misc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import kryzex.event.MacroEventType;
import kryzex.module.MacroCategories;
import kryzex.module.MacroEventBus;
import kryzex.module.Module;
import kryzex.module.Phase;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.util.SecureString;

public class MacroModule
extends Module {
    private final String id;
    private final List<MacroSetting> extSettings = new ArrayList<MacroSetting>();
    private MacroBoolSetting notifications;

    protected MacroModule(String string, String string2, MacroCategories macroCategories) {
        this(string.toLowerCase(Locale.ROOT).replace(' ', '-'), string, string2, macroCategories);
    }

    protected MacroModule(String string, String string2, String string3, MacroCategories macroCategories) {
        super(SecureString.of(string2), SecureString.of(string3), -1, macroCategories.kryzex());
        this.id = string;
        MacroEventBus.track(this);
    }

    protected final <S extends MacroSetting> S addSetting(S s) {
        return this.addSetting(s.id(), s);
    }

    protected final <S extends MacroSetting> S addSetting(String string, S s) {
        s.bindId(string);
        this.extSettings.add(s);
        super.addSetting(s.kryzex());
        return s;
    }

    public final List<MacroSetting> extSettings() {
        return Collections.unmodifiableList(this.extSettings);
    }

    protected final MacroBoolSetting usesNotifications() {
        if (this.notifications != null) return this.notifications;
        this.notifications = this.addSetting("notifications", new MacroBoolSetting("Notifications", true));
        return this.notifications;
    }

    public final boolean notificationsOn() {
        if (this.notifications == null) return true;
        if (!this.notifications.get()) return false;
        return true;
    }

    public final boolean toggleMessageOn() {
        return false;
    }

    public final String id() {
        return this.id;
    }

    public final String name() {
        return this.getName().toString();
    }

    public final String description() {
        if (this.getDescription() == null) {
            return "";
        }
        String string = this.getDescription().toString();
        return string;
    }

    public boolean isAction() {
        return false;
    }

    public boolean inConfigs() {
        return true;
    }

    public boolean persistEnabled() {
        return true;
    }

    protected final void requestDisable() {
        MacroEventBus.later(this::lmbd$requestDisable$0);
    }

    protected final <E> void on(MacroEventType<E> macroEventType, Consumer<E> consumer) {
        MacroEventBus.subscribe(this, macroEventType.type(), Phase.PRE, consumer, this.isEnabled());
    }

    protected final <E> void on(MacroEventType<E> macroEventType, Phase sA2, Consumer<E> consumer) {
        MacroEventBus.subscribe(this, macroEventType.type(), sA2, consumer, this.isEnabled());
    }

    @Override
    public void toggle() {
        super.toggle();
        if (this.isEnabled()) return;
        MacroEventBus.dropOwned(this);
    }

    @Override
    public void toggle(boolean bl) {
        super.toggle(bl);
        if (this.isEnabled()) return;
        MacroEventBus.dropOwned(this);
    }

    private void lmbd$requestDisable$0() {
        this.toggle(false);
    }
}
