package kryzex.modules.misc;

import kryzex.client.KryzexClient;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.util.SecureString;

public class NameProtect
extends Module {
    private static String[] a;
    private final StringSetting fakeName = new StringSetting("Fake Name", "Player");

    public NameProtect() {
        super(SecureString.of("Name Protect"), SecureString.of("Replaces your name with given one."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.fakeName});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    public String S() {
        String string = this.fakeName.getValue();
        if (string == null) return "Player";
        if (string.isBlank()) {
            return "Player";
        }
        String string2 = string.trim();
        return string2;
    }

    public static String O(String string) {
        if (string == null || string.isEmpty()) {
            return "";
        }
        if (KryzexClient.INSTANCE != null && KryzexClient.INSTANCE.getModuleManager() != null) {
            NameProtect nameProtect;
            return (nameProtect = (NameProtect)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(NameProtect.class)) != null && nameProtect.isEnabled() ? nameProtect.S() : string;
        }
        return string;
    }

    static {
        a = new String[]{"Fake Name", "Player", "Player", "Replaces your name with given one.", "Name Protect"};
    }
}
