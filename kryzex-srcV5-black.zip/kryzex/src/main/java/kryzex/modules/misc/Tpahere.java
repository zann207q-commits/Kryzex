package kryzex.modules.misc;

enum Tpahere {
    TPA("Tpa", 0),
    TPAHERE("Tpahere", 1);

    private Tpahere(String string2, int n2) {
    }
}
