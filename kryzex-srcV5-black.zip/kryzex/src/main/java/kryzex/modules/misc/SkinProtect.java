package kryzex.modules.misc;

import com.mojang.authlib.GameProfile;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.util.SecureString;
import net.minecraft.class_1068;
import net.minecraft.class_640;
import net.minecraft.class_8685;

public final class SkinProtect
extends Module {
    private static String[] a;
    private static long LOOKUP_DEBOUNCE_NANOS;
    private static long RETRY_NANOS;
    private final StringSetting skinName = new StringSetting("Skin Name", "").setDescription(SecureString.of("Minecraft username to use for the skin and cape. Blank uses the default skin"));
    private final BoolSetting protectEverybody = new BoolSetting(SecureString.of("Protect Everybody"), false).setDescription(SecureString.of("Show the selected skin and cape on every player instead of only yourself"));
    private volatile class_8685 selectedTextures = class_1068.method_62620();
    private String requestedKey = "";
    private String requestedName = "";
    private CompletableFuture<Optional<class_8685>> pendingLookup;
    private long nextLookupNanos;
    private int lookupVersion;

    public SkinProtect() {
        super(SecureString.of("Skin Protect"), SecureString.of("Locally replaces player skins, capes and elytra textures"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.skinName, this.protectEverybody});
    }

    @Override
    public void onEnable() {
        this.o();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.o();
        super.onDisable();
    }

    private void o() {
        ++this.lookupVersion;
        this.pendingLookup = null;
        this.selectedTextures = class_1068.method_62620();
        this.requestedKey = "";
        this.requestedName = "";
        this.nextLookupNanos = 0L;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        long l = System.nanoTime();
        String string = this.skinName.getValue() == null ? "" : this.skinName.getValue().trim();
        String string2 = string.toLowerCase(Locale.ROOT);
        if (!string2.equals(this.requestedKey)) {
            this.requestedKey = string2;
            this.requestedName = string;
            ++this.lookupVersion;
            this.pendingLookup = null;
            this.selectedTextures = class_1068.method_62620();
            this.nextLookupNanos = l + LOOKUP_DEBOUNCE_NANOS;
        }
        if (this.pendingLookup != null || l < this.nextLookupNanos || !this.requestedName.matches("[A-Za-z0-9_]{3,16}")) {
            return;
        }
        this.W(this.requestedName);
    }

    private void W(String string) {
        class_640 class_6402;
        int n = this.lookupVersion;
        GameProfile gameProfile = null;
        if (this.mc.method_1562() != null && (class_6402 = this.mc.method_1562().method_2874(string)) != null) {
            gameProfile = class_6402.method_2966();
        }
        CompletableFuture<Optional<GameProfile>> completableFuture = gameProfile == null ? CompletableFuture.<Optional<GameProfile>>supplyAsync(() -> this.lmbd$resolveTextures$0(string)) : CompletableFuture.<Optional<GameProfile>>completedFuture(Optional.of(gameProfile));
        CompletableFuture<Optional<class_8685>> completableFuture2 = completableFuture.thenCompose(this::lmbd$resolveTextures$5).toCompletableFuture();
        this.pendingLookup = completableFuture2;
        completableFuture2.whenComplete((arg_0, arg_1) -> this.lmbd$resolveTextures$7(n, arg_0, arg_1));
    }

    public class_8685 R(UUID uUID, String string, class_8685 class_86852) {
        if (!this.isEnabled()) {
            return class_86852;
        }
        if (this.protectEverybody.getValue() || this.T(uUID, string)) return this.selectedTextures;
        return class_86852;
    }

    private boolean T(UUID uUID, String string) {
        UUID uUID2 = this.mc.method_1548().method_44717();
        if (uUID2 != null) {
            if (uUID2.equals(uUID)) return true;
        }
        if (string == null) return false;
        if (!string.equalsIgnoreCase(this.mc.method_1548().method_1676())) return false;
        return true;
    }

    private void lmbd$resolveTextures$7(int n, Optional<class_8685> optional, Throwable throwable) {
        this.mc.execute(() -> this.lmbd$resolveTextures$6(n, throwable, optional));
    }

    private void lmbd$resolveTextures$6(int n, Throwable throwable, Optional<class_8685> optional) {
        if (n != this.lookupVersion || !this.isEnabled()) {
            return;
        }
        this.pendingLookup = null;
        if (throwable == null && optional != null && optional.isPresent()) {
            this.selectedTextures = (class_8685)optional.get();
            this.nextLookupNanos = Long.MAX_VALUE;
            return;
        } else {
            this.selectedTextures = class_1068.method_62620();
            this.nextLookupNanos = System.nanoTime() + RETRY_NANOS;
        }
    }

    private CompletionStage<Optional<class_8685>> lmbd$resolveTextures$5(Optional<GameProfile> optional) {
        return optional.map(this::lmbd$resolveTextures$3).orElseGet(SkinProtect::lmbd$resolveTextures$4);
    }

    private static CompletableFuture<Optional<class_8685>> lmbd$resolveTextures$4() {
        return CompletableFuture.completedFuture(Optional.empty());
    }

    private CompletableFuture<Optional<class_8685>> lmbd$resolveTextures$3(GameProfile gameProfile) {
        return CompletableFuture.supplyAsync(() -> this.lmbd$resolveTextures$1(gameProfile)).thenCompose(SkinProtect::lmbd$resolveTextures$2);
    }

    private static CompletionStage<Optional<class_8685>> lmbd$resolveTextures$2(CompletableFuture<Optional<class_8685>> completableFuture) {
        return completableFuture;
    }

    private CompletableFuture<Optional<class_8685>> lmbd$resolveTextures$1(GameProfile gameProfile) {
        return this.mc.method_1582().method_52863(gameProfile);
    }

    private Optional<GameProfile> lmbd$resolveTextures$0(String string) {
        return this.mc.method_73361().comp_4624().method_73289(string);
    }

    static {
        a = new String[]{"Minecraft username to use for the skin and cape. Blank uses the default skin", "Skin Protect", "Protect Everybody", "Locally replaces player skins, capes and elytra textures", "Skin Name", "Show the selected skin and cape on every player instead of only yourself"};
        LOOKUP_DEBOUNCE_NANOS = TimeUnit.MILLISECONDS.toNanos(350L);
        RETRY_NANOS = TimeUnit.SECONDS.toNanos(30L);
    }
}
