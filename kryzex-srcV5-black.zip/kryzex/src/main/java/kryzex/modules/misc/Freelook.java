package kryzex.modules.misc;

import kryzex.client.KryzexClient;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.misc.Freecam;
import kryzex.util.SecureString;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

public final class Freelook
extends Module {
    private static String[] a;
    private static final double MOUSE_SCALE = 0.15;
    private final NumberSetting distance = new NumberSetting(SecureString.of("Distance"), 1.0, 15.0, 4.0, 0.1);
    private final NumberSetting sensitivity = new NumberSetting(SecureString.of("Sensitivity"), 0.1, 3.0, 1.0, 0.1);
    private final BoolSetting throughWalls = new BoolSetting(SecureString.of("Through Walls"), false);
    private final BoolSetting invertY = new BoolSetting(SecureString.of("Invert Y"), false);
    private class_5498 savedPerspective;
    private boolean savedChunkCulling;
    private float cameraYaw;
    private float cameraPitch;

    public Freelook() {
        super(SecureString.of("Freelook"), SecureString.of("Rotates the third-person camera without changing player rotation"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.distance, this.sensitivity, this.throughWalls, this.invertY});
    }

    @Override
    public void onEnable() {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
            Freecam freecam = (Freecam)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(Freecam.class);
            if (freecam != null && freecam.isEnabled()) {
                freecam.toggle(false);
            }
            this.savedPerspective = this.mc.field_1690.method_31044();
            this.savedChunkCulling = this.mc.field_1730;
            this.cameraYaw = this.mc.field_1724.method_36454();
            this.cameraPitch = this.mc.field_1724.method_36455();
            this.mc.field_1690.method_31043(class_5498.field_26665);
            this.mc.field_1730 = this.savedChunkCulling && !this.throughWalls.getValue();
            super.onEnable();
            return;
        } else {
            this.toggle(false);
        }
    }

    @Override
    public void onDisable() {
        if (this.savedPerspective != null) {
            this.mc.field_1690.method_31043(this.savedPerspective);
        }
        this.mc.field_1730 = this.savedChunkCulling;
        super.onDisable();
    }

    @Subscribe
    private void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
            if (this.mc.field_1690.method_31044() == class_5498.field_26665) return;
            this.mc.field_1690.method_31043(class_5498.field_26665);
            return;
        } else {
            this.toggle(false);
        }
    }

    public void R(double d, double d2) {
        double d3 = 0.15 * this.sensitivity.getValue();
        this.cameraYaw = class_3532.method_15393((float)(this.cameraYaw + (float)(d * d3)));
        double d4 = d2 * d3 * (this.invertY.getValue() ? -1.0 : 1.0);
        this.cameraPitch = class_3532.method_15363((float)(this.cameraPitch + (float)d4), -90.0f, 90.0f);
    }

    public float o() {
        return this.cameraYaw;
    }

    public float r() {
        return this.cameraPitch;
    }

    public float W() {
        return this.distance.getFloatValue();
    }

    public boolean X() {
        return this.throughWalls.getValue();
    }

    static {
        a = new String[]{"Distance", "Freelook", "Sensitivity", "Through Walls", "Rotates the third-person camera without changing player rotation", "Invert Y"};
    }
}
