package kryzex.modules.misc;

import kryzex.client.KryzexClient;
import kryzex.event.ItemUseReturnEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.misc.ElytraGlide;
import kryzex.util.SecureString;
import kryzex.util.Unknown2;
import kryzex.util.InventoryUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_9334;

public final class AutoFirework
extends Module {
    private static String[] a;
    private final KeybindSetting activateKey = new KeybindSetting(SecureString.of("Activate Key"), -1, false);
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 0.0, 20.0, 0.0, 1.0);
    private final BoolSetting switchBack = new BoolSetting(SecureString.of("Switch Back"), true);
    private final NumberSetting switchDelay = new NumberSetting(SecureString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0).getValue(SecureString.of("Delay after using firework before switching back."));
    private boolean isFireworkActive;
    private boolean hasUsedFirework;
    private int useDelayCounter;
    private int previousSelectedSlot;
    private int switchDelayCounter;
    private int cooldownCounter;
    private static final long qiHvBK5j2cgtkAue = -1486327636378718105L;

    public AutoFirework() {
        super(SecureString.of("Auto Firework"), SecureString.of("Switches to a firework and uses it when you press a bind."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.activateKey, this.delay, this.switchBack, this.switchDelay});
    }

    @Override
    public void onEnable() {
        this.F();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1755 != null) return;
        if (this.cooldownCounter > 0) {
            --this.cooldownCounter;
            return;
        } else {
            if (this.mc.field_1724 != null && Unknown2.isKeyPressed(this.activateKey.getValue()) && (KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(ElytraGlide.class).isEnabled() || this.mc.field_1724.method_6128()) && this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833) && !this.mc.field_1724.method_31548().method_7391().method_31574(class_1802.field_8639) && !this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) && !this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_54196)) {
                this.isFireworkActive = true;
            }
            if (!this.isFireworkActive) return;
            if (this.previousSelectedSlot == -1) {
                this.previousSelectedSlot = this.mc.field_1724.method_31548().method_67532();
            }
            if (!InventoryUtil.swap(class_1802.field_8639)) {
                this.F();
                return;
            }
            if (this.useDelayCounter < this.delay.getIntValue()) {
                ++this.useDelayCounter;
                return;
            }
            if (!this.hasUsedFirework) {
                this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
                this.hasUsedFirework = true;
            }
            if (this.switchBack.getValue()) {
                this.P();
                return;
            } else {
                this.F();
            }
        }
    }

    private void P() {
        if (this.switchDelayCounter < this.switchDelay.getIntValue()) {
            ++this.switchDelayCounter;
            return;
        } else {
            InventoryUtil.swap(this.previousSelectedSlot);
            this.F();
        }
    }

    private void F() {
        this.previousSelectedSlot = -1;
        this.useDelayCounter = 0;
        this.switchDelayCounter = 0;
        this.cooldownCounter = 4;
        this.isFireworkActive = false;
        this.hasUsedFirework = false;
    }

    @Subscribe
    public void onItemUseReturn(ItemUseReturnEvent itemUseReturnEvent) {
        if (this.mc.field_1724.method_6047().method_31574(class_1802.field_8639)) {
            this.hasUsedFirework = true;
        }
        if (this.cooldownCounter <= 0) return;
        itemUseReturnEvent.cancel();
    }

    static {
        a = new String[]{"Switch Back", "Switches to a firework and uses it when you press a bind.", "Delay", "Activate Key", "Switch Delay", "Delay after using firework before switching back.", "Auto Firework"};
    }
}
