package org.jcodec.common;
import org.jcodec.common.model.AudioBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;

public interface AudioDecoder {
    AudioBuffer decodeFrame(ByteBuffer frame, ByteBuffer dst) throws IOException;

    AudioCodecMeta getCodecMeta(ByteBuffer data) throws IOException;
}
