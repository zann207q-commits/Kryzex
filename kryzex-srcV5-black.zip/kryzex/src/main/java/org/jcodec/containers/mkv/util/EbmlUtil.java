package org.jcodec.containers.mkv.util;
import java.lang.StringBuilder;

public class EbmlUtil {

    public static byte[] ebmlEncodeLen(long value, int length) {
        byte[] b = new byte[length];
        for (int idx = 0; idx < length; idx++) {

            b[length - idx - 1] = (byte) ((value >>> (8 * idx)) & 0xFFL);
        }

        b[0] |= 0x80 >>> (length - 1);
        return b;
    }

    public static byte[] ebmlEncode(long value) {
        return ebmlEncodeLen(value, ebmlLength(value));
    }

    public static final byte[] lengthOptions = { 0, (byte) 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };

    static public int computeLength(byte b) {
        if (b == 0x00)
            throw new RuntimeException("Invalid head element for ebml sequence");

        int i = 1;
        while ((b & lengthOptions[i]) == 0)
            i++;

        return i;
    }

    public static final long one = 0x7F;

    public static final long two = 0x3F80;

    public static final long three = 0x1FC000;

    public static final long four = 0x0FE00000;

    public static final long five = 0x07F0000000L;

    public static final long six = 0x03F800000000L;

    public static final long seven = 0x01FC0000000000L;

    public static final long eight = 0xFE000000000000L;
    public static final long[] ebmlLengthMasks = new long[] { 0, one, two, three, four, five, six, seven, eight };

    public static int ebmlLength(long v) {
        if (v == 0)
            return 1;

        int length = 8;

        while (length > 0 && (v & ebmlLengthMasks[length]) == 0)
            length--;

        return length;
    }

    public static String toHexString(byte[] a) {
        StringBuilder sb = new StringBuilder();
        for (byte b : a)
            sb.append(String.format("0x%02x ", b & 0xff));
        return sb.toString();
    }

}
