package org.jcodec.containers.mp4.boxes;

import java.nio.ByteBuffer;

public class FielExtension extends Box {
    public FielExtension(Header header) {
        super(header);
    }

    private int type;
    private int order;

    public static String fourcc() {
        return "fiel";
    }

    public boolean isInterlaced() {
        return type == 2;
    }

    public boolean topFieldFirst() {
        return order == 1 || order == 6;
    }

    public String getOrderInterpretation() {
        if (isInterlaced())

            switch (order) {
            case 1:

                return "top";
            case 6:

                return "bottom";
            case 9:

                return "bottomtop";
            case 14:

                return "topbottom";
            }

        return "";
    }

    @Override
    public void parse(ByteBuffer input) {
        this.type = input.get() & 0xff;
        if (isInterlaced()) {
            this.order = input.get() & 0xff;
        }
    }

    @Override
    public void doWrite(ByteBuffer out) {
        out.put((byte) type);
        out.put((byte) order);
    }

    @Override
    public int estimateSize() {
        return 2 + 8;
    }
}
