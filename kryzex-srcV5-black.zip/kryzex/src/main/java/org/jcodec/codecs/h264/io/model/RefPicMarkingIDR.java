package org.jcodec.codecs.h264.io.model;

import org.jcodec.common.tools.ToJSON;
import org.jcodec.platform.Platform;

public class RefPicMarkingIDR {
    boolean discardDecodedPics;
    boolean useForlongTerm;

    public RefPicMarkingIDR(boolean discardDecodedPics, boolean useForlongTerm) {
        this.discardDecodedPics = discardDecodedPics;
        this.useForlongTerm = useForlongTerm;
    }

    public boolean isDiscardDecodedPics() {
        return discardDecodedPics;
    }

    public boolean isUseForlongTerm() {
        return useForlongTerm;
    }

    @Override
    public String toString() {
        return Platform.toJSON(this);
    }
}
