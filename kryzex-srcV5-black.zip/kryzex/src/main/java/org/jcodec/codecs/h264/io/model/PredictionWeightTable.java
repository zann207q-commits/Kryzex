package org.jcodec.codecs.h264.io.model;

public class PredictionWeightTable {

    public int lumaLog2WeightDenom;

    public int chromaLog2WeightDenom;

    public int[][] lumaWeight;

    public int[][][] chromaWeight;

    public int[][] lumaOffset;

    public int[][][] chromaOffset;

    public PredictionWeightTable() {
        this.lumaWeight = new int[2][];
        this.chromaWeight = new int[2][][];

        this.lumaOffset = new int[2][];
        this.chromaOffset = new int[2][][];
    }
}
