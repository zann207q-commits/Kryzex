package org.jcodec.codecs.mpeg12;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.List;

import org.jcodec.codecs.mpeg12.bitstream.PictureHeader;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.model.Packet.FrameType;
import org.jcodec.containers.mps.MPEGPacket;

public class MPEGES extends SegmentReader {

    private int frameNo;
    public long lastKnownDuration;

    public MPEGES(ReadableByteChannel channel, int fetchSize) throws IOException {
        super(channel, fetchSize);
    }

    public MPEGPacket frame(ByteBuffer buffer) throws IOException {

        ByteBuffer dup = buffer.duplicate();

        while (curMarker != 0x100 && curMarker != 0x1b3 && skipToMarker())
            ;

        while (curMarker != 0x100 && readToNextMarker(dup))
            ;

        readToNextMarker(dup);

        while (curMarker != 0x100 && curMarker != 0x1b3 && readToNextMarker(dup))
            ;

        dup.flip();

        PictureHeader ph = MPEGDecoder.getPictureHeader(dup.duplicate());

        return dup.hasRemaining() ? new MPEGPacket(dup, 0, 90000, 0, frameNo++,
                ph.picture_coding_type <= MPEGConst.IntraCoded ? FrameType.KEY : FrameType.INTER, null) : null;
    }

    public MPEGPacket getFrame() throws IOException {

        while (curMarker != 0x100 && curMarker != 0x1b3 && skipToMarker())
            ;

        List<ByteBuffer> buffers = new ArrayList<ByteBuffer>();

        while (curMarker != 0x100 && !done)
            readToNextMarkerBuffers(buffers);

        readToNextMarkerBuffers(buffers);

        while (curMarker != 0x100 && curMarker != 0x1b3 && !done)
            readToNextMarkerBuffers(buffers);

        ByteBuffer dup = NIOUtils.combineBuffers(buffers);
        PictureHeader ph = MPEGDecoder.getPictureHeader(dup.duplicate());

        return dup.hasRemaining() ? new MPEGPacket(dup, 0, 90000, 0, frameNo++,
                ph.picture_coding_type <= MPEGConst.IntraCoded ? FrameType.KEY : FrameType.INTER, null) : null;
    }
}