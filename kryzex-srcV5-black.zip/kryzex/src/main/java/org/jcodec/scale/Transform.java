package org.jcodec.scale;

import org.jcodec.common.model.Picture;

public interface Transform {
    public static enum Levels {
        STUDIO, PC
    };
    public void transform(Picture src, Picture dst);
}