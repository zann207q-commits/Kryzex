package kryzex.gui;

final class Data {
    final float[] data;
    final float gain;
    int pos;

    Data(float[] fArray, float f) {
        this.data = fArray;
        this.gain = f;
    }

    boolean mixInto(float[] fArray) {
        int n = Math.min(fArray.length, this.data.length - this.pos);
        for (int i = 0; i < n; ++i) {
            int n2 = i;
            fArray[n2] = fArray[n2] + this.data[this.pos + i] * this.gain;
        }
        this.pos += n;
        if (this.pos < this.data.length) return false;
        return true;
    }
}
