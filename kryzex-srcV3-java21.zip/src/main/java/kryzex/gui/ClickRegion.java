package kryzex.gui;

import kryzex.gui.PaletteEntry;

class ClickRegion {
    public final float x;
    public final float y;
    public final float w;
    public final float h;
    public final PaletteEntry row;
    public final Runnable action;

    public ClickRegion(float x, float y, float w, float h, PaletteEntry row, Runnable action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.row = row;
        this.action = action;
    }

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float w() {
        return this.w;
    }

    public float h() {
        return this.h;
    }

    public PaletteEntry row() {
        return this.row;
    }

    public Runnable action() {
        return this.action;
    }
}
