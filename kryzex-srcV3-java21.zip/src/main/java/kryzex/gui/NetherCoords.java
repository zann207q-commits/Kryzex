package kryzex.gui;

public final class NetherCoords {
    public boolean watermark = true;
    public boolean time = true;
    public boolean info = true;
    public boolean player;
    public boolean coords = true;
    public boolean direction = true;
    public boolean netherCoords;
    public boolean modules = true;
    public float scale = 1.0f;
    public float opacity = 0.62f;
    public boolean rainbow;
    public float rainbowSpeed = 1.0f;
}
