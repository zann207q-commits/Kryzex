package kryzex.gui;

final class TextSize {
    final float unit;
    final float logoX;
    final float logoY;
    final float logoW;
    final float logoH;
    final float barX;
    final float barY;
    final float barW;
    final float barH;
    final float textY;
    final float textSize;

    TextSize(int n, int n2, float f) {
        this.unit = Math.max(0.35f, Math.min((float)n / 1920.0f, (float)n2 / 1080.0f));
        float f2 = (float)n / 2.0f;
        float f3 = (float)n2 * 0.45f;
        float f4 = Math.min((float)n * 0.62f, 660.0f * this.unit);
        this.logoW = f4 * f;
        this.logoH = this.logoW / 6.0f;
        this.logoX = f2 - this.logoW / 2.0f;
        this.logoY = f3 - this.logoH / 2.0f;
        float f5 = f3 + 0.195f * f4 / 6.0f;
        this.barW = Math.min((float)n * 0.6f, 400.0f * this.unit) * (1.0f + (f - 1.0f) * 0.5f);
        this.barH = Math.max(3.0f, 5.0f * this.unit);
        this.barX = f2 - this.barW / 2.0f;
        this.barY = f5 + 44.0f * this.unit;
        this.textSize = Math.max(9.0f, 17.0f * this.unit);
        this.textY = this.barY + this.barH + 15.0f * this.unit;
    }
}
