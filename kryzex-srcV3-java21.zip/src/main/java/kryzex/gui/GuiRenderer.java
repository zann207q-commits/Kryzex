package kryzex.gui;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Handle;
import kryzex.gui.Pipeline;
import kryzex.gui.RenderPipeline;
import kryzex.gui.RoundedRect;
import kryzex.gui.KryzexTexture;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_11246;
import net.minecraft.class_12137;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7532;
import net.minecraft.class_8030;
import net.minecraft.class_8685;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;

public final class GuiRenderer
extends BaseRenderer {
    private static final Map<class_1792, class_1799> STACKS = new HashMap<class_1792, class_1799>();
    private static Supplier<class_8685> profileSkin;
    private final class_332 ctx;
    private final float guiScale;
    private int pushed;
    private static Field STATE;
    private static Field SCISSORS;
    private static Method PEEK;
    private final class_11246 state;
    private final Deque<class_8030> clips = new ArrayDeque<class_8030>();
    private final class_8030 inheritedClip;
    private Pipeline batch;
    private Handle batchTexture;
    private class_8030 clip;

    private static Field stateField() {
        for (Field field : class_332.class.getDeclaredFields()) {
            if (field.getType() != class_11246.class) continue;
            field.setAccessible(true);
            return field;
        }
        throw new IllegalStateException("Missing GUI render state");
    }

    private static Field scissorField() {
        for (Field field : class_332.class.getDeclaredFields()) {
            if (field.getType().getEnclosingClass() != class_332.class) continue;
            for (Method method : field.getType().getDeclaredMethods()) {
                if (method.getParameterCount() != 0 || method.getReturnType() != class_8030.class) continue;
                field.setAccessible(true);
                return field;
            }
        }
        throw new IllegalStateException("Missing GUI clipping state");
    }

    private static Method scissorPeek() {
        for (Method method : SCISSORS.getType().getDeclaredMethods()) {
            if (method.getParameterCount() != 0 || method.getReturnType() != class_8030.class || !method.getName().equals("peekLast") && !method.getName().equals("method_70863")) continue;
            method.setAccessible(true);
            return method;
        }
        throw new IllegalStateException("Missing GUI clip accessor");
    }

    public GuiRenderer(class_332 class_3322, float f) {
        this.ctx = class_3322;
        this.guiScale = f <= 0.0f ? 1.0f : f;
        try {
            this.state = (class_11246)STATE.get(class_3322);
            this.clip = this.inheritedClip = (class_8030)PEEK.invoke(SCISSORS.get(class_3322), new Object[0]);
            return;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Cannot access GUI drawing state", reflectiveOperationException);
        }
    }

    @Override
    protected void fillRaw(int n, int n2, int n3, int n4, int n5) {
        if (n3 <= n || n4 <= n2) return;
        this.quad(null, n, n2, n3, n4, 0.0f, 0.0f, 0.0f, 0.0f, n5, n5);
    }

    @Override
    protected void gradientRaw(int n, int n2, int n3, int n4, int n5, int n6) {
        if (n3 <= n || n4 <= n2) return;
        this.quad(null, n, n2, n3, n4, 0.0f, 0.0f, 0.0f, 0.0f, n5, n6);
    }

    @Override
    protected void blitRaw(Handle handle, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9) {
        class_2960 class_29602;
        if (n3 <= 0 || n4 <= 0 || (class_29602 = GuiRenderer.upload(handle)) == null) return;
        this.quad(handle, n, n2, n + n3, n2 + n4, (float)n5 / (float)handle.w, (float)n6 / (float)handle.h, (float)(n5 + n7) / (float)handle.w, (float)(n6 + n8) / (float)handle.h, n9, n9);
    }

    private void quad(Handle handle, int n, int n2, int n3, int n4, float f, float f2, float f3, float f4, int n5, int n6) {
        Matrix3x2fStack matrix3x2fStack = this.ctx.method_51448();
        if (this.batch == null || this.batchTexture != handle) {
            class_11231 class_112312 = class_11231.method_70899();
            if (handle != null) {
                class_2960 object = (class_2960)handle.handle;
                class_1044 class_10442 = class_310.method_1551().method_1531().method_4619(object);
                class_112312 = class_11231.method_70900((GpuTextureView)class_10442.method_71659(), (class_12137)class_10442.method_75484());
            }
            Pipeline object = new Pipeline(handle == null ? class_10799.field_56879 : class_10799.field_56883, class_112312, this.clip);
            if (!object.append((Matrix3x2fc)matrix3x2fStack, n, n2, n3, n4, f, f2, f3, f4, n5, n6)) {
                return;
            }
            this.state.method_71059();
            this.state.method_70919((class_11244)object);
            this.batch = object;
            this.batchTexture = handle;
            return;
        } else {
            this.batch.append((Matrix3x2fc)matrix3x2fStack, n, n2, n3, n4, f, f2, f3, f4, n5, n6);
        }
    }

    public boolean shaderRound(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2) {
        if (f3 <= 0.0f || f4 <= 0.0f) {
            return true;
        }
        if (!RenderPipeline.ready()) {
            return false;
        }
        this.barrier();
        RoundedRect roundedRect = new RoundedRect((Matrix3x2fc)this.ctx.method_51448(), this.clip, f, f2, f3, f4, f5, f6, n, n2);
        class_8030 class_80302 = roundedRect.comp_4274();
        if (class_80302 == null || class_80302.method_49621() <= class_80302.method_49620() || class_80302.method_49619() <= class_80302.method_49618()) return true;
        this.state.method_71059();
        this.state.method_70919((class_11244)roundedRect);
        return true;
    }

    private void barrier() {
        this.batch = null;
        this.batchTexture = null;
    }

    @Override
    public void pushTransform(float f, float f2, float f3) {
        Matrix3x2fStack matrix3x2fStack = this.ctx.method_51448();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        matrix3x2fStack.scale(f3, f3);
        ++this.pushed;
    }

    @Override
    public void popTransform() {
        if (this.pushed <= 0) return;
        --this.pushed;
        this.ctx.method_51448().popMatrix();
    }

    @Override
    public float scale() {
        Matrix3x2fStack matrix3x2fStack = this.ctx.method_51448();
        float f = (float)Math.sqrt(matrix3x2fStack.m00() * matrix3x2fStack.m00() + matrix3x2fStack.m01() * matrix3x2fStack.m01());
        return f * this.guiScale;
    }

    @Override
    public void pushClip(float f, float f2, float f3, float f4) {
        class_8030 class_80302;
        this.ctx.method_44379(Math.round(f), Math.round(f2), Math.round(f + f3), Math.round(f2 + f4));
        class_8030 class_80303 = new class_8030(Math.round(f), Math.round(f2), Math.round(f + f3) - Math.round(f), Math.round(f2 + f4) - Math.round(f2)).method_65185((Matrix3x2fc)this.ctx.method_51448());
        class_8030 class_80304 = class_80302 = this.clips.isEmpty() ? this.inheritedClip : this.clips.peek();
        if (class_80302 != null) {
            class_80303 = class_80302.method_49701(class_80303);
        }
        if (class_80303 == null) {
            class_80303 = class_8030.method_48248();
        }
        this.clips.push(class_80303);
        this.clip = class_80303;
        this.barrier();
    }

    @Override
    public void popClip() {
        this.ctx.method_44380();
        if (!this.clips.isEmpty()) {
            this.clips.pop();
        }
        this.clip = this.clips.isEmpty() ? this.inheritedClip : this.clips.peek();
        this.barrier();
    }

    @Override
    public void head(float f, float f2, float f3) {
        this.barrier();
        this.state.method_71059();
        try {
            class_8685 class_86852;
            class_310 class_3102 = class_310.method_1551();
            if (class_3102.field_1724 != null) {
                class_86852 = class_3102.field_1724.method_52814();
            } else {
                if (profileSkin == null) {
                    profileSkin = class_3102.method_1582().method_73544(class_3102.method_53462(), false);
                }
                class_86852 = profileSkin.get();
            }
            if (class_86852 == null) return;
            this.ctx.method_51448().pushMatrix();
            this.ctx.method_51448().translate((float)Math.round(f), (float)Math.round(f2));
            class_7532.method_52722((class_332)this.ctx, (class_8685)class_86852, 0, 0, (int)Math.round(f3));
            this.ctx.method_51448().popMatrix();
            return;
        }
        catch (Throwable throwable) {

        }
    }

    @Override
    public void item(Object object, float f, float f2, float f3) {
        this.barrier();
        this.state.method_71059();
        if (!(object instanceof class_1792)) return;
        class_1792 class_17922 = (class_1792)object;
        class_1799 class_17992 = STACKS.computeIfAbsent(class_17922, class_1799::new);
        Matrix3x2fStack matrix3x2fStack = this.ctx.method_51448();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        matrix3x2fStack.scale(f3 / 16.0f, f3 / 16.0f);
        this.ctx.method_51427(class_17992, 0, 0);
        matrix3x2fStack.popMatrix();
    }

    static class_2960 upload(Handle handle) {
        Object object = handle.handle;
        if (object instanceof class_2960) {
            return (class_2960)object;
        }
        if (handle.handle != null) {
            return null;
        }
        try {
            class_1011 nativeImage = new class_1011(handle.w, handle.h, false);
            for (int i = 0; i < handle.h; ++i) {
                for (int j = 0; j < handle.w; ++j) {
                    nativeImage.method_61941(j, i, handle.argb[i * handle.w + j]);
                }
            }
            String string = "kui/" + handle.key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_");
            class_2960 class_29602 = class_2960.method_60655((String)"r87f4560b4c09f4", (String)string);
            class_310.method_1551().method_1531().method_4616(class_29602, (class_1044)new KryzexTexture(handle.key, nativeImage));
            handle.handle = class_29602;
            return class_29602;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: texture upload failed for " + handle.key + ": " + String.valueOf(throwable));
            handle.handle = Boolean.FALSE;
            return null;
        }
    }

    static {
        STATE = GuiRenderer.stateField();
        SCISSORS = GuiRenderer.scissorField();
        PEEK = GuiRenderer.scissorPeek();
    }
}
