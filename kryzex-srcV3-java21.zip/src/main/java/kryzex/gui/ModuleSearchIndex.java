package kryzex.gui;

import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import kryzex.module.Category;
import kryzex.module.Module;

final class ModuleSearchIndex {
    Module[] modules = new Module[0];
    Object[] nameSources = new Object[0];
    Object[] descriptionSources = new Object[0];
    Category[] categorySources = new Category[0];
    String[] names = new String[0];
    String[] displayNames = new String[0];
    String[] descriptions = new String[0];
    boolean[] enabled = new boolean[0];
    final EnumMap<Category, List<Module>> categories = new EnumMap(Category.class);
    String query;
    List<Module> results = List.of();
    List<String> activeNames = List.of();

    public ModuleSearchIndex() {
    }

    boolean update(List<Module> list) {
        int n;
        boolean bl;
        boolean bl2 = bl = list.size() != this.modules.length;
        if (!bl) {
            for (n = 0; n < list.size(); ++n) {
                Module module = list.get(n);
                if (module == this.modules[n] && module.getName() == this.nameSources[n] && module.getDescription() == this.descriptionSources[n] && module.getCategory() == this.categorySources[n]) continue;
                bl = true;
                break;
            }
        }
        if (!bl) {
            return false;
        }
        n = list.size();
        this.modules = (Module[])list.toArray(ModuleSearchIndex::lmbd$update$0);
        this.nameSources = new Object[n];
        this.descriptionSources = new Object[n];
        this.categorySources = new Category[n];
        this.names = new String[n];
        this.displayNames = new String[n];
        this.descriptions = new String[n];
        this.enabled = new boolean[n];
        for (int i = 0; i < n; ++i) {
            Module module = this.modules[i];
            this.nameSources[i] = module.getName();
            this.descriptionSources[i] = module.getDescription();
            this.categorySources[i] = module.getCategory();
            this.displayNames[i] = this.nameSources[i].toString();
            this.names[i] = this.displayNames[i].toLowerCase(Locale.ROOT);
            this.descriptions[i] = this.descriptionSources[i] == null ? "" : this.descriptionSources[i].toString().toLowerCase(Locale.ROOT);
        }
        this.categories.clear();
        this.query = null;
        return true;
    }

    private static Module[] lmbd$update$0(int n) {
        return new Module[n];
    }
}
