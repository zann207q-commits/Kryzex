package kryzex.gui;

import java.awt.image.BufferedImage;
import kryzex.gui.Handle;
import kryzex.gui.FallbackFont;

final class FallbackAdvance {
    final int px;
    final Handle tex;
    final int[] w;
    final int[] h;
    final float[] adv;
    final int[] ox;
    final int[] oy;
    final int[] u;
    final int[] v;
    final float ascent;
    private final float fallbackAdvance;

    FallbackAdvance(int n, Handle handle, BufferedImage[] bufferedImageArray, float[] fArray, int[] nArray, int[] nArray2, int[] nArray3, int[] nArray4, float f) {
        this.px = n;
        this.tex = handle;
        this.w = new int[bufferedImageArray.length];
        this.h = new int[bufferedImageArray.length];
        for (int i = 0; i < bufferedImageArray.length; ++i) {
            if (bufferedImageArray[i] == null) continue;
            this.w[i] = bufferedImageArray[i].getWidth();
            this.h[i] = bufferedImageArray[i].getHeight();
        }
        this.adv = fArray;
        this.ox = nArray;
        this.oy = nArray2;
        this.u = nArray3;
        this.v = nArray4;
        this.ascent = f;
        this.fallbackAdvance = fArray[FallbackFont.CHARS.indexOf(63)];
    }

    int index(char c) {
        return c >= ' ' && c <= '~' ? c - 32 : FallbackFont.CHARS.indexOf(c);
    }

    float advance(char c) {
        int n = this.index(c);
        return n < 0 ? this.fallbackAdvance : this.adv[n];
    }
}
