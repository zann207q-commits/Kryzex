package kryzex.gui;

final class GuiParticle {
    float x;
    float y;
    float speed;
    float size;
    float phase;
    float fade;
    float sway;
    float base;

    public GuiParticle() {
    }
}
