package kryzex.gui;

public final class Tween {
    private Tween() {
    }

    public static float approach(float f, float f2, float f3, float f4) {
        float f5 = f + (f2 - f) * (1.0f - (float)Math.exp(-f3 * f4));
        return Math.abs(f2 - f5) < 0.001f ? f2 : f5;
    }

    public static float easeOutCubic(float f) {
        f = Tween.clamp01(f);
        float f2 = 1.0f - f;
        return 1.0f - f2 * f2 * f2;
    }

    public static float easeInOut(float f) {
        f = Tween.clamp01(f);
        return f * f * (3.0f - 2.0f * f);
    }

    public static float easeOutBack(float f) {
        f = Tween.clamp01(f);
        float f2 = 1.2f;
        float f3 = f2 + 1.0f;
        float f4 = f - 1.0f;
        return 1.0f + f3 * f4 * f4 * f4 + f2 * f4 * f4;
    }

    public static float clamp01(float f) {
        return Math.max(0.0f, Math.min(1.0f, f));
    }
}
