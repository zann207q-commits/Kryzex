package kryzex.gui;

import kryzex.gui.Handle;

final class ThemeStyle {
    Handle fill;
    Handle stroke;
    Handle glow;
    int pad;
    int w;
    int h;

    ThemeStyle() {
    }
}
