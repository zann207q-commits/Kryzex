package kryzex.gui;

import kryzex.gui.ListeningModule;
import kryzex.gui.StepSettingRow;
import kryzex.module.Module;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.Setting;

final class Mode
extends StepSettingRow {
    private final CycleSetting<?> mode;

    Mode(Module module, CycleSetting<?> cycleSetting) {
        super(module, (Setting)((Object)cycleSetting));
        this.mode = cycleSetting;
    }

    @Override
    String value() {
        Enum<?> enum_ = this.mode.getValue();
        if (enum_ == null) {
            return "";
        }
        String string = ListeningModule.pretty(enum_.toString());
        return string;
    }

    @Override
    void step(int n) {
        if (n > 0) {
            this.mode.cycleUp();
            return;
        } else {
            this.mode.cycleDown();
        }
    }
}
