package kryzex.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import kryzex.gui.CapHeight;
import kryzex.gui.PixelUnit;
import kryzex.gui.DropdownFont;

final class AtlasHeight {
    final PixelUnit spec;
    final int atlasHeight;
    final CapHeight title;
    final CapHeight body;
    final CapHeight pixel;
    final Map<String, int[]> icons = new HashMap<String, int[]>();
    final int[] argb;
    private int x = 1;
    private int y = 1;
    private int rowHeight;
    private final Map<CapHeight, GlyphVector[]> vectors = new LinkedHashMap<CapHeight, GlyphVector[]>();
    private final Map<CapHeight, Rectangle[]> bounds = new HashMap<CapHeight, Rectangle[]>();

    AtlasHeight(PixelUnit pixelUnit, Map<String, int[]> map) {
        int n;
        int n2;
        int n3;
        int n4;
        BufferedImage bufferedImage;
        this.spec = pixelUnit;
        int n5 = pixelUnit.iconSize();
        int n6 = pixelUnit.pixelUnit();
        CapHeight capHeight = this.ttf("/assets/r87f4560b4c09f4/r83d2dcd48984c5/minecraft_ten.ttf", pixelUnit.page(), 0.7f);
        this.pixel = new CapHeight(7 * n6, 0.0f, 1.0f);
        if (pixelUnit.font() == 2) {
            this.title = this.ttf("/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Bold.ttf", Math.round((float)pixelUnit.page() * 0.92f), 0.7f);
            this.body = this.ttf("/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Medium.ttf", Math.round((float)pixelUnit.page() * 0.9f), 0.7f);
        } else {
            this.title = capHeight;
            this.body = pixelUnit.font() == 1 ? this.pixel : capHeight;
        }
        try (InputStream inputStream = DropdownFont.class.getResourceAsStream("/assets/minecraft/textures/font/ascii.png");){
            bufferedImage = inputStream == null ? null : ImageIO.read(inputStream);
        }
        catch (Exception exception) {
            bufferedImage = null;
        }
        int n7 = bufferedImage == null ? 8 : bufferedImage.getWidth() / 16;
        float f = 8.0f * (float)n6 / (float)n7;
        int[] nArray = new int[95];
        for (n4 = 0; bufferedImage != null && n4 < 95; ++n4) {
            int n8;
            int n9;
            n3 = 32 + n4;
            int n10 = n3 % 16 * n7;
            int n11 = n3 / 16 * n7;
            int n12 = 0;
            block8: for (n9 = n7 - 1; n9 >= 0 && n12 == 0; --n9) {
                for (n8 = 0; n8 < n7; ++n8) {
                    if (bufferedImage.getRGB(n10 + n9, n11 + n8) >>> 24 <= 0) continue;
                    n12 = n9 + 1;
                    continue block8;
                }
            }
            this.pixel.present[n4] = true;
            if (n3 == 32) {
                this.pixel.advance[n4] = 4 * n6;
                continue;
            }
            if (n12 == 0) {
                this.pixel.present[n4] = false;
                continue;
            }
            nArray[n4] = n12;
            n9 = Math.round((float)n12 * f);
            n8 = Math.round((float)n7 * f);
            this.pixel.advance[n4] = n9 + n6;
            this.place(this.pixel, n4, n9 + 2, n8 + 2);
            this.pixel.offsetX[n4] = -1;
            this.pixel.offsetY[n4] = -7 * n6 - 1;
        }
        n4 = this.y + this.rowHeight + 2;
        n3 = 1;
        for (String string : map.keySet()) {
            if (n3 + n5 + 2 > 512) {
                n3 = 1;
                n4 += n5 + 3;
            }
            this.icons.put(string, new int[]{n3 + '\u0001', n4 + 1});
            n3 += n5 + 3;
        }
        this.atlasHeight = n4 + n5 + 3;
        BufferedImage bufferedImage2 = new BufferedImage(512, this.atlasHeight, 2);
        Graphics2D graphics2D = DropdownFont.hinted(bufferedImage2.createGraphics());
        graphics2D.setColor(Color.WHITE);
        for (Map.Entry<CapHeight, GlyphVector[]> entry : this.vectors.entrySet()) {
            CapHeight capHeight2 = entry.getKey();
            GlyphVector[] glyphVectorArray = entry.getValue();
            Rectangle[] rectangleArray = this.bounds.get(capHeight2);
            for (n2 = 0; n2 < 95; ++n2) {
                if (glyphVectorArray[n2] == null) continue;
                graphics2D.drawGlyphVector(glyphVectorArray[n2], capHeight2.u[n2] + 1 - rectangleArray[n2].x, capHeight2.v[n2] + 1 - rectangleArray[n2].y);
            }
        }
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        for (n = 0; bufferedImage != null && n < 95; ++n) {
            if (nArray[n] == 0) continue;
            char c = (char)(32 + n);
            int n13 = c % 16 * n7;
            int n14 = c / 16 * n7;
            int n15 = this.pixel.u[n] + 1;
            n2 = this.pixel.v[n] + 1;
            graphics2D.drawImage(bufferedImage, n15, n2, n15 + this.pixel.w[n] - 2, n2 + this.pixel.h[n] - 2, n13, n14, n13 + nArray[n], n14 + n7, null);
        }
        graphics2D.dispose();
        this.argb = bufferedImage2.getRGB(0, 0, 512, this.atlasHeight, null, 0, 512);
        for (n = 0; n < this.argb.length; ++n) {
            this.argb[n] = this.argb[n] & 0xFF000000 | 0xFFFFFF;
        }
        for (Map.Entry<String, int[]> entry : map.entrySet()) {
            int[] nArray2 = this.icons.get(entry.getKey());
            int[] nArray3 = entry.getValue();
            for (int i = 0; i < n5; ++i) {
                for (n2 = 0; n2 < n5; ++n2) {
                    int n16 = nArray3[i * n5 + n2] >>> 24;
                    this.argb[(nArray2[1] + i) * 512 + nArray2[0] + n2] = n16 << 24 | 0xFFFFFF;
                }
            }
        }
    }

    private CapHeight ttf(String string, int n, float f) {
        CapHeight capHeight = new CapHeight((float)n * f / 2.0f, -1.0f, 0.5f);
        Font font = DropdownFont.font(string).deriveFont(0, n);
        Graphics2D graphics2D = DropdownFont.hinted(new BufferedImage(1, 1, 2).createGraphics());
        FontRenderContext fontRenderContext = graphics2D.getFontRenderContext();
        graphics2D.dispose();
        FontRenderContext fontRenderContext2 = new FontRenderContext(null, true, true);
        GlyphVector[] glyphVectorArray = new GlyphVector[95];
        Rectangle[] rectangleArray = new Rectangle[95];
        for (int i = 0; i < 95; ++i) {
            char c = (char)(32 + i);
            if (!font.canDisplay(c)) continue;
            capHeight.present[i] = true;
            capHeight.advance[i] = (float)Math.round(font.createGlyphVector(fontRenderContext2, new char[]{c}).getGlyphMetrics(0).getAdvanceX()) / 2.0f;
            GlyphVector glyphVector = font.createGlyphVector(fontRenderContext, new char[]{c});
            Rectangle rectangle = glyphVector.getPixelBounds(fontRenderContext, 0.0f, 0.0f);
            if (rectangle.isEmpty()) continue;
            glyphVectorArray[i] = glyphVector;
            rectangleArray[i] = rectangle;
            this.place(capHeight, i, rectangle.width + 2, rectangle.height + 2);
            capHeight.offsetX[i] = rectangle.x - 1;
            capHeight.offsetY[i] = rectangle.y - 1;
        }
        this.vectors.put(capHeight, glyphVectorArray);
        this.bounds.put(capHeight, rectangleArray);
        return capHeight;
    }

    private void place(CapHeight capHeight, int n, int n2, int n3) {
        if (this.x + n2 > 512) {
            this.x = 1;
            this.y = this.y + this.rowHeight + 1;
            this.rowHeight = 0;
        }
        capHeight.u[n] = this.x;
        capHeight.v[n] = this.y;
        capHeight.w[n] = n2;
        capHeight.h[n] = n3;
        this.x += n2 + 1;
        this.rowHeight = Math.max(this.rowHeight, n3);
    }
}
