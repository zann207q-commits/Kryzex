package kryzex.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import kryzex.gui.Advance;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Easing;
import kryzex.gui.Life;
import kryzex.gui.Sansserif;
import kryzex.gui.SpeakerOff;
import kryzex.gui.ThemeStyle;
import kryzex.gui.WorldPitch;

public final class WelcomeScreen {
    public static final float CONTINUE_DELAY = 3.0f;
    private static final float WELCOME_IN = 0.45f;
    private static final float BRAND_IN = 0.9f;
    private static final float LANDED = 2.1f;
    private final Random rnd = new Random();
    private final List<Life> motes = new ArrayList<Life>();
    private final float[] button = new float[4];
    private float buttonShown;
    private float hover;
    private float press;
    private float spawn;
    private float flicker = 1.0f;

    public static float continueAt() {
        return 5.1f;
    }

    public boolean overContinue(double d, double d2) {
        if (!(this.buttonShown > 0.6f)) return false;
        if (!(d >= (double)this.button[0])) return false;
        if (!(d2 >= (double)this.button[1])) return false;
        if (!(d < (double)(this.button[0] + this.button[2]))) return false;
        if (!(d2 < (double)(this.button[1] + this.button[3]))) return false;
        return true;
    }

    public boolean continueVisible() {
        if (!(this.buttonShown > 0.6f)) return false;
        return true;
    }

    public void pressed() {
        this.press = 1.0f;
    }

    private static float expoOut(float f) {
        if ((f = Easing.clamp(f, 0.0f, 1.0f)) >= 1.0f) {
            return 1.0f;
        }
        float f2 = 1.0f - (float)Math.pow(2.0, -10.0 * (double)f);
        return f2;
    }

    private static float smooth(float f) {
        f = Easing.clamp(f, 0.0f, 1.0f);
        return f * f * (3.0f - 2.0f * f);
    }

    private static int argb(float f, int n) {
        return Math.round(Easing.clamp(f, 0.0f, 1.0f) * 255.0f) << 24 | n & 0xFFFFFF;
    }

    public void render(BaseRenderer baseRenderer, int n, int n2, float f, float f2, float f3, double d, double d2) {
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13 = Easing.inOut(f3);
        float f14 = 1.0f - f13;
        float f15 = (float)n2 / 1080.0f;
        float f16 = (float)n / 2.0f;
        float f17 = (float)n2 * 0.42f;
        float f18 = 0.86f + 0.08f * (float)Math.sin(f * 7.1f) * (float)Math.sin(f * 2.3f + 1.0f) + 0.06f * (float)Math.sin(f * 13.7f);
        this.flicker += (f18 - this.flicker) * (1.0f - (float)Math.exp(-f2 * 12.0f));
        float f19 = WelcomeScreen.smooth((f - 0.2f) / 1.4f) * f14;
        baseRenderer.glow(f16, f17, (float)n2 * 0.7f, BaseRenderer.argb(0.38f * f19, 6, 2, 8));
        int n3 = Math.max(18, Math.round(96.0f * f15));
        ThemeStyle themeStyle = Sansserif.title("KRYZEX CLIENT", n3, 0.02f);
        float f20 = WelcomeScreen.expoOut((f - 0.9f) / 1.25f);
        float f21 = WelcomeScreen.smooth((f - 0.9f) / 0.7f) * f14;
        float f22 = (1.0f + 0.1f * (1.0f - f20)) * (1.0f + 0.04f * f13);
        float f23 = (float)themeStyle.w * f22;
        float f24 = (float)themeStyle.h * f22;
        float f25 = f16 - f23 / 2.0f;
        float f26 = f17 - f24 / 2.0f + 14.0f * f15 * (1.0f - f20) - 8.0f * f15 * f13;
        float f27 = (float)Math.exp(-Math.max(0.0f, f - 0.9f - 0.55f) * 2.2f) * WelcomeScreen.smooth((f - 0.9f - 0.15f) / 0.45f);
        if (f21 > 0.002f) {
            f12 = (0.3f + 0.4f * f27) * this.flicker;
            baseRenderer.texture(themeStyle.glow, f25, f26 + 6.0f * f15 * f22, f23, f24, WelcomeScreen.argb(f12 * f21, 16742942));
            baseRenderer.texture(themeStyle.glow, f25, f26, f23, f24, WelcomeScreen.argb(0.22f * f21 * this.flicker, 16762218));
            baseRenderer.texture(themeStyle.stroke, f25, f26 + 5.0f * f15 * f22, f23, f24, WelcomeScreen.argb(0.55f * f21, 656134));
            baseRenderer.texture(themeStyle.stroke, f25, f26, f23, f24, WelcomeScreen.argb(0.92f * f21, 1509129));
            int n4 = Easing.mix(-1648952, -1, this.flicker * 0.9f + f27 * 0.4f);
            baseRenderer.texture(themeStyle.fill, f25, f26, f23, f24, n4 & 0xFFFFFF | Math.round(255.0f * f21) << 24);
            float f28 = (f - 2.1f - 0.2f) / 2.2f;
            if (f28 > 0.0f && f28 < 1.0f) {
                f11 = f25 + f23 * (f28 * 1.25f - 0.12f);
                baseRenderer.pushClip(f11 - f23 * 0.05f, f26, f23 * 0.1f, f24);
                baseRenderer.texture(themeStyle.stroke, f25, f26, f23, f24, WelcomeScreen.argb(0.3f * f21 * (float)Math.sin(Math.PI * (double)f28), 16774368));
                baseRenderer.popClip();
            }
        }
        f12 = WelcomeScreen.expoOut((f - 0.45f) / 1.4f);
        float f29 = WelcomeScreen.smooth((f - 0.45f) / 0.8f) * f14;
        int n5 = Math.max(10, Math.round(22.0f * f15));
        f11 = f26 + (float)themeStyle.pad * f22 - 12.0f * f15;
        float f30 = f11 - (float)n5 * 1.9f - (1.0f - f12) * 10.0f * f15 - f13 * 6.0f * f15;
        if (f29 > 0.002f) {
            String string = "WELCOME TO";
            f10 = (float)n5 * (0.95f - 0.5f * f12);
            f9 = 0.0f;
            for (int i = 0; i < string.length(); ++i) {
                f9 += Sansserif.glyph((char)string.charAt((int)i), (int)n5).advance + (i + 1 < string.length() ? f10 : 0.0f);
            }
            f8 = f16 - f9 / 2.0f;
            int n6 = 15984338;
            for (int i = 0; i < string.length(); ++i) {
                Advance advance = Sansserif.glyph(string.charAt(i), n5);
                f7 = WelcomeScreen.smooth((f - 0.45f - (float)i * 0.035f) / 0.6f) * f14;
                baseRenderer.texture(advance.mask, f8 - (float)advance.pad, f30 - (float)advance.pad + 3.0f * f15 * (1.0f - f7), advance.mask.w, advance.mask.h, WelcomeScreen.argb(0.9f * f7 * f29, n6));
                f8 += advance.advance + f10;
            }
            float f31 = WelcomeScreen.smooth((f - 0.45f - 0.3f) / 1.0f) * f29;
            f6 = f30 + (float)n5 * 0.38f;
            f7 = 22.0f * f15;
            f5 = 150.0f * f15 * f31;
            baseRenderer.pushTransform(f16 - f9 / 2.0f - f7 - f5, f6, 1.0f);
            WelcomeScreen.hRule(baseRenderer, f5, Math.max(1.0f, 1.4f * f15), WelcomeScreen.argb(0.65f * f31, n6), false);
            baseRenderer.popTransform();
            baseRenderer.pushTransform(f16 + f9 / 2.0f + f7, f6, 1.0f);
            WelcomeScreen.hRule(baseRenderer, f5, Math.max(1.0f, 1.4f * f15), WelcomeScreen.argb(0.65f * f31, n6), true);
            baseRenderer.popTransform();
        }
        if ((f4 = WelcomeScreen.smooth((f - 0.9f - 0.6f) / 1.1f) * f14) > 0.002f) {
            f10 = f26 + f24 - (float)themeStyle.pad * f22 + 22.0f * f15;
            f9 = 210.0f * f15 * f4;
            baseRenderer.pushTransform(f16 - f9 - 16.0f * f15, f10, 1.0f);
            WelcomeScreen.hRule(baseRenderer, f9, Math.max(1.0f, 1.4f * f15), WelcomeScreen.argb(0.55f * f4, 15980980), false);
            baseRenderer.popTransform();
            baseRenderer.pushTransform(f16 + 16.0f * f15, f10, 1.0f);
            WelcomeScreen.hRule(baseRenderer, f9, Math.max(1.0f, 1.4f * f15), WelcomeScreen.argb(0.55f * f4, 15980980), true);
            baseRenderer.popTransform();
            WorldPitch.lantern(baseRenderer, f16 - 12.0f * f15, f10 - 13.0f * f15, 24.0f * f15, f, f4);
        }
        this.motes(baseRenderer, n, n2, f16, f17, f23, f24, f, f2, f14 * WelcomeScreen.smooth((f - 0.9f) / 1.6f));
        f10 = WelcomeScreen.expoOut((f - WelcomeScreen.continueAt()) / 0.9f);
        this.buttonShown = WelcomeScreen.smooth((f - WelcomeScreen.continueAt()) / 0.6f) * f14;
        if (!(this.buttonShown > 0.002f)) return;
        f9 = 236.0f * f15;
        f8 = 54.0f * f15;
        float f32 = (float)n2 * 0.665f;
        boolean bl = this.buttonShown > 0.6f && d >= (double)(f16 - f9 / 2.0f) && d < (double)(f16 + f9 / 2.0f) && d2 >= (double)f32 && d2 < (double)(f32 + f8);
        this.hover += ((bl ? 1.0f : 0.0f) - this.hover) * (1.0f - (float)Math.exp(-14.0f * f2));
        this.press = Math.max(0.0f, this.press - f2 * 3.0f);
        f6 = (1.0f - f10) * 20.0f * f15 + this.hover * 2.0f * f15;
        f7 = (0.95f + 0.05f * f10) * (1.0f - 0.03f * this.press);
        f5 = f9 * f7;
        float f33 = f8 * f7;
        float f34 = f16 - f5 / 2.0f;
        float f35 = f32 - f6 + (f8 - f33) / 2.0f;
        this.button[0] = f16 - f9 / 2.0f;
        this.button[1] = f32;
        this.button[2] = f9;
        this.button[3] = f8;
        baseRenderer.pushAlpha(this.buttonShown);
        float f36 = (f - WelcomeScreen.continueAt()) % 2.6f / 2.6f;
        if (f10 > 0.98f) {
            float f37 = f36 * 10.0f * f15;
            baseRenderer.outline(f34 - f37, f35 - f37, f5 + f37 * 2.0f, f33 + f37 * 2.0f, f33 / 2.0f + f37, Math.max(1.0f, f15), WelcomeScreen.argb(0.2f * (1.0f - f36), 16756832));
        }
        baseRenderer.shadow(f34, f35, f5, f33, f33 / 2.0f, 22.0f * f15, BaseRenderer.argb(0.5f, 0, 0, 0));
        baseRenderer.glow(f34 + f5 / 2.0f, f35 + f33 / 2.0f, f5 * 0.75f, WelcomeScreen.argb(0.05f + 0.1f * this.hover, 16747066));
        baseRenderer.round(f34, f35, f5, f33, f33 / 2.0f, BaseRenderer.argb(0.7f, 20, 12, 14));
        baseRenderer.roundGradient(f34, f35, f5, f33 * 0.55f, f33 / 2.0f, BaseRenderer.white(0.06f + 0.04f * this.hover), BaseRenderer.white(0.0f));
        baseRenderer.round(f34, f35, f5, f33, f33 / 2.0f, WelcomeScreen.argb(0.1f * this.hover + 0.18f * this.press, 16751176));
        baseRenderer.outline(f34, f35, f5, f33, f33 / 2.0f, Math.max(1.0f, 1.2f * f15), Easing.mix(WelcomeScreen.argb(0.22f, 15984338), WelcomeScreen.argb(0.8f, 16757862), this.hover));
        int n7 = Math.max(8, Math.round(15.0f * f15));
        String string = "CONTINUE";
        float f38 = (float)n7 * 0.28f;
        float f39 = 0.0f;
        for (int i = 0; i < string.length(); ++i) {
            f39 += Sansserif.glyph((char)string.charAt((int)i), (int)n7).advance + (i + 1 < string.length() ? f38 : 0.0f);
        }
        float f40 = 16.0f * f15;
        float f41 = 10.0f * f15;
        float f42 = f34 + (f5 - f39 - f41 - f40) / 2.0f;
        float f43 = f35 + (f33 - (float)n7) / 2.0f - (float)n7 * 0.08f;
        int n8 = Easing.mix(-792878, -7492, this.hover);
        for (int i = 0; i < string.length(); ++i) {
            Advance advance = Sansserif.glyph(string.charAt(i), n7);
            baseRenderer.texture(advance.mask, f42 - (float)advance.pad, f43 - (float)advance.pad, advance.mask.w, advance.mask.h, n8);
            f42 += advance.advance + f38;
        }
        baseRenderer.icon(SpeakerOff.CHEVRON_RIGHT, f42 - f38 + f41 + this.hover * 3.0f * f15, f35 + (f33 - f40) / 2.0f, f40, Easing.mix(BaseRenderer.white(0.75f), WelcomeScreen.argb(1.0f, 16757862), this.hover));
        baseRenderer.popAlpha();
    }

    private static void hRule(BaseRenderer baseRenderer, float f, float f2, int n, boolean bl) {
        int n2 = 12;
        float f3 = f / (float)n2;
        for (int i = 0; i < n2; ++i) {
            float f4 = ((float)i + 0.5f) / (float)n2;
            float f5 = bl ? 1.0f - f4 : f4;
            int n3 = Math.round((float)(n >>> 24) * f5 * f5) << 24 | n & 0xFFFFFF;
            baseRenderer.rect((float)i * f3, 0.0f, f3 + 0.5f, f2, n3);
        }
    }

    private void motes(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        if (f9 <= 0.002f) {
            return;
        }
        this.spawn += f8 * 16.0f;
        while (this.spawn >= 1.0f && this.motes.size() < 56) {
            this.spawn -= 1.0f;
            Life life = new Life();
            life.kind = this.rnd.nextFloat() < 0.72f ? 0 : 1;
            life.x = f3 + (this.rnd.nextFloat() - 0.5f) * f5 * 1.25f;
            life.y = f4 + f6 * (0.25f + this.rnd.nextFloat() * 0.9f);
            life.vx = (this.rnd.nextFloat() - 0.5f) * f2 * 0.01f;
            life.vy = -f2 * (0.03f + this.rnd.nextFloat() * 0.04f) * (life.kind == 1 ? 0.35f : 1.0f);
            life.life = 2.4f + this.rnd.nextFloat() * 2.6f;
            life.size = f2 * (life.kind == 0 ? 0.0012f + this.rnd.nextFloat() * 0.0018f : 8.0E-4f + this.rnd.nextFloat() * 0.001f);
            life.seed = this.rnd.nextFloat() * 50.0f;
            this.motes.add(life);
        }
        for (int i = this.motes.size() - 1; i >= 0; --i) {
            Life life = this.motes.get(i);
            life.age += f8;
            if (life.age >= life.life) {
                this.motes.remove(i);
                continue;
            }
            float f10 = 1.0f - life.age / life.life;
            life.x = life.x + (life.vx + (float)Math.sin(life.age * 2.1f + life.seed) * f2 * 0.012f * (life.kind == 0 ? 1.0f : 0.4f)) * f8;
            life.y += life.vy * f8 * (0.5f + 0.5f * f10);
            float f11 = life.age / life.life;
            float f12 = (float)Math.sin(Math.PI * (double)Math.min(1.0f, f11 * 1.2f)) * f9;
            float f13 = (life.x - f3) / (f5 * 0.52f);
            float f14 = (life.y - f4) / (f6 * 0.42f);
            f12 *= Easing.clamp((f13 * f13 + f14 * f14 - 0.7f) / 0.6f, 0.12f, 1.0f);
            if (life.kind == 0) {
                float f15 = 0.65f + 0.35f * (float)Math.sin(life.age * 19.0f + life.seed);
                int n = Easing.mix(-8032, -38368, f11);
                baseRenderer.glow(life.x, life.y, life.size * 8.0f, WelcomeScreen.argb(0.16f * f12 * f15, 16738842));
                baseRenderer.glow(life.x, life.y, life.size * 2.0f, WelcomeScreen.argb(0.95f * f12 * f15, n));
                continue;
            }
            baseRenderer.glow(life.x, life.y, life.size * 3.0f, WelcomeScreen.argb(0.35f * f12, 15984338));
        }
    }
}
