package kryzex.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.class_1011;
import net.minecraft.class_1043;

final class KryzexLoadingLogo
extends class_1043 {
    KryzexLoadingLogo(class_1011 class_10112) {
        super(KryzexLoadingLogo::lmbd$new$0, class_10112);
        this.field_63613 = RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
    }

    private static String lmbd$new$0() {
        return "Kryzex loading logo";
    }
}
