package kryzex.gui;

class Action {
    public final float x;
    public final float y;
    public final float w;
    public final float h;
    public final Runnable action;

    public Action(float x, float y, float w, float h, Runnable action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.action = action;
    }

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float w() {
        return this.w;
    }

    public float h() {
        return this.h;
    }

    public Runnable action() {
        return this.action;
    }
}
