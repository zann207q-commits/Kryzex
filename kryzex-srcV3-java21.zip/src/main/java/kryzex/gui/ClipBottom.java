package kryzex.gui;

class ClipBottom {
    public final String name;
    public final float x;
    public final float y;
    public final float size;
    public final float alpha;
    public final float clipTop;
    public final float clipBottom;

    public ClipBottom(String name, float x, float y, float size, float alpha, float clipTop, float clipBottom) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.size = size;
        this.alpha = alpha;
        this.clipTop = clipTop;
        this.clipBottom = clipBottom;
    }

    public String name() {
        return this.name;
    }

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float size() {
        return this.size;
    }

    public float alpha() {
        return this.alpha;
    }

    public float clipTop() {
        return this.clipTop;
    }

    public float clipBottom() {
        return this.clipBottom;
    }
}
