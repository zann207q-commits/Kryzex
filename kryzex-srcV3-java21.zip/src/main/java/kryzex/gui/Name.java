package kryzex.gui;

import java.util.UUID;

public class Name {
    public final String name;
    public final UUID uuid;

    public Name(String name, UUID uuid) {
        this.name = name;
        this.uuid = uuid;
    }

    public String name() {
        return this.name;
    }

    public UUID uuid() {
        return this.uuid;
    }
}
