package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.LastSource;
import kryzex.gui.SquareCorners;

public final class GuiWidgets {
    private GuiWidgets() {
    }

    public static void header(SquareCorners squareCorners, float f, float f2, float f3, String string, String string2, float f4, float f5) {
        float f6 = f2 + 12.5f;
        squareCorners.icon(string2, f + 17.5f, f6, LastSource.ICON);
        squareCorners.useTitleFont();
        squareCorners.text(string, f + 28.0f, f6, -723976, f3 - 28.0f - 26.0f);
        squareCorners.useBodyFont();
        float f7 = f + f3 - 12.0f;
        float f8 = f7 - 7.0f;
        float f9 = f6 + 0.5f;
        int n = LastSource.mix(-7434347, -723976, f5);
        float f10 = 0.7f;
        squareCorners.roundRect(f8, f9 - f10, f7, f9 + f10, f10, n);
        if (!(f4 > 0.01f)) return;
        float f11 = (f8 + f7) / 2.0f;
        float f12 = 3.5f * f4;
        squareCorners.roundRect(f11 - f10, f9 - f12, f11 + f10, f9 + f12, f10, n);
    }

    public static boolean overMinus(float f, float f2, float f3, float f4, float f5) {
        if (!(f4 >= f + f3 - 12.0f - 7.0f - 7.0f)) return false;
        if (!(f4 < f + f3)) return false;
        if (!(f5 >= f2)) return false;
        if (!(f5 < f2 + 26.0f)) return false;
        return true;
    }

    public static void toggle(SquareCorners squareCorners, float f, float f2, float f3, float f4) {
        float f5 = Tween.easeInOut(f3);
        float f6 = f - 32.0f;
        float f7 = f2 - 8.0f;
        float f8 = f2 + 8.0f;
        float f9 = 8.0f;
        if (f5 > 0.01f) {
            squareCorners.shadow(f6 + 1.0f, f7 + 1.0f, f - 1.0f, f8 - 1.0f, f9, 6.0f, LastSource.withAlpha(LastSource.GLOW, f5 * (0.85f + 0.15f * f4)));
        }
        int n = LastSource.mix(977945216, 1347308172, f4 * 0.6f);
        squareCorners.roundRect(f6, f7, f, f8, f9, LastSource.mix(n, LastSource.SWITCH_ON, f5));
        float f10 = f6 + 8.0f + (f - f6 - 16.0f) * f5;
        squareCorners.circle(f10, f2 + 0.5f, 6.5f, 0x26000000);
        squareCorners.circle(f10, f2, 6.0f, -460547);
    }

    public static void slider(SquareCorners squareCorners, float f, float f2, float f3, float f4, float f5, boolean bl) {
        float f6 = 1.75f;
        float f7 = f + (f2 - f) * Math.max(0.0f, Math.min(1.0f, f4));
        squareCorners.roundRect(f, f3 - f6, f2, f3 + f6, f6, LastSource.mix(0x16000000, 0x42000000, f5));
        if (f7 > f + 0.5f) {
            squareCorners.shadow(f, f3 - f6, f7, f3 + f6, f6, 3.0f, LastSource.withAlpha(LastSource.GLOW, 0.35f + 0.25f * f5));
            squareCorners.roundRect(f, f3 - f6, f7, f3 + f6, f6, LastSource.SLIDER_FILL);
        }
        GuiWidgets.knob(squareCorners, f7, f3, f5, bl);
    }

    public static void range(SquareCorners squareCorners, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        float f7 = 1.75f;
        float f8 = f + (f2 - f) * Math.max(0.0f, Math.min(1.0f, f4));
        float f9 = f + (f2 - f) * Math.max(0.0f, Math.min(1.0f, f5));
        squareCorners.roundRect(f, f3 - f7, f2, f3 + f7, f7, LastSource.mix(0x16000000, 0x42000000, f6));
        if (f9 > f8 + 0.5f) {
            squareCorners.shadow(f8, f3 - f7, f9, f3 + f7, f7, 3.0f, LastSource.withAlpha(LastSource.GLOW, 0.35f + 0.25f * f6));
            squareCorners.roundRect(f8, f3 - f7, f9, f3 + f7, f7, LastSource.SLIDER_FILL);
        }
        GuiWidgets.knob(squareCorners, f8, f3, f6, n == 1);
        GuiWidgets.knob(squareCorners, f9, f3, f6, n == 2);
    }

    private static void knob(SquareCorners squareCorners, float f, float f2, float f3, boolean bl) {
        float f4 = 4.5f + (bl ? 0.8f : 0.4f * f3);
        squareCorners.circle(f, f2 + 0.4f, f4 + 0.4f, 0x2A000000);
        squareCorners.circle(f, f2, f4, -460547);
    }

    public static float fractionAt(float f, float f2, float f3) {
        return Math.max(0.0f, Math.min(1.0f, (f3 - f) / (f2 - f)));
    }

    public static void keybind(SquareCorners squareCorners, float f, float f2, String string, float f3, float f4, float f5) {
        float f6 = f - 92.0f;
        float f7 = f2 - 11.5f;
        float f8 = f2 + 11.5f;
        squareCorners.roundRect(f6, f7, f, f8, 4.0f, LastSource.mix(0x2E000000, 0x40000000, f3));
        float f9 = 0.6f + 0.4f * (float)Math.sin(f5 * 6.0f) * 0.5f + 0.2f;
        int n = LastSource.mix(0x14FFFFFF, LastSource.withAlpha(LastSource.SWITCH_ON, 0.5f), f4 * f9);
        squareCorners.stroke(f6, f7, f, f8, 4.0f, 1.0f, LastSource.mix(n, 0x24FFFFFF, f3 * (1.0f - f4)));
        squareCorners.text(string, (f6 + f) / 2.0f - Math.min(squareCorners.textWidth(string), 80.0f) / 2.0f, f2, LastSource.VALUE, 80.0f);
    }

    public static float chip(SquareCorners squareCorners, float f, float f2, String string, float f3, float f4) {
        float f5 = Math.min(squareCorners.textWidth(string), f4);
        float f6 = f - 9.0f - f5;
        squareCorners.text(string, f6, f2, LastSource.mix(LastSource.VALUE, LastSource.TEXT_ACTIVE_HOVER, f3), f4);
        int n = LastSource.withAlpha(LastSource.VALUE, 0.55f + 0.45f * f3);
        GuiWidgets.chevron(squareCorners, f - 2.5f, f2, 1.0f, n);
        GuiWidgets.chevron(squareCorners, f6 - 7.0f, f2, -1.0f, n);
        return f6 - 10.0f;
    }

    public static void chevron(SquareCorners squareCorners, float f, float f2, float f3, int n) {
        for (int i = 0; i < 4; ++i) {
            float f4 = (float)i * 0.9f;
            squareCorners.circle(f - f3 * f4, f2 - f4, 0.75f, n);
            squareCorners.circle(f - f3 * f4, f2 + f4, 0.75f, n);
        }
    }

    public static float button(SquareCorners squareCorners, float f, float f2, String string, float f3, float f4) {
        float f5 = squareCorners.textWidth(string) + 18.0f;
        float f6 = f - f5;
        float f7 = 21.0f;
        float f8 = f2 - f7 / 2.0f;
        if (f3 > 0.01f) {
            squareCorners.shadow(f6 + 1.0f, f8 + 1.0f, f - 1.0f, f8 + f7 - 1.0f, 5.0f, 6.0f, LastSource.withAlpha(LastSource.GLOW, 0.55f * f3));
        }
        squareCorners.roundRect(f6, f8, f, f8 + f7, 5.0f, LastSource.mix(LastSource.withAlpha(LastSource.SWITCH_ON, 0.22f), LastSource.withAlpha(LastSource.SWITCH_ON, 0.42f), Math.max(f3, f4)));
        squareCorners.stroke(f6, f8, f, f8 + f7, 5.0f, 1.0f, LastSource.withAlpha(LastSource.SWITCH_ON, 0.5f + 0.3f * f3));
        squareCorners.text(string, f6 + 9.0f, f2, LastSource.mix(LastSource.TEXT_ACTIVE, -1, f3));
        return f5;
    }

    public static void magnifier(SquareCorners squareCorners, float f, float f2, int n) {
        float f3 = 3.6f;
        float f4 = f - 1.0f;
        float f5 = f2 - 1.0f;
        squareCorners.stroke(f4 - f3, f5 - f3, f4 + f3, f5 + f3, f3, 1.3f, n);
        for (float f6 = 0.0f; f6 <= 1.001f; f6 += 0.25f) {
            float f7 = f3 + 0.6f + f6 * 2.6f;
            squareCorners.circle(f4 + f7 * 0.7071f, f5 + f7 * 0.7071f, 0.7f, n);
        }
    }
}
