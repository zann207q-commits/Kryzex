package kryzex.gui;

@FunctionalInterface
interface DrawAction {
    public void draw(float var1, float var2);
}
