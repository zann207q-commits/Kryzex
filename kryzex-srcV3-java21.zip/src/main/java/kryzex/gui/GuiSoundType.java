package kryzex.gui;

public enum GuiSoundType {
    TICK,
    SLIDE,
    TAB,
    ON,
    OFF,
    OPEN,
    BACK,
    CONFIRM,
    THEME,
    GUI_OPEN,
    GUI_CLOSE,
    TAB_2,
    TAB_3;

}
