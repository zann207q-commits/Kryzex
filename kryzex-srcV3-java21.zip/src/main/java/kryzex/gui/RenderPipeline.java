package kryzex.gui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import kryzex.util.EffectPipelines;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_290;
import net.minecraft.class_2960;

final class RenderPipeline {
    static final com.mojang.blaze3d.pipeline.RenderPipeline PIPELINE = com.mojang.blaze3d.pipeline.RenderPipeline.builder((com.mojang.blaze3d.pipeline.RenderPipeline.Snippet[])new com.mojang.blaze3d.pipeline.RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/gui_analytic_round")).withVertexShader(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/gui_analytic_round")).withFragmentShader(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/gui_analytic_round")).withUniform("DynamicTransforms", class_10789.field_60031).withUniform("Projection", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(class_10799.field_56879.getDepthTestFunction()).withDepthWrite(class_10799.field_56879.isWriteDepth()).withCull(false).withVertexFormat(class_290.field_1580, VertexFormat.class_5596.field_27382).build();
    private static boolean checked;
    private static boolean available;

    RenderPipeline() {
    }

    static boolean ready() {
        if (checked) return available;
        checked = true;
        try {
            available = EffectPipelines.compiled(PIPELINE);
            if (available) return available;
            System.err.println("Kryzex GUI shader unavailable; using standard rounded rendering.");
            return available;
        }
        catch (RuntimeException runtimeException) {
            available = false;
            System.err.println("Kryzex GUI shader: " + runtimeException.getClass().getSimpleName());
        }
        return available;
    }
}
