package kryzex.gui;

import kryzex.gui.IntSetter;

class Layer {
    public final float x;
    public final float y;
    public final float w;
    public final float h;
    public final int layer;
    public final IntSetter act;

    public Layer(float x, float y, float w, float h, int layer, IntSetter act) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.layer = layer;
        this.act = act;
    }

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float w() {
        return this.w;
    }

    public float h() {
        return this.h;
    }

    public int layer() {
        return this.layer;
    }

    public IntSetter act() {
        return this.act;
    }
}
