package kryzex.gui;

final class Alpha {
    float sx;
    float sy;
    float dy;
    float alpha;
    int kind;
    boolean seen;

    public Alpha() {
    }
}
