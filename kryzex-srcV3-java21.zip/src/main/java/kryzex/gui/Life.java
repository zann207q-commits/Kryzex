package kryzex.gui;

final class Life {
    float x;
    float y;
    float vx;
    float vy;
    float life;
    float age;
    float size;
    float seed;
    int kind;

    public Life() {
    }
}
