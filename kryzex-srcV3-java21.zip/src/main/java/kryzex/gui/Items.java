package kryzex.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Predicate;
import kryzex.gui.Normalized;
import kryzex.gui.PaletteEntry;
import kryzex.gui.Previous;
import kryzex.gui.SelectItem;
import kryzex.module.Module;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.MacroEnchantSetting;
import kryzex.module.settings.MacroItemSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.misc.MacroModule;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_7923;

public final class Items {
    private static final Map<Setting, SelectItem> BINDINGS = new IdentityHashMap<Setting, SelectItem>();
    private static List<PaletteEntry> items;

    private static Predicate<PaletteEntry> textSelection(MacroEnchantSetting macroEnchantSetting) {
        return new Normalized(macroEnchantSetting);
    }

    private static Predicate<PaletteEntry> listSelection(MacroItemSetting macroItemSetting) {
        return new Previous(macroItemSetting);
    }

    private Items() {
    }

    static String id(String string) {
        String string2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
        if (string2.isEmpty()) return "";
        if (string2.equals("minecraft:air")) {
            return "";
        }
        String object = string2.contains(":") ? string2 : "minecraft:" + string2;
        return object;
    }

    private static List<PaletteEntry> items() {
        if (items != null) return items;
        ArrayList<PaletteEntry> arrayList = new ArrayList<PaletteEntry>();
        arrayList.add(new PaletteEntry("", "None", null, null));
        for (class_1792 class_17922 : class_7923.field_41178) {
            if (class_17922 == class_1802.field_8162) continue;
            arrayList.add(new PaletteEntry(class_7923.field_41178.method_10221((class_1792)class_17922).toString(), class_17922.method_63680().getString(), class_17922, null));
        }
        arrayList.subList(1, arrayList.size()).sort(Comparator.comparing(PaletteEntry::name, String.CASE_INSENSITIVE_ORDER));
        items = List.copyOf(arrayList);
        return items;
    }

    public static SelectItem forSetting(Module module, Setting setting) {
        SelectItem selectItem = BINDINGS.get(setting);
        if (selectItem != null) {
            return selectItem;
        }
        SelectItem selectItem2 = null;
        if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            selectItem2 = new SelectItem(setting.getName().toString(), Items.items(), false, arg_0 -> Items.lmbd$forSetting$0(itemSetting, arg_0), arg_0 -> Items.lmbd$forSetting$1(itemSetting, arg_0), () -> Items.lmbd$forSetting$2(itemSetting));
        } else if (setting instanceof ListSetting) {
            ListSetting listSetting = (ListSetting)setting;
            ArrayList<PaletteEntry> arrayList = new ArrayList<PaletteEntry>();
            for (ToggleEntry toggleEntry : listSetting.entries()) {
                arrayList.add(new PaletteEntry(toggleEntry.id(), toggleEntry.displayName(), toggleEntry.item(), toggleEntry));
            }
            arrayList.sort(Comparator.comparing(PaletteEntry::name, String.CASE_INSENSITIVE_ORDER));
            selectItem2 = new SelectItem(setting.getName().toString(), List.copyOf(arrayList), true, Items::lmbd$forSetting$3, Items::lmbd$forSetting$4, listSetting::clear);
        } else if (module instanceof MacroModule) {
            MacroModule macroModule = (MacroModule)module;
            for (MacroSetting macroSetting : macroModule.extSettings()) {
                MacroEnchantSetting macroEnchantSetting;
                if (macroSetting.kryzex() != setting) continue;
                if (macroSetting instanceof MacroEnchantSetting && (macroEnchantSetting = (MacroEnchantSetting)macroSetting).isItemPicker()) {
                    selectItem2 = new SelectItem(setting.getName().toString(), Items.items(), false, Items.textSelection(macroEnchantSetting), arg_0 -> Items.lmbd$forSetting$5(macroEnchantSetting, arg_0), () -> Items.lmbd$forSetting$6(macroEnchantSetting));
                    break;
                }
                if (!(macroSetting instanceof MacroItemSetting)) break;
                MacroItemSetting macroItemSetting = (MacroItemSetting)macroSetting;
                selectItem2 = new SelectItem(setting.getName().toString(), Items.items().subList(1, Items.items().size()), true, Items.listSelection(macroItemSetting), arg_0 -> Items.lmbd$forSetting$7(macroItemSetting, arg_0), () -> Items.lmbd$forSetting$8(macroItemSetting));
                break;
            }
        }
        if (selectItem2 == null) return selectItem2;
        BINDINGS.put(setting, selectItem2);
        return selectItem2;
    }

    private static void lmbd$forSetting$8(MacroItemSetting macroItemSetting) {
        macroItemSetting.set(List.of());
    }

    private static void lmbd$forSetting$7(MacroItemSetting macroItemSetting, PaletteEntry paletteEntry) {
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        for (String string : macroItemSetting.get()) {
            linkedHashSet.add(Items.id(string));
        }
        if (!linkedHashSet.remove(paletteEntry.id())) {
            linkedHashSet.add(paletteEntry.id());
        }
        macroItemSetting.set(List.copyOf(linkedHashSet));
    }

    private static void lmbd$forSetting$6(MacroEnchantSetting macroEnchantSetting) {
        macroEnchantSetting.set("");
    }

    private static void lmbd$forSetting$5(MacroEnchantSetting macroEnchantSetting, PaletteEntry paletteEntry) {
        macroEnchantSetting.set(paletteEntry.id());
    }

    private static void lmbd$forSetting$4(PaletteEntry paletteEntry) {
        paletteEntry.palette().toggle();
    }

    private static boolean lmbd$forSetting$3(PaletteEntry paletteEntry) {
        return paletteEntry.palette().enabled();
    }

    private static void lmbd$forSetting$2(ItemSetting itemSetting) {
        itemSetting.setItem(class_1802.field_8162);
    }

    private static void lmbd$forSetting$1(ItemSetting itemSetting, PaletteEntry paletteEntry) {
        class_1792 class_17922;
        Object object = paletteEntry.item();
        itemSetting.setItem(object instanceof class_1792 ? (class_17922 = (class_1792)object) : class_1802.field_8162);
    }

    private static boolean lmbd$forSetting$0(ItemSetting itemSetting, PaletteEntry paletteEntry) {
        if (paletteEntry.item() == itemSetting.getItem()) return true;
        if (paletteEntry.item() != null) return false;
        if (itemSetting.getItem() == null) return true;
        if (itemSetting.getItem() != class_1802.field_8162) return false;
        return true;
    }
}
