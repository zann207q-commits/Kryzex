package kryzex.gui;

final class Bottom {
    boolean moved;
    boolean right;
    boolean bottom;
    float ox;
    float oy;

    public Bottom() {
    }
}
