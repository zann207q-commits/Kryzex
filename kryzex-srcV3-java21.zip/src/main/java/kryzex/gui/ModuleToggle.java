package kryzex.gui;

import kryzex.gui.GuiAudio;
import kryzex.gui.GuiSoundType;
import kryzex.module.Module;
import kryzex.modules.client.KryzexPlus;

public final class ModuleToggle {
    private ModuleToggle() {
    }

    public static void toggle(Module module) {
        boolean bl = module.isEnabled();
        module.toggle();
        if (bl == module.isEnabled() || module instanceof KryzexPlus) return;
        GuiAudio.play(module.isEnabled() ? GuiSoundType.ON : GuiSoundType.OFF);
    }
}
