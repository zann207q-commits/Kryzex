package kryzex.gui;

import java.awt.Color;

public final class LastSource {
    public static final float DESIGN_WIDTH = 1600.0f;
    public static final float DESIGN_HEIGHT = 840.0f;
    public static final int COLUMNS = 7;
    public static final float PANEL_WIDTH = 210.0f;
    public static final float PANEL_GAP = 19.0f;
    public static final float PANEL_TOP = 65.0f;
    public static final float PANEL_RADIUS = 7.0f;
    public static final float PANEL_BOTTOM_PAD = 2.5f;
    public static final float HEADER_HEIGHT = 26.0f;
    public static final float HEADER_TEXT_Y = 12.5f;
    public static final float ICON_CENTER_X = 17.5f;
    public static final float TITLE_X = 28.0f;
    public static final float MINUS_RIGHT = 12.0f;
    public static final float MINUS_WIDTH = 7.0f;
    public static final float ROW_HEIGHT = 27.5f;
    public static final float TEXT_X = 8.0f;
    public static final float RIGHT_INSET = 10.0f;
    public static final float SETTING_ROW = 30.0f;
    public static final float NUMBER_ROW = 48.0f;
    public static final float NUMBER_LABEL_Y = 14.5f;
    public static final float NUMBER_SLIDER_Y = 38.5f;
    public static final float WRAP_LINE = 19.0f;
    public static final float SWITCH_WIDTH = 32.0f;
    public static final float SWITCH_HEIGHT = 16.0f;
    public static final float KNOB_RADIUS = 6.0f;
    public static final float KNOB_INSET = 8.0f;
    public static final float SLIDER_THICKNESS = 3.5f;
    public static final float SLIDER_KNOB = 4.5f;
    public static final float SWATCH_SIZE = 15.0f;
    public static final float KEYBIND_WIDTH = 92.0f;
    public static final float KEYBIND_HEIGHT = 23.0f;
    public static final float ACCENT_WIDTH = 3.0f;
    public static final float SEARCH_FIELD_TOP = 32.0f;
    public static final float SEARCH_FIELD_HEIGHT = 24.0f;
    public static final float SEARCH_FIELD_INSET = 6.0f;
    public static final float CAP_HEIGHT = 11.9f;
    public static final float ICON_SIZE = 13.0f;
    public static final float TEN_FONT_SIZE = 14.583333f;
    public static final int PANEL_TINT = -1004988385;
    public static final int PANEL_SHADOW = 0x66000000;
    public static final int SEPARATOR = 0x10FFFFFF;
    public static final int ROW_HOVER = 0x10FFFFFF;
    public static final int TEXT = -3553071;
    public static final int TEXT_HOVER = -1776662;
    public static final int TITLE = -723976;
    public static final int PLACEHOLDER = -7368810;
    public static final int MINUS = -7434347;
    public static final int SWITCH_OFF = 977945216;
    public static final int KNOB = -460547;
    public static final int SLIDER_TRACK = 0x16000000;
    public static final int FIELD_FILL = 0x47000000;
    public static final int FIELD_BORDER = 0xEFFFFFF;
    public static final int KEYBIND_FILL = 0x2E000000;
    public static final int KEYBIND_BORDER = 0x14FFFFFF;
    public static final int TOOLTIP_TINT = -535093718;
    public static final int TOOLTIP_TEXT = -1117959;
    private static final int GLASS_BLUE = -8864002;
    public static int ACCENT = -7750161;
    public static int SWITCH_ON = -8864002;
    public static int GLOW = 1433976574;
    public static int SLIDER_FILL = -8537872;
    public static int TEXT_ACTIVE = -6437650;
    public static int TEXT_ACTIVE_HOVER = -4926476;
    public static int VALUE = -6373664;
    public static int ICON = -5651484;
    private static int lastSource;

    private LastSource() {
    }

    public static void accent(int n) {
        int n2;
        if (n == lastSource) {
            return;
        }
        lastSource = n;
        float[] fArray = Color.RGBtoHSB(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF, null);
        SWITCH_ON = n2 = fArray[1] < 0.18f ? -8864002 : 0xFF000000 | Color.HSBtoRGB(fArray[0], Math.min(0.62f, Math.max(0.42f, fArray[1])), Math.max(0.92f, fArray[2]));
        ACCENT = LastSource.mix(n2, -1, 0.08f);
        GLOW = LastSource.withAlpha(n2, 0.33f);
        SLIDER_FILL = LastSource.mix(n2, -1, 0.04f);
        TEXT_ACTIVE = LastSource.mix(n2, -1, 0.28f);
        TEXT_ACTIVE_HOVER = LastSource.mix(n2, -1, 0.45f);
        VALUE = LastSource.mix(n2, -1, 0.32f);
        ICON = LastSource.mix(n2, -1, 0.4f);
    }

    public static int mix(int n, int n2, float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        int n3 = n >>> 24;
        int n4 = n >> 16 & 0xFF;
        int n5 = n >> 8 & 0xFF;
        int n6 = n & 0xFF;
        int n7 = n2 >>> 24;
        int n8 = n2 >> 16 & 0xFF;
        int n9 = n2 >> 8 & 0xFF;
        int n10 = n2 & 0xFF;
        return Math.round((float)n3 + (float)(n7 - n3) * f) << 24 | Math.round((float)n4 + (float)(n8 - n4) * f) << 16 | Math.round((float)n5 + (float)(n9 - n5) * f) << 8 | Math.round((float)n6 + (float)(n10 - n6) * f);
    }

    public static int withAlpha(int n, float f) {
        return Math.round((float)(n >>> 24) * Math.max(0.0f, Math.min(1.0f, f))) << 24 | n & 0xFFFFFF;
    }
}
