package kryzex.gui;

import kryzex.gui.MarkStore;

public interface RadarSource {
    public float yaw();

    public void scan(float var1, boolean var2, MarkStore var3);
}
