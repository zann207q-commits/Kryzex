package kryzex.gui;

public final class Initialized {
    private float value = 1.0f;
    private float velocity;
    private boolean initialized;

    public float update(float f, float f2) {
        if (!this.initialized) {
            this.initialized = true;
            this.value = f;
            return this.value;
        }
        float f3 = Math.max(0.0f, Math.min(0.1f, f2));
        float f4 = 18.0f;
        float f5 = this.value - f;
        float f6 = this.velocity + f4 * f5;
        float f7 = (float)Math.exp(-f4 * f3);
        this.value = f + (f5 + f6 * f3) * f7;
        this.velocity = (this.velocity - f4 * f6 * f3) * f7;
        if (!(Math.abs(this.value - f) < 1.0E-4f) || !(Math.abs(this.velocity) < 0.001f)) return this.value;
        this.value = f;
        this.velocity = 0.0f;
        return this.value;
    }
}
