package kryzex.gui;

import java.util.ArrayList;
import java.util.List;
import kryzex.gui.Tween;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;

public final class OfferedText {
    private static final float DELAY = 0.45f;
    private static final float MAX_TEXT_WIDTH = 295.0f;
    private static final float PAD_LEFT = 9.0f;
    private static final float PAD_RIGHT = 12.0f;
    private static final float FIRST_LINE = 14.0f;
    private static final float LINE = 19.5f;
    private Object key;
    private Object offeredKey;
    private String text;
    private String offeredText;
    private float hoverTime;
    private float fade;
    private List<String> lines = new ArrayList<String>();
    private String linesFor;
    private Object linesFont;

    public void offer(Object object, String string) {
        this.offeredKey = object;
        this.offeredText = string;
    }

    public void render(ListeningModule listeningModule) {
        if (this.offeredKey != null && this.offeredKey.equals(this.key)) {
            this.hoverTime += listeningModule.dt;
        } else {
            this.key = this.offeredKey;
            this.text = this.offeredText;
            this.hoverTime = 0.0f;
            this.fade = 0.0f;
        }
        this.offeredKey = null;
        boolean bl = this.key != null && this.hoverTime >= 0.45f && listeningModule.captured == null;
        float f = this.fade = bl ? Tween.approach(this.fade, 1.0f, 14.0f, listeningModule.dt) : 0.0f;
        if (this.fade <= 0.01f || this.text == null || this.text.isBlank()) return;
        SquareCorners squareCorners = listeningModule.painter;
        if (!this.text.equals(this.linesFor) || this.linesFont != squareCorners.atlasKey()) {
            this.lines = OfferedText.wrap(squareCorners, this.text, 295.0f);
            this.linesFor = this.text;
            this.linesFont = squareCorners.atlasKey();
        }
        float f2 = 0.0f;
        for (String string : this.lines) {
            f2 = Math.max(f2, squareCorners.textWidth(string));
        }
        float f3 = f2 + 9.0f + 12.0f;
        float f4 = 33.0f + (float)(this.lines.size() - 1) * 19.5f;
        float f5 = listeningModule.mouseX + 14.0f;
        float f6 = listeningModule.mouseY + 16.0f;
        if (f5 + f3 > listeningModule.width - 4.0f) {
            f5 = listeningModule.mouseX - 14.0f - f3;
        }
        if (f6 + f4 > listeningModule.height - 4.0f) {
            f6 = listeningModule.mouseY - 16.0f - f4;
        }
        f5 = Math.max(4.0f, f5);
        f6 = Math.max(4.0f, f6) + (1.0f - this.fade) * 3.0f;
        float f7 = squareCorners.alpha();
        squareCorners.alpha(this.fade);
        squareCorners.shadow(f5, f6 + 2.0f, f5 + f3, f6 + f4 + 2.0f, 6.0f, 8.0f, 0x55000000);
        squareCorners.glass(f5, f6, f5 + f3, f6 + f4, 6.0f, -535093718);
        float f8 = f6 + 14.0f;
        for (String string : this.lines) {
            squareCorners.text(string, f5 + 9.0f, f8, -1117959);
            f8 += 19.5f;
        }
        squareCorners.alpha(f7);
    }

    public static List<String> wrap(SquareCorners squareCorners, String string, float f) {
        ArrayList<String> arrayList = new ArrayList<String>();
        StringBuilder stringBuilder = new StringBuilder();
        for (String string2 : string.split(" ")) {
            String string3;
            String string4 = string3 = stringBuilder.isEmpty() ? string2 : String.valueOf(stringBuilder) + " " + string2;
            if (!stringBuilder.isEmpty() && squareCorners.textWidth(string3) > f) {
                arrayList.add(stringBuilder.toString());
                stringBuilder.setLength(0);
                stringBuilder.append(string2);
                continue;
            }
            stringBuilder.setLength(0);
            stringBuilder.append(string3);
        }
        if (stringBuilder.isEmpty()) return arrayList;
        arrayList.add(stringBuilder.toString());
        return arrayList;
    }
}
