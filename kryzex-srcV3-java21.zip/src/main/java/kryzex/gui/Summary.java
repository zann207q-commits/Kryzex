package kryzex.gui;

import kryzex.gui.GuiWidgets;
import kryzex.gui.LastSource;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.Setting;

final class Summary
extends LinesWidth {
    private String summary = "";

    Summary(Module module, Setting setting) {
        super(module, setting);
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return Math.min(squareCorners.textWidth(this.summary), 92.0f) + 12.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        String string = listeningModule.host.pickerSummary(this.module, this.setting);
        this.summary = string == null ? "" : string;
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        float f6 = f + f3 - 10.0f;
        float f7 = Math.min(listeningModule.painter.textWidth(this.summary), 92.0f);
        listeningModule.painter.text(this.summary, f6 - 9.0f - f7, f5, LastSource.mix(LastSource.VALUE, LastSource.TEXT_ACTIVE_HOVER, this.hover), 92.0f);
        GuiWidgets.chevron(listeningModule.painter, f6 - 1.5f, f5, 1.0f, LastSource.withAlpha(LastSource.VALUE, 0.55f + 0.45f * this.hover));
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0 || !listeningModule.host.openPicker(this.module, this.setting)) return true;
        listeningModule.host.sound("OPEN");
        return true;
    }
}
