package kryzex.gui;

import kryzex.gui.BaseRenderer;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiDrawer;
import kryzex.gui.HudActions;
import kryzex.module.settings.ListSetting;

public final class PhaseTime {
    private final HudActions host;
    private GuiDrawer original;

    public PhaseTime(HudActions hudActions) {
        this.host = hudActions;
    }

    private GuiDrawer current() {
        if (this.original == null) {
            this.original = new GuiDrawer(this.host);
        }
        return this.original;
    }

    public void onOpen(boolean bl) {
        this.current().onOpen(bl);
    }

    public void requestClose() {
        this.current().requestClose();
        GuiAudio.stopScroll();
    }

    public boolean isClosing() {
        return this.current().isClosing();
    }

    public float visibility() {
        return this.current().visibility();
    }

    public boolean isTyping() {
        return this.current().isTyping();
    }

    public void render(BaseRenderer baseRenderer, int n, int n2, double d, double d2, float f) {
        this.current().render(baseRenderer, n, n2, d, d2, f);
    }

    public boolean mouseClicked(double d, double d2, int n) {
        return this.current().mouseClicked(d, d2, n);
    }

    public void mouseReleased(double d, double d2, int n) {
        this.current().mouseReleased(d, d2, n);
    }

    public void mouseDragged(double d, double d2) {
        this.current().mouseDragged(d, d2);
    }

    public void mouseScrolled(double d, double d2, double d3) {
        this.current().mouseScrolled(d, d2, d3);
    }

    public boolean keyPressed(int n, int n2) {
        return this.current().keyPressed(n, n2);
    }

    public boolean charTyped(char c) {
        return this.current().charTyped(c);
    }

    public void openStorage(ListSetting listSetting) {
        this.current().openStorage(listSetting);
    }

    public Object layoutState() {
        return this.current();
    }
}
