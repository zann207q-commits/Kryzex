package kryzex.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;

final class ClampTexture
extends class_1043 {
    public ClampTexture(class_2960 class_29602, class_1011 class_10112) {
        super(() -> ((class_2960)class_29602).toString(), class_10112);
        this.field_63613 = RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
    }
}
