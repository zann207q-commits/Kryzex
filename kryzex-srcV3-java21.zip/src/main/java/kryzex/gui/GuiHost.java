package kryzex.gui;

import kryzex.module.Module;
import kryzex.module.settings.Setting;

public interface GuiHost {
    public String keyName(int var1);

    public boolean openPicker(Module var1, Setting var2);

    public String pickerSummary(Module var1, Setting var2);

    public void sound(String var1);

    public void toggle(Module var1);

    public void openHudEditor();

    default public void openConfigs() {
    }

    public void switchToOriginal();
}
