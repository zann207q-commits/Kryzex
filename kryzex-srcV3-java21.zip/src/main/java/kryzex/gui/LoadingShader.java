package kryzex.gui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.CompiledRenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.ShaderType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_10789;
import net.minecraft.class_12289;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public final class LoadingShader {
    private static final class_2960 SHADER = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/kryzex_loader");
    private static boolean logged;
    public static RenderPipeline LOADER;
    private static final String VSH = "#version 330\n\nlayout(std140) uniform DynamicTransforms {\n    mat4 ModelViewMat;\n    vec4 ColorModulator;\n    vec3 ModelOffset;\n    mat4 TextureMat;\n};\nlayout(std140) uniform Projection {\n    mat4 ProjMat;\n};\n\nin vec3 Position;\nin vec4 Color;\nin vec2 UV0;\nin ivec2 UV1;\nin ivec2 UV2;\nin vec3 Normal;\n\nout vec2 local;\nflat out vec4 tint;\nflat out float time;\nflat out ivec2 data;\nflat out int mode;\nflat out float amount;\nflat out vec2 halfSize;\nflat out float unit;\n\nvoid main() {\n\n    gl_Position = ProjMat * ModelViewMat * vec4(Position.xy, 0.0, 1.0);\n    local = UV0;\n    tint = Color;\n    time = Position.z;\n    data = UV1 & 0xFFFF;\n    mode = UV2.x & 15;\n    amount = float(UV2.y & 0xFFFF) / 32767.0;\n    float pad = float((UV2.x >> 4) & 4095);\n\n    halfSize = abs(UV0) - vec2(pad);\n    unit = max(Normal.x * 4.0, 0.25);\n}\n";
    private static final String FSH = "#version 330\n\nlayout(std140) uniform DynamicTransforms {\n    mat4 ModelViewMat;\n    vec4 ColorModulator;\n    vec3 ModelOffset;\n    mat4 TextureMat;\n};\n\nuniform sampler2D Sampler0;\n\nin vec2 local;\nflat in vec4 tint;\nflat in float time;\nflat in ivec2 data;\nflat in int mode;\nflat in float amount;\nflat in vec2 halfSize;\nflat in float unit;\n\nout vec4 fragColor;\n\nconst int MODE_BACKGROUND = 0;\nconst int MODE_LOGO = 1;\nconst int MODE_BAR = 2;\n\nvec3 rgb565(int c) {\n    return vec3(float((c >> 11) & 31) / 31.0, float((c >> 5) & 63) / 63.0, float(c & 31) / 31.0);\n}\n\nfloat hash(vec2 p) {\n    vec3 q = fract(vec3(p.xyx) * 0.1031);\n    q += dot(q, q.yzx + 33.33);\n    return fract((q.x + q.y) * q.z);\n}\n\n\nfloat dither() {\n    vec2 p = gl_FragCoord.xy + fract(time * 7.0) * 37.0;\n    return (hash(p) + hash(p + 17.31) - 1.0) / 255.0;\n}\n\nfloat roundBox(vec2 p, vec2 b, float r) {\n    r = min(r, min(b.x, b.y));\n    vec2 q = abs(p) - b + r;\n    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;\n}\n\nfloat coverage(float d) {\n    return clamp(0.5 - d / max(fwidth(d), 1e-4), 0.0, 1.0);\n}\n\nfloat glow(vec2 p, vec2 c, float radius) {\n    vec2 d = (p - c) / radius;\n    return exp(-dot(d, d));\n}\n\nvec4 background() {\n\n    vec2 p = vec2(local.x, -local.y) / (2.0 * halfSize.y);\n    vec3 top = rgb565(data.x);\n    vec3 bottom = rgb565(data.y);\n    vec3 accent = tint.rgb;\n    vec3 color = mix(bottom, top, smoothstep(-0.55, 0.6, p.y));\n\n    float breathe = 0.86 + 0.14 * sin(time * 1.25);\n    color += accent * 0.13 * breathe * glow(p, vec2(0.0, 0.07), 0.42);\n    color += accent * 0.045 * glow(p, vec2(0.0, 0.05), 0.95);\n\n    vec2 a = vec2(0.62 * sin(time * 0.115), 0.08 + 0.22 * cos(time * 0.137));\n    vec2 b = vec2(0.66 * cos(time * 0.093 + 1.7), -0.05 + 0.26 * sin(time * 0.121 + 0.4));\n    color += accent * 0.055 * glow(p, a, 0.36);\n    color += mix(accent, vec3(1.0), 0.45) * 0.035 * glow(p, b, 0.42);\n\n    float v = length(p * vec2(0.82, 1.18));\n    color *= mix(1.0, 0.58, smoothstep(0.35, 1.05, v));\n    color += dither();\n    float alpha = tint.a;\n    if (amount > 0.0) {\n\n        float reach = length(vec2(halfSize.x / (2.0 * halfSize.y), 0.5)) + 0.3;\n        float edge = amount * reach;\n        alpha *= smoothstep(edge - 0.3, edge, length(p));\n    }\n    return vec4(color, alpha);\n}\n\nvec4 logoTap(vec2 uv) {\n    vec4 c = texture(Sampler0, uv);\n    vec2 inside = step(vec2(0.0), uv) * step(uv, vec2(1.0));\n    c.a *= inside.x * inside.y;\n    return vec4(c.rgb * c.a, c.a);\n}\n\nvec4 logo() {\n    vec2 size = 2.0 * halfSize;\n    vec2 uv = local / size + 0.5;\n\n    vec2 dx = dFdx(uv);\n    vec2 dy = dFdy(uv);\n    vec4 sum = vec4(0.0);\n    for (int i = 0; i < 4; i++) {\n        for (int j = 0; j < 4; j++) {\n            vec2 o = (vec2(float(i), float(j)) - 1.5) * 0.25;\n            sum += logoTap(uv + dx * o.x + dy * o.y);\n        }\n    }\n    vec4 logo = sum / 16.0;\n\n    float spread = 7.0 * unit;\n    float bloom = 0.0;\n    for (int i = 0; i < 12; i++) {\n        float angle = float(i) * 0.5235988 + 0.26;\n        vec2 dir = vec2(cos(angle), sin(angle));\n        bloom += logoTap(uv + dir * spread / size).a;\n        bloom += logoTap(uv + dir * spread * 2.4 / size).a * 0.6;\n    }\n    bloom /= 19.2;\n    float breathe = 0.82 + 0.18 * sin(time * 1.25);\n    vec3 bloomColor = mix(tint.rgb, vec3(1.0), 0.2);\n    float bloomAlpha = bloom * 0.5 * breathe;\n\n    float cycle = mod(time + 0.6, 4.2);\n    float pos = mix(-0.25, 1.25, clamp(cycle / 1.1, 0.0, 1.0));\n    float band = exp(-pow((uv.x + (0.5 - uv.y) * 0.22 - pos) / 0.045, 2.0)) * step(cycle, 1.1);\n    vec3 color = logo.rgb + vec3(0.9) * band * 0.55 * logo.a;\n\n    vec3 outColor = color + bloomColor * bloomAlpha * (1.0 - logo.a);\n    float outAlpha = logo.a + bloomAlpha * (1.0 - logo.a);\n    if (outAlpha <= 0.0) {\n        return vec4(0.0);\n    }\n    return vec4(outColor / outAlpha, outAlpha * tint.a);\n}\n\nvec4 bar() {\n    float radius = halfSize.y;\n    float d = roundBox(local, halfSize, radius);\n    float track = coverage(d);\n    float from = float(data.x) / 32767.0;\n    float to = float(data.y) / 32767.0;\n    float x0 = mix(-halfSize.x, halfSize.x, from);\n    float x1 = mix(-halfSize.x, halfSize.x, to);\n    vec2 fillCentre = vec2((x0 + x1) * 0.5, 0.0);\n    vec2 fillHalf = vec2(max((x1 - x0) * 0.5, 0.0), halfSize.y);\n    float fd = roundBox(local - fillCentre, fillHalf, radius);\n    float present = step(0.0005, to - from);\n    float fill = coverage(fd) * present;\n    vec3 accent = tint.rgb;\n    float x01 = (local.x + halfSize.x) / (2.0 * halfSize.x);\n    vec3 deep = accent * 0.72;\n    vec3 bright = mix(accent, vec3(1.0), 0.38);\n    vec3 fillColor = mix(deep, bright, smoothstep(from - 0.05, to + 0.02, x01));\n\n    float shimmerPos = mix(from, to, fract(time * 0.62));\n    fillColor += vec3(0.45) * exp(-pow((x01 - shimmerPos) / 0.035, 2.0)) * amount;\n\n    float highlight = smoothstep(0.0, -halfSize.y, local.y) * 0.5;\n\n    float halo = exp(-max(fd, 0.0) / (5.5 * unit)) * 0.32 * present;\n    float head = exp(-dot(local - vec2(x1, 0.0), local - vec2(x1, 0.0)) / pow(9.0 * unit, 2.0)) * 0.55 * present;\n    vec4 color = vec4(vec3(1.0), (0.085 + 0.05 * highlight) * track);\n    float glowAlpha = clamp(halo + head, 0.0, 1.0) * (1.0 - track * 0.6);\n    color.rgb = mix(color.rgb, accent, glowAlpha / max(color.a + glowAlpha, 1e-4));\n    color.a = color.a + glowAlpha * (1.0 - color.a);\n    vec3 lit = fillColor + vec3(0.18) * highlight;\n    color.rgb = mix(color.rgb, lit, fill);\n    color.a = mix(color.a, 1.0, fill);\n    return vec4(color.rgb, color.a * tint.a);\n}\n\nvoid main() {\n    vec4 color;\n    if (mode == MODE_BACKGROUND) {\n        color = background();\n    } else if (mode == MODE_LOGO) {\n        color = logo();\n    } else {\n        color = bar();\n    }\n    if (color.a <= 0.0) {\n        discard;\n    }\n    fragColor = color * ColorModulator;\n}\n";
    public static class_12289 SOURCES;

    private LoadingShader() {
    }

    public static boolean ready() {
        try {
            CompiledRenderPipeline compiledRenderPipeline = RenderSystem.getDevice().precompilePipeline(LOADER, SOURCES);
            if (compiledRenderPipeline.isValid()) {
                return true;
            }
        }
        catch (Throwable throwable) {
            if (logged) return false;
            logged = true;
            System.err.println("Kryzex: loading screen shader failed: " + String.valueOf(throwable));
            return false;
        }
        if (logged) return false;
        logged = true;
        System.err.println("Kryzex: loading screen shader did not compile");
        return false;
    }

    private static String lmbd$static$0(class_2960 class_29602, ShaderType shaderType) {
        if (!SHADER.equals((Object)class_29602)) return null;
        if (shaderType != ShaderType.VERTEX) return FSH;
        return VSH;
    }

    static {
        LOADER = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/kryzex_loader")).withVertexShader(SHADER).withFragmentShader(SHADER).withUniform("DynamicTransforms", class_10789.field_60031).withUniform("Projection", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withVertexFormat(class_290.field_1580, VertexFormat.class_5596.field_27382).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
        SOURCES = LoadingShader::lmbd$static$0;
    }
}
