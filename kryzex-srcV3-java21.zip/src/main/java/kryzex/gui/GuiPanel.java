package kryzex.gui;

import kryzex.gui.BaseRenderer;
import kryzex.module.settings.ListSetting;

interface GuiPanel {
    public void onOpen(boolean var1);

    public void requestClose();

    public boolean isClosing();

    public float visibility();

    public boolean isTyping();

    public void render(BaseRenderer var1, int var2, int var3, double var4, double var6, float var8);

    public boolean mouseClicked(double var1, double var3, int var5);

    public void mouseReleased(double var1, double var3, int var5);

    public void mouseDragged(double var1, double var3);

    public void mouseScrolled(double var1, double var3, double var5);

    public boolean keyPressed(int var1, int var2);

    public boolean charTyped(char var1);

    public void openStorage(ListSetting var1);

    public void openStyleSettings();

    public void cancelInteractions();

    public boolean styleSettingsOpen();
}
