package kryzex.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import kryzex.cinematic.Ambience;
import kryzex.gui.Data;
import kryzex.gui.GuiSoundType;
import kryzex.gui.ModuleWAV;
import kryzex.gui.SoundBank;
import kryzex.modules.client.KryzexPlus;

public final class GuiAudio {
    static final int SR = 44100;
    private static final int BLOCK = 512;
    private static final Object LOCK = new Object();
    private static final ConcurrentLinkedQueue<float[]> QUEUE = new ConcurrentLinkedQueue();
    private static volatile float master = 1.0f;
    private static volatile boolean failed;
    public static volatile boolean muted;
    private static Thread thread;
    private static volatile float[][] bank;
    private static volatile long scrollUntil;
    private static volatile float scrollGain;
    private static AtomicInteger TAB_SEQUENCE;
    private static long lastSlide;
    private static volatile long written;
    private static volatile long played;
    private static volatile long playedAt;

    private GuiAudio() {
    }

    public static void play(GuiSoundType guiSoundType) {
        if (muted || failed) return;
        try {
            float f;
            if (!KryzexPlus.uiSounds.getValue()) {
                return;
            }
            if (guiSoundType == GuiSoundType.SLIDE) {
                long l = System.nanoTime();
                if (l - lastSlide < 45000000L) {
                    return;
                }
                lastSlide = l;
            }
            if (!((f = (float)(KryzexPlus.uiVolume.getValue() / 100.0) * master) > 0.001f)) return;
            if (QUEUE.size() >= 32) {
                return;
            }
            if (guiSoundType == GuiSoundType.TAB) {
                int n = Math.floorMod(TAB_SEQUENCE.getAndIncrement(), 3);
                guiSoundType = n == 0 ? GuiSoundType.TAB : (n == 1 ? GuiSoundType.TAB_2 : GuiSoundType.TAB_3);
            }
            QUEUE.add(new float[]{guiSoundType.ordinal(), f});
            GuiAudio.ensureRunning();
            return;
        }
        catch (Throwable throwable) {

        }
    }

    public static void scroll(boolean bl) {
        if (!bl) {
            return;
        }
        try {
            if (muted || failed || !KryzexPlus.uiSounds.getValue()) {
                scrollUntil = 0L;
                return;
            }
            scrollGain = (float)(KryzexPlus.uiVolume.getValue() / 100.0) * master;
            if (scrollGain <= 0.001f) {
                return;
            }
            scrollUntil = System.nanoTime() + 100000000L;
            GuiAudio.ensureRunning();
            return;
        }
        catch (Throwable throwable) {

        }
    }

    public static void stopScroll() {
        scrollUntil = 0L;
    }

    public static void setAmbience(boolean bl) {
    }

    public static void setMaster(float f) {
        master = Math.max(0.0f, Math.min(1.0f, f));
    }

    public static void wake() {
        GuiAudio.ensureRunning();
    }

    public static long heardFrame() {
        long l = played;
        long l2 = playedAt;
        if (l2 == 0L) {
            return 0L;
        }
        long l3 = l + (System.nanoTime() - l2) * 44100L / 1000000000L;
        return Math.min(l3, written);
    }

    private static void ensureRunning() {
        if (muted || failed) return;
        Object object = LOCK;
        synchronized (object) {
            if (thread != null) return;
            thread = new Thread(GuiAudio::run, "Kryzex Audio");
            thread.setDaemon(true);
            thread.setPriority(7);
            thread.start();
            return;
        }
    }

    private static void run() {
        SourceDataLine var0 = null;
        try {
            AudioFormat var1_1 = new AudioFormat(44100.0f, 16, 2, true, false);
            var0 = AudioSystem.getSourceDataLine(var1_1);
            var0.open(var1_1, 8192);
            var0.start();
            long var2_4 = GuiAudio.written;
            if (GuiAudio.bank == null) {
                GuiAudio.bank = SoundBank.bank();
            }
            ArrayList<Data> var4_6 = new ArrayList<Data>();
            float[] var5_7 = new float[1024];
            byte[] var6_8 = new byte[2048];
            long var7_9 = 0L;
            while (true) {
                float[] var9_10;
                if ((var9_10 = GuiAudio.QUEUE.poll()) != null) {
                    if (var4_6.size() >= 16) {
                        var4_6.remove(0);
                    }
                    var4_6.add(new Data(GuiAudio.bank[(int)var9_10[0]], var9_10[1]));
                    continue;
                }
                Arrays.fill(var5_7, 0.0f);
                for (int var10_11 = var4_6.size() - 1; var10_11 >= 0; --var10_11) {
                    if (!((Data)var4_6.get(var10_11)).mixInto(var5_7)) continue;
                    var4_6.remove(var10_11);
                }
                boolean var10_12 = ModuleWAV.mixScroll(var5_7, 512, GuiAudio.muted ? 0.0f : GuiAudio.scrollGain, !GuiAudio.muted && System.nanoTime() < GuiAudio.scrollUntil);
                Ambience.mix(var5_7, 512, GuiAudio.master, GuiAudio.written);
                for (int var11_12 = 0; var11_12 < var5_7.length; ++var11_12) {
                    float var12_14 = var5_7[var11_12];
                    var12_14 /= 1.0f + Math.abs(var12_14) * 0.25f;
                    int var13_16 = Math.round(Math.max(-1.0f, Math.min(1.0f, var12_14)) * 32767.0f);
                    var6_8[var11_12 * 2] = (byte)var13_16;
                    var6_8[var11_12 * 2 + 1] = (byte)(var13_16 >> 8);
                }
                var0.write(var6_8, 0, var6_8.length);
                GuiAudio.written += 512L;
                GuiAudio.played = var2_4 + var0.getLongFramePosition();
                GuiAudio.playedAt = System.nanoTime();
                if (!var4_6.isEmpty() || var10_12 || Ambience.active()) {
                    var7_9 = 0L;
                    continue;
                }
                if (var7_9 == 0L) {
                    var7_9 = System.nanoTime();
                    continue;
                }
                if (System.nanoTime() - var7_9 <= 4000000000L) continue;
                synchronized (GuiAudio.LOCK) {
                    if (GuiAudio.QUEUE.isEmpty() && !Ambience.active() && System.nanoTime() >= GuiAudio.scrollUntil) {
                        GuiAudio.thread = null;
                        return;
                    }
                }
                var7_9 = 0L;
            }
        }
        catch (Throwable var1_2) {
            GuiAudio.failed = true;
            System.err.println("Kryzex: audio output unavailable: " + String.valueOf(var1_2));
            Ambience.closeAll();
            synchronized (GuiAudio.LOCK) {
                GuiAudio.thread = null;
            }
            return;
        }
        finally {
            if (var0 != null) {
                try {
                    var0.drain();
                    var0.stop();
                    var0.close();
                }
                catch (Throwable var12_15) {}
            }
        }
    }

    public static float[] renderSfx(GuiSoundType guiSoundType) {
        if (bank != null) return bank[guiSoundType.ordinal()];
        bank = SoundBank.bank();
        return bank[guiSoundType.ordinal()];
    }

    static {
        TAB_SEQUENCE = new AtomicInteger();
    }
}
