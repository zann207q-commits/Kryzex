package kryzex.gui;

import java.io.IOException;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import kryzex.gui.Advance;
import kryzex.gui.Handle;
import kryzex.gui.ThemeStyle;
import kryzex.gui.FallbackFont;

final class Sansserif {
    private static Font akira;
    private static boolean failed;
    private static final Map<String, ThemeStyle> LINES;
    private static final Map<String, Advance> GLYPHS;

    private Sansserif() {
    }

    static Font font(float f) {
        Object object;
        if (akira == null && !failed) {
            try {
                object = Sansserif.class.getResourceAsStream("/assets/r87f4560b4c09f4/r83d2dcd48984c5/AkiraExpanded.otf");
                try {
                    akira = object == null ? null : Font.createFont(0, (InputStream)object);
                }
                finally {
                    if (object != null) {
                        try {
                            ((InputStream)object).close();
                        }
                        catch (IOException iOException) {

                        }
                    }
                }
            }
            catch (Throwable throwable) {
                akira = null;
            }
            if (akira == null) {
                failed = true;
            }
        }
        object = akira != null ? akira : FallbackFont.base(1);
        return object != null ? ((Font)object).deriveFont(f) : new Font("SansSerif", 1, Math.round(f));
    }

    private static Shape outline(String string, Font font, float f) {
        FontRenderContext fontRenderContext = new FontRenderContext(new AffineTransform(), true, true);
        GlyphVector glyphVector = font.createGlyphVector(fontRenderContext, string);
        if (f == 0.0f) return glyphVector.getOutline();
        for (int i = 0; i < glyphVector.getNumGlyphs(); ++i) {
            Point2D point2D = glyphVector.getGlyphPosition(i);
            glyphVector.setGlyphPosition(i, new Point2D.Double(point2D.getX() + (double)((float)i * f), point2D.getY()));
        }
        return glyphVector.getOutline();
    }

    private static Graphics2D g(BufferedImage bufferedImage) {
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        return graphics2D;
    }

    static ThemeStyle title(String string, int n, float f) {
        String string2 = string + "@" + n + "/" + f;
        ThemeStyle themeStyle = LINES.get(string2);
        if (themeStyle != null) {
            return themeStyle;
        }
        Font font = Sansserif.font(n);
        Shape shape = Sansserif.outline(string, font, (float)n * f);
        Rectangle2D rectangle2D = shape.getBounds2D();
        int n2 = Math.round((float)n * 0.6f);
        int n3 = (int)Math.ceil(rectangle2D.getWidth()) + n2 * 2;
        int n4 = (int)Math.ceil(rectangle2D.getHeight()) + n2 * 2;
        AffineTransform affineTransform = AffineTransform.getTranslateInstance((double)n2 - rectangle2D.getX(), (double)n2 - rectangle2D.getY());
        Shape shape2 = affineTransform.createTransformedShape(shape);
        float f2 = n2;
        float f3 = (float)n2 + (float)rectangle2D.getHeight();
        BufferedImage bufferedImage = new BufferedImage(n3, n4, 2);
        Graphics2D graphics2D = Sansserif.g(bufferedImage);
        graphics2D.setPaint(new LinearGradientPaint(0.0f, f2, 0.0f, f3, new float[]{0.0f, 0.42f, 0.78f, 1.0f}, new Color[]{new Color(255, 241, 214), new Color(255, 196, 112), new Color(244, 120, 38), new Color(196, 70, 22)}));
        graphics2D.fill(shape2);
        graphics2D.setClip(shape2);
        graphics2D.setPaint(new LinearGradientPaint(0.0f, f2, 0.0f, f2 + (f3 - f2) * 0.22f, new float[]{0.0f, 1.0f}, new Color[]{new Color(255, 255, 255, 90), new Color(255, 255, 255, 0)}));
        graphics2D.fillRect(0, 0, n3, n4);
        graphics2D.dispose();
        BufferedImage bufferedImage2 = new BufferedImage(n3, n4, 2);
        graphics2D = Sansserif.g(bufferedImage2);
        graphics2D.setColor(Color.WHITE);
        graphics2D.setStroke(new BasicStroke(Math.max(2.0f, (float)n * 0.075f), 1, 1));
        graphics2D.draw(shape2);
        graphics2D.fill(shape2);
        graphics2D.dispose();
        ThemeStyle themeStyle2 = new ThemeStyle();
        themeStyle2.fill = Sansserif.colour("hw_title_fill_" + string2.hashCode(), bufferedImage);
        themeStyle2.stroke = Sansserif.mask("hw_title_stroke_" + string2.hashCode(), bufferedImage2);
        themeStyle2.glow = Sansserif.glow("hw_title_glow_" + string2.hashCode(), bufferedImage2, Math.max(3, Math.round((float)n * 0.22f)), 1.7f);
        themeStyle2.pad = n2;
        themeStyle2.w = n3;
        themeStyle2.h = n4;
        LINES.put(string2, themeStyle2);
        return themeStyle2;
    }

    static Advance glyph(char c, int n) {
        String string = c + "@" + n;
        Advance advance = GLYPHS.get(string);
        if (advance != null) {
            return advance;
        }
        Font font = Sansserif.font(n);
        FontRenderContext fontRenderContext = new FontRenderContext(new AffineTransform(), true, true);
        GlyphVector glyphVector = font.createGlyphVector(fontRenderContext, String.valueOf(c));
        float f = glyphVector.getGlyphMetrics(0).getAdvance();
        int n2 = Math.max(2, Math.round((float)n * 0.3f));
        int n3 = Math.max(1, (int)Math.ceil(f) + n2 * 2);
        int n4 = Math.round((float)n * 1.0f) + n2 * 2;
        BufferedImage bufferedImage = new BufferedImage(n3, n4, 2);
        Graphics2D graphics2D = Sansserif.g(bufferedImage);
        graphics2D.setColor(Color.WHITE);
        graphics2D.fill(AffineTransform.getTranslateInstance(n2, (float)n2 + (float)n * 0.8f).createTransformedShape(glyphVector.getOutline()));
        graphics2D.dispose();
        Advance advance2 = new Advance();
        advance2.mask = Sansserif.mask("hw_glyph_" + c + "_" + n, bufferedImage);
        advance2.advance = f;
        advance2.pad = n2;
        GLYPHS.put(string, advance2);
        return advance2;
    }

    private static Handle colour(String string, BufferedImage bufferedImage) {
        int n = bufferedImage.getWidth();
        int n2 = bufferedImage.getHeight();
        return new Handle(string, n, n2, bufferedImage.getRGB(0, 0, n, n2, null, 0, n));
    }

    private static Handle mask(String string, BufferedImage bufferedImage) {
        int n = bufferedImage.getWidth();
        int n2 = bufferedImage.getHeight();
        int[] nArray = bufferedImage.getRGB(0, 0, n, n2, null, 0, n);
        for (int i = 0; i < nArray.length; ++i) {
            nArray[i] = nArray[i] & 0xFF000000 | 0xFFFFFF;
        }
        return new Handle(string, n, n2, nArray);
    }

    private static Handle glow(String string, BufferedImage bufferedImage, int n, float f) {
        int n2;
        int n3 = bufferedImage.getWidth();
        int n4 = bufferedImage.getHeight();
        int[] nArray = bufferedImage.getRGB(0, 0, n3, n4, null, 0, n3);
        float[] fArray = new float[n3 * n4];
        for (n2 = 0; n2 < fArray.length; ++n2) {
            fArray[n2] = (float)(nArray[n2] >>> 24) / 255.0f;
        }
        for (n2 = 0; n2 < 3; ++n2) {
            fArray = Sansserif.blur(fArray, n3, n4, n, true);
            fArray = Sansserif.blur(fArray, n3, n4, n, false);
        }
        for (n2 = 0; n2 < fArray.length; ++n2) {
            fArray[n2] = Math.min(1.0f, fArray[n2] * f);
        }
        return Handle.fromCoverage(string, n3, n4, fArray);
    }

    private static float[] blur(float[] fArray, int n, int n2, int n3, boolean bl) {
        float[] fArray2 = new float[fArray.length];
        int n4 = bl ? n : n2;
        int n5 = bl ? n2 : n;
        for (int i = 0; i < n5; ++i) {
            int n6;
            float f = 0.0f;
            for (n6 = -n3; n6 <= n3; ++n6) {
                f += Sansserif.at(fArray, n, bl, i, Math.max(0, Math.min(n4 - 1, n6)));
            }
            for (n6 = 0; n6 < n4; ++n6) {
                int n7 = bl ? i * n + n6 : n6 * n + i;
                fArray2[n7] = f / (float)(2 * n3 + 1);
                f += Sansserif.at(fArray, n, bl, i, Math.min(n4 - 1, n6 + n3 + 1)) - Sansserif.at(fArray, n, bl, i, Math.max(0, n6 - n3));
            }
        }
        return fArray2;
    }

    private static float at(float[] fArray, int n, boolean bl, int n2, int n3) {
        return bl ? fArray[n2 * n + n3] : fArray[n3 * n + n2];
    }

    static {
        LINES = new HashMap<String, ThemeStyle>();
        GLYPHS = new HashMap<String, Advance>();
    }
}
