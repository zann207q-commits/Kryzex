package kryzex.gui;

import java.io.IOException;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import kryzex.gui.AtlasHeight;
import kryzex.gui.CapHeight;
import kryzex.gui.ClampTexture;
import kryzex.gui.PixelUnit;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_12137;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class DropdownFont {
    static final char FIRST = ' ';
    static final int COUNT = 95;
    private static final int WIDTH = 512;
    private static final String TEN = "/assets/r87f4560b4c09f4/r83d2dcd48984c5/minecraft_ten.ttf";
    private static final String MONT = "/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Medium.ttf";
    private static final String MONT_BOLD = "/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Bold.ttf";
    private static final String PIXEL_FONT_SHEET = "/assets/minecraft/textures/font/ascii.png";
    private static final Map<Object, CompletableFuture<AtlasHeight>> PREPARED = new ConcurrentHashMap<Object, CompletableFuture<AtlasHeight>>();
    private static final Map<String, Font> FONTS = new ConcurrentHashMap<String, Font>();
    private static int nextId;
    public final PixelUnit spec;
    public final int iconSize;
    public final CapHeight title;
    public final CapHeight body;
    public final CapHeight pixel;
    final int atlasHeight;
    final Map<String, int[]> icons;
    private final class_2960 id;
    private final ClampTexture texture;

    public static void prepare(PixelUnit pixelUnit, Map<String, int[]> map) {
        PREPARED.computeIfAbsent(List.of(pixelUnit, Set.copyOf(map.keySet())), arg_0 -> DropdownFont.lmbd$prepare$0(pixelUnit, map, arg_0));
    }

    public static DropdownFont create(PixelUnit pixelUnit, Map<String, int[]> map) {
        CompletableFuture<AtlasHeight> completableFuture = PREPARED.remove(List.of(pixelUnit, Set.copyOf(map.keySet())));
        AtlasHeight atlasHeight = completableFuture != null ? completableFuture.join() : new AtlasHeight(pixelUnit, map);
        return new DropdownFont(atlasHeight);
    }

    private DropdownFont(AtlasHeight atlasHeight) {
        this.spec = atlasHeight.spec;
        this.iconSize = atlasHeight.spec.iconSize();
        this.title = atlasHeight.title;
        this.body = atlasHeight.body;
        this.pixel = atlasHeight.pixel;
        this.atlasHeight = atlasHeight.atlasHeight;
        this.icons = atlasHeight.icons;
        this.id = class_2960.method_60655((String)"r87f4560b4c09f4", (String)("dropdown_atlas/" + nextId++));
        class_1011 class_10112 = new class_1011(512, this.atlasHeight, true);
        int[] nArray = atlasHeight.argb;
        for (int i = 0; i < this.atlasHeight; ++i) {
            for (int j = 0; j < 512; ++j) {
                class_10112.method_61941(j, i, nArray[i * 512 + j]);
            }
        }
        this.texture = new ClampTexture(this.id, class_10112);
        class_310.method_1551().method_1531().method_4616(this.id, (class_1044)this.texture);
    }

    public GpuTextureView view() {
        return this.texture.method_71659();
    }

    public class_12137 sampler() {
        return this.texture.method_75484();
    }

    public float uScale() {
        return 0.001953125f;
    }

    public float vScale() {
        return 1.0f / (float)this.atlasHeight;
    }

    public void close() {
        class_310.method_1551().method_1531().method_4615(this.id);
    }

    static Font font(String string) {
        return FONTS.computeIfAbsent(string, DropdownFont::lmbd$font$0);
    }

    public static Graphics2D hinted(Graphics2D graphics2D) {
        graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        return graphics2D;
    }

    private static Font lmbd$font$0(String string) {
        Font font;
        InputStream inputStream = DropdownFont.class.getResourceAsStream(string);
        try {
            if (inputStream == null) {
                throw new IllegalStateException("missing " + string);
            }
            font = Font.createFont(0, inputStream);
            if (inputStream == null) return font;
        }
        catch (Throwable throwable) {
            try {
                if (inputStream == null) throw throwable;
                try {
                    inputStream.close();
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
            catch (Exception exception) {
                System.err.println("Kryzex: dropdown font unavailable: " + String.valueOf(exception));
                return new Font("SansSerif", 0, 12);
            }
        }
        try {
            inputStream.close();
        }
        catch (IOException iOException) {

        }
        return font;
    }

    private static CompletableFuture lmbd$prepare$0(PixelUnit pixelUnit, Map map, Object object) {
        return CompletableFuture.supplyAsync(() -> DropdownFont.lmbd$prepare$1(pixelUnit, map));
    }

    private static AtlasHeight lmbd$prepare$1(PixelUnit pixelUnit, Map map) {
        return new AtlasHeight(pixelUnit, map);
    }
}
