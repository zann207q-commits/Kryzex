package kryzex.gui;

class Action2 {
    public final float x0;
    public final float y0;
    public final float x1;
    public final float y1;
    public final Runnable action;

    public Action2(float x0, float y0, float x1, float y1, Runnable action) {
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        this.action = action;
    }

    public float x0() {
        return this.x0;
    }

    public float y0() {
        return this.y0;
    }

    public float x1() {
        return this.x1;
    }

    public float y1() {
        return this.y1;
    }

    public Runnable action() {
        return this.action;
    }
}
