package kryzex.gui;

import java.util.List;
import kryzex.module.Module;

public final class ModuleSorter {
    private ModuleSorter() {
    }

    public static List<Module> newFirst(List<Module> list) {
        return list;
    }
}
