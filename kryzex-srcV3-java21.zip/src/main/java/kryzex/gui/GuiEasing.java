package kryzex.gui;

final class GuiEasing {
    private GuiEasing() {
    }

    static float outCubic(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        float f2 = 1.0f - f;
        return 1.0f - f2 * f2 * f2;
    }

    static float smooth(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * (3.0f - 2.0f * f);
    }
}
