package kryzex.gui;

import java.util.HashMap;
import java.util.Map;
import kryzex.gui.Handle;

final class ShapeCache {
    private static final int SS = 6;
    private static final Map<String, Handle> CACHE = new HashMap<String, Handle>();

    private ShapeCache() {
    }

    static Handle circle(int n) {
        return CACHE.computeIfAbsent("c" + n, arg_0 -> ShapeCache.lmbd$circle$0(n, arg_0));
    }

    static Handle ring(int n, float f) {
        return CACHE.computeIfAbsent("r" + n + "_" + f, arg_0 -> ShapeCache.lmbd$ring$0(n, f, arg_0));
    }

    static Handle shadow(int n, int n2) {
        return CACHE.computeIfAbsent("s" + n + "_" + n2, arg_0 -> ShapeCache.lmbd$shadow$0(n, n2, arg_0));
    }

    static Handle radial() {
        return CACHE.computeIfAbsent("radial", ShapeCache::lmbd$radial$0);
    }

    private static float discCoverage(int n, int n2, double d, double d2, double d3) {
        if (d3 <= 0.0) {
            return 0.0f;
        }
        double d4 = d3 * d3;
        int n3 = 0;
        for (int i = 0; i < 6; ++i) {
            for (int j = 0; j < 6; ++j) {
                double d5 = (double)n + ((double)j + 0.5) / 6.0 - d;
                double d6 = (double)n2 + ((double)i + 0.5) / 6.0 - d2;
                if (!(d5 * d5 + d6 * d6 <= d4)) continue;
                ++n3;
            }
        }
        return (float)n3 / 36.0f;
    }

    private static Handle lmbd$radial$0(String string) {
        int n = 128;
        float[] fArray = new float[n * n];
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                double d = ((double)j + 0.5 - 64.0) / 64.0;
                double d2 = ((double)i + 0.5 - 64.0) / 64.0;
                double d3 = Math.sqrt(d * d + d2 * d2);
                double d4 = Math.exp(-d3 * d3 * 4.2);
                double d5 = Math.min(1.0, Math.max(0.0, (1.0 - d3) / 0.25));
                fArray[i * n + j] = (float)(d4 * d5 * d5);
            }
        }
        return Handle.fromCoverage(string, n, n, fArray);
    }

    private static Handle lmbd$shadow$0(int n, int n2, String string) {
        int n3 = n + n2;
        int n4 = n3 * 2;
        float[] fArray = new float[n4 * n4];
        for (int i = 0; i < n4; ++i) {
            for (int j = 0; j < n4; ++j) {
                float f;
                double d = (double)j + 0.5 - (double)n3;
                double d2 = (double)i + 0.5 - (double)n3;
                double d3 = Math.sqrt(d * d + d2 * d2) - (double)n;
                if (d3 < -1.0) {
                    f = 0.0f;
                } else {
                    double d4 = Math.pow(Math.max(0.0, 1.0 - Math.max(0.0, d3) / (double)n2), 2.6);
                    f = (float)(d4 * Math.min(1.0, d3 + 1.0));
                }
                fArray[i * n4 + j] = f;
            }
        }
        return Handle.fromCoverage(string, n4, n4, fArray);
    }

    private static Handle lmbd$ring$0(int n, float f, String string) {
        int n2 = n * 2;
        float[] fArray = new float[n2 * n2];
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n2; ++j) {
                fArray[i * n2 + j] = Math.max(0.0f, ShapeCache.discCoverage(j, i, n, n, n) - ShapeCache.discCoverage(j, i, n, n, (float)n - f));
            }
        }
        return Handle.fromCoverage(string, n2, n2, fArray);
    }

    private static Handle lmbd$circle$0(int n, String string) {
        int n2 = n * 2;
        float[] fArray = new float[n2 * n2];
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n2; ++j) {
                fArray[i * n2 + j] = ShapeCache.discCoverage(j, i, n, n, n);
            }
        }
        return Handle.fromCoverage(string, n2, n2, fArray);
    }
}
