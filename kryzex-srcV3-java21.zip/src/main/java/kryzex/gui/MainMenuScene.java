package kryzex.gui;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import kryzex.gui.KryzexMenuVideo;
import kryzex.gui.UtilityIcons;
import kryzex.gui.Rect;
import kryzex.util.EffectPipelines;
import kryzex.util.GaussianKernel;
import net.minecraft.class_1043;
import net.minecraft.class_10789;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import org.lwjgl.BufferUtils;

public final class MainMenuScene {
    public static final int UNIFORM_BYTES = 592;
    private static final RenderPipeline SCENE = MainMenuScene.base("menu_scene").withUniform("MenuData", class_10789.field_60031).build();
    private static final RenderPipeline GLASS = MainMenuScene.base("menu_glass").withSampler("GlassSampler").withUniform("MenuData", class_10789.field_60031).build();
    private static final RenderPipeline BACKDROP = MainMenuScene.base("menu_backdrop").withSampler("GlassSampler").withUniform("MenuData", class_10789.field_60031).build();
    private static final float[] EMPTY = new float[14];
    private static final RenderPipeline BLUR = MainMenuScene.base("storage_bloom_blur").withUniform("BlurData", class_10789.field_60031).build();
    private static class_6367 scene;
    private static class_6367 horizontal;
    private static class_6367 vertical;
    private static GpuBuffer menuBuffer;
    private static GpuBuffer horizontalBuffer;
    private static GpuBuffer verticalBuffer;
    private static ByteBuffer menuData;
    private static ByteBuffer blurData;
    private static boolean ready;
    private static boolean failed;

    private MainMenuScene() {
    }

    private static RenderPipeline.Builder base(String string) {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)("pipeline/main_menu_" + string))).withVertexShader(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/fx_fullscreen")).withFragmentShader(class_2960.method_60655((String)"r87f4560b4c09f4", (String)("core/" + string))).withSampler("InSampler").withoutBlend().withCull(false).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379);
    }

    private static void prepare(int n, int n2) {
        if (!ready) {
            if (!(EffectPipelines.compiled(SCENE) && EffectPipelines.compiled(GLASS) && EffectPipelines.compiled(BACKDROP) && EffectPipelines.compiled(BLUR))) {
                throw new IllegalStateException("Menu shader compilation failed");
            }
            ready = true;
        }
        if (scene == null) {
            scene = new class_6367("Kryzex menu scene", n, n2, false);
            horizontal = new class_6367("Kryzex menu glass horizontal", n, n2, false);
            vertical = new class_6367("Kryzex menu glass vertical", n, n2, false);
            int n3 = 136;
            menuBuffer = RenderSystem.getDevice().createBuffer(MainMenuScene::lmbd$prepare$0, n3, 592L);
            horizontalBuffer = RenderSystem.getDevice().createBuffer(MainMenuScene::lmbd$prepare$1, n3, 144L);
            verticalBuffer = RenderSystem.getDevice().createBuffer(MainMenuScene::lmbd$prepare$2, n3, 144L);
            menuData = BufferUtils.createByteBuffer(592);
            blurData = BufferUtils.createByteBuffer(144);
            GaussianKernel.write(blurData, 24);
            return;
        } else {
            if (MainMenuScene.scene.field_1482 == n && MainMenuScene.scene.field_1481 == n2) return;
            scene.method_1234(n, n2);
            horizontal.method_1234(n, n2);
            vertical.method_1234(n, n2);
        }
    }

    public static void fill(ByteBuffer byteBuffer, UtilityIcons utilityIcons, int n, int n2, float f, float f2, float f3, float f4, int n3, int n4, float[] fArray, float[] fArray2) {
        byteBuffer.putFloat(0, n).putFloat(4, n2).putFloat(8, f).putFloat(12, f2);
        byteBuffer.putFloat(16, n3).putFloat(20, n4).putFloat(24, f3).putFloat(28, f4);
        byteBuffer.putFloat(32, 17.0f).putFloat(36, 0.0f).putFloat(40, 0.0f).putFloat(44, 0.0f);
        for (int i = 0; i < 17; ++i) {
            Rect m62 = utilityIcons.shape(i);
            int n5 = 48 + i * 16;
            byteBuffer.putFloat(n5, m62.x()).putFloat(n5 + 4, m62.y()).putFloat(n5 + 8, m62.w()).putFloat(n5 + 12, m62.h());
            int n6 = i >= 1 && i <= 6 ? i - 1 : (i >= 9 ? 6 + i - 9 : -1);
            n5 = 320 + i * 16;
            byteBuffer.putFloat(n5, n6 >= 0 && n6 < fArray.length ? fArray[n6] : 0.0f).putFloat(n5 + 4, n6 >= 0 && n6 < fArray2.length ? fArray2[n6] : 0.0f).putFloat(n5 + 8, utilityIcons.corner(i)).putFloat(n5 + 12, i == 0 || i == 7 ? 0.0f : (i >= 9 ? (float)(2 + utilityIcons.utilityIcons[i - 9]) : 1.0f));
        }
    }

    public static boolean render(UtilityIcons utilityIcons, int n, int n2, float f, float f2, float f3, float f4, float[] fArray, float[] fArray2) {
        return MainMenuScene.renderInternal(utilityIcons, n, n2, f, f2, f3, f4, fArray, fArray2, false);
    }

    public static boolean backdrop(int n, int n2, float f) {
        return MainMenuScene.renderInternal(new UtilityIcons(n, n2, 1.0f), n, n2, f, 1.0f, 0.0f, 0.0f, EMPTY, EMPTY, true);
    }

    private static boolean renderInternal(UtilityIcons utilityIcons, int n, int n2, float f, float f2, float f3, float f4, float[] fArray, float[] fArray2, boolean bl) {
        if (failed) {
            return false;
        }
        try {
            class_310 class_3102 = class_310.method_1551();
            class_1043 class_10432 = KryzexMenuVideo.texture();
            int n3 = Math.max(1, (n + 1) / 2);
            int n4 = Math.max(1, (n2 + 1) / 2);
            MainMenuScene.prepare(n3, n4);
            MainMenuScene.fill(menuData, utilityIcons, n, n2, f, f2, f3, f4, class_10432.method_4525().method_4307(), class_10432.method_4525().method_4323(), fArray, fArray2);
            CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
            commandEncoder.writeToBuffer(menuBuffer.slice(), menuData);
            EffectPipelines.draw(commandEncoder, SCENE, scene.method_71639(), class_10432.method_71659(), "MenuData", menuBuffer.slice());
            blurData.putFloat(0, 1.0f / (float)n3).putFloat(4, 0.0f);
            commandEncoder.writeToBuffer(horizontalBuffer.slice(), blurData);
            blurData.putFloat(0, 0.0f).putFloat(4, 1.0f / (float)n4);
            commandEncoder.writeToBuffer(verticalBuffer.slice(), blurData);
            EffectPipelines.draw(commandEncoder, BLUR, horizontal.method_71639(), scene.method_71639(), "BlurData", horizontalBuffer.slice());
            EffectPipelines.draw(commandEncoder, BLUR, vertical.method_71639(), horizontal.method_71639(), "BlurData", verticalBuffer.slice());
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_3102.method_1522().method_71639();
            try (RenderPass renderPass = commandEncoder.createRenderPass(MainMenuScene::lmbd$renderInternal$0, gpuTextureView, OptionalInt.empty());){
                renderPass.setPipeline(bl ? BACKDROP : GLASS);
                renderPass.setUniform("MenuData", menuBuffer.slice());
                renderPass.bindTexture("InSampler", class_10432.method_71659(), RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
                renderPass.bindTexture("GlassSampler", vertical.method_71639(), RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
                renderPass.draw(0, 3);
                return true;
            }
        }
        catch (RuntimeException runtimeException) {
            MainMenuScene.release();
            failed = true;
            System.err.println("Kryzex menu glass: " + runtimeException.getClass().getSimpleName() + ": " + runtimeException.getMessage());
            return false;
        }
    }

    public static void release() {
        if (scene != null) {
            scene.method_1238();
        }
        if (horizontal != null) {
            horizontal.method_1238();
        }
        if (vertical != null) {
            vertical.method_1238();
        }
        if (menuBuffer != null) {
            menuBuffer.close();
        }
        if (horizontalBuffer != null) {
            horizontalBuffer.close();
        }
        if (verticalBuffer != null) {
            verticalBuffer.close();
        }
        vertical = null;
        horizontal = null;
        scene = null;
        verticalBuffer = null;
        horizontalBuffer = null;
        menuBuffer = null;
        blurData = null;
        menuData = null;
        failed = false;
        ready = false;
    }

    private static String lmbd$renderInternal$0() {
        return "Kryzex liquid glass menu";
    }

    private static String lmbd$prepare$2() {
        return "Kryzex menu blur vertical";
    }

    private static String lmbd$prepare$1() {
        return "Kryzex menu blur horizontal";
    }

    private static String lmbd$prepare$0() {
        return "Kryzex menu layout";
    }
}
