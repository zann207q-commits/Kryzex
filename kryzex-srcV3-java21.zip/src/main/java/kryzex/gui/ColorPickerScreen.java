package kryzex.gui;

import java.awt.Color;
import java.util.Locale;
import kryzex.gui.KeybindScreen;
import kryzex.module.settings.ToggleEntry;
import kryzex.util.FontRenderer;
import kryzex.util.InverseProjectionScratch;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_10799;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public final class ColorPickerScreen
extends class_437 {
    private static final int WIDTH = 275;
    private static final int HEIGHT = 425;
    private static final int TEXTURE_SIZE = 128;
    private static final class_2960 SQUARE_TEXTURE_ID = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"runtime/storage_color_square");
    private static final class_2960 HUE_TEXTURE_ID = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"runtime/storage_color_hue");
    private static class_1043 squareTexture;
    private static class_1043 hueTexture;
    private static float uploadedHue;
    private final class_437 parent;
    private final ToggleEntry entry;
    private final Color original;
    private float hue;
    private float saturation;
    private float brightness;
    private boolean draggingSquare;
    private boolean draggingHue;
    private boolean editingHex;
    private boolean selectAllHex;
    private String hexValue;

    public ColorPickerScreen(KeybindScreen keybindScreen, ToggleEntry toggleEntry) {
        this((class_437)keybindScreen, toggleEntry);
    }

    public ColorPickerScreen(class_437 class_4372, ToggleEntry toggleEntry) {
        super((class_2561)class_2561.method_43473());
        this.parent = class_4372;
        this.entry = toggleEntry;
        this.original = toggleEntry.color();
        float[] fArray = Color.RGBtoHSB(this.original.getRed(), this.original.getGreen(), this.original.getBlue(), null);
        this.hue = fArray[0];
        this.saturation = fArray[1];
        this.brightness = fArray[2];
        this.hexValue = ColorPickerScreen.toHex(this.original);
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        int n3;
        InverseProjectionScratch.setContext(class_3322);
        InverseProjectionScratch.unscaledProjection();
        int n4 = class_310.method_1551().method_22683().method_4480();
        int n5 = class_310.method_1551().method_22683().method_4507();
        class_3322.method_25294(0, 0, n4, n5, new Color(0, 0, 0, 70).getRGB());
        int n6 = (n4 - 275) / 2;
        int n7 = (n5 - 425) / 2;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(31, 31, 38, 250), n6, n7, n6 + 275, n7 + 425, 9.0, 9.0, 9.0, 9.0, 20.0);
        FontRenderer.drawCenteredString("COLOR: " + this.entry.displayName().toUpperCase(Locale.ROOT), class_3322, n6 + 137, n7 + 10, Color.WHITE.getRGB());
        int n8 = n6 + 20;
        int n9 = n7 + 44;
        int n10 = 200;
        this.ensureTextures();
        class_3322.method_25293(class_10799.field_56883, SQUARE_TEXTURE_ID, n8, n9, 0.0f, 0.0f, n10, n10, 128, 128, 128, 128, -1);
        int n11 = n8 + Math.round(this.saturation * (float)n10);
        int n12 = n9 + Math.round((1.0f - this.brightness) * (float)n10);
        InverseProjectionScratch.renderCircle(class_3322.method_51448(), Color.BLACK, n11, n12, 6.0, 18);
        InverseProjectionScratch.renderCircle(class_3322.method_51448(), Color.WHITE, n11, n12, 4.0, 18);
        int n13 = n8 + n10 + 14;
        class_3322.method_25293(class_10799.field_56883, HUE_TEXTURE_ID, n13, n9, 0.0f, 0.0f, 20, n10, 1, 128, 1, 128, -1);
        int n14 = n9 + Math.round(this.hue * (float)n10);
        class_3322.method_25294(n13 - 2, n14 - 2, n13 + 22, n14 + 2, Color.WHITE.getRGB());
        class_3322.method_25294(n13 - 1, n14 - 1, n13 + 21, n14 + 1, Color.BLACK.getRGB());
        Color color = this.chosenColor();
        int n15 = n7 + 258;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), this.original, n8, n15, n8 + 110, n15 + 30, 4.0, 4.0, 4.0, 4.0, 20.0);
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), color, n8 + 125, n15, n8 + 235, n15 + 30, 4.0, 4.0, 4.0, 4.0, 20.0);
        FontRenderer.drawCenteredString("ORIGINAL", class_3322, n8 + 55, n15 + 38, new Color(160, 160, 165).getRGB());
        FontRenderer.drawCenteredString("NEW", class_3322, n8 + 180, n15 + 38, new Color(160, 160, 165).getRGB());
        int n16 = n7 + 318;
        int n17 = n6 + 65;
        boolean bl = ColorPickerScreen.isValidHex(this.hexValue);
        FontRenderer.drawString("HEX", class_3322, n6 + 20, n16 + 8, new Color(190, 190, 198).getRGB());
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(18, 18, 23), n17, n16, n6 + 275 - 20, n16 + 30, 5.0, 5.0, 5.0, 5.0, 20.0);
        InverseProjectionScratch.renderRoundedOutline(class_3322, !bl ? new Color(255, 95, 95) : (this.editingHex ? new Color(120, 190, 255) : new Color(65, 65, 72)), n17, n16, n6 + 275 - 20, n16 + 30, 5.0, 5.0, 5.0, 5.0, 1.0, 20.0);
        int n18 = bl ? new Color(235, 235, 240).getRGB() : new Color(255, 105, 105).getRGB();
        int n19 = FontRenderer.getWidth(this.hexValue);
        if (this.editingHex && this.selectAllHex && !this.hexValue.isEmpty()) {
            class_3322.method_25294(n17 + 8, n16 + 5, n17 + 12 + n19, n16 + 24, new Color(65, 125, 190, 120).getRGB());
        }
        FontRenderer.drawString(this.hexValue, class_3322, n17 + 10, n16 + 8, n18);
        if (this.editingHex && System.currentTimeMillis() % 1000L < 500L) {
            n3 = n17 + 10 + n19;
            class_3322.method_25294(n3, n16 + 6, n3 + 1, n16 + 23, Color.WHITE.getRGB());
        }
        n3 = n7 + 425 - 45;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(38, 38, 44), n6 + 107, n3, n6 + 177, n3 + 30, 5.0, 5.0, 5.0, 5.0, 20.0);
        FontRenderer.drawCenteredString("CANCEL", class_3322, n6 + 142, n3 + 8, new Color(255, 105, 105).getRGB());
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(38, 38, 44), n6 + 186, n3, n6 + 256, n3 + 30, 5.0, 5.0, 5.0, 5.0, 20.0);
        FontRenderer.drawCenteredString("OK", class_3322, n6 + 221, n3 + 8, new Color(120, 190, 255).getRGB());
        InverseProjectionScratch.scaledProjection();
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (n != 0) {
            return false;
        }
        int n2 = ColorPickerScreen.physical(d);
        int n3 = ColorPickerScreen.physical(d2);
        int n4 = class_310.method_1551().method_22683().method_4480();
        int n5 = class_310.method_1551().method_22683().method_4507();
        int n6 = (n4 - 275) / 2;
        int n7 = (n5 - 425) / 2;
        int n8 = n6 + 20;
        int n9 = n7 + 44;
        int n10 = n6 + 65;
        int n11 = n7 + 318;
        if (ColorPickerScreen.inside(n2, n3, n10, n11, 190, 30)) {
            this.editingHex = true;
            this.selectAllHex = true;
            return true;
        }
        this.editingHex = false;
        this.selectAllHex = false;
        if (ColorPickerScreen.inside(n2, n3, n8, n9, 200, 200)) {
            this.draggingSquare = true;
            this.updateSquare(n2, n3, n8, n9);
            return true;
        }
        if (ColorPickerScreen.inside(n2, n3, n8 + 214, n9, 20, 200)) {
            this.draggingHue = true;
            this.updateHue(n3, n9);
            return true;
        }
        int n12 = n7 + 425 - 45;
        if (ColorPickerScreen.inside(n2, n3, n6 + 107, n12, 70, 30)) {
            class_310.method_1551().method_1507(this.parent);
            return true;
        }
        if (!ColorPickerScreen.inside(n2, n3, n6 + 186, n12, 70, 30)) return false;
        Color color = ColorPickerScreen.parseHex(this.hexValue);
        if (color == null) {
            this.editingHex = true;
            return true;
        }
        this.entry.setColor(color);
        class_310.method_1551().method_1507(this.parent);
        return true;
    }

    public boolean mouseDragged(double d, double d2, int n, double d3, double d4) {
        int n2 = ColorPickerScreen.physical(d);
        int n3 = ColorPickerScreen.physical(d2);
        int n4 = (class_310.method_1551().method_22683().method_4480() - 275) / 2;
        int n5 = (class_310.method_1551().method_22683().method_4507() - 425) / 2;
        if (this.draggingSquare) {
            this.updateSquare(n2, n3, n4 + 20, n5 + 44);
            return true;
        }
        if (!this.draggingHue) return false;
        this.updateHue(n3, n5 + 44);
        return true;
    }

    public boolean mouseReleased(double d, double d2, int n) {
        this.draggingSquare = false;
        this.draggingHue = false;
        return true;
    }

    public boolean keyPressed(int n, int n2, int n3) {
        if (n == 256) {
            class_310.method_1551().method_1507(this.parent);
            return true;
        }
        if (!this.editingHex) {
            return false;
        }
        if (n == 65 && ColorPickerScreen.hasControlDown()) {
            this.selectAllHex = true;
            return true;
        }
        if (n == 67 && ColorPickerScreen.hasControlDown()) {
            GLFW.glfwSetClipboardString((long)class_310.method_1551().method_22683().method_4490(), (CharSequence)this.hexValue);
            return true;
        }
        if (n == 88 && ColorPickerScreen.hasControlDown()) {
            GLFW.glfwSetClipboardString((long)class_310.method_1551().method_22683().method_4490(), (CharSequence)this.hexValue);
            this.hexValue = "";
            this.selectAllHex = false;
            return true;
        }
        if (n == 259 && this.selectAllHex) {
            this.hexValue = "";
            this.selectAllHex = false;
            return true;
        }
        if (n == 259 && !this.hexValue.isEmpty()) {
            this.hexValue = this.hexValue.substring(0, this.hexValue.length() - 1);
            this.applyHexIfValid();
            return true;
        }
        if (n == 86 && ColorPickerScreen.hasControlDown()) {
            String string = class_310.method_1551().field_1774.method_1460().trim();
            if (!string.matches("(?i)#?[0-9a-f]{6}")) return true;
            this.hexValue = ((String)(string.startsWith("#") ? string : "#" + string)).toUpperCase(Locale.ROOT);
            this.selectAllHex = false;
            this.applyHexIfValid();
            return true;
        }
        if (n != 257) return false;
        this.applyHexIfValid();
        this.editingHex = false;
        this.selectAllHex = false;
        return true;
    }

    public boolean charTyped(char c, int n) {
        if (!this.editingHex) {
            return false;
        }
        if (this.selectAllHex) {
            this.hexValue = "";
            this.selectAllHex = false;
        }
        if (c == '#' && this.hexValue.isEmpty()) {
            this.hexValue = "#";
        } else if (Character.digit(c, 16) >= 0 && this.hexValue.length() < 7) {
            if (this.hexValue.isEmpty()) {
                this.hexValue = "#";
            }
            this.hexValue = this.hexValue + Character.toUpperCase(c);
        }
        this.applyHexIfValid();
        return true;
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        return this.mouseClicked(class_119092.comp_4798(), class_119092.comp_4799(), class_119092.method_74245());
    }

    public boolean method_25403(class_11909 class_119092, double d, double d2) {
        return this.mouseDragged(class_119092.comp_4798(), class_119092.comp_4799(), class_119092.method_74245(), d, d2);
    }

    public boolean method_25406(class_11909 class_119092) {
        return this.mouseReleased(class_119092.comp_4798(), class_119092.comp_4799(), class_119092.method_74245());
    }

    public boolean method_25404(class_11908 class_119082) {
        return this.keyPressed(class_119082.comp_4795(), class_119082.comp_4796(), class_119082.comp_4797());
    }

    public boolean method_25400(class_11905 class_119052) {
        if (!class_119052.method_74227()) return false;
        if (!this.charTyped((char)class_119052.comp_4793(), class_119052.comp_4794())) return false;
        return true;
    }

    public void method_25420(class_332 class_3322, int n, int n2, float f) {
    }

    public boolean method_25422() {
        return false;
    }

    public boolean method_25421() {
        return false;
    }

    private void updateSquare(int n, int n2, int n3, int n4) {
        this.saturation = ColorPickerScreen.clamp((float)(n - n3) / 200.0f);
        this.brightness = 1.0f - ColorPickerScreen.clamp((float)(n2 - n4) / 200.0f);
        this.selectAllHex = false;
        this.hexValue = ColorPickerScreen.toHex(this.chosenColor());
    }

    private void updateHue(int n, int n2) {
        this.hue = ColorPickerScreen.clamp((float)(n - n2) / 200.0f);
        this.selectAllHex = false;
        this.hexValue = ColorPickerScreen.toHex(this.chosenColor());
    }

    private void ensureTextures() {
        class_1011 class_10112;
        class_310 class_3102 = class_310.method_1551();
        if (hueTexture == null) {
            class_10112 = new class_1011(1, 128, false);
            for (int i = 0; i < 128; ++i) {
                class_10112.method_61941(0, i, 0xFF000000 | Color.HSBtoRGB((float)i / 127.0f, 1.0f, 1.0f) & 0xFFFFFF);
            }
            hueTexture = new class_1043(ColorPickerScreen::lmbd$ensureTextures$0, class_10112);
            class_3102.method_1531().method_4616(HUE_TEXTURE_ID, (class_1044)hueTexture);
        }
        if (squareTexture == null) {
            class_10112 = new class_1011(128, 128, false);
            this.fillSquare(class_10112);
            squareTexture = new class_1043(ColorPickerScreen::lmbd$ensureTextures$1, class_10112);
            class_3102.method_1531().method_4616(SQUARE_TEXTURE_ID, (class_1044)squareTexture);
            uploadedHue = this.hue;
            return;
        } else {
            if (!(Math.abs(uploadedHue - this.hue) > 1.0E-4f)) return;
            this.fillSquare(squareTexture.method_4525());
            squareTexture.method_4524();
            uploadedHue = this.hue;
        }
    }

    private void fillSquare(class_1011 class_10112) {
        for (int i = 0; i < 128; ++i) {
            float f = 1.0f - (float)i / 127.0f;
            for (int j = 0; j < 128; ++j) {
                float f2 = (float)j / 127.0f;
                class_10112.method_61941(j, i, 0xFF000000 | Color.HSBtoRGB(this.hue, f2, f) & 0xFFFFFF);
            }
        }
    }

    private Color chosenColor() {
        return new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
    }

    private void applyHexIfValid() {
        Color color = ColorPickerScreen.parseHex(this.hexValue);
        if (color == null) return;
        float[] fArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        this.hue = fArray[0];
        this.saturation = fArray[1];
        this.brightness = fArray[2];
    }

    private static String toHex(Color color) {
        return String.format(Locale.ROOT, "#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static boolean isValidHex(String string) {
        if (string == null) return false;
        if (!string.matches("(?i)#[0-9a-f]{6}")) return false;
        return true;
    }

    private static Color parseHex(String string) {
        if (!ColorPickerScreen.isValidHex(string)) {
            return null;
        }
        try {
            return new Color(Integer.parseInt(string.substring(1), 16));
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    private static boolean hasControlDown() {
        long l = class_310.method_1551().method_22683().method_4490();
        if (GLFW.glfwGetKey((long)l, 341) == 1) return true;
        if (GLFW.glfwGetKey((long)l, 345) != 1) return false;
        return true;
    }

    private static float clamp(float f) {
        return Math.max(0.0f, Math.min(1.0f, f));
    }

    private static int physical(double d) {
        return (int)Math.round(d * (double)class_310.method_1551().method_22683().method_4495());
    }

    private static boolean inside(double d, double d2, int n, int n2, int n3, int n4) {
        if (!(d >= (double)n)) return false;
        if (!(d <= (double)(n + n3))) return false;
        if (!(d2 >= (double)n2)) return false;
        if (!(d2 <= (double)(n2 + n4))) return false;
        return true;
    }

    private static String lmbd$ensureTextures$1() {
        return "Kryzex storage color square";
    }

    private static String lmbd$ensureTextures$0() {
        return "Kryzex storage hue";
    }

    static {
        uploadedHue = -1.0f;
    }
}
