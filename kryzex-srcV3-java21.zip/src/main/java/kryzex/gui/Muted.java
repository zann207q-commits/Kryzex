package kryzex.gui;

import kryzex.cinematic.Ambience;
import kryzex.client.KryzexClient;
import kryzex.modules.client.KryzexPlus;
import net.minecraft.class_310;

public final class Muted {
    private static volatile boolean muted;

    private Muted() {
    }

    public static boolean enabled() {
        if (muted) return false;
        return true;
    }

    public static float volume() {
        try {
            return (float)(KryzexPlus.halloweenVolume.getValue() / 100.0);
        }
        catch (RuntimeException runtimeException) {
            return 0.35f;
        }
    }

    public static void setVolume(float f) {
        KryzexPlus.halloweenVolume.getValue(Math.max(0, Math.min(100, Math.round(f * 100.0f))));
    }

    public static void toggle() {
        muted = !muted;
    }

    public static void save() {
        try {
            if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.getSettingsManager() == null) return;
            KryzexClient.INSTANCE.getSettingsManager().saveNow();
            return;
        }
        catch (RuntimeException runtimeException) {
            System.err.println("Kryzex: menu sound settings could not be saved");
        }
    }

    public static void requested(boolean bl, float f) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 != null && class_3102.field_1687 == null) {
            bl = Muted.enabled();
        }
        Ambience.setMenuWanted(bl, f);
    }
}
