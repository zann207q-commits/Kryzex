package kryzex.gui;

public enum Watermark {
    WATERMARK("Watermark"),
    INFO("Info"),
    PLAYER("Player"),
    COORDS("Coordinates"),
    MODULES("Modules");

    final String label;

    private Watermark(String string2) {
        this.label = string2;
    }
}
