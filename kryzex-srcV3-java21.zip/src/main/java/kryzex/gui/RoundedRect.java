package kryzex.gui;

import kryzex.gui.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2fc;

final class RoundedRect
implements class_11244 {
    private final float[] xy = new float[8];
    private final float width;
    private final float height;
    private final float pad = 2.0f;
    private final int sizeX;
    private final int sizeY;
    private final int radius;
    private final int stroke;
    private final int top;
    private final int bottom;
    private final class_8030 clip;
    private final class_8030 bounds;

    RoundedRect(Matrix3x2fc matrix3x2fc, class_8030 class_80302, float f, float f2, float f3, float f4, float f5, float f6, int n, int n2) {
        this.width = f3;
        this.height = f4;
        this.sizeX = Math.clamp((long)Math.round(f3 * 4.0f), 1, Short.MAX_VALUE);
        this.sizeY = Math.clamp((long)Math.round(f4 * 4.0f), 1, Short.MAX_VALUE);
        this.radius = Math.clamp((long)Math.round(Math.min(f5, Math.min(f3, f4) / 2.0f) * 64.0f), 0, Short.MAX_VALUE);
        this.stroke = Math.clamp((long)Math.round(f6 * 64.0f), 0, Short.MAX_VALUE);
        this.top = n;
        this.bottom = n2;
        this.clip = class_80302;
        float[] fArray = new float[]{f - 2.0f, f - 2.0f, f + f3 + 2.0f, f + f3 + 2.0f};
        float[] fArray2 = new float[]{f2 - 2.0f, f2 + f4 + 2.0f, f2 + f4 + 2.0f, f2 - 2.0f};
        float f8 = Float.POSITIVE_INFINITY;
        float f7 = Float.NEGATIVE_INFINITY;
        float f9 = Float.POSITIVE_INFINITY;
        float f10 = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < 4; ++i) {
            float f11 = matrix3x2fc.m00() * fArray[i] + matrix3x2fc.m10() * fArray2[i] + matrix3x2fc.m20();
            float f12 = matrix3x2fc.m01() * fArray[i] + matrix3x2fc.m11() * fArray2[i] + matrix3x2fc.m21();
            this.xy[i * 2] = f11;
            this.xy[i * 2 + 1] = f12;
            f8 = Math.min(f8, f11);
            f9 = Math.min(f9, f12);
            f7 = Math.max(f7, f11);
            f10 = Math.max(f10, f12);
        }
        class_8030 class_80303 = new class_8030((int)Math.floor(f8), (int)Math.floor(f9), (int)Math.ceil(f7) - (int)Math.floor(f8), (int)Math.ceil(f10) - (int)Math.floor(f9));
        this.bounds = class_80302 == null ? class_80303 : class_80303.method_49701(class_80302);
    }

    public void method_70917(class_4588 class_45882) {
        for (int i = 0; i < 4; ++i) {
            float f = i < 2 ? -2.0f / this.width : 1.0f + 2.0f / this.width;
            float f2 = i == 0 || i == 3 ? -2.0f / this.height : 1.0f + 2.0f / this.height;
            class_45882.method_22912(this.xy[i * 2], this.xy[i * 2 + 1], 0.0f).method_39415(i == 0 || i == 3 ? this.top : this.bottom).method_22913(f, f2).method_60796(this.sizeX, this.sizeY).method_22921(this.radius, this.stroke).method_22914(0.0f, 0.0f, 1.0f);
        }
    }

    public com.mojang.blaze3d.pipeline.RenderPipeline comp_4055() {
        return RenderPipeline.PIPELINE;
    }

    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    public class_8030 comp_4069() {
        return this.clip;
    }

    public class_8030 comp_4274() {
        return this.bounds;
    }
}
