package kryzex.gui;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Bottom;
import kryzex.gui.Easing;
import kryzex.gui.HudInfo;
import kryzex.gui.NetherCoords;
import kryzex.gui.Presence;
import kryzex.gui.SpeakerOff;
import kryzex.gui.Theme;
import kryzex.gui.Watermark;
import kryzex.gui.FloatArrayGetter;
import kryzex.gui.DrawAction;

public final class Logo {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final float EDGE = 10.0f;
    private static final float STACK_GAP = 7.0f;
    private static final float ROW_H = 22.0f;
    private static final float ROW_GAP = 4.0f;
    private final Map<Watermark, Bottom> places = new EnumMap<Watermark, Bottom>(Watermark.class);
    private final Map<Watermark, float[]> bounds = new EnumMap<Watermark, float[]>(Watermark.class);
    private final Map<String, Presence> rows = new LinkedHashMap<String, Presence>();
    private final Map<String, Float> widthCache = new LinkedHashMap<String, Float>(512, 0.75f, true);
    private List<String> moduleNames = List.of();
    private List<String> sortedModuleNames = List.of();
    private float sortedAtSize = -1.0f;
    private final ArrayList<String> removedRows = new ArrayList();
    private float u = 1.0f;
    private int lastSw = 1920;
    private float dt;
    private long last;
    private float time;
    private boolean loaded;
    private Watermark dragging;
    private double grabX;
    private double grabY;
    private Path file;
    private NetherCoords lastOptions = new NetherCoords();
    private final Map<String, float[]> anims = new HashMap<String, float[]>();

    public void setFile(Path path) {
        this.file = path;
    }

    public void render(BaseRenderer baseRenderer, int n, int n2, HudInfo hudInfo, NetherCoords netherCoords, float f, boolean bl, double d, double d2) {
        long l = System.nanoTime();
        this.dt = this.last == 0L ? 0.016f : Math.min(0.1f, (float)(l - this.last) / 1.0E9f);
        this.last = l;
        this.time += this.dt;
        this.load();
        this.lastOptions = netherCoords;
        this.u = Math.max(0.5f, (float)n2 / 1080.0f * netherCoords.scale);
        this.lastSw = n;
        if (this.dragging != null) {
            Bottom bottom = this.places.computeIfAbsent(this.dragging, Logo::lmbd$render$0);
            float[] fArray = this.bounds.get((Object)this.dragging);
            if (fArray != null) {
                this.placeFromPixel(bottom, (float)(d - this.grabX), (float)(d2 - this.grabY), fArray[2], fArray[3], n, n2);
            }
        }
        baseRenderer.pushAlpha(f);
        float f2 = this.d(10.0f);
        f2 = this.element(baseRenderer, Watermark.WATERMARK, netherCoords.watermark, n, n2, f2, bl, d, d2, () -> this.lmbd$render$1(baseRenderer, netherCoords), (arg_0, arg_1) -> this.lmbd$render$2(baseRenderer, netherCoords, arg_0, arg_1));
        f2 = this.element(baseRenderer, Watermark.INFO, netherCoords.info && hudInfo.inWorld(), n, n2, f2, bl, d, d2, () -> this.lmbd$render$3(baseRenderer, hudInfo), (arg_0, arg_1) -> this.lmbd$render$4(baseRenderer, hudInfo, arg_0, arg_1));
        f2 = this.element(baseRenderer, Watermark.PLAYER, netherCoords.player && hudInfo.inWorld(), n, n2, f2, bl, d, d2, () -> this.lmbd$render$5(baseRenderer, hudInfo), (arg_0, arg_1) -> this.lmbd$render$6(baseRenderer, hudInfo, arg_0, arg_1));
        this.element(baseRenderer, Watermark.COORDS, netherCoords.coords && hudInfo.inWorld(), n, n2, f2, bl, d, d2, () -> this.lmbd$render$7(baseRenderer, hudInfo, netherCoords), (arg_0, arg_1) -> this.lmbd$render$8(baseRenderer, hudInfo, netherCoords, arg_0, arg_1));
        this.drawModules(baseRenderer, netherCoords.modules, n, n2, hudInfo, bl, d, d2);
        baseRenderer.popAlpha();
    }

    private float d(float f) {
        return f * this.u;
    }

    private float element(BaseRenderer baseRenderer, Watermark watermark, boolean bl, int n, int n2, float f, boolean bl2, double d, double d2, FloatArrayGetter l12, DrawAction lA2) {
        Bottom bottom;
        float f2 = this.anim("el:" + watermark.name(), bl ? 1.0f : 0.0f, 9.0f);
        if (f2 < 0.01f) {
            this.bounds.remove((Object)watermark);
            return f;
        }
        float[] fArray = l12.get();
        float f3 = fArray[0];
        float f4 = fArray[1];
        float[] fArray2 = this.position(watermark, f3, f4, n, n2, f);
        float f5 = fArray2[0];
        float f6 = fArray2[1];
        this.bounds.put(watermark, new float[]{f5, f6, f3, f4});
        float f7 = Easing.out(f2);
        baseRenderer.pushAlpha(f7);
        baseRenderer.pushTransform(0.0f, (1.0f - f7) * this.d(-6.0f), 1.0f);
        lA2.draw(f5, f6);
        baseRenderer.popTransform();
        baseRenderer.popAlpha();
        if (bl2) {
            this.editFrame(baseRenderer, watermark, f5, f6, f3, f4, d, d2);
        }
        boolean bl3 = ((bottom = this.places.get((Object)watermark)) == null || !bottom.moved) && watermark != Watermark.COORDS;
        return bl3 ? f + (f4 + this.d(7.0f)) * f7 : f;
    }

    private void glass(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, NetherCoords netherCoords) {
        baseRenderer.shadow(f, f2, f3, f4, f5, this.d(12.0f), BaseRenderer.argb(0.28f, 0, 0, 0));
        baseRenderer.round(f, f2, f3, f4, f5, Theme.glass(Math.max(0.0f, Math.min(1.0f, netherCoords.opacity))));
        baseRenderer.roundGradient(f, f2, f3, f4 * 0.6f, f5, BaseRenderer.white(0.055f), BaseRenderer.white(0.0f));
        baseRenderer.outline(f, f2, f3, f4, f5, Math.max(1.0f, this.u * 0.85f), BaseRenderer.white(0.075f));
    }

    private float textW(BaseRenderer baseRenderer, String string, float f, int n) {
        String string2 = n + "|" + f + "|" + string;
        Float f2 = this.widthCache.get(string2);
        if (f2 != null) return f2.floatValue();
        if (this.widthCache.size() > 512) {
            this.widthCache.remove(this.widthCache.keySet().iterator().next());
        }
        f2 = Float.valueOf(baseRenderer.textWidth(string, f, n));
        this.widthCache.put(string2, f2);
        return f2.floatValue();
    }

    private float[] watermarkSize(BaseRenderer baseRenderer, NetherCoords netherCoords) {
        this.lastOptions = netherCoords;
        float f = this.d(10.0f) + this.d(18.0f) + this.d(8.0f) + this.textW(baseRenderer, "Kryzex", this.d(14.0f), 1) + this.d(12.0f);
        if (!netherCoords.time) return new float[]{f, this.d(32.0f)};
        f += this.d(10.0f) + this.textW(baseRenderer, this.clock(), this.d(12.5f), 0);
        return new float[]{f, this.d(32.0f)};
    }

    private String clock() {
        return LocalTime.now().format(CLOCK);
    }

    private void drawWatermark(BaseRenderer baseRenderer, float f, float f2, NetherCoords netherCoords) {
        float f3 = this.d(32.0f);
        float[] fArray = this.watermarkSize(baseRenderer, netherCoords);
        this.glass(baseRenderer, f, f2, fArray[0], f3, f3 / 2.0f, netherCoords);
        float f4 = this.d(18.0f);
        float f5 = f + this.d(10.0f);
        float f6 = 0.5f + 0.5f * (float)Math.sin(this.time * 0.9f);
        if (netherCoords.rainbow) {
            baseRenderer.glow(f5 + f4 / 2.0f, f2 + f3 / 2.0f, f4 * 1.3f, this.accent(0.16f + 0.05f * f6, 0.0f));
            baseRenderer.imageGradient("logo", f5, f2 + (f3 - f4) / 2.0f, f4, this.accent(1.0f, 0.0f), this.accent(1.0f, 0.18f));
        } else {
            baseRenderer.glow(f5 + f4 / 2.0f, f2 + f3 / 2.0f, f4 * 1.3f, Theme.logoBottom(0.12f + 0.05f * f6));
            baseRenderer.imageGradient("logo", f5, f2 + (f3 - f4) / 2.0f, f4, Theme.logoTop(1.0f), Theme.logoBottom(1.0f));
        }
        float f7 = f5 + f4 + this.d(8.0f);
        baseRenderer.text("Kryzex", f7, f2 + (f3 - this.d(14.0f)) / 2.0f - this.d(1.0f), this.d(14.0f), 1, BaseRenderer.white(0.96f));
        if (!netherCoords.time) return;
        float f8 = f7 + this.textW(baseRenderer, "Kryzex", this.d(14.0f), 1) + this.d(9.0f);
        baseRenderer.rect(f8, f2 + f3 * 0.3f, Math.max(1.0f, this.u), f3 * 0.4f, BaseRenderer.white(0.14f));
        baseRenderer.text(this.clock(), f8 + this.d(9.0f), f2 + (f3 - this.d(12.5f)) / 2.0f - this.d(0.5f), this.d(12.5f), 0, BaseRenderer.white(0.62f));
    }

    private List<String[]> infoChips(HudInfo hudInfo) {
        ArrayList<String[]> arrayList = new ArrayList<String[]>();
        arrayList.add(new String[]{"ACTIVITY", String.valueOf(hudInfo.fps()), "fps"});
        arrayList.add(new String[]{"SIGNAL", hudInfo.ping(), "ms"});
        String string = hudInfo.server();
        if (string == null || string.isBlank()) return arrayList;
        arrayList.add(new String[]{"GLOBE", string, ""});
        return arrayList;
    }

    private float chipW(BaseRenderer baseRenderer, String[] stringArray) {
        float f = this.d(14.0f) + this.d(6.0f) + this.textW(baseRenderer, stringArray[1], this.d(12.5f), 1);
        if (stringArray[2].isEmpty()) return f;
        f += this.d(3.0f) + this.textW(baseRenderer, stringArray[2], this.d(11.0f), 0);
        return f;
    }

    private float[] infoSize(BaseRenderer baseRenderer, HudInfo hudInfo) {
        float f = this.d(12.0f);
        List<String[]> list = this.infoChips(hudInfo);
        for (int i = 0; i < list.size(); ++i) {
            f += this.chipW(baseRenderer, list.get(i)) + (i > 0 ? this.d(14.0f) : 0.0f);
        }
        return new float[]{f + this.d(12.0f), this.d(28.0f)};
    }

    private void drawInfo(BaseRenderer baseRenderer, float f, float f2, HudInfo hudInfo) {
        float[] fArray = this.infoSize(baseRenderer, hudInfo);
        float f3 = fArray[1];
        this.glass(baseRenderer, f, f2, fArray[0], f3, f3 / 2.0f, this.lastOptions);
        float f4 = f + this.d(12.0f);
        List<String[]> list = this.infoChips(hudInfo);
        for (int i = 0; i < list.size(); ++i) {
            String[] stringArray = list.get(i);
            if (i > 0) {
                baseRenderer.circle(f4 + this.d(7.0f), f2 + f3 / 2.0f, this.d(1.5f), BaseRenderer.white(0.25f));
                f4 += this.d(14.0f);
            }
            float f5 = this.d(14.0f);
            baseRenderer.icon(SpeakerOff.valueOf(stringArray[0]), f4, f2 + (f3 - f5) / 2.0f, f5, i == 0 ? this.accent(0.95f, 0.0f) : BaseRenderer.white(0.8f));
            float f6 = f4 + f5 + this.d(6.0f);
            boolean bl = stringArray[2].isEmpty();
            float f7 = baseRenderer.text(stringArray[1], f6, f2 + (f3 - this.d(12.5f)) / 2.0f - this.d(1.0f), this.d(12.5f), bl ? 0 : 1, BaseRenderer.white(bl ? 0.66f : 0.95f));
            if (!bl) {
                baseRenderer.text(stringArray[2], f6 + f7 + this.d(3.0f), f2 + (f3 - this.d(11.0f)) / 2.0f - this.d(0.5f), this.d(11.0f), 0, BaseRenderer.white(0.5f));
            }
            f4 += this.chipW(baseRenderer, stringArray);
        }
    }

    private float[] playerSize(BaseRenderer baseRenderer, HudInfo hudInfo) {
        String string = this.hp(hudInfo);
        float f = this.d(8.0f) + this.d(18.0f) + this.d(8.0f) + this.textW(baseRenderer, hudInfo.playerName(), this.d(12.5f), 1) + this.d(12.0f) + this.d(12.0f) + this.d(4.0f) + this.textW(baseRenderer, string, this.d(12.0f), 1) + this.d(12.0f);
        return new float[]{f, this.d(30.0f)};
    }

    private String hp(HudInfo hudInfo) {
        float f = Math.max(0.0f, hudInfo.health());
        return f == (float)Math.round(f) ? String.valueOf(Math.round(f)) : String.format(Locale.ROOT, "%.1f", Float.valueOf(f));
    }

    private void drawPlayer(BaseRenderer baseRenderer, float f, float f2, HudInfo hudInfo) {
        float[] fArray = this.playerSize(baseRenderer, hudInfo);
        float f3 = fArray[1];
        this.glass(baseRenderer, f, f2, fArray[0], f3, f3 / 2.0f, this.lastOptions);
        float f4 = this.d(18.0f);
        float f5 = f + this.d(8.0f);
        baseRenderer.round(f5 - this.d(1.5f), f2 + (f3 - f4) / 2.0f - this.d(1.5f), f4 + this.d(3.0f), f4 + this.d(3.0f), this.d(6.0f), BaseRenderer.white(0.1f));
        baseRenderer.head(f5, f2 + (f3 - f4) / 2.0f, f4);
        float f6 = f5 + f4 + this.d(8.0f);
        float f7 = baseRenderer.text(hudInfo.playerName(), f6, f2 + (f3 - this.d(12.5f)) / 2.0f - this.d(1.0f), this.d(12.5f), 1, BaseRenderer.white(0.95f));
        float f8 = f6 + f7 + this.d(12.0f);
        float f9 = this.d(12.0f);
        baseRenderer.icon(SpeakerOff.HEART, f8, f2 + (f3 - f9) / 2.0f, f9, this.accent(0.95f, 0.2f));
        baseRenderer.text(this.hp(hudInfo), f8 + f9 + this.d(4.0f), f2 + (f3 - this.d(12.0f)) / 2.0f - this.d(1.0f), this.d(12.0f), 1, BaseRenderer.white(0.85f));
    }

    private String[] axes(HudInfo hudInfo, boolean bl) {
        double d = bl ? (hudInfo.nether() ? 8.0 : 0.125) : 1.0;
        return new String[]{String.valueOf((long)Math.floor(hudInfo.x() * d)), String.valueOf((long)Math.floor(hudInfo.y())), String.valueOf((long)Math.floor(hudInfo.z() * d))};
    }

    private float axesW(BaseRenderer baseRenderer, String[] stringArray, float f) {
        float f2 = 0.0f;
        String[] stringArray2 = new String[]{"X", "Y", "Z"};
        for (int i = 0; i < 3; ++i) {
            f2 += this.textW(baseRenderer, stringArray2[i], f * 0.8f, 1) + this.d(4.0f) + this.textW(baseRenderer, stringArray[i], f, 1) + (i < 2 ? this.d(10.0f) : 0.0f);
        }
        return f2;
    }

    private static String facing(float f) {
        String[] stringArray = new String[]{"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        int n = Math.floorMod(Math.round(f % 360.0f / 45.0f), 8);
        return stringArray[n];
    }

    private float[] coordsSize(BaseRenderer baseRenderer, HudInfo hudInfo, NetherCoords netherCoords) {
        float f = this.d(10.0f) + this.d(18.0f) + this.d(10.0f) + this.axesW(baseRenderer, this.axes(hudInfo, false), this.d(13.0f)) + this.d(12.0f);
        if (netherCoords.direction) {
            f += this.textW(baseRenderer, Logo.facing(hudInfo.yaw()), this.d(10.5f), 1) + this.d(14.0f) + this.d(4.0f);
        }
        float f2 = this.d(32.0f);
        if (!netherCoords.netherCoords) return new float[]{f, f2};
        float f3 = this.d(10.0f) + this.netherTagW(baseRenderer, hudInfo) + this.d(8.0f) + this.axesW(baseRenderer, this.axes(hudInfo, true), this.d(11.0f)) + this.d(12.0f);
        f = Math.max(f, f3);
        f2 += this.d(16.0f);
        return new float[]{f, f2};
    }

    private void drawCoords(BaseRenderer baseRenderer, float f, float f2, HudInfo hudInfo, NetherCoords netherCoords) {
        float f3;
        float[] fArray = this.coordsSize(baseRenderer, hudInfo, netherCoords);
        float f4 = fArray[0];
        float f5 = fArray[1];
        this.glass(baseRenderer, f, f2, f4, f5, this.d(16.0f), netherCoords);
        float f6 = this.d(18.0f);
        float f7 = f + this.d(10.0f) + f6 / 2.0f;
        float f8 = f2 + this.d(16.0f);
        baseRenderer.outline(f7 - f6 / 2.0f, f8 - f6 / 2.0f, f6, f6, f6 / 2.0f, Math.max(1.0f, this.u * 1.2f), BaseRenderer.white(0.42f));
        double d = Math.toRadians(hudInfo.yaw());
        float f9 = (float)(-Math.sin(d));
        float f10 = (float)Math.cos(d);
        float f11 = f6 / 2.0f - this.d(3.5f);
        baseRenderer.glow(f7, f8, f6, this.accent(0.1f, 0.4f));
        baseRenderer.circle(f7 - f9 * f11, f8 - f10 * f11, this.d(2.4f), this.accent(1.0f, 0.4f));
        baseRenderer.circle(f7 + f9 * f11, f8 + f10 * f11, this.d(1.6f), BaseRenderer.white(0.35f));
        baseRenderer.circle(f7, f8, this.d(1.4f), BaseRenderer.white(0.85f));
        float f12 = f + this.d(10.0f) + f6 + this.d(10.0f);
        this.drawAxes(baseRenderer, this.axes(hudInfo, false), f12, f2 + this.d(16.0f) - this.d(7.5f), this.d(13.0f), 0.95f);
        if (netherCoords.direction) {
            String string = Logo.facing(hudInfo.yaw());
            float f13 = this.textW(baseRenderer, string, this.d(10.5f), 1) + this.d(14.0f);
            f3 = f + f4 - this.d(8.0f) - f13;
            float f14 = f2 + this.d(16.0f) - this.d(9.0f);
            baseRenderer.round(f3, f14, f13, this.d(18.0f), this.d(9.0f), BaseRenderer.white(0.09f));
            baseRenderer.textCentered(string, f3 + f13 / 2.0f, f14 + this.d(3.0f), this.d(10.5f), 1, BaseRenderer.white(0.85f));
        }
        if (!netherCoords.netherCoords) return;
        float f15 = f2 + this.d(32.0f) - this.d(3.0f);
        String string = hudInfo.nether() ? "OVERWORLD" : "NETHER";
        f3 = this.netherTagW(baseRenderer, hudInfo);
        baseRenderer.round(f + this.d(10.0f), f15 - this.d(1.0f), f3, this.d(14.0f), this.d(7.0f), BaseRenderer.white(0.07f));
        baseRenderer.textCentered(string, f + this.d(10.0f) + f3 / 2.0f, f15 + this.d(1.5f), this.d(8.5f), 1, BaseRenderer.white(0.5f));
        this.drawAxes(baseRenderer, this.axes(hudInfo, true), f + this.d(10.0f) + f3 + this.d(8.0f), f15, this.d(11.0f), 0.6f);
    }

    private float netherTagW(BaseRenderer baseRenderer, HudInfo hudInfo) {
        return this.textW(baseRenderer, hudInfo.nether() ? "OVERWORLD" : "NETHER", this.d(8.5f), 1) + this.d(12.0f);
    }

    private void drawAxes(BaseRenderer baseRenderer, String[] stringArray, float f, float f2, float f3, float f4) {
        String[] stringArray2 = new String[]{"X", "Y", "Z"};
        float f5 = f;
        for (int i = 0; i < 3; ++i) {
            float f6 = baseRenderer.text(stringArray2[i], f5, f2 + f3 * 0.12f, f3 * 0.8f, 1, BaseRenderer.white(0.38f * f4));
            f5 += f6 + this.d(4.0f);
            f5 += baseRenderer.text(stringArray[i], f5, f2, f3, 1, BaseRenderer.white(f4)) + this.d(10.0f);
        }
    }

    private void drawModules(BaseRenderer baseRenderer, boolean bl, int n, int n2, HudInfo hudInfo, boolean bl2, double d, double d2) {
        List<String> list;
        List<String> list2;
        float f = this.anim("el:MODULES", bl ? 1.0f : 0.0f, 9.0f);
        float f2 = this.d(12.5f);
        List<String> list3 = list2 = bl ? hudInfo.modules() : List.<String>of();
        if (f2 != this.sortedAtSize || !list2.equals(this.moduleNames)) {
            this.moduleNames = List.copyOf(list2);
            list = new ArrayList<String>(list2);
            list.sort((arg_0, arg_1) -> this.lmbd$drawModules$0(baseRenderer, f2, arg_0, arg_1));
            this.sortedModuleNames = list;
            this.sortedAtSize = f2;
        }
        list = this.sortedModuleNames;
        for (Presence presence : this.rows.values()) {
            presence.active = false;
        }
        int n3 = 0;
        while (n3 < list.size()) {
            Presence presence;
            presence = this.rows.computeIfAbsent(list.get(n3), Logo::lmbd$drawModules$1);
            presence.active = true;
            presence.index = n3++;
        }
        float f3 = this.d(26.0f);
        float f4 = this.d(22.0f);
        float f5 = 0.0f;
        for (String string : list) {
            f5 = Math.max(f5, this.rowW(baseRenderer, string, f2));
        }
        float f6 = Math.max(this.d(90.0f), f5);
        float f7 = Math.max(f4, (float)list.size() * f3 - this.d(4.0f));
        if (f < 0.01f && this.rows.isEmpty()) {
            this.bounds.remove((Object)Watermark.MODULES);
            return;
        } else {
            float[] fArray = this.position(Watermark.MODULES, f6, f7, n, n2, 0.0f);
            float f8 = fArray[0];
            float f9 = fArray[1];
            boolean bl3 = f8 + f6 / 2.0f > (float)n / 2.0f;
            this.bounds.put(Watermark.MODULES, new float[]{f8, f9, f6, f7});
            float f10 = 1.0f - (float)Math.exp(-13.0f * this.dt);
            baseRenderer.pushAlpha(Easing.out(f));
            this.removedRows.clear();
            ArrayList<String> arrayList = this.removedRows;
            for (Map.Entry<String, Presence> object : this.rows.entrySet()) {
                float f11;
                Presence presence = object.getValue();
                String string = object.getKey();
                if (presence.active) {
                    presence.target = (float)presence.index * f3;
                }
                if (Float.isNaN(presence.y)) {
                    presence.y = presence.target;
                }
                presence.y += (presence.target - presence.y) * f10;
                presence.presence = presence.presence + ((presence.active ? 1.0f : 0.0f) - presence.presence) * (1.0f - (float)Math.exp(-11.0f * this.dt));
                if (!presence.active && presence.presence < 0.015f) {
                    arrayList.add(string);
                    continue;
                }
                float f12 = Easing.out(presence.presence);
                float f13 = this.rowW(baseRenderer, string, f2);
                float f14 = (1.0f - f12) * this.d(18.0f);
                float f15 = f11 = bl3 ? f8 + f6 - f13 + f14 : f8 - f14;
                float f16 = f9 + presence.y;
                if (f16 + f4 + this.d(12.0f) < 0.0f || f16 - this.d(12.0f) > (float)n2 || f11 + f13 + this.d(12.0f) < 0.0f || f11 - this.d(12.0f) > (float)n) continue;
                baseRenderer.pushAlpha(f12);
                this.glassRow(baseRenderer, f11, f16, f13, f4);
                float f17 = (float)presence.index * 0.045f;
                if (this.lastOptions.rainbow) {
                    baseRenderer.outline(f11, f16, f13, f4, f4 / 2.0f, Math.max(1.0f, this.u * 0.85f), this.accent(0.22f, f17));
                }
                baseRenderer.text(string, f11 + this.d(11.0f), f16 + (f4 - f2) / 2.0f - this.d(1.0f), f2, 0, this.lastOptions.rainbow ? this.accent(0.97f, f17) : BaseRenderer.white(0.95f));
                baseRenderer.popAlpha();
            }
            for (String string : arrayList) {
                this.rows.remove(string);
            }
            baseRenderer.popAlpha();
            if (!bl2) return;
            this.editFrame(baseRenderer, Watermark.MODULES, f8, f9, f6, f7, d, d2);
        }
    }

    private float rowW(BaseRenderer baseRenderer, String string, float f) {
        return this.d(11.0f) + this.textW(baseRenderer, string, f, 0) + this.d(11.0f);
    }

    private void glassRow(BaseRenderer baseRenderer, float f, float f2, float f3, float f4) {
        NetherCoords netherCoords = this.lastOptions;
        baseRenderer.shadow(f, f2, f3, f4, f4 / 2.0f, this.d(9.0f), BaseRenderer.argb(0.22f, 0, 0, 0));
        baseRenderer.round(f, f2, f3, f4, f4 / 2.0f, Theme.glass(Math.max(0.0f, Math.min(1.0f, netherCoords.opacity))));
        baseRenderer.roundGradient(f, f2, f3, f4 * 0.65f, f4 / 2.0f, BaseRenderer.white(0.05f), BaseRenderer.white(0.0f));
        baseRenderer.outline(f, f2, f3, f4, f4 / 2.0f, Math.max(1.0f, this.u * 0.85f), BaseRenderer.white(0.065f));
    }

    private float[] position(Watermark watermark, float f, float f2, int n, int n2, float f3) {
        float[] fArray;
        Bottom bottom = this.places.get((Object)watermark);
        if (bottom != null && bottom.moved) {
            float f4 = bottom.right ? (float)n - this.d(bottom.ox) - f : this.d(bottom.ox);
            float f5 = bottom.bottom ? (float)n2 - this.d(bottom.oy) - f2 : this.d(bottom.oy);
            return new float[]{Logo.clamp(f4, 0.0f, (float)n - f), Logo.clamp(f5, 0.0f, (float)n2 - f2)};
        }
        switch (watermark.ordinal()) {
            case 3: {
                float[] fArray2 = new float[2];
                fArray2[0] = this.d(10.0f);
                fArray = fArray2;
                fArray2[1] = (float)n2 - this.d(10.0f) - f2;
                return fArray;
            }
            case 4: {
                float[] fArray3 = new float[2];
                fArray3[0] = (float)n - this.d(10.0f) - f;
                fArray = fArray3;
                fArray3[1] = this.d(10.0f);
                return fArray;
            }
            default: {
                float[] fArray4 = new float[2];
                fArray4[0] = this.d(10.0f);
                fArray = fArray4;
                fArray4[1] = f3;
            }
        }
        return fArray;
    }

    private void placeFromPixel(Bottom bottom, float f, float f2, float f3, float f4, int n, int n2) {
        f = Logo.clamp(f, 0.0f, (float)n - f3);
        f2 = Logo.clamp(f2, 0.0f, (float)n2 - f4);
        bottom.moved = true;
        bottom.right = f + f3 / 2.0f > (float)n / 2.0f;
        bottom.bottom = f2 + f4 / 2.0f > (float)n2 / 2.0f;
        bottom.ox = (bottom.right ? (float)n - f - f3 : f) / this.u;
        bottom.oy = (bottom.bottom ? (float)n2 - f2 - f4 : f2) / this.u;
    }

    private void editFrame(BaseRenderer baseRenderer, Watermark watermark, float f, float f2, float f3, float f4, double d, double d2) {
        boolean bl = this.dragging == watermark || d >= (double)f && d < (double)(f + f3) && d2 >= (double)f2 && d2 < (double)(f2 + f4);
        float f5 = this.anim("edit:" + watermark.name(), bl ? 1.0f : 0.0f, 14.0f);
        float f6 = this.d(4.0f);
        baseRenderer.outline(f - f6, f2 - f6, f3 + f6 * 2.0f, f4 + f6 * 2.0f, this.d(10.0f), Math.max(1.0f, this.u), BaseRenderer.white(0.22f + 0.35f * f5));
        float f7 = this.textW(baseRenderer, watermark.label, this.d(10.0f), 1) + this.d(12.0f);
        float f8 = this.d(16.0f);
        boolean bl2 = f + f3 / 2.0f > (float)this.lastSw / 2.0f;
        float f9 = bl2 ? f - f6 - this.d(6.0f) - f7 : f + f3 + f6 + this.d(6.0f);
        float f10 = watermark == Watermark.MODULES ? f2 : f2 + (f4 - f8) / 2.0f;
        baseRenderer.pushAlpha(0.5f + 0.5f * f5);
        baseRenderer.round(f9, f10, f7, f8, f8 / 2.0f, BaseRenderer.argb(0.85f, 20, 21, 25));
        baseRenderer.text(watermark.label, f9 + this.d(6.0f), f10 + this.d(2.5f), this.d(10.0f), 1, BaseRenderer.white(0.85f));
        baseRenderer.popAlpha();
    }

    public boolean mousePressed(double d, double d2) {
        Watermark[] watermarkArray = Watermark.values();
        for (int i = watermarkArray.length - 1; i >= 0; --i) {
            float[] fArray = this.bounds.get((Object)watermarkArray[i]);
            if (fArray == null || !(d >= (double)fArray[0]) || !(d < (double)(fArray[0] + fArray[2])) || !(d2 >= (double)fArray[1]) || !(d2 < (double)(fArray[1] + fArray[3]))) continue;
            this.dragging = watermarkArray[i];
            this.grabX = d - (double)fArray[0];
            this.grabY = d2 - (double)fArray[1];
            return true;
        }
        return false;
    }

    public void mouseReleased() {
        if (this.dragging == null) return;
        this.dragging = null;
        this.save();
    }

    public void resetLayout() {
        this.places.clear();
        this.save();
    }

    private float anim(String string, float f, float f2) {
        float[] fArray = this.anims.computeIfAbsent(string, arg_0 -> Logo.lmbd$anim$0(f, arg_0));
        fArray[0] = fArray[0] + (f - fArray[0]) * (1.0f - (float)Math.exp(-f2 * this.dt));
        if (!(Math.abs(f - fArray[0]) < 0.001f)) return fArray[0];
        fArray[0] = f;
        return fArray[0];
    }

    private int accent(float f, float f2) {
        if (!this.lastOptions.rainbow) {
            return Theme.accent(f);
        }
        float f3 = (this.time * 0.08f * this.lastOptions.rainbowSpeed + f2) % 1.0f;
        int n = Color.HSBtoRGB(f3 < 0.0f ? f3 + 1.0f : f3, 0.5f, 1.0f) & 0xFFFFFF;
        return Math.round(Math.max(0.0f, Math.min(1.0f, f)) * 255.0f) << 24 | n;
    }

    private static float clamp(float f, float f2, float f3) {
        return f3 < f2 ? f2 : Math.max(f2, Math.min(f3, f));
    }

    private void load() {
        if (this.loaded) return;
        this.loaded = true;
        try {
            if (this.file == null || !Files.isRegularFile(this.file, new LinkOption[0])) return;
            for (String string : Files.readAllLines(this.file, StandardCharsets.UTF_8)) {
                String[] stringArray = string.trim().split(",");
                if (stringArray.length != 5) continue;
                Bottom bottom = new Bottom();
                bottom.moved = true;
                bottom.right = stringArray[1].equals("R");
                bottom.bottom = stringArray[2].equals("B");
                bottom.ox = Float.parseFloat(stringArray[3]);
                bottom.oy = Float.parseFloat(stringArray[4]);
                this.places.put(Watermark.valueOf(stringArray[0]), bottom);
            }
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private void save() {
        try {
            if (this.file == null) return;
            StringBuilder stringBuilder = new StringBuilder();
            for (Map.Entry<Watermark, Bottom> entry : this.places.entrySet()) {
                Bottom bottom = entry.getValue();
                if (!bottom.moved) continue;
                stringBuilder.append(entry.getKey().name()).append(',').append(bottom.right ? "R" : "L").append(',').append(bottom.bottom ? "B" : "T").append(',').append(String.format(Locale.ROOT, "%.1f,%.1f", Float.valueOf(bottom.ox), Float.valueOf(bottom.oy))).append('\n');
            }
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Files.writeString(this.file, (CharSequence)stringBuilder.toString(), StandardCharsets.UTF_8, new OpenOption[0]);
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private static float[] lmbd$anim$0(float f, String string) {
        return new float[]{f};
    }

    private static Presence lmbd$drawModules$1(String string) {
        return new Presence();
    }

    private int lmbd$drawModules$0(BaseRenderer baseRenderer, float f, String string, String string2) {
        int n = Float.compare(this.textW(baseRenderer, string2, f, 0), this.textW(baseRenderer, string, f, 0));
        return n != 0 ? n : string.compareTo(string2);
    }

    private void lmbd$render$8(BaseRenderer baseRenderer, HudInfo hudInfo, NetherCoords netherCoords, float f, float f2) {
        this.drawCoords(baseRenderer, f, f2, hudInfo, netherCoords);
    }

    private float[] lmbd$render$7(BaseRenderer baseRenderer, HudInfo hudInfo, NetherCoords netherCoords) {
        return this.coordsSize(baseRenderer, hudInfo, netherCoords);
    }

    private void lmbd$render$6(BaseRenderer baseRenderer, HudInfo hudInfo, float f, float f2) {
        this.drawPlayer(baseRenderer, f, f2, hudInfo);
    }

    private float[] lmbd$render$5(BaseRenderer baseRenderer, HudInfo hudInfo) {
        return this.playerSize(baseRenderer, hudInfo);
    }

    private void lmbd$render$4(BaseRenderer baseRenderer, HudInfo hudInfo, float f, float f2) {
        this.drawInfo(baseRenderer, f, f2, hudInfo);
    }

    private float[] lmbd$render$3(BaseRenderer baseRenderer, HudInfo hudInfo) {
        return this.infoSize(baseRenderer, hudInfo);
    }

    private void lmbd$render$2(BaseRenderer baseRenderer, NetherCoords netherCoords, float f, float f2) {
        this.drawWatermark(baseRenderer, f, f2, netherCoords);
    }

    private float[] lmbd$render$1(BaseRenderer baseRenderer, NetherCoords netherCoords) {
        return this.watermarkSize(baseRenderer, netherCoords);
    }

    private static Bottom lmbd$render$0(Watermark watermark) {
        return new Bottom();
    }
}
