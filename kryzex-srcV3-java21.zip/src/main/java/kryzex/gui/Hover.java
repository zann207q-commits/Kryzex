package kryzex.gui;

final class Hover {
    float hover;
    long last = System.nanoTime();

    public Hover() {
    }
}
