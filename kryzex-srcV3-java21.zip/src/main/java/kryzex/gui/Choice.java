package kryzex.gui;

import kryzex.gui.ListeningModule;
import kryzex.gui.StepSettingRow;
import kryzex.module.Module;
import kryzex.module.settings.ModeSetting;

final class Choice
extends StepSettingRow {
    private final ModeSetting choice;

    Choice(Module module, ModeSetting modeSetting) {
        super(module, modeSetting);
        this.choice = modeSetting;
    }

    @Override
    String value() {
        return ListeningModule.pretty(this.choice.getMode());
    }

    @Override
    void step(int n) {
        if (n > 0) {
            this.choice.cycleUp();
            return;
        } else {
            this.choice.cycleDown();
        }
    }
}
