package kryzex.gui;

public final class CapHeight {
    public final float capHeight;
    public final float tracking;
    public final float drawScale;
    final boolean[] present = new boolean[95];
    final float[] advance = new float[95];
    final int[] u = new int[95];
    final int[] v = new int[95];
    final int[] w = new int[95];
    final int[] h = new int[95];
    final int[] offsetX = new int[95];
    final int[] offsetY = new int[95];

    CapHeight(float f, float f2, float f3) {
        this.capHeight = f;
        this.tracking = f2;
        this.drawScale = f3;
    }

    boolean has(char c) {
        if (c < ' ') return false;
        if (c >= '\u007f') return false;
        if (!this.present[c - 32]) return false;
        return true;
    }
}
