package kryzex.gui;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import kryzex.gui.Alpha;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Bottom2;
import kryzex.gui.Handle;
import kryzex.gui.HudConfig;
import kryzex.gui.HudElement;
import kryzex.gui.HudInfo;
import kryzex.gui.Insampler;
import kryzex.gui.KryzexLoadingBrand;
import kryzex.gui.LabelColor;
import kryzex.gui.LastSource;
import kryzex.gui.MarkStore;
import kryzex.gui.PixelUnit;
import kryzex.gui.Presence2;
import kryzex.gui.DropdownFont;
import kryzex.gui.SpeakerOff;
import kryzex.gui.SquareCorners;
import kryzex.gui.Theme;
import kryzex.gui.RadarSource;
import kryzex.gui.GuiEasing;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class Clock {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final float EDGE = 8.0f;
    private static final float RADIUS = 7.0f;
    private static final float PAD = 10.0f;
    private static final float ROW = 24.0f;
    private static final float SEG_GAP = 14.0f;
    private static final float ICON = 13.0f;
    private static final float RADAR_D = 150.0f;
    private static final float RADAR_PAD = 11.0f;
    private static final float MOD_ROW_H = 19.0f;
    private static final float MOD_PAD = 8.0f;
    private static final float RAIL_W = 2.5f;
    private static final float LOGO_H = 10.5f;
    private static final int HOSTILE = -37266;
    private static final int PASSIVE = -9249128;
    private static final HudElement[] STACK = new HudElement[]{HudElement.WATERMARK, HudElement.INFO, HudElement.PLAYER, HudElement.RADAR};
    private static DropdownFont atlas;
    private static float atlasScale;
    private final SquareCorners p = new SquareCorners();
    private final Insampler backdrop = new Insampler();
    private final Map<HudElement, Bottom2> places = new EnumMap<HudElement, Bottom2>(HudElement.class);
    private final Map<HudElement, float[]> bounds = new EnumMap<HudElement, float[]>(HudElement.class);
    private final Map<String, float[]> anims = new HashMap<String, float[]>();
    private final Map<String, Presence2> rows = new LinkedHashMap<String, Presence2>();
    private final Map<Integer, Alpha> blips = new HashMap<Integer, Alpha>();
    private final MarkStore scan = new MarkStore();
    private final List<Runnable> overlays = new ArrayList<Runnable>();
    private Path file;
    private boolean loaded;
    private long last;
    private float dt;
    private float time;
    private float k = 1.0f;
    private float sw;
    private float sh;
    private float mouseX;
    private float mouseY;
    private HudElement dragging;
    private float grabX;
    private float grabY;
    private HudConfig settings = new HudConfig();
    private Handle logoTex;
    private int[] logoCrop;
    private BaseRenderer paint;

    public void setFile(Path path) {
        this.file = path;
    }

    public void render(class_332 class_3322, BaseRenderer baseRenderer, int n, int n2, HudInfo hudInfo, HudConfig hudConfig, RadarSource vf, float f, boolean bl, double d, double d2) {
        float[] object;
        long l = System.nanoTime();
        this.dt = this.last == 0L ? 0.016f : Math.min(0.1f, (float)(l - this.last) / 1.0E9f);
        this.last = l;
        this.time += this.dt;
        this.load();
        this.settings = hudConfig;
        this.paint = baseRenderer;
        this.k = Math.max(0.5f, (float)n2 / 1080.0f * 1.15f * hudConfig.scale);
        this.sw = (float)n / this.k;
        this.sh = (float)n2 / this.k;
        this.mouseX = (float)(d / (double)this.k);
        this.mouseY = (float)(d2 / (double)this.k);
        Clock.ensureAtlas(this.k, hudConfig.font);
        LastSource.accent(Theme.accent(1.0f) | 0xFF000000);
        if (this.dragging != null && (object = this.bounds.get((Object)this.dragging)) != null) {
            this.placeAt(this.places.computeIfAbsent(this.dragging, Clock::lmbd$render$0), this.mouseX - this.grabX, this.mouseY - this.grabY, (float)object[2], (float)object[3]);
        }
        Object object2 = this.backdrop.capture();
        this.overlays.clear();
        this.p.begin(atlas, this.k, f);
        boolean bl2 = hudInfo.inWorld();
        this.drawColumn(hudInfo, hudConfig, vf, bl2);
        this.drawModules(hudInfo, hudConfig);
        if (bl) {
            this.drawEditFrames();
        }
        this.p.submit(class_3322, (GpuTextureView)object2, this.backdrop.sampler());
        if (this.overlays.isEmpty()) return;
        class_3322.method_71048();
        baseRenderer.pushAlpha(f);
        try {
            for (Runnable runnable : this.overlays) {
                runnable.run();
            }
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    private List<LabelColor> segments(HudElement hudElement, HudInfo hudInfo, HudConfig hudConfig, boolean bl) {
        ArrayList<LabelColor> arrayList = new ArrayList<LabelColor>(3);
        if (hudElement == HudElement.WATERMARK) {
            if (hudConfig.watermark) {
                arrayList.add(new LabelColor(null, "", "", 0, true));
            }
            if (hudConfig.info && bl) {
                arrayList.add(new LabelColor("fps", String.valueOf(hudInfo.fps()), "FPS", -723976, false));
            }
            if (!hudConfig.time) return arrayList;
            arrayList.add(new LabelColor("clock", Clock.clock(), "", 0, false));
            return arrayList;
        } else {
            String[] stringArray;
            if (hudElement != HudElement.INFO || !bl) return arrayList;
            if (hudConfig.coords) {
                stringArray = Clock.axes(hudInfo, false);
                arrayList.add(new LabelColor("compass", stringArray[0] + " " + stringArray[1] + " " + stringArray[2], hudConfig.direction ? Clock.facing(hudInfo.yaw()) : "", this.accent(0.9f, 0.0f), false));
            }
            if (hudConfig.netherCoords) {
                stringArray = Clock.axes(hudInfo, true);
                arrayList.add(new LabelColor("portal", stringArray[0] + " " + stringArray[2], hudInfo.nether() ? "OW" : "NETHER", LastSource.withAlpha(-3553071, 0.6f), false));
            }
            if (!hudConfig.info) return arrayList;
            arrayList.add(new LabelColor("ping", hudInfo.ping(), "PING", -723976, false));
        }
        return arrayList;
    }

    private float segW(LabelColor labelColor) {
        if (labelColor.logo()) {
            return this.logoW();
        }
        float f = 18.0f + this.p.textWidth(labelColor.value());
        return labelColor.label().isEmpty() ? f : f + 4.5f + this.p.textWidth(labelColor.label());
    }

    private float segsW(List<LabelColor> list) {
        float f = 0.0f;
        for (int i = 0; i < list.size(); ++i) {
            f += this.segW(list.get(i)) + (i > 0 ? 14.0f : 0.0f);
        }
        return 10.0f + f + 10.0f;
    }

    private void drawSegs(List<LabelColor> list, float f, float f2) {
        float f3 = f + 10.0f;
        for (LabelColor labelColor : list) {
            if (labelColor.logo()) {
                this.drawLogo(f3, f2);
            } else {
                this.p.icon(labelColor.icon(), f3 + 6.5f, f2, this.accent(1.0f, 0.0f), 1.0f);
                float f4 = f3 + 13.0f + 5.0f;
                this.p.text(labelColor.value(), f4, f2, -723976);
                if (!labelColor.label().isEmpty()) {
                    this.p.text(labelColor.label(), f4 + this.p.textWidth(labelColor.value()) + 4.5f, f2, labelColor.labelColor());
                }
            }
            f3 += this.segW(labelColor) + 14.0f;
        }
    }

    private boolean wanted(HudElement hudElement, HudInfo hudInfo, HudConfig hudConfig, boolean bl) {
        switch (hudElement.ordinal()) {
            case 0:
            case 1: {
                if (this.segments(hudElement, hudInfo, hudConfig, bl).isEmpty()) return false;
                return true;
            }
            case 2: {
                if (!hudConfig.player) return false;
                if (!bl) return false;
                return true;
            }
            case 3: {
                if (!hudConfig.radar) return false;
                if (!bl) return false;
                return true;
            }
            default: {
                return false;
            }
        }
    }

    private float naturalW(HudElement hudElement, HudInfo hudInfo, HudConfig hudConfig, boolean bl) {
        float f;
        switch (hudElement.ordinal()) {
            case 2: {
                f = 34.0f + this.p.textWidth(hudInfo.playerName()) + 16.0f + 11.0f + 5.0f + this.p.textWidth(Clock.hp(hudInfo)) + 10.0f;
                return f;
            }
            case 3: {
                return 170.0f;
            }
            default: {
                f = this.segsW(this.segments(hudElement, hudInfo, hudConfig, bl));
            }
        }
        return f;
    }

    private static float lineH(HudElement hudElement) {
        if (hudElement != HudElement.RADAR) return 24.0f;
        return 172.0f;
    }

    private void drawColumn(HudInfo hudInfo, HudConfig hudConfig, RadarSource vf, boolean bl) {
        float f;
        float f2;
        int n;
        int n2 = 0;
        HudElement[] hudElementArray = new HudElement[STACK.length];
        float[] fArray = new float[STACK.length];
        float[] fArray2 = new float[STACK.length];
        float[] fArray3 = new float[STACK.length];
        HudElement[] hudElementArray2 = STACK;
        int n3 = hudElementArray2.length;
        for (n = 0; n < n3; ++n) {
            HudElement hudElement = hudElementArray2[n];
            boolean bl2 = !this.moved(hudElement) && this.wanted(hudElement, hudInfo, hudConfig, bl);
            f2 = this.anim("stack:" + String.valueOf((Object)hudElement), bl2 ? 1.0f : 0.0f, 10.0f);
            if (f2 <= 0.002f || this.moved(hudElement)) {
                if (this.moved(hudElement)) continue;
                this.bounds.remove((Object)hudElement);
                continue;
            }
            float f3 = this.naturalW(hudElement, hudInfo, hudConfig, bl);
            float[] fArray4 = this.anims.computeIfAbsent("w:" + String.valueOf((Object)hudElement), arg_0 -> Clock.lmbd$drawColumn$0(f3, arg_0));
            fArray4[0] = fArray4[0] + (f3 - fArray4[0]) * (1.0f - (float)Math.exp((f3 > fArray4[0] ? -16.0f : -6.0f) * this.dt));
            hudElementArray[n2] = hudElement;
            fArray[n2] = this.snap(fArray4[0] * (0.6f + 0.4f * GuiEasing.outCubic(f2)));
            fArray2[n2] = Clock.lineH(hudElement) * GuiEasing.outCubic(f2);
            fArray3[n2] = f2;
            ++n2;
        }
        float f4 = 8.0f;
        float f5 = 8.0f;
        for (n = 0; n < n2; ++n) {
            float f6 = fArray[n];
            float f7 = this.snap(f5);
            f2 = this.snap(f5 + fArray2[n]);
            f5 += fArray2[n];
            if (f2 - f7 < 0.5f) continue;
            boolean bl3 = n > 0;
            boolean bl4 = n < n2 - 1;
            f = bl3 ? fArray[n - 1] : 0.0f;
            float f8 = bl4 ? fArray[n + 1] : 0.0f;
            boolean bl5 = f < f6 - 0.5f;
            boolean bl6 = f8 < f6 - 0.5f;
            float f9 = 7.0f;
            if (bl5 && bl3) {
                f9 = Math.min(f9, f6 - f);
            }
            if (bl6 && bl4) {
                f9 = Math.min(f9, f6 - f8);
            }
            int n4 = (bl3 ? 1 : 0) | (bl4 ? 4 : 0) | (bl5 ? 0 : 2) | (bl6 ? 0 : 8);
            float f10 = GuiEasing.outCubic(fArray3[n]);
            this.p.alpha(f10);
            this.pill(f4, f7, f4 + f6, f2, f9, n4, bl3, bl4);
            int n5 = this.p.clipState();
            this.p.clip(f7, f2);
            if (bl3) {
                this.p.rect(f4 + 10.0f, f7, f4 + Math.min(f6, f) - 10.0f, f7 + this.p.pixel(), n == 1 && hudElementArray[0] == HudElement.WATERMARK ? 0 : 0x10FFFFFF);
            }
            this.line(hudElementArray[n], f4, f7, f6, hudInfo, hudConfig, vf, bl);
            if (hudElementArray[n] == HudElement.WATERMARK && bl4) {
                int n6 = LastSource.withAlpha(this.accent(1.0f, 0.0f), 0.5f);
                float f11 = f4 + Math.min(f6, f8) - 10.0f;
                this.p.gradient(f4 + 10.0f, f2 - this.p.pixel(), f11, f2, 0.0f, n6, n6 & 0xFFFFFF, n6 & 0xFFFFFF, n6);
            }
            this.p.restoreClip(n5);
            this.p.alpha(1.0f);
            this.bounds.put(hudElementArray[n], new float[]{f4, f7, f6, f2 - f7});
        }
        for (HudElement hudElement : STACK) {
            if (!this.moved(hudElement)) continue;
            float f12 = this.anim("solo:" + String.valueOf((Object)hudElement), this.wanted(hudElement, hudInfo, hudConfig, bl) ? 1.0f : 0.0f, 10.0f);
            if (f12 < 0.01f) {
                this.bounds.remove((Object)hudElement);
                continue;
            }
            float f13 = this.snap(this.naturalW(hudElement, hudInfo, hudConfig, bl));
            f = this.snap(Clock.lineH(hudElement));
            float[] fArray5 = this.position(hudElement, f13, f);
            this.p.alpha(GuiEasing.outCubic(f12));
            this.pill(fArray5[0], fArray5[1], fArray5[0] + f13, fArray5[1] + f, 7.0f, 0, false, false);
            this.line(hudElement, fArray5[0], fArray5[1], f13, hudInfo, hudConfig, vf, bl);
            this.p.alpha(1.0f);
            this.bounds.put(hudElement, new float[]{fArray5[0], fArray5[1], f13, f});
        }
    }

    private void pill(float f, float f2, float f3, float f4, float f5, int n, boolean bl, boolean bl2) {
        this.p.squareCorners(n);
        this.p.seamless(false, false);
        this.p.shadow(f, f2 + 2.0f, f3, f4 + 2.0f, Math.max(0.5f, f5), 8.0f, 0x48000000);
        this.p.seamless(bl, bl2);
        this.p.glass(f, f2, f3, f4, Math.max(0.0f, f5), this.tint());
        this.p.squareCorners(0);
        this.p.seamless(false, false);
    }

    private int tint() {
        float f = 0.36f + 0.56f * Math.max(0.0f, Math.min(1.0f, this.settings.opacity));
        return LastSource.withAlpha(-15330020, f);
    }

    private void line(HudElement hudElement, float f, float f2, float f3, HudInfo hudInfo, HudConfig hudConfig, RadarSource vf, boolean bl) {
        switch (hudElement.ordinal()) {
            case 0:
            case 1: {
                this.drawSegs(this.segments(hudElement, hudInfo, hudConfig, bl), f, f2 + 12.0f);
                return;
            }
            case 2: {
                this.player(f, f2, f3, hudInfo);
                return;
            }
            case 3: {
                this.radar(f, f2, f3, vf, hudConfig);
                return;
            }
        }
    }

    private void drawLogo(float f, float f2) {
        float f3 = this.logoW();
        float f4 = 0.5f + 0.5f * (float)Math.sin(this.time * 1.1f);
        this.p.shadow(f + 6.0f, f2 - 2.0f, f + f3 - 6.0f, f2 + 2.0f, 2.0f, 9.0f, LastSource.withAlpha(this.accent(1.0f, 0.0f), 0.16f + 0.06f * f4));
        float f5 = this.p.alpha();
        float f6 = Math.round(f * this.k);
        float f7 = Math.round((f2 - 5.25f) * this.k);
        int n = Math.max(1, Math.round(f3 * this.k));
        int n2 = Math.max(1, Math.round(10.5f * this.k));
        int n3 = this.p.clipState();
        float f8 = n3 & 0xFFFF;
        float f9 = n3 >>> 16;
        this.overlays.add(() -> this.lmbd$drawLogo$0(n, n2, f7, f8, f9, f5, f6));
    }

    private static String hp(HudInfo hudInfo) {
        float f = Math.max(0.0f, hudInfo.health());
        return f == (float)Math.round(f) ? String.valueOf(Math.round(f)) : String.format(Locale.ROOT, "%.1f", Float.valueOf(f));
    }

    private void player(float f, float f2, float f3, HudInfo hudInfo) {
        float f4 = f2 + 12.0f;
        float f5 = 15.0f;
        float f6 = this.p.alpha();
        float f7 = Math.round((f + 10.0f) * this.k);
        float f8 = Math.round((f4 - f5 / 2.0f) * this.k);
        float f9 = Math.round(f5 * this.k);
        this.overlays.add(() -> this.lmbd$player$0(f6, f7, f8, f9));
        String string = Clock.hp(hudInfo);
        float f10 = this.p.textWidth(string);
        float f11 = f + 10.0f + f5 + 8.0f;
        this.p.text(hudInfo.playerName(), f11, f4, -723976, Math.max(10.0f, f + f3 - 10.0f - f10 - 21.0f - f11));
        this.p.textRight(string, f + f3 - 10.0f, f4, -723976);
        this.p.icon("heart", f + f3 - 10.0f - f10 - 10.5f, f4, -38019, 0.85f);
    }

    private static String[] axes(HudInfo hudInfo, boolean bl) {
        double d = bl ? (hudInfo.nether() ? 8.0 : 0.125) : 1.0;
        return new String[]{String.valueOf((long)Math.floor(hudInfo.x() * d)), String.valueOf((long)Math.floor(hudInfo.y())), String.valueOf((long)Math.floor(hudInfo.z() * d))};
    }

    private static String facing(float f) {
        String[] stringArray = new String[]{"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        return stringArray[Math.floorMod(Math.round(f % 360.0f / 45.0f), 8)];
    }

    private void radar(float f, float f2, float f3, RadarSource vf, HudConfig hudConfig) {
        float f4;
        float f5;
        float f6;
        float f7;
        float f82;
        float f9 = 150.0f;
        float f10 = f9 / 2.0f;
        float f11 = f + f3 / 2.0f;
        float f12 = f2 + 11.0f + f10;
        float f13 = this.p.pixel();
        this.p.roundRect(f11 - f10, f12 - f10, f11 + f10, f12 + f10, f10, 0x30000000);
        this.p.stroke(f11 - f10, f12 - f10, f11 + f10, f12 + f10, f10, f13, 0x1EFFFFFF);
        for (float f83 : new float[]{0.66f, 0.33f}) {
            f7 = f10 * f83;
            this.p.stroke(f11 - f7, f12 - f7, f11 + f7, f12 + f7, f7, f13, 0xDFFFFFF);
        }
        this.p.rect(f11 - f10 + 7.0f, f12 - f13 / 2.0f, f11 + f10 - 7.0f, f12 + f13 / 2.0f, 0xAFFFFFF);
        this.p.rect(f11 - f13 / 2.0f, f12 - f10 + 7.0f, f11 + f13 / 2.0f, f12 + f10 - 7.0f, 0xAFFFFFF);
        if (vf == null) {
            return;
        }
        double d = Math.toRadians(vf.yaw());
        float f14 = (float)(-Math.cos(d));
        f82 = (float)(-Math.sin(d));
        f7 = (float)(-Math.sin(d));
        float f15 = (float)Math.cos(d);
        String[] stringArray = new String[]{"N", "E", "S", "W"};
        float[][] fArrayArray = new float[][]{{0.0f, -1.0f},new float[]{1.0f, 0.0f},new float[]{0.0f, 1.0f},new float[]{-1.0f, 0.0f}};
        for (int i = 0; i < 4; ++i) {
            f6 = fArrayArray[i][0] * f14 + fArrayArray[i][1] * f82;
            float f16 = -(fArrayArray[i][0] * f7 + fArrayArray[i][1] * f15);
            float f17 = f10 - 8.5f;
            f5 = i == 0 ? 0.62f : 0.5f;
            int n = i == 0 ? this.accent(1.0f, 0.0f) : LastSource.withAlpha(-3553071, 0.55f);
            f4 = this.p.smallWidth(stringArray[i], f5);
            this.p.smallText(stringArray[i], f11 + f6 * f17 - f4 / 2.0f, f12 + f16 * f17, n, f5);
        }
        float f18 = Math.max(4.0f, hudConfig.radarRange);
        this.scan.clear();
        vf.scan(f18 * 1.1f, hudConfig.radarMobs, this.scan);
        f6 = (f10 - 3.0f) / f18;
        for (Alpha alpha : this.blips.values()) {
            alpha.seen = false;
        }
        for (int i = 0; i < this.scan.count; ++i) {
            Alpha alpha = this.blips.computeIfAbsent(this.scan.id[i], Clock::lmbd$radar$0);
            alpha.seen = true;
            alpha.kind = this.scan.kind[i];
            f5 = this.scan.dx[i];
            float f19 = this.scan.dz[i];
            alpha.sx = (f5 * f14 + f19 * f82) * f6;
            alpha.sy = -(f5 * f7 + f19 * f15) * f6;
            alpha.dy = this.scan.dy[i];
        }
        Iterator<Alpha> iterator = this.blips.values().iterator();
        while (iterator.hasNext()) {
            Alpha alpha = iterator.next();
            alpha.alpha = alpha.alpha + ((alpha.seen ? 1.0f : 0.0f) - alpha.alpha) * (1.0f - (float)Math.exp(-(alpha.seen ? 9.0f : 6.0f) * this.dt));
            if (alpha.seen || !(alpha.alpha < 0.02f)) continue;
            iterator.remove();
        }
        for (int i = 2; i >= 0; --i) {
            for (Alpha alpha : this.blips.values()) {
                int n = 0;
                float f20;
                float f21;
                float f22;
                if (alpha.kind != i || (f22 = alpha.alpha * (f4 = 1.0f - GuiEasing.smooth(((f21 = (float)Math.sqrt(alpha.sx * alpha.sx + alpha.sy * alpha.sy)) - (f10 - 14.0f)) / 10.0f)) * (f20 = 1.0f - 0.5f * GuiEasing.smooth((Math.abs(alpha.dy) - 6.0f) / 22.0f))) <= 0.01f) continue;
                float f23 = f11 + alpha.sx;
                float f24 = f12 + alpha.sy;
                int n2 = alpha.kind == 0 ? this.accent(1.0f, 0.0f) : (n = alpha.kind == 1 ? -37266 : -9249128);
                float f25 = alpha.kind == 0 ? 3.0f : (alpha.kind == 1 ? 2.4f : 2.1f);
                this.p.circle(f23, f24, f25, alpha.kind == 0 ? 4.5f : 3.0f, LastSource.withAlpha(n, f22));
                if (alpha.kind != 0) continue;
                this.p.circle(f23, f24, 1.2f, LastSource.withAlpha(-1, f22 * 0.9f));
            }
        }
        this.p.circle(f11, f12, 3.0f, 8.0f, LastSource.withAlpha(this.accent(1.0f, 0.0f), 0.32f));
        this.p.icon("arrow", f11, f12, -591877, 0.92f);
        String string = Math.round(f18) + "m";
        float f26 = this.p.smallWidth(string, 0.5f);
        this.p.smallText(string, f11 + f10 * 0.7071f + 2.0f - f26, f12 + f10 * 0.7071f + 4.0f, LastSource.withAlpha(-3553071, 0.4f), 0.5f);
    }

    private void drawModules(HudInfo hudInfo, HudConfig hudConfig) {
        int var19_32 = 0;
        Object object;
        float f = this.anim("el:MODULES", hudConfig.modules ? 1.0f : 0.0f, 9.0f);
        ArrayList<String> arrayList = hudConfig.modules ? new ArrayList<String>(hudInfo.modules()) : new ArrayList();
        arrayList.sort(this.order(hudConfig));
        for (Presence2 object4 : this.rows.values()) {
            object4.active = false;
        }
        int n = 0;
        while (n < arrayList.size()) {
            Presence2 presence2 = this.rows.computeIfAbsent((String)arrayList.get(n), Clock::lmbd$drawModules$0);
            presence2.active = true;
            presence2.index = n++;
        }
        float f2 = 57.0f;
        for (String string : arrayList) {
            f2 = Math.max(f2, this.rowW(string));
        }
        float f3 = Math.max(19.0f, (float)arrayList.size() * 19.0f);
        if (f < 0.01f && this.rows.isEmpty()) {
            this.bounds.remove((Object)HudElement.MODULES);
            return;
        }
        float[] fArray = this.position(HudElement.MODULES, f2, f3);
        boolean bl = fArray[0] + f2 / 2.0f > this.sw / 2.0f;
        float f4 = bl ? fArray[0] + f2 : fArray[0];
        float f5 = fArray[1];
        this.bounds.put(HudElement.MODULES, new float[]{fArray[0], f5, f2, f3});
        float f6 = 1.0f - (float)Math.exp(-13.0f * this.dt);
        ArrayList<String> arrayList2 = new ArrayList<String>();
        ArrayList<Object[]> arrayList3 = new ArrayList<Object[]>();
        for (Map.Entry<String, Presence2> entry : this.rows.entrySet()) {
            object = entry.getValue();
            if (((Presence2)object).active) {
                ((Presence2)object).target = (float)((Presence2)object).index * 19.0f;
            }
            if (Float.isNaN(((Presence2)object).y)) {
                ((Presence2)object).y = ((Presence2)object).target;
            }
            ((Presence2)object).y += (((Presence2)object).target - ((Presence2)object).y) * f6;
            ((Presence2)object).presence = ((Presence2)object).presence + ((((Presence2)object).active ? 1.0f : 0.0f) - ((Presence2)object).presence) * (1.0f - (float)Math.exp(-11.0f * this.dt));
            if (!((Presence2)object).active && ((Presence2)object).presence < 0.015f) {
                arrayList2.add(entry.getKey());
                continue;
            }
            arrayList3.add(new Object[]{entry.getKey(), object});
        }
        arrayList2.forEach(this.rows::remove);
        arrayList3.sort(Clock::lmbd$drawModules$1);
        int n2 = arrayList3.size();
        float[] fArray2 = new float[n2];
        float[] object5 = new float[n2];
        for (int i = 0; i < n2; ++i) {
            Presence2 presence2 = (Presence2)((Object[])arrayList3.get(i))[1];
            float f7 = GuiEasing.outCubic(presence2.presence);
            fArray2[i] = this.snap(this.rowW((String)((Object[])arrayList3.get(i))[0]) * (0.35f + 0.65f * f7));
            object5[i] = this.snap(f5 + presence2.y);
        }
        this.p.alpha(GuiEasing.outCubic(f));
        float object2 = Float.NaN;
        float f8 = Float.NaN;
        boolean bl2 = false;
        while (var19_32 < n2) {
            int n3;
            String string = (String)((Object[])arrayList3.get((int)var19_32))[0];
            Presence2 presence2 = (Presence2)((Object[])arrayList3.get((int)var19_32))[1];
            float f9 = fArray2[var19_32];
            float object3 = object5[var19_32];
            float f10 = this.snap((float)(object3 + 19.0f));
            boolean bl3 = var19_32 > 0 && Math.abs((float)(object5[var19_32 - 1] + 19.0f - object3)) < 1.5f;
            boolean bl4 = var19_32 < n2 - 1 && Math.abs((float)(object3 + 19.0f - object5[var19_32 + 1])) < 1.5f;
            float f11 = bl3 ? fArray2[var19_32 - 1] : 0.0f;
            float f12 = bl4 ? fArray2[var19_32 + 1] : 0.0f;
            boolean bl5 = f11 < f9 - 0.5f;
            boolean bl6 = f12 < f9 - 0.5f;
            float f13 = 5.0f;
            if (bl5 && bl3) {
                f13 = Math.min(f13, f9 - f11);
            }
            if (bl6 && bl4) {
                f13 = Math.min(f13, f9 - f12);
            }
            int n4 = n3 = bl ? 10 : 5;
            if (!bl5) {
                n3 |= bl ? 1 : 2;
            }
            if (!bl6) {
                n3 |= bl ? 4 : 8;
            }
            float f14 = bl ? f4 - f9 : f4;
            float f15 = bl ? f4 : f4 + f9;
            float f16 = (1.0f - GuiEasing.outCubic(presence2.presence)) * 14.0f * (bl ? 1.0f : -1.0f);
            this.p.alpha(GuiEasing.outCubic(f) * GuiEasing.outCubic(presence2.presence));
            this.p.squareCorners(n3);
            this.p.shadow(f14 + f16, (float)(object3 + 2.0f), f15 + f16, f10 + 2.0f, Math.max(1.0f, f13), 7.0f, 0x3A000000);
            this.p.seamless(bl3, bl4);
            this.p.glass(f14 + f16, (float)object3, f15 + f16, f10, Math.max(0.0f, f13), this.tint());
            this.p.squareCorners(0);
            this.p.seamless(false, false);
            int n5 = hudConfig.rainbow ? this.accent(1.0f, (float)presence2.index * 0.045f) : -723976;
            float f17 = bl ? f14 + 8.0f : f14 + 2.5f + 8.0f;
            this.p.text(string, f17 + f16, (float)((object3 + f10) / 2.0f), n5);
            if (hudConfig.rainbow) {
                this.p.rect(bl ? f15 - 2.5f + f16 : f14 + f16, (float)object3, bl ? f15 + f16 : f14 + 2.5f + f16, f10, this.accent(1.0f, (float)presence2.index * 0.045f));
            }
            object2 = Float.isNaN(object2) ? object3 : Math.min(object2, object3);
            f8 = Float.isNaN(f8) ? f10 : Math.max(f8, f10);
            ++var19_32;
        }
        if (!hudConfig.rainbow && !Float.isNaN(object2)) {
            this.p.alpha(GuiEasing.outCubic(f));
            float f18 = bl ? f4 - 2.5f : f4;
            float f19 = f18 + 2.5f;
            this.p.shadow(f18, (float)object2, f19, f8, 1.0f, 6.0f, LastSource.GLOW);
            this.p.roundRect(f18, (float)object2, f19, f8, 1.25f, LastSource.ACCENT);
        }
        this.p.alpha(1.0f);
    }

    private Comparator<String> order(HudConfig hudConfig) {
        Comparator<String> comparator;
        Comparator<String> comparator2 = this::lmbd$order$0;
        Comparator<String> comparator3 = String.CASE_INSENSITIVE_ORDER;
        switch (hudConfig.sort.ordinal()) {
            case 1: {
                comparator = comparator2.reversed().thenComparing(comparator3);
                return comparator;
            }
            case 2: {
                comparator = Comparator.comparingInt((String arg_0) -> Clock.lmbd$order$1(hudConfig, arg_0)).thenComparing(comparator2).thenComparing(comparator3);
                return comparator;
            }
            case 3: {
                comparator = comparator3;
                return comparator;
            }
            default: {
                comparator = comparator2.thenComparing(comparator3);
            }
        }
        return comparator;
    }

    private float rowW(String string) {
        return 8.0f + this.p.textWidth(string) + 8.0f + 2.5f;
    }

    private void drawEditFrames() {
        for (Map.Entry<HudElement, float[]> entry : this.bounds.entrySet()) {
            float[] fArray = entry.getValue();
            boolean bl = this.dragging == entry.getKey() || this.inside(fArray, this.mouseX, this.mouseY);
            float f = this.anim("edit:" + String.valueOf((Object)entry.getKey()), bl ? 1.0f : 0.0f, 14.0f);
            float f2 = 3.0f;
            this.p.stroke(fArray[0] - f2, fArray[1] - f2, fArray[0] + fArray[2] + f2, fArray[1] + fArray[3] + f2, 7.0f + f2, this.p.pixel() * 1.2f, LastSource.mix(0x33FFFFFF, LastSource.withAlpha(LastSource.ACCENT, 0.9f), f));
            if (!(f > 0.02f)) continue;
            String string = entry.getKey().label;
            float f3 = this.p.smallWidth(string, 0.6f) + 12.0f;
            boolean bl2 = fArray[0] + fArray[2] / 2.0f > this.sw / 2.0f;
            float f4 = bl2 ? fArray[0] - f2 - 6.0f - f3 : fArray[0] + fArray[2] + f2 + 6.0f;
            float f5 = fArray[1] + Math.min(fArray[3], 22.0f) / 2.0f;
            this.p.alpha(f);
            this.p.roundRect(f4, f5 - 8.0f, f4 + f3, f5 + 8.0f, 8.0f, -535093718);
            this.p.smallText(string, f4 + 6.0f, f5, -1117959, 0.6f);
            this.p.alpha(1.0f);
        }
    }

    private boolean inside(float[] fArray, float f, float f2) {
        if (!(f >= fArray[0])) return false;
        if (!(f < fArray[0] + fArray[2])) return false;
        if (!(f2 >= fArray[1])) return false;
        if (!(f2 < fArray[1] + fArray[3])) return false;
        return true;
    }

    public boolean mousePressed(double d, double d2) {
        HudElement[] hudElementArray;
        float f = (float)(d / (double)this.k);
        float f2 = (float)(d2 / (double)this.k);
        for (HudElement hudElement : hudElementArray = new HudElement[]{HudElement.MODULES, HudElement.COORDS, HudElement.RADAR, HudElement.PLAYER, HudElement.INFO, HudElement.WATERMARK}) {
            float[] fArray = this.bounds.get((Object)hudElement);
            if (fArray == null || !this.inside(fArray, f, f2)) continue;
            this.dragging = hudElement;
            this.grabX = f - fArray[0];
            this.grabY = f2 - fArray[1];
            return true;
        }
        return false;
    }

    public void mouseReleased() {
        if (this.dragging == null) return;
        HudElement hudElement = this.dragging;
        this.dragging = null;
        Bottom2 bottom2 = this.places.get((Object)hudElement);
        float[] fArray = this.bounds.get((Object)hudElement);
        if (bottom2 != null && fArray != null && Clock.isStack(hudElement) && fArray[0] < 30.0f && fArray[1] < this.stackBottom() + 26.0f) {
            bottom2.moved = false;
        }
        this.save();
    }

    private float stackBottom() {
        float f = 8.0f;
        for (HudElement hudElement : STACK) {
            float[] fArray = this.bounds.get((Object)hudElement);
            if (fArray == null || this.moved(hudElement)) continue;
            f = Math.max(f, fArray[1] + fArray[3]);
        }
        return f;
    }

    private static boolean isStack(HudElement hudElement) {
        if (hudElement == HudElement.WATERMARK) return true;
        if (hudElement == HudElement.INFO) return true;
        if (hudElement == HudElement.PLAYER) return true;
        if (hudElement != HudElement.RADAR) return false;
        return true;
    }

    public void resetLayout() {
        this.places.clear();
        this.save();
    }

    private boolean moved(HudElement hudElement) {
        Bottom2 bottom2 = this.places.get((Object)hudElement);
        if (bottom2 == null) return false;
        if (!bottom2.moved) return false;
        return true;
    }

    private float[] position(HudElement hudElement, float f, float f2) {
        float[] fArray;
        Bottom2 bottom2 = this.places.get((Object)hudElement);
        if (bottom2 != null && bottom2.moved) {
            float f3 = bottom2.right ? this.sw - bottom2.ox - f : bottom2.ox;
            float f4 = bottom2.bottom ? this.sh - bottom2.oy - f2 : bottom2.oy;
            return new float[]{this.snap(Clock.clamp(f3, 0.0f, this.sw - f)), this.snap(Clock.clamp(f4, 0.0f, this.sh - f2))};
        }
        switch (hudElement.ordinal()) {
            case 4: {
                float[] fArray2 = new float[2];
                fArray2[0] = 8.0f;
                fArray = fArray2;
                fArray2[1] = this.snap(this.sh - 8.0f - f2);
                return fArray;
            }
            case 5: {
                float[] fArray3 = new float[2];
                fArray3[0] = this.snap(this.sw - 8.0f - f);
                fArray = fArray3;
                fArray3[1] = 8.0f;
                return fArray;
            }
            default: {
                float[] fArray4 = new float[2];
                fArray4[0] = 8.0f;
                fArray = fArray4;
                fArray4[1] = 8.0f;
            }
        }
        return fArray;
    }

    private void placeAt(Bottom2 bottom2, float f, float f2, float f3, float f4) {
        f = Clock.clamp(f, 0.0f, this.sw - f3);
        f2 = Clock.clamp(f2, 0.0f, this.sh - f4);
        bottom2.moved = true;
        bottom2.right = f + f3 / 2.0f > this.sw / 2.0f;
        bottom2.bottom = f2 + f4 / 2.0f > this.sh / 2.0f;
        bottom2.ox = bottom2.right ? this.sw - f - f3 : f;
        bottom2.oy = bottom2.bottom ? this.sh - f2 - f4 : f2;
    }

    private void load() {
        if (this.loaded) {
            return;
        }
        this.loaded = true;
        try {
            if (this.file == null || !Files.isRegularFile(this.file, new LinkOption[0])) return;
            for (String string : Files.readAllLines(this.file, StandardCharsets.UTF_8)) {
                String[] stringArray = string.trim().split(",");
                if (stringArray.length != 5) continue;
                Bottom2 bottom2 = new Bottom2();
                bottom2.moved = true;
                bottom2.right = stringArray[1].equals("R");
                bottom2.bottom = stringArray[2].equals("B");
                bottom2.ox = Float.parseFloat(stringArray[3]);
                bottom2.oy = Float.parseFloat(stringArray[4]);
                this.places.put(HudElement.valueOf(stringArray[0]), bottom2);
            }
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private void save() {
        try {
            if (this.file == null) return;
            StringBuilder stringBuilder = new StringBuilder();
            for (Map.Entry<HudElement, Bottom2> entry : this.places.entrySet()) {
                Bottom2 bottom2 = entry.getValue();
                if (!bottom2.moved) continue;
                stringBuilder.append(entry.getKey().name()).append(',').append(bottom2.right ? "R" : "L").append(',').append(bottom2.bottom ? "B" : "T").append(',').append(String.format(Locale.ROOT, "%.1f,%.1f", Float.valueOf(bottom2.ox), Float.valueOf(bottom2.oy))).append('\n');
            }
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Files.writeString(this.file, (CharSequence)stringBuilder.toString(), StandardCharsets.UTF_8, new OpenOption[0]);
            return;
        }
        catch (Throwable throwable) {

        }
    }

    private float snap(float f) {
        return (float)Math.round(f * this.k) / this.k;
    }

    private float anim(String string, float f, float f2) {
        float[] fArray = this.anims.computeIfAbsent(string, arg_0 -> Clock.lmbd$anim$0(f, arg_0));
        fArray[0] = fArray[0] + (f - fArray[0]) * (1.0f - (float)Math.exp(-f2 * this.dt));
        if (!(Math.abs(f - fArray[0]) < 0.001f)) return fArray[0];
        fArray[0] = f;
        return fArray[0];
    }

    private int accent(float f, float f2) {
        if (!this.settings.rainbow) {
            return LastSource.withAlpha(LastSource.ACCENT, f);
        }
        float f3 = (this.time * 0.08f * this.settings.rainbowSpeed + f2) % 1.0f;
        int n = Color.HSBtoRGB(f3 < 0.0f ? f3 + 1.0f : f3, 0.5f, 1.0f) & 0xFFFFFF;
        return Math.round(Math.max(0.0f, Math.min(1.0f, f)) * 255.0f) << 24 | n;
    }

    private static String clock() {
        return LocalTime.now().format(CLOCK);
    }

    private static float clamp(float f, float f2, float f3) {
        return f3 < f2 ? f2 : Math.max(f2, Math.min(f3, f));
    }

    private float logoW() {
        int[] nArray = this.crop();
        if (nArray == null) {
            return 136.5f;
        }
        float f = 10.5f * (float)nArray[2] / (float)nArray[3];
        return f;
    }

    private int[] crop() {
        if (this.logoCrop != null) return this.logoCrop;
        try {
            Handle handle = KryzexLoadingBrand.logo();
            int n = handle.w;
            int n2 = handle.h;
            int n3 = -1;
            int n4 = -1;
            for (int i = 0; i < handle.h; ++i) {
                for (int j = 0; j < handle.w; ++j) {
                    if (handle.argb[i * handle.w + j] >>> 24 <= 10) continue;
                    n = Math.min(n, j);
                    n2 = Math.min(n2, i);
                    n3 = Math.max(n3, j);
                    n4 = Math.max(n4, i);
                }
            }
            if (n3 <= n || n4 <= n2) return this.logoCrop;
            this.logoCrop = new int[]{n, n2, n3 - n + 1, n4 - n2 + 1};
            return this.logoCrop;
        }
        catch (Throwable throwable) {
            this.logoCrop = null;
        }
        return this.logoCrop;
    }

    private Handle logo(int n, int n2) {
        Object object;
        if (this.logoTex != null && this.logoTex.w == n && this.logoTex.h == n2) {
            return this.logoTex;
        }
        int[] nArray = this.crop();
        if (nArray == null) {
            return null;
        }
        Handle handle = KryzexLoadingBrand.logo();
        int n3 = nArray[2];
        int n4 = nArray[3];
        float[] fArray = new float[n3 * n4 * 4];
        for (int i = 0; i < n4; ++i) {
            for (int j = 0; j < n3; ++j) {
                int n5 = handle.argb[(nArray[1] + i) * handle.w + nArray[0] + j];
                float f = (float)(n5 >>> 24) / 255.0f;
                int n6 = (i * n3 + j) * 4;
                fArray[n6] = f;
                fArray[n6 + 1] = (float)(n5 >> 16 & 0xFF) / 255.0f * f;
                fArray[n6 + 2] = (float)(n5 >> 8 & 0xFF) / 255.0f * f;
                fArray[n6 + 3] = (float)(n5 & 0xFF) / 255.0f * f;
            }
        }
        float[] fArray2 = Clock.boxResample(fArray, n3, n4, n, true);
        float[] fArray3 = Clock.boxResample(fArray2, n, n4, n2, false);
        int[] nArray2 = new int[n * n2];
        for (int i = 0; i < n * n2; ++i) {
            float f = fArray3[i * 4];
            if (!(f > 0.0f)) continue;
            int n7 = Math.min(255, Math.round(fArray3[i * 4 + 1] / f * 255.0f));
            int n8 = Math.min(255, Math.round(fArray3[i * 4 + 2] / f * 255.0f));
            int n9 = Math.min(255, Math.round(fArray3[i * 4 + 3] / f * 255.0f));
            nArray2[i] = Math.min(255, Math.round(f * 255.0f)) << 24 | n7 << 16 | n8 << 8 | n9;
        }
        if (this.logoTex != null && (object = this.logoTex.handle) instanceof class_2960) {
            class_2960 class_29602 = (class_2960)object;
            class_310.method_1551().method_1531().method_4615(class_29602);
        }
        this.logoTex = new Handle("hud_logo_" + n + "x" + n2, n, n2, nArray2);
        return this.logoTex;
    }

    private static float[] boxResample(float[] fArray, int n, int n2, int n3, boolean bl) {
        int n4 = bl ? n : n2;
        int n5 = bl ? n3 : n;
        int n6 = bl ? n2 : n3;
        float[] fArray2 = new float[n5 * n6 * 4];
        float f = (float)n4 / (float)n3;
        for (int i = 0; i < n3; ++i) {
            float f2 = (float)i * f;
            float f3 = f2 + f;
            int n7 = (int)Math.floor(f2);
            int n8 = Math.min(n4 - 1, (int)Math.ceil(f3) - 1);
            int n9 = bl ? n2 : n;
            for (int j = 0; j < n9; ++j) {
                int n10;
                float f4 = 0.0f;
                float f5 = 0.0f;
                float f6 = 0.0f;
                float f7 = 0.0f;
                float f8 = 0.0f;
                for (n10 = n7; n10 <= n8; ++n10) {
                    float f9 = Math.min((float)(n10 + 1), f3) - Math.max((float)n10, f2);
                    if (f9 <= 0.0f) continue;
                    int n11 = (bl ? j * n + n10 : n10 * n + j) * 4;
                    f4 += fArray[n11] * f9;
                    f5 += fArray[n11 + 1] * f9;
                    f6 += fArray[n11 + 2] * f9;
                    f7 += fArray[n11 + 3] * f9;
                    f8 += f9;
                }
                n10 = (bl ? j * n5 + i : i * n5 + j) * 4;
                if (!(f8 > 0.0f)) continue;
                fArray2[n10] = f4 / f8;
                fArray2[n10 + 1] = f5 / f8;
                fArray2[n10 + 2] = f6 / f8;
                fArray2[n10 + 3] = f7 / f8;
            }
        }
        return fArray2;
    }

    private static void ensureAtlas(float f, int n) {
        int n2 = Math.max(8, Math.round(29.166666f * f));
        int n3 = Math.max(1, Math.round(11.9f * f / 7.0f));
        int n4 = Math.max(8, Math.round(13.0f * f));
        PixelUnit pixelUnit = new PixelUnit(n2, n3, n4, n);
        if (atlas == null || !Clock.atlas.spec.equals(pixelUnit)) {
            if (atlas != null) {
                atlas.close();
            }
            atlas = DropdownFont.create(pixelUnit, Clock.icons(n4));
        }
        atlasScale = f;
    }

    private static Map<String, int[]> icons(int n) {
        LinkedHashMap<String, int[]> linkedHashMap = new LinkedHashMap<String, int[]>();
        linkedHashMap.put("fps", Clock.drawn(n, Clock::lmbd$icons$0));
        linkedHashMap.put("clock", Clock.drawn(n, Clock::lmbd$icons$1));
        linkedHashMap.put("compass", Clock.drawn(n, Clock::lmbd$icons$2));
        linkedHashMap.put("portal", Clock.drawn(n, Clock::lmbd$icons$3));
        linkedHashMap.put("ping", SpeakerOff.SIGNAL.tex((int)n).argb);
        linkedHashMap.put("heart", SpeakerOff.HEART.tex((int)n).argb);
        linkedHashMap.put("arrow", Clock.arrow(n));
        return linkedHashMap;
    }

    private static int[] drawn(int n, Consumer<Graphics2D> consumer) {
        BufferedImage bufferedImage = new BufferedImage(n, n, 2);
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        graphics2D.scale((double)n / 24.0, (double)n / 24.0);
        graphics2D.setColor(Color.WHITE);
        graphics2D.setStroke(new BasicStroke(2.2f, 1, 1));
        consumer.accept(graphics2D);
        graphics2D.dispose();
        return bufferedImage.getRGB(0, 0, n, n, null, 0, n);
    }

    private static int[] arrow(int n) {
        BufferedImage bufferedImage = new BufferedImage(n, n, 2);
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        float f = n;
        Path2D.Float float_ = new Path2D.Float();
        float_.moveTo(f * 0.5f, f * 0.1f);
        float_.lineTo(f * 0.84f, f * 0.86f);
        float_.lineTo(f * 0.5f, f * 0.68f);
        float_.lineTo(f * 0.16f, f * 0.86f);
        float_.closePath();
        graphics2D.setColor(Color.WHITE);
        graphics2D.fill(float_);
        graphics2D.setStroke(new BasicStroke(Math.max(0.6f, f / 22.0f), 1, 1));
        graphics2D.draw(float_);
        graphics2D.dispose();
        return bufferedImage.getRGB(0, 0, n, n, null, 0, n);
    }

    private static void lmbd$icons$3(Graphics2D graphics2D) {
        graphics2D.draw(new RoundRectangle2D.Float(6.5f, 3.5f, 11.0f, 17.0f, 3.0f, 3.0f));
        graphics2D.setColor(new Color(255, 255, 255, 120));
        graphics2D.fill(new RoundRectangle2D.Float(9.0f, 6.0f, 6.0f, 12.0f, 2.0f, 2.0f));
    }

    private static void lmbd$icons$2(Graphics2D graphics2D) {
        graphics2D.draw(new Ellipse2D.Float(3.5f, 3.5f, 17.0f, 17.0f));
        Path2D.Float float_ = new Path2D.Float();
        float_.moveTo(15.5f, 8.5f);
        float_.lineTo(13.4f, 13.4f);
        float_.lineTo(8.5f, 15.5f);
        float_.lineTo(10.6f, 10.6f);
        float_.closePath();
        graphics2D.fill(float_);
    }

    private static void lmbd$icons$1(Graphics2D graphics2D) {
        graphics2D.draw(new Ellipse2D.Float(3.5f, 3.5f, 17.0f, 17.0f));
        Path2D.Float float_ = new Path2D.Float();
        float_.moveTo(12.0f, 7.0f);
        float_.lineTo(12.0f, 12.0f);
        float_.lineTo(15.5f, 14.0f);
        graphics2D.draw(float_);
    }

    private static void lmbd$icons$0(Graphics2D graphics2D) {
        float[][] fArrayArray;
        for (float[] fArray : fArrayArray = new float[][]{{4.0f, 9.0f, 4.0f, 4.0f, 9.0f, 4.0f},new float[]{15.0f, 4.0f, 20.0f, 4.0f, 20.0f, 9.0f},new float[]{4.0f, 15.0f, 4.0f, 20.0f, 9.0f, 20.0f},new float[]{15.0f, 20.0f, 20.0f, 20.0f, 20.0f, 15.0f}}) {
            Path2D.Float float_ = new Path2D.Float();
            float_.moveTo(fArray[0], fArray[1]);
            float_.lineTo(fArray[2], fArray[3]);
            float_.lineTo(fArray[4], fArray[5]);
            graphics2D.draw(float_);
        }
    }

    private static float[] lmbd$anim$0(float f, String string) {
        return new float[]{f};
    }

    private static int lmbd$order$1(HudConfig hudConfig, String string) {
        return hudConfig.category.applyAsInt(string);
    }

    private int lmbd$order$0(String string, String string2) {
        return Float.compare(this.p.textWidth(string2), this.p.textWidth(string));
    }

    private static int lmbd$drawModules$1(Object[] objectArray, Object[] objectArray2) {
        return Float.compare(((Presence2)objectArray[1]).y, ((Presence2)objectArray2[1]).y);
    }

    private static Presence2 lmbd$drawModules$0(String string) {
        return new Presence2();
    }

    private static Alpha lmbd$radar$0(Integer n) {
        return new Alpha();
    }

    private void lmbd$player$0(float f, float f2, float f3, float f4) {
        this.paint.pushAlpha(f);
        this.paint.head(f2, f3, f4);
        this.paint.popAlpha();
    }

    private void lmbd$drawLogo$0(int n, int n2, float f, float f2, float f3, float f4, float f5) {
        Handle handle = this.logo(n, n2);
        if (handle == null || !(f >= f2 - 1.0f) || !(f + (float)n2 <= f3 + 1.0f)) return;
        this.paint.pushAlpha(f4);
        this.paint.texture(handle, f5, f, n, n2, -1);
        this.paint.popAlpha();
    }

    private static float[] lmbd$drawColumn$0(float f, String string) {
        return new float[]{f};
    }

    private static Bottom2 lmbd$render$0(HudElement hudElement) {
        return new Bottom2();
    }
}
