package kryzex.gui;

public class PixelUnit {
    public final int page;
    public final int pixelUnit;
    public final int iconSize;
    public final int font;

    public PixelUnit(int page, int pixelUnit, int iconSize, int font) {
        this.page = page;
        this.pixelUnit = pixelUnit;
        this.iconSize = iconSize;
        this.font = font;
    }

    public int page() {
        return this.page;
    }

    public int pixelUnit() {
        return this.pixelUnit;
    }

    public int iconSize() {
        return this.iconSize;
    }

    public int font() {
        return this.font;
    }
}
