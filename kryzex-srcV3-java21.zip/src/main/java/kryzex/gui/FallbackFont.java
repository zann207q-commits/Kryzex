package kryzex.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import kryzex.gui.FallbackAdvance;
import kryzex.gui.Handle;

public final class FallbackFont {
    public static final int MEDIUM = 0;
    public static final int BOLD = 1;
    private static final String[] FILES = new String[]{"/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Medium.ttf", "/assets/r87f4560b4c09f4/r83d2dcd48984c5/Montserrat-Bold.ttf", "/assets/r87f4560b4c09f4/r83d2dcd48984c5/Inter-Regular.ttf", "/assets/r87f4560b4c09f4/r83d2dcd48984c5/Inter-Medium.ttf"};
    static final String CHARS;
    private static Font[] BASE;
    private static boolean[] FAILED;
    private static final Map<Integer, FallbackAdvance> ATLASES;
    private static final int MAX_PX = 160;

    private FallbackFont() {
    }

    public static boolean available() {
        if (FallbackFont.base(0) == null) return false;
        return true;
    }

    static Font base(int n) {
        if (BASE[n] != null || FAILED[n]) return BASE[n];
        try (InputStream inputStream = FallbackFont.class.getResourceAsStream(FILES[n]);){
            if (inputStream == null) {
                throw new IllegalStateException("missing " + FILES[n]);
            }
            FallbackFont.BASE[n] = Font.createFont(0, inputStream);
            return BASE[n];
        }
        catch (Throwable throwable) {
            FallbackFont.FAILED[n] = true;
            System.err.println("Kryzex: font unavailable, falling back: " + String.valueOf(throwable));
        }
        return BASE[n];
    }

    static FallbackAdvance atlas(int n, int n2) {
        int n3 = Math.max(4, Math.min(160, n2));
        return ATLASES.computeIfAbsent(n << 16 | n3, arg_0 -> FallbackFont.lmbd$atlas$0(n, n3, arg_0));
    }

    public static float width(String string, float f, int n) {
        FallbackAdvance fallbackAdvance = FallbackFont.atlas(n, Math.max(4, Math.round(f)));
        float f2 = f / (float)fallbackAdvance.px;
        float f3 = 0.0f;
        for (int i = 0; i < string.length(); ++i) {
            f3 += fallbackAdvance.advance(string.charAt(i));
        }
        return f3 * f2;
    }

    private static FallbackAdvance build(int n, int n2) {
        int n3;
        Object object;
        int n4;
        Font font = FallbackFont.base(n);
        if (font == null) {
            return null;
        }
        Font font2 = font.deriveFont((float)n2);
        FontRenderContext fontRenderContext = new FontRenderContext(null, true, true);
        int n5 = CHARS.length();
        BufferedImage[] bufferedImageArray = new BufferedImage[n5];
        float[] fArray = new float[n5];
        int[] nArray = new int[n5];
        int[] nArray2 = new int[n5];
        for (n4 = 0; n4 < n5; ++n4) {
            GlyphVector glyphVector = font2.createGlyphVector(fontRenderContext, new char[]{CHARS.charAt(n4)});
            fArray[n4] = glyphVector.getGlyphMetrics(0).getAdvanceX();
            Rectangle rectangle = glyphVector.getPixelBounds(fontRenderContext, 0.0f, 0.0f);
            if (rectangle.width <= 0 || rectangle.height <= 0) continue;
            BufferedImage bufferedImage = new BufferedImage(rectangle.width + 2, rectangle.height + 2, 2);
            object = bufferedImage.createGraphics();
            ((Graphics2D)object).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            ((Graphics2D)object).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            ((Graphics2D)object).setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            ((Graphics2D)object).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            ((Graphics2D)object).setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            ((Graphics)object).setColor(Color.WHITE);
            ((Graphics2D)object).drawGlyphVector(glyphVector, -rectangle.x + 1, -rectangle.y + 1);
            ((Graphics)object).dispose();
            bufferedImageArray[n4] = bufferedImage;
            nArray[n4] = rectangle.x - 1;
            nArray2[n4] = rectangle.y - 1;
        }
        n4 = n2 > 60 ? 2048 : 1024;
        int n6 = 1;
        int n7 = 1;
        int n8 = 0;
        int[] object2 = new int[n5];
        int[] nArray3 = new int[n5];
        for (n3 = 0; n3 < n5; ++n3) {
            if (bufferedImageArray[n3] == null) continue;
            if (n6 + bufferedImageArray[n3].getWidth() + 1 > n4) {
                n6 = 1;
                n7 += n8 + 1;
                n8 = 0;
            }
            object2[n3] = n6;
            nArray3[n3] = n7;
            n6 += bufferedImageArray[n3].getWidth() + 1;
            n8 = Math.max(n8, bufferedImageArray[n3].getHeight());
        }
        n3 = n7 + n8 + 1;
        int[] nArray4 = new int[n4 * n3];
        for (int i = 0; i < n5; ++i) {
            if (bufferedImageArray[i] == null) continue;
            BufferedImage bufferedImage = bufferedImageArray[i];
            for (int j = 0; j < bufferedImage.getHeight(); ++j) {
                for (int k = 0; k < bufferedImage.getWidth(); ++k) {
                    int n9 = bufferedImage.getRGB(k, j) >>> 24;
                    int n10 = (int)Math.round(Math.pow((double)n9 / 255.0, 0.82) * 255.0);
                    nArray4[(nArray3[i] + j) * n4 + object2[i] + k] = n10 << 24 | 0xFFFFFF;
                }
            }
        }
        Handle handle = new Handle("font_" + n + "_" + n2, n4, n3, nArray4);
        float f = font2.getLineMetrics("Hd", fontRenderContext).getAscent();
        return new FallbackAdvance(n2, handle, bufferedImageArray, fArray, nArray, nArray2, object2, nArray3, f);
    }

    private static FallbackAdvance lmbd$atlas$0(int n, int n2, Integer n3) {
        return FallbackFont.build(n, n2);
    }

    static {
        BASE = new Font[4];
        FAILED = new boolean[4];
        ATLASES = new HashMap<Integer, FallbackAdvance>();
        StringBuilder stringBuilder = new StringBuilder();
        for (char c = ' '; c <= '~'; c = (char)(c + '\u0001')) {
            stringBuilder.append(c);
        }
        stringBuilder.append("\u2022\u2026\u00b7\u2014\u2013\u00b0\u00d7\u2190\u2192\u2713\u00a7\u00e9\u00e8\u00e0\u00e7\u00f1\u00fc\u00f6\u00e4\u00df");
        CHARS = stringBuilder.toString();
    }
}
