package kryzex.gui;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.Arrays;
import kryzex.gui.KryzexLoadingLogo;
import kryzex.gui.LoadingScreenLogo;
import kryzex.gui.TextureSetup2;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_11246;
import net.minecraft.class_12137;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;

final class Floats {
    private final float scale;
    private final float time;
    private float[] floats = new float[0];
    private int[] ints = new int[0];
    private int count;

    Floats(float f, float f2) {
        this.scale = f;
        this.time = f2;
    }

    void add(float f, float f2, float f3, float f4, float f5, int n, int n2, int n3, float f6, float f7) {
        if (this.floats.length < (this.count + 1) * 8) {
            this.floats = Arrays.copyOf(this.floats, (this.count + 1) * 8);
            this.ints = Arrays.copyOf(this.ints, (this.count + 1) * 4);
        }
        int n4 = this.count * 8;
        int n5 = this.count * 4;
        this.floats[n4] = (f - f5) / this.scale;
        this.floats[n4 + 1] = (f2 - f5) / this.scale;
        this.floats[n4 + 2] = (f3 + f5) / this.scale;
        this.floats[n4 + 3] = (f4 + f5) / this.scale;
        this.floats[n4 + 4] = (f3 - f) / 2.0f + f5;
        this.floats[n4 + 5] = (f4 - f2) / 2.0f + f5;
        this.floats[n4 + 6] = f7;
        this.floats[n4 + 7] = 0.0f;
        this.ints[n5] = n;
        this.ints[n5 + 1] = n2;
        this.ints[n5 + 2] = n3 | Math.round(f5) << 4;
        this.ints[n5 + 3] = Math.round(LoadingScreenLogo.clamp01(f6) * 32767.0f);
        ++this.count;
    }

    void submit(class_332 class_3322, KryzexLoadingLogo kryzexLoadingLogo) {
        class_11246 class_112462 = LoadingScreenLogo.state(class_3322);
        if (class_112462 == null || this.count <= 0) return;
        class_310 class_3102 = class_310.method_1551();
        class_8030 class_80302 = new class_8030(0, 0, class_3102.method_22683().method_4486(), class_3102.method_22683().method_4502());
        class_11231 class_112312 = class_11231.method_70900((GpuTextureView)kryzexLoadingLogo.method_71659(), (class_12137)kryzexLoadingLogo.method_75484());
        class_112462.method_70919((class_11244)new TextureSetup2((Matrix3x2fc)new Matrix3x2f((Matrix3x2fc)class_3322.method_51448()), class_112312, Arrays.copyOf(this.floats, this.count * 8), Arrays.copyOf(this.ints, this.count * 4), this.count, this.time, class_80302));
    }
}
