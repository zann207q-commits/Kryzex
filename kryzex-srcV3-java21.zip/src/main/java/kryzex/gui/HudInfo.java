package kryzex.gui;

import java.util.List;

public interface HudInfo {
    public int fps();

    public String ping();

    public String server();

    public boolean inWorld();

    public double x();

    public double y();

    public double z();

    public float yaw();

    public boolean nether();

    public String playerName();

    public float health();

    public List<String> modules();
}
