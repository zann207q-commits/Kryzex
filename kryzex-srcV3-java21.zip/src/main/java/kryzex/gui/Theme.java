package kryzex.gui;

import kryzex.modules.client.KryzexPlus;
import java.awt.Color;

public enum Theme {
    Black(15527409, 0xFFFFFF, 1.0f, 1316121, 1579293, 131587, 0xFFFFFF, 9343126),
    White(0xFFFFFF, 0xFFFFFF, 1.9f, 0x33353C, 3816516, 657932, 0xFFFFFF, 14277860),
    Purple(11897599, 13676031, 1.25f, 2168623, 2956355, 986135, 15919359, 9852393),
    Ocean(8571135, 5941503, 1.4f, 1120806, 1388623, 132620, 0xFFFFFF, 6140671),
    Rose(16753606, 16742572, 1.35f, 2233372, 4528175, 656134, 0xFFFFFF, 16745137),
    Mint(9302732, 5234092, 1.3f, 0x111F1B, 1391923, 133640, 0xFFFFFF, 5956276),
    Amber(16763786, 16754002, 1.3f, 0x211A11, 4599834, 656898, 0xFFFFFF, 16756318),
    Crimson(0xFF8A8A, 0xFF5A5A, 1.3f, 2233108, 4659483, 656131, 0xFFFFFF, 0xFF6464),
    Halloween(15964750, 9725680, 1.25f, 1708568, 2757680, 656389, 16761470, 10706687);

    private static final int SIZE = 23;
    private static final long BLEND_NS = 700000000L;
    private static Theme target;
    private static float[] from;
    private static long changedAt;
    private static float[] cached;
    private static long cachedAt;
    final int accent;
    final int light;
    final float lightAmount;
    final int glass;
    final int bgTop;
    final int bgBottom;
    final int logoTop;
    final int logoBottom;

    private Theme(int n2, int n3, float f, int n4, int n5, int n6, int n7, int n8) {
        this.accent = n2;
        this.light = n3;
        this.lightAmount = f;
        this.glass = n4;
        this.bgTop = n5;
        this.bgBottom = n6;
        this.logoTop = n7;
        this.logoBottom = n8;
    }

    private float[] vector() {
        float[] fArray = new float[23];
        Theme.put(fArray, 0, this.accent);
        Theme.put(fArray, 3, this.light);
        Theme.put(fArray, 6, this.glass);
        Theme.put(fArray, 9, this.bgTop);
        Theme.put(fArray, 12, this.bgBottom);
        Theme.put(fArray, 15, this.logoTop);
        Theme.put(fArray, 18, this.logoBottom);
        fArray[21] = this.lightAmount;
        fArray[22] = this == Halloween ? 1.0f : 0.0f;
        return fArray;
    }

    private static void put(float[] fArray, int n, int n2) {
        fArray[n] = n2 >> 16 & 0xFF;
        fArray[n + 1] = n2 >> 8 & 0xFF;
        fArray[n + 2] = n2 & 0xFF;
    }

    public static Theme selected() {
        try {
            Theme theme;
            Enum enum_ = kryzex.modules.client.KryzexPlus.theme.getValue();
            return enum_ instanceof Theme ? (theme = (Theme)enum_) : Black;
        }
        catch (Throwable throwable) {
            return Black;
        }
    }

    private static float[] now() {
        long l = System.nanoTime();
        if (cached != null && target == Theme.selected() && (l - cachedAt < 1000000L || l - changedAt >= 700000000L && cachedAt - changedAt >= 700000000L)) {
            return cached;
        }
        if (l == cachedAt && cached != null) {
            return cached;
        }
        Theme theme = Theme.selected();
        if (target == null) {
            target = theme;
            from = theme.vector();
            changedAt = l - 700000000L;
        } else if (theme != target) {
            from = cached != null ? (float[])cached.clone() : target.vector();
            target = theme;
            changedAt = l;
        }
        float f = Math.min(1.0f, (float)(l - changedAt) / 7.0E8f);
        float f2 = f * f * (3.0f - 2.0f * f);
        float[] fArray = target.vector();
        float[] fArray2 = new float[23];
        for (int i = 0; i < 23; ++i) {
            fArray2[i] = from[i] + (fArray[i] - from[i]) * f2;
        }
        cached = fArray2;
        cachedAt = l;
        return fArray2;
    }

    private static int rgb(float[] fArray, int n, float f) {
        int n2 = Math.round(Math.max(0.0f, Math.min(1.0f, f)) * 255.0f);
        return n2 << 24 | Math.round(fArray[n]) << 16 | Math.round(fArray[n + 1]) << 8 | Math.round(fArray[n + 2]);
    }

    public static int accent(float f) {
        return Theme.rgb(Theme.now(), 0, f);
    }

    public static int light(float f) {
        return Theme.rgb(Theme.now(), 3, f);
    }

    public static int glass(float f) {
        return Theme.rgb(Theme.now(), 6, f);
    }

    public static int bgTop(float f) {
        return Theme.rgb(Theme.now(), 9, f);
    }

    public static int bgBottom(float f) {
        return Theme.rgb(Theme.now(), 12, f);
    }

    public static int logoTop(float f) {
        return Theme.rgb(Theme.now(), 15, f);
    }

    public static int logoBottom(float f) {
        return Theme.rgb(Theme.now(), 18, f);
    }

    public static float halloween() {
        return Theme.now()[22];
    }

    public static float lightAmount() {
        return Theme.now()[21];
    }

    public static Color accentColor(int n) {
        float[] fArray = Theme.now();
        return new Color(Math.round(fArray[0]), Math.round(fArray[1]), Math.round(fArray[2]), Math.max(0, Math.min(255, n)));
    }

    public String label() {
        return this.name();
    }

    public static float transition() {
        Theme.now();
        return Math.max(0.0f, Math.min(1.0f, (float)(System.nanoTime() - changedAt) / 7.0E8f));
    }

    public int previewAccent() {
        return 0xFF000000 | this.accent;
    }

    public int previewLight() {
        return 0xFF000000 | this.light;
    }

    public int previewTop() {
        return 0xFF000000 | this.bgTop;
    }

    public int previewLogo() {
        return 0xFF000000 | this.logoBottom;
    }

    static {
        cachedAt = -1L;
    }
}
