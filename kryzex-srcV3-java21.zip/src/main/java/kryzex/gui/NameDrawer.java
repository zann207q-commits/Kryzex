package kryzex.gui;

import kryzex.gui.Name;

@FunctionalInterface
public interface NameDrawer {
    public void draw(Name var1, float var2, float var3, float var4, float var5);
}
