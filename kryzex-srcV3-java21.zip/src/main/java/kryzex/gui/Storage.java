package kryzex.gui;

import java.awt.Color;
import java.util.List;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.Saturation;
import kryzex.gui.SquareCorners;
import kryzex.gui.IntBinding;
import kryzex.module.Module;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.ToggleEntry;

final class Storage
extends LinesWidth
implements IntBinding {
    private final ListSetting storage;

    Storage(Module module, ListSetting listSetting) {
        super(module, listSetting);
        this.storage = listSetting;
    }

    private ToggleEntry entry() {
        List<ToggleEntry> list = this.storage.entries();
        if (list.isEmpty()) {
            return null;
        }
        ToggleEntry toggleEntry = list.get(0);
        return toggleEntry;
    }

    @Override
    public int get() {
        ToggleEntry toggleEntry = this.entry();
        if (toggleEntry == null) return -1;
        if (toggleEntry.color() == null) {
            return -1;
        }
        int n = toggleEntry.color().getRGB();
        return n;
    }

    @Override
    public void set(int n) {
        ToggleEntry toggleEntry = this.entry();
        if (toggleEntry == null) return;
        toggleEntry.setColor(new Color(n, true));
    }

    @Override
    public Object key() {
        return this.storage;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return 15.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        Saturation.swatch(listeningModule.painter, f + f3 - 10.0f, f5, this.get() & 0xFFFFFF, listeningModule.picker.isOpenFor(this.storage) ? 1.0f : this.hover);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (this.entry() == null) return true;
        listeningModule.picker.open(this, f + f3, f2 + f4 / 2.0f);
        listeningModule.host.sound("OPEN");
        return true;
    }
}
