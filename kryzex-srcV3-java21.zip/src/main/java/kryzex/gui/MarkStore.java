package kryzex.gui;

import java.util.Arrays;

public final class MarkStore {
    int count;
    int[] id = new int[64];
    int[] kind = new int[64];
    float[] dx = new float[64];
    float[] dy = new float[64];
    float[] dz = new float[64];

    void clear() {
        this.count = 0;
    }

    public void add(int n, float f, float f2, float f3, int n2) {
        if (this.count == this.id.length) {
            int n3 = this.count * 2;
            this.id = Arrays.copyOf(this.id, n3);
            this.kind = Arrays.copyOf(this.kind, n3);
            this.dx = Arrays.copyOf(this.dx, n3);
            this.dy = Arrays.copyOf(this.dy, n3);
            this.dz = Arrays.copyOf(this.dz, n3);
        }
        this.id[this.count] = n;
        this.kind[this.count] = n2;
        this.dx[this.count] = f;
        this.dy[this.count] = f2;
        this.dz[this.count] = f3;
        ++this.count;
    }
}
