package kryzex.gui;

import kryzex.gui.Handle;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public enum SpeakerOff {
    SWORD,
    GRID,
    BOLT,
    DONUT,
    EYE,
    MONITOR,
    SEARCH,
    GEAR,
    SPEAKER,
    SPEAKER_OFF,
    LAYOUT,
    CHEVRON_LEFT,
    CHEVRON_RIGHT,
    CLOSE,
    GRIP,
    USER,
    BOX,
    KEYBOARD,
    SIGNAL,
    CHECK,
    ACTIVITY,
    GLOBE,
    HEART,
    FOLDER,
    PLUS,
    EDIT,
    COPY,
    TRASH,
    RESET;

    private static final Map<Long, Handle> CACHE;

    Handle tex(int n) {
        int n2 = Math.max(6, Math.min(256, n));
        return CACHE.computeIfAbsent((long)this.ordinal() << 32 | (long)n2, arg_0 -> this.lmbd$tex$0(n2, arg_0));
    }

    private void paint(Graphics2D graphics2D) {
        switch (this.ordinal()) {
            case 23: {
                Path2D path2D = SpeakerOff.poly(3.0, 7.0, 3.0, 5.0, 9.0, 5.0, 11.0, 7.0, 21.0, 7.0, 21.0, 19.0, 3.0, 19.0);
                path2D.closePath();
                graphics2D.draw(path2D);
                SpeakerOff.line(graphics2D, 3.0, 10.0, 21.0, 10.0);
                return;
            }
            case 24: {
                SpeakerOff.line(graphics2D, 12.0, 5.0, 12.0, 19.0);
                SpeakerOff.line(graphics2D, 5.0, 12.0, 19.0, 12.0);
                return;
            }
            case 25: {
                Path2D path2D = SpeakerOff.poly(5.0, 15.0, 15.0, 5.0, 19.0, 9.0, 9.0, 19.0, 4.0, 20.0, 5.0, 15.0);
                graphics2D.draw(path2D);
                SpeakerOff.line(graphics2D, 13.0, 7.0, 17.0, 11.0);
                return;
            }
            case 26: {
                graphics2D.draw(new RoundRectangle2D.Double(8.0, 8.0, 12.0, 13.0, 3.0, 3.0));
                graphics2D.draw(SpeakerOff.poly(15.0, 4.0, 4.0, 4.0, 4.0, 16.0));
                return;
            }
            case 27: {
                SpeakerOff.line(graphics2D, 5.0, 7.0, 19.0, 7.0);
                SpeakerOff.line(graphics2D, 9.0, 4.0, 15.0, 4.0);
                graphics2D.draw(SpeakerOff.poly(7.0, 7.0, 8.0, 20.0, 16.0, 20.0, 17.0, 7.0));
                SpeakerOff.line(graphics2D, 10.0, 11.0, 10.0, 16.0);
                SpeakerOff.line(graphics2D, 14.0, 11.0, 14.0, 16.0);
                return;
            }
            case 28: {
                graphics2D.draw(new Arc2D.Double(5.0, 5.0, 15.0, 15.0, -80.0, 285.0, 0));
                graphics2D.draw(SpeakerOff.poly(4.0, 4.0, 4.0, 10.0, 10.0, 10.0));
                return;
            }
            case 0: {
                graphics2D.draw(SpeakerOff.poly(14.5, 17.5, 3.0, 6.0, 3.0, 3.0, 6.0, 3.0, 17.5, 14.5));
                SpeakerOff.line(graphics2D, 13.0, 19.0, 19.0, 13.0);
                SpeakerOff.line(graphics2D, 16.0, 16.0, 20.0, 20.0);
                SpeakerOff.line(graphics2D, 19.0, 21.0, 21.0, 19.0);
                return;
            }
            case 1: {
                graphics2D.draw(new RoundRectangle2D.Double(3.0, 3.0, 7.0, 7.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(14.0, 3.0, 7.0, 7.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(14.0, 14.0, 7.0, 7.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(3.0, 14.0, 7.0, 7.0, 2.5, 2.5));
                return;
            }
            case 2: {
                Path2D path2D = SpeakerOff.poly(13.0, 2.0, 4.0, 13.5, 11.5, 13.5, 10.5, 22.0, 20.0, 10.5, 12.5, 10.5);
                path2D.closePath();
                graphics2D.draw(path2D);
                return;
            }
            case 3: {
                graphics2D.draw(new Ellipse2D.Double(3.0, 3.0, 18.0, 18.0));
                graphics2D.draw(new Ellipse2D.Double(9.0, 9.0, 6.0, 6.0));
                SpeakerOff.line(graphics2D, 7.2, 8.0, 8.4, 7.0);
                SpeakerOff.line(graphics2D, 15.8, 6.6, 16.8, 7.8);
                SpeakerOff.line(graphics2D, 6.6, 15.4, 7.6, 16.6);
                SpeakerOff.line(graphics2D, 16.4, 15.8, 17.6, 14.8);
                SpeakerOff.line(graphics2D, 12.0, 5.2, 12.0, 6.4);
                return;
            }
            case 4: {
                Path2D.Double double_ = new Path2D.Double();
                double_.moveTo(2.0, 12.0);
                double_.curveTo(5.0, 6.0, 8.5, 5.0, 12.0, 5.0);
                double_.curveTo(15.5, 5.0, 19.0, 6.0, 22.0, 12.0);
                double_.curveTo(19.0, 18.0, 15.5, 19.0, 12.0, 19.0);
                double_.curveTo(8.5, 19.0, 5.0, 18.0, 2.0, 12.0);
                double_.closePath();
                graphics2D.draw(double_);
                graphics2D.draw(new Ellipse2D.Double(9.0, 9.0, 6.0, 6.0));
                return;
            }
            case 5: {
                graphics2D.draw(new RoundRectangle2D.Double(2.5, 3.5, 19.0, 13.0, 4.0, 4.0));
                SpeakerOff.line(graphics2D, 8.0, 20.5, 16.0, 20.5);
                SpeakerOff.line(graphics2D, 12.0, 16.5, 12.0, 20.5);
                return;
            }
            case 6: {
                graphics2D.draw(new Ellipse2D.Double(3.5, 3.5, 14.0, 14.0));
                SpeakerOff.line(graphics2D, 20.5, 20.5, 15.6, 15.6);
                return;
            }
            case 7: {
                Path2D.Double double_ = new Path2D.Double();
                int n = 8;
                for (int i = 0; i < n * 4; ++i) {
                    double d = Math.PI * 2 * (double)i / (double)(n * 4) - 1.5707963267948966;
                    double d2 = i % 4 != 0 && i % 4 != 1 ? 7.4 : 9.6;
                    double d3 = 12.0 + Math.cos(d) * d2;
                    double d4 = 12.0 + Math.sin(d) * d2;
                    if (i == 0) {
                        double_.moveTo(d3, d4);
                        continue;
                    }
                    double_.lineTo(d3, d4);
                }
                double_.closePath();
                graphics2D.draw(double_);
                graphics2D.draw(new Ellipse2D.Double(9.0, 9.0, 6.0, 6.0));
                return;
            }
            case 8:
            case 9: {
                Path2D path2D = SpeakerOff.poly(11.0, 5.0, 6.0, 9.0, 2.5, 9.0, 2.5, 15.0, 6.0, 15.0, 11.0, 19.0);
                path2D.closePath();
                graphics2D.draw(path2D);
                if (this == SPEAKER) {
                    graphics2D.draw(new Arc2D.Double(10.5, 8.5, 7.0, 7.0, -45.0, 90.0, 0));
                    graphics2D.draw(new Arc2D.Double(9.5, 4.5, 13.0, 15.0, -48.0, 96.0, 0));
                    return;
                }
                SpeakerOff.line(graphics2D, 22.0, 9.0, 16.0, 15.0);
                SpeakerOff.line(graphics2D, 16.0, 9.0, 22.0, 15.0);
                return;
            }
            case 10: {
                graphics2D.draw(new RoundRectangle2D.Double(3.0, 3.0, 7.0, 9.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(14.0, 3.0, 7.0, 5.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(14.0, 12.0, 7.0, 9.0, 2.5, 2.5));
                graphics2D.draw(new RoundRectangle2D.Double(3.0, 16.0, 7.0, 5.0, 2.5, 2.5));
                return;
            }
            case 11: {
                graphics2D.draw(SpeakerOff.poly(15.0, 18.0, 9.0, 12.0, 15.0, 6.0));
                return;
            }
            case 12: {
                graphics2D.draw(SpeakerOff.poly(9.0, 18.0, 15.0, 12.0, 9.0, 6.0));
                return;
            }
            case 13: {
                SpeakerOff.line(graphics2D, 18.0, 6.0, 6.0, 18.0);
                SpeakerOff.line(graphics2D, 6.0, 6.0, 18.0, 18.0);
                return;
            }
            case 14: {
                for (int i = 0; i < 2; ++i) {
                    for (int j = 0; j < 3; ++j) {
                        graphics2D.fill(new Ellipse2D.Double(8.0 + (double)i * 6.5, 4.6 + (double)j * 6.2, 2.4, 2.4));
                    }
                }
                return;
            }
            case 15: {
                graphics2D.draw(new Ellipse2D.Double(8.0, 4.0, 8.0, 8.0));
                Path2D.Double double_ = new Path2D.Double();
                double_.moveTo(5.0, 20.5);
                double_.curveTo(5.0, 16.5, 8.0, 14.5, 12.0, 14.5);
                double_.curveTo(16.0, 14.5, 19.0, 16.5, 19.0, 20.5);
                graphics2D.draw(double_);
                return;
            }
            case 16: {
                Path2D path2D = SpeakerOff.poly(12.0, 2.8, 20.5, 7.4, 20.5, 16.6, 12.0, 21.2, 3.5, 16.6, 3.5, 7.4);
                path2D.closePath();
                graphics2D.draw(path2D);
                graphics2D.draw(SpeakerOff.poly(3.5, 7.4, 12.0, 12.0, 20.5, 7.4));
                SpeakerOff.line(graphics2D, 12.0, 12.0, 12.0, 21.2);
                return;
            }
            case 17: {
                graphics2D.draw(new RoundRectangle2D.Double(2.5, 6.0, 19.0, 12.0, 4.0, 4.0));
                SpeakerOff.line(graphics2D, 7.0, 14.5, 17.0, 14.5);
                SpeakerOff.line(graphics2D, 7.0, 10.0, 7.01, 10.0);
                SpeakerOff.line(graphics2D, 10.3, 10.0, 10.31, 10.0);
                SpeakerOff.line(graphics2D, 13.6, 10.0, 13.61, 10.0);
                SpeakerOff.line(graphics2D, 17.0, 10.0, 17.01, 10.0);
                return;
            }
            case 18: {
                SpeakerOff.line(graphics2D, 5.0, 19.0, 5.0, 16.0);
                SpeakerOff.line(graphics2D, 10.0, 19.0, 10.0, 12.5);
                SpeakerOff.line(graphics2D, 15.0, 19.0, 15.0, 9.0);
                SpeakerOff.line(graphics2D, 20.0, 19.0, 20.0, 5.0);
                return;
            }
            case 19: {
                graphics2D.draw(SpeakerOff.poly(5.0, 12.5, 10.0, 17.5, 19.5, 7.0));
                return;
            }
            case 20: {
                graphics2D.draw(SpeakerOff.poly(2.5, 12.0, 6.5, 12.0, 9.5, 5.0, 14.5, 19.0, 17.5, 12.0, 21.5, 12.0));
                return;
            }
            case 21: {
                graphics2D.draw(new Ellipse2D.Double(3.0, 3.0, 18.0, 18.0));
                graphics2D.draw(new Ellipse2D.Double(8.0, 3.0, 8.0, 18.0));
                SpeakerOff.line(graphics2D, 3.4, 12.0, 20.6, 12.0);
                return;
            }
            case 22: {
                Path2D.Double double_ = new Path2D.Double();
                double_.moveTo(12.0, 20.0);
                double_.curveTo(5.0, 15.5, 2.5, 12.0, 2.5, 8.6);
                double_.curveTo(2.5, 5.6, 4.8, 3.6, 7.5, 3.6);
                double_.curveTo(9.4, 3.6, 11.0, 4.7, 12.0, 6.4);
                double_.curveTo(13.0, 4.7, 14.6, 3.6, 16.5, 3.6);
                double_.curveTo(19.2, 3.6, 21.5, 5.6, 21.5, 8.6);
                double_.curveTo(21.5, 12.0, 19.0, 15.5, 12.0, 20.0);
                double_.closePath();
                graphics2D.draw(double_);
            }
        }
    }

    private static Path2D poly(double ... dArray) {
        Path2D.Double double_ = new Path2D.Double();
        double_.moveTo(dArray[0], dArray[1]);
        for (int n = 2; n < dArray.length; n = (int)((byte)(n + 2))) {
            double_.lineTo(dArray[n], dArray[n + 1]);
        }
        return double_;
    }

    private static void line(Graphics2D graphics2D, double d, double d2, double d3, double d4) {
        graphics2D.draw(new Line2D.Double(d, d2, d3, d4));
    }

    private Handle lmbd$tex$0(int n, Long l) {
        BufferedImage bufferedImage = new BufferedImage(n, n, 2);
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.scale((double)n / 24.0, (double)n / 24.0);
        graphics2D.setColor(Color.WHITE);
        float f = Math.max(1.75f, 31.199999f / (float)n);
        graphics2D.setStroke(new BasicStroke(f, 1, 1));
        this.paint(graphics2D);
        graphics2D.dispose();
        int[] nArray = new int[n * n];
        bufferedImage.getRGB(0, 0, n, n, nArray, 0, n);
        for (int i = 0; i < nArray.length; ++i) {
            nArray[i] = nArray[i] & 0xFF000000 | 0xFFFFFF;
        }
        return new Handle("icon_" + this.name() + "_" + n, n, n, nArray);
    }

    static {
        CACHE = new HashMap<Long, Handle>();
    }
}
