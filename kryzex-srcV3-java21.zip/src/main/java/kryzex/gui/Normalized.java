package kryzex.gui;

import kryzex.gui.PaletteEntry;
import kryzex.gui.Items;
import kryzex.module.settings.MacroEnchantSetting;
import java.util.Objects;
import java.util.function.Predicate;

class Normalized
implements Predicate<PaletteEntry> {
    String previous;
    String normalized;
    final MacroEnchantSetting val$text;

    Normalized(MacroEnchantSetting lB2) {
        this.val$text = lB2;
    }

    @Override
    public boolean test(PaletteEntry ub) {
        String string = this.val$text.get();
        if (Objects.equals(this.previous, string)) return ub.id().equals(this.normalized);
        this.previous = string;
        this.normalized = Items.id((String)string);
        return ub.id().equals(this.normalized);
    }
}
