package kryzex.gui;

import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.Saturation;
import kryzex.gui.SquareCorners;
import kryzex.gui.IntBinding;
import kryzex.module.Module;
import kryzex.module.settings.ColorSetting;

final class ColorSettingRow
extends LinesWidth
implements IntBinding {
    private final ColorSetting rgb;

    ColorSettingRow(Module module, ColorSetting colorSetting) {
        super(module, colorSetting);
        this.rgb = colorSetting;
    }

    @Override
    public int get() {
        return this.rgb.getArgb();
    }

    @Override
    public void set(int n) {
        this.rgb.setArgb(n);
    }

    @Override
    public Object key() {
        return this.rgb;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return 15.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        Saturation.swatch(listeningModule.painter, f + f3 - 10.0f, f5, this.rgb.getArgb() & 0xFFFFFF, listeningModule.picker.isOpenFor(this.rgb) ? 1.0f : this.hover);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        listeningModule.picker.open(this, f + f3, f2 + f4 / 2.0f);
        listeningModule.host.sound("OPEN");
        return true;
    }
}
