package kryzex.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;
import kryzex.client.KryzexClient;
import kryzex.gui.ModuleSearchIndex;
import kryzex.gui.ModuleSorter;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.modules.client.KryzexPlus;

public final class ModuleLists {
    private static final Map<Object, ModuleSearchIndex> CACHES = new WeakHashMap<Object, ModuleSearchIndex>();

    private ModuleLists() {
    }

    private static List<Module> all() {
        try {
            return KryzexClient.INSTANCE.getModuleManager().getAllModules();
        }
        catch (RuntimeException runtimeException) {
            return List.of();
        }
    }

    public static List<Module> category(Object object, Category category) {
        List<Module> list = ModuleLists.all();
        ModuleSearchIndex moduleSearchIndex = CACHES.computeIfAbsent(object, ModuleLists::lmbd$category$0);
        moduleSearchIndex.update(list);
        return moduleSearchIndex.categories.computeIfAbsent(category, arg_0 -> ModuleLists.lmbd$category$1(list, arg_0));
    }

    public static List<Module> search(Object object, String string) {
        ModuleSearchIndex moduleSearchIndex = CACHES.computeIfAbsent(object, ModuleLists::lmbd$search$0);
        moduleSearchIndex.update(ModuleLists.all());
        String string2 = string.toLowerCase(Locale.ROOT).trim();
        if (string2.equals(moduleSearchIndex.query)) {
            return moduleSearchIndex.results;
        }
        ArrayList<Module> arrayList = new ArrayList<Module>();
        ArrayList<Module> arrayList2 = new ArrayList<Module>();
        for (int i = 0; i < moduleSearchIndex.modules.length; ++i) {
            String string3 = moduleSearchIndex.names[i];
            if (string3.contains(string2)) {
                (string3.startsWith(string2) ? arrayList : arrayList2).add(moduleSearchIndex.modules[i]);
                continue;
            }
            if (!moduleSearchIndex.descriptions[i].contains(string2)) continue;
            arrayList2.add(moduleSearchIndex.modules[i]);
        }
        arrayList.addAll(arrayList2);
        moduleSearchIndex.query = string2;
        moduleSearchIndex.results = ModuleSorter.newFirst(arrayList);
        return moduleSearchIndex.results;
    }

    public static List<String> enabled(Module module) {
        int n;
        ModuleSearchIndex moduleSearchIndex = CACHES.computeIfAbsent(module, ModuleLists::lmbd$enabled$0);
        boolean bl = moduleSearchIndex.update(ModuleLists.all());
        for (int i = 0; i < moduleSearchIndex.modules.length; ++i) {
            n = moduleSearchIndex.modules[i].isEnabled() ? 1 : 0;
            if (n == (moduleSearchIndex.enabled[i] ? 1 : 0)) continue;
            moduleSearchIndex.enabled[i] = n != 0;
            bl = true;
        }
        if (!bl) return moduleSearchIndex.activeNames;
        ArrayList<String> arrayList = new ArrayList<String>();
        for (n = 0; n < moduleSearchIndex.modules.length; ++n) {
            Module module2 = moduleSearchIndex.modules[n];
            if (!moduleSearchIndex.enabled[n] || module2 == module || module2 instanceof KryzexPlus) continue;
            arrayList.add(moduleSearchIndex.displayNames[n]);
        }
        moduleSearchIndex.activeNames = List.copyOf(arrayList);
        return moduleSearchIndex.activeNames;
    }

    private static ModuleSearchIndex lmbd$enabled$0(Object object) {
        return new ModuleSearchIndex();
    }

    private static ModuleSearchIndex lmbd$search$0(Object object) {
        return new ModuleSearchIndex();
    }

    private static List lmbd$category$1(List<Module> list, Category category) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        for (Module module : list) {
            if (module.getCategory() != category) continue;
            arrayList.add(module);
        }
        return ModuleSorter.newFirst(arrayList);
    }

    private static ModuleSearchIndex lmbd$category$0(Object object) {
        return new ModuleSearchIndex();
    }
}
