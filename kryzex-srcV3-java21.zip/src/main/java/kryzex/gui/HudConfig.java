package kryzex.gui;

import java.util.function.ToIntFunction;
import kryzex.gui.SortMode;

public final class HudConfig {
    public boolean watermark = true;
    public boolean time = true;
    public boolean info = true;
    public boolean player;
    public boolean radar = true;
    public boolean coords = true;
    public boolean direction = true;
    public boolean netherCoords;
    public boolean modules = true;
    public boolean rainbow;
    public boolean radarMobs = true;
    public float radarRange = 48.0f;
    public float rainbowSpeed = 1.0f;
    public float scale = 1.0f;
    public float opacity = 0.62f;
    public int font;
    public SortMode sort = SortMode.Longest;
    public ToIntFunction<String> category = HudConfig::lmbd$new$0;

    private static int lmbd$new$0(String string) {
        return 0;
    }
}
