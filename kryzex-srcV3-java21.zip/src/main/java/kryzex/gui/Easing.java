package kryzex.gui;

final class Easing {
    private Easing() {
    }

    static float clamp(float f, float f2, float f3) {
        return f < f2 ? f2 : Math.min(f, f3);
    }

    static float out(float f) {
        float f2 = 1.0f - Easing.clamp(f, 0.0f, 1.0f);
        return 1.0f - f2 * f2 * f2;
    }

    static float inOut(float f) {
        return (f = Easing.clamp(f, 0.0f, 1.0f)) < 0.5f ? 4.0f * f * f * f : 1.0f - (float)Math.pow(-2.0f * f + 2.0f, 3.0) / 2.0f;
    }

    static float lerp(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }

    static int mix(int n, int n2, float f) {
        f = Easing.clamp(f, 0.0f, 1.0f);
        int n3 = Math.round(Easing.lerp(n >>> 24, n2 >>> 24, f));
        int n4 = Math.round(Easing.lerp(n >> 16 & 0xFF, n2 >> 16 & 0xFF, f));
        int n5 = Math.round(Easing.lerp(n >> 8 & 0xFF, n2 >> 8 & 0xFF, f));
        int n6 = Math.round(Easing.lerp(n & 0xFF, n2 & 0xFF, f));
        return n3 << 24 | n4 << 16 | n5 << 8 | n6;
    }
}
