package kryzex.gui;

import net.minecraft.class_4185;

class Control {
    public final String label;
    public final int icon;
    public final class_4185 control;

    public Control(String label, int icon, class_4185 control) {
        this.label = label;
        this.icon = icon;
        this.control = control;
    }

    public String label() {
        return this.label;
    }

    public int icon() {
        return this.icon;
    }

    public class_4185 control() {
        return this.control;
    }
}
