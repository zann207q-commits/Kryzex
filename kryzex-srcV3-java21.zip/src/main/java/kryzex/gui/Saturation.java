package kryzex.gui;

import java.awt.Color;
import kryzex.gui.Tween;
import kryzex.gui.LastSource;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.gui.IntBinding;

public final class Saturation {
    private static final float WIDTH = 152.0f;
    private static final float PAD = 8.0f;
    private static final float SQUARE = 92.0f;
    private static final float HUE = 10.0f;
    private static final float FOOTER = 22.0f;
    private static final float HEIGHT = 148.0f;
    private static final int[] HUES = new int[]{-65536, -256, -16711936, -16711681, -16776961, -65281, -65536};
    private IntBinding target;
    private float anchorX;
    private float anchorY;
    private float open;
    private float hue;
    private float saturation;
    private float brightness;
    private int dragging;
    private float x;
    private float y;

    public static void swatch(SquareCorners squareCorners, float f, float f2, int n, float f3) {
        float f4 = 15.0f + f3;
        float f5 = f - 15.0f - f3 / 2.0f;
        float f6 = f2 - f4 / 2.0f;
        squareCorners.shadow(f5, f6, f5 + f4, f6 + f4, 3.0f, 3.0f, LastSource.withAlpha(0xFF000000 | n, 0.25f + 0.2f * f3));
        squareCorners.roundRect(f5, f6, f5 + f4, f6 + f4, 3.0f, 0xFF000000 | n);
    }

    public boolean isOpen() {
        if (this.target == null) return false;
        return true;
    }

    public boolean isOpenFor(Object object) {
        if (this.target == null) return false;
        if (this.target.key() != object) return false;
        return true;
    }

    public void open(IntBinding mw2, float f, float f2) {
        if (this.isOpenFor(mw2.key())) {
            this.close();
            return;
        } else {
            this.target = mw2;
            this.anchorX = f;
            this.anchorY = f2;
            int n = mw2.get();
            float[] fArray = Color.RGBtoHSB(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF, null);
            this.hue = fArray[0];
            this.saturation = fArray[1];
            this.brightness = fArray[2];
            this.open = 0.0f;
        }
    }

    public void close() {
        this.target = null;
        this.dragging = 0;
    }

    public boolean contains(float f, float f2) {
        if (this.target == null) return false;
        if (!(f >= this.x)) return false;
        if (!(f < this.x + 152.0f)) return false;
        if (!(f2 >= this.y)) return false;
        if (!(f2 < this.y + 148.0f)) return false;
        return true;
    }

    public void render(ListeningModule listeningModule) {
        float f;
        if (this.target == null) return;
        SquareCorners squareCorners = listeningModule.painter;
        this.open = Tween.approach(this.open, 1.0f, 16.0f, listeningModule.dt);
        this.x = this.anchorX + 14.0f;
        if (this.x + 152.0f > listeningModule.width - 6.0f) {
            this.x = this.anchorX - 210.0f - 152.0f - 4.0f;
        }
        this.y = Math.max(6.0f, Math.min(listeningModule.height - 148.0f - 6.0f, this.anchorY - 20.0f));
        if (this.dragging != 0) {
            if (!listeningModule.mouseDown) {
                this.dragging = 0;
                listeningModule.captured = null;
            } else {
                this.update(listeningModule.mouseX, listeningModule.mouseY);
            }
        }
        float f2 = Tween.easeOutCubic(this.open);
        float f3 = squareCorners.alpha();
        squareCorners.alpha(f3 * f2);
        float f4 = this.y + (1.0f - f2) * 6.0f;
        squareCorners.shadow(this.x, f4 + 3.0f, this.x + 152.0f, f4 + 148.0f + 3.0f, 7.0f, 12.0f, 0x66000000);
        squareCorners.glass(this.x, f4, this.x + 152.0f, f4 + 148.0f, 7.0f, -1004988385);
        float f5 = this.x + 8.0f;
        float f6 = f4 + 8.0f;
        float f7 = this.x + 152.0f - 8.0f;
        float f8 = f6 + 92.0f;
        int n = 0xFF000000 | Color.HSBtoRGB(this.hue, 1.0f, 1.0f);
        int n2 = this.target.get();
        squareCorners.gradient(f5, f6, f7, f8, 4.0f, -1, n, -16777216, -16777216);
        squareCorners.stroke(f5, f6, f7, f8, 4.0f, 1.0f, 0x18FFFFFF);
        float f9 = f5 + (f7 - f5) * this.saturation;
        float f10 = f6 + (f8 - f6) * (1.0f - this.brightness);
        squareCorners.circle(f9, f10, 5.5f, 0x55000000);
        squareCorners.circle(f9, f10, 4.5f, -1);
        squareCorners.circle(f9, f10, 3.2f, 0xFF000000 | n2);
        float f11 = f8 + 8.0f;
        float f12 = f11 + 10.0f;
        float f13 = (f7 - f5) / 6.0f;
        for (int i = 0; i < 6; ++i) {
            float f14;
            f = f5 + f13 * (float)i;
            float f15 = i == 5 ? f7 : f + f13 + 0.5f;
            float f16 = f14 = i != 0 && i != 5 ? 0.0f : 5.0f;
            if (f14 > 0.0f) {
                float f17 = i == 0 ? f + 5.0f : f15 - 5.0f;
                int n3 = LastSource.mix(HUES[i], HUES[i + 1], (f17 - f) / (f15 - f));
                if (i == 0) {
                    squareCorners.gradient(f, f11, f + 10.0f, f12, f14, HUES[i], n3, n3, HUES[i]);
                    squareCorners.gradient(f17, f11, f15, f12, 0.0f, n3, HUES[i + 1], HUES[i + 1], n3);
                    continue;
                }
                squareCorners.gradient(f, f11, f17, f12, 0.0f, HUES[i], n3, n3, HUES[i]);
                squareCorners.gradient(f15 - 10.0f, f11, f15, f12, f14, n3, HUES[i + 1], HUES[i + 1], n3);
                continue;
            }
            squareCorners.gradient(f, f11, f15, f12, 0.0f, HUES[i], HUES[i + 1], HUES[i + 1], HUES[i]);
        }
        float f18 = f5 + (f7 - f5) * this.hue;
        squareCorners.circle(f18, (f11 + f12) / 2.0f, 6.0f, 0x55000000);
        squareCorners.circle(f18, (f11 + f12) / 2.0f, 5.0f, -1);
        squareCorners.circle(f18, (f11 + f12) / 2.0f, 3.5f, n);
        f = f12 + 8.0f + 11.0f;
        squareCorners.roundRect(f5, f - 7.0f, f5 + 14.0f, f + 7.0f, 3.0f, 0xFF000000 | n2);
        squareCorners.text(String.format("#%06X", n2 & 0xFFFFFF), f5 + 22.0f, f, -3553071);
        squareCorners.alpha(f3);
    }

    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2) {
        if (this.target == null) {
            return false;
        }
        if (!this.contains(f, f2)) {
            this.close();
            return true;
        }
        float f3 = this.x + 8.0f;
        float f4 = this.y + 8.0f;
        float f5 = this.x + 152.0f - 8.0f;
        float f6 = f4 + 92.0f;
        float f7 = f6 + 8.0f;
        float f8 = f7 + 10.0f;
        if (f >= f3 - 3.0f && f <= f5 + 3.0f && f2 >= f4 - 3.0f && f2 <= f6 + 3.0f) {
            this.dragging = 1;
        } else if (f >= f3 - 3.0f && f <= f5 + 3.0f && f2 >= f7 - 4.0f && f2 <= f8 + 4.0f) {
            this.dragging = 2;
        }
        if (this.dragging == 0) return true;
        listeningModule.captured = this;
        this.update(f, f2);
        return true;
    }

    private void update(float f, float f2) {
        float f3 = this.x + 8.0f;
        float f4 = this.y + 8.0f;
        float f5 = this.x + 152.0f - 8.0f;
        float f6 = f4 + 92.0f;
        if (this.dragging == 1) {
            this.saturation = Tween.clamp01((f - f3) / (f5 - f3));
            this.brightness = 1.0f - Tween.clamp01((f2 - f4) / (f6 - f4));
        } else if (this.dragging == 2) {
            this.hue = Math.min(0.9999f, Tween.clamp01((f - f3) / (f5 - f3)));
        }
        int n = this.target.get() & 0xFF000000;
        this.target.set(n == 0 ? 0xFF000000 | Color.HSBtoRGB(this.hue, this.saturation, this.brightness) & 0xFFFFFF : n | Color.HSBtoRGB(this.hue, this.saturation, this.brightness) & 0xFFFFFF);
    }
}
