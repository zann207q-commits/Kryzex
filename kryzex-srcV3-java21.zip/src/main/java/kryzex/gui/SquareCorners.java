package kryzex.gui;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.lang.reflect.Field;
import java.util.Arrays;
import kryzex.gui.CapHeight;
import kryzex.gui.DropdownFont;
import kryzex.gui.DropdownBlur;
import kryzex.gui.TextureSetup;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_11246;
import net.minecraft.class_12137;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;

public final class SquareCorners {
    private static final int MODE_RECT = 0;
    private static final int MODE_CIRCLE = 1;
    private static final int MODE_GLASS = 2;
    private static final int MODE_TEXTURE = 3;
    private static final int MODE_STROKE = 4;
    private static final int NO_CLIP = 0x7FFF0000;
    private static Field stateField;
    private float[] floats = new float[5632];
    private int[] ints = new int[3072];
    private int count;
    private float ox;
    private float oy;
    private float k = 1.0f;
    private float alpha = 1.0f;
    private float master = 1.0f;
    private int clip = 0x7FFF0000;
    private int squareCorners;
    private int seamless;
    private DropdownFont atlas;
    private float atlasScale = 1.0f;
    private CapHeight face;

    public void begin(DropdownFont r87f4560b4c09f4, float f, float f2) {
        this.atlas = r87f4560b4c09f4;
        this.atlasScale = f;
        this.face = r87f4560b4c09f4.body;
        this.count = 0;
        this.alpha = 1.0f;
        this.master = f2;
        this.clip = 0x7FFF0000;
        this.squareCorners = 0;
        this.seamless = 0;
        this.transform(0.0f, 0.0f, f);
    }

    public void useTitleFont() {
        this.face = this.atlas.title;
    }

    public void useBodyFont() {
        this.face = this.atlas.body;
    }

    public void transform(float f, float f2, float f3) {
        this.ox = f;
        this.oy = f2;
        this.k = f3;
    }

    public Object atlasKey() {
        if (this.atlas == null) {
            return null;
        }
        CapHeight capHeight = this.atlas.body;
        return capHeight;
    }

    public float scale() {
        return this.k;
    }

    public void alpha(float f) {
        this.alpha = Math.max(0.0f, Math.min(1.0f, f));
    }

    public void squareCorners(int n) {
        this.squareCorners = n & 0xF;
    }

    public void seamless(boolean bl, boolean bl2) {
        this.seamless = (bl ? 1 : 0) | (bl2 ? 2 : 0);
    }

    public float alpha() {
        return this.alpha;
    }

    public void clip(float f, float f2) {
        int n = Math.max(this.clip & 0xFFFF, Math.max(0, Math.min(Short.MAX_VALUE, Math.round(this.Y(f)))));
        int n2 = Math.min(this.clip >>> 16, Math.max(0, Math.min(Short.MAX_VALUE, Math.round(this.Y(f2)))));
        this.clip = n | Math.max(n, n2) << 16;
    }

    public int clipState() {
        return this.clip;
    }

    public void restoreClip(int n) {
        this.clip = n;
    }

    public float X(float f) {
        return this.ox + f * this.k;
    }

    public float Y(float f) {
        return this.oy + f * this.k;
    }

    public float pixel() {
        return 1.0f / this.k;
    }

    public void rect(float f, float f2, float f3, float f4, int n) {
        this.shape(f, f2, f3, f4, 0.0f, 0.0f, 0, n, n, n, n);
    }

    public void roundRect(float f, float f2, float f3, float f4, float f5, int n) {
        this.shape(f, f2, f3, f4, f5, 0.0f, 0, n, n, n, n);
    }

    public void gradient(float f, float f2, float f3, float f4, float f5, int n, int n2, int n3, int n4) {
        this.shape(f, f2, f3, f4, f5, 0.0f, 0, n, n4, n3, n2);
    }

    public void shadow(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        this.shape(f, f2, f3, f4, f5, Math.max(0.01f, f6), 0, n, n, n, n);
    }

    public void stroke(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if ((n = this.fade(n)) >>> 24 == 0 || f3 <= f || f4 <= f2) return;
        float f7 = this.X(f);
        float f8 = this.Y(f2);
        float f9 = this.X(f3);
        float f10 = this.Y(f4);
        float f11 = (f7 + f9) / 2.0f;
        float f12 = (f8 + f10) / 2.0f;
        int n2 = Math.min(2047, Math.round(f6 * this.k * 8.0f));
        int n3 = 4 | n2 << 4 | Math.min(Short.MAX_VALUE, Math.round(f5 * this.k * 16.0f)) << 16;
        float f13 = (float)n2 / 8.0f + 1.0f;
        this.put(f7 - f13, f8 - f13, f9 + f13, f10 + f13, f7 - f13 - f11, f8 - f13 - f12, f9 + f13 - f11, f10 + f13 - f12, n, n, n, n, n3, this.alpha * this.master);
    }

    public void glass(float f, float f2, float f3, float f4, float f5, int n) {
        this.shapeRaw(f, f2, f3, f4, f5 * this.k, 0.0f, 2, n, n, n, n, this.alpha * this.master);
    }

    public void circle(float f, float f2, float f3, int n) {
        this.circle(f, f2, f3, 0.0f, n);
    }

    public void circle(float f, float f2, float f3, float f4, int n) {
        if ((n = this.fade(n)) >>> 24 == 0) return;
        float f5 = f3 * this.k;
        float f6 = f4 * this.k;
        float f7 = f5 + f6 + 1.5f;
        float f8 = this.X(f);
        float f9 = this.Y(f2);
        int n2 = 1 | Math.min(2047, Math.round(f6 * 8.0f)) << 4 | Math.min(Short.MAX_VALUE, Math.round(f5 * 16.0f)) << 16;
        this.put(f8 - f7, f9 - f7, f8 + f7, f9 + f7, -f7, -f7, f7, f7, n, n, n, n, n2, this.alpha * this.master);
    }

    private void shape(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4, int n5) {
        this.shapeRaw(f, f2, f3, f4, f5 * this.k, f6 * this.k, n, this.fade(n2), this.fade(n3), this.fade(n4), this.fade(n5), this.alpha * this.master);
    }

    private void shapeRaw(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4, int n5, float f7) {
        if (f3 <= f || f4 <= f2 || (n2 | n3 | n4 | n5) >>> 24 == 0 && n != 2) return;
        float f8 = this.X(f);
        float f9 = this.Y(f2);
        float f10 = this.X(f3);
        float f11 = this.Y(f4);
        int n6 = Math.min(2047, Math.round(f6 * 8.0f));
        float f12 = (float)n6 / 8.0f + 1.0f;
        float f13 = (f8 + f10) / 2.0f;
        float f14 = (f9 + f11) / 2.0f;
        int n7 = n | n6 << 4 | Math.min(Short.MAX_VALUE, Math.round(f5 * 16.0f)) << 16;
        this.put(f8 - f12, f9 - f12, f10 + f12, f11 + f12, f8 - f12 - f13, f9 - f12 - f14, f10 + f12 - f13, f11 + f12 - f14, n2, n3, n4, n5, n7, f7);
    }

    public float textWidth(String string) {
        return this.textWidth(string, 0.0f);
    }

    public float tightWidth(String string) {
        return this.textWidth(string, this.face.tracking);
    }

    private float textWidth(String string, float f) {
        float f2 = 0.0f;
        for (int i = 0; i < string.length(); ++i) {
            f2 += this.advance(string.charAt(i)) + (string.charAt(i) == ' ' ? 0.0f : f);
        }
        return f2 / this.atlasScale;
    }

    public void text(String string, float f, float f2, int n, float f3) {
        if (this.textWidth(string, 0.0f) <= f3) {
            this.drawText(string, f, f2, n, 0.0f);
            return;
        } else if (this.textWidth(string, this.face.tracking) <= f3) {
            this.drawText(string, f, f2, n, this.face.tracking);
            return;
        } else {
            String string2 = string;
            while (string2.length() > 1 && this.textWidth(string2 + "..", this.face.tracking) > f3) {
                string2 = string2.substring(0, string2.length() - 1);
            }
            this.drawText(string2.stripTrailing() + "..", f, f2, n, this.face.tracking);
        }
    }

    public float capHeight() {
        return this.face.capHeight / this.atlasScale;
    }

    public void text(String string, float f, float f2, int n) {
        this.drawText(string, f, f2, n, 0.0f);
    }

    public void smallText(String string, float f, float f2, int n, float f3) {
        float f4 = this.ox;
        float f5 = this.oy;
        float f6 = this.k;
        float f7 = f6 * f3;
        this.ox = f4 + f * f6 - f * f7;
        this.oy = f5 + f2 * f6 - f2 * f7;
        this.k = f7;
        this.drawText(string, f, f2, n, 0.0f);
        this.ox = f4;
        this.oy = f5;
        this.k = f6;
    }

    public float smallWidth(String string, float f) {
        return this.textWidth(string) * f;
    }

    private void drawText(String string, float f, float f2, int n, float f3) {
        boolean bl;
        if ((n = this.fade(n)) >>> 24 == 0 || string.isEmpty()) return;
        float f4 = this.k / this.atlasScale;
        float f5 = this.X(f);
        float f6 = this.Y(f2) + this.face.capHeight * f4 / 2.0f;
        boolean bl2 = bl = Math.abs(f4 - 1.0f) < 0.001f;
        if (bl) {
            f5 = Math.round(f5);
            f6 = Math.round(f6);
        }
        float f7 = this.atlas.uScale();
        float f8 = this.atlas.vScale();
        float f9 = 0.0f;
        for (int i = 0; i < string.length(); ++i) {
            int n2 = string.charAt(i);
            CapHeight capHeight = this.glyphFace((char)n2);
            if (capHeight == null) {
                n2 = 63;
                capHeight = this.face;
            }
            float f10 = capHeight == this.face ? 1.0f : this.face.capHeight / capHeight.capHeight;
            int n3 = n2 - 32;
            if (n3 < 0 || n3 >= 95) continue;
            if (capHeight.w[n3] > 0) {
                float f11 = capHeight.drawScale * f10;
                float f12 = f5 + (f9 + (float)capHeight.offsetX[n3] * f11) * f4;
                float f13 = f6 + (float)capHeight.offsetY[n3] * f11 * f4;
                if (bl && capHeight.drawScale < 1.0f && capHeight == this.face) {
                    f13 = (float)Math.round(f13 + f11) - f11;
                }
                float f14 = (float)capHeight.w[n3] * f11 * f4;
                float f15 = (float)capHeight.h[n3] * f11 * f4;
                this.put(f12, f13, f12 + f14, f13 + f15, (float)capHeight.u[n3] * f7, (float)capHeight.v[n3] * f8, (float)(capHeight.u[n3] + capHeight.w[n3]) * f7, (float)(capHeight.v[n3] + capHeight.h[n3]) * f8, n, n, n, n, 3, this.alpha * this.master);
            }
            f9 += capHeight.advance[n3] * f10 + (n2 == 32 ? 0.0f : f3);
        }
    }

    private CapHeight glyphFace(char c) {
        if (this.face.has(c)) {
            return this.face;
        }
        if (!this.atlas.pixel.has(c)) return null;
        return this.atlas.pixel;
    }

    public void textRight(String string, float f, float f2, int n) {
        this.text(string, f - this.textWidth(string), f2, n);
    }

    public void textCentered(String string, float f, float f2, int n) {
        this.text(string, f - this.textWidth(string) / 2.0f, f2, n);
    }

    public void icon(String string, float f, float f2, int n, float f3) {
        n = this.fade(n);
        int[] nArray = this.atlas.icons.get(string);
        if (nArray == null || n >>> 24 == 0) return;
        float f4 = this.k / this.atlasScale;
        float f5 = (float)this.atlas.iconSize * f4 * f3;
        float f6 = this.X(f) - f5 / 2.0f;
        float f7 = this.Y(f2) - f5 / 2.0f;
        if (Math.abs(f4 * f3 - 1.0f) < 0.001f) {
            f6 = Math.round(f6);
            f7 = Math.round(f7);
        }
        float f8 = this.atlas.uScale();
        float f9 = this.atlas.vScale();
        this.put(f6, f7, f6 + f5, f7 + f5, (float)nArray[0] * f8, (float)nArray[1] * f9, (float)(nArray[0] + this.atlas.iconSize) * f8, (float)(nArray[1] + this.atlas.iconSize) * f9, n, n, n, n, 3, this.alpha * this.master);
    }

    public void icon(String string, float f, float f2, int n) {
        this.icon(string, f, f2, n, 1.0f);
    }

    private float advance(char c) {
        CapHeight capHeight = this.glyphFace(c);
        if (capHeight != null) return capHeight.advance[c - 32] * (capHeight == this.face ? 1.0f : this.face.capHeight / capHeight.capHeight);
        return this.face.advance[31];
    }

    private int fade(int n) {
        float f = this.alpha * this.master;
        if (!(f >= 1.0f)) return Math.round((float)(n >>> 24) * f) << 24 | n & 0xFFFFFF;
        return n;
    }

    private void put(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n, int n2, int n3, int n4, int n5, float f9) {
        if (this.count * 11 == this.floats.length) {
            this.floats = Arrays.copyOf(this.floats, this.floats.length * 2);
            this.ints = Arrays.copyOf(this.ints, this.ints.length * 2);
        }
        int n6 = this.count * 11;
        int n7 = this.count * 6;
        this.floats[n6] = f;
        this.floats[n6 + 1] = f2;
        this.floats[n6 + 2] = f3;
        this.floats[n6 + 3] = f4;
        this.floats[n6 + 4] = f5;
        this.floats[n6 + 5] = f6;
        this.floats[n6 + 6] = f7;
        this.floats[n6 + 7] = f8;
        this.floats[n6 + 8] = f9;
        this.floats[n6 + 9] = Math.min(1.0f, this.k / 4.0f);
        this.floats[n6 + 10] = (float)(this.squareCorners | this.seamless << 4) / 63.0f;
        this.ints[n7] = n;
        this.ints[n7 + 1] = n2;
        this.ints[n7 + 2] = n3;
        this.ints[n7 + 3] = n4;
        this.ints[n7 + 4] = n5;
        this.ints[n7 + 5] = this.clip;
        ++this.count;
    }

    public void submit(class_332 class_3322, GpuTextureView gpuTextureView, class_12137 class_121372) {
        if (this.count == 0) return;
        if (!DropdownBlur.ready(DropdownBlur.UI)) {
            this.count = 0;
            return;
        } else {
            class_310 class_3102 = class_310.method_1551();
            Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)class_3322.method_51448());
            class_8030 class_80302 = new class_8030(0, 0, class_3102.method_22683().method_4486(), class_3102.method_22683().method_4502());
            class_11231 class_112312 = class_11231.method_70901((GpuTextureView)gpuTextureView, (class_12137)class_121372, (GpuTextureView)this.atlas.view(), (class_12137)this.atlas.sampler());
            class_11246 class_112462 = SquareCorners.state(class_3322);
            if (class_112462 != null) {
                class_112462.method_70919((class_11244)new TextureSetup((Matrix3x2fc)matrix3x2f, class_112312, Arrays.copyOf(this.floats, this.count * 11), Arrays.copyOf(this.ints, this.count * 6), this.count, class_80302));
            }
            this.count = 0;
        }
    }

    private static class_11246 state(class_332 class_3322) {
        try {
            if (stateField == null) {
                for (Field field : class_332.class.getDeclaredFields()) {
                    if (field.getType() != class_11246.class) continue;
                    field.setAccessible(true);
                    stateField = field;
                    break;
                }
            }
            if (stateField == null) {
                return null;
            }
            class_11246 class_112462 = (class_11246)stateField.get(class_3322);
            return class_112462;
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}
