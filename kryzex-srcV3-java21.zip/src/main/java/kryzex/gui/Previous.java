package kryzex.gui;

import kryzex.gui.PaletteEntry;
import kryzex.gui.Items;
import kryzex.module.settings.MacroItemSetting;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

class Previous
implements Predicate<PaletteEntry> {
    List<String> previous;
    Set<String> selected;
    final MacroItemSetting val$list;

    Previous(MacroItemSetting l22) {
        this.val$list = l22;
        this.selected = Set.of();
    }

    @Override
    public boolean test(PaletteEntry ub) {
        List<String> list = this.val$list.get();
        if (this.previous == list) return this.selected.contains(ub.id());
        this.previous = list;
        HashSet<String> hashSet = new HashSet<String>();
        for (String string : list) {
            hashSet.add(Items.id((String)string));
        }
        this.selected = hashSet;
        return this.selected.contains(ub.id());
    }
}
