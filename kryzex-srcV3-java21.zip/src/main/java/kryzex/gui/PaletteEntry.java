package kryzex.gui;

import java.util.Locale;
import kryzex.module.settings.ToggleEntry;

public class PaletteEntry {
    public final String id;
    public final String name;
    public final Object item;
    public final ToggleEntry palette;

    public PaletteEntry(String id, String name, Object item, ToggleEntry palette) {
        this.id = id;
        this.name = name;
        this.item = item;
        this.palette = palette;
    }

    public String id() {
        return this.id;
    }

    public String name() {
        return this.name;
    }

    public Object item() {
        return this.item;
    }

    public ToggleEntry palette() {
        return this.palette;
    }
    public String search() {
        return (this.name + " " + this.id).toLowerCase(Locale.ROOT);
    }
}
