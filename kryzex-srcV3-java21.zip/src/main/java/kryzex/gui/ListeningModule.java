package kryzex.gui;

import java.util.Locale;
import kryzex.gui.OfferedText;
import kryzex.gui.Saturation;
import kryzex.gui.SquareCorners;
import kryzex.gui.GuiHost;
import kryzex.module.Module;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.StringSetting;

public final class ListeningModule {
    public final SquareCorners painter = new SquareCorners();
    public final OfferedText tooltip = new OfferedText();
    public final Saturation picker = new Saturation();
    public final GuiHost host;
    public float mouseX;
    public float mouseY;
    public boolean mouseDown;
    public float dt;
    public float time;
    public String query = "";
    public boolean searchFocused;
    public KeybindSetting listening;
    public Module listeningModule;
    public StringSetting editing;
    public float caretTime;
    public Object captured;
    public float width;
    public float height;
    public boolean hoverEnabled = true;

    public ListeningModule(GuiHost cT2) {
        this.host = cT2;
    }

    public boolean over(float f, float f2, float f3, float f4) {
        if (!this.hoverEnabled) return false;
        if (!(this.mouseX >= f)) return false;
        if (!(this.mouseX < f3)) return false;
        if (!(this.mouseY >= f2)) return false;
        if (!(this.mouseY < f4)) return false;
        return true;
    }

    public boolean typing() {
        if (this.searchFocused) return true;
        if (this.editing != null) return true;
        if (this.listening == null) return false;
        return true;
    }

    public static String name(CharSequence charSequence) {
        if (charSequence == null) {
            return "";
        }
        String string = charSequence.toString();
        return string;
    }

    public boolean matches(Module module) {
        if (this.query.isEmpty()) {
            return true;
        }
        String string = this.query.toLowerCase(Locale.ROOT).replace(" ", "");
        return ListeningModule.name(module.getName()).toLowerCase(Locale.ROOT).replace(" ", "").contains(string);
    }

    public static String pretty(String string) {
        if (string == null) {
            return "";
        }
        String string2 = string.replace('_', ' ').trim();
        if (string2.isEmpty()) return string2;
        if (!string2.equals(string2.toUpperCase(Locale.ROOT))) return string2;
        if (string2.length() <= 3) return string2;
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = true;
        char[] cArray = string2.toCharArray();
        int n = cArray.length;
        int n2 = 0;
        while (n2 < n) {
            char c = cArray[n2];
            stringBuilder.append(bl ? c : Character.toLowerCase(c));
            bl = c == ' ';
            ++n2;
        }
        return stringBuilder.toString();
    }
}
