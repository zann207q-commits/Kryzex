package kryzex.gui;

import java.io.InputStream;
import java.lang.reflect.Field;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Floats;
import kryzex.gui.KryzexClient;
import kryzex.gui.KryzexLoadingBrand;
import kryzex.gui.KryzexLoadingLogo;
import kryzex.gui.LoadingShader;
import kryzex.gui.TextSize;
import kryzex.gui.Theme;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_11246;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.jetbrains.annotations.Nullable;

public final class LoadingScreenLogo {
    private static final class_2960 LOGO_ID = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"loader/logo");
    private static final long START = System.nanoTime();
    private static final long SESSION_GAP = 450000000L;
    private static final float FADE_IN = 0.45f;
    private static final float REVEAL = 0.8f;
    private static final int MODE_BACKGROUND = 0;
    private static final int MODE_LOGO = 1;
    private static final int MODE_BAR = 2;
    private static Field stateField;
    private static KryzexLoadingLogo logo;
    private static boolean logoFailed;
    private static long sessionStart;
    private static long lastFrame;
    private static long revealStart;
    private static boolean revealArmed;
    private static float shown;
    private static float determinate;
    private static float sweep;
    private static String status;

    private LoadingScreenLogo() {
    }

    public static void screen(class_332 class_3322, float f, String string) {
        long l = System.nanoTime();
        LoadingScreenLogo.advance(l, f);
        status = string == null ? "" : KryzexClient.brand(string.strip());
        float f2 = (float)(l - sessionStart) / 1.0E9f;
        float f3 = LoadingScreenLogo.ease(LoadingScreenLogo.clamp01(f2 / 0.3f));
        float f4 = LoadingScreenLogo.ease(LoadingScreenLogo.clamp01((f2 - 0.06f) / 0.45f));
        float f5 = 0.965f + 0.035f * LoadingScreenLogo.ease(LoadingScreenLogo.clamp01(f2 / 0.75f));
        LoadingScreenLogo.draw(class_3322, f3, f4, f5, 0.0f, true);
        lastFrame = l;
        revealStart = 0L;
        revealArmed = true;
    }

    public static void splash(class_332 class_3322, float f, float f2) {
        long l = System.nanoTime();
        LoadingScreenLogo.advance(l, f);
        status = "";
        LoadingScreenLogo.draw(class_3322, f2, f2, 1.0f, 0.0f, false);
        lastFrame = l;
        revealStart = 0L;
        revealArmed = false;
    }

    public static void reveal(class_332 class_3322) {
        float f;
        class_310 class_3102 = class_310.method_1551();
        if (!revealArmed || lastFrame == 0L || class_3102.field_1687 == null || KryzexClient.loading(class_3102.field_1755) || class_3102.method_18506() != null) {
            return;
        }
        long l = System.nanoTime();
        if (revealStart == 0L) {
            if (l - lastFrame > 450000000L) {
                revealArmed = false;
                return;
            }
            revealStart = l;
        }
        if ((f = (float)(l - revealStart) / 1.0E9f / 0.8f) >= 1.0f) {
            revealArmed = false;
            revealStart = 0L;
            return;
        }
        float f2 = 1.0f - LoadingScreenLogo.ease(LoadingScreenLogo.clamp01(f / 0.45f));
        float f3 = 1.0f + 0.045f * LoadingScreenLogo.ease(LoadingScreenLogo.clamp01(f / 0.6f));
        class_3322.method_71048();
        LoadingScreenLogo.draw(class_3322, 1.0f, f2, f3, Math.max(5.0E-4f, LoadingScreenLogo.easeInOut(f)), true);
    }

    public static int buttonTop(int n) {
        class_310 class_3102 = class_310.method_1551();
        float f = class_3102.method_22683().method_4495();
        TextSize textSize = new TextSize(class_3102.method_22683().method_4489(), class_3102.method_22683().method_4506(), 1.0f);
        return Math.min(n - 26, Math.round((textSize.textY + textSize.textSize + 34.0f * textSize.unit) / f));
    }

    private static float advance(long l, float f) {
        if (lastFrame == 0L || l - lastFrame > 450000000L) {
            sessionStart = l;
            shown = Math.max(0.0f, f);
            determinate = f >= 0.0f ? 1.0f : 0.0f;
            sweep = 0.14f;
            lastFrame = l;
        }
        float f2 = Math.min(0.05f, Math.max(0.0f, (float)(l - lastFrame) / 1.0E9f));
        if (f >= 0.0f) {
            float f3 = LoadingScreenLogo.clamp01(f);
            if (determinate < 0.02f) {
                shown = Math.min(shown, f3);
            }
            shown += (f3 - shown) * (1.0f - (float)Math.exp(-7.5f * f2));
        }
        determinate += ((f >= 0.0f ? 1.0f : 0.0f) - determinate) * (1.0f - (float)Math.exp(-6.0f * f2));
        sweep += f2 / 1.55f;
        return f2;
    }

    private static void draw(class_332 class_3322, float f, float f2, float f3, float f4, boolean bl) {
        float f5;
        float f6;
        class_310 class_3102 = class_310.method_1551();
        int n = class_3102.method_22683().method_4489();
        int n2 = class_3102.method_22683().method_4506();
        float f7 = class_3102.method_22683().method_4495();
        TextSize textSize = new TextSize(n, n2, f3);
        float f8 = (float)(System.nanoTime() - START) / 1.0E9f;
        float f9 = sweep - (float)Math.floor(sweep);
        float f10 = -0.2f + 1.4f * LoadingScreenLogo.easeInOut(f9);
        float f11 = LoadingScreenLogo.clamp01(f10 - 0.16f);
        float f12 = LoadingScreenLogo.clamp01(f10 + 0.16f);
        float f13 = LoadingScreenLogo.lerp(f11, 0.0f, determinate);
        float f14 = LoadingScreenLogo.lerp(f12, shown, determinate);
        KryzexLoadingLogo kryzexLoadingLogo = LoadingScreenLogo.logo();
        if (kryzexLoadingLogo != null && LoadingShader.ready()) {
            int n3 = Theme.accent(1.0f);
            int n4 = Theme.bgTop(1.0f);
            int n5 = Theme.bgBottom(1.0f);
            f6 = Math.min(1.0f, textSize.unit / 4.0f);
            Floats floats = new Floats(f7, f8);
            floats.add(0.0f, 0.0f, n, n2, 0.0f, LoadingScreenLogo.withAlpha(n3, f), LoadingScreenLogo.rgb565(n4) | LoadingScreenLogo.rgb565(n5) << 16, 0, f4, f6);
            if (f2 > 0.003f) {
                float f15 = (float)Math.ceil(26.0f * textSize.unit);
                floats.add(textSize.logoX, textSize.logoY, textSize.logoX + textSize.logoW, textSize.logoY + textSize.logoH, f15, LoadingScreenLogo.withAlpha(n3, f2), 0, 1, 0.0f, f6);
                f5 = (float)Math.ceil(24.0f * textSize.unit);
                int n6 = Math.round(LoadingScreenLogo.clamp01(f13) * 32767.0f) | Math.round(LoadingScreenLogo.clamp01(Math.max(f13, f14)) * 32767.0f) << 16;
                floats.add(textSize.barX, textSize.barY, textSize.barX + textSize.barW, textSize.barY + textSize.barH, f5, LoadingScreenLogo.withAlpha(n3, f2), n6, 2, determinate, f6);
            }
            floats.submit(class_3322, kryzexLoadingLogo);
        } else {
            LoadingScreenLogo.fallback(class_3322, textSize, f7, f, f2, f13, f14);
        }
        if (!bl || !(f2 > 0.003f) || status.isEmpty()) return;
        class_3322.method_71048();
        BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
        baseRenderer.pushAlpha(f2);
        try {
            float f16 = textSize.textSize / f7;
            float f17 = textSize.barX / f7;
            f6 = textSize.textY / f7;
            float f18 = textSize.barW / f7;
            String string = Math.round(shown * 100.0f) + "%";
            f5 = determinate > 0.02f ? baseRenderer.textWidth(string, f16, 1) + 10.0f / f7 * textSize.unit : 0.0f;
            String string2 = baseRenderer.ellipsize(status, Math.max(8.0f, f18 - f5), f16, 0);
            baseRenderer.text(string2, f17, f6, f16, 0, BaseRenderer.white(0.58f));
            if (!(determinate > 0.02f)) return;
            baseRenderer.pushAlpha(determinate);
            baseRenderer.textRight(string, f17 + f18, f6, f16, 1, BaseRenderer.white(0.86f));
            baseRenderer.popAlpha();
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    private static void fallback(class_332 class_3322, TextSize textSize, float f, float f2, float f3, float f4, float f5) {
        BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
        float f6 = class_3322.method_51421();
        float f7 = class_3322.method_51443();
        baseRenderer.pushAlpha(f2);
        baseRenderer.gradient(0.0f, 0.0f, f6, f7, Theme.bgTop(1.0f), Theme.bgBottom(1.0f));
        baseRenderer.popAlpha();
        baseRenderer.pushAlpha(f3);
        try {
            baseRenderer.texture(KryzexLoadingBrand.logo(), textSize.logoX / f, textSize.logoY / f, textSize.logoW / f, textSize.logoH / f, -1);
            float f8 = textSize.barX / f;
            float f9 = textSize.barY / f;
            float f10 = textSize.barW / f;
            float f11 = Math.max(1.0f, textSize.barH / f);
            baseRenderer.round(f8, f9, f10, f11, f11 / 2.0f, BaseRenderer.white(0.1f));
            if (!(f5 > f4)) return;
            baseRenderer.round(f8 + f10 * f4, f9, f10 * (f5 - f4), f11, f11 / 2.0f, Theme.accent(1.0f));
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    @Nullable
    private static KryzexLoadingLogo logo() {
        if (logo != null || logoFailed) return logo;
        try (InputStream inputStream = LoadingScreenLogo.class.getResourceAsStream("/assets/r87f4560b4c09f4/menu/title.png");){
            logo = new KryzexLoadingLogo(class_1011.method_4309((InputStream)inputStream));
            class_310.method_1551().method_1531().method_4616(LOGO_ID, (class_1044)logo);
            return logo;
        }
        catch (Throwable throwable) {
            logoFailed = true;
            System.err.println("Kryzex: loading screen logo unavailable: " + String.valueOf(throwable));
        }
        return logo;
    }

    private static int withAlpha(int n, float f) {
        return Math.round(LoadingScreenLogo.clamp01(f) * 255.0f) << 24 | n & 0xFFFFFF;
    }

    private static int rgb565(int n) {
        int n2 = Math.round((float)(n >> 16 & 0xFF) / 255.0f * 31.0f);
        int n3 = Math.round((float)(n >> 8 & 0xFF) / 255.0f * 63.0f);
        int n4 = Math.round((float)(n & 0xFF) / 255.0f * 31.0f);
        return n2 << 11 | n3 << 5 | n4;
    }

    public static float clamp01(float f) {
        return Math.max(0.0f, Math.min(1.0f, f));
    }

    private static float lerp(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }

    private static float ease(float f) {
        float f2 = 1.0f - f;
        return 1.0f - f2 * f2 * f2;
    }

    private static float easeInOut(float f) {
        return f < 0.5f ? 4.0f * f * f * f : 1.0f - (float)Math.pow(-2.0f * f + 2.0f, 3.0) / 2.0f;
    }

    @Nullable
    public static class_11246 state(class_332 class_3322) {
        try {
            if (stateField == null) {
                for (Field field : class_332.class.getDeclaredFields()) {
                    if (field.getType() != class_11246.class) continue;
                    field.setAccessible(true);
                    stateField = field;
                    break;
                }
            }
            if (stateField == null) {
                return null;
            }
            class_11246 class_112462 = (class_11246)stateField.get(class_3322);
            return class_112462;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    static {
        status = "";
    }
}
