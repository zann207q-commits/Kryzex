package kryzex.gui;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Locale;
import kryzex.config.ConfigProfileManager;
import net.fabricmc.loader.api.FabricLoader;

public final class Filename {
    private final String filename;
    private float x;
    private float y;
    private boolean loaded;
    private boolean dragging;
    private boolean pressed;
    private double grabX;
    private double grabY;

    public Filename(String string, float f, float f2) {
        this.filename = string;
        this.x = f;
        this.y = f2;
    }

    private Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve(this.filename);
    }

    private void load() {
        if (this.loaded) {
            return;
        }
        this.loaded = true;
        try {
            if (!Files.isRegularFile(this.path(), new LinkOption[0])) return;
            String[] stringArray = Files.readString(this.path()).trim().split(",");
            float f = Float.parseFloat(stringArray[0]);
            float f2 = Float.parseFloat(stringArray[1]);
            if (!Float.isFinite(f) || !Float.isFinite(f2)) return;
            this.x = Math.max(0.0f, Math.min(1.0f, f));
            this.y = Math.max(0.0f, Math.min(1.0f, f2));
            return;
        }
        catch (Exception exception) {

        }
    }

    public float x(int n) {
        this.load();
        return this.x * (float)n;
    }

    public float y(int n) {
        this.load();
        return this.y * (float)n;
    }

    public boolean dragging() {
        return this.dragging;
    }

    public void update(boolean bl, boolean bl2, double d, double d2, float f, float f2, float f3, float f4, int n, int n2) {
        this.load();
        if (bl && bl2 && !this.pressed && d >= (double)f && d2 >= (double)f2 && d < (double)(f + f3) && d2 < (double)(f2 + f4)) {
            this.dragging = true;
            this.grabX = d - (double)f;
            this.grabY = d2 - (double)f2;
        }
        if (this.dragging && bl && bl2) {
            this.x = (float)Math.max(8.0, Math.min((double)((float)n - f3 - 8.0f), d - this.grabX)) / (float)Math.max(1, n);
            this.y = (float)Math.max(8.0, Math.min((double)((float)n2 - f4 - 8.0f), d2 - this.grabY)) / (float)Math.max(1, n2);
        }
        if (!(!this.dragging || bl && bl2)) {
            this.dragging = false;
            try {
                ConfigProfileManager.writeAtomic(this.path(), String.format(Locale.ROOT, "%.6f,%.6f", Float.valueOf(this.x), Float.valueOf(this.y)));
            }
            catch (Exception exception) {

            }
        }
        this.pressed = bl && bl2;
    }
}
