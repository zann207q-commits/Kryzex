package kryzex.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.lang.invoke.MethodHandle;
import kryzex.gui.LoadingShader;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fc;
import org.joml.Vector2f;

final class TextureSetup2
implements class_11244 {
    private final Matrix3x2fc pose;
    private final class_11231 textureSetup;
    private final float[] floats;
    private final int[] ints;
    private final int count;
    private final float time;
    @Nullable
    private final class_8030 bounds;

    public TextureSetup2(Matrix3x2fc matrix3x2fc, class_11231 class_112312, float[] fArray, int[] nArray, int n, float f, @Nullable class_8030 class_80302) {
        this.pose = matrix3x2fc;
        this.textureSetup = class_112312;
        this.floats = fArray;
        this.ints = nArray;
        this.count = n;
        this.time = f;
        this.bounds = class_80302;
    }

    public void method_70917(class_4588 class_45882) {
        Vector2f vector2f = new Vector2f();
        for (int i = 0; i < this.count; ++i) {
            int n = i * 8;
            int n2 = i * 4;
            float f = this.floats[n];
            float f2 = this.floats[n + 1];
            float f3 = this.floats[n + 2];
            float f4 = this.floats[n + 3];
            float f5 = this.floats[n + 4];
            float f6 = this.floats[n + 5];
            float f7 = this.floats[n + 6];
            int n3 = this.ints[n2];
            int n4 = this.ints[n2 + 1] & 0xFFFF;
            int n5 = this.ints[n2 + 1] >>> 16;
            int n6 = this.ints[n2 + 2];
            int n7 = this.ints[n2 + 3];
            this.corner(class_45882, vector2f, f, 0.0f, -f5, -f6, n3, n4, n5, n6, n7, f7);
            this.corner(class_45882, vector2f, f, f4, -f5, f6, n3, n4, n5, n6, n7, f7);
            this.corner(class_45882, vector2f, f3, f4, f5, f6, n3, n4, n5, n6, n7, f7);
            this.corner(class_45882, vector2f, f3, 0.0f, f5, -f6, n3, n4, n5, n6, n7, f7);
        }
    }

    private void corner(class_4588 class_45882, Vector2f vector2f, float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, int n5, float f5) {
        this.pose.transformPosition(f, f2, vector2f);
        class_45882.method_22912(vector2f.x, vector2f.y, this.time).method_39415(n).method_22913(f3, f4).method_60796(n2, n3).method_22921(n4, n5).method_22914(f5, 0.0f, 0.0f);
    }

    public RenderPipeline comp_4055() {
        return LoadingShader.LOADER;
    }

    @Nullable
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public final String toString() {
        return "TextureSetup2[" + "pose=" + this.pose + ", " + "textureSetup=" + this.textureSetup + ", " + "floats=" + this.floats + ", " + "ints=" + this.ints + ", " + "count=" + this.count + ", " + "time=" + this.time + ", " + "bounds=" + this.bounds + "]";
    }

    @Override
    public final int hashCode() {
        return java.util.Objects.hash(this.pose, this.textureSetup, this.floats, this.ints, this.count, this.time, this.bounds);
    }

    @Override
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextureSetup2)) {
            return false;
        }
        TextureSetup2 texturesetup2 = (TextureSetup2)object;
        return java.util.Objects.equals(this.pose, texturesetup2.pose) &&
                java.util.Objects.equals(this.textureSetup, texturesetup2.textureSetup) &&
                java.util.Objects.equals(this.floats, texturesetup2.floats) &&
                java.util.Objects.equals(this.ints, texturesetup2.ints) &&
                java.util.Objects.equals(this.count, texturesetup2.count) &&
                java.util.Objects.equals(this.time, texturesetup2.time) &&
                java.util.Objects.equals(this.bounds, texturesetup2.bounds);
    }

    public Matrix3x2fc pose() {
        return this.pose;
    }

    public class_11231 comp_4056() {
        return this.textureSetup;
    }

    public float[] floats() {
        return this.floats;
    }

    public int[] ints() {
        return this.ints;
    }

    public int count() {
        return this.count;
    }

    public float time() {
        return this.time;
    }

    @Nullable
    public class_8030 comp_4274() {
        return this.bounds;
    }
}
