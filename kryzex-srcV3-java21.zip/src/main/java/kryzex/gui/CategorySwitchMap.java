package kryzex.gui;

import kryzex.module.Category;

class CategorySwitchMap {
    static final int[] $SwitchMap$kryzex$module$Category = new int[Category.values().length];

    static {
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.COMBAT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.MISC.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.MACROS.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.DONUT.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.RENDER.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            CategorySwitchMap.$SwitchMap$kryzex$module$Category[Category.CLIENT.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
    }
}
