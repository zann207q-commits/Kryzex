package kryzex.gui;

final class Bottom2 {
    boolean moved;
    boolean right;
    boolean bottom;
    float ox;
    float oy;

    public Bottom2() {
    }
}
