package kryzex.gui;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import kryzex.cinematic.Ambience;
import kryzex.cinematic.CinematicDirector;
import kryzex.client.KryzexClient;
import kryzex.gui.ColorPickerScreen;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiRenderer;
import kryzex.gui.HudActions;
import kryzex.gui.KeybindScreen;
import kryzex.gui.PhaseTime;
import kryzex.module.Module;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.ListSetting;
import kryzex.modules.client.KryzexPlus;
import kryzex.modules.misc.NameProtect;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.Unknown2;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1041;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3419;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_640;
import net.minecraft.class_7923;

public final class ClickGuiScreen
extends class_437
implements HudActions {
    private final PhaseTime ui = new PhaseTime(this);
    private boolean freshOpen = true;
    private boolean inEditor;
    private boolean finishPending;
    private Runnable afterClose;
    private List<class_1792> items;

    public ClickGuiScreen() {
        super((class_2561)class_2561.method_43473());
    }

    public void prepareOpen() {
        if (KryzexClient.mc != null && KryzexClient.mc.field_1755 == this) {
            this.ui.onOpen(false);
            this.freshOpen = false;
            return;
        } else {
            this.freshOpen = true;
        }
    }

    protected void method_25426() {
        this.ui.onOpen(this.freshOpen);
        this.freshOpen = false;
        this.inEditor = false;
        this.afterClose = null;
        this.syncAmbience();
    }

    private boolean ambienceWanted() {
        class_437 class_4372;
        class_437 class_4373 = class_4372 = KryzexClient.mc == null ? null : KryzexClient.mc.field_1755;
        if (class_4372 == this) {
            if (this.ui.isClosing()) return false;
            return true;
        }
        if (!this.inEditor) return false;
        if (class_4372 instanceof KeybindScreen) return true;
        if (!(class_4372 instanceof ColorPickerScreen)) return false;
        return true;
    }

    public boolean showing() {
        return this.ambienceWanted();
    }

    @Override
    public float beat() {
        return Ambience.beat();
    }

    @Override
    public float shakeStrength() {
        if (!KryzexPlus.beatShake.getValue()) return 0.0f;
        float f = (float)(KryzexPlus.shakeStrength.getValue() / 100.0);
        return f;
    }

    public void syncAmbience() {
        try {
            if (KryzexClient.mc == null || KryzexClient.mc.field_1690 == null) return;
            GuiAudio.setMaster(KryzexClient.mc.field_1690.method_71978(class_3419.field_15250));
            return;
        }
        catch (Throwable throwable) {

        }
    }

    public static int blurRadius(int n) {
        try {
            ClickGuiScreen clickGuiScreen = KryzexClient.INSTANCE.GUI;
            if (clickGuiScreen == null || KryzexClient.mc == null || KryzexClient.mc.field_1755 != clickGuiScreen) return n;
            return Math.round((float)n * clickGuiScreen.ui.visibility());
        }
        catch (Throwable throwable) {

        }
        return n;
    }

    public boolean isTyping() {
        return this.ui.isTyping();
    }

    public void requestClose() {
        this.ui.requestClose();
        GuiAudio.setAmbience(false);
    }

    public void method_25419() {
        this.requestClose();
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        if (this.field_22787 == null || this.field_22787.method_22683() == null) return;
        class_1041 class_10412 = this.field_22787.method_22683();
        int n3 = class_10412.method_4489();
        int n4 = class_10412.method_4506();
        if (n3 <= 0 || n4 <= 0) return;
        InverseProjectionScratch.setContext(class_3322);
        if (CinematicDirector.guiLocked() && !this.ui.isClosing()) {
            this.requestClose();
        }
        this.syncAmbience();
        if (KryzexClient.INSTANCE.screen != null && KryzexClient.INSTANCE.screen != this) {
            KryzexClient.INSTANCE.screen.method_25394(class_3322, 0, 0, f);
        }
        if (ClickGuiScreen.blurRadius(this.field_22787.field_1690.method_57703()) > 0) {
            try {
                class_3322.method_71278();
            }
            catch (Throwable throwable) {

            }
        }
        float f2 = class_10412.method_4495();
        double d = this.field_22787.field_1729.method_1603() * (double)n3 / (double)Math.max(1, class_10412.method_4480());
        double d2 = this.field_22787.field_1729.method_1604() * (double)n4 / (double)Math.max(1, class_10412.method_4507());
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().scale(1.0f / f2, 1.0f / f2);
        try {
            float f3 = (float)(KryzexPlus.guiSize.getValue() / 100.0);
            this.ui.render(new GuiRenderer(class_3322, f2), n3, n4, d, d2, f3);
        }
        finally {
            class_3322.method_51448().popMatrix();
        }
        if (!this.finishPending) return;
        this.finishPending = false;
        this.finishClose();
    }

    private void finishClose() {
        Module module = KryzexClient.INSTANCE.getModuleManager().getModuleByClass(KryzexPlus.class);
        if (module != null) {
            module.setEnabled(false);
        }
        try {
            KryzexClient.INSTANCE.getSettingsManager().saveNow();
        }
        catch (Throwable throwable) {
            throwable.printStackTrace(System.err);
        }
        Runnable runnable = this.afterClose;
        this.afterClose = null;
        if (this.field_22787 == null || this.field_22787.field_1755 != this) return;
        if (runnable != null) {
            runnable.run();
            return;
        } else {
            this.field_22787.method_1507(KryzexClient.INSTANCE.screen);
        }
    }

    private double sx(double d) {
        return d * (this.field_22787 == null ? 1.0 : (double)this.field_22787.method_22683().method_4495());
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        return this.ui.mouseClicked(this.sx(class_119092.comp_4798()), this.sx(class_119092.comp_4799()), class_119092.method_74245());
    }

    public boolean method_25406(class_11909 class_119092) {
        this.ui.mouseReleased(this.sx(class_119092.comp_4798()), this.sx(class_119092.comp_4799()), class_119092.method_74245());
        return true;
    }

    public boolean method_25403(class_11909 class_119092, double d, double d2) {
        this.ui.mouseDragged(this.sx(class_119092.comp_4798()), this.sx(class_119092.comp_4799()));
        return true;
    }

    public boolean method_25401(double d, double d2, double d3, double d4) {
        this.ui.mouseScrolled(this.sx(d), this.sx(d2), d4);
        return true;
    }

    public boolean method_25404(class_11908 class_119082) {
        return this.ui.keyPressed(class_119082.comp_4795(), class_119082.comp_4797());
    }

    public boolean method_25400(class_11905 class_119052) {
        if (!class_119052.method_74227()) return false;
        if (!this.ui.charTyped((char)class_119052.comp_4793())) return false;
        return true;
    }

    @Override
    public String playerName() {
        try {
            String string = this.field_22787.method_1548().method_1676();
            return NameProtect.O(string);
        }
        catch (Throwable throwable) {
            return NameProtect.O("Player");
        }
    }

    @Override
    public String serverLine() {
        try {
            class_640 class_6402;
            String string;
            if (this.field_22787.field_1687 == null) {
                return "Main menu";
            }
            if (this.field_22787.method_1542()) {
                return "Singleplayer";
            }
            String string2 = string = this.field_22787.method_1558() != null ? this.field_22787.method_1558().field_3761 : "Multiplayer";
            if (this.field_22787.field_1724 == null || this.field_22787.method_1562() == null || (class_6402 = this.field_22787.method_1562().method_2871(this.field_22787.field_1724.method_5667())) == null) return string;
            return string + "  \u00b7  " + class_6402.method_2959() + " ms";
        }
        catch (Throwable throwable) {
            return "";
        }
    }

    @Override
    public boolean inWorld() {
        if (this.field_22787 == null) return false;
        if (this.field_22787.field_1724 == null) return false;
        if (this.field_22787.field_1687 == null) return false;
        return true;
    }

    @Override
    public String keyName(int n) {
        try {
            CharSequence charSequence = Unknown2.getKey(n);
            if (charSequence == null) {
                return null;
            }
            String string = charSequence.toString();
            return string;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    @Override
    public void openStorage(ListSetting listSetting) {
        this.ui.openStorage(listSetting);
    }

    @Override
    public void openHudEditor() {
        if (!this.inWorld()) return;
        this.afterClose = this::lmbd$openHudEditor$0;
        this.ui.requestClose();
    }

    @Override
    public void closeNow() {
        this.finishPending = true;
    }

    @Override
    public List<?> items() {
        if (this.items != null) return this.items;
        this.items = new ArrayList<class_1792>();
        for (class_1792 class_17922 : class_7923.field_41178) {
            if (class_17922 == class_1802.field_8162) continue;
            this.items.add(class_17922);
        }
        return this.items;
    }

    @Override
    public String itemName(Object object) {
        try {
            if (!(object instanceof class_1792)) return "None";
            class_1792 class_17922 = (class_1792)object;
            String string = class_17922.method_63680().getString();
            return string;
        }
        catch (Throwable throwable) {
            return "Item";
        }
    }

    @Override
    public Object itemOf(ItemSetting itemSetting) {
        return itemSetting.getItem();
    }

    @Override
    public void setItem(ItemSetting itemSetting, Object object) {
        if (!(object instanceof class_1792)) return;
        class_1792 class_17922 = (class_1792)object;
        itemSetting.setItem(class_17922);
    }

    @Override
    public Path stateFile() {
        try {
            return FabricLoader.getInstance().getConfigDir().resolve("kryzex-gui-position.txt");
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private void lmbd$openHudEditor$0() {
        this.field_22787.method_1507((class_437)new class_408("", false));
    }
}
