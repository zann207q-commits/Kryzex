package kryzex.gui;

class LabelColor {
    public final String icon;
    public final String value;
    public final String label;
    public final int labelColor;
    public final boolean logo;

    public LabelColor(String icon, String value, String label, int labelColor, boolean logo) {
        this.icon = icon;
        this.value = value;
        this.label = label;
        this.labelColor = labelColor;
        this.logo = logo;
    }

    public String icon() {
        return this.icon;
    }

    public String value() {
        return this.value;
    }

    public String label() {
        return this.label;
    }

    public int labelColor() {
        return this.labelColor;
    }

    public boolean logo() {
        return this.logo;
    }
}
