package kryzex.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Easing;
import kryzex.gui.HalloweenFx;
import kryzex.gui.Handle;
import kryzex.gui.Speed;
import kryzex.gui.Speed2;

public final class WorldPitch {
    private static final int GHOSTS = 7;
    static volatile float worldRoll;
    static volatile float worldPitch;
    private static volatile long shakeAt;
    private final Random rnd = new Random();
    private final List<Speed2> ghosts = new ArrayList<Speed2>();
    private final List<Speed> bats = new ArrayList<Speed>();
    private float batTimer = 5.0f;
    private float sx;
    private float sy;
    private float svx;
    private float svy;
    private float kick;
    private float kickVel;
    private float[] window;

    public static float worldRoll() {
        if (System.nanoTime() - shakeAt >= 150000000L) return 0.0f;
        float f = worldRoll;
        return f;
    }

    public static float worldPitch() {
        if (System.nanoTime() - shakeAt >= 150000000L) return 0.0f;
        float f = worldPitch;
        return f;
    }

    float[] shake(float f, float f2, float f3, float f4, float f5) {
        float f6 = f4 / 1080.0f * 7.0f * f3;
        float f7 = (float)(Math.sin((double)f5 * 9.7) * 0.6 + Math.sin((double)f5 * 5.3 + 1.1) * 0.4);
        float f8 = (float)(Math.sin((double)f5 * 8.1 + 2.3) * 0.5 + Math.sin((double)f5 * 4.7 + 0.4) * 0.5);
        float f9 = f7 * f2 * f6 * 0.75f;
        float f10 = (f8 * 0.45f + 0.55f) * f2 * f6;
        float f11 = 260.0f;
        float f12 = 2.0f * (float)Math.sqrt(f11) * 0.9f;
        int n = Math.max(1, (int)Math.ceil(f / 0.004f));
        float f13 = f / (float)n;
        for (int i = 0; i < n; ++i) {
            this.svx += ((f9 - this.sx) * f11 - this.svx * f12) * f13;
            this.svy += ((f10 - this.sy) * f11 - this.svy * f12) * f13;
            this.sx += this.svx * f13;
            this.sy += this.svy * f13;
            this.kickVel += ((f2 * f3 - this.kick) * f11 - this.kickVel * f12) * f13;
            this.kick += this.kickVel * f13;
        }
        worldRoll = this.sx / Math.max(1.0f, f6) * 0.35f * f3;
        worldPitch = this.kick * 0.28f;
        shakeAt = System.nanoTime();
        return new float[]{this.sx, this.sy};
    }

    void calm() {
        worldRoll = 0.0f;
        worldPitch = 0.0f;
    }

    void background(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float[] fArray) {
        this.window = fArray;
        if (f5 <= 0.003f) {
            return;
        }
        float f6 = Math.max(f, f2);
        baseRenderer.pushAlpha(f5);
        float f7 = f2 * 0.115f;
        float f8 = f * 0.83f + (float)Math.sin((double)f3 * 0.05) * f * 0.004f;
        float f9 = f2 * 0.17f;
        baseRenderer.glow(f8, f9, f7 * 3.4f, BaseRenderer.argb(0.055f, 255, 190, 140));
        baseRenderer.glow(f8, f9, f7 * 1.5f, BaseRenderer.argb(0.1f, 255, 228, 200));
        baseRenderer.texture(HalloweenFx.moon(Math.round(f7)), f8 - f7 / 2.0f, f9 - f7 / 2.0f, f7, f7, BaseRenderer.white(0.21f));
        float f10 = f2 * 0.3f;
        float f11 = f * 1.25f;
        Handle handle = HalloweenFx.mist(512, 128);
        this.mistLayer(baseRenderer, handle, f, f2, f10, f11, f3 * 9.0f, BaseRenderer.argb(0.13f, 196, 180, 224));
        this.mistLayer(baseRenderer, handle, f, f2, f10 * 0.75f, f11 * 0.8f, -f3 * 5.5f + f11 * 0.37f, BaseRenderer.argb(0.09f, 220, 160, 140));
        float f12 = f2 * 0.26f;
        float f13 = (float)Math.sin((double)f3 * 0.55) * f2 * 0.0018f;
        baseRenderer.texture(HalloweenFx.web(Math.round(f12)), -2.0f + f13, -2.0f, f12, f12, BaseRenderer.white(0.068f));
        baseRenderer.texture(HalloweenFx.web(Math.round(f12), true), f - f12 + 2.0f - f13, -2.0f, f12, f12, BaseRenderer.white(0.058f));
        this.pumpkin(baseRenderer, f * 0.045f, f2, f2 * 0.13f, f3, 0.0f);
        this.pumpkin(baseRenderer, f - f * 0.075f, f2, f2 * 0.095f, f3, 2.3f);
        this.pumpkin(baseRenderer, f - f * 0.03f - f2 * 0.11f, f2, f2 * 0.065f, f3, 4.1f);
        this.bats(baseRenderer, f, f2, f4, f3);
        this.ghosts(baseRenderer, f, f2, f4, f3, f6);
        baseRenderer.popAlpha();
    }

    private void mistLayer(BaseRenderer baseRenderer, Handle handle, float f, float f2, float f3, float f4, float f5, int n) {
        float f6 = f5 % f4;
        if (f6 > 0.0f) {
            f6 -= f4;
        }
        for (float f7 = f6; f7 < f; f7 += f4) {
            baseRenderer.texture(handle, f7, f2 - f3, f4 + 1.0f, f3, n);
        }
    }

    private void pumpkin(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5) {
        float f6 = 0.62f + 0.22f * (float)Math.sin((double)f4 * 7.3 + (double)f5) + 0.16f * (float)Math.sin((double)f4 * 13.1 + (double)(f5 * 2.0f));
        float f7 = f2 - f3 * 0.92f;
        baseRenderer.glow(f, f7 + f3 * 0.55f, f3 * 1.6f, BaseRenderer.argb(0.07f * f6, 255, 140, 40));
        baseRenderer.glow(f, f7 + f3 * 0.62f, f3 * 0.55f, BaseRenderer.argb(0.16f * f6, 255, 196, 90));
        baseRenderer.texture(HalloweenFx.pumpkin(Math.round(f3)), f - f3 / 2.0f, f7, f3, f3, BaseRenderer.white(0.78f));
    }

    private void bats(BaseRenderer baseRenderer, float f, float f2, float f3, float f4) {
        this.batTimer -= f3;
        if (this.batTimer <= 0.0f && this.bats.size() < 2) {
            Speed speed = new Speed();
            speed.dir = this.rnd.nextBoolean() ? 1 : -1;
            speed.x = speed.dir > 0 ? -0.08f : 1.08f;
            speed.y = 0.08f + this.rnd.nextFloat() * 0.22f;
            speed.speed = 0.075f + this.rnd.nextFloat() * 0.05f;
            speed.size = 0.028f + this.rnd.nextFloat() * 0.016f;
            speed.phase = this.rnd.nextFloat() * 10.0f;
            this.bats.add(speed);
            this.batTimer = 7.0f + this.rnd.nextFloat() * 9.0f;
        }
        for (int i = this.bats.size() - 1; i >= 0; --i) {
            Speed speed = this.bats.get(i);
            speed.x += (float)speed.dir * speed.speed * f3;
            speed.age += f3;
            if (speed.x < -0.12f || speed.x > 1.12f) {
                this.bats.remove(i);
                continue;
            }
            float f5 = (speed.age * 11.0f + speed.phase) % 3.0f;
            int n = (int)f5;
            float f6 = speed.size * f2 * 2.0f;
            float f7 = f6 / 2.0f;
            float f8 = (speed.y + 0.018f * (float)Math.sin(speed.age * 3.1f + speed.phase)) * f2;
            float f9 = Math.min(1.0f, Math.min(speed.x + 0.1f, 1.1f - speed.x) / 0.1f);
            baseRenderer.texture(HalloweenFx.bat(Math.round(f6), n), speed.x * f - f6 / 2.0f, f8, f6, f7, BaseRenderer.argb(0.42f * f9, 14, 6, 20));
        }
    }

    private void ghosts(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5) {
        int n;
        if (this.ghosts.isEmpty()) {
            for (n = 0; n < 7; ++n) {
                Speed2 speed2 = new Speed2();
                this.respawn(speed2);
                speed2.age = this.rnd.nextFloat() * speed2.life;
                this.ghosts.add(speed2);
            }
        }
        n = Math.round(f2 * 0.085f);
        for (Speed2 speed2 : this.ghosts) {
            float f6;
            speed2.age += f3;
            if (speed2.age >= speed2.life) {
                this.respawn(speed2);
            }
            float f7 = speed2.age + speed2.seed;
            float f8 = speed2.drift + 0.018f * (float)Math.sin(f7 * 0.31f) + 0.01f * (float)Math.sin(f7 * 0.77f + 1.3f);
            float f9 = -0.006f + 0.012f * (float)Math.sin(f7 * 0.23f + 2.1f) + 0.006f * (float)Math.sin(f7 * 0.61f);
            speed2.x += f8 * speed2.speed * f3;
            speed2.y += f9 * speed2.speed * f3;
            float f10 = Easing.out(speed2.age / 2.6f);
            float f11 = Easing.out((speed2.life - speed2.age) / 2.8f);
            float f12 = Math.min(f10, f11);
            float f13 = (float)Math.sin(f4 * 1.25f + speed2.seed) * 0.006f;
            float f14 = 1.0f + 0.035f * (float)Math.sin(f4 * 1.9f + speed2.seed * 2.0f);
            float f15 = f6 = speed2.size * f2 * f14;
            float f16 = f6 * 1.25f;
            float f17 = speed2.x * f;
            float f18 = (speed2.y + f13) * f2;
            float f19 = speed2.alpha * f12 * this.behind(f17, f18, f6);
            if (f19 <= 0.002f) continue;
            baseRenderer.glow(f17, f18, f6 * 1.25f, BaseRenderer.argb(0.1f * f19, 200, 170, 255));
            baseRenderer.glow(f17, f18 - f6 * 0.1f, f6 * 0.55f, BaseRenderer.argb(0.12f * f19, 255, 244, 255));
            float f20 = (f4 * 5.5f + speed2.seed * 3.0f) % 8.0f;
            int n2 = (int)f20;
            int n3 = (n2 + 1) % 8;
            float f21 = f20 - (float)n2;
            int n4 = Easing.mix(BaseRenderer.argb(1.0f, 236, 230, 255), BaseRenderer.argb(1.0f, 255, 238, 220), speed2.warm);
            baseRenderer.texture(HalloweenFx.ghost(n, n2), f17 - f15 / 2.0f, f18 - f16 / 2.0f, f15, f16, n4 & 0xFFFFFF | Math.round(255.0f * f19 * (1.0f - f21)) << 24);
            baseRenderer.texture(HalloweenFx.ghost(n, n3), f17 - f15 / 2.0f, f18 - f16 / 2.0f, f15, f16, n4 & 0xFFFFFF | Math.round(255.0f * f19 * f21) << 24);
        }
    }

    private float behind(float f, float f2, float f3) {
        if (this.window == null) {
            return 1.0f;
        }
        float[] fArray = this.window;
        float f4 = Math.max(fArray[0] - f, f - (fArray[0] + fArray[2]));
        float f5 = Math.max(fArray[1] - f2, f2 - (fArray[1] + fArray[3]));
        float f6 = Math.max(f4, f5);
        float f7 = Easing.clamp((f6 + f3 * 0.6f) / (f3 * 1.2f), 0.0f, 1.0f);
        f7 = f7 * f7 * (3.0f - 2.0f * f7);
        return 0.28f + 0.72f * f7;
    }

    private void respawn(Speed2 speed2) {
        speed2.x = 0.06f + this.rnd.nextFloat() * 0.88f;
        speed2.y = 0.18f + this.rnd.nextFloat() * 0.66f;
        speed2.size = 0.045f + this.rnd.nextFloat() * 0.045f;
        speed2.speed = 0.6f + this.rnd.nextFloat() * 0.7f;
        speed2.drift = (float)(this.rnd.nextBoolean() ? 1 : -1) * (0.004f + this.rnd.nextFloat() * 0.01f);
        speed2.seed = this.rnd.nextFloat() * 100.0f;
        speed2.life = 13.0f + this.rnd.nextFloat() * 10.0f;
        speed2.alpha = 0.18f + this.rnd.nextFloat() * 0.17f;
        speed2.warm = this.rnd.nextFloat() * 0.5f;
        speed2.age = 0.0f;
    }

    void panelWeb(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean bl) {
        if (f7 <= 0.003f) {
            return;
        }
        float f8 = 70.0f * f5;
        baseRenderer.pushClip(f, f2, f3, f4);
        baseRenderer.texture(HalloweenFx.web(Math.round(f8), true), f + f3 - f8 - 1.0f, f2 + 1.0f, f8, f8, BaseRenderer.white(0.075f * f7));
        baseRenderer.popClip();
        if (!bl) return;
        float f9 = (26.0f + 9.0f * (float)Math.sin(f6 * 0.7f)) * f5;
        float f10 = f + f3 - 30.0f * f5;
        float f11 = f2 + 8.0f * f5;
        baseRenderer.rect(f10, f11, Math.max(1.0f, f5 * 0.8f), f9, BaseRenderer.white(0.1f * f7));
        float f12 = 13.0f * f5;
        baseRenderer.texture(HalloweenFx.spider(Math.round(f12)), f10 - f12 / 2.0f + 0.5f, f11 + f9 - f12 * 0.32f, f12, f12, BaseRenderer.argb(0.55f * f7, 18, 10, 24));
    }

    static void lantern(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5) {
        if (f5 <= 0.003f) {
            return;
        }
        float f6 = 0.7f + 0.3f * (float)Math.sin(f4 * 8.0f) * (float)Math.sin(f4 * 3.1f + 1.0f);
        baseRenderer.glow(f + f3 / 2.0f, f2 + f3 * 0.62f, f3 * 1.1f, BaseRenderer.argb(0.18f * f5 * f6, 255, 150, 50));
        baseRenderer.texture(HalloweenFx.pumpkin(Math.round(f3)), f, f2, f3, f3, BaseRenderer.white(f5));
    }
}
