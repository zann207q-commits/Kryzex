package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.GuiWidgets;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.Setting;

final class Listening
extends LinesWidth {
    private final KeybindSetting bind;
    private float listening;

    Listening(Module module, KeybindSetting keybindSetting) {
        super(module, (Setting)((Object)keybindSetting));
        this.bind = keybindSetting;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return 92.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        int n;
        boolean bl = listeningModule.listening == this.bind;
        this.listening = Tween.approach(this.listening, bl ? 1.0f : 0.0f, 14.0f, listeningModule.dt);
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        int n2 = n = this.bind.isModuleKey() ? this.module.getKeybind() : this.bind.getValue();
        String string = bl ? "..." : (n == -1 || n == 0 ? "None" : String.valueOf(listeningModule.host.keyName(n)));
        GuiWidgets.keybind(listeningModule.painter, f + f3 - 10.0f, f5, string, this.hover, this.listening, listeningModule.time);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (listeningModule.listening == this.bind) {
            listeningModule.listening = null;
            listeningModule.listeningModule = null;
            return true;
        } else {
            listeningModule.listening = this.bind;
            listeningModule.listeningModule = this.module;
            listeningModule.host.sound("OPEN");
        }
        return true;
    }
}
