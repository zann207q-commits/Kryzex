package kryzex.gui;

import java.nio.file.Path;
import java.util.List;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.ListSetting;

public interface HudActions {
    public String playerName();

    public String serverLine();

    public boolean inWorld();

    public String keyName(int var1);

    public void openStorage(ListSetting var1);

    public void openHudEditor();

    public void closeNow();

    public List<?> items();

    public String itemName(Object var1);

    public Object itemOf(ItemSetting var1);

    public void setItem(ItemSetting var1, Object var2);

    public Path stateFile();

    default public float beat() {
        return 0.0f;
    }

    default public float shakeStrength() {
        return 0.0f;
    }
}
