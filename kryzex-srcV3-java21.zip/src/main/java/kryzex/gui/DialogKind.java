package kryzex.gui;

enum DialogKind {
    NONE,
    CREATE,
    RENAME,
    DELETE,
    RESET;

}
