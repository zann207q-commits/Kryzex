package kryzex.gui;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.regex.Pattern;

public final class NameCache {
    private static final Pattern VALID = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private final Supplier<String> read;
    private final Consumer<String> write;
    private String cached;
    private List<String> names = List.of();
    private Set<String> lookup = Set.of();

    public NameCache(Supplier<String> supplier, Consumer<String> consumer) {
        this.read = supplier;
        this.write = consumer;
    }

    public static boolean valid(String string) {
        if (string == null) return false;
        if (!VALID.matcher(string.trim()).matches()) return false;
        return true;
    }

    private void refresh() {
        String string = this.read.get();
        if (string == null) {
            string = "";
        }
        if (string.equals(this.cached)) {
            return;
        }
        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<String, String>();
        for (String string2 : string.split("[,;\\s]+")) {
            if (!NameCache.valid(string2)) continue;
            linkedHashMap.putIfAbsent(string2.toLowerCase(Locale.ROOT), string2);
        }
        this.names = List.copyOf(linkedHashMap.values());
        this.lookup = Set.copyOf(linkedHashMap.keySet());
        this.cached = string;
    }

    public List<String> names() {
        this.refresh();
        return this.names;
    }

    public boolean contains(String string) {
        this.refresh();
        if (string == null) return false;
        if (!this.lookup.contains(string.toLowerCase(Locale.ROOT))) return false;
        return true;
    }

    public String add(String string) {
        String string2 = string.trim();
        if (!NameCache.valid(string2)) {
            return "Use 1\u201316 letters, numbers or underscores.";
        }
        if (this.contains(string2)) {
            return string2 + " is already a friend.";
        }
        ArrayList<String> arrayList = new ArrayList<String>(this.names());
        arrayList.add(string2);
        this.write.accept(String.join((CharSequence)", ", arrayList));
        this.cached = null;
        this.refresh();
        return "";
    }

    public void remove(String string) {
        List<String> list = this.names().stream().filter(arg_0 -> NameCache.lmbd$remove$0(string, arg_0)).toList();
        this.write.accept(String.join((CharSequence)", ", list));
        this.cached = null;
        this.refresh();
    }

    private static boolean lmbd$remove$0(String string, String string2) {
        if (string2.equalsIgnoreCase(string)) return false;
        return true;
    }
}
