package kryzex.gui;

public enum HudElement {
    WATERMARK("Watermark"),
    INFO("Info"),
    PLAYER("Player"),
    RADAR("Radar"),
    COORDS("Coordinates"),
    MODULES("Modules");

    final String label;

    private HudElement(String string2) {
        this.label = string2;
    }
}
