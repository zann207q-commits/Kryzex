package kryzex.gui;

public interface IntBinding {
    public int get();

    public void set(int var1);

    public Object key();
}
