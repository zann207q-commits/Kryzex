package kryzex.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.util.OptionalInt;
import kryzex.gui.DropdownBlur;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_310;

public final class Insampler {
    private static final int LEVELS = 3;
    private static final int USAGE = 12;
    private final GpuTexture[] down = new GpuTexture[3];
    private final GpuTextureView[] downViews = new GpuTextureView[3];
    private final GpuTexture[] up = new GpuTexture[2];
    private final GpuTextureView[] upViews = new GpuTextureView[2];
    private int width;
    private int height;

    public GpuTextureView capture() {
        int n;
        class_276 class_2762 = class_310.method_1551().method_1522();
        GpuTextureView gpuTextureView = class_2762.method_71639();
        if (!DropdownBlur.ready(DropdownBlur.BLUR_DOWN) || !DropdownBlur.ready(DropdownBlur.BLUR_UP)) {
            return gpuTextureView;
        }
        this.ensureSize(class_2762.field_1482, class_2762.field_1481);
        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        class_12137 class_121372 = this.sampler();
        for (n = 0; n < 3; ++n) {
            Insampler.pass(commandEncoder, DropdownBlur.BLUR_DOWN, gpuTextureView, this.downViews[n], class_121372);
            gpuTextureView = this.downViews[n];
        }
        for (n = 1; n >= 0; --n) {
            Insampler.pass(commandEncoder, DropdownBlur.BLUR_UP, gpuTextureView, this.upViews[n], class_121372);
            gpuTextureView = this.upViews[n];
        }
        return gpuTextureView;
    }

    public class_12137 sampler() {
        return RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
    }

    private static void pass(CommandEncoder commandEncoder, RenderPipeline renderPipeline, GpuTextureView gpuTextureView, GpuTextureView gpuTextureView2, class_12137 class_121372) {
        try (RenderPass renderPass = commandEncoder.createRenderPass(Insampler::lmbd$pass$0, gpuTextureView2, OptionalInt.empty());){
            renderPass.setPipeline(renderPipeline);
            renderPass.bindTexture("InSampler", gpuTextureView, class_121372);
            renderPass.draw(0, 3);
            return;
        }
    }

    private void ensureSize(int n, int n2) {
        if (n == this.width && n2 == this.height && this.down[0] != null) return;
        this.close();
        this.width = n;
        this.height = n2;
        GpuDevice gpuDevice = RenderSystem.getDevice();
        for (int i = 0; i < 3; ++i) {
            int n3 = Math.max(1, n >> i + 1);
            int n4 = Math.max(1, n2 >> i + 1);
            this.down[i] = gpuDevice.createTexture("Kryzex dropdown blur down " + i, 12, TextureFormat.RGBA8, n3, n4, 1, 1);
            this.downViews[i] = gpuDevice.createTextureView(this.down[i]);
            if (i >= 2) continue;
            this.up[i] = gpuDevice.createTexture("Kryzex dropdown blur up " + i, 12, TextureFormat.RGBA8, n3, n4, 1, 1);
            this.upViews[i] = gpuDevice.createTextureView(this.up[i]);
        }
    }

    public void close() {
        int n;
        for (n = 0; n < 3; ++n) {
            if (this.downViews[n] != null) {
                this.downViews[n].close();
            }
            if (this.down[n] != null) {
                this.down[n].close();
            }
            this.downViews[n] = null;
            this.down[n] = null;
        }
        for (n = 0; n < 2; ++n) {
            if (this.upViews[n] != null) {
                this.upViews[n].close();
            }
            if (this.up[n] != null) {
                this.up[n].close();
            }
            this.upViews[n] = null;
            this.up[n] = null;
        }
        this.height = 0;
        this.width = 0;
    }

    private static String lmbd$pass$0() {
        return "Kryzex dropdown glass blur";
    }
}
