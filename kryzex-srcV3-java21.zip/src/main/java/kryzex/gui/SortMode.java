package kryzex.gui;

public enum SortMode {
    Longest,
    Shortest,
    Category,
    Alphabetical;

}
