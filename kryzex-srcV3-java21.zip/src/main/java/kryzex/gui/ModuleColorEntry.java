package kryzex.gui;

import java.awt.Color;

class ModuleColorEntry {
    public final boolean enabled;
    public final Color color;

    public ModuleColorEntry(boolean enabled, Color color) {
        this.enabled = enabled;
        this.color = color;
    }

    public boolean enabled() {
        return this.enabled;
    }

    public Color color() {
        return this.color;
    }
}
