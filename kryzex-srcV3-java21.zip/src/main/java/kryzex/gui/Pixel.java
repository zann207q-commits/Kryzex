package kryzex.gui;

public enum Pixel {
    Minecraft,
    Pixel,
    Kryzex;

}
