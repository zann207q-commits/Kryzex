package kryzex.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.lang.invoke.MethodHandle;
import kryzex.gui.DropdownBlur;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fc;

final class TextureSetup
implements class_11244 {
    private final Matrix3x2fc pose;
    private final class_11231 textureSetup;
    private final float[] floats;
    private final int[] ints;
    private final int count;
    @Nullable
    private final class_8030 bounds;

    public TextureSetup(Matrix3x2fc matrix3x2fc, class_11231 class_112312, float[] fArray, int[] nArray, int n, @Nullable class_8030 class_80302) {
        this.pose = matrix3x2fc;
        this.textureSetup = class_112312;
        this.floats = fArray;
        this.ints = nArray;
        this.count = n;
        this.bounds = class_80302;
    }

    public void method_70917(class_4588 class_45882) {
        for (int i = 0; i < this.count; ++i) {
            int n = i * 11;
            int n2 = i * 6;
            float f = this.floats[n];
            float f2 = this.floats[n + 1];
            float f3 = this.floats[n + 2];
            float f4 = this.floats[n + 3];
            float f5 = this.floats[n + 4];
            float f6 = this.floats[n + 5];
            float f7 = this.floats[n + 6];
            float f8 = this.floats[n + 7];
            float f9 = this.floats[n + 8];
            float f10 = this.floats[n + 9];
            float f11 = this.floats[n + 10];
            int n3 = this.ints[n2 + 4];
            int n4 = this.ints[n2 + 5];
            int n5 = n3 & 0xFFFF;
            int n6 = n3 >>> 16;
            int n7 = n4 & 0xFFFF;
            int n8 = n4 >>> 16;
            class_45882.method_70815(this.pose, f, f2).method_39415(this.ints[n2]).method_22913(f5, f6).method_60796(n7, n8).method_22921(n5, n6).method_22914(f9, f10, f11);
            class_45882.method_70815(this.pose, f, f4).method_39415(this.ints[n2 + 1]).method_22913(f5, f8).method_60796(n7, n8).method_22921(n5, n6).method_22914(f9, f10, f11);
            class_45882.method_70815(this.pose, f3, f4).method_39415(this.ints[n2 + 2]).method_22913(f7, f8).method_60796(n7, n8).method_22921(n5, n6).method_22914(f9, f10, f11);
            class_45882.method_70815(this.pose, f3, f2).method_39415(this.ints[n2 + 3]).method_22913(f7, f6).method_60796(n7, n8).method_22921(n5, n6).method_22914(f9, f10, f11);
        }
    }

    public RenderPipeline comp_4055() {
        return DropdownBlur.UI;
    }

    @Nullable
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public final String toString() {
        return "TextureSetup[" + "pose=" + this.pose + ", " + "textureSetup=" + this.textureSetup + ", " + "floats=" + this.floats + ", " + "ints=" + this.ints + ", " + "count=" + this.count + ", " + "bounds=" + this.bounds + "]";
    }

    @Override
    public final int hashCode() {
        return java.util.Objects.hash(this.pose, this.textureSetup, this.floats, this.ints, this.count, this.bounds);
    }

    @Override
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextureSetup)) {
            return false;
        }
        TextureSetup texturesetup = (TextureSetup)object;
        return java.util.Objects.equals(this.pose, texturesetup.pose) &&
                java.util.Objects.equals(this.textureSetup, texturesetup.textureSetup) &&
                java.util.Objects.equals(this.floats, texturesetup.floats) &&
                java.util.Objects.equals(this.ints, texturesetup.ints) &&
                java.util.Objects.equals(this.count, texturesetup.count) &&
                java.util.Objects.equals(this.bounds, texturesetup.bounds);
    }

    public Matrix3x2fc pose() {
        return this.pose;
    }

    public class_11231 comp_4056() {
        return this.textureSetup;
    }

    public float[] floats() {
        return this.floats;
    }

    public int[] ints() {
        return this.ints;
    }

    public int count() {
        return this.count;
    }

    @Nullable
    public class_8030 comp_4274() {
        return this.bounds;
    }
}
