package kryzex.gui;

import java.io.IOException;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import kryzex.gui.Handle;

final class PurpleLogo {
    private static final Map<String, BufferedImage> SOURCES = new HashMap<String, BufferedImage>();
    private static final Map<String, Handle> CACHE = new HashMap<String, Handle>();

    private PurpleLogo() {
    }

    static Handle get(String string, int n) {
        int n2 = Math.max(4, Math.min(512, n));
        return CACHE.computeIfAbsent(string + "@" + n2, arg_0 -> PurpleLogo.lmbd$get$0(string, n2, arg_0));
    }

    private static BufferedImage source(String string) {
        return SOURCES.computeIfAbsent(string, PurpleLogo::lmbd$source$0);
    }

    private static BufferedImage resize(BufferedImage bufferedImage, int n, int n2) {
        BufferedImage bufferedImage2 = new BufferedImage(n, n2, 2);
        Graphics2D graphics2D = bufferedImage2.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.drawImage(bufferedImage, 0, 0, n, n2, null);
        graphics2D.dispose();
        return bufferedImage2;
    }

    private static BufferedImage lmbd$source$0(String string) {
        BufferedImage bufferedImage;
        String string2;
        switch (string) {
            case "purple_logo": {
                string2 = "/assets/r87f4560b4c09f4/textures/r4432cc134f2554/kryzex_purple.png";
                break;
            }
            case "logo": {
                string2 = "/assets/r87f4560b4c09f4/textures/r4432cc134f2554/r8f4f21bc51d271.png";
                break;
            }
            default: {
                return null;
            }
        }
        String string3 = string2;
        if (string3 == null) {
            return null;
        }
        Object object = PurpleLogo.class.getResourceAsStream(string3);
        try {
            bufferedImage = object == null ? null : ImageIO.read((InputStream)object);
            if (object == null) return bufferedImage;
        }
        catch (Throwable throwable) {
            try {
                if (object == null) throw throwable;
                try {
                    try {
                        ((InputStream)object).close();
                    }
                    catch (IOException iOException) {

                    }
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
            catch (Throwable throwable3) {
                return null;
            }
        }
        try {
            ((InputStream)object).close();
        }
        catch (IOException iOException) {

        }
        return bufferedImage;
    }

    private static Handle lmbd$get$0(String string, int n, String string2) {
        BufferedImage bufferedImage = PurpleLogo.source(string);
        if (bufferedImage == null) {
            return null;
        }
        BufferedImage bufferedImage2 = bufferedImage;
        while (bufferedImage2.getWidth() / 2 >= n) {
            bufferedImage2 = PurpleLogo.resize(bufferedImage2, bufferedImage2.getWidth() / 2, bufferedImage2.getHeight() / 2);
        }
        BufferedImage bufferedImage3 = PurpleLogo.resize(bufferedImage2, n, n);
        int[] nArray = new int[n * n];
        bufferedImage3.getRGB(0, 0, n, n, nArray, 0, n);
        for (int i = 0; i < nArray.length; ++i) {
            nArray[i] = nArray[i] & 0xFF000000 | 0xFFFFFF;
        }
        return new Handle("img_" + string2, n, n, nArray);
    }
}
