package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.GuiWidgets;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.Setting;

final class Bool
extends LinesWidth {
    private final BoolSetting bool;
    private float on;

    Bool(Module module, BoolSetting boolSetting) {
        super(module, (Setting)((Object)boolSetting));
        this.bool = boolSetting;
        this.on = boolSetting.getValue() ? 1.0f : 0.0f;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return 48.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        this.on = Tween.approach(this.on, this.bool.getValue() ? 1.0f : 0.0f, 14.0f, listeningModule.dt);
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        GuiWidgets.toggle(listeningModule.painter, f + f3 - 10.0f, f5, this.on, this.hover);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0) {
            return false;
        }
        this.bool.toggle();
        listeningModule.host.sound(this.bool.getValue() ? "ON" : "OFF");
        return true;
    }
}
