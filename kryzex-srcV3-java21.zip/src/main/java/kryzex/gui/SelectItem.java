package kryzex.gui;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import kryzex.gui.PaletteEntry;

public class SelectItem {
    public final String title;
    public final List<PaletteEntry> rows;
    public final boolean multiple;
    public final Predicate<PaletteEntry> selected;
    public final Consumer<PaletteEntry> choose;
    public final Runnable clear;

    public SelectItem(String title, List<PaletteEntry> rows, boolean multiple, Predicate<PaletteEntry> selected, Consumer<PaletteEntry> choose, Runnable clear) {
        this.title = title;
        this.rows = rows;
        this.multiple = multiple;
        this.selected = selected;
        this.choose = choose;
        this.clear = clear;
    }

    public String title() {
        return this.title;
    }

    public List<PaletteEntry> rows() {
        return this.rows;
    }

    public boolean multiple() {
        return this.multiple;
    }

    public Predicate<PaletteEntry> selected() {
        return this.selected;
    }

    public Consumer<PaletteEntry> choose() {
        return this.choose;
    }

    public Runnable clear() {
        return this.clear;
    }
    public int count() {
        int n = 0;
        for (PaletteEntry paletteEntry : this.rows) {
            if (!this.selected.test(paletteEntry)) continue;
            ++n;
        }
        return n;
    }

    public String summary() {
        if (this.multiple) {
            return this.count() + " selected";
        }
        for (PaletteEntry paletteEntry : this.rows) {
            if (!this.selected.test(paletteEntry)) continue;
            return paletteEntry.name();
        }
        return "Select item";
    }

    public Object icon() {
        for (PaletteEntry paletteEntry : this.rows) {
            if (!this.selected.test(paletteEntry)) continue;
            return paletteEntry.item();
        }
        return null;
    }
}
