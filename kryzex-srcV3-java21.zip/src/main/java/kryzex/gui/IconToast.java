package kryzex.gui;

import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_9334;

public final class IconToast
implements class_368 {
    private static final class_2960 TEXTURE = class_2960.method_60656((String)"toast/advancement");
    private static final class_2960 GLOW = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"textures/r4432cc134f2554/chest-glow.png");
    private static final Object TYPE_KEY = new Object();
    private static final class_3414 SOUND = class_3414.method_47908((class_2960)class_2960.method_60655((String)"r87f4560b4c09f4", (String)"chunk_flag"));
    private static final class_1799 ICON = IconToast.createIcon();
    private class_2561 coordinates;
    private class_368.class_369 visibility = class_368.class_369.field_2210;
    private boolean playSound;
    private boolean resetPending = true;
    private long resetAt;

    public IconToast(int n, int n2, boolean bl) {
        this.refresh(n, n2, bl);
    }

    private static class_1799 createIcon() {
        class_1799 class_17992 = new class_1799((class_1935)class_1802.field_8106);
        class_17992.method_57379(class_9334.field_49641, true);
        return class_17992;
    }

    public static void show(int n, int n2, boolean bl) {
        class_374 class_3742 = class_310.method_1551().method_1566();
        IconToast iconToast = (IconToast)class_3742.method_1997(IconToast.class, TYPE_KEY);
        if (iconToast == null) {
            class_3742.method_1999((class_368)new IconToast(n, n2, bl));
            return;
        } else {
            iconToast.refresh(n, n2, bl);
        }
    }

    private void refresh(int n, int n2, boolean bl) {
        this.coordinates = class_2561.method_43470((String)("X: " + n + " Z: " + n2));
        this.playSound = bl;
        this.resetPending = true;
        this.visibility = class_368.class_369.field_2210;
    }

    public Object method_1987() {
        return TYPE_KEY;
    }

    public class_368.class_369 method_61988() {
        return this.visibility;
    }

    public class_3414 method_66530() {
        if (!this.playSound) return null;
        class_3414 class_34142 = SOUND;
        return class_34142;
    }

    public void method_61989(class_374 class_3742, long l) {
        if (this.resetPending) {
            this.resetAt = l;
            this.resetPending = false;
        }
        this.visibility = (double)(l - this.resetAt) >= 5000.0 * class_3742.method_48221() ? class_368.class_369.field_2209 : class_368.class_369.field_2210;
    }

    public void method_1986(class_332 class_3322, class_327 class_3272, long l) {
        class_3322.method_52706(class_10799.field_56883, TEXTURE, 0, 0, this.method_29049(), this.method_29050());
        float f = 0.76f + 0.08f * (float)Math.sin((double)l / 850.0);
        int n = Math.round(f * 255.0f) << 24 | 0xFFFFFF;
        class_3322.method_25293(class_10799.field_56883, GLOW, 0, 0, 0.0f, 0.0f, 32, 32, 64, 64, 64, 64, n);
        class_3322.method_51439(class_3272, (class_2561)class_2561.method_43470((String)"Chunk Finder Better"), 30, 7, -43521, false);
        class_3322.method_51439(class_3272, this.coordinates, 30, 18, -1, false);
        class_3322.method_51445(ICON, 8, 8);
    }
}
