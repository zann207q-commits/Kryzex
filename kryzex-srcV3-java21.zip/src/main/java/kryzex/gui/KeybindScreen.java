package kryzex.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kryzex.client.KryzexClient;
import kryzex.gui.ColorPickerScreen;
import kryzex.gui.ModuleColorEntry;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.ToggleEntry;
import kryzex.util.FontRenderer;
import kryzex.util.InverseProjectionScratch;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class KeybindScreen
extends class_437 {
    private static final int WIDTH = 580;
    private static final int HEIGHT = 460;
    private static final int COLUMNS = 11;
    private static final int CELL = 42;
    private final ListSetting setting;
    private final Map<String, ModuleColorEntry> original = new LinkedHashMap<String, ModuleColorEntry>();
    private String search = "";
    private boolean selectedOnly;
    private int scrollRow;

    public KeybindScreen(ListSetting listSetting) {
        super((class_2561)class_2561.method_43473());
        this.setting = listSetting;
        for (ToggleEntry toggleEntry : listSetting.entries()) {
            this.original.put(toggleEntry.id(), new ModuleColorEntry(toggleEntry.enabled(), toggleEntry.color()));
        }
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        int n3;
        InverseProjectionScratch.setContext(class_3322);
        InverseProjectionScratch.unscaledProjection();
        int n4 = KeybindScreen.physical(n);
        int n5 = KeybindScreen.physical(n2);
        int n6 = class_310.method_1551().method_22683().method_4480();
        int n7 = class_310.method_1551().method_22683().method_4507();
        class_3322.method_25294(0, 0, n6, n7, new Color(0, 0, 0, 70).getRGB());
        int n8 = (n6 - 580) / 2;
        int n9 = (n7 - 460) / 2;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(30, 30, 35, 246), n8, n9, n8 + 580, n9 + 460, 8.0, 8.0, 8.0, 8.0, 20.0);
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(40, 40, 45), n8, n9, n8 + 580, n9 + 34, 8.0, 8.0, 0.0, 0.0, 20.0);
        boolean bl = this.setting.isPickerOnly();
        FontRenderer.drawCenteredString(bl ? this.setting.getName().toString().toUpperCase(Locale.ROOT) + " (" + this.setting.selectedCount() + " SELECTED)" : "BLOCK COLORS: " + this.setting.getName().toString().toUpperCase(Locale.ROOT) + " (" + this.setting.selectedCount() + " BLOCKS)", class_3322, n8 + 290, n9 + 9, Color.WHITE.getRGB());
        int n10 = n9 + 42;
        this.button(class_3322, n8 + 20, n10, 150, 30, bl ? "ALL ITEMS" : "ALL BLOCKS", !this.selectedOnly, new Color(120, 190, 255));
        this.button(class_3322, n8 + 180, n10, 150, 30, "SELECTED (" + this.setting.selectedCount() + ")", this.selectedOnly, new Color(120, 190, 255));
        int n11 = n9 + 82;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(18, 18, 23), n8 + 20, n11, n8 + 580 - 20, n11 + 31, 5.0, 5.0, 5.0, 5.0, 20.0);
        String string = System.currentTimeMillis() % 1000L > 500L ? "|" : "";
        FontRenderer.drawString((CharSequence)(this.search.isEmpty() ? "SEARCH..." : this.search + string), class_3322, n8 + 30, n11 + 8, new Color(145, 145, 155).getRGB());
        int n12 = n8 + 20;
        int n13 = n9 + 124;
        int n14 = 270;
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), new Color(20, 20, 25), n12, n13, n8 + 580 - 20, n13 + n14, 5.0, 5.0, 5.0, 5.0, 20.0);
        List<ToggleEntry> list = this.visibleEntries();
        int n15 = Math.min(this.scrollRow * 11, Math.max(0, list.size() - 1));
        int n16 = Math.min(list.size(), n15 + 66);
        for (n3 = n15; n3 < n16; ++n3) {
            ToggleEntry toggleEntry = list.get(n3);
            int n17 = n3 - n15;
            int n18 = n12 + 6 + n17 % 11 * 42;
            int n19 = n13 + 6 + n17 / 11 * 42;
            Color color = toggleEntry.enabled() ? new Color(toggleEntry.color().getRed(), toggleEntry.color().getGreen(), toggleEntry.color().getBlue(), 85) : new Color(35, 35, 40);
            InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), color, n18, n19, n18 + 36, n19 + 36, 4.0, 4.0, 4.0, 4.0, 20.0);
            if (toggleEntry.enabled()) {
                InverseProjectionScratch.renderRoundedOutline(class_3322, toggleEntry.color(), n18, n19, n18 + 36, n19 + 36, 4.0, 4.0, 4.0, 4.0, 1.5, 20.0);
            }
            InverseProjectionScratch.drawItem(class_3322, new class_1799((class_1935)toggleEntry.item()), n18 + 2, n19 + 2, 32.0f, 0);
            class_3322.method_25294(n18 + 27, n19 + 3, n18 + 33, n19 + 9, toggleEntry.color().getRGB());
            if (!KeybindScreen.inside(n4, n5, n18, n19, 36, 36)) continue;
            InverseProjectionScratch.renderRoundedOutline(class_3322, new Color(255, 255, 255, 210), n18, n19, n18 + 36, n19 + 36, 4.0, 4.0, 4.0, 4.0, 1.0, 20.0);
            FontRenderer.drawCenteredString(toggleEntry.displayName().toUpperCase(Locale.ROOT), class_3322, n8 + 290, n9 + 460 - 82, new Color(220, 220, 225).getRGB());
        }
        n3 = n9 + 460 - 42;
        this.button(class_3322, n8 + 580 - 100, n3, 80, 30, "SAVE", true, new Color(90, 220, 135));
        this.button(class_3322, n8 + 580 - 210, n3, 100, 30, "CANCEL", false, new Color(255, 105, 105));
        this.button(class_3322, n8 + 580 - 320, n3, 100, 30, "CLEAR ALL", false, Color.WHITE);
        InverseProjectionScratch.scaledProjection();
    }

    private void button(class_332 class_3322, int n, int n2, int n3, int n4, String string, boolean bl, Color color) {
        InverseProjectionScratch.renderRoundedQuad(class_3322.method_51448(), bl ? new Color(75, 125, 185) : new Color(38, 38, 44), n, n2, n + n3, n2 + n4, 5.0, 5.0, 5.0, 5.0, 20.0);
        FontRenderer.drawCenteredString(string, class_3322, n + n3 / 2, n2 + 8, color.getRGB());
    }

    private List<ToggleEntry> visibleEntries() {
        ArrayList<ToggleEntry> arrayList = new ArrayList<ToggleEntry>();
        String string = this.search.toLowerCase(Locale.ROOT);
        for (ToggleEntry toggleEntry : this.setting.entries()) {
            if (this.selectedOnly && !toggleEntry.enabled() || !string.isEmpty() && !toggleEntry.displayName().toLowerCase(Locale.ROOT).contains(string)) continue;
            arrayList.add(toggleEntry);
        }
        return arrayList;
    }

    public boolean mouseClicked(double d, double d2, int n) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8 = KeybindScreen.physical(d);
        if (KeybindScreen.inside(n8, n7 = KeybindScreen.physical(d2), (n6 = ((n5 = class_310.method_1551().method_22683().method_4480()) - 580) / 2) + 20, (n4 = ((n3 = class_310.method_1551().method_22683().method_4507()) - 460) / 2) + 42, 150, 30)) {
            this.selectedOnly = false;
            return true;
        }
        if (KeybindScreen.inside(n8, n7, n6 + 180, n4 + 42, 150, 30)) {
            this.selectedOnly = true;
            return true;
        }
        int n9 = n6 + 20;
        int n10 = n4 + 124;
        List<ToggleEntry> list = this.visibleEntries();
        int n11 = Math.min(this.scrollRow * 11, Math.max(0, list.size() - 1));
        int n12 = Math.min(list.size(), n11 + 66);
        for (n2 = n11; n2 < n12; ++n2) {
            int n13 = n2 - n11;
            int n14 = n9 + 6 + n13 % 11 * 42;
            int n15 = n10 + 6 + n13 / 11 * 42;
            if (!KeybindScreen.inside(n8, n7, n14, n15, 36, 36)) continue;
            ToggleEntry toggleEntry = list.get(n2);
            if (n == 0 || n == 1 && this.setting.isPickerOnly()) {
                toggleEntry.toggle();
                return true;
            } else {
                if (n != 1) return true;
                class_310.method_1551().method_1507((class_437)new ColorPickerScreen(this, toggleEntry));
            }
            return true;
        }
        n2 = n4 + 460 - 42;
        if (KeybindScreen.inside(n8, n7, n6 + 580 - 100, n2, 80, 30)) {
            KryzexClient.INSTANCE.getSettingsManager().saveNow();
            this.returnToGui();
            return true;
        }
        if (KeybindScreen.inside(n8, n7, n6 + 580 - 210, n2, 100, 30)) {
            this.restore();
            this.returnToGui();
            return true;
        }
        if (!KeybindScreen.inside(n8, n7, n6 + 580 - 320, n2, 100, 30)) return false;
        this.setting.clear();
        return true;
    }

    public boolean method_25401(double d, double d2, double d3, double d4) {
        List<ToggleEntry> list = this.visibleEntries();
        int n = Math.max(0, (list.size() + 11 - 1) / 11 - 6);
        this.scrollRow = Math.max(0, Math.min(n, this.scrollRow - (int)Math.signum(d4)));
        return true;
    }

    public boolean keyPressed(int n, int n2, int n3) {
        if (n == 256) {
            this.restore();
            this.returnToGui();
            return true;
        }
        if (n != 259 || this.search.isEmpty()) return false;
        this.search = this.search.substring(0, this.search.length() - 1);
        this.scrollRow = 0;
        return true;
    }

    public boolean charTyped(char c, int n) {
        if (Character.isISOControl(c) || this.search.length() >= 28) return true;
        this.search = this.search + c;
        this.scrollRow = 0;
        return true;
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        return this.mouseClicked(class_119092.comp_4798(), class_119092.comp_4799(), class_119092.method_74245());
    }

    public boolean method_25404(class_11908 class_119082) {
        return this.keyPressed(class_119082.comp_4795(), class_119082.comp_4796(), class_119082.comp_4797());
    }

    public boolean method_25400(class_11905 class_119052) {
        if (!class_119052.method_74227()) return false;
        if (!this.charTyped((char)class_119052.comp_4793(), class_119052.comp_4794())) return false;
        return true;
    }

    public void method_25420(class_332 class_3322, int n, int n2, float f) {
    }

    public boolean method_25422() {
        return false;
    }

    public boolean method_25421() {
        return false;
    }

    private void restore() {
        for (ToggleEntry toggleEntry : this.setting.entries()) {
            ModuleColorEntry moduleColorEntry = this.original.get(toggleEntry.id());
            if (moduleColorEntry == null) continue;
            toggleEntry.setEnabled(moduleColorEntry.enabled());
            toggleEntry.setColor(moduleColorEntry.color());
        }
    }

    private void returnToGui() {
        class_310.method_1551().method_1507((class_437)KryzexClient.INSTANCE.GUI);
    }

    private static int physical(double d) {
        return (int)Math.round(d * (double)class_310.method_1551().method_22683().method_4495());
    }

    private static boolean inside(double d, double d2, int n, int n2, int n3, int n4) {
        if (!(d >= (double)n)) return false;
        if (!(d <= (double)(n + n3))) return false;
        if (!(d2 >= (double)n2)) return false;
        if (!(d2 <= (double)(n2 + n4))) return false;
        return true;
    }
}
