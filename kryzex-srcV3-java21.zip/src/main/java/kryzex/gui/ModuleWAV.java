package kryzex.gui;

import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import kryzex.gui.GuiSoundType;

final class ModuleWAV {
    private static float[] scrolling;
    private static int cursor;
    private static int loopStart;
    private static float envelope;

    private ModuleWAV() {
    }

    static float[] load(String string, float f) {
        try (InputStream inputStream = ModuleWAV.class.getResourceAsStream("/assets/r87f4560b4c09f4/sounds/ui/" + string);){
            float[] fArray;
            if (inputStream == null) {
                throw new IllegalStateException("Missing UI sound " + string);
            }
            try (AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new BufferedInputStream(inputStream));){
                AudioFormat audioFormat = audioInputStream.getFormat();
                if (audioFormat.getChannels() != 2 || audioFormat.getSampleRate() != 44100.0f || audioFormat.getSampleSizeInBits() != 16 || audioFormat.isBigEndian()) {
                    throw new IllegalStateException("Unsupported UI PCM " + string);
                }
                byte[] byArray = audioInputStream.readNBytes(0x600000);
                float[] fArray2 = new float[byArray.length / 2];
                float f2 = 0.0f;
                for (int i = 0; i < fArray2.length; ++i) {
                    fArray2[i] = (float)((short)(byArray[i * 2] & 0xFF | byArray[i * 2 + 1] << 8)) / 32768.0f;
                    f2 = Math.max(f2, Math.abs(fArray2[i]));
                }
                float f3 = f2 > 0.0f ? Math.min(2.0f, f / f2) : 1.0f;
                int n = 0;
                while (n < fArray2.length) {
                    int n2 = n++;
                    fArray2[n2] = fArray2[n2] * f3;
                }
                fArray = fArray2;
                if (audioInputStream == null) return fArray;
            }
            return fArray;
        }
        catch (Exception exception) {
            System.err.println("Kryzex UI clip: " + exception.getMessage());
            return new float[2];
        }
    }

    static float[][] apply(float[][] fArray) {
        int n;
        fArray[GuiSoundType.ON.ordinal()] = ModuleWAV.load("module-on.wav", 0.27f);
        fArray[GuiSoundType.OFF.ordinal()] = ModuleWAV.load("module-off.wav", 0.23f);
        fArray[GuiSoundType.TAB.ordinal()] = ModuleWAV.load("tab-1.wav", 0.22f);
        fArray[GuiSoundType.TAB_2.ordinal()] = ModuleWAV.load("tab-2.wav", 0.22f);
        fArray[GuiSoundType.TAB_3.ordinal()] = ModuleWAV.load("tab-3.wav", 0.22f);
        scrolling = ModuleWAV.load("scroll-loop.wav", 0.075f);
        int n2 = scrolling.length / 2;
        loopStart = n = Math.min(441, n2 / 8);
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < 2; ++j) {
                float f = (float)i / (float)Math.max(1, n - 1);
                int n3 = (n2 - n + i) * 2 + j;
                ModuleWAV.scrolling[n3] = scrolling[n3] * (1.0f - f) + scrolling[i * 2 + j] * f;
            }
        }
        return fArray;
    }

    static boolean mixScroll(float[] fArray, int n, float f, boolean bl) {
        if (scrolling == null) return false;
        if (scrolling.length < 4) {
            return false;
        }
        int n2 = scrolling.length / 2;
        for (int i = 0; i < n; ++i) {
            if ((envelope += ((float)(bl ? (char)'\u0001' : '\u0000') - envelope) * (bl ? 0.0012f : 6.0E-4f)) < 1.0E-4f && !bl) {
                envelope = 0.0f;
                continue;
            }
            float f2 = envelope * f;
            int n3 = i * 2;
            fArray[n3] = fArray[n3] + scrolling[cursor * 2] * f2;
            int n4 = i * 2 + 1;
            fArray[n4] = fArray[n4] + scrolling[cursor * 2 + 1] * f2;
            if (++cursor < n2) continue;
            cursor = loopStart;
        }
        if (envelope > 1.0E-4f) return true;
        if (!bl) return false;
        return true;
    }
}
