package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.GuiWidgets;
import kryzex.gui.LastSource;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.NumberSetting;

final class ShownValue
extends LinesWidth {
    private final NumberSetting number;
    private float shownValue;

    ShownValue(Module module, NumberSetting numberSetting) {
        super(module, numberSetting);
        this.number = numberSetting;
        this.shownValue = this.fraction();
    }

    private float fraction() {
        double d = this.number.getMax() - this.number.getMin();
        if (d <= 0.0) {
            return 0.0f;
        }
        float f = (float)((this.number.getValue() - this.number.getMin()) / d);
        return f;
    }

    private void setFraction(float f) {
        double d = this.number.getMin() + (double)f * (this.number.getMax() - this.number.getMin());
        this.number.getValue(ShownValue.snap(d, this.number.getMin(), this.number.getMax(), this.number.getFormat()));
    }

    private String display() {
        return ShownValue.format(this.number.getValue(), this.number.getFormat());
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return Math.max(squareCorners.textWidth(this.display()), squareCorners.textWidth("00"));
    }

    @Override
    protected float baseHeight() {
        return 48.0f;
    }

    @Override
    protected boolean condenses() {
        return true;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        boolean bl;
        SquareCorners squareCorners = listeningModule.painter;
        float f5 = f + 8.0f;
        float f6 = f + f3 - 10.0f;
        float f7 = (float)(this.labelLines(squareCorners, f3).size() - 1) * 19.0f;
        float f8 = f2 + 38.5f + f7;
        boolean bl2 = bl = listeningModule.captured == this;
        if (bl) {
            if (listeningModule.mouseDown) {
                this.setFraction(GuiWidgets.fractionAt(f5, f6, listeningModule.mouseX));
            } else {
                listeningModule.captured = null;
            }
        }
        this.shownValue = bl ? this.fraction() : Tween.approach(this.shownValue, this.fraction(), 22.0f, listeningModule.dt);
        this.drawLabel(listeningModule, f, f2, f3, 14.5f);
        squareCorners.textRight(this.display(), f6, f2 + 14.5f, LastSource.VALUE);
        GuiWidgets.slider(squareCorners, f5, f6, f8, this.shownValue, this.hover, bl);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0) {
            return false;
        }
        this.setFraction(GuiWidgets.fractionAt(f + 8.0f, f + f3 - 10.0f, f5));
        listeningModule.captured = this;
        listeningModule.host.sound("SLIDE");
        return true;
    }
}
