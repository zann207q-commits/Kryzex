package kryzex.gui;

import kryzex.gui.GuiWidgets;
import kryzex.gui.LastSource;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.RangeSetting;

final class Dragging
extends LinesWidth {
    private final RangeSetting range;
    private int dragging;

    Dragging(Module module, RangeSetting rangeSetting) {
        super(module, rangeSetting);
        this.range = rangeSetting;
    }

    private float frac(double d) {
        double d2 = this.range.getMaxValue() - this.range.getMinValue();
        if (d2 <= 0.0) {
            return 0.0f;
        }
        float f = (float)((d - this.range.getMinValue()) / d2);
        return f;
    }

    private double value(float f) {
        return this.range.getMinValue() + (double)f * (this.range.getMaxValue() - this.range.getMinValue());
    }

    private String display() {
        return Dragging.format(this.range.getCurrentMin(), this.range.getStep()) + " - " + Dragging.format(this.range.getCurrentMax(), this.range.getStep());
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return squareCorners.textWidth(this.display());
    }

    @Override
    protected float baseHeight() {
        return 48.0f;
    }

    @Override
    protected boolean condenses() {
        return true;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        SquareCorners squareCorners = listeningModule.painter;
        float f5 = f + 8.0f;
        float f6 = f + f3 - 10.0f;
        float f7 = (float)(this.labelLines(squareCorners, f3).size() - 1) * 19.0f;
        if (listeningModule.captured == this) {
            if (listeningModule.mouseDown) {
                this.apply(GuiWidgets.fractionAt(f5, f6, listeningModule.mouseX));
            } else {
                listeningModule.captured = null;
                this.dragging = 0;
            }
        }
        this.drawLabel(listeningModule, f, f2, f3, 14.5f);
        squareCorners.textRight(this.display(), f6, f2 + 14.5f, LastSource.VALUE);
        GuiWidgets.range(squareCorners, f5, f6, f2 + 38.5f + f7, this.frac(this.range.getCurrentMin()), this.frac(this.range.getCurrentMax()), this.hover, listeningModule.captured == this ? this.dragging : 0);
    }

    private void apply(float f) {
        double d = this.value(f);
        if (this.dragging == 1) {
            this.range.setCurrentMin(Math.min(d, this.range.getCurrentMax()));
            return;
        } else {
            if (this.dragging != 2) return;
            this.range.setCurrentMax(Math.max(d, this.range.getCurrentMin()));
        }
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0) {
            return false;
        }
        float f7 = GuiWidgets.fractionAt(f + 8.0f, f + f3 - 10.0f, f5);
        float f8 = this.frac(this.range.getCurrentMin());
        float f9 = this.frac(this.range.getCurrentMax());
        int n2 = this.dragging = Math.abs(f7 - f8) < Math.abs(f7 - f9) || f7 < f8 ? 1 : 2;
        if (f8 == f9) {
            this.dragging = f7 < f8 ? 1 : 2;
        }
        listeningModule.captured = this;
        this.apply(f7);
        listeningModule.host.sound("SLIDE");
        return true;
    }
}
