package kryzex.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import kryzex.client.KryzexClient;
import kryzex.config.ConfigProfile;
import kryzex.config.ConfigProfileManager;
import kryzex.gui.Action;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Easing;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiSoundType;
import kryzex.gui.SpeakerOff;
import kryzex.gui.Theme;
import kryzex.gui.DialogKind;
import net.minecraft.class_310;

public final class CopyDialog {
    private static final int TEXT = BaseRenderer.white(0.96f);
    private static final int SUB = BaseRenderer.white(0.55f);
    private final Supplier<ConfigProfileManager> library;
    private final Supplier<String> clipboard;
    private final Consumer<String> copy;
    private final List<Action> hits = new ArrayList<Action>();
    private final Map<String, Float> hover = new HashMap<String, Float>();
    private boolean opened;
    private boolean selectAll;
    private float progress;
    private float unit;
    private float delta;
    private float x;
    private float y;
    private float width;
    private float height;
    private float caret;
    private double mx;
    private double my;
    private DialogKind dialog = DialogKind.NONE;
    private String target;
    private String input = "";
    private String status = "";
    private String selection;
    private boolean error;

    public CopyDialog() {
        this(CopyDialog::lmbd$new$0, CopyDialog::lmbd$new$1, CopyDialog::lmbd$new$2);
    }

    public CopyDialog(Supplier<ConfigProfileManager> supplier, Supplier<String> supplier2, Consumer<String> consumer) {
        this.library = supplier;
        this.clipboard = supplier2;
        this.copy = consumer;
    }

    public void open() {
        this.opened = true;
        this.dialog = DialogKind.NONE;
        this.status = "";
        this.error = false;
        try {
            this.selection = this.library.get().selected();
        }
        catch (RuntimeException runtimeException) {
            this.fail(runtimeException);
        }
        GuiAudio.play(GuiSoundType.OPEN);
    }

    public void close() {
        this.opened = false;
        this.dialog = DialogKind.NONE;
        GuiAudio.play(GuiSoundType.BACK);
    }

    public boolean active() {
        if (this.opened) return true;
        if (!(this.progress > 0.005f)) return false;
        return true;
    }

    public boolean isOpen() {
        return this.opened;
    }

    public float visibility() {
        return this.progress;
    }

    private float d(float f) {
        return f * this.unit;
    }

    private void fail(RuntimeException runtimeException) {
        this.status = runtimeException.getMessage() == null ? "Couldn't complete this action." : runtimeException.getMessage();
        this.error = true;
    }

    private void run(Runnable runnable, String string) {
        try {
            runnable.run();
            this.status = string;
            this.error = false;
            GuiAudio.play(GuiSoundType.CONFIRM);
            return;
        }
        catch (RuntimeException runtimeException) {
            this.fail(runtimeException);
        }
    }

    public void render(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6, double d, double d2, boolean bl) {
        List<ConfigProfile> list;
        this.unit = f5;
        this.delta = f6;
        this.mx = d;
        this.my = d2;
        this.caret += f6;
        this.progress += ((this.opened ? 1.0f : 0.0f) - this.progress) * (1.0f - (float)Math.exp(-14.0f * f6));
        if (this.progress < 0.005f && !this.opened) {
            this.progress = 0.0f;
            this.hits.clear();
            return;
        }
        this.x = f;
        this.y = f2;
        this.width = f3;
        this.height = f4;
        this.hits.clear();
        baseRenderer.pushAlpha(this.progress);
        float f7 = this.d(6.0f) * (1.0f - Easing.out(this.progress));
        this.y += f7;
        boolean bl2 = this.opened && bl && this.progress > 0.6f;
        try {
            list = this.library.get().profiles();
        }
        catch (RuntimeException runtimeException) {
            this.fail(runtimeException);
            list = List.of();
        }
        baseRenderer.round(this.x + this.d(22.0f), this.y + this.d(18.0f), this.d(44.0f), this.d(44.0f), this.d(14.0f), BaseRenderer.white(0.07f));
        baseRenderer.outline(this.x + this.d(22.0f), this.y + this.d(18.0f), this.d(44.0f), this.d(44.0f), this.d(14.0f), Math.max(1.0f, this.unit * 0.9f), BaseRenderer.white(0.09f));
        baseRenderer.icon(SpeakerOff.FOLDER, this.x + this.d(33.5f), this.y + this.d(29.5f), this.d(21.0f), TEXT);
        baseRenderer.text("Configs", this.x + this.d(82.0f), this.y + this.d(19.0f), this.d(21.0f), 1, TEXT);
        baseRenderer.text(list.size() + " / 5 saved", this.x + this.d(83.0f), this.y + this.d(45.0f), this.d(12.0f), 0, SUB);
        this.iconButton(baseRenderer, "close", SpeakerOff.CLOSE, "Close", this.x + this.width - this.d(54.0f), this.y + this.d(24.0f), this.d(32.0f), bl2, this::close);
        baseRenderer.rect(this.x + this.d(20.0f), this.y + this.d(78.0f), this.width - this.d(40.0f), Math.max(1.0f, this.unit), BaseRenderer.white(0.055f));
        boolean bl3 = list.size() >= 5;
        this.button(baseRenderer, "create", "Create new", SpeakerOff.PLUS, this.x + this.d(22.0f), this.y + this.d(94.0f), this.d(132.0f), this.d(34.0f), bl2 && !bl3, true, this::lmbd$render$0);
        this.button(baseRenderer, "paste", "Paste config", SpeakerOff.COPY, this.x + this.d(164.0f), this.y + this.d(94.0f), this.d(132.0f), this.d(34.0f), bl2 && !bl3, false, this::lmbd$render$1);
        this.button(baseRenderer, "reset", "Reset all", SpeakerOff.RESET, this.x + this.width - this.d(136.0f), this.y + this.d(94.0f), this.d(114.0f), this.d(34.0f), bl2, false, this::lmbd$render$3);
        float f8 = this.y + this.d(144.0f);
        float f9 = this.width - this.d(44.0f);
        if (list.isEmpty()) {
            baseRenderer.textCentered("No saved configs", this.x + this.width / 2.0f, this.y + this.d(281.0f), this.d(14.0f), 1, SUB);
            baseRenderer.textCentered("Create new or paste a config.", this.x + this.width / 2.0f, this.y + this.d(308.0f), this.d(11.5f), 0, BaseRenderer.white(0.34f));
        }
        for (ConfigProfile configProfile : list) {
            String string = configProfile.id();
            boolean bl4 = Objects.equals(this.selection, string);
            float f10 = this.x + this.d(22.0f);
            float f11 = this.d(58.0f);
            float f12 = this.animate("row:" + string, this.hot(f10, f8, f9, f11) && bl2 ? 1.0f : 0.0f);
            baseRenderer.round(f10, f8, f9, f11, this.d(16.0f), Easing.mix(BaseRenderer.white((bl4 ? 0.065f : 0.03f) + 0.025f * f12), Theme.accent(0.065f + 0.025f * f12), bl4 ? 0.25f : 0.0f));
            baseRenderer.roundGradient(f10, f8, f9, f11, this.d(16.0f), BaseRenderer.white(0.025f), BaseRenderer.white(0.0f));
            baseRenderer.outline(f10, f8, f9, f11, this.d(16.0f), Math.max(1.0f, this.unit * 0.9f), BaseRenderer.white((bl4 ? 0.12f : 0.055f) + 0.05f * f12));
            baseRenderer.icon(bl4 ? SpeakerOff.CHECK : SpeakerOff.FOLDER, f10 + this.d(15.0f), f8 + this.d(17.0f), this.d(19.0f), bl4 ? Theme.accent(0.9f) : SUB);
            baseRenderer.text(baseRenderer.ellipsize(configProfile.name(), f9 - this.d(265.0f), this.d(14.0f), 1), f10 + this.d(47.0f), f8 + this.d(10.0f), this.d(14.0f), 1, TEXT);
            baseRenderer.text(configProfile.enabledCount() + " enabled", f10 + this.d(47.0f), f8 + this.d(33.0f), this.d(10.5f), 0, SUB);
            if (bl2 && this.dialog == DialogKind.NONE) {
                this.hits.add(new Action(f10, f8, f9, f11, () -> this.lmbd$render$4(string)));
            }
            float f13 = f10 + f9 - this.d(211.0f);
            this.iconButton(baseRenderer, "rename:" + string, SpeakerOff.EDIT, "Rename", f13, f8 + this.d(11.0f), this.d(32.0f), bl2, () -> this.lmbd$render$6(string, configProfile));
            this.iconButton(baseRenderer, "copy:" + string, SpeakerOff.COPY, "Copy code", f13 + this.d(38.0f), f8 + this.d(11.0f), this.d(32.0f), bl2, () -> this.lmbd$render$7(string));
            this.iconButton(baseRenderer, "delete:" + string, SpeakerOff.TRASH, "Delete", f13 + this.d(76.0f), f8 + this.d(11.0f), this.d(32.0f), bl2, () -> this.lmbd$render$9(string, configProfile));
            this.button(baseRenderer, "load:" + string, "Load", null, f13 + this.d(120.0f), f8 + this.d(10.0f), this.d(76.0f), this.d(35.0f), bl2, bl4, () -> this.lmbd$render$10(string, configProfile));
            f8 += this.d(68.0f);
        }
        float f14 = this.y + this.height - this.d(54.0f);
        baseRenderer.rect(this.x + this.d(20.0f), f14 - this.d(13.0f), this.width - this.d(40.0f), Math.max(1.0f, this.unit), BaseRenderer.white(0.055f));
        this.button(baseRenderer, "save", "Save current", SpeakerOff.CHECK, this.x + this.d(22.0f), f14, this.d(145.0f), this.d(36.0f), bl2 && this.selection != null, true, this::lmbd$render$12);
        baseRenderer.text(baseRenderer.ellipsize(this.status, this.width - this.d(210.0f), this.d(10.7f), 0), this.x + this.d(185.0f), f14 + this.d(11.0f), this.d(10.7f), 0, this.error ? BaseRenderer.white(0.92f) : SUB);
        if (this.dialog != DialogKind.NONE) {
            this.drawDialog(baseRenderer, bl2);
        }
        baseRenderer.popAlpha();
    }

    private float animate(String string, float f) {
        float f2 = this.hover.getOrDefault(string, Float.valueOf(0.0f)).floatValue();
        f2 += (f - f2) * (1.0f - (float)Math.exp(-14.0f * this.delta));
        this.hover.put(string, Float.valueOf(f2));
        return f2;
    }

    private boolean hot(float f, float f2, float f3, float f4) {
        if (!(this.mx >= (double)f)) return false;
        if (!(this.my >= (double)f2)) return false;
        if (!(this.mx < (double)(f + f3))) return false;
        if (!(this.my < (double)(f2 + f4))) return false;
        return true;
    }

    private void button(BaseRenderer baseRenderer, String string, String string2, SpeakerOff speakerOff, float f, float f2, float f3, float f4, boolean bl, boolean bl2, Runnable runnable) {
        boolean bl3;
        boolean bl4 = bl3 = bl && this.dialog == DialogKind.NONE && this.hot(f, f2, f3, f4);
        if (string.startsWith("dialog:")) {
            bl3 = bl && this.hot(f, f2, f3, f4);
        }
        float f5 = this.animate(string, bl3 ? 1.0f : 0.0f);
        baseRenderer.round(f, f2, f3, f4, this.d(12.0f), Easing.mix(BaseRenderer.white((bl2 && bl ? 0.07f : 0.035f) + 0.04f * f5), Theme.accent(0.09f + 0.04f * f5), bl2 && bl ? 0.25f : 0.0f));
        baseRenderer.roundGradient(f, f2, f3, f4, this.d(12.0f), BaseRenderer.white(0.025f), BaseRenderer.white(0.0f));
        baseRenderer.outline(f, f2, f3, f4, this.d(12.0f), Math.max(1.0f, this.unit * 0.9f), BaseRenderer.white(bl ? 0.08f + 0.075f * f5 : 0.035f));
        int n = BaseRenderer.white(bl ? 0.84f + 0.12f * f5 : 0.26f);
        if (speakerOff != null) {
            baseRenderer.icon(speakerOff, f + this.d(13.0f), f2 + (f4 - this.d(15.0f)) / 2.0f, this.d(15.0f), n);
        }
        baseRenderer.textCentered(string2, f + f3 / 2.0f + (speakerOff == null ? 0.0f : this.d(9.0f)), f2 + (f4 - this.d(11.5f)) / 2.0f - this.d(0.5f), this.d(11.5f), 1, n);
        if (!bl || this.dialog != DialogKind.NONE && !string.startsWith("dialog:")) return;
        this.hits.add(new Action(f, f2, f3, f4, runnable));
    }

    private void iconButton(BaseRenderer baseRenderer, String string, SpeakerOff speakerOff, String string2, float f, float f2, float f3, boolean bl, Runnable runnable) {
        float f4 = this.animate(string, bl && this.dialog == DialogKind.NONE && this.hot(f, f2, f3, f3) ? 1.0f : 0.0f);
        baseRenderer.round(f, f2, f3, f3, this.d(10.0f), BaseRenderer.white(0.02f + 0.075f * f4));
        baseRenderer.icon(speakerOff, f + (f3 - this.d(16.0f)) / 2.0f, f2 + (f3 - this.d(16.0f)) / 2.0f, this.d(16.0f), BaseRenderer.white(bl ? 0.55f + 0.4f * f4 : 0.25f));
        if (f4 > 0.35f) {
            float f5 = baseRenderer.textWidth(string2, this.d(10.0f), 0) + this.d(16.0f);
            float f6 = f + f3 / 2.0f - f5 / 2.0f;
            baseRenderer.round(f6, f2 - this.d(29.0f), f5, this.d(24.0f), this.d(8.0f), Theme.glass(0.96f));
            baseRenderer.textCentered(string2, f + f3 / 2.0f, f2 - this.d(23.0f), this.d(10.0f), 0, TEXT);
        }
        if (!bl || this.dialog != DialogKind.NONE) return;
        this.hits.add(new Action(f, f2, f3, f3, runnable));
    }

    private void begin(DialogKind u2, String string, String string2) {
        this.dialog = u2;
        this.target = string;
        this.input = string2;
        this.selectAll = u2 == DialogKind.RENAME;
        this.status = "";
        this.error = false;
        this.caret = 0.0f;
        GuiAudio.play(GuiSoundType.OPEN);
    }

    private void drawDialog(BaseRenderer baseRenderer, boolean bl) {
        this.hits.clear();
        baseRenderer.round(this.x, this.y, this.width, this.height, this.d(22.0f), BaseRenderer.argb(0.42f, 5, 6, 9));
        float f = this.d(444.0f);
        float f2 = this.d(222.0f);
        float f3 = this.x + (this.width - f) / 2.0f;
        float f4 = this.y + (this.height - f2) / 2.0f;
        baseRenderer.shadow(f3, f4, f, f2, this.d(20.0f), this.d(30.0f), BaseRenderer.argb(0.55f, 0, 0, 0));
        baseRenderer.round(f3, f4, f, f2, this.d(20.0f), Theme.glass(0.94f));
        baseRenderer.roundGradient(f3, f4, f, f2, this.d(20.0f), BaseRenderer.white(0.05f), BaseRenderer.white(0.0f));
        baseRenderer.outline(f3, f4, f, f2, this.d(20.0f), Math.max(1.0f, this.unit * 0.9f), BaseRenderer.white(0.1f));
        boolean bl2 = this.dialog == DialogKind.CREATE || this.dialog == DialogKind.RENAME;
        String string = switch (this.dialog.ordinal()) {
            case 1 -> "New config";
            case 2 -> "Rename config";
            case 3 -> "Delete config?";
            default -> "Reset all?";
        };
        baseRenderer.text(string, f3 + this.d(24.0f), f4 + this.d(22.0f), this.d(19.0f), 1, TEXT);
        String string2 = bl2 ? "Name" : (this.dialog == DialogKind.DELETE ? "Remove this saved config." : "Reset modules, settings, binds and layout.");
        baseRenderer.text(baseRenderer.ellipsize(string2, f - this.d(48.0f), this.d(11.0f), 0), f3 + this.d(24.0f), f4 + this.d(54.0f), this.d(11.0f), 0, SUB);
        if (bl2) {
            float f5 = f3 + this.d(24.0f);
            float f6 = f4 + this.d(83.0f);
            float f7 = f - this.d(48.0f);
            float f8 = this.d(43.0f);
            baseRenderer.round(f5, f6, f7, f8, this.d(12.0f), BaseRenderer.white(0.055f));
            baseRenderer.outline(f5, f6, f7, f8, this.d(12.0f), Math.max(1.0f, this.unit), Theme.accent(0.35f));
            if (this.selectAll && !this.input.isEmpty()) {
                baseRenderer.round(f5 + this.d(12.0f), f6 + this.d(10.0f), Math.min(f7 - this.d(24.0f), baseRenderer.textWidth(this.input, this.d(13.0f), 0)), this.d(22.0f), this.d(4.0f), Theme.accent(0.18f));
            }
            baseRenderer.pushClip(f5 + this.d(12.0f), f6, f7 - this.d(24.0f), f8);
            float f9 = baseRenderer.textWidth(this.input, this.d(13.0f), 0);
            float f10 = Math.max(0.0f, f9 - f7 + this.d(28.0f));
            baseRenderer.text(this.input.isEmpty() ? "Config name" : this.input, f5 + this.d(13.0f) - f10, f6 + this.d(13.0f), this.d(13.0f), 0, this.input.isEmpty() ? SUB : TEXT);
            if (this.caret % 1.2f < 0.6f) {
                baseRenderer.rect(f5 + this.d(14.0f) + f9 - f10, f6 + this.d(11.0f), Math.max(1.0f, this.unit), this.d(21.0f), TEXT);
            }
            baseRenderer.popClip();
        } else {
            baseRenderer.text(this.dialog == DialogKind.DELETE ? this.input : "Your saved configs will remain available.", f3 + this.d(24.0f), f4 + this.d(99.0f), this.d(13.0f), 1, TEXT);
        }
        if (this.error) {
            baseRenderer.text(baseRenderer.ellipsize(this.status, f - this.d(48.0f), this.d(10.5f), 0), f3 + this.d(24.0f), f4 + this.d(140.0f), this.d(10.5f), 0, TEXT);
        }
        this.button(baseRenderer, "dialog:cancel", "Cancel", null, f3 + this.d(24.0f), f4 + f2 - this.d(55.0f), this.d(116.0f), this.d(34.0f), bl, false, this::lmbd$drawDialog$0);
        String string3 = switch (this.dialog.ordinal()) {
            case 1 -> "Create";
            case 2 -> "Rename";
            case 3 -> "Delete";
            default -> "Reset All";
        };
        this.button(baseRenderer, "dialog:confirm", string3, null, f3 + f - this.d(146.0f), f4 + f2 - this.d(55.0f), this.d(122.0f), this.d(34.0f), bl, true, this::confirm);
    }

    private void confirm() {
        try {
            switch (this.dialog.ordinal()) {
                case 1: {
                    this.selection = this.library.get().create(this.input);
                    this.status = "Config created.";
                    break;
                }
                case 2: {
                    this.library.get().rename(this.target, this.input);
                    this.status = "Config renamed.";
                    break;
                }
                case 3: {
                    this.library.get().delete(this.target);
                    this.selection = this.library.get().selected();
                    this.status = "Config deleted.";
                    break;
                }
                case 4: {
                    this.library.get().resetCurrent();
                    this.status = "Reset complete.";
                    break;
                }
                default: {
                    return;
                }
            }
            this.dialog = DialogKind.NONE;
            this.error = false;
            GuiAudio.play(GuiSoundType.CONFIRM);
            return;
        }
        catch (RuntimeException runtimeException) {
            this.fail(runtimeException);
        }
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (!this.active()) {
            return false;
        }
        if (!this.opened || this.progress < 0.6f || n != 0) {
            return true;
        }
        for (int i = this.hits.size() - 1; i >= 0; --i) {
            Action action = this.hits.get(i);
            if (!(d >= (double)action.x()) || !(d2 >= (double)action.y()) || !(d < (double)(action.x() + action.w())) || !(d2 < (double)(action.y() + action.h()))) continue;
            action.action().run();
            return true;
        }
        if (this.dialog != DialogKind.NONE || d >= (double)this.x && d2 >= (double)this.y && d < (double)(this.x + this.width) && d2 < (double)(this.y + this.height)) return true;
        this.close();
        return true;
    }

    public boolean keyPressed(int n, int n2) {
        boolean bl;
        if (!this.active()) {
            return false;
        }
        if (n == 256) {
            if (this.dialog != DialogKind.NONE) {
                this.dialog = DialogKind.NONE;
                this.error = false;
                this.status = "";
                return true;
            } else {
                this.close();
            }
            return true;
        }
        boolean bl2 = this.dialog == DialogKind.CREATE || this.dialog == DialogKind.RENAME;
        boolean bl3 = bl = (n2 & 2) != 0;
        if (n == 257 || n == 335) {
            if (this.dialog == DialogKind.NONE) return true;
            this.confirm();
            return true;
        }
        if (!bl2) return true;
        if (bl && n == 65) {
            this.selectAll = true;
        } else if (bl && n == 67) {
            this.copy.accept(this.input);
        } else if (bl && n == 86) {
            String string = this.clipboard.get().replaceAll("[\\p{Cntrl}]", "");
            this.input = (this.selectAll ? "" : this.input) + string;
            this.input = this.input.substring(0, Math.min(32, this.input.length()));
            this.selectAll = false;
        } else if (n == 259 || n == 261) {
            this.input = this.selectAll || bl ? "" : this.input.substring(0, Math.max(0, this.input.length() - 1));
            this.selectAll = false;
        }
        this.caret = 0.0f;
        return true;
    }

    public boolean charTyped(char c) {
        if (!this.active()) {
            return false;
        }
        if (Character.isISOControl(c) || this.dialog != DialogKind.CREATE && this.dialog != DialogKind.RENAME) return true;
        if (this.selectAll) {
            this.input = "";
        }
        if (this.input.length() < 32) {
            this.input = this.input + c;
        }
        this.selectAll = false;
        this.caret = 0.0f;
        return true;
    }

    private void lmbd$drawDialog$0() {
        this.dialog = DialogKind.NONE;
        this.status = "";
        this.error = false;
    }

    private void lmbd$render$12() {
        this.run(this::lmbd$render$13, "Saved.");
    }

    private void lmbd$render$13() {
        this.library.get().saveCurrent(this.selection);
    }

    private void lmbd$render$10(String string, ConfigProfile configProfile) {
        this.run(() -> this.lmbd$render$11(string), "Loaded " + configProfile.name() + ".");
    }

    private void lmbd$render$11(String string) {
        this.library.get().loadConfig(string);
        this.selection = string;
    }

    private void lmbd$render$9(String string, ConfigProfile configProfile) {
        this.begin(DialogKind.DELETE, string, configProfile.name());
    }

    private void lmbd$render$7(String string) {
        this.run(() -> this.lmbd$render$8(string), "Code copied.");
    }

    private void lmbd$render$8(String string) {
        this.copy.accept(this.library.get().copyCode(string));
    }

    private void lmbd$render$6(String string, ConfigProfile configProfile) {
        this.begin(DialogKind.RENAME, string, configProfile.name());
    }

    private void lmbd$render$4(String string) {
        this.run(() -> this.lmbd$render$5(string), "");
    }

    private void lmbd$render$5(String string) {
        this.library.get().select(string);
        this.selection = string;
    }

    private void lmbd$render$3() {
        this.begin(DialogKind.RESET, null, "");
    }

    private void lmbd$render$1() {
        this.run(this::lmbd$render$2, "Imported. Click Load to apply.");
    }

    private void lmbd$render$2() {
        this.selection = this.library.get().pasteCode(this.clipboard.get());
    }

    private void lmbd$render$0() {
        this.begin(DialogKind.CREATE, null, "");
    }

    private static void lmbd$new$2(String string) {
        class_310.method_1551().field_1774.method_1455(string);
    }

    private static String lmbd$new$1() {
        return class_310.method_1551().field_1774.method_1460();
    }

    private static ConfigProfileManager lmbd$new$0() {
        return KryzexClient.INSTANCE.getSettingsManager().configs();
    }
}
