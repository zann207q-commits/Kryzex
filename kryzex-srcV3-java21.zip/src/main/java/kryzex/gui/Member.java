package kryzex.gui;

import kryzex.gui.Name;

final class Member {
    Name member;
    boolean active;
    float alpha;
    float y;
    int index;

    Member(Name name, int n) {
        this.member = name;
        this.index = n;
        this.y = (float)n * 30.0f;
    }
}
