package kryzex.gui;

final class Speed2 {
    float x;
    float y;
    float size;
    float speed;
    float drift;
    float seed;
    float life;
    float age;
    float alpha;
    float warm;

    public Speed2() {
    }
}
