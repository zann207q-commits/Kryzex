package kryzex.gui;

import kryzex.gui.Rect;

public final class UtilityIcons {
    public static final int BUTTONS = 6;
    public static final int UTILITIES = 8;
    public static final int SHAPES = 17;
    public final float scale;
    public final float offsetX;
    public final float offsetY;
    public final Rect title;
    public final Rect panel;
    public final Rect music;
    public final Rect mute;
    public final Rect slider;
    public final Rect[] buttons = new Rect[6];
    public final Rect[] utilities = new Rect[8];
    public final int[] utilityIcons = new int[8];
    public final int utilityCount;

    public UtilityIcons(int n, int n2, float f) {
        this(n, n2, f, 0);
    }

    public UtilityIcons(int n, int n2, float f, int n3) {
        this.utilityCount = Math.clamp((long)n3, 0, 8);
        this.scale = Math.max(0.01f, Math.min((float)n / 1280.0f, (float)n2 / 720.0f));
        this.offsetX = ((float)n - 1280.0f * this.scale) * 0.5f;
        this.offsetY = ((float)n2 - 720.0f * this.scale) * 0.5f;
        float f2 = (1.0f - f) * 18.0f;
        this.title = this.rect(240.0f, 145.0f + f2 * 0.5f, 800.0f, 133.33333f);
        this.panel = this.rect(442.0f, 288.0f + f2, 396.0f, 280.0f);
        this.buttons[0] = this.rect(469.0f, 314.0f + f2, 342.0f, 54.0f);
        this.buttons[1] = this.rect(469.0f, 378.0f + f2, 342.0f, 54.0f);
        this.buttons[2] = this.rect(469.0f, 442.0f + f2, 342.0f, 44.0f);
        this.buttons[3] = this.rect(469.0f, 496.0f + f2, 108.0f, 44.0f);
        this.buttons[4] = this.rect(586.0f, 496.0f + f2, 108.0f, 44.0f);
        this.buttons[5] = this.rect(703.0f, 496.0f + f2, 108.0f, 44.0f);
        for (int i = 0; i < 8; ++i) {
            this.utilities[i] = this.rect(900.0f, (float)(300 + 44 * i) + f2, 220.0f, 36.0f);
        }
        this.music = this.rect(28.0f, 650.0f, 284.0f, 44.0f);
        this.mute = this.rect(35.0f, 657.0f, 30.0f, 30.0f);
        this.slider = this.rect(174.0f, 669.0f, 119.0f, 8.0f);
    }

    public Rect rect(float f, float f2, float f3, float f4) {
        return new Rect(this.offsetX + f * this.scale, this.offsetY + f2 * this.scale, f3 * this.scale, f4 * this.scale);
    }

    public Rect shape(int n) {
        return n == 0 ? this.panel : (n <= 6 ? this.buttons[n - 1] : (n == 7 ? this.music : (n == 8 ? this.mute : (n - 9 < this.utilityCount ? this.utilities[n - 9] : new Rect(0.0f, 0.0f, 0.0f, 0.0f)))));
    }

    public float corner(int n) {
        return (float)(n == 0 ? 29 : (n == 7 ? 18 : (n == 8 ? 12 : (n >= 9 ? 13 : 16)))) * this.scale;
    }
}
