package kryzex.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_5348;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
public class NotificationToast
implements class_368 {
    private static final class_2960 BACKGROUND = class_2960.method_60656((String)"toast/advancement");
    private static final int TITLE_COLOR = -30465;
    private static final int MESSAGE_COLOR = -1;
    private static final int TEXT_X = 30;
    private static final int TEXT_PAD = 4;
    private static final int MAX_WIDTH = 240;
    private static final long DISPLAY_MILLIS = 5000L;
    private final Object token;
    private final class_1799 icon;
    private final boolean sound;
    private class_2561 title;
    private class_2561 message;
    private int width;
    private int count = 1;
    private boolean changed;
    private boolean hiding;
    private long changedAt;
    private class_368.class_369 wanted = class_368.class_369.field_2209;

    public NotificationToast(class_1799 class_17992, class_2561 class_25612, class_2561 class_25613, boolean bl) {
        this(field_2208, class_17992, class_25612, class_25613, bl);
    }

    private NotificationToast(Object object, class_1799 class_17992, class_2561 class_25612, class_2561 class_25613, boolean bl) {
        this.token = object;
        this.icon = class_17992.method_7972();
        this.icon.method_57379(class_9334.field_49641, true);
        this.title = class_25612;
        this.message = class_25613;
        this.sound = bl;
        this.fit();
    }

    public static void addOrUpdate(class_1799 class_17992, String string, class_2561 class_25612, boolean bl) {
        NotificationToast.addOrUpdate(class_17992, string, null, class_25612, bl);
    }

    public static void addOrUpdate(class_1799 class_17992, String string, String string2, class_2561 class_25612, boolean bl) {
        class_310 class_3102 = class_310.method_1551();
        if (!class_3102.method_18854()) {
            class_3102.execute(() -> NotificationToast.lmbd$addOrUpdate$0(class_17992, string, string2, class_25612, bl));
            return;
        } else {
            class_374 class_3742 = class_3102.method_1566();
            NotificationToast notificationToast = (NotificationToast)class_3742.method_1997(NotificationToast.class, (Object)string);
            if (notificationToast == null) {
                class_3742.method_1999((class_368)new NotificationToast(string, class_17992, (class_2561)class_2561.method_43470((String)string), class_25612, bl));
                return;
            } else {
                ++notificationToast.count;
                if (string2 != null) {
                    notificationToast.title = class_2561.method_43470((String)(notificationToast.count + " " + string2));
                }
                notificationToast.message = class_25612;
                notificationToast.changed = true;
                notificationToast.fit();
            }
        }
    }

    private void fit() {
        class_327 class_3272 = class_310.method_1551().field_1772;
        int n = Math.max(class_3272.method_27525((class_5348)this.title), class_3272.method_27525((class_5348)this.message));
        this.width = class_3532.method_15340((int)(30 + n + 4), 160, 240);
    }

    public Object method_1987() {
        return this.token;
    }

    public class_3414 method_66530() {
        if (!this.sound) return null;
        class_3414 class_34142 = (class_3414)class_3417.field_14793.comp_349();
        return class_34142;
    }

    public class_368.class_369 method_61988() {
        return this.wanted;
    }

    public int method_29049() {
        return this.width;
    }

    public void method_61989(class_374 class_3742, long l) {
        if (this.hiding) return;
        if (this.changed) {
            this.changedAt = l;
            this.changed = false;
        }
        this.hiding = (double)(l - this.changedAt) >= 5000.0 * class_3742.method_48221();
        this.wanted = this.hiding ? class_368.class_369.field_2209 : class_368.class_369.field_2210;
    }

    public void method_71995() {
        if (!this.changed) return;
        this.hiding = false;
        class_310.method_1551().method_1566().method_1999((class_368)this);
    }

    public void method_1986(class_332 class_3322, class_327 class_3272, long l) {
        int n = this.width / 2;
        NotificationToast.drawBackground(class_3322, 0, 0, n);
        NotificationToast.drawBackground(class_3322, 160 - (this.width - n), n, this.width - n);
        boolean bl = this.message.getString().isEmpty();
        this.drawText(class_3322, class_3272, this.title, bl ? 12 : 7, -30465);
        if (!bl) {
            this.drawText(class_3322, class_3272, this.message, 18, -1);
        }
        class_3322.method_51445(this.icon, 8, 8);
    }

    private static void drawBackground(class_332 class_3322, int n, int n2, int n3) {
        class_3322.method_70846(class_10799.field_56883, BACKGROUND, 160, 32, n, 0, n2, 0, n3, 32);
    }

    private void drawText(class_332 class_3322, class_327 class_3272, class_2561 class_25612, int n, int n2) {
        int n3 = this.width - 30 - 4;
        int n4 = class_3272.method_27525((class_5348)class_25612);
        if (n4 <= n3) {
            class_3322.method_51439(class_3272, class_25612, 30, n, n2, false);
            return;
        } else {
            class_3322.method_51448().pushMatrix();
            class_3322.method_51448().translate(30.0f, (float)n);
            class_3322.method_51448().scale((float)n3 / (float)n4, 1.0f);
            class_3322.method_51439(class_3272, class_25612, 0, 0, n2, false);
            class_3322.method_51448().popMatrix();
        }
    }

    private static void lmbd$addOrUpdate$0(class_1799 class_17992, String string, String string2, class_2561 class_25612, boolean bl) {
        NotificationToast.addOrUpdate(class_17992, string, string2, class_25612, bl);
    }
}
