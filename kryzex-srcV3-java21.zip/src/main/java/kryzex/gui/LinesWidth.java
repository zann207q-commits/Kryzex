package kryzex.gui;

import java.util.List;
import java.util.Locale;
import kryzex.gui.Bool;
import kryzex.gui.Button;
import kryzex.gui.Choice;
import kryzex.gui.Dragging;
import kryzex.gui.Focus;
import kryzex.gui.Tween;
import kryzex.gui.LastSource;
import kryzex.gui.Listening;
import kryzex.gui.ListeningModule;
import kryzex.gui.Mode;
import kryzex.gui.OfferedText;
import kryzex.gui.ColorSettingRow;
import kryzex.gui.ShownValue;
import kryzex.gui.SquareCorners;
import kryzex.gui.Storage;
import kryzex.gui.Summary;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.RangeSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.module.settings.StringSetting;

public abstract class LinesWidth {
    public final Module module;
    public final Setting setting;
    protected final String name;
    protected float hover;
    private float shown = 1.0f;
    private List<String> lines;
    private float linesWidth = -1.0f;
    private Object linesAtlas;

    protected LinesWidth(Module module, Setting setting) {
        this.module = module;
        this.setting = setting;
        this.name = ListeningModule.name(setting.getName());
    }

    public static LinesWidth of(ListeningModule listeningModule, Module module, Setting setting) {
        ListSetting listSetting;
        if (setting instanceof BoolSetting) {
            BoolSetting boolSetting = (BoolSetting)((Object)setting);
            return new Bool(module, boolSetting);
        }
        if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            return new ShownValue(module, numberSetting);
        }
        if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            return new Dragging(module, rangeSetting);
        }
        if (setting instanceof CycleSetting) {
            CycleSetting cycleSetting = (CycleSetting)((Object)setting);
            return new Mode(module, cycleSetting);
        }
        if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            return new Choice(module, modeSetting);
        }
        if (setting instanceof KeybindSetting) {
            KeybindSetting keybindSetting = (KeybindSetting)((Object)setting);
            return new Listening(module, keybindSetting);
        }
        if (setting instanceof ActionSetting) {
            ActionSetting actionSetting = (ActionSetting)setting;
            return new Button(module, actionSetting);
        }
        if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            return new ColorSettingRow(module, colorSetting);
        }
        if (setting instanceof ListSetting && (listSetting = (ListSetting)setting).isColorOnly()) {
            return new Storage(module, listSetting);
        }
        if (listeningModule.host.pickerSummary(module, setting) != null) {
            return new Summary(module, setting);
        }
        if (!(setting instanceof StringSetting)) return null;
        StringSetting stringSetting = (StringSetting)((Object)setting);
        Focus focus = new Focus(module, stringSetting);
        return focus;
    }

    public void settle() {
        this.shown = SettingGroup.visible(this.setting) ? 1.0f : 0.0f;
    }

    protected abstract float controlWidth(SquareCorners var1);

    protected abstract float baseHeight();

    protected boolean condenses() {
        return false;
    }

    public float height(ListeningModule listeningModule, float f) {
        return this.fullHeight(listeningModule.painter, f) * Tween.easeInOut(this.shown);
    }

    public void tick(ListeningModule listeningModule) {
        this.shown = Tween.approach(this.shown, SettingGroup.visible(this.setting) ? 1.0f : 0.0f, 16.0f, listeningModule.dt);
    }

    private float fullHeight(SquareCorners squareCorners, float f) {
        return this.baseHeight() + (float)(this.labelLines(squareCorners, f).size() - 1) * 19.0f;
    }

    private float labelWidth(SquareCorners squareCorners, float f) {
        return f - 8.0f - 10.0f - this.controlWidth(squareCorners) - 6.0f;
    }

    protected List<String> labelLines(SquareCorners squareCorners, float f) {
        float f2 = this.labelWidth(squareCorners, f);
        if (this.lines != null && f2 == this.linesWidth && this.linesAtlas == squareCorners.atlasKey()) return this.lines;
        List<String> list = this.lines = this.condenses() && squareCorners.tightWidth(this.name) <= f2 ? List.of(this.name) : OfferedText.wrap(squareCorners, this.name, Math.max(30.0f, f2));
        if (this.lines.size() > 3) {
            this.lines = this.lines.subList(0, 3);
        }
        this.linesWidth = f2;
        this.linesAtlas = squareCorners.atlasKey();
        return this.lines;
    }

    protected float drawLabel(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        SquareCorners squareCorners = listeningModule.painter;
        List<String> list = this.labelLines(squareCorners, f3);
        int n = LastSource.mix(-3553071, -1776662, this.hover);
        float f5 = this.labelWidth(squareCorners, f3);
        float f6 = f2 + f4;
        for (String string : list) {
            squareCorners.text(string, f + 8.0f, f6, n, Math.max(30.0f, f5));
            f6 += 19.0f;
        }
        return f2 + f4 + (float)(list.size() - 1) * 19.0f / 2.0f;
    }

    public void render(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        boolean bl;
        boolean bl2;
        if (f4 < 0.5f) return;
        SquareCorners squareCorners = listeningModule.painter;
        int n = squareCorners.clipState();
        float f5 = squareCorners.alpha();
        boolean bl3 = bl2 = this.shown < 0.999f;
        if (bl2) {
            squareCorners.clip(f2, f2 + f4);
            squareCorners.alpha(f5 * Tween.easeInOut(this.shown));
        }
        this.hover = Tween.approach(this.hover, !(bl = listeningModule.over(f, f2, f + f3, f2 + f4)) && listeningModule.captured != this ? 0.0f : 1.0f, 16.0f, listeningModule.dt);
        if (this.hover > 0.01f) {
            squareCorners.rect(f, f2, f + f3, f2 + f4, LastSource.withAlpha(0x10FFFFFF, this.hover));
        }
        if (bl) {
            String string = ListeningModule.name(this.setting.getDescription());
            listeningModule.tooltip.offer(this.setting, (String)(string.isEmpty() ? this.name : this.name + ": " + string));
        }
        this.draw(listeningModule, f, f2, f3, f4);
        if (!bl2) return;
        squareCorners.restoreClip(n);
        squareCorners.alpha(f5);
    }

    protected abstract void draw(ListeningModule var1, float var2, float var3, float var4, float var5);

    public abstract boolean mouseClicked(ListeningModule var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8);

    static String format(double d, double d2) {
        if (d2 >= 1.0 || Math.abs(d - Math.rint(d)) < 1.0E-9 && d2 <= 0.0) {
            return String.valueOf(Math.round(d));
        }
        int n = d2 <= 0.0 ? 2 : Math.max(0, Math.min(3, (int)Math.ceil(-Math.log10(d2) - 1.0E-9)));
        return String.format(Locale.ROOT, "%." + n + "f", d);
    }

    static double snap(double d, double d2, double d3, double d4) {
        d = Math.max(d2, Math.min(d3, d));
        if (!(d4 > 0.0)) return d;
        d = (double)Math.round((d - d2) / d4) * d4 + d2;
        return Math.max(d2, Math.min(d3, d));
    }
}
