package kryzex.gui;

public class Rect {
    public final float x;
    public final float y;
    public final float w;
    public final float h;

    public Rect(float x, float y, float w, float h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public float x() {
        return this.x;
    }

    public float y() {
        return this.y;
    }

    public float w() {
        return this.w;
    }

    public float h() {
        return this.h;
    }
    public boolean contains(double d, double d2) {
        if (!(d >= (double)this.x)) return false;
        if (!(d2 >= (double)this.y)) return false;
        if (!(d < (double)(this.x + this.w))) return false;
        if (!(d2 < (double)(this.y + this.h))) return false;
        return true;
    }
}
