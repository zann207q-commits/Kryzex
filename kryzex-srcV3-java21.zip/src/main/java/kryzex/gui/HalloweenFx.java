package kryzex.gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import kryzex.gui.Handle;
import kryzex.gui.FallbackFont;

final class HalloweenFx {
    static final int GHOST_FRAMES = 8;
    private static final Map<String, Handle> CACHE = new HashMap<String, Handle>();

    private HalloweenFx() {
    }

    static int quant(float f) {
        return Math.max(8, Math.min(512, Math.round(f / 8.0f) * 8));
    }

    private static Handle cached(String string, Supplier<Handle> supplier) {
        Handle handle = CACHE.get(string);
        if (handle != null) return handle;
        handle = supplier.get();
        CACHE.put(string, handle);
        return handle;
    }

    private static Graphics2D g(BufferedImage bufferedImage) {
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        graphics2D.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        return graphics2D;
    }

    private static Handle finish(String string, BufferedImage bufferedImage, int n, int n2, int n3, boolean bl) {
        float f;
        int n4;
        int n5;
        int[] nArray = bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), null, 0, bufferedImage.getWidth());
        int n6 = bufferedImage.getWidth();
        int n7 = n6 / n;
        float[] fArray = new float[n * n2];
        float[] fArray2 = new float[n * n2];
        float[] fArray3 = new float[n * n2];
        float[] fArray4 = new float[n * n2];
        for (n5 = 0; n5 < n2; ++n5) {
            for (n4 = 0; n4 < n; ++n4) {
                int n8;
                f = 0.0f;
                float f2 = 0.0f;
                float f3 = 0.0f;
                float f4 = 0.0f;
                for (n8 = 0; n8 < n7; ++n8) {
                    for (int i = 0; i < n7; ++i) {
                        int n9 = nArray[(n5 * n7 + n8) * n6 + n4 * n7 + i];
                        float f5 = (float)(n9 >>> 24) / 255.0f;
                        f += f5;
                        f2 += (float)(n9 >> 16 & 0xFF) * f5;
                        f3 += (float)(n9 >> 8 & 0xFF) * f5;
                        f4 += (float)(n9 & 0xFF) * f5;
                    }
                }
                n8 = n5 * n + n4;
                fArray[n8] = f / (float)(n7 * n7);
                fArray2[n8] = f2 / (float)(n7 * n7);
                fArray3[n8] = f3 / (float)(n7 * n7);
                fArray4[n8] = f4 / (float)(n7 * n7);
            }
        }
        for (n5 = 0; n5 < n3; ++n5) {
            fArray = HalloweenFx.box(fArray, n, n2);
            fArray2 = HalloweenFx.box(fArray2, n, n2);
            fArray3 = HalloweenFx.box(fArray3, n, n2);
            fArray4 = HalloweenFx.box(fArray4, n, n2);
        }
        int[] nArray2 = new int[n * n2];
        for (n4 = 0; n4 < nArray2.length; ++n4) {
            f = Math.min(1.0f, fArray[n4]);
            if (bl) {
                nArray2[n4] = Math.round(f * 255.0f) << 24 | 0xFFFFFF;
                continue;
            }
            if (!(f > 1.0E-4f)) continue;
            int n10 = Math.min(255, Math.round(fArray2[n4] / fArray[n4]));
            int n11 = Math.min(255, Math.round(fArray3[n4] / fArray[n4]));
            int n12 = Math.min(255, Math.round(fArray4[n4] / fArray[n4]));
            nArray2[n4] = Math.round(f * 255.0f) << 24 | n10 << 16 | n11 << 8 | n12;
        }
        return new Handle(string, n, n2, nArray2);
    }

    private static float[] box(float[] fArray, int n, int n2) {
        float[] fArray2 = new float[fArray.length];
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n; ++j) {
                float f = 0.0f;
                int n3 = 0;
                for (int k = -1; k <= 1; ++k) {
                    for (int i2 = -1; i2 <= 1; ++i2) {
                        int n4 = j + i2;
                        int n5 = i + k;
                        if (n4 < 0 || n5 < 0 || n4 >= n || n5 >= n2) continue;
                        f += fArray[n5 * n + n4];
                        ++n3;
                    }
                }
                fArray2[i * n + j] = f / (float)n3;
            }
        }
        return fArray2;
    }

    static Handle ghost(int n, int n2) {
        int n3 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_ghost_" + n3 + "_" + n2, () -> HalloweenFx.lmbd$ghost$0(n3, n2));
    }

    static Handle pumpkin(int n) {
        int n2 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_pumpkin_" + n2, () -> HalloweenFx.lmbd$pumpkin$0(n2));
    }

    static Handle web(int n) {
        return HalloweenFx.web(n, false);
    }

    static Handle web(int n, boolean bl) {
        int n2 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_web_" + n2 + (bl ? "m" : ""), () -> HalloweenFx.lmbd$web$0(n2, bl));
    }

    static Handle spider(int n) {
        int n2 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_spider_" + n2, () -> HalloweenFx.lmbd$spider$0(n2));
    }

    static Handle bat(int n, int n2) {
        int n3 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_bat_" + n3 + "_" + n2, () -> HalloweenFx.lmbd$bat$0(n3, n2));
    }

    static Handle moon(int n) {
        int n2 = HalloweenFx.quant(n);
        return HalloweenFx.cached("hw_moon_" + n2, () -> HalloweenFx.lmbd$moon$0(n2));
    }

    static Handle mist(int n, int n2) {
        int n3 = HalloweenFx.quant(n);
        int n4 = HalloweenFx.quant(n2);
        return HalloweenFx.cached("hw_mist_" + n3 + "x" + n4, () -> HalloweenFx.lmbd$mist$0(n3, n4));
    }

    private static float hash(int n, int n2) {
        int n3 = n * 374761393 + n2 * 668265263;
        n3 = (n3 ^ n3 >>> 13) * 1274126177;
        return (float)((n3 ^ n3 >>> 16) & 0xFFFF) / 65535.0f;
    }

    private static float periodicNoise(float f, float f2, int n) {
        int n2 = (int)Math.floor(f);
        int n3 = (int)Math.floor(f2);
        float f3 = f - (float)n2;
        float f4 = f2 - (float)n3;
        float f5 = f3 * f3 * (3.0f - 2.0f * f3);
        float f6 = f4 * f4 * (3.0f - 2.0f * f4);
        int n4 = Math.max(1, n);
        float f7 = HalloweenFx.hash(Math.floorMod(n2, n4), n3);
        float f8 = HalloweenFx.hash(Math.floorMod(n2 + 1, n4), n3);
        float f9 = HalloweenFx.hash(Math.floorMod(n2, n4), n3 + 1);
        float f10 = HalloweenFx.hash(Math.floorMod(n2 + 1, n4), n3 + 1);
        return (f7 + (f8 - f7) * f5 + (f9 - f7) * f6 + (f7 - f8 - f9 + f10) * f5 * f6) * 2.0f - 1.0f;
    }

    static Handle[] lettering(String string, int n, int n2) {
        int n3;
        String string2 = "hw_txt_" + n + "_" + n2 + "_" + Integer.toHexString(string.hashCode());
        Handle handle = CACHE.get(string2);
        Handle handle2 = CACHE.get(string2 + "_g");
        if (handle != null && handle2 != null) return new Handle[]{handle, handle2};
        Font font = FallbackFont.base(n);
        Font font2 = font == null ? new Font("SansSerif", 1, n2) : font.deriveFont((float)n2);
        BufferedImage bufferedImage = new BufferedImage(1, 1, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.setFont(font2);
        FontMetrics fontMetrics = graphics2D.getFontMetrics();
        int n4 = Math.round((float)n2 * 0.55f);
        int n5 = fontMetrics.stringWidth(string) + n4 * 2;
        int n6 = fontMetrics.getAscent() + fontMetrics.getDescent() + n4 * 2;
        graphics2D.dispose();
        BufferedImage bufferedImage2 = new BufferedImage(n5, n6, 2);
        Graphics2D graphics2D2 = HalloweenFx.g(bufferedImage2);
        graphics2D2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics2D2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        graphics2D2.setFont(font2);
        graphics2D2.setColor(Color.WHITE);
        graphics2D2.drawString(string, n4, n4 + fontMetrics.getAscent());
        graphics2D2.dispose();
        int[] nArray = bufferedImage2.getRGB(0, 0, n5, n6, null, 0, n5);
        float[] fArray = new float[n5 * n6];
        for (int i = 0; i < fArray.length; ++i) {
            fArray[i] = (float)(nArray[i] >>> 24) / 255.0f;
        }
        handle = Handle.fromCoverage(string2, n5, n6, fArray);
        float[] fArray2 = (float[])fArray.clone();
        int n7 = Math.max(2, Math.round((float)n2 * 0.16f));
        for (n3 = 0; n3 < 3; ++n3) {
            fArray2 = HalloweenFx.blurH(fArray2, n5, n6, n7);
            fArray2 = HalloweenFx.blurV(fArray2, n5, n6, n7);
        }
        for (n3 = 0; n3 < fArray2.length; ++n3) {
            fArray2[n3] = Math.min(1.0f, fArray2[n3] * 2.2f);
        }
        handle2 = Handle.fromCoverage(string2 + "_g", n5, n6, fArray2);
        CACHE.put(string2, handle);
        CACHE.put(string2 + "_g", handle2);
        return new Handle[]{handle, handle2};
    }

    private static float[] blurH(float[] fArray, int n, int n2, int n3) {
        float[] fArray2 = new float[fArray.length];
        for (int i = 0; i < n2; ++i) {
            int n4;
            float f = 0.0f;
            int n5 = i * n;
            for (n4 = -n3; n4 <= n3; ++n4) {
                f += fArray[n5 + Math.max(0, Math.min(n - 1, n4))];
            }
            for (n4 = 0; n4 < n; ++n4) {
                fArray2[n5 + n4] = f / (float)(2 * n3 + 1);
                f += fArray[n5 + Math.min(n - 1, n4 + n3 + 1)] - fArray[n5 + Math.max(0, n4 - n3)];
            }
        }
        return fArray2;
    }

    private static float[] blurV(float[] fArray, int n, int n2, int n3) {
        float[] fArray2 = new float[fArray.length];
        for (int i = 0; i < n; ++i) {
            int n4;
            float f = 0.0f;
            for (n4 = -n3; n4 <= n3; ++n4) {
                f += fArray[Math.max(0, Math.min(n2 - 1, n4)) * n + i];
            }
            for (n4 = 0; n4 < n2; ++n4) {
                fArray2[n4 * n + i] = f / (float)(2 * n3 + 1);
                f += fArray[Math.min(n2 - 1, n4 + n3 + 1) * n + i] - fArray[Math.max(0, n4 - n3) * n + i];
            }
        }
        return fArray2;
    }

    private static Handle lmbd$mist$0(int n, int n2) {
        float[] fArray = new float[n * n2];
        int n3 = 6;
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n; ++j) {
                float f = (float)j / (float)n;
                float f2 = (float)i / (float)n2;
                float f3 = 0.0f;
                float f4 = 0.55f;
                float f5 = 1.0f;
                for (int k = 0; k < 4; ++k) {
                    f3 += f4 * HalloweenFx.periodicNoise(f * (float)n3 * f5, f2 * 3.0f * f5 + (float)k * 7.3f, (int)((float)n3 * f5));
                    f4 *= 0.5f;
                    f5 *= 2.0f;
                }
                float f6 = (float)Math.sin(Math.PI * (double)f2);
                f6 = f6 * f6 * (0.4f + 0.6f * f2);
                fArray[i * n + j] = Math.max(0.0f, Math.min(1.0f, (f3 * 0.9f + 0.35f) * f6));
            }
        }
        return Handle.fromCoverage("hw_mist_" + n + "x" + n2, n, n2, fArray);
    }

    private static Handle lmbd$moon$0(int n) {
        int n2 = 2;
        BufferedImage bufferedImage = new BufferedImage(n * n2, n * n2, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.scale((double)(n * n2) / 100.0, (double)(n * n2) / 100.0);
        graphics2D.setPaint(new RadialGradientPaint(new Point2D.Double(42.0, 40.0), 60.0f, new float[]{0.0f, 1.0f}, new Color[]{new Color(255, 246, 226), new Color(214, 196, 176)}));
        graphics2D.fill(new Ellipse2D.Double(2.0, 2.0, 96.0, 96.0));
        graphics2D.setColor(new Color(150, 132, 120, 70));
        graphics2D.fill(new Ellipse2D.Double(24.0, 22.0, 26.0, 20.0));
        graphics2D.fill(new Ellipse2D.Double(54.0, 46.0, 22.0, 26.0));
        graphics2D.fill(new Ellipse2D.Double(34.0, 60.0, 14.0, 12.0));
        graphics2D.fill(new Ellipse2D.Double(62.0, 24.0, 10.0, 9.0));
        graphics2D.dispose();
        return HalloweenFx.finish("hw_moon_" + n, bufferedImage, n, n, 1, false);
    }

    private static Handle lmbd$bat$0(int n, int n2) {
        int n3 = n;
        int n4 = n / 2;
        int n5 = 2;
        BufferedImage bufferedImage = new BufferedImage(n3 * n5, n4 * n5, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.scale((double)(n3 * n5) / 100.0, (double)(n4 * n5) / 50.0);
        graphics2D.setColor(Color.WHITE);
        double d = n2 == 0 ? -14.0 : (n2 == 1 ? 0.0 : 10.0);
        Path2D.Double double_ = new Path2D.Double();
        ((Path2D)double_).moveTo(50.0, 22.0);
        ((Path2D)double_).curveTo(40.0, 14.0 + d * 0.3, 22.0, 10.0 + d, 2.0, 14.0 + d);
        ((Path2D)double_).curveTo(10.0, 20.0 + d * 0.6, 12.0, 26.0 + d * 0.3, 10.0, 32.0 + d * 0.2);
        ((Path2D)double_).curveTo(18.0, 27.0, 22.0, 32.0, 26.0, 36.0 + d * 0.1);
        ((Path2D)double_).curveTo(32.0, 30.0, 36.0, 34.0, 40.0, 38.0);
        ((Path2D)double_).curveTo(44.0, 32.0, 46.0, 30.0, 50.0, 34.0);
        ((Path2D)double_).curveTo(54.0, 30.0, 56.0, 32.0, 60.0, 38.0);
        ((Path2D)double_).curveTo(64.0, 34.0, 68.0, 30.0, 74.0, 36.0 + d * 0.1);
        ((Path2D)double_).curveTo(78.0, 32.0, 82.0, 27.0, 90.0, 32.0 + d * 0.2);
        ((Path2D)double_).curveTo(88.0, 26.0 + d * 0.3, 90.0, 20.0 + d * 0.6, 98.0, 14.0 + d);
        ((Path2D)double_).curveTo(78.0, 10.0 + d, 60.0, 14.0 + d * 0.3, 50.0, 22.0);
        double_.closePath();
        graphics2D.fill(double_);
        graphics2D.fill(new Ellipse2D.Double(45.0, 18.0, 10.0, 18.0));
        Path2D.Double double_2 = new Path2D.Double();
        ((Path2D)double_2).moveTo(46.0, 21.0);
        ((Path2D)double_2).lineTo(47.0, 13.0);
        ((Path2D)double_2).lineTo(49.5, 19.0);
        ((Path2D)double_2).lineTo(50.5, 19.0);
        ((Path2D)double_2).lineTo(53.0, 13.0);
        ((Path2D)double_2).lineTo(54.0, 21.0);
        double_2.closePath();
        graphics2D.fill(double_2);
        graphics2D.dispose();
        return HalloweenFx.finish("hw_bat_" + n + "_" + n2, bufferedImage, n3, n4, 0, true);
    }

    private static Handle lmbd$spider$0(int n) {
        int n2 = 2;
        BufferedImage bufferedImage = new BufferedImage(n * n2, n * n2, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.scale((double)(n * n2) / 100.0, (double)(n * n2) / 100.0);
        graphics2D.setColor(Color.WHITE);
        graphics2D.setStroke(new BasicStroke(4.0f, 1, 1));
        for (int i = -1; i <= 1; i += 2) {
            for (int j = 0; j < 4; ++j) {
                double d = 46 + j * 5;
                double d2 = 50 + i * 8;
                double d3 = 50 + i * (30 + j * 4);
                double d4 = d - 16.0 + (double)(j * 14);
                Path2D.Double double_ = new Path2D.Double();
                ((Path2D)double_).moveTo(d2, d);
                ((Path2D)double_).quadTo(50 + i * (22 + j * 2), d - 20.0 + (double)(j * 4), d3, d4);
                graphics2D.draw(double_);
            }
        }
        graphics2D.fill(new Ellipse2D.Double(38.0, 44.0, 24.0, 30.0));
        graphics2D.fill(new Ellipse2D.Double(42.0, 32.0, 16.0, 16.0));
        graphics2D.dispose();
        return HalloweenFx.finish("hw_spider_" + n, bufferedImage, n, n, 0, true);
    }

    private static Handle lmbd$web$0(int n, boolean bl) {
        int n2;
        int n3 = 2;
        BufferedImage bufferedImage = new BufferedImage(n * n3, n * n3, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        if (bl) {
            graphics2D.translate(n * n3, 0);
            graphics2D.scale(-1.0, 1.0);
        }
        double d = (double)(n * n3) / 100.0;
        graphics2D.setColor(Color.WHITE);
        float f = (float)Math.max(1.0, (double)(n * n3) / 140.0);
        graphics2D.setStroke(new BasicStroke(f, 1, 1));
        int n4 = 7;
        double[] dArray = new double[n4];
        for (n2 = 0; n2 < n4; ++n2) {
            dArray[n2] = Math.toRadians(4.0 + (double)n2 * (82.0 / (double)(n4 - 1)));
            graphics2D.draw(new Line2D.Double(0.0, 0.0, Math.cos(dArray[n2]) * 104.0 * d, Math.sin(dArray[n2]) * 104.0 * d));
        }
        for (n2 = 1; n2 <= 6; ++n2) {
            double d2 = (double)n2 * 15.5 * d;
            int n5 = 0;
            while (n5 + 1 < n4) {
                double d3 = d2 * (1.0 + 0.04 * Math.sin((double)n2 * 3.1 + (double)n5));
                double d4 = d2 * (1.0 + 0.04 * Math.sin((double)n2 * 3.1 + (double)n5 + 1.0));
                double d5 = Math.cos(dArray[n5]) * d3;
                double d6 = Math.sin(dArray[n5]) * d3;
                double d7 = Math.cos(dArray[n5 + 1]) * d4;
                double d8 = Math.sin(dArray[n5 + 1]) * d4;
                double d9 = (d5 + d7) / 2.0;
                double d10 = (d6 + d8) / 2.0;
                double d11 = Math.hypot(d9, d10);
                double d12 = 0.86;
                graphics2D.draw(new QuadCurve2D.Double(d5, d6, d9 / d11 * d11 * d12, d10 / d11 * d11 * d12, d7, d8));
                ++n5;
            }
        }
        graphics2D.dispose();
        return HalloweenFx.finish("hw_web_" + n + (bl ? "m" : ""), bufferedImage, n, n, 0, true);
    }

    private static Handle lmbd$pumpkin$0(int n) {
        Serializable serializable;
        double[] object;
        int n2 = 2;
        BufferedImage bufferedImage = new BufferedImage(n * n2, n * n2, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.scale((double)(n * n2) / 100.0, (double)(n * n2) / 100.0);
        double[][] dArrayArray = new double[][]{{18.0, 30.0, 40.0, 62.0}, {60.0, 30.0, 22.0, 62.0}, {30.0, 26.0, 26.0, 66.0}, {44.0, 26.0, 26.0, 66.0}, {36.0, 25.0, 28.0, 68.0}};
        Color[] colorArray = new Color[]{new Color(196, 82, 20), new Color(196, 82, 20), new Color(222, 104, 30), new Color(222, 104, 30), new Color(238, 124, 40)};
        for (int i = 0; i < dArrayArray.length; ++i) {
            object = dArrayArray[i];
            serializable = new Ellipse2D.Double(object[0], object[1], object[2], object[3]);
            graphics2D.setPaint(new RadialGradientPaint(new Point2D.Double(object[0] + object[2] * 0.42, object[1] + object[3] * 0.35), (float)(object[3] * 0.75), new float[]{0.0f, 1.0f}, new Color[]{colorArray[i].brighter(), colorArray[i].darker().darker()}));
            graphics2D.fill((Shape)((Object)serializable));
            graphics2D.setColor(new Color(90, 30, 6, 120));
            graphics2D.setStroke(new BasicStroke(1.2f));
            graphics2D.draw((Shape)((Object)serializable));
        }
        Path2D.Double double_ = new Path2D.Double();
        ((Path2D)double_).moveTo(46.0, 30.0);
        ((Path2D)double_).curveTo(45.0, 22.0, 47.0, 14.0, 54.0, 10.0);
        ((Path2D)double_).lineTo(57.0, 13.0);
        ((Path2D)double_).curveTo(52.0, 17.0, 52.0, 23.0, 54.0, 30.0);
        double_.closePath();
        graphics2D.setPaint(new GradientPaint(46.0f, 10.0f, new Color(96, 110, 52), 54.0f, 30.0f, new Color(48, 52, 22)));
        graphics2D.fill(double_);
        Color color1 = new Color(255, 226, 120);
        Color color2 = new Color(255, 140, 30);
        GeneralPath generalPath = new GeneralPath();
        generalPath.moveTo(32.0f, 52.0f);
        generalPath.lineTo(42.0f, 44.0f);
        generalPath.lineTo(44.0f, 56.0f);
        generalPath.closePath();
        generalPath.moveTo(68.0f, 52.0f);
        generalPath.lineTo(58.0f, 44.0f);
        generalPath.lineTo(56.0f, 56.0f);
        generalPath.closePath();
        generalPath.moveTo(46.0f, 60.0f);
        generalPath.lineTo(50.0f, 55.0f);
        generalPath.lineTo(54.0f, 60.0f);
        generalPath.closePath();
        generalPath.moveTo(30.0f, 66.0f);
        generalPath.curveTo(40.0f, 80.0f, 60.0f, 80.0f, 70.0f, 66.0f);
        generalPath.lineTo(64.0f, 70.0f);
        generalPath.lineTo(60.0f, 66.0f);
        generalPath.lineTo(55.0f, 72.0f);
        generalPath.lineTo(50.0f, 67.0f);
        generalPath.lineTo(45.0f, 72.0f);
        generalPath.lineTo(40.0f, 66.0f);
        generalPath.lineTo(36.0f, 70.0f);
        generalPath.closePath();
        graphics2D.setPaint(new RadialGradientPaint(new Point2D.Double(50.0, 62.0), 26.0f, new float[]{0.0f, 1.0f}, new Color[]{color1, color2}));
        graphics2D.fill(generalPath);
        graphics2D.dispose();
        return HalloweenFx.finish("hw_pumpkin_" + n, bufferedImage, n, n, 0, false);
    }

    private static Handle lmbd$ghost$0(int n, int n2) {
        int n3 = n;
        int n4 = Math.round((float)n * 1.25f);
        int n5 = 2;
        BufferedImage bufferedImage = new BufferedImage(n3 * n5, n4 * n5, 2);
        Graphics2D graphics2D = HalloweenFx.g(bufferedImage);
        graphics2D.scale((double)(n3 * n5) / 100.0, (double)(n4 * n5) / 125.0);
        double d = (double)n2 * Math.PI * 2.0 / 8.0;
        Path2D.Double double_ = new Path2D.Double();
        ((Path2D)double_).moveTo(18.0, 58.0);
        ((Path2D)double_).curveTo(18.0, 22.0, 36.0, 8.0, 50.0, 8.0);
        ((Path2D)double_).curveTo(64.0, 8.0, 82.0, 22.0, 82.0, 58.0);
        ((Path2D)double_).curveTo(83.0, 76.0, 86.0 + 3.0 * Math.sin(d), 92.0, 88.0 + 2.0 * Math.sin(d + 0.5), 104.0);
        int n6 = 4;
        double d2 = 12.0 + 2.0 * Math.sin(d + 1.7);
        double d3 = 88.0 + 2.0 * Math.sin(d + 0.5);
        for (int i = n6; i > 0; --i) {
            double d4 = d2 + (d3 - d2) * (double)i / (double)n6;
            double d5 = d2 + (d3 - d2) * (double)(i - 1) / (double)n6;
            double d6 = (d4 + d5) / 2.0;
            double d7 = 9.0 + 5.0 * Math.sin(d * 1.0 + (double)i * 1.9);
            double d8 = 104.0 + 4.0 * Math.sin(d + (double)i * 1.3);
            double d9 = 104.0 + 4.0 * Math.sin(d + (double)(i - 1) * 1.3);
            ((Path2D)double_).curveTo(d4 - 3.0, d8 + d7, d6 + 3.0, (d8 + d9) / 2.0 + d7 + 6.0, d5, d9);
        }
        ((Path2D)double_).curveTo(14.0 + 2.0 * Math.sin(d + 2.1), 92.0, 17.0, 76.0, 18.0, 58.0);
        double_.closePath();
        graphics2D.setPaint(new GradientPaint(0.0f, 10.0f, new Color(255, 255, 255, 250), 0.0f, 122.0f, new Color(255, 255, 255, 40)));
        graphics2D.fill(double_);
        graphics2D.setColor(new Color(24, 10, 34, 235));
        graphics2D.fill(new Ellipse2D.Double(33.0, 36.0, 11.0, 15.0));
        graphics2D.fill(new Ellipse2D.Double(56.0, 36.0, 11.0, 15.0));
        graphics2D.fill(new Ellipse2D.Double(43.5, 57.0, 13.0, 10.0 + 3.0 * Math.sin(d * 2.0)));
        graphics2D.dispose();
        return HalloweenFx.finish("hw_ghost_" + n + "_" + n2, bufferedImage, n3, n4, 1, false);
    }
}
