package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.GuiWidgets;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;

final class Button
extends LinesWidth {
    private final ActionSetting button;
    private float press;

    Button(Module module, ActionSetting actionSetting) {
        super(module, actionSetting);
        this.button = actionSetting;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return squareCorners.textWidth("Run") + 18.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        this.press = Tween.approach(this.press, 0.0f, 8.0f, listeningModule.dt);
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        GuiWidgets.button(listeningModule.painter, f + f3 - 10.0f, f5, "Run", this.hover, this.press);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0) {
            return false;
        }
        this.press = 1.0f;
        listeningModule.host.sound("CONFIRM");
        this.button.run();
        return true;
    }
}
