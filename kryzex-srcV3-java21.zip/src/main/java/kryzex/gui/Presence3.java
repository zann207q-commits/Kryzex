package kryzex.gui;

final class Presence3 {
    String name;
    float presence;
    float x = Float.NaN;
    float y = Float.NaN;
    int index;
    boolean alive = true;
    boolean match = true;

    public Presence3() {
    }
}
