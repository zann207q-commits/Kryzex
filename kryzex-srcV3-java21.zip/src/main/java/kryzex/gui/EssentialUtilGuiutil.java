package kryzex.gui;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.minecraft.class_437;

public final class EssentialUtilGuiutil {
    private static final String ROOT = "gg.essential.";
    private static Object accountManager;

    private EssentialUtilGuiutil() {
    }

    private static Class<?> type(String string) throws ClassNotFoundException {
        return Class.forName(ROOT + string, true, EssentialUtilGuiutil.class.getClassLoader());
    }

    public static boolean available() {
        try {
            Class.forName("gg.essential.util.GuiUtil", false, EssentialUtilGuiutil.class.getClassLoader());
            return true;
        }
        catch (ClassNotFoundException | LinkageError throwable) {
            return false;
        }
    }

    public static boolean proxy(Object object) {
        return object.getClass().getName().startsWith("gg.essential.gui.proxies.");
    }

    public static void open(String string) throws ReflectiveOperationException {
        if (string.equals("account")) {
            EssentialUtilGuiutil.accounts();
            return;
        }
        if (string.equals("invite_host")) {
            EssentialUtilGuiutil.type("gui.sps.InviteOrHostModalFlowKt").getMethod("launchInviteOrHostModalFlow", new Class[0]).invoke(null, new Object[0]);
            return;
        }
        Object obj = switch (string) {
            case "social" -> EssentialUtilGuiutil.type("gui.friends.SocialMenu").getConstructor(new Class[0]).newInstance(new Object[0]);
            case "wardrobe" -> EssentialUtilGuiutil.type("gui.wardrobe.Wardrobe").getConstructor(new Class[0]).newInstance(new Object[0]);
            case "pictures" -> EssentialUtilGuiutil.type("gui.screenshot.components.ScreenshotBrowser").getConstructor(new Class[0]).newInstance(new Object[0]);
            case "settings" -> {
                Class<?> var4_3 = EssentialUtilGuiutil.type("config.McEssentialConfig");
                yield var4_3.getMethod("gui", new Class[0]).invoke(var4_3.getField("INSTANCE").get(null), new Object[0]);
            }
            default -> throw new IllegalArgumentException("Unknown Essential menu action: " + string);
        };
        Object object = EssentialUtilGuiutil.type("util.GuiUtil");
        ((Class)object).getMethod("openScreen", class_437.class).invoke(((Class)object).getField("INSTANCE").get(null), (class_437)obj);
    }

    private static void accounts() throws ReflectiveOperationException {
        Class<?> clazz = EssentialUtilGuiutil.type("util.GuiUtil");
        Class<?> clazz2 = EssentialUtilGuiutil.type("gui.menu.AccountManager");
        Class<?> clazz3 = EssentialUtilGuiutil.type("gui.overlay.ModalManager");
        Class<?> clazz4 = EssentialUtilGuiutil.type("gui.elementa.state.v2.State");
        if (accountManager == null) {
            accountManager = clazz2.getConstructor(new Class[0]).newInstance(new Object[0]);
        }
        Object object = clazz2.getMethod("getAllAccounts", new Class[0]).invoke(accountManager, new Object[0]);
        Constructor<?> constructor = EssentialUtilGuiutil.type("gui.menu.AccountManagerModal").getConstructor(clazz3, clazz2, clazz4);
        Class<?> clazz5 = Class.forName("kotlin.jvm.functions.Function1", true, clazz.getClassLoader());
        Object object2 = Proxy.newProxyInstance(clazz5.getClassLoader(), new Class[]{clazz5}, (arg_0, arg_1, arg_2) -> EssentialUtilGuiutil.lmbd$accounts$0(constructor, object, arg_0, arg_1, arg_2));
        clazz.getMethod("pushModal", clazz5).invoke(clazz.getField("INSTANCE").get(null), object2);
    }

    private static Object lmbd$accounts$0(Constructor constructor, Object object, Object object2, Method method, Object[] objectArray) throws Throwable {
        if (method.getName().equals("invoke")) {
            return constructor.newInstance(objectArray[0], accountManager, object);
        }
        if (method.getName().equals("toString")) {
            return "Kryzex Essential account dialog";
        }
        if (method.getName().equals("hashCode")) {
            return System.identityHashCode(object2);
        }
        if (!method.getName().equals("equals")) throw new UnsupportedOperationException(method.getName());
        return object2 == objectArray[0];
    }
}
