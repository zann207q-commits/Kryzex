package kryzex.gui;

@FunctionalInterface
interface IntSetter {
    public void on(int var1);
}
