package kryzex.gui;

@FunctionalInterface
interface FloatArrayGetter {
    public float[] get();
}
