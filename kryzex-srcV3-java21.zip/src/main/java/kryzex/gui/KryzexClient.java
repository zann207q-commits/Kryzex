package kryzex.gui;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.regex.Pattern;
import kryzex.gui.BaseRenderer;
import kryzex.gui.GuiRenderer;
import kryzex.gui.Hover;
import kryzex.gui.KryzexLoadingBrand;
import kryzex.gui.KryzexMenuVideo;
import kryzex.gui.MenuPlaydemo;
import kryzex.gui.Muted;
import kryzex.gui.MainMenuScene;
import kryzex.gui.SpeakerOff;
import kryzex.gui.ScreenFilter;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_357;
import net.minecraft.class_3928;
import net.minecraft.class_408;
import net.minecraft.class_412;
import net.minecraft.class_424;
import net.minecraft.class_425;
import net.minecraft.class_4286;
import net.minecraft.class_435;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_5481;
import net.minecraft.class_8021;
import net.minecraft.class_8671;

public final class KryzexClient {
    private static final Pattern BRAND = Pattern.compile("(?i)\\b(?:minecraft|mojang(?: studios)?)\\b");
    private static final Map<Object, Hover> MOTION = Collections.synchronizedMap(new WeakHashMap());
    private static final ThreadLocal<Integer> EDIT = ThreadLocal.withInitial(KryzexClient::lmbd$static$0);
    private static final long START = System.nanoTime();
    private static boolean wasMenu;

    private KryzexClient() {
    }

    public static String brand(String string) {
        if (string == null) {
            return "";
        }
        String string2 = BRAND.matcher(string).replaceAll("Kryzex Client");
        return string2;
    }

    public static boolean supports(String string) {
        if (string == null) return false;
        if (!string.codePoints().allMatch(KryzexClient::lmbd$supports$0)) return false;
        return true;
    }

    public static boolean supports(class_5481 class_54812) {
        if (class_54812 == null) {
            return false;
        }
        boolean[] blArray = new boolean[]{true};
        class_54812.accept((arg_0, arg_1, arg_2) -> KryzexClient.lmbd$supports$1(blArray, arg_0, arg_1, arg_2));
        return blArray[0];
    }

    public static boolean supports(class_2561 class_25612) {
        if (class_25612 == null) return false;
        if (!KryzexClient.supports(class_25612.method_30937())) return false;
        return true;
    }

    public static boolean themed(class_437 class_4372) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null) {
            return false;
        }
        if (class_4372 == null || class_4372 instanceof class_408 || class_4372 instanceof class_465) {
            return false;
        }
        String string = class_4372.getClass().getName();
        return ScreenFilter.allows(class_3102.field_1687 != null, class_3102.method_1562() != null, class_4372 instanceof MenuPlaydemo, string);
    }

    public static boolean active() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null) return false;
        if (!KryzexClient.themed(class_3102.field_1755)) return false;
        if (class_3102.field_1755 instanceof MenuPlaydemo) return false;
        return true;
    }

    public static boolean typography() {
        if (!KryzexClient.active()) return false;
        if (EDIT.get() != 0) return false;
        return true;
    }

    public static boolean loading(class_437 class_4372) {
        if (class_4372 instanceof class_435) return true;
        if (class_4372 instanceof class_3928) return true;
        if (class_4372 instanceof class_412) return true;
        if (class_4372 instanceof class_424) return true;
        if (!(class_4372 instanceof class_8671)) return false;
        return true;
    }

    public static boolean backdrop() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null) return false;
        if (class_3102.field_1687 != null) return false;
        if (!KryzexClient.active()) return false;
        return true;
    }

    public static void editing(boolean bl) {
        EDIT.set(Math.max(0, EDIT.get() + (bl ? 1 : -1)));
    }

    public static void tick(class_310 class_3102) {
        boolean bl = class_3102.field_1687 == null;
        KryzexMenuVideo.setWanted(bl && !(class_3102.method_18506() instanceof class_425) && !KryzexClient.loading(class_3102.field_1755));
        if (bl && Muted.enabled()) {
            class_3102.method_1538().method_4859();
        }
        if (wasMenu && !bl) {
            MainMenuScene.release();
        }
        wasMenu = bl;
    }

    public static void background(class_332 class_3322) {
        BaseRenderer baseRenderer;
        EDIT.set(0);
        class_310 class_3102 = class_310.method_1551();
        int n = class_3102.method_22683().method_4489();
        int n2 = class_3102.method_22683().method_4506();
        KryzexMenuVideo.setWanted(true);
        if (!MainMenuScene.backdrop(n, n2, (float)(System.nanoTime() - START) / 1.0E9f)) {
            baseRenderer = KryzexClient.paint(class_3322);
            baseRenderer.rect(0.0f, 0.0f, class_3322.method_51421(), class_3322.method_51443(), -14671063);
        }
        baseRenderer = KryzexClient.paint(class_3322);
        float f = Math.min(105.0f, (float)class_3322.method_51421() * 0.18f);
        baseRenderer.texture(KryzexLoadingBrand.logo(), 10.0f, 4.0f, f, f / 6.0f, -571542790);
    }

    public static BaseRenderer paint(class_332 class_3322) {
        return new GuiRenderer(class_3322, class_310.method_1551().method_22683().method_4495());
    }

    public static void label(BaseRenderer baseRenderer, String string, float f, float f2, float f3, int n, boolean bl) {
        baseRenderer.text(KryzexClient.brand(string), f, f2, f3, bl ? 1 : 0, n);
    }

    public static void centered(BaseRenderer baseRenderer, String string, float f, float f2, float f3, int n, boolean bl) {
        String string2 = KryzexClient.brand(string);
        int n2 = bl ? 1 : 0;
        baseRenderer.text(string2, f - baseRenderer.textWidth(string2, f3, n2) / 2.0f, f2, f3, n2, n);
    }

    public static float hover(Object object, boolean bl) {
        Hover hover = MOTION.computeIfAbsent(object, KryzexClient::lmbd$hover$0);
        long l = System.nanoTime();
        float f = Math.min(0.1f, (float)(l - hover.last) / 1.0E9f);
        hover.last = l;
        hover.hover = hover.hover + ((float)(bl ? (char)'\u0001' : '\u0000') - hover.hover) * (1.0f - (float)Math.exp(-13.0f * f));
        return hover.hover;
    }

    public static void glass(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, boolean bl) {
        float f6 = Math.min(7.0f, f4 * 0.43f);
        baseRenderer.round(f, f2 + 1.0f, f3, f4, f6, 0x25000000);
        baseRenderer.round(f, f2, f3, f4, f6, BaseRenderer.argb(0.24f + 0.1f * f5 + (bl ? 0.08f : 0.0f), 80, 86, 98));
        baseRenderer.outline(f, f2, f3, f4, f6, 0.65f, BaseRenderer.argb(0.17f + 0.18f * f5, 235, 242, 255));
        baseRenderer.round(f + Math.min(6.0f, f3 * 0.1f), f2 + 0.7f, Math.max(0.0f, f3 - Math.min(12.0f, f3 * 0.2f)), 0.7f, 0.35f, BaseRenderer.argb(0.1f + 0.1f * f5, 255, 255, 255));
    }

    public static boolean button(class_332 class_3322, class_339 class_3392) {
        if (!KryzexClient.active()) return false;
        if (!KryzexClient.supports(class_3392.method_25369().getString())) return false;
        if (class_3392.method_25369().getString().isEmpty()) return false;
        boolean bl = KryzexClient.button(KryzexClient.paint(class_3322), class_3392);
        return bl;
    }

    public static boolean button(BaseRenderer baseRenderer, class_339 class_3392) {
        if (class_3392.method_25369().getString().isEmpty()) {
            return false;
        }
        float f = KryzexClient.hover(class_3392, class_3392.field_22763 && class_3392.method_25367());
        baseRenderer.pushAlpha(class_3392.method_75798());
        try {
            if (class_3392 instanceof class_4286) {
                class_4286 class_42862 = (class_4286)class_3392;
                float f2 = Math.min(15, class_3392.method_25364() - 2);
                KryzexClient.glass(baseRenderer, class_3392.method_46426(), class_3392.method_46427() + 1, f2, f2, f, class_42862.method_20372());
                if (class_42862.method_20372()) {
                    baseRenderer.icon(SpeakerOff.CHECK, class_3392.method_46426() + 2, class_3392.method_46427() + 3, f2 - 4.0f, -657412);
                }
                KryzexClient.label(baseRenderer, class_3392.method_25369().getString(), (float)class_3392.method_46426() + f2 + 5.0f, (float)class_3392.method_46427() + Math.max(0.0f, (float)(class_3392.method_25364() - 10) / 2.0f), 9.5f, class_3392.field_22763 ? -986119 : -2133468443, false);
                return true;
            } else {
                KryzexClient.glass(baseRenderer, class_3392.method_46426(), class_3392.method_46427(), class_3392.method_25368(), class_3392.method_25364(), f, false);
                String string = KryzexClient.brand(class_3392.method_25369().getString());
                float f3 = Math.min(10.25f, (float)class_3392.method_25364() * 0.47f);
                string = baseRenderer.ellipsize(string, Math.max(1, class_3392.method_25368() - 12), f3, 0);
                KryzexClient.centered(baseRenderer, string, (float)class_3392.method_46426() + (float)class_3392.method_25368() / 2.0f, (float)class_3392.method_46427() + ((float)class_3392.method_25364() - f3) / 2.0f - f * 0.35f, f3, class_3392.field_22763 ? -788998 : -2134125857, false);
            }
            return true;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    public static void slider(class_332 class_3322, class_357 class_3572, double d) {
        KryzexClient.slider(KryzexClient.paint(class_3322), class_3572, d);
    }

    public static void slider(BaseRenderer baseRenderer, class_357 class_3572, double d) {
        float f = KryzexClient.hover(class_3572, class_3572.field_22763 && class_3572.method_25367());
        baseRenderer.pushAlpha(class_3572.method_75798());
        try {
            KryzexClient.glass(baseRenderer, class_3572.method_46426(), class_3572.method_46427(), class_3572.method_25368(), class_3572.method_25364(), f, false);
            float f2 = class_3572.method_46426() + 8;
            float f3 = class_3572.method_46427() + class_3572.method_25364() - 4;
            float f4 = Math.max(1, class_3572.method_25368() - 16);
            float f5 = (float)Math.clamp(d, 0.0, 1.0);
            baseRenderer.round(f2, f3, f4, 1.5f, 0.75f, 0x44FFFFFF);
            baseRenderer.round(f2, f3, f4 * f5, 1.5f, 0.75f, -857149703);
            baseRenderer.circle(f2 + f4 * f5, f3 + 0.75f, 2.6f, -657409);
            String string = baseRenderer.ellipsize(KryzexClient.brand(class_3572.method_25369().getString()), Math.max(1, class_3572.method_25368() - 12), 9.0f, 0);
            KryzexClient.centered(baseRenderer, string, (float)class_3572.method_46426() + (float)class_3572.method_25368() / 2.0f, class_3572.method_46427() + 2, 9.0f, class_3572.field_22763 ? -854532 : -2134125857, false);
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    public static void list(class_332 class_3322, class_339 class_3392) {
        BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
        KryzexClient.glass(baseRenderer, class_3392.method_46426() + 1, class_3392.method_46427(), Math.max(1, class_3392.method_25368() - 2), class_3392.method_25364(), 0.0f, false);
    }

    public static void selection(class_332 class_3322, class_8021 class_80212) {
        BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
        KryzexClient.glass(baseRenderer, class_80212.method_46426(), class_80212.method_46427(), class_80212.method_25368(), class_80212.method_25364(), 0.45f, true);
    }

    public static void text(class_332 class_3322, String string, int n, int n2, int n3, boolean bl) {
        BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
        if (bl) {
            KryzexClient.centered(baseRenderer, string, n, n2, 10.0f, n3, false);
            return;
        } else {
            KryzexClient.label(baseRenderer, string, n, n2, 9.5f, n3, false);
        }
    }

    public static void text(class_332 class_3322, class_5481 class_54812, int n, int n2, int n3, boolean bl) {
        if (bl) {
            StringBuilder stringBuilder = new StringBuilder();
            class_54812.accept((arg_0, arg_1, arg_2) -> KryzexClient.lmbd$text$0(stringBuilder, arg_0, arg_1, arg_2));
            KryzexClient.text(class_3322, stringBuilder.toString(), n, n2, n3, true);
            return;
        } else {
            BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
            float[] fArray = new float[]{n};
            StringBuilder stringBuilder = new StringBuilder();
            int[] nArray = new int[]{n3};
            boolean[] blArray = new boolean[]{false};
            Runnable runnable = () -> KryzexClient.lmbd$text$1(stringBuilder, fArray, baseRenderer, n2, blArray, nArray);
            class_54812.accept((arg_0, arg_1, arg_2) -> KryzexClient.lmbd$text$2(n3, nArray, blArray, runnable, stringBuilder, arg_0, arg_1, arg_2));
            runnable.run();
        }
    }

    private static boolean lmbd$text$2(int n, int[] nArray, boolean[] blArray, Runnable runnable, StringBuilder stringBuilder, int n2, class_2583 class_25832, int n3) {
        int n4;
        int n5 = n4 = class_25832.method_10973() == null ? n : n & 0xFF000000 | class_25832.method_10973().method_27716();
        if (n4 != nArray[0] || class_25832.method_10984() != blArray[0]) {
            runnable.run();
            nArray[0] = n4;
            blArray[0] = class_25832.method_10984();
        }
        stringBuilder.appendCodePoint(n3);
        return true;
    }

    private static void lmbd$text$1(StringBuilder stringBuilder, float[] fArray, BaseRenderer baseRenderer, int n, boolean[] blArray, int[] nArray) {
        if (stringBuilder.length() <= 0) return;
        String string = KryzexClient.brand(stringBuilder.toString());
        fArray[0] = fArray[0] + baseRenderer.text(string, fArray[0], n, 9.5f, blArray[0] ? 1 : 0, nArray[0]);
        stringBuilder.setLength(0);
    }

    private static boolean lmbd$text$0(StringBuilder stringBuilder, int n, class_2583 class_25832, int n2) {
        stringBuilder.appendCodePoint(n2);
        return true;
    }

    private static Hover lmbd$hover$0(Object object) {
        return new Hover();
    }

    private static boolean lmbd$supports$1(boolean[] blArray, int n, class_2583 class_25832, int n2) {
        blArray[0] = blArray[0] & (class_11719.field_61972.equals((Object)class_25832.method_27708()) && !class_25832.method_10987() && !class_25832.method_10966() && !class_25832.method_10965() && !class_25832.method_10986() && (n2 >= 32 && n2 <= 126 || "\u2022\u2026\u00b7\u2014\u2013\u00b0\u00d7\u2190\u2192\u2713\u00a7\u00e9\u00e8\u00e0\u00e7\u00f1\u00fc\u00f6\u00e4\u00df".indexOf(n2) >= 0));
        return true;
    }

    private static boolean lmbd$supports$0(int n) {
        if (n >= 32) {
            if (n <= 126) return true;
        }
        if ("\u2022\u2026\u00b7\u2014\u2013\u00b0\u00d7\u2190\u2192\u2713\u00a7\u00e9\u00e8\u00e0\u00e7\u00f1\u00fc\u00f6\u00e4\u00df".indexOf(n) < 0) return false;
        return true;
    }

    private static Integer lmbd$static$0() {
        return 0;
    }
}
