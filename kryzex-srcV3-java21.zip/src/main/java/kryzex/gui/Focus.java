package kryzex.gui;

import kryzex.gui.Tween;
import kryzex.gui.LastSource;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;

final class Focus
extends LinesWidth {
    private final StringSetting text;
    private float focus;

    Focus(Module module, StringSetting stringSetting) {
        super(module, (Setting)((Object)stringSetting));
        this.text = stringSetting;
    }

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return 96.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        SquareCorners squareCorners = listeningModule.painter;
        boolean bl = listeningModule.editing == this.text;
        this.focus = Tween.approach(this.focus, bl ? 1.0f : 0.0f, 14.0f, listeningModule.dt);
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        float f6 = f + f3 - 10.0f;
        float f7 = f6 - 96.0f;
        float f8 = f5 - 11.5f;
        float f9 = f5 + 11.5f;
        squareCorners.roundRect(f7, f8, f6, f9, 4.0f, LastSource.mix(0x47000000, 0x5A000000, this.hover * 0.5f));
        squareCorners.stroke(f7, f8, f6, f9, 4.0f, 1.0f, LastSource.mix(LastSource.mix(0xEFFFFFF, 0x1CFFFFFF, this.hover), LastSource.withAlpha(LastSource.SWITCH_ON, 0.45f), this.focus));
        String string = this.text.getValue() == null ? "" : this.text.getValue();
        float f10 = 84.0f;
        String string2 = string;
        while (string2.length() > 1 && squareCorners.textWidth(string2) > f10) {
            string2 = bl ? string2.substring(1) : string2.substring(0, string2.length() - 1);
        }
        squareCorners.text(string2, f7 + 6.0f, f5, bl ? -723976 : LastSource.VALUE);
        if (!bl || !(listeningModule.caretTime % 1.0f < 0.55f)) return;
        float f11 = f7 + 6.0f + squareCorners.textWidth(string2) + 1.0f;
        squareCorners.rect(f11, f5 - 6.0f, f11 + 1.2f, f5 + 6.0f, LastSource.withAlpha(-723976, 0.8f));
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        listeningModule.editing = listeningModule.editing == this.text ? null : this.text;
        listeningModule.caretTime = 0.0f;
        listeningModule.searchFocused = false;
        return true;
    }
}
