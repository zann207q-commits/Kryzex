package kryzex.gui;

import kryzex.gui.GuiSoundType;
import kryzex.gui.ModuleWAV;

final class SoundBank {
    private SoundBank() {
    }

    static float[][] bank() {
        float[][] fArrayArray = new float[GuiSoundType.values().length][];
        fArrayArray[GuiSoundType.TICK.ordinal()] = SoundBank.finish(SoundBank.tick(), 0.15f);
        fArrayArray[GuiSoundType.SLIDE.ordinal()] = SoundBank.finish(SoundBank.slide(), 0.07f);
        fArrayArray[GuiSoundType.TAB.ordinal()] = SoundBank.finish(SoundBank.seq(0.2f,new float[]{784.0f, 0.0f, 0.09f, 1.0f},new float[]{1174.7f, 0.0f, 0.06f, 0.22f}), 0.17f);
        fArrayArray[GuiSoundType.ON.ordinal()] = SoundBank.finish(SoundBank.seq(0.3f,new float[]{659.3f, 0.0f, 0.14f, 1.0f},new float[]{987.8f, 0.055f, 0.18f, 0.9f}), 0.19f);
        fArrayArray[GuiSoundType.OFF.ordinal()] = SoundBank.finish(SoundBank.seq(0.28f,new float[]{880.0f, 0.0f, 0.11f, 0.85f},new float[]{659.3f, 0.05f, 0.15f, 1.0f}), 0.16f);
        fArrayArray[GuiSoundType.OPEN.ordinal()] = SoundBank.finish(SoundBank.add(SoundBank.swoosh(380.0f, 2400.0f, 0.17f, 0.5f), SoundBank.seq(0.32f, new float[][]{{1108.7f, 0.06f, 0.16f, 1.0f}})), 0.16f);
        fArrayArray[GuiSoundType.BACK.ordinal()] = SoundBank.finish(SoundBank.add(SoundBank.swoosh(2200.0f, 420.0f, 0.15f, 0.45f), SoundBank.seq(0.26f, new float[][]{{830.6f, 0.035f, 0.12f, 1.0f}})), 0.14f);
        fArrayArray[GuiSoundType.CONFIRM.ordinal()] = SoundBank.finish(SoundBank.seq(0.32f,new float[]{987.8f, 0.0f, 0.16f, 1.0f},new float[]{1318.5f, 0.012f, 0.16f, 0.7f}), 0.17f);
        fArrayArray[GuiSoundType.THEME.ordinal()] = SoundBank.finish(SoundBank.seq(0.55f,new float[]{659.3f, 0.0f, 0.26f, 1.0f},new float[]{830.6f, 0.05f, 0.26f, 0.9f},new float[]{987.8f, 0.1f, 0.26f, 0.85f},new float[]{1318.5f, 0.15f, 0.3f, 0.7f}), 0.19f);
        fArrayArray[GuiSoundType.GUI_OPEN.ordinal()] = SoundBank.finish(SoundBank.pad(new float[]{329.6f, 493.9f, 659.3f, 1318.5f}, new float[]{0.9f, 0.7f, 0.55f, 0.16f}, 0.06f, 0.5f), 0.15f);
        fArrayArray[GuiSoundType.GUI_CLOSE.ordinal()] = SoundBank.finish(SoundBank.seq(0.45f,new float[]{493.9f, 0.0f, 0.22f, 0.9f},new float[]{329.6f, 0.07f, 0.3f, 1.0f}), 0.12f);
        return ModuleWAV.apply(fArrayArray);
    }

    private static float[] buf(float f) {
        return new float[Math.round(f * 44100.0f)];
    }

    private static void note(float[] fArray, float f, float f2, float f3, float f4, float f5) {
        double d;
        double d2;
        int n = Math.round(f2 * 44100.0f);
        double d3 = Math.PI * 2 * (double)f / 44100.0;
        int n2 = 0;
        while (!(n + n2 >= fArray.length || (d2 = (1.0 - Math.exp(-(d = (double)n2 / 44100.0) / (double)f5)) * Math.exp(-d / (double)f3)) < 1.0E-5 && d > (double)f5 * 4.0)) {
            double d4 = Math.sin(d3 * (double)n2) + 0.16 * Math.sin(2.0 * d3 * (double)n2) * Math.exp(-d / ((double)f3 * 0.45)) + 0.05 * Math.sin(3.0 * d3 * (double)n2) * Math.exp(-d / ((double)f3 * 0.3)) + 0.1 * Math.sin(0.5 * d3 * (double)n2);
            fArray[n + n2] = fArray[n + n2] + (float)((double)f4 * d2 * d4);
            ++n2;
        }
    }

    private static float[] seq(float f, float[] ... fArray) {
        float[] fArray2 = SoundBank.buf(f);
        for (float[] fArray3 : fArray) {
            SoundBank.note(fArray2, fArray3[0], fArray3[1], fArray3[2], fArray3[3], 0.004f);
        }
        return fArray2;
    }

    private static float[] pad(float[] fArray, float[] fArray2, float f, float f2) {
        float[] fArray3 = SoundBank.buf(1.1f);
        for (int i = 0; i < fArray.length; ++i) {
            SoundBank.note(fArray3, fArray[i], 0.0f, f2, fArray2[i], f);
        }
        return fArray3;
    }

    private static float[] tick() {
        float[] fArray = SoundBank.buf(0.12f);
        SoundBank.note(fArray, 1046.5f, 0.0f, 0.035f, 1.0f, 0.0025f);
        long l = 1234567L;
        float f = 0.0f;
        int n = 0;
        while ((float)n < 264.6f) {
            l = l * 6364136223846793005L + 1442695040888963407L;
            float f2 = (float)(l >>> 40) / 8388608.0f - 1.0f;
            f += 0.25f * (f2 - f);
            int n2 = n;
            fArray[n2] = fArray[n2] + f * 0.25f * (1.0f - (float)n / 264.6f);
            ++n;
        }
        return fArray;
    }

    private static float[] slide() {
        float[] fArray = SoundBank.buf(0.05f);
        SoundBank.note(fArray, 1568.0f, 0.0f, 0.012f, 1.0f, 0.0015f);
        return fArray;
    }

    private static float[] swoosh(float f, float f2, float f3, float f4) {
        float[] fArray = SoundBank.buf(f3 + 0.05f);
        long l = 987654321L;
        float f5 = 0.0f;
        float f6 = 0.0f;
        int n = Math.round(f3 * 44100.0f);
        int n2 = 0;
        while (n2 < n) {
            float f7 = (float)n2 / (float)n;
            float f8 = (float)((double)f * Math.pow(f2 / f, f7));
            float f9 = (float)(2.0 * Math.sin(Math.PI * (double)f8 / 44100.0));
            l = l * 6364136223846793005L + 1442695040888963407L;
            float f10 = (float)(l >>> 40) / 8388608.0f - 1.0f;
            float f11 = f10 - (f5 += f9 * f6) - 0.7f * f6;
            float f12 = (float)Math.pow(Math.sin(Math.PI * (double)f7), 2.0);
            int n3 = n2++;
            fArray[n3] = fArray[n3] + (f6 += f9 * f11) * f12 * f4;
        }
        return fArray;
    }

    private static float[] add(float[] fArray, float[] fArray2) {
        int n;
        float[] fArray3 = new float[Math.max(fArray.length, fArray2.length)];
        for (n = 0; n < fArray.length; ++n) {
            int n2 = n;
            fArray3[n2] = fArray3[n2] + fArray[n];
        }
        for (n = 0; n < fArray2.length; ++n) {
            int n3 = n;
            fArray3[n3] = fArray3[n3] + fArray2[n];
        }
        return fArray3;
    }

    private static float[] finish(float[] fArray, float f) {
        float f2 = 1.0E-6f;
        for (float f3 : fArray) {
            f2 = Math.max(f2, Math.abs(f3));
        }
        float f4 = f / f2;
        int n = Math.round(30870.0f);
        int n2 = fArray.length + n;
        float[] fArray2 = new float[n2];
        for (int i = 0; i < fArray.length; ++i) {
            fArray2[i] = fArray[i] * f4;
        }
        float[] fArray3 = SoundBank.room(fArray2, new int[]{1116, 1188, 1277, 1356}, new int[]{556, 441});
        float[] fArray4 = SoundBank.room(fArray2, new int[]{1139, 1211, 1300, 1379}, new int[]{579, 464});
        float[] fArray5 = new float[n2 * 2];
        int n3 = Math.round(3528.0f);
        for (int i = 0; i < n2; ++i) {
            float f5 = i > n2 - n3 ? (float)(n2 - i) / (float)n3 : 1.0f;
            fArray5[i * 2] = (fArray2[i] * 0.86f + fArray3[i] * 0.22f) * f5;
            fArray5[i * 2 + 1] = (fArray2[i] * 0.86f + fArray4[i] * 0.22f) * f5;
        }
        return fArray5;
    }

    private static float[] room(float[] fArray, int[] nArray, int[] nArray2) {
        float f;
        int n;
        float[] fArray2;
        float[] fArray3 = new float[fArray.length];
        for (int n2 : nArray) {
            fArray2 = new float[n2];
            n = 0;
            float f2 = 0.0f;
            int n3 = 0;
            while (n3 < fArray.length) {
                f = fArray2[n];
                f2 = f * 0.62f + f2 * 0.38f;
                fArray2[n] = fArray[n3] + f2 * 0.74f;
                n = (n + 1) % n2;
                int n4 = n3++;
                fArray3[n4] = fArray3[n4] + f * 0.25f;
            }
        }
        for (int n2 : nArray2) {
            fArray2 = new float[n2];
            n = 0;
            for (int i = 0; i < fArray3.length; ++i) {
                float f3 = fArray2[n];
                f = fArray3[i];
                fArray2[n] = f + f3 * 0.5f;
                fArray3[i] = f3 - f;
                n = (n + 1) % n2;
            }
        }
        return fArray3;
    }
}
