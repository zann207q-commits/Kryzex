package kryzex.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.util.Arrays;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2fc;

final class Pipeline
implements class_11244 {
    private final RenderPipeline pipeline;
    private final class_11231 texture;
    private final class_8030 clip;
    private float[] xyuv = new float[256];
    private int[] colors = new int[64];
    private int vertices;
    private int left = Integer.MAX_VALUE;
    private int top = Integer.MAX_VALUE;
    private int right = Integer.MIN_VALUE;
    private int bottom = Integer.MIN_VALUE;

    Pipeline(RenderPipeline renderPipeline, class_11231 class_112312, class_8030 class_80302) {
        this.pipeline = renderPipeline;
        this.texture = class_112312;
        this.clip = class_80302;
    }

    boolean append(Matrix3x2fc matrix3x2fc, int n, int n2, int n3, int n4, float f, float f2, float f3, float f4, int n5, int n6) {
        float f5 = matrix3x2fc.m00() * (float)n + matrix3x2fc.m10() * (float)n2 + matrix3x2fc.m20();
        float f6 = matrix3x2fc.m01() * (float)n + matrix3x2fc.m11() * (float)n2 + matrix3x2fc.m21();
        float f7 = matrix3x2fc.m00() * (float)n + matrix3x2fc.m10() * (float)n4 + matrix3x2fc.m20();
        float f8 = matrix3x2fc.m01() * (float)n + matrix3x2fc.m11() * (float)n4 + matrix3x2fc.m21();
        float f9 = matrix3x2fc.m00() * (float)n3 + matrix3x2fc.m10() * (float)n4 + matrix3x2fc.m20();
        float f10 = matrix3x2fc.m01() * (float)n3 + matrix3x2fc.m11() * (float)n4 + matrix3x2fc.m21();
        float f11 = matrix3x2fc.m00() * (float)n3 + matrix3x2fc.m10() * (float)n2 + matrix3x2fc.m20();
        float f12 = matrix3x2fc.m01() * (float)n3 + matrix3x2fc.m11() * (float)n2 + matrix3x2fc.m21();
        int n7 = (int)Math.floor(Math.min(Math.min(f5, f7), Math.min(f9, f11)));
        int n8 = (int)Math.floor(Math.min(Math.min(f6, f8), Math.min(f10, f12)));
        int n9 = (int)Math.ceil(Math.max(Math.max(f5, f7), Math.max(f9, f11)));
        int n10 = (int)Math.ceil(Math.max(Math.max(f6, f8), Math.max(f10, f12)));
        if (this.clip != null && (n9 <= this.clip.method_49620() || n7 >= this.clip.method_49621() || n10 <= this.clip.method_49618() || n8 >= this.clip.method_49619())) {
            return false;
        }
        if (this.vertices + 4 > this.colors.length) {
            this.colors = Arrays.copyOf(this.colors, this.colors.length * 2);
            this.xyuv = Arrays.copyOf(this.xyuv, this.xyuv.length * 2);
        }
        this.vertex(f5, f6, f, f2, n5);
        this.vertex(f7, f8, f, f4, n6);
        this.vertex(f9, f10, f3, f4, n6);
        this.vertex(f11, f12, f3, f2, n5);
        this.left = Math.min(this.left, n7);
        this.top = Math.min(this.top, n8);
        this.right = Math.max(this.right, n9);
        this.bottom = Math.max(this.bottom, n10);
        return true;
    }

    private void vertex(float f, float f2, float f3, float f4, int n) {
        int n2 = this.vertices * 4;
        this.xyuv[n2] = f;
        this.xyuv[n2 + 1] = f2;
        this.xyuv[n2 + 2] = f3;
        this.xyuv[n2 + 3] = f4;
        this.colors[this.vertices++] = n;
    }

    public void method_70917(class_4588 class_45882) {
        for (int i = 0; i < this.vertices; ++i) {
            int n = i * 4;
            class_4588 class_45883 = class_45882.method_22912(this.xyuv[n], this.xyuv[n + 1], 0.0f);
            if (this.pipeline != class_10799.field_56879) {
                class_45883.method_22913(this.xyuv[n + 2], this.xyuv[n + 3]);
            }
            class_45883.method_39415(this.colors[i]);
        }
    }

    public RenderPipeline comp_4055() {
        return this.pipeline;
    }

    public class_11231 comp_4056() {
        return this.texture;
    }

    public class_8030 comp_4069() {
        return this.clip;
    }

    public class_8030 comp_4274() {
        class_8030 class_80302 = new class_8030(this.left, this.top, this.right - this.left, this.bottom - this.top);
        return this.clip == null ? class_80302 : class_80302.method_49701(this.clip);
    }
}
