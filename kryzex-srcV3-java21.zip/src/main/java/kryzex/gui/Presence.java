package kryzex.gui;

final class Presence {
    float y = Float.NaN;
    float presence;
    float target;
    int index;
    boolean active;

    public Presence() {
    }
}
