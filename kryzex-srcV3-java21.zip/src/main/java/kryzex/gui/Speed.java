package kryzex.gui;

final class Speed {
    float x;
    float y;
    float speed;
    float size;
    float phase;
    float age;
    int dir;

    public Speed() {
    }
}
