package kryzex.gui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.CompiledRenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.ShaderType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_10789;
import net.minecraft.class_12289;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public final class DropdownBlur {
    private static final class_2960 UI_SHADER = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/dd_ui");
    private static final class_2960 QUAD = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/dd_quad");
    private static final class_2960 DOWN = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/dd_kawase_down");
    private static final class_2960 UP = class_2960.method_60655((String)"r87f4560b4c09f4", (String)"core/dd_kawase_up");
    private static final Map<RenderPipeline, Boolean> LOGGED = new IdentityHashMap<RenderPipeline, Boolean>();
    public static final RenderPipeline UI = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/dd_ui")).withVertexShader(UI_SHADER).withFragmentShader(UI_SHADER).withUniform("DynamicTransforms", class_10789.field_60031).withUniform("Projection", class_10789.field_60031).withUniform("Globals", class_10789.field_60031).withSampler("Sampler0").withSampler("Sampler1").withBlend(BlendFunction.TRANSLUCENT).withVertexFormat(class_290.field_1580, VertexFormat.class_5596.field_27382).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
    public static final RenderPipeline BLUR_DOWN = DropdownBlur.fullscreen("dd_blur_down", DOWN);
    public static final RenderPipeline BLUR_UP = DropdownBlur.fullscreen("dd_blur_up", UP);
    private static final String UI_VSH = "#version 330\n\nlayout(std140) uniform DynamicTransforms {\n    mat4 ModelViewMat;\n    vec4 ColorModulator;\n    vec3 ModelOffset;\n    mat4 TextureMat;\n};\nlayout(std140) uniform Projection {\n    mat4 ProjMat;\n};\n\nin vec3 Position;\nin vec4 Color;\nin vec2 UV0;\nin ivec2 UV1;\nin ivec2 UV2;\nin vec3 Normal;\n\nout vec4 vertexColor;\nout vec2 texCoord;\nflat out ivec2 shapeParams;\nflat out vec2 clipRows;\nflat out vec2 halfSize;\nflat out float opacity;\nflat out float uiScale;\nflat out int squareCorners;\nflat out int seamless;\n\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n    vertexColor = Color;\n\n    texCoord = UV0;\n    shapeParams = UV2;\n\n    clipRows = vec2(UV1);\n    opacity = Normal.x;\n    uiScale = Normal.y * 4.0;\n\n    int shapeFlags = int(Normal.z * 63.0 + 0.5);\n    squareCorners = shapeFlags & 15;\n\n    seamless = shapeFlags >> 4;\n\n    float softness = float((UV2.x >> 4) & 2047) / 8.0;\n    halfSize = abs(UV0) - vec2(softness + 1.0);\n}\n";
    private static final String UI_FSH = "#version 330\n\nlayout(std140) uniform DynamicTransforms {\n    mat4 ModelViewMat;\n    vec4 ColorModulator;\n    vec3 ModelOffset;\n    mat4 TextureMat;\n};\nlayout(std140) uniform Globals {\n    ivec3 CameraBlockPos;\n    vec3 CameraOffset;\n    vec2 ScreenSize;\n    float GlintAlpha;\n    float GameTime;\n    int MenuBlurRadius;\n    int UseRgss;\n};\n\n\nuniform sampler2D Sampler0;\nuniform sampler2D Sampler1;\n\nin vec4 vertexColor;\nin vec2 texCoord;\nflat in ivec2 shapeParams;\nflat in vec2 clipRows;\nflat in vec2 halfSize;\nflat in float opacity;\nflat in float uiScale;\nflat in int squareCorners;\nflat in int seamless;\n\nout vec4 fragColor;\n\nconst int MODE_RECT = 0;\nconst int MODE_CIRCLE = 1;\nconst int MODE_GLASS = 2;\nconst int MODE_TEXTURE = 3;\nconst int MODE_STROKE = 4;\n\nfloat roundBox(vec2 p, vec2 b, float r) {\n    int quadrant = (p.x < 0.0 ? 0 : 1) + (p.y < 0.0 ? 0 : 2);\n    if (((squareCorners >> quadrant) & 1) != 0) {\n        r = 0.0;\n    }\n    r = min(r, min(b.x, b.y));\n    vec2 q = abs(p) - b + r;\n    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;\n}\n\nfloat coverage(float d) {\n    return clamp(0.5 - d / max(fwidth(d), 1e-4), 0.0, 1.0);\n}\n\nvec4 glass(vec2 p, float radius) {\n    float k = max(uiScale, 0.5);\n    float d = roundBox(p, halfSize, radius);\n\n    float extendTop = (seamless & 1) != 0 ? 4096.0 : 0.0;\n    float extendBottom = (seamless & 2) != 0 ? 4096.0 : 0.0;\n    vec2 ep = vec2(p.x, p.y + (extendTop - extendBottom) * 0.5);\n    vec2 eb = vec2(halfSize.x, halfSize.y + (extendTop + extendBottom) * 0.5);\n    float de = roundBox(ep, eb, radius);\n    float inside = -de;\n\n    vec2 e = vec2(0.5, 0.0);\n    vec2 n = vec2(roundBox(ep + e.xy, eb, radius) - roundBox(ep - e.xy, eb, radius),\n                  roundBox(ep + e.yx, eb, radius) - roundBox(ep - e.yx, eb, radius));\n    n = n / max(length(n), 1e-4);\n    float rim = 1.0 - smoothstep(0.0, 9.0 * k, inside);\n    vec2 offset = vec2(n.x, -n.y) * rim * rim * 3.5 * k;\n    vec3 backdrop = texture(Sampler0, (gl_FragCoord.xy - offset) / ScreenSize).rgb;\n    float luma = dot(backdrop, vec3(0.2126, 0.7152, 0.0722));\n    backdrop = mix(vec3(luma), backdrop, 1.18);\n    vec3 color = mix(backdrop, vertexColor.rgb, vertexColor.a);\n    float fromTop = ep.y + eb.y;\n    color += vec3(0.030) * (1.0 - smoothstep(0.0, 34.0 * k, fromTop));\n    color += vec3(0.55, 0.70, 1.0) * 0.045 * (1.0 - smoothstep(0.0, 3.5 * k, inside));\n    float lineWidth = max(1.0, 0.85 * k);\n    float border = coverage(de) * (1.0 - coverage(de + lineWidth));\n    float borderAlpha = mix(0.20, 0.07, clamp(fromTop / (2.0 * halfSize.y), 0.0, 1.0));\n    color = mix(color, vec3(0.93, 0.95, 1.0), border * borderAlpha);\n    return vec4(color, coverage(d) * opacity);\n}\n\nvoid main() {\n    float row = ScreenSize.y - gl_FragCoord.y;\n    float clip = clamp(row - clipRows.x + 0.5, 0.0, 1.0) * clamp(clipRows.y - row + 0.5, 0.0, 1.0);\n    if (clip <= 0.0) {\n        discard;\n    }\n    int mode = shapeParams.x & 15;\n    float aux = float((shapeParams.x >> 4) & 2047) / 8.0;\n    float primary = float(shapeParams.y) / 16.0;\n    vec4 color;\n    if (mode == MODE_TEXTURE) {\n        color = vec4(vertexColor.rgb, vertexColor.a * texture(Sampler1, texCoord).a);\n    } else if (mode == MODE_GLASS) {\n        color = glass(texCoord, primary);\n    } else if (mode == MODE_CIRCLE) {\n        float d = length(texCoord) - primary;\n        float core = coverage(d);\n        float halo = aux > 0.0 ? (1.0 - smoothstep(-aux * 0.2, aux, d)) * 0.5 : 0.0;\n        color = vec4(vertexColor.rgb, vertexColor.a * max(core, halo));\n    } else if (mode == MODE_STROKE) {\n        float d = roundBox(texCoord, halfSize, primary);\n        float alpha = coverage(d) * (1.0 - coverage(d + max(aux, 0.5)));\n        color = vec4(vertexColor.rgb, vertexColor.a * alpha);\n    } else {\n        float d = roundBox(texCoord, halfSize, primary);\n        float alpha = aux > 0.0 ? 1.0 - smoothstep(-aux, aux, d) : coverage(d);\n        color = vec4(vertexColor.rgb, vertexColor.a * alpha);\n    }\n    color.a *= clip;\n    if (color.a <= 0.0) {\n        discard;\n    }\n    fragColor = color * ColorModulator;\n}\n";
    private static final String QUAD_VSH = "#version 330\n\nout vec2 texCoord;\n\nvoid main() {\n    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n    texCoord = p;\n    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n";
    private static final String DOWN_FSH = "#version 330\n\n\nuniform sampler2D InSampler;\n\nin vec2 texCoord;\nout vec4 fragColor;\n\nvoid main() {\n    vec2 o = 1.0 / vec2(textureSize(InSampler, 0));\n    vec3 sum = texture(InSampler, texCoord).rgb * 4.0;\n    sum += texture(InSampler, texCoord - o).rgb;\n    sum += texture(InSampler, texCoord + o).rgb;\n    sum += texture(InSampler, texCoord + vec2(o.x, -o.y)).rgb;\n    sum += texture(InSampler, texCoord - vec2(o.x, -o.y)).rgb;\n    fragColor = vec4(sum / 8.0, 1.0);\n}\n";
    private static final String UP_FSH = "#version 330\n\n\nuniform sampler2D InSampler;\n\nin vec2 texCoord;\nout vec4 fragColor;\n\nvoid main() {\n    vec2 o = 1.0 / vec2(textureSize(InSampler, 0));\n    vec3 sum = texture(InSampler, texCoord + vec2(-o.x * 2.0, 0.0)).rgb;\n    sum += texture(InSampler, texCoord + vec2(-o.x, o.y)).rgb * 2.0;\n    sum += texture(InSampler, texCoord + vec2(0.0, o.y * 2.0)).rgb;\n    sum += texture(InSampler, texCoord + vec2(o.x, o.y)).rgb * 2.0;\n    sum += texture(InSampler, texCoord + vec2(o.x * 2.0, 0.0)).rgb;\n    sum += texture(InSampler, texCoord + vec2(o.x, -o.y)).rgb * 2.0;\n    sum += texture(InSampler, texCoord + vec2(0.0, -o.y * 2.0)).rgb;\n    sum += texture(InSampler, texCoord + vec2(-o.x, -o.y)).rgb * 2.0;\n    fragColor = vec4(sum / 12.0, 1.0);\n}\n";
    public static final class_12289 SOURCES = DropdownBlur::lmbd$static$0;

    private static RenderPipeline fullscreen(String string, class_2960 class_29602) {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)("pipeline/" + string))).withVertexShader(QUAD).withFragmentShader(class_29602).withSampler("InSampler").withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
    }

    private DropdownBlur() {
    }

    public static boolean ready(RenderPipeline renderPipeline) {
        try {
            CompiledRenderPipeline compiledRenderPipeline = RenderSystem.getDevice().precompilePipeline(renderPipeline, SOURCES);
            if (compiledRenderPipeline.isValid()) {
                return true;
            }
        }
        catch (Throwable throwable) {
            if (LOGGED.put(renderPipeline, Boolean.TRUE) != null) return false;
            System.err.println("Kryzex: dropdown GUI shader failed: " + String.valueOf(renderPipeline.getLocation()) + ": " + String.valueOf(throwable));
            return false;
        }
        if (LOGGED.put(renderPipeline, Boolean.TRUE) != null) return false;
        System.err.println("Kryzex: dropdown GUI shader did not compile: " + String.valueOf(renderPipeline.getLocation()));
        return false;
    }

    private static String lmbd$static$0(class_2960 class_29602, ShaderType shaderType) {
        if (UI_SHADER.equals((Object)class_29602)) {
            if (shaderType != ShaderType.VERTEX) return UI_FSH;
            return UI_VSH;
        }
        if (QUAD.equals((Object)class_29602)) {
            return QUAD_VSH;
        }
        if (DOWN.equals((Object)class_29602)) {
            return DOWN_FSH;
        }
        if (!UP.equals((Object)class_29602)) return null;
        return UP_FSH;
    }
}
