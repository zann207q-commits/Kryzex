package kryzex.gui;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Member;
import kryzex.gui.Name;
import kryzex.gui.SpeakerOff;
import kryzex.gui.Theme;
import kryzex.gui.NameDrawer;

public final class StaffList {
    private final Map<String, Member> rows = new LinkedHashMap<String, Member>();
    private int count;
    private float visibility;
    private float height;
    private double time;

    public void setMembers(List<Name> list) {
        for (Member object : this.rows.values()) {
            object.active = false;
        }
        int n = 0;
        for (Name name : list) {
            String string = name.name().toLowerCase(Locale.ROOT);
            Member member = this.rows.get(string);
            if (member == null) {
                member = new Member(name, n);
                this.rows.put(string, member);
            }
            member.member = name;
            member.index = n++;
            member.active = true;
        }
        this.count = n;
    }

    public void reset() {
        this.rows.clear();
        this.count = 0;
        this.height = 0.0f;
        this.visibility = 0.0f;
    }

    public void render(BaseRenderer baseRenderer, float f, float f2, float f3, float f4, float f5, float f6, boolean bl, boolean bl2, boolean bl3, int n, NameDrawer sh2) {
        f6 = Math.max(0.0f, Math.min(0.1f, f6));
        this.time += (double)f6;
        float f7 = 1.0f - (float)Math.exp(-12.0f * f6);
        float f8 = bl && (this.count != 0 || bl2) ? 1.0f : 0.0f;
        this.visibility += (f8 - this.visibility) * f7;
        int n2 = Math.max(1, (int)(((float)n - f2) / f4 - 54.0f) / 30);
        if (this.count > n2) {
            n2 = Math.max(1, (int)(((float)n - f2) / f4 - 73.0f) / 30);
        }
        int n3 = Math.min(Math.max(1, this.count), n2);
        float f9 = (float)(44 + n3 * 30 + 10 + (this.count > n2 ? 19 : 0)) * f4;
        if (this.height == 0.0f) {
            this.height = f9;
        }
        this.height += (f9 - this.height) * f7;
        Iterator<Member> iterator = this.rows.values().iterator();
        while (iterator.hasNext()) {
            Member member = iterator.next();
            member.alpha = member.alpha + ((member.active ? 1.0f : 0.0f) - member.alpha) * f7;
            member.y += ((float)member.index * 30.0f - member.y) * f7;
            if (member.active || !(member.alpha < 0.005f)) continue;
            iterator.remove();
        }
        if (this.visibility < 0.005f) {
            return;
        }
        float f10 = 16.0f * f4;
        baseRenderer.pushAlpha(this.visibility);
        baseRenderer.shadow(f, f2, f3, this.height, f10, 18.0f * f4, BaseRenderer.argb(0.3f, 0, 0, 0));
        baseRenderer.round(f, f2, f3, this.height, f10, Theme.glass(f5));
        baseRenderer.roundGradient(f, f2, f3, this.height, f10, BaseRenderer.white(0.05f), BaseRenderer.white(0.0f));
        float f11 = Math.min(f3, this.height) * 0.38f;
        baseRenderer.glow(f + f3 * (0.5f + 0.08f * (float)Math.sin(this.time * 0.12)), f2 + this.height * 0.5f, f11, Theme.light(0.025f * f5));
        baseRenderer.outline(f, f2, f3, this.height, f10, Math.max(1.0f, f4 * 0.8f), BaseRenderer.white(0.085f));
        baseRenderer.rect(f + f10, f2 + Math.max(1.0f, f4), f3 - f10 * 2.0f, Math.max(1.0f, f4 * 0.7f), BaseRenderer.white(0.045f));
        baseRenderer.icon(SpeakerOff.USER, f + 13.0f * f4, f2 + 13.0f * f4, 16.0f * f4, BaseRenderer.white(0.85f));
        baseRenderer.text(baseRenderer.ellipsize("Staff List", f3 - 72.0f * f4, 13.0f * f4, 1), f + 38.0f * f4, f2 + 13.0f * f4, 13.0f * f4, 1, BaseRenderer.white(0.95f));
        baseRenderer.textRight(Integer.toString(this.count), f + f3 - 14.0f * f4, f2 + 14.0f * f4, 11.0f * f4, 0, BaseRenderer.white(0.45f));
        baseRenderer.rect(f + 12.0f * f4, f2 + 38.0f * f4, f3 - 24.0f * f4, Math.max(1.0f, f4 * 0.8f), BaseRenderer.white(0.055f));
        if (this.count == 0 && this.rows.isEmpty()) {
            baseRenderer.text("No staff online", f + 14.0f * f4, f2 + 54.0f * f4, 11.5f * f4, 0, BaseRenderer.white(0.45f));
        }
        baseRenderer.pushClip(f + 8.0f * f4, f2 + 44.0f * f4, f3 - 16.0f * f4, Math.max(0.0f, this.height - 51.0f * f4));
        for (Member member : this.rows.values()) {
            float f12 = f2 + 44.0f * f4 + member.y * f4;
            if (member.index >= n2 || f12 > f2 + this.height - 10.0f * f4 || member.alpha < 0.005f) continue;
            baseRenderer.pushAlpha(member.alpha);
            float f13 = (1.0f - member.alpha) * 6.0f * f4;
            float f14 = f + 14.0f * f4 + f13;
            if (bl3) {
                baseRenderer.round(f14 - 2.0f * f4, f12 + 3.0f * f4, 23.0f * f4, 23.0f * f4, 7.0f * f4, BaseRenderer.white(0.035f));
                sh2.draw(member.member, f14, f12 + 5.0f * f4, 19.0f * f4, member.alpha * this.visibility);
                f14 += 29.0f * f4;
            }
            baseRenderer.text(baseRenderer.ellipsize(member.member.name(), f + f3 - 14.0f * f4 - f14, 12.0f * f4, 0), f14, f12 + 8.0f * f4, 12.0f * f4, 0, BaseRenderer.white(0.9f));
            baseRenderer.popAlpha();
        }
        baseRenderer.popClip();
        if (this.count > n2) {
            baseRenderer.text("+" + (this.count - n2) + " more", f + 14.0f * f4, f2 + this.height - 24.0f * f4, 10.0f * f4, 0, BaseRenderer.white(0.4f));
        }
        baseRenderer.popAlpha();
    }
}
