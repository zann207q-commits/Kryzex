package kryzex.gui;

import kryzex.gui.Handle;

final class Advance {
    Handle mask;
    float advance;
    int pad;

    Advance() {
    }
}
