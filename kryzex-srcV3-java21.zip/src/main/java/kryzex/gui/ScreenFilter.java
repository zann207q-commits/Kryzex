package kryzex.gui;

public final class ScreenFilter {
    private ScreenFilter() {
    }

    public static boolean allows(boolean bl, boolean bl2, boolean bl3, String string) {
        if (bl) return false;
        if (bl2) return false;
        if (string == null) return false;
        if (bl3) return true;
        if (!string.startsWith("net.minecraft.client.gui.screen.")) return false;
        return true;
    }
}
