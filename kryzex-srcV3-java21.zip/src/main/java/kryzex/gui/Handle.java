package kryzex.gui;

public final class Handle {
    public final String key;
    public final int w;
    public final int h;
    public final int[] argb;
    public Object handle;

    public Handle(String string, int n, int n2, int[] nArray) {
        this.key = string;
        this.w = n;
        this.h = n2;
        this.argb = nArray;
    }

    static Handle fromCoverage(String string, int n, int n2, float[] fArray) {
        int[] nArray = new int[n * n2];
        for (int i = 0; i < nArray.length; ++i) {
            int n3 = Math.round(Math.max(0.0f, Math.min(1.0f, fArray[i])) * 255.0f);
            nArray[i] = n3 << 24 | 0xFFFFFF;
        }
        return new Handle(string, n, n2, nArray);
    }
}
