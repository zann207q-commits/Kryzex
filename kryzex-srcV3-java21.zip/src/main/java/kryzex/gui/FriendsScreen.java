package kryzex.gui;

import kryzex.gui.FriendsMenu;
import kryzex.gui.NameCache;
import net.minecraft.class_1041;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class FriendsScreen
extends class_437 {
    private final class_437 parent;
    private final FriendsMenu menu;

    public FriendsScreen(class_437 class_4372, NameCache nameCache) {
        super((class_2561)class_2561.method_43470((String)"Friends"));
        this.parent = class_4372;
        this.menu = new FriendsMenu(nameCache, this::lmbd$new$0);
    }

    private float scale() {
        return this.field_22787.method_22683().method_4495();
    }

    public void method_25420(class_332 class_3322, int n, int n2, float f) {
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        class_1041 class_10412 = this.field_22787.method_22683();
        int n3 = class_10412.method_4489();
        int n4 = class_10412.method_4506();
        double d = this.field_22787.field_1729.method_1603() * (double)n3 / (double)Math.max(1, class_10412.method_4480());
        double d2 = this.field_22787.field_1729.method_1604() * (double)n4 / (double)Math.max(1, class_10412.method_4507());
        float f2 = this.scale();
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().scale(1.0f / f2, 1.0f / f2);
        try {
            this.menu.render(class_3322, n3, n4, d, d2);
            return;
        }
        finally {
            class_3322.method_51448().popMatrix();
        }
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        float f = this.scale();
        return this.menu.click(class_119092.comp_4798() * (double)f, class_119092.comp_4799() * (double)f, class_119092.method_74245());
    }

    public boolean method_25401(double d, double d2, double d3, double d4) {
        this.menu.scroll(d4);
        return true;
    }

    public boolean method_25404(class_11908 class_119082) {
        boolean bl;
        boolean bl2 = bl = (class_119082.comp_4797() & 2) != 0;
        if (bl && class_119082.comp_4795() == 86) {
            this.menu.insert(this.field_22787.field_1774.method_1460());
            return true;
        } else {
            this.menu.key(class_119082.comp_4795(), bl);
        }
        return true;
    }

    public boolean method_25400(class_11905 class_119052) {
        this.menu.insert(new String(Character.toChars(class_119052.comp_4793())));
        return true;
    }

    public void method_25419() {
        this.menu.close();
    }

    public boolean method_25421() {
        return false;
    }

    private void lmbd$new$0() {
        this.field_22787.method_1507(this.parent);
    }
}
