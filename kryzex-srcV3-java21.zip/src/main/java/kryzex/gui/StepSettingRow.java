package kryzex.gui;

import kryzex.gui.GuiWidgets;
import kryzex.gui.LinesWidth;
import kryzex.gui.ListeningModule;
import kryzex.gui.SquareCorners;
import kryzex.module.Module;
import kryzex.module.settings.Setting;

abstract class StepSettingRow
extends LinesWidth {
    StepSettingRow(Module module, Setting setting) {
        super(module, setting);
    }

    abstract String value();

    abstract void step(int var1);

    @Override
    protected float controlWidth(SquareCorners squareCorners) {
        return Math.min(squareCorners.textWidth(this.value()), 110.0f) + 22.0f;
    }

    @Override
    protected float baseHeight() {
        return 30.0f;
    }

    @Override
    protected void draw(ListeningModule listeningModule, float f, float f2, float f3, float f4) {
        float f5 = this.drawLabel(listeningModule, f, f2, f3, 15.0f);
        GuiWidgets.chip(listeningModule.painter, f + f3 - 10.0f, f5, this.value(), this.hover, 110.0f);
    }

    @Override
    public boolean mouseClicked(ListeningModule listeningModule, float f, float f2, float f3, float f4, float f5, float f6, int n) {
        if (n != 0 && n != 1) {
            return false;
        }
        this.step(n == 0 ? 1 : -1);
        listeningModule.host.sound("TICK");
        return true;
    }
}
