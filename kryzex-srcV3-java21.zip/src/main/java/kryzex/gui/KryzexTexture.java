package kryzex.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.class_1011;
import net.minecraft.class_1043;

final class KryzexTexture
extends class_1043 {
    public KryzexTexture(String string, class_1011 class_10112) {
        super(() -> KryzexTexture.lmbd$new$0(string), class_10112);
        this.field_63613 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
    }

    private static String lmbd$new$0(String string) {
        return "Kryzex " + string;
    }
}
