package kryzex.gui;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;
import kryzex.gui.BaseRenderer;
import kryzex.gui.Handle;
import kryzex.gui.KryzexClient;
import net.minecraft.class_332;

public final class KryzexLoadingBrand {
    private static Handle logo;
    private static long START;

    private KryzexLoadingBrand() {
    }

    public static Handle logo() {
        if (logo != null) return logo;
        try (InputStream inputStream = KryzexLoadingBrand.class.getResourceAsStream("/assets/r87f4560b4c09f4/menu/title.png");){
            BufferedImage bufferedImage = ImageIO.read(inputStream);
            logo = new Handle("kryzex_loading_brand", bufferedImage.getWidth(), bufferedImage.getHeight(), bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), null, 0, bufferedImage.getWidth()));
            return logo;
        }
        catch (Exception exception) {
            throw new IllegalStateException("Kryzex menu brand unavailable", exception);
        }
    }

    public static void draw(class_332 class_3322, float f, String string, float f2, boolean bl) {
        KryzexLoadingBrand.draw(KryzexClient.paint(class_3322), class_3322.method_51421(), class_3322.method_51443(), f, string, f2, bl);
    }

    public static void resources(class_332 class_3322, float f, float f2) {
        KryzexLoadingBrand.resources(KryzexClient.paint(class_3322), class_3322.method_51421(), class_3322.method_51443(), f, f2);
    }

    public static void resources(BaseRenderer baseRenderer, float f, float f2, float f3, float f4) {
        float f5 = Math.min(f / 640.0f, f2 / 360.0f);
        float f6 = f * 0.5f;
        float f7 = f2 * 0.48f;
        baseRenderer.pushAlpha(Math.clamp(f4, 0.0f, 1.0f));
        try {
            baseRenderer.gradient(0.0f, 0.0f, f, f2, -14342097, -15724010);
            baseRenderer.gradient(0.0f, 0.0f, f, f2 * 0.62f, 0x9FFFFFF, 0xFFFFFF);
            float f8 = Math.min(f * 0.68f, 390.0f * f5);
            float f9 = f8 / 6.0f;
            baseRenderer.texture(KryzexLoadingBrand.logo(), f6 - f8 / 2.0f, f7 - f9 / 2.0f, f8, f9, -526084);
            float f10 = Math.min(f * 0.6f, 355.0f * f5);
            float f11 = Math.max(4.0f, 6.0f * f5);
            float f12 = f6 - f10 / 2.0f;
            float f13 = f2 * 0.8325f;
            baseRenderer.round(f12, f13, f10, f11, f11 / 2.0f, 0x14FFFFFF);
            baseRenderer.outline(f12, f13, f10, f11, f11 / 2.0f, 0.6f * f5, 0x30FFFFFF);
            float f14 = Math.max(0.7f, f5);
            float f15 = (f10 - 2.0f * f14) * Math.clamp(f3, 0.0f, 1.0f);
            if (!(f15 > 0.0f)) return;
            baseRenderer.roundGradient(f12 + f14, f13 + f14, f15, Math.max(1.0f, f11 - 2.0f * f14), Math.max(1.0f, (f11 - 2.0f * f14) / 2.0f), -525825, -4208424);
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    public static void draw(BaseRenderer baseRenderer, float f, float f2, float f3, String string, float f4, boolean bl) {
        float f5 = Math.min(f / 640.0f, f2 / 360.0f);
        float f6 = (float)(System.nanoTime() - START) / 1.0E9f;
        baseRenderer.pushAlpha(Math.clamp(f4, 0.0f, 1.0f));
        try {
            float f7;
            float f8;
            if (bl) {
                baseRenderer.rect(0.0f, 0.0f, f, f2, -15197407);
                baseRenderer.gradient(0.0f, 0.0f, f, f2, -13617600, -15460579);
                for (int i = 0; i < 5; ++i) {
                    f8 = f * (0.1f + (float)i * 0.2f) + 10.0f * f5 * (float)Math.sin((double)f6 * 0.13 + (double)i);
                    f7 = f2 * (0.22f + 0.12f * (float)(i % 3));
                    baseRenderer.circle(f8, f7, 1.1f * f5, 0x38FFFFFF);
                }
            }
            float f9 = Math.min(f - 32.0f, 400.0f * f5);
            f8 = 122.0f * f5;
            f7 = f / 2.0f;
            float f10 = f2 * 0.45f;
            KryzexClient.glass(baseRenderer, f7 - f9 / 2.0f, f10 - f8 / 2.0f, f9, f8, 0.25f, false);
            float f11 = Math.min(f9 - 38.0f * f5, 330.0f * f5);
            baseRenderer.texture(KryzexLoadingBrand.logo(), f7 - f11 / 2.0f, f10 - 40.0f * f5, f11, f11 / 6.0f, -657412);
            String string2 = KryzexClient.brand(string == null || string.isBlank() ? "Preparing your experience" : string);
            float f12 = 10.0f * f5;
            string2 = baseRenderer.ellipsize(string2, f9 - 36.0f * f5, f12, 0);
            KryzexClient.centered(baseRenderer, string2, f7, f10 + 20.0f * f5, f12, -824384787, false);
            float f13 = f9 - 46.0f * f5;
            float f14 = f7 - f13 / 2.0f;
            float f15 = f10 + 43.0f * f5;
            float f16 = 3.0f * f5;
            baseRenderer.round(f14, f15, f13, f16, f16 / 2.0f, 0x32FFFFFF);
            if (f3 >= 0.0f) {
                float f17 = Math.clamp(f3, 0.0f, 1.0f);
                baseRenderer.round(f14, f15, f13 * f17, f16, f16 / 2.0f, -437390593);
                return;
            } else {
                float f18 = (float)(0.5 - 0.5 * Math.cos((double)f6 * 1.7));
                baseRenderer.round(f14 + (f13 - f13 * 0.24f) * f18, f15, f13 * 0.24f, f16, f16 / 2.0f, -437390593);
            }
            return;
        }
        finally {
            baseRenderer.popAlpha();
        }
    }

    static {
        START = System.nanoTime();
    }
}
