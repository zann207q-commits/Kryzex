package kryzex.modules.render;

import java.awt.Color;
import java.util.AbstractCollection;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.render.Outline;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.ChunkUtil;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2818;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class BedrockESP
extends Module {
    private static String[] a;
    private static List<Integer> OVERWORLD_LEVELS;
    private static List<Integer> NETHER_LEVELS;
    private final NumberSetting minimumSize = new NumberSetting(SecureString.of("Minimum Void Size"), 1.0, 50.0, 2.0, 1.0);
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
    private final CycleSetting<Outline> renderMode = new CycleSetting<Outline>(SecureString.of("Render Mode"), Outline.Box, Outline.class).setDescription(SecureString.of("Filled box, outline only, or both"));
    private final ListSetting color = new ListSetting(SecureString.of("Color")).add("void", "Void", class_1802.field_8542, true, new Color(240, 85, 80)).colorOnly();
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false);
    private final BoolSetting chatFeedback = new BoolSetting(SecureString.of("Chat Feedback"), true);
    private final Set<class_2338> voidBlocks = new HashSet<class_2338>();
    private final Map<Long, Set<class_2338>> voidsByChunk = new HashMap<Long, Set<class_2338>>();
    private final Set<class_2338> announcedGroups = new HashSet<class_2338>();
    private final Queue<Long> scanQueue = new ArrayDeque<Long>();
    private final Set<Long> queuedChunks = new HashSet<Long>();
    private final Set<Long> scannedChunks = new HashSet<Long>();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private Object scannedWorld;
    private int ticks;

    public BedrockESP() {
        super(SecureString.of("Bedrock ESP"), SecureString.of("Finds enclosed gaps in the overworld and nether bedrock layers"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.minimumSize, this.alpha, this.renderMode, this.color, this.tracers, this.chatFeedback});
    }

    @Override
    public void onEnable() {
        this.o();
        this.scannedWorld = this.mc.field_1687;
        this.k();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.o();
        super.onDisable();
    }

    private void o() {
        this.voidBlocks.clear();
        this.voidsByChunk.clear();
        this.announcedGroups.clear();
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.scannedChunks.clear();
        this.renderBoxes.clear();
        this.renderLines.clear();
        this.scannedWorld = null;
        this.ticks = 0;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.Q(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
            if (this.scannedWorld != this.mc.field_1687) {
                this.voidBlocks.clear();
                this.voidsByChunk.clear();
                this.announcedGroups.clear();
                this.scanQueue.clear();
                this.queuedChunks.clear();
                this.scannedChunks.clear();
                this.scannedWorld = this.mc.field_1687;
                this.ticks = 0;
            }
            ++this.ticks;
            if (this.ticks % 20 == 1) {
                this.k();
            }
            if (this.ticks % 200 == 0 && this.scanQueue.isEmpty()) {
                this.scannedChunks.clear();
                this.k();
            }
            this.U();
            if (this.ticks % 40 != 0) return;
            this.W();
            return;
        } else {
            this.o();
        }
    }

    private void k() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) return;
        class_1923 class_19232 = this.mc.field_1724.method_31476();
        List<class_2818> list = ChunkUtil.getLoadedChunksList();
        list.sort(Comparator.comparingInt(arg_0 -> BedrockESP.lmbd$enqueueLoadedChunks$0(class_19232, arg_0)));
        for (class_2818 class_28182 : list) {
            this.Q(class_28182.method_12004().field_9181, class_28182.method_12004().field_9180);
        }
    }

    private void Q(int n, int n2) {
        long l = class_1923.method_8331((int)n, (int)n2);
        if (this.scannedChunks.contains(l) || !this.queuedChunks.add(l)) return;
        this.scanQueue.offer(l);
    }

    private void U() {
        Long l = this.scanQueue.poll();
        if (l == null) return;
        this.queuedChunks.remove(l);
        this.scannedChunks.add(l);
        int n = class_1923.method_8325((long)l);
        int n2 = class_1923.method_8332((long)l);
        if (!this.mc.field_1687.method_8393(n, n2)) {
            this.p(l);
            return;
        } else {
            this.C(this.mc.field_1687.method_8497(n, n2), l);
        }
    }

    private void C(class_2818 class_28182, long l) {
        Object object;
        List<Integer> list;
        Set<class_2338> set = this.voidsByChunk.remove(l);
        if (set != null) {
            this.voidBlocks.removeAll(set);
        }
        if ((list = this.K()).isEmpty()) return;
        HashSet<class_2338> hashSet = new HashSet<class_2338>();
        int n = class_28182.method_12004().method_8326();
        int n2 = class_28182.method_12004().method_8328();
        java.util.Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {
            int n3 = iterator.next();
            for (int i = 0; i < 16; ++i) {
                for (int j = 0; j < 16; ++j) {
                    class_2338 blockPos = new class_2338(n + i, n3, n2 + j);
                    if (class_28182.method_8320(blockPos).method_26204() == class_2246.field_9987) continue;
                    hashSet.add(blockPos);
                }
            }
        }
        HashSet<class_2338> voidSet = new HashSet<class_2338>();
        HashSet<class_2338> hashSet2 = new HashSet<class_2338>();
        for (class_2338 class_23382 : hashSet) {
            class_2338 class_23383;
            if (!hashSet2.add(class_23382)) continue;
            HashSet<class_2338> group = new HashSet<class_2338>();
            ArrayDeque<class_2338> arrayDeque = new ArrayDeque<class_2338>();
            arrayDeque.add(class_23382);
            while (!arrayDeque.isEmpty() && group.size() < 200) {
                class_23383 = arrayDeque.remove();
                group.add(class_23383);
                for (class_2350 class_23502 : class_2350.values()) {
                    class_2338 class_23384 = class_23383.method_10093(class_23502);
                    if (!hashSet.contains(class_23384) || !hashSet2.add(class_23384)) continue;
                    arrayDeque.add(class_23384);
                }
            }
            if (!arrayDeque.isEmpty() || group.size() < this.minimumSize.getIntValue() || !this.V(group)) continue;
            voidSet.addAll(group);
            class_23383 = group.iterator().next();
            if (!this.chatFeedback.getValue() || !this.announcedGroups.add(class_23383)) continue;
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7d[Bedrock ESP] \u00a7fVoid found: " + group.size() + " blocks at " + class_23383.method_23854())), false);
        }
        if (!voidSet.isEmpty()) {
            this.voidsByChunk.put(l, Set.copyOf(voidSet));
        }
        this.voidBlocks.addAll((Collection<class_2338>)voidSet);
        this.announcedGroups.retainAll(this.voidBlocks);
    }

    private boolean V(Set<class_2338> set) {
        for (class_2338 class_23382 : set) {
            for (class_2350 class_23502 : class_2350.values()) {
                class_2338 class_23383 = class_23382.method_10093(class_23502);
                if (set.contains(class_23383) || this.mc.field_1687.method_8320(class_23383).method_26204() == class_2246.field_9987) continue;
                return false;
            }
        }
        return true;
    }

    private void W() {
        for (Long l : new ArrayList<Long>(this.voidsByChunk.keySet())) {
            int n;
            int n2 = class_1923.method_8325((long)l);
            if (this.mc.field_1687.method_8393(n2, n = class_1923.method_8332((long)l))) continue;
            this.p(l);
        }
    }

    private void p(long l) {
        Set<class_2338> set = this.voidsByChunk.remove(l);
        if (set != null) {
            this.voidBlocks.removeAll(set);
        }
        this.scannedChunks.remove(l);
        this.queuedChunks.remove(l);
    }

    private List<Integer> K() {
        String string = this.mc.field_1687.method_27983().method_29177().toString();
        if (!string.equals("minecraft:overworld")) return string.equals("minecraft:the_nether") ? NETHER_LEVELS : List.of();
        return OVERWORLD_LEVELS;
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1687 == null || this.voidBlocks.isEmpty() || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        Color color = this.color.entries().get(0).color();
        Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.alpha.getIntValue());
        Color color3 = new Color(Math.min(255, color.getRed() + 15), Math.min(255, color.getGreen() + 15), Math.min(255, color.getBlue() + 15), Math.max(160, this.alpha.getIntValue()));
        boolean bl = !this.renderMode.isMode(Outline.Outline);
        boolean bl2 = !this.renderMode.isMode(Outline.Box);
        this.renderBoxes.clear();
        this.renderLines.clear();
        class_243 class_2432 = InverseProjectionScratch.getTracerStart(class_41842);
        for (class_2338 class_23382 : this.voidBlocks) {
            if (!this.tracers.getValue() && !OriginX.box(class_23382.method_10263(), class_23382.method_10264(), class_23382.method_10260(), class_23382.method_10263() + 1, class_23382.method_10264() + 1, class_23382.method_10260() + 1)) continue;
            double d = (double)class_23382.method_10263() + 0.03;
            double d2 = (double)class_23382.method_10264() + 0.03;
            double d3 = (double)class_23382.method_10260() + 0.03;
            double d4 = (double)class_23382.method_10263() + 0.97;
            double d5 = (double)class_23382.method_10264() + 0.97;
            double d6 = (double)class_23382.method_10260() + 0.97;
            if (bl && this.alpha.getIntValue() > 0) {
                this.renderBoxes.add(new kryzex.util.Color(d, d2, d3, d4, d5, d6, color2));
            }
            if (bl2) {
                InverseProjectionScratch.addBoxOutline(this.renderLines, d, d2, d3, d4, d5, d6, color3, 1.5f);
            }
            if (!this.tracers.getValue()) continue;
            this.renderLines.add(new Start(class_2432, class_243.method_24953((class_2382)class_23382), color3, 1.5f));
        }
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        InverseProjectionScratch.renderLines(class_45872, this.renderLines);
        class_45872.method_22909();
    }

    private static int lmbd$enqueueLoadedChunks$0(class_1923 class_19232, class_2818 class_28182) {
        return Math.max(Math.abs(class_28182.method_12004().field_9181 - class_19232.field_9181), Math.abs(class_28182.method_12004().field_9180 - class_19232.field_9180));
    }

    static {
        a = new String[]{"Tracers", "minecraft:the_nether", "minecraft:overworld", "Chat Feedback", "Alpha", "Void", "Finds enclosed gaps in the overworld and nether bedrock layers", "Bedrock ESP", "Render Mode", "Color", "Minimum Void Size", "Filled box, outline only, or both", "void"};
        OVERWORLD_LEVELS = List.of(Integer.valueOf(-64), Integer.valueOf(-63), Integer.valueOf(-62), Integer.valueOf(-61), Integer.valueOf(-60));
        NETHER_LEVELS = List.of(Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(123), Integer.valueOf(124), Integer.valueOf(125), Integer.valueOf(126), Integer.valueOf(127));
    }
}
