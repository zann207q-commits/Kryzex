package kryzex.modules.render;

import java.util.List;
import kryzex.modules.render.Bottom;

class Generation {
    public final long generation;
    public final long chunk;
    public final List<Bottom> shafts;

    public Generation(long generation, long chunk, List<Bottom> shafts) {
        this.generation = generation;
        this.chunk = chunk;
        this.shafts = shafts;
    }

    public long generation() {
        return this.generation;
    }

    public long chunk() {
        return this.chunk;
    }

    public List<Bottom> shafts() {
        return this.shafts;
    }
}
