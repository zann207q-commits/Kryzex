package kryzex.modules.render;

import kryzex.gui.Theme;

final class AccentColor {
    private AccentColor() {
    }

    static int N() {
        return Theme.accent(1.0f) | 0xFF000000;
    }
}
