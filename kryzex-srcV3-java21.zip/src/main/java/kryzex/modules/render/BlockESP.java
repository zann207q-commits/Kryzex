package kryzex.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import kryzex.event.BlockStateChangeEvent;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.render.Block2;
import kryzex.modules.render.Overridden;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.ChunkUtil;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class BlockESP
extends Module {
    private static String[] a;
    private static final int MAX_RENDERED_BLOCKS = 4096;
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 53.0, 1.0);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false);
    private final ListSetting blocks = BlockESP.h();
    private final Map<Long, List<Block2>> results = new HashMap<Long, List<Block2>>();
    private final Queue<Long> scanQueue = new PriorityQueue<Long>(Comparator.comparingLong(this::u));
    private Overridden task;
    private int centerX;
    private int centerZ;
    private final ConcurrentLinkedQueue<class_2338> blockChanges = new ConcurrentLinkedQueue();
    private final Set<Long> queued = new HashSet<Long>();
    private final Set<Long> scanned = new HashSet<Long>();
    private final Map<class_2248, ToggleEntry> selected = new HashMap<class_2248, ToggleEntry>();
    private final List<kryzex.util.Color> renderBoxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private Object trackedWorld;
    private int selectionSignature;
    private int ticks;

    public BlockESP() {
        super(SecureString.of("Block ESP"), SecureString.of("Searches and highlights any selected Minecraft block"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.alpha, this.tracers, this.blocks});
    }

    private static ListSetting h() {
        ListSetting listSetting = new ListSetting(SecureString.of("Blocks"));
        for (class_2248 class_22482 : class_7923.field_41175) {
            if (class_22482 == class_2246.field_10124 || class_22482 == class_2246.field_10543 || class_22482 == class_2246.field_10243) continue;
            class_2960 class_29602 = class_7923.field_41175.method_10221((class_2248)class_22482);
            int n = class_29602.toString().hashCode();
            Color color = Color.getHSBColor((float)(n & 0xFFFF) / 65535.0f, 0.58f, 1.0f);
            listSetting.add(class_29602.toString(), class_22482.method_9518().getString(), class_22482.method_8389(), false, color);
        }
        return listSetting;
    }

    @Override
    public void onEnable() {
        this.L();
        this.trackedWorld = this.mc.field_1687;
        this.o();
        this.m();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.L();
        super.onDisable();
    }

    private void L() {
        this.task = null;
        this.blockChanges.clear();
        this.results.clear();
        this.scanQueue.clear();
        this.queued.clear();
        this.scanned.clear();
        this.selected.clear();
        this.renderBoxes.clear();
        this.renderLines.clear();
        this.trackedWorld = null;
        this.selectionSignature = 0;
        this.ticks = 0;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.B(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
            int n;
            if (this.trackedWorld != this.mc.field_1687) {
                this.L();
                this.trackedWorld = this.mc.field_1687;
            }
            if ((n = this.N()) != this.selectionSignature) {
                this.task = null;
                this.results.clear();
                this.scanQueue.clear();
                this.queued.clear();
                this.scanned.clear();
                this.o();
                this.m();
            }
            if (this.selected.isEmpty()) return;
            ++this.ticks;
            class_1923 class_19232 = this.mc.field_1724.method_31476();
            boolean bl = class_19232.field_9181 != this.centerX || class_19232.field_9180 != this.centerZ;
            this.centerX = class_19232.field_9181;
            this.centerZ = class_19232.field_9180;
            if (bl && !this.scanQueue.isEmpty()) {
                ArrayList<Long> arrayList = new ArrayList<Long>(this.scanQueue);
                this.scanQueue.clear();
                this.scanQueue.addAll(arrayList);
            }
            this.n();
            if (this.ticks % 20 == 1 || bl) {
                this.m();
            }
            this.f();
            if (this.ticks % 20 != 0) return;
            this.d();
            return;
        } else {
            this.L();
        }
    }

    private int N() {
        int n = 1;
        for (ToggleEntry toggleEntry : this.blocks.entries()) {
            if (!toggleEntry.enabled()) continue;
            n = 31 * n + toggleEntry.id().hashCode();
        }
        return n;
    }

    private void o() {
        this.selected.clear();
        for (ToggleEntry toggleEntry : this.blocks.entries()) {
            if (!toggleEntry.enabled()) continue;
            class_7923.field_41175.method_10223(class_2960.method_60654((String)toggleEntry.id())).ifPresent(arg_0 -> this.lmbd$refreshSelection$0(toggleEntry, arg_0));
        }
        this.selectionSignature = this.N();
    }

    private void m() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.selected.isEmpty()) return;
        class_1923 class_19232 = this.mc.field_1724.method_31476();
        this.centerX = class_19232.field_9181;
        this.centerZ = class_19232.field_9180;
        List<class_2818> list = ChunkUtil.getLoadedChunksList();
        list.sort(Comparator.comparingInt(arg_0 -> BlockESP.lmbd$enqueueLoadedChunks$0(class_19232, arg_0)));
        for (class_2818 class_28182 : list) {
            this.k(class_28182.method_12004().field_9181, class_28182.method_12004().field_9180);
        }
    }

    private void k(int n, int n2) {
        long l = class_1923.method_8331((int)n, (int)n2);
        if (this.selected.isEmpty() || this.scanned.contains(l) || !this.queued.add(l)) return;
        this.scanQueue.offer(l);
    }

    private long u(long l) {
        long l2 = (long)class_1923.method_8325((long)l) - (long)this.centerX;
        long l3 = (long)class_1923.method_8332((long)l) - (long)this.centerZ;
        return l2 * l2 + l3 * l3;
    }

    private void B(int n, int n2) {
        long l = class_1923.method_8331((int)n, (int)n2);
        this.scanned.remove(l);
        if (this.task != null && this.task.key == l) {
            this.task = null;
        }
        this.k(n, n2);
    }

    @Subscribe
    public void onBlockStateChange(BlockStateChangeEvent blockStateChangeEvent) {
        if (blockStateChangeEvent.pos == null || blockStateChangeEvent.newState == null || blockStateChangeEvent.oldState == null || blockStateChangeEvent.newState.method_26204() == blockStateChangeEvent.oldState.method_26204() || !this.selected.containsKey(blockStateChangeEvent.newState.method_26204()) && !this.selected.containsKey(blockStateChangeEvent.oldState.method_26204())) return;
        this.blockChanges.offer(blockStateChangeEvent.pos.method_10062());
    }

    private void n() {
        class_2338 class_233822;
        HashSet<class_2338> hashSet = new HashSet<class_2338>();
        for (int i = 0; i < 256 && (class_233822 = this.blockChanges.poll()) != null; ++i) {
            hashSet.add(class_233822);
        }
        for (class_2338 class_233823 : hashSet) {
            int n;
            int n2 = class_233823.method_10263() >> 4;
            if (!this.mc.field_1687.method_8393(n2, n = class_233823.method_10260() >> 4)) continue;
            long l = class_1923.method_8331((int)n2, (int)n);
            class_2248 class_22482 = this.mc.field_1687.method_8320(class_233823).method_26204();
            List<Block2> list = this.results.get(l);
            ArrayList<Block2> arrayList = list == null ? new ArrayList<Block2>() : new ArrayList<Block2>(list);
            arrayList.removeIf(arg_0 -> BlockESP.lmbd$applyBlockChanges$0(class_233823, arg_0));
            if (this.selected.containsKey(class_22482) && arrayList.size() < 4096) {
                arrayList.add(new Block2(class_233823, class_22482));
            }
            if (arrayList.isEmpty()) {
                this.results.remove(l);
            } else {
                this.results.put(l, List.copyOf(arrayList));
            }
            if (this.task != null && this.task.key == l) {
                this.task.overridden.add(class_233823);
                this.task.found.removeIf(arg_0 -> BlockESP.lmbd$applyBlockChanges$1(class_233823, arg_0));
                if (this.selected.containsKey(class_22482) && this.task.found.size() < 4096) {
                    this.task.found.add(new Block2(class_233823, class_22482));
                }
            }
            if (this.scanned.contains(l) || this.task != null && this.task.key == l) continue;
            this.k(n2, n);
        }
    }

    private void f() {
        long l = System.nanoTime() + 2500000L;
        int n = 0;
        int n2 = 0;
        while (n2 < 64 && n < 131072) {
            int n3;
            Object object;
            if (System.nanoTime() >= l) {
                return;
            }
            if (this.task == null) {
                object = this.scanQueue.poll();
                if (object == null) {
                    return;
                }
                this.queued.remove(object);
                int n4 = class_1923.method_8325((long)((Long)object));
                n3 = class_1923.method_8332((long)((Long)object));
                if (!this.mc.field_1687.method_8393(n4, n3)) {
                    this.results.remove(object);
                    this.scanned.remove(object);
                    continue;
                }
                this.task = new Overridden((Long)object, this.mc.field_1687.method_8497(n4, n3));
            }
            object = this.task;
            if (!this.mc.field_1687.method_8393(class_1923.method_8325((long)((Overridden)object).key), class_1923.method_8332((long)((Overridden)object).key))) {
                this.results.remove(((Overridden)object).key);
                this.task = null;
                continue;
            }
            while (((Overridden)object).section < ((Overridden)object).sections.length && ((Overridden)object).found.size() < 4096) {
                class_2826 class_28262 = ((Overridden)object).sections[((Overridden)object).section];
                if (((Overridden)object).cell == 0 && (class_28262 == null || class_28262.method_38292() || !class_28262.method_19523(this::lmbd$scanNextChunk$0))) {
                    ++((Overridden)object).section;
                    continue;
                }
                while (((Overridden)object).cell < 4096 && ((Overridden)object).found.size() < 4096) {
                    class_2338 class_23382;
                    if ((n++ & 0x3F) == 0 && (System.nanoTime() >= l || n >= 131072)) {
                        return;
                    }
                    n3 = ((Overridden)object).cell & 0xF;
                    int n5 = ((Overridden)object).cell >> 8 & 0xF;
                    int n6 = ((Overridden)object).cell >> 4 & 0xF;
                    class_2248 class_22482 = class_28262.method_12254(n3, n5, n6).method_26204();
                    if (this.selected.containsKey(class_22482) && !((Overridden)object).overridden.contains(class_23382 = new class_2338(((Overridden)object).x + n3, (((Overridden)object).bottom + ((Overridden)object).section << 4) + n5, ((Overridden)object).z + n6))) {
                        ((Overridden)object).found.add(new Block2(class_23382, class_22482));
                    }
                    ++((Overridden)object).cell;
                }
                ++((Overridden)object).section;
                ((Overridden)object).cell = 0;
            }
            if (((Overridden)object).found.isEmpty()) {
                this.results.remove(((Overridden)object).key);
            } else {
                this.results.put(((Overridden)object).key, List.copyOf(((Overridden)object).found));
            }
            this.scanned.add(((Overridden)object).key);
            this.task = null;
            ++n2;
        }
    }

    private void d() {
        this.scanned.removeIf(this::lmbd$pruneUnloaded$0);
        this.results.keySet().removeIf(this::lmbd$pruneUnloaded$1);
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1687 == null || this.results.isEmpty() || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        this.renderBoxes.clear();
        this.renderLines.clear();
        class_243 class_2432 = InverseProjectionScratch.getTracerStart(class_41842);
        int n = this.alpha.getIntValue();
        int n2 = 0;
        for (List<Block2> list : this.results.values()) {
            for (Block2 block2 : list) {
                ToggleEntry toggleEntry;
                class_2338 class_23382 = block2.pos();
                if (!this.tracers.getValue() && !OriginX.box(class_23382.method_10263(), class_23382.method_10264(), class_23382.method_10260(), class_23382.method_10263() + 1, class_23382.method_10264() + 1, class_23382.method_10260() + 1) || (toggleEntry = this.selected.get(block2.block())) == null) continue;
                Color color = toggleEntry.color();
                Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
                double d = 0.08;
                this.renderBoxes.add(new kryzex.util.Color((double)class_23382.method_10263() + d, (double)class_23382.method_10264() + d, (double)class_23382.method_10260() + d, (double)class_23382.method_10263() + 1.0 - d, (double)class_23382.method_10264() + 1.0 - d, (double)class_23382.method_10260() + 1.0 - d, color2));
                if (this.tracers.getValue()) {
                    this.renderLines.add(new Start(class_2432, new class_243((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 0.5, (double)class_23382.method_10260() + 0.5), color2, 1.5f));
                }
                if (++n2 < 4096) continue;
                break;
            }
            if (n2 < 4096) continue;
            break;
        }
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        InverseProjectionScratch.renderLines(class_45872, this.renderLines);
        class_45872.method_22909();
    }

    private boolean lmbd$pruneUnloaded$1(Long l) {
        if (this.mc.field_1687.method_8393(class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }

    private boolean lmbd$pruneUnloaded$0(Long l) {
        if (this.mc.field_1687.method_8393(class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }

    private boolean lmbd$scanNextChunk$0(class_2680 class_26802) {
        return this.selected.containsKey(class_26802.method_26204());
    }

    private static boolean lmbd$applyBlockChanges$1(class_2338 class_23382, Block2 block2) {
        return block2.pos().equals((Object)class_23382);
    }

    private static boolean lmbd$applyBlockChanges$0(class_2338 class_23382, Block2 block2) {
        return block2.pos().equals((Object)class_23382);
    }

    private static int lmbd$enqueueLoadedChunks$0(class_1923 class_19232, class_2818 class_28182) {
        class_1923 class_19233 = class_28182.method_12004();
        return Math.max(Math.abs(class_19233.field_9181 - class_19232.field_9181), Math.abs(class_19233.field_9180 - class_19232.field_9180));
    }

    private void lmbd$refreshSelection$0(ToggleEntry toggleEntry, class_6880.class_6883 class_68832) {
        this.selected.put((class_2248)class_68832.comp_349(), toggleEntry);
    }

    static {
        a = new String[]{"Alpha", "Block ESP", "Blocks", "Tracers", "Searches and highlights any selected Minecraft block"};
    }
}
