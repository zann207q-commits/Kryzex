package kryzex.modules.render;

import net.minecraft.class_2246;
import net.minecraft.class_2248;

enum Chest {
    CHEST("chest", class_2246.field_10034),
    TRAPPED_CHEST("trapped_chest", class_2246.field_10380),
    ENDER_CHEST("ender_chest", class_2246.field_10443),
    SHULKER("shulker", class_2246.field_10603),
    SPAWNER("spawner", class_2246.field_10260),
    BARREL("barrel", class_2246.field_16328),
    TRIAL_SPAWNER("trial_spawner", class_2246.field_47336),
    VAULT("vault", class_2246.field_48851),
    FURNACE("furnace", class_2246.field_10181),
    BLAST_FURNACE("blast_furnace", class_2246.field_16333),
    SMOKER("smoker", class_2246.field_16334),
    HOPPER("hopper", class_2246.field_10312),
    DISPENSER("dispenser", class_2246.field_10200),
    DROPPER("dropper", class_2246.field_10228),
    CHISELED_BOOKSHELF("chiseled_bookshelf", class_2246.field_40276),
    BREWING_STAND("brewing_stand", class_2246.field_10333),
    CRAFTER("crafter", class_2246.field_46797),
    DECORATED_POT("decorated_pot", class_2246.field_42752);

    final String id;
    final class_2248 block;

    private Chest(String string2, class_2248 class_22482) {
        this.id = string2;
        this.block = class_22482;
    }
}
