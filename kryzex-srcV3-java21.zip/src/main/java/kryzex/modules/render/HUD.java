package kryzex.modules.render;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kryzex.event.HudRenderEvent;
import kryzex.event.Subscribe;
import kryzex.gui.BaseRenderer;
import kryzex.gui.ClickGuiScreen;
import kryzex.gui.GuiRenderer;
import kryzex.gui.Logo;
import kryzex.gui.Pixel;
import kryzex.gui.SortMode;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.util.SecureString;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1041;
import net.minecraft.class_1937;
import net.minecraft.class_310;

/**
 * HUD kieu Kaze: watermark, info (FPS/ping/server), dong ho, toa do va danh sach module
 * dang bo tron goc. Khong keo tha vi tri.
 */
public final class HUD
extends Module {
    private static final int PRIMARY = 0xFF41B9FF;
    private static final int SECONDARY = 0xFFFF6EE6;
    private static final int GRAY = 0xFFAFAFAF;
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");

    public static final BoolSetting HIDE_POTION_HUD = new BoolSetting(SecureString.of("Hide Potion HUD"), true).setDescription(SecureString.of("Hides the full vanilla status-effect overlay"));
    private final BoolSetting showWatermark = new BoolSetting(SecureString.of("Watermark"), true).setDescription(SecureString.of("Shows client name on screen"));
    private final BoolSetting showInfo = new BoolSetting(SecureString.of("Info"), true).setDescription(SecureString.of("Shows FPS, ping and server"));
    private final BoolSetting showModules = new BoolSetting(SecureString.of("Modules"), true).setDescription(SecureString.of("Renders module array list"));
    private final BoolSetting showTime = new BoolSetting(SecureString.of("Time"), true).setDescription(SecureString.of("Shows current time"));
    private final BoolSetting showCoordinates = new BoolSetting(SecureString.of("Coordinates"), true).setDescription(SecureString.of("Shows player coordinates"));
    private final NumberSetting opacity = new NumberSetting(SecureString.of("Opacity"), 0.0, 1.0, 0.8, 0.05).getValue(SecureString.of("Controls the opacity of HUD elements"));
    private final NumberSetting cornerRadius = new NumberSetting(SecureString.of("Corner Radius"), 0.0, 10.0, 5.0, 0.5).getValue(SecureString.of("Controls the roundness of corners"));
    private final CycleSetting<SortMode> moduleSort = new CycleSetting<SortMode>(SecureString.of("Sort Mode"), SortMode.Longest, SortMode.class).setDescription(SecureString.of("How to sort the module list"));
    private final BoolSetting rainbow = new BoolSetting(SecureString.of("Rainbow"), false).setDescription(SecureString.of("Enables rainbow coloring effect"));
    private final NumberSetting rainbowSpeed = new NumberSetting(SecureString.of("Rainbow Speed"), 0.1, 10.0, 2.0, 0.1).getValue(SecureString.of("Controls the speed of the rainbow effect"));
    private final CycleSetting<Pixel> hudFont = new CycleSetting<Pixel>(SecureString.of("HUD Font"), Pixel.Minecraft, Pixel.class).setDescription(SecureString.of("Font of the HUD: Minecraft Ten, the vanilla pixel font or Kryzex's font"));
    private final NumberSetting hudScale = new NumberSetting(SecureString.of("HUD Scale"), 60.0, 160.0, 100.0, 5.0).getValue(SecureString.of("Size of the HUD in percent"));
    public final StringSetting customIp = new StringSetting(SecureString.of("Custom IP"), "").setDescription(SecureString.of("Server name shown in the HUD; blank uses the connected server"));
    public final BoolSetting spoofPing = new BoolSetting(SecureString.of("Ping Spoof"), false).setDescription(SecureString.of("Display a custom ping value in this HUD only"));
    public final NumberSetting spoofedPing = new NumberSetting(SecureString.of("Spoofed Ping"), 0.0, 9999.0, 50.0, 1.0).getValue(SecureString.of("Ping value shown in the HUD while Ping Spoof is enabled"));

    // Giu lai: HudLayoutUtil (luu/nap layout trong SettingsManager) doc field "hud" bang reflection.
    private final Logo hud = new Logo();
    private final Singleplayer data = new Singleplayer(this);
    public float tickDelta = 1.0f;
    public final Map<String, Integer> categories = new HashMap<String, Integer>();

    // Cache danh sach module da sap xep
    private List<String> sortSource;
    private int sortKey;
    private String[] sortedNames = new String[0];
    private float[] sortedWidths = new float[0];

    public HUD() {
        super(SecureString.of("HUD"), SecureString.of("Customizable Heads-Up Display for client information"), -1, Category.CLIENT);
        this.addSettings(new Setting[]{this.showWatermark, this.showInfo, this.showModules, this.showTime, this.showCoordinates, this.opacity, this.cornerRadius, this.moduleSort, this.rainbow, this.rainbowSpeed, this.hudFont, this.hudScale, HIDE_POTION_HUD, this.customIp, this.spoofPing, this.spoofedPing});
        try {
            this.hud.setFile(FabricLoader.getInstance().getConfigDir().resolve("kryzex-hud-layout.txt"));
        }
        catch (Throwable throwable) {
            // layout file is optional
        }
    }

    @Subscribe
    public void onHudRender(HudRenderEvent event) {
        class_1041 window = this.mc.method_22683();
        if (this.mc.field_1690.field_1842 || window == null) return;
        if (this.mc.field_1755 instanceof ClickGuiScreen) return;
        this.tickDelta = event.tickDelta;
        int fbW = window.method_4489();
        int fbH = window.method_4506();
        float guiScale = window.method_4495();
        event.context.method_51448().pushMatrix();
        event.context.method_51448().scale(1.0f / guiScale, 1.0f / guiScale);
        try {
            this.draw(new GuiRenderer(event.context, guiScale), fbW, fbH);
        }
        finally {
            event.context.method_51448().popMatrix();
        }
    }

    private void draw(GuiRenderer r, int fbW, int fbH) {
        float u = Math.max(0.5f, (float)fbH / 1080.0f * (float)(this.hudScale.getValue() / 100.0));
        float ts = 12.5f * u;
        float rowH = 20.0f * u;
        float radius = this.cornerRadius.getFloatValue() * u;
        int font = this.hudFont.getModeIndex();
        int bg = BaseRenderer.argb(this.opacity.getFloatValue(), 35, 35, 35);
        boolean inWorld = this.data.inWorld();

        if (this.showWatermark.getValue()) {
            String label = "Kryzex";
            float w = r.textWidth(label, ts, font);
            float x = 5.0f * u;
            float y = 5.0f * u;
            r.round(x, y, w + 12.0f * u, rowH, radius, bg);
            r.text(label, x + 6.0f * u, this.textY(y, rowH, ts, u), ts, font, this.accent(0.0f));
        }

        if (this.showInfo.getValue() && inWorld) {
            String fps = "FPS: " + this.data.fps() + " | ";
            String server = this.data.server();
            boolean hasServer = server != null && !server.isBlank();
            String ping = "Ping: " + this.data.ping() + "ms" + (hasServer ? " | " : "");
            float w1 = r.textWidth(fps, ts, font);
            float w2 = r.textWidth(ping, ts, font);
            float w3 = hasServer ? r.textWidth(server, ts, font) : 0.0f;
            float x = 5.0f * u;
            float y = 30.0f * u;
            float ty = this.textY(y, rowH, ts, u);
            r.round(x, y, w1 + w2 + w3 + 10.0f * u, rowH, radius, bg);
            float cx = x + 5.0f * u;
            r.text(fps, cx, ty, ts, font, PRIMARY);
            r.text(ping, cx + w1, ty, ts, font, SECONDARY);
            if (hasServer) {
                r.text(server, cx + w1 + w2, ty, ts, font, GRAY);
            }
        }

        if (this.showTime.getValue()) {
            String time = TIME_FORMAT.format(new Date());
            float w = r.textWidth(time, ts, font);
            float boxW = w + 10.0f * u;
            float x = (float)fbW / 2.0f - boxW / 2.0f;
            float y = 5.0f * u;
            r.round(x, y, boxW, rowH, radius, bg);
            r.text(time, x + 5.0f * u, this.textY(y, rowH, ts, u), ts, font, this.accent(0.0f));
        }

        if (this.showCoordinates.getValue() && inWorld) {
            double px = this.data.x();
            double py = this.data.y();
            double pz = this.data.z();
            String coords = String.format(Locale.ROOT, "X: %.1f | Y: %.1f | Z: %.1f", px, py, pz);
            if (this.mc.field_1687 != null) {
                if (this.data.nether()) {
                    coords = coords + String.format(Locale.ROOT, " [%.1f, %.1f]", px * 8.0, pz * 8.0);
                } else if (this.mc.field_1687.method_27983() == class_1937.field_25179) {
                    coords = coords + String.format(Locale.ROOT, " [%.1f, %.1f]", px / 8.0, pz / 8.0);
                }
            }
            float w = r.textWidth(coords, ts, font);
            float x = 5.0f * u;
            float y = (float)fbH - 25.0f * u;
            r.round(x, y, w + 10.0f * u, rowH, radius, bg);
            r.text(coords, x + 5.0f * u, this.textY(y, rowH, ts, u), ts, font, PRIMARY);
        }

        if (this.showModules.getValue()) {
            this.drawModules(r, fbW, u, ts, rowH, radius, font, bg);
        }
    }

    private void drawModules(GuiRenderer r, int fbW, float u, float ts, float rowH, float radius, int font, int bg) {
        this.refreshSorted(r, ts, font);
        int count = this.sortedNames.length;
        float y = 5.0f * u;
        float right = (float)fbW - 5.0f * u;
        float barInset = Math.min(radius * 0.5f, 5.0f * u);
        for (int i = 0; i < count; ++i) {
            String name = this.sortedNames[i];
            float w = this.sortedWidths[i];
            int color = this.rainbow.getValue() ? this.accent((float)i * 0.04f) : this.blend(PRIMARY, SECONDARY, count <= 1 ? 0.0f : (float)i / (float)count);
            float boxW = w + 9.0f * u;
            r.round(right - boxW, y, boxW, rowH, radius, bg);
            r.rect(right - 2.0f * u, y + barInset, Math.max(1.0f, 2.0f * u), rowH - barInset * 2.0f, color);
            r.text(name, right - 5.0f * u - w, this.textY(y, rowH, ts, u), ts, font, color);
            y += 25.0f * u;
        }
    }

    private void refreshSorted(GuiRenderer r, float ts, int font) {
        List<String> source = this.data.modules();
        SortMode mode = (SortMode)this.moduleSort.getValue();
        int key = mode.ordinal() * 31 + font * 7 + Math.round(ts * 10.0f);
        if (source == this.sortSource && key == this.sortKey) return;
        this.sortSource = source;
        this.sortKey = key;
        record Row(String name, float width, int category) {}
        ArrayList<Row> rows = new ArrayList<Row>(source.size());
        for (String name : source) {
            rows.add(new Row(name, r.textWidth(name, ts, font), mode == SortMode.Category ? this.data.d(name) : 0));
        }
        switch (mode) {
            case Longest -> rows.sort((a, b) -> Float.compare(b.width(), a.width()));
            case Shortest -> rows.sort((a, b) -> Float.compare(a.width(), b.width()));
            case Alphabetical -> rows.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
            case Category -> rows.sort((a, b) -> a.category() != b.category() ? Integer.compare(a.category(), b.category()) : a.name().compareToIgnoreCase(b.name()));
        }
        this.sortedNames = new String[rows.size()];
        this.sortedWidths = new float[rows.size()];
        for (int i = 0; i < rows.size(); ++i) {
            this.sortedNames[i] = rows.get(i).name();
            this.sortedWidths[i] = rows.get(i).width();
        }
    }

    private float textY(float boxY, float boxH, float textSize, float u) {
        return boxY + (boxH - textSize) / 2.0f - 0.75f * u;
    }

    private int accent(float offset) {
        if (!this.rainbow.getValue()) return PRIMARY;
        float t = (float)(System.currentTimeMillis() % 1000000L) / 1000.0f;
        float hue = (t * (float)this.rainbowSpeed.getValue() * 0.1f + offset) % 1.0f;
        if (hue < 0.0f) {
            hue += 1.0f;
        }
        return 0xFF000000 | java.awt.Color.HSBtoRGB(hue, 0.55f, 1.0f) & 0xFFFFFF;
    }

    private int blend(int a, int b, float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        int rr = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * f);
        int gg = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * f);
        int bb = Math.round((a & 255) + ((b & 255) - (a & 255)) * f);
        return 0xFF000000 | rr << 16 | gg << 8 | bb;
    }

    // Singleplayer (nguon du lieu HUD) truy cap mc qua cac ham nay
    static class_310 w(HUD hUD) {
        return hUD.mc;
    }

    static class_310 f(HUD hUD) {
        return hUD.mc;
    }

    static class_310 n(HUD hUD) {
        return hUD.mc;
    }

    static class_310 L(HUD hUD) {
        return hUD.mc;
    }

    static class_310 c(HUD hUD) {
        return hUD.mc;
    }

    static class_310 N(HUD hUD) {
        return hUD.mc;
    }

    static class_310 b(HUD hUD) {
        return hUD.mc;
    }

    static class_310 t(HUD hUD) {
        return hUD.mc;
    }

    static class_310 P(HUD hUD) {
        return hUD.mc;
    }

    static class_310 l(HUD hUD) {
        return hUD.mc;
    }

    static class_310 G(HUD hUD) {
        return hUD.mc;
    }

    static class_310 E(HUD hUD) {
        return hUD.mc;
    }

    static class_310 r(HUD hUD) {
        return hUD.mc;
    }

    static class_310 B(HUD hUD) {
        return hUD.mc;
    }

    static class_310 e(HUD hUD) {
        return hUD.mc;
    }

    static class_310 V(HUD hUD) {
        return hUD.mc;
    }

    static class_310 W(HUD hUD) {
        return hUD.mc;
    }

    static class_310 X(HUD hUD) {
        return hUD.mc;
    }

    static class_310 C(HUD hUD) {
        return hUD.mc;
    }

    static class_310 j(HUD hUD) {
        return hUD.mc;
    }

    static class_310 K(HUD hUD) {
        return hUD.mc;
    }

    static class_310 i(HUD hUD) {
        return hUD.mc;
    }

    static class_310 k(HUD hUD) {
        return hUD.mc;
    }

    static class_310 q(HUD hUD) {
        return hUD.mc;
    }

    static class_310 o(HUD hUD) {
        return hUD.mc;
    }

    static class_310 H(HUD hUD) {
        return hUD.mc;
    }
}
