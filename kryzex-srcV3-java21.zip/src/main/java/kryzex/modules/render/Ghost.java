package kryzex.modules.render;

public enum Ghost {
    Ghost,
    Forged_3D,
    Spectral_3D;

}
