package kryzex.modules.render;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import kryzex.event.ChunkDataEvent;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.event.WorldRenderEvent;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.render.Block;
import kryzex.modules.render.NotifyMode;
import kryzex.util.DiscordWebhookURL;
import kryzex.util.InverseProjectionScratch;
import kryzex.util.ChunkUtil;
import kryzex.util.OriginX;
import kryzex.util.SecureString;
import kryzex.util.Start;
import kryzex.util.Title;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class BlockNotifier
extends Module {
    private static final int MAX_RENDERED = 4096;
    private final ListSetting blocks = BlockNotifier.n();
    private final CycleSetting<NotifyMode> notificationMode = new CycleSetting<NotifyMode>(SecureString.of("Notification Mode"), NotifyMode.BOTH, NotifyMode.class);
    private final BoolSetting disconnectOnFind = new BoolSetting(SecureString.of("Disconnect On Find"), false);
    private final BoolSetting notifications = new BoolSetting(SecureString.of("Notifications"), true);
    private final BoolSetting webhookEnabled = new BoolSetting(SecureString.of("Webhook Enabled"), false);
    private final StringSetting webhookUrl = new StringSetting(SecureString.of("Webhook URL"), "");
    private final BoolSetting selfPing = new BoolSetting(SecureString.of("Self Ping"), false);
    private final StringSetting discordId = new StringSetting(SecureString.of("Discord ID"), "");
    private final BoolSetting showEsp = new BoolSetting(SecureString.of("Show ESP"), true);
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
    private final BoolSetting outlines = new BoolSetting(SecureString.of("Outlines"), true);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), true);
    private final BoolSetting onlyNew = new BoolSetting(SecureString.of("Only Render New"), false);
    private final NumberSetting renderDistance = new NumberSetting(SecureString.of("Render Distance"), 0.0, 500.0, 0.0, 5.0);
    private final Map<class_2248, ToggleEntry> selected = new HashMap<class_2248, ToggleEntry>();
    private final Map<Long, List<Block>> perChunk = new HashMap<Long, List<Block>>();
    private final Set<class_2338> everFound = new HashSet<class_2338>();
    private final Set<class_2338> newFound = new HashSet<class_2338>();
    private final Queue<Long> scanQueue = new ArrayDeque<Long>();
    private final Set<Long> queued = new HashSet<Long>();
    private final Set<Long> scanned = new HashSet<Long>();
    private final List<kryzex.util.Color> boxes = new ArrayList<kryzex.util.Color>();
    private final List<Start> lines = new ArrayList<Start>();
    private Object trackedWorld;
    private int selectionSignature;
    private int ticks;
    private int totalFound;
    private static final String[] a = new String[]{"Notifies and highlights selected blocks when chunks load", "Notification Mode", "Target block found at ", "Outlines", "\u00a7b[Block Notifier] \u00a7fDeactivated. Found ", "Notifications", "Block Notifier", "Blocks To Find", "Alpha", "Singleplayer", "Self Ping", "Webhook URL", "Render Distance", "Block Notifier Alert", " at chunk ", "\u00a7b[Block Notifier] \u00a7f", "Only Render New", "Coordinates", "Discord ID", " x", "Disconnect On Find", "Show ESP", "Server", "Webhook Enabled", ", ", "Tracers", "Webhook failed: ", "Kryzex Block Notifier", "Block Notifier activated.", "Found ", " blocks this session.", "\u00a76[Block Notifier] \u00a7f", ", ", "<@"};

    public BlockNotifier() {
        super(SecureString.of("Block Notifier"), SecureString.of("Notifies and highlights selected blocks when chunks load"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.blocks, this.notificationMode, this.disconnectOnFind, this.notifications, this.webhookEnabled, this.webhookUrl, this.selfPing, this.discordId, this.showEsp, this.alpha, this.outlines, this.tracers, this.onlyNew, this.renderDistance});
    }

    private static ListSetting n() {
        ListSetting listSetting = new ListSetting(SecureString.of("Blocks To Find"));
        for (class_2248 class_22482 : class_7923.field_41175) {
            if (class_22482 == class_2246.field_10124 || class_22482 == class_2246.field_10543 || class_22482 == class_2246.field_10243) continue;
            class_2960 class_29602 = class_7923.field_41175.method_10221((class_2248)class_22482);
            Color color = Color.getHSBColor((float)(class_29602.toString().hashCode() & 0xFFFF) / 65535.0f, 0.7f, 1.0f);
            listSetting.add(class_29602.toString(), class_22482.method_9518().getString(), class_22482.method_8389(), false, color);
        }
        return listSetting;
    }

    @Override
    public void onEnable() {
        this.S();
        this.trackedWorld = this.mc.field_1687;
        this.D();
        this.M();
        this.h("Block Notifier activated.");
        super.onEnable();
    }

    @Override
    public void onDisable() {
        int n = this.totalFound;
        this.S();
        if (this.notifications.getValue() && this.mc.field_1724 != null) {
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7b[Block Notifier] \u00a7fDeactivated. Found " + n + " blocks this session.")), false);
        }
        super.onDisable();
    }

    private void S() {
        this.selected.clear();
        this.perChunk.clear();
        this.everFound.clear();
        this.newFound.clear();
        this.scanQueue.clear();
        this.queued.clear();
        this.scanned.clear();
        this.boxes.clear();
        this.lines.clear();
        this.trackedWorld = null;
        this.selectionSignature = 0;
        this.ticks = 0;
        this.totalFound = 0;
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.U(chunkDataEvent.packet.method_11523(), chunkDataEvent.packet.method_11524());
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        int n;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) return;
        if (this.trackedWorld != this.mc.field_1687) {
            this.S();
            this.trackedWorld = this.mc.field_1687;
            this.D();
            this.M();
        }
        if ((n = this.J()) != this.selectionSignature) {
            this.perChunk.clear();
            this.everFound.clear();
            this.newFound.clear();
            this.scanQueue.clear();
            this.queued.clear();
            this.scanned.clear();
            this.totalFound = 0;
            this.D();
            this.M();
        }
        if (this.selected.isEmpty()) return;
        ++this.ticks;
        if (this.ticks % 100 == 1) {
            this.M();
        }
        if (this.ticks % 400 == 0) {
            this.scanned.clear();
        }
        this.W();
        if (this.ticks % 20 != 0) return;
        this.perChunk.keySet().removeIf(this::lmbd$onTick$0);
    }

    private int J() {
        int n = 1;
        for (ToggleEntry toggleEntry : this.blocks.entries()) {
            if (!toggleEntry.enabled()) continue;
            n = 31 * n + toggleEntry.id().hashCode();
        }
        return n;
    }

    private void D() {
        this.selected.clear();
        for (ToggleEntry toggleEntry : this.blocks.entries()) {
            if (!toggleEntry.enabled()) continue;
            class_7923.field_41175.method_10223(class_2960.method_60654((String)toggleEntry.id())).ifPresent(arg_0 -> this.lmbd$refreshSelection$0(toggleEntry, arg_0));
        }
        this.selectionSignature = this.J();
    }

    private void M() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.selected.isEmpty()) return;
        class_1923 class_19232 = this.mc.field_1724.method_31476();
        List<class_2818> list = ChunkUtil.getLoadedChunksList();
        list.sort(Comparator.comparingInt(arg_0 -> BlockNotifier.lmbd$enqueueLoaded$0(class_19232, arg_0)));
        for (class_2818 class_28182 : list) {
            this.U(class_28182.method_12004().field_9181, class_28182.method_12004().field_9180);
        }
    }

    private void U(int n, int n2) {
        long l = class_1923.method_8331((int)n, (int)n2);
        if (this.selected.isEmpty() || this.scanned.contains(l) || !this.queued.add(l)) return;
        this.scanQueue.offer(l);
    }

    private void W() {
        Long l = this.scanQueue.poll();
        if (l == null) return;
        this.queued.remove(l);
        this.scanned.add(l);
        int n = class_1923.method_8325((long)l);
        int n2 = class_1923.method_8332((long)l);
        if (!this.mc.field_1687.method_8393(n, n2)) return;
        class_2818 class_28182 = this.mc.field_1687.method_8497(n, n2);
        ArrayList<Block> arrayList = new ArrayList<Block>();
        HashMap<class_2248, Integer> hashMap = new HashMap<class_2248, Integer>();
        class_2826[] class_2826Array = class_28182.method_12006();
        int n3 = class_28182.method_32891();
        for (int i = 0; i < class_2826Array.length; ++i) {
            class_2826 class_28262 = class_2826Array[i];
            if (class_28262 == null || !class_28262.method_12265().method_19526(this::lmbd$scanOne$0)) continue;
            int n4 = n3 + i << 4;
            for (int j = 0; j < 16; ++j) {
                for (int k = 0; k < 16; ++k) {
                    for (int i2 = 0; i2 < 16; ++i2) {
                        class_2248 class_22482 = class_28262.method_12254(i2, j, k).method_26204();
                        if (!this.selected.containsKey(class_22482)) continue;
                        class_2338 class_23382 = new class_2338(class_28182.method_12004().method_8326() + i2, n4 + j, class_28182.method_12004().method_8328() + k);
                        arrayList.add(new Block(class_23382, class_22482));
                        if (!this.everFound.add(class_23382)) continue;
                        this.newFound.add(class_23382);
                        ++this.totalFound;
                        hashMap.merge(class_22482, 1, Integer::sum);
                    }
                }
            }
        }
        if (arrayList.isEmpty()) {
            this.perChunk.remove(l);
        } else {
            this.perChunk.put(l, List.copyOf(arrayList));
        }
        if (hashMap.isEmpty()) return;
        this.C(class_28182.method_12004(), hashMap);
    }

    private void C(class_1923 class_19232, Map<class_2248, Integer> map) {
        String[] stringArray;
        int n = class_19232.method_33940();
        int n2 = class_19232.method_33942();
        StringBuilder stringBuilder = new StringBuilder();
        for (Map.Entry<class_2248, Integer> entry : map.entrySet()) {
            if (!stringBuilder.isEmpty()) {
                stringArray = a;
                stringBuilder.append(", ");
            }
            stringArray = a;
            stringBuilder.append(entry.getKey().method_9518().getString()).append(" x").append(entry.getValue());
        }
        int n3 = n2;
        int n4 = n;
        String string = String.valueOf(stringBuilder);
        stringArray = a;
        String string2 = "Found " + string + " at chunk " + n4 + ", " + n3;
        if (this.notificationMode.isMode(NotifyMode.CHAT) || this.notificationMode.isMode(NotifyMode.BOTH)) {
            this.h(string2);
        }
        if ((this.notificationMode.isMode(NotifyMode.TOAST) || this.notificationMode.isMode(NotifyMode.BOTH)) && this.mc.field_1724 != null) {
            stringArray = a;
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a76[Block Notifier] \u00a7f" + (String)string2)), true);
        }
        if (this.webhookEnabled.getValue() && !this.webhookUrl.getValue().isBlank()) {
            this.X(string2, n, n2);
        }
        if (!this.disconnectOnFind.getValue() || this.mc.method_1562() == null) return;
        this.toggle(false);
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("Target block found at " + n + ", " + n2)));
    }

    private void X(String string, int n, int n2) {
        String string2 = this.webhookUrl.getValue().trim();
        String string3 = this.selfPing.getValue() && !this.discordId.getValue().isBlank() ? "<@" + this.discordId.getValue().trim() + ">" : null;
        String string4 = this.mc.method_1558() == null ? "Singleplayer" : this.mc.method_1558().field_3761;
        CompletableFuture.runAsync(() -> this.lmbd$sendWebhook$0(string2, string3, string, n, n2, string4));
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1724 == null || this.perChunk.isEmpty() || !this.showEsp.getValue() && !this.tracers.getValue() || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        this.boxes.clear();
        this.lines.clear();
        class_243 class_2432 = InverseProjectionScratch.getTracerStart(class_41842);
        double d = this.renderDistance.getValue();
        int n = 0;
        block0: for (List<Block> list : this.perChunk.values()) {
            for (Block block : list) {
                ToggleEntry toggleEntry;
                if (!this.tracers.getValue() && !OriginX.box(block.pos.method_10263(), block.pos.method_10264(), block.pos.method_10260(), block.pos.method_10263() + 1, block.pos.method_10264() + 1, block.pos.method_10260() + 1) || this.onlyNew.getValue() && !this.newFound.contains(block.pos) || d > 0.0 && this.mc.field_1724.method_5707(class_243.method_24953((class_2382)block.pos)) > d * d || (toggleEntry = this.selected.get(block.block)) == null) continue;
                Color color = toggleEntry.color();
                Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.alpha.getIntValue());
                if (this.showEsp.getValue()) {
                    double d2 = this.outlines.getValue() ? 0.05 : 0.0;
                    this.boxes.add(new kryzex.util.Color((double)block.pos.method_10263() + d2, (double)block.pos.method_10264() + d2, (double)block.pos.method_10260() + d2, (double)(block.pos.method_10263() + 1) - d2, (double)(block.pos.method_10264() + 1) - d2, (double)(block.pos.method_10260() + 1) - d2, color2));
                }
                if (this.tracers.getValue()) {
                    this.lines.add(new Start(class_2432, class_243.method_24953((class_2382)block.pos), color2, 1.5f));
                }
                if (++n < 4096) continue;
                continue block0;
            }
        }
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.boxes);
        InverseProjectionScratch.renderLines(class_45872, this.lines);
        class_45872.method_22909();
    }

    private void h(String string) {
        if (!this.notifications.getValue() || this.mc.field_1724 == null) return;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7b[Block Notifier] \u00a7f" + string)), false);
    }

    public int g() {
        return this.totalFound;
    }

    private void lmbd$sendWebhook$0(String string, String string2, String string3, int n, int n2, String string4) {
        try {
            DiscordWebhookURL discordWebhookURL = new DiscordWebhookURL(string);
            String[] stringArray = a;
            discordWebhookURL.b("Kryzex Block Notifier");
            if (string2 != null) {
                discordWebhookURL.a(string2);
            }
            discordWebhookURL.addEmbed(new Title().setTitle("Block Notifier Alert").setDescription(string3).setColor(new Color(120, 190, 255)).addField("Coordinates", n + ", " + n2, true).addField("Server", string4, true));
            discordWebhookURL.execute();
            return;
        }
        catch (Exception exception) {
            this.mc.execute(() -> this.lmbd$sendWebhook$1(exception));
        }
    }

    private void lmbd$sendWebhook$1(Exception exception) {
        this.h("Webhook failed: " + exception.getMessage());
    }

    private boolean lmbd$scanOne$0(class_2680 class_26802) {
        return this.selected.containsKey(class_26802.method_26204());
    }

    private static int lmbd$enqueueLoaded$0(class_1923 class_19232, class_2818 class_28182) {
        return Math.max(Math.abs(class_28182.method_12004().field_9181 - class_19232.field_9181), Math.abs(class_28182.method_12004().field_9180 - class_19232.field_9180));
    }

    private void lmbd$refreshSelection$0(ToggleEntry toggleEntry, class_6880.class_6883 class_68832) {
        this.selected.put((class_2248)class_68832.comp_349(), toggleEntry);
    }

    private boolean lmbd$onTick$0(Long l) {
        if (this.mc.field_1687.method_8393(class_1923.method_8325((long)l), class_1923.method_8332((long)l))) return false;
        return true;
    }
}
