package kryzex.modules.render;

import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.render.Pickaxes;
import kryzex.util.SecureString;
import kryzex.weapon.KnifeManager;

public final class CSGOKnifes
extends Module {
    public static BoolSetting intro;
    public static CycleSetting<Pickaxes> show;
    public static NumberSetting volume;
    public static KeybindSetting inspectKey;
    public static BoolSetting spinInspectOnly;
    private static CSGOKnifes instance;
    private static String[] a;

    public CSGOKnifes() {
        super(SecureString.of("CSGO Knifes"), SecureString.of("A case opening and an equippable galaxy butterfly knife"), -1, Category.RENDER);
        String[] stringArray = a;
        this.addSettings(new Setting[]{intro, show, volume, inspectKey, spinInspectOnly, new ActionSetting(SecureString.of(stringArray[11]), KnifeManager::openCase).setDescription(SecureString.of("Open the Kryzex Case again"))});
        instance = this;
    }

    public static boolean H() {
        if (instance == null) return false;
        if (!instance.isEnabled()) return false;
        return true;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        KnifeManager.enable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        KnifeManager.disable();
    }

    static {
        String[] stringArray = a = new String[]{"Case opening volume", "When the butterfly knife replaces your first-person main hand (default: any pickaxe)", "Volume", "Play Intro", "Open the Kryzex Case again", "Always play the spinning inspect animation", "Open the case every time the module is enabled", "CSGO Knifes", "Spin Inspect Only", "A case opening and an equippable galaxy butterfly knife", "Show Knife", "Open Case", "Inspect Key"};
        intro = new BoolSetting(SecureString.of(stringArray[3]), true).setDescription(SecureString.of(stringArray[6]));
        show = new CycleSetting<Pickaxes>(SecureString.of(stringArray[10]), Pickaxes.Pickaxes, Pickaxes.class).setDescription(SecureString.of(stringArray[1]));
        volume = new NumberSetting(SecureString.of(stringArray[2]), 0.0, 100.0, 80.0, 1.0).getValue(SecureString.of(stringArray[0]));
        inspectKey = new KeybindSetting(SecureString.of(stringArray[12]), 71, false);
        spinInspectOnly = new BoolSetting(SecureString.of(stringArray[8]), false).setDescription(SecureString.of(stringArray[5]));
    }
}
