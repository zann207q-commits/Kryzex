package kryzex.modules.render;

import java.util.ArrayList;
import java.util.List;
import kryzex.event.MacroRender3DEvent;
import kryzex.mixin.BlockOverlayDestroyProgressMixin;
import kryzex.mixin.SHOULDRenderBlockOUTLINEMixin;
import kryzex.module.MacroCategories;
import kryzex.module.MacroSubscribe;
import kryzex.module.settings.MacroBoolSetting;
import kryzex.module.settings.MacroColorSetting;
import kryzex.module.settings.MacroModeSetting;
import kryzex.module.settings.MacroNumberSetting;
import kryzex.modules.misc.MacroModule;
import kryzex.modules.render.SwitchMapNetMinecraftUtilMathDirectionAxis;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12178;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_2244;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_2756;
import net.minecraft.class_2769;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_9848;

@Environment(value=EnvType.CLIENT)
public final class BlockOverlay
extends MacroModule {
    private static String BOTH;
    private static String OUTLINE;
    private static String FILL;
    private static String GRADIENT;
    private static String SOLID;
    private static String RAINBOW;
    private static final float FADE_IN = 0.12f;
    private static final float FADE_OUT = 0.2f;
    private static final double SNAP_DISTANCE = 6.0;
    private static final float FLOW_SPEED = 0.35f;
    private static final double SEGMENT = 0.125;
    private static final double FILL_INFLATE = 0.002;
    private static final double LINE_LIFT = 0.004;
    private static final double GLOW_LIFT = 0.002;
    private final MacroModeSetting style = this.addSetting("style", new MacroModeSetting("Style", "Both", "Both", "Outline", "Fill"));
    private final MacroModeSetting colorMode = this.addSetting("color-mode", new MacroModeSetting("Color Mode", "Gradient", "Gradient", "Solid", "Rainbow"));
    private final MacroColorSetting color = this.addSetting("color", new MacroColorSetting("Color", -871878));
    private final MacroColorSetting secondColor = this.addSetting("second-color", new MacroColorSetting("Second Color", -6480));
    private final MacroBoolSetting flow = this.addSetting("flow", new MacroBoolSetting("Flow", true));
    private final MacroNumberSetting fillOpacity = this.addSetting("fill-opacity", new MacroNumberSetting("Fill Opacity", 20.0f, 2.0f, 60.0f).step(1.0f));
    private final MacroNumberSetting width = this.addSetting("width", new MacroNumberSetting("Width", 2.0f, 1.0f, 5.0f).step(0.5f));
    private final MacroBoolSetting glow = this.addSetting("glow", new MacroBoolSetting("Glow", true));
    private final MacroBoolSetting smooth = this.addSetting("smooth", new MacroBoolSetting("Smooth", true));
    private final MacroNumberSetting smoothSpeed = this.addSetting("smooth-speed", new MacroNumberSetting("Smooth Speed", 16.0f, 4.0f, 40.0f).step(1.0f));
    private final MacroBoolSetting miningProgress = this.addSetting("mining-progress", new MacroBoolSetting("Mining Progress", true));
    private final MacroBoolSetting faceOnly = this.addSetting("face-only", new MacroBoolSetting("Face Only", false));
    private final MacroBoolSetting seeThrough = this.addSetting("see-through", new MacroBoolSetting("See Through", false));
    private class_638 level;
    private class_2338 pos;
    private class_2680 state;
    private class_2338 partner;
    private class_2680 partnerState;
    private final List<double[]> edges = new ArrayList<double[]>();
    private List<class_238> boxes = List.of();
    private class_238 localBounds;
    private class_238 goal;
    private class_238 box;
    private class_2350 face;
    private class_238 faceBox;
    private float presence;
    private float progress;
    private long lastFrame;
    private class_243 eye;
    private double time;
    private float fade;
    private double ax;
    private double bx;
    private double ay;
    private double by;
    private double az;
    private double bz;
    private static String[] a;

    public BlockOverlay() {
        super("block-overlay", "Block Overlay", "A smooth, animated outline and fill on the block you look at.", MacroCategories.VISUALS);
        this.secondColor.visibleWhen(this::lmbd$new$0);
        this.flow.visibleWhen(this::lmbd$new$1);
        this.fillOpacity.visibleWhen(this::lmbd$new$2);
        this.width.visibleWhen(this::lmbd$new$3);
        this.glow.visibleWhen(this::lmbd$new$4);
        this.smoothSpeed.visibleWhen(this.smooth::get);
    }

    @Override
    public void onDisable() {
        this.n();
    }

    @MacroSubscribe
    public void onMacroRender3D(MacroRender3DEvent macroRender3DEvent) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 != null && class_3102.field_1724 != null) {
            if (class_3102.field_1687 != this.level) {
                this.n();
                this.level = class_3102.field_1687;
            }
            long l = System.nanoTime();
            float f = this.lastFrame == 0L ? 0.0f : Math.min((float)(l - this.lastFrame) / 1.0E9f, 0.1f);
            this.lastFrame = l;
            class_3965 class_39652 = BlockOverlay.O(class_3102);
            if (class_39652 != null && this.I(class_3102, class_39652)) {
                this.box = this.box != null && !(this.presence < 0.02f) && this.smooth.get() && !(this.box.method_1005().method_1022(this.goal.method_1005()) > 6.0) ? BlockOverlay.c(this.box, this.goal, 1.0f - (float)Math.exp(-this.smoothSpeed.get() * f)) : this.goal;
                this.presence = Math.min(1.0f, this.presence + f / 0.12f);
            } else {
                class_39652 = null;
                this.presence = Math.max(0.0f, this.presence - f / 0.2f);
                if (this.presence == 0.0f) {
                    this.n();
                    this.level = class_3102.field_1687;
                    return;
                }
            }
            if (this.box == null) return;
            this.l(class_3102, f, class_39652 != null);
            this.eye = class_3102.field_1773.method_19418().method_71156();
            this.time = (double)(l % 3600000000000L) / 1.0E9;
            this.k();
            return;
        } else {
            this.n();
        }
    }

    private static class_3965 O(class_310 class_3102) {
        class_239 class_2392 = class_3102.field_1765;
        if (!(class_2392 instanceof class_3965)) return null;
        class_3965 class_39652 = (class_3965)class_2392;
        if (class_39652.method_17783() != class_239.class_240.field_1332) return null;
        if (class_39652.method_17781()) {
            return null;
        }
        if (!((SHOULDRenderBlockOUTLINEMixin)class_3102.field_1773).kryzex$shouldRenderBlockOutline()) {
            return null;
        }
        class_2338 blockPos = class_39652.method_17777();
        if (class_3102.field_1687.method_8320(blockPos).method_26215()) return null;
        if (!class_3102.field_1687.method_8621().method_11952(blockPos)) return null;
        class_3965 class_39653 = class_39652;
        return class_39653;
    }

    private boolean I(class_310 class_3102, class_3965 class_39652) {
        class_2680 class_26802;
        class_2338 class_23382;
        class_638 class_6382 = class_3102.field_1687;
        class_2338 class_23383 = class_39652.method_17777();
        class_2338 class_23384 = BlockOverlay.q(class_6382, class_23383, class_6382.method_8320(class_23383));
        class_2338 class_23385 = class_23382 = class_23384 != null && class_23384.method_10265((class_2382)class_23383) < 0 ? class_23384 : class_23383;
        class_2338 class_23386 = class_23384 == null ? null : (class_23382.equals((Object)class_23383) ? class_23384 : class_23383);
        class_2680 class_26803 = class_6382.method_8320(class_23382);
        class_2680 class_26804 = class_26802 = class_23386 == null ? null : class_6382.method_8320(class_23386);
        if (!class_23382.equals((Object)this.pos) || class_26803 != this.state || class_26802 != this.partnerState) {
            class_1297 class_12972 = class_3102.method_1560();
            class_3726 class_37262 = class_12972 == null ? class_3726.method_16194() : class_3726.method_16195((class_1297)class_12972);
            class_265 class_2652 = class_26803.method_26172((class_1922)class_6382, class_23382, class_37262);
            if (class_23386 != null) {
                class_2652 = class_259.method_1084((class_265)class_2652, (class_265)class_26802.method_26172((class_1922)class_6382, class_23386, class_37262).method_66507((class_2382)class_23386.method_10059((class_2382)class_23382)));
            }
            if ((class_2652 = class_2652.method_1097()).method_1110()) {
                return false;
            }
            if (!class_23382.equals((Object)this.pos)) {
                this.progress = 0.0f;
            }
            this.pos = class_23382;
            this.state = class_26803;
            this.partner = class_23386;
            this.partnerState = class_26802;
            this.edges.clear();
            class_2652.method_1104(this::lmbd$adopt$0);
            this.boxes = class_2652.method_1090();
            this.localBounds = class_2652.method_1107();
            this.goal = this.localBounds.method_996(class_23382);
        }
        this.face = class_39652.method_17780();
        this.faceBox = this.L(class_39652.method_17784().method_1023((double)this.pos.method_10263(), (double)this.pos.method_10264(), (double)this.pos.method_10260()));
        return true;
    }

    private static class_2338 q(class_638 class_6382, class_2338 class_23382, class_2680 class_26802) {
        class_2338 class_23383 = null;
        if (class_26802.method_28498((class_2769)class_2741.field_12533)) {
            class_23383 = class_26802.method_11654((class_2769)class_2741.field_12533) == class_2756.field_12607 ? class_23382.method_10084() : class_23382.method_10074();
        } else if (class_26802.method_26204() instanceof class_2244) {
            class_23383 = class_23382.method_10093(class_2244.method_24163((class_2680)class_26802));
        } else if (class_26802.method_26204() instanceof class_2281 && class_26802.method_11654((class_2769)class_2281.field_10770) != class_2745.field_12569) {
            class_23383 = class_2281.method_72581((class_2338)class_23382, (class_2680)class_26802);
        }
        if (class_23383 == null) return null;
        if (!class_6382.method_8320(class_23383).method_27852(class_26802.method_26204())) return null;
        class_2338 class_23384 = class_23383;
        return class_23384;
    }

    private class_238 L(class_243 class_2432) {
        double d = 0.001;
        for (class_238 class_2383 : this.boxes) {
            boolean bl;
            if (!(bl = (switch (SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[this.face.ordinal()]) {
                default -> throw new MatchException(null, null);
                case 1 -> {
                    if (Math.abs(class_2432.field_1352 - class_2383.field_1320) < d) {
                        yield true;
                    }
                    yield false;
                }
                case 2 -> {
                    if (Math.abs(class_2432.field_1352 - class_2383.field_1323) < d) {
                        yield true;
                    }
                    yield false;
                }
                case 3 -> {
                    if (Math.abs(class_2432.field_1351 - class_2383.field_1325) < d) {
                        yield true;
                    }
                    yield false;
                }
                case 4 -> {
                    if (Math.abs(class_2432.field_1351 - class_2383.field_1322) < d) {
                        yield true;
                    }
                    yield false;
                }
                case 5 -> {
                    if (Math.abs(class_2432.field_1350 - class_2383.field_1324) < d) {
                        yield true;
                    }
                    yield false;
                }
                case 6 -> Math.abs(class_2432.field_1350 - class_2383.field_1321) < d;
            })) || !class_2383.method_1014(d).method_1006(class_2432)) continue;
            return class_2383;
        }
        return this.localBounds;
    }

    private void l(class_310 class_3102, float f, boolean bl) {
        BlockOverlayDestroyProgressMixin blockOverlayDestroyProgressMixin;
        class_2338 class_23382;
        float f2 = 0.0f;
        class_636 class_6362 = class_3102.field_1761;
        if (bl && this.miningProgress.get() && class_6362 != null && class_6362.method_2923() && (class_23382 = (blockOverlayDestroyProgressMixin = (BlockOverlayDestroyProgressMixin)class_6362).kryzex$blockOverlayDestroyPos()) != null && (class_23382.equals((Object)this.pos) || class_23382.equals((Object)this.partner))) {
            f2 = class_3532.method_15363((float)blockOverlayDestroyProgressMixin.kryzex$blockOverlayDestroyProgress(), 0.0f, 1.0f);
        }
        this.progress += (f2 - this.progress) * (1.0f - (float)Math.exp(-18.0f * f));
    }

    private void n() {
        this.level = null;
        this.pos = null;
        this.state = null;
        this.partner = null;
        this.partnerState = null;
        this.edges.clear();
        this.boxes = List.of();
        this.localBounds = null;
        this.goal = null;
        this.box = null;
        this.face = null;
        this.faceBox = null;
        this.presence = 0.0f;
        this.progress = 0.0f;
        this.lastFrame = 0L;
    }

    private void k() {
        this.fade = this.presence * this.presence * (3.0f - 2.0f * this.presence);
        double d = 0.94 + 0.06 * (double)this.fade;
        double[] dArray = BlockOverlay.T(this.box.field_1323, this.box.field_1320, this.goal.field_1323, this.goal.field_1320, (double)this.pos.method_10263() - this.goal.field_1323, d);
        double[] dArray2 = BlockOverlay.T(this.box.field_1322, this.box.field_1325, this.goal.field_1322, this.goal.field_1325, (double)this.pos.method_10264() - this.goal.field_1322, d);
        double[] dArray3 = BlockOverlay.T(this.box.field_1321, this.box.field_1324, this.goal.field_1321, this.goal.field_1324, (double)this.pos.method_10260() - this.goal.field_1321, d);
        this.ax = dArray[0];
        this.bx = dArray[1];
        this.ay = dArray2[0];
        this.by = dArray2[1];
        this.az = dArray3[0];
        this.bz = dArray3[1];
        boolean bl = !this.style.is("Fill");
        boolean bl2 = !this.style.is("Outline");
        float f = this.fillOpacity.get() / 100.0f;
        if (bl2) {
            if (this.faceOnly.get()) {
                this.u(this.faceBox, this.face, f, 0.002);
            } else {
                for (class_238 class_2383 : this.boxes) {
                    this.t(class_2383, f, 0.002);
                }
            }
        }
        if (this.progress > 0.01f) {
            this.J(Math.min(0.45f, f * 1.4f + 0.16f));
        }
        if (!bl) return;
        this.i(this.faceOnly.get() ? BlockOverlay.N(this.faceBox, this.face) : this.edges);
    }

    private static double[] T(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d4 - d3;
        double d8 = d7 > 1.0E-6 ? (d2 - d) / d7 : 1.0;
        double d9 = (d + d2) * 0.5;
        double d10 = d9 * (1.0 - d6) + (d + d5 * d8) * d6;
        return new double[]{d10, d8 * d6};
    }

    private class_243 U(double d, double d2, double d3) {
        return new class_243(this.ax + this.bx * d, this.ay + this.by * d2, this.az + this.bz * d3);
    }

    private void i(List<double[]> list) {
        boolean bl = !this.colorMode.is("Solid");
        ArrayList<double[]> arrayList = new ArrayList<double[]>(list.size() * 4);
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>(list.size() * 4);
        for (double[] dArray : list) {
            double d = Math.sqrt(BlockOverlay.E(dArray[3] - dArray[0]) + BlockOverlay.E(dArray[4] - dArray[1]) + BlockOverlay.E(dArray[5] - dArray[2]));
            int n = bl ? class_3532.method_15340((int)((int)Math.ceil(d / 0.125)), 1, 16) : 1;
            for (int i = 0; i < n; ++i) {
                double d2 = (double)i / (double)n;
                double d3 = (double)(i + 1) / (double)n;
                double d4 = (d2 + d3) * 0.5;
                arrayList.add(new double[]{class_3532.method_16436((double)d2, (double)dArray[0], (double)dArray[3]), class_3532.method_16436((double)d2, (double)dArray[1], (double)dArray[4]), class_3532.method_16436((double)d2, (double)dArray[2], (double)dArray[5]), class_3532.method_16436((double)d3, (double)dArray[0], (double)dArray[3]), class_3532.method_16436((double)d3, (double)dArray[1], (double)dArray[4]), class_3532.method_16436((double)d3, (double)dArray[2], (double)dArray[5])});
                arrayList2.add(this.r(class_3532.method_16436((double)d4, (double)dArray[0], (double)dArray[3]), class_3532.method_16436((double)d4, (double)dArray[1], (double)dArray[4]), class_3532.method_16436((double)d4, (double)dArray[2], (double)dArray[5])));
            }
        }
        float f = this.width.get();
        if (this.glow.get()) {
            for (int i = 0; i < arrayList.size(); ++i) {
                double[] dArray = (double[])arrayList.get(i);
                int n = (Integer)arrayList2.get(i);
                this.C(dArray, class_9848.method_75601((int)n, (float)(0.34f * this.fade)), f + 3.0f, 0.002);
                this.C(dArray, class_9848.method_75601((int)n, (float)(0.13f * this.fade)), f + 8.0f, 0.002);
            }
        }
        for (int i = 0; i < arrayList.size(); ++i) {
            this.C((double[])arrayList.get(i), class_9848.method_75601((int)((Integer)arrayList2.get(i)), (float)this.fade), f, 0.004);
        }
    }

    private void C(double[] dArray, int n, float f, double d) {
        class_12178 class_121782 = class_12180.method_75546((class_243)this.d(this.U(dArray[0], dArray[1], dArray[2]), d), (class_243)this.d(this.U(dArray[3], dArray[4], dArray[5]), d), (int)n, (float)f);
        if (!this.seeThrough.get()) return;
        class_121782.method_75533();
    }

    private class_243 d(class_243 class_2432, double d) {
        class_243 class_2433 = this.eye.method_1020(class_2432);
        double d2 = class_2433.method_1033();
        return d2 < 1.0E-6 ? class_2432 : class_2432.method_1019(class_2433.method_1021(d / d2));
    }

    private void t(class_238 class_2383, float f, double d) {
        for (class_2350 class_23502 : class_2350.values()) {
            this.u(class_2383, class_23502, f, d);
        }
    }

    private void u(class_238 class_2383, class_2350 class_23502, float f, double d) {
        class_243 class_2432 = this.U(class_2383.field_1323, class_2383.field_1322, class_2383.field_1321).method_1023(d, d, d);
        class_243 class_2433 = this.U(class_2383.field_1320, class_2383.field_1325, class_2383.field_1324).method_1031(d, d, d);
        class_243 class_2434 = BlockOverlay.p(class_2383, class_23502);
        int n = this.r(class_2434.field_1352, class_2434.field_1351, class_2434.field_1350);
        int n2 = class_3532.method_15340((int)Math.round(f * this.fade * 255.0f), 0, 255) << 24 | n & 0xFFFFFF;
        class_12178 class_121782 = class_12180.method_75548((class_243)class_2432, (class_243)class_2433, (class_2350)class_23502, (class_12179)class_12179.method_75539((int)n2));
        if (!this.seeThrough.get()) return;
        class_121782.method_75533();
    }

    private void J(float f) {
        double d = 0.004;
        if (this.faceOnly.get()) {
            class_238 class_2383 = this.faceBox;
            class_238 class_2384 = this.face.method_10166() == class_2350.class_2351.field_11052 ? class_2383.method_35580(class_2383.method_17939() * (double)(1.0f - this.progress) * 0.5, 0.0, class_2383.method_17941() * (double)(1.0f - this.progress) * 0.5) : new class_238(class_2383.field_1323, class_2383.field_1322, class_2383.field_1321, class_2383.field_1320, class_2383.field_1322 + class_2383.method_17940() * (double)this.progress, class_2383.field_1324);
            this.u(class_2384, this.face, f, d);
            return;
        } else {
            double d2 = this.localBounds.field_1322 + this.localBounds.method_17940() * (double)this.progress;
            for (class_238 class_2385 : this.boxes) {
                if (class_2385.field_1322 >= d2) continue;
                this.t(new class_238(class_2385.field_1323, class_2385.field_1322, class_2385.field_1321, class_2385.field_1320, Math.min(class_2385.field_1325, d2), class_2385.field_1324), f, d);
            }
        }
    }

    private int r(double d, double d2, double d3) {
        double d4;
        int n = this.color.argb();
        if (this.colorMode.is("Solid")) {
            return n;
        }
        double d5 = (BlockOverlay.X(d, this.localBounds.field_1323, this.localBounds.field_1320) + BlockOverlay.X(d2, this.localBounds.field_1322, this.localBounds.field_1325) + BlockOverlay.X(d3, this.localBounds.field_1321, this.localBounds.field_1324)) / 3.0;
        double d6 = d4 = this.flow.get() ? this.time * (double)0.35f : 0.0;
        if (this.colorMode.is("Rainbow")) {
            double d7 = d5 * 0.5 - d4;
            return n & 0xFF000000 | class_3532.method_15369((float)((float)(d7 - Math.floor(d7))), 0.65f, 1.0f) & 0xFFFFFF;
        }
        double d8 = this.flow.get() ? 0.5 - 0.5 * Math.cos(Math.PI * 2 * (d5 - d4)) : d5;
        return class_9848.method_61319((float)((float)d8), (int)n, (int)this.secondColor.argb());
    }

    private static double X(double d, double d2, double d3) {
        if (d3 - d2 < 1.0E-6) {
            return 0.5;
        }
        double d4 = (d - d2) / (d3 - d2);
        return d4;
    }

    private static class_243 p(class_238 class_2383, class_2350 class_23502) {
        class_243 class_2432;
        class_243 class_2433 = class_2383.method_1005();
        switch (SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_23502.ordinal()]) {
            default: {
                throw new MatchException(null, null);
            }
            case 1: {
                class_2432 = new class_243(class_2383.field_1320, class_2433.field_1351, class_2433.field_1350);
                return class_2432;
            }
            case 2: {
                class_2432 = new class_243(class_2383.field_1323, class_2433.field_1351, class_2433.field_1350);
                return class_2432;
            }
            case 3: {
                class_2432 = new class_243(class_2433.field_1352, class_2383.field_1325, class_2433.field_1350);
                return class_2432;
            }
            case 4: {
                class_2432 = new class_243(class_2433.field_1352, class_2383.field_1322, class_2433.field_1350);
                return class_2432;
            }
            case 5: {
                class_2432 = new class_243(class_2433.field_1352, class_2433.field_1351, class_2383.field_1324);
                return class_2432;
            }
            case 6: {
                class_2432 = new class_243(class_2433.field_1352, class_2433.field_1351, class_2383.field_1321);
            }
        }
        return class_2432;
    }

    private static List<double[]> N(class_238 class_2383, class_2350 class_23502) {
        double[][] dArrayArray;
        switch (class_23502.method_10166()) {
            default: {
                throw new MatchException(null, null);
            }
            case field_11048: {
                double d = class_23502 == class_2350.field_11034 ? class_2383.field_1320 : class_2383.field_1323;
                double[][] dArrayArray2 = new double[4][];
                dArrayArray2[0] = new double[]{d, class_2383.field_1322, class_2383.field_1321};
                dArrayArray2[1] = new double[]{d, class_2383.field_1325, class_2383.field_1321};
                dArrayArray2[2] = new double[]{d, class_2383.field_1325, class_2383.field_1324};
                dArrayArray = dArrayArray2;
                dArrayArray2[3] = new double[]{d, class_2383.field_1322, class_2383.field_1324};
                break;
            }
            case field_11052: {
                double d = class_23502 == class_2350.field_11036 ? class_2383.field_1325 : class_2383.field_1322;
                double[][] dArrayArray3 = new double[4][];
                dArrayArray3[0] = new double[]{class_2383.field_1323, d, class_2383.field_1321};
                dArrayArray3[1] = new double[]{class_2383.field_1320, d, class_2383.field_1321};
                dArrayArray3[2] = new double[]{class_2383.field_1320, d, class_2383.field_1324};
                dArrayArray = dArrayArray3;
                dArrayArray3[3] = new double[]{class_2383.field_1323, d, class_2383.field_1324};
                break;
            }
            case field_11051: {
                double d = class_23502 == class_2350.field_11035 ? class_2383.field_1324 : class_2383.field_1321;
                double[][] dArrayArray4 = new double[4][];
                dArrayArray4[0] = new double[]{class_2383.field_1323, class_2383.field_1322, d};
                dArrayArray4[1] = new double[]{class_2383.field_1320, class_2383.field_1322, d};
                dArrayArray4[2] = new double[]{class_2383.field_1320, class_2383.field_1325, d};
                dArrayArray = dArrayArray4;
                dArrayArray4[3] = new double[]{class_2383.field_1323, class_2383.field_1325, d};
                break;
            }
        }
        double[][] dArrayArray5 = dArrayArray;
        ArrayList<double[]> arrayList = new ArrayList<double[]>(4);
        for (int i = 0; i < 4; ++i) {
            double[] dArray = dArrayArray5[i];
            double[] dArray2 = dArrayArray5[(i + 1) % 4];
            arrayList.add(new double[]{dArray[0], dArray[1], dArray[2], dArray2[0], dArray2[1], dArray2[2]});
        }
        return arrayList;
    }

    private static class_238 c(class_238 class_2383, class_238 class_2384, float f) {
        return new class_238(class_3532.method_16436((double)f, (double)class_2383.field_1323, (double)class_2384.field_1323), class_3532.method_16436((double)f, (double)class_2383.field_1322, (double)class_2384.field_1322), class_3532.method_16436((double)f, (double)class_2383.field_1321, (double)class_2384.field_1321), class_3532.method_16436((double)f, (double)class_2383.field_1320, (double)class_2384.field_1320), class_3532.method_16436((double)f, (double)class_2383.field_1325, (double)class_2384.field_1325), class_3532.method_16436((double)f, (double)class_2383.field_1324, (double)class_2384.field_1324));
    }

    private static double E(double d) {
        return d * d;
    }

    private void lmbd$adopt$0(double d, double d2, double d3, double d4, double d5, double d6) {
        this.edges.add(new double[]{d, d2, d3, d4, d5, d6});
    }

    private boolean lmbd$new$4() {
        if (this.style.is("Fill")) return false;
        return true;
    }

    private boolean lmbd$new$3() {
        if (this.style.is("Fill")) return false;
        return true;
    }

    private boolean lmbd$new$2() {
        if (this.style.is("Outline")) return false;
        return true;
    }

    private boolean lmbd$new$1() {
        if (this.colorMode.is("Solid")) return false;
        return true;
    }

    private boolean lmbd$new$0() {
        return this.colorMode.is("Gradient");
    }

    static {
        a = new String[]{"Rainbow", "Mining Progress", "face-only", "smooth", "see-through", "second-color", "color-mode", "flow", "See Through", "Outline", "Style", "Rainbow", "mining-progress", "Gradient", "Block Overlay", "Outline", "Color Mode", "Width", "A smooth, animated outline and fill on the block you look at.", "Smooth", "Solid", "Both", "Smooth Speed", "style", "Color", "smooth-speed", "Glow", "Fill Opacity", "width", "color", "Flow", "Solid", "glow", "Face Only", "Second Color", "Fill", "block-overlay", "Both", "Fill", "fill-opacity", "Gradient"};
        FILL = a[35];
        GRADIENT = a[40];
        RAINBOW = a[11];
        BOTH = a[21];
        SOLID = a[31];
        OUTLINE = a[15];
    }
}
