package kryzex.modules.client;

public enum PlusStyle {
    NORMAL,
    POSITIVE,
    OFF;

}
