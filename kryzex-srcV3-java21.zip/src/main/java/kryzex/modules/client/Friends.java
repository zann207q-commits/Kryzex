package kryzex.modules.client;

import kryzex.client.KryzexClient;
import kryzex.gui.FriendsScreen;
import kryzex.gui.NameCache;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.module.settings.StringSetting;
import net.minecraft.class_437;

public final class Friends
extends Module {
    private static String[] a;
    private static Friends instance;
    private final StringSetting playerNames = new StringSetting("Player Names", "");
    private final NameCache friends = new NameCache(this.playerNames::getValue, this::lmbd$new$0);

    public Friends() {
        super("Friends", "Manage the players protected by Ignore Friends.", -1, Category.CLIENT);
        this.addSetting((Setting)((Object)this.playerNames));
        SettingGroup.set((Setting)((Object)this.playerNames), Friends::lmbd$new$1);
        this.addSetting(new ActionSetting("Manage Friends", this::lmbd$new$2));
        this.setEnabled(true);
        instance = this;
    }

    public static Friends A() {
        return instance;
    }

    public NameCache Q() {
        return this.friends;
    }

    public boolean p(String string) {
        if (!this.isEnabled()) return false;
        if (!this.friends.contains(string)) return false;
        return true;
    }

    private void lmbd$new$2() {
        this.mc.method_1507((class_437)new FriendsScreen(this.mc.field_1755, this.friends));
    }

    private static boolean lmbd$new$1() {
        return false;
    }

    private void lmbd$new$0(String string) {
        this.playerNames.setValue(string);
        if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.getSettingsManager() == null) return;
        KryzexClient.INSTANCE.getSettingsManager().saveNow();
    }

    static {
        a = new String[]{"Player Names", "Friends", "Manage the players protected by Ignore Friends.", "Manage Friends"};
    }
}
