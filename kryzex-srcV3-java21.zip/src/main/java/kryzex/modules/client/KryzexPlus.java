package kryzex.modules.client;

import kryzex.cinematic.CinematicDirector;
import kryzex.client.KryzexClient;
import kryzex.event.Subscribe;
import kryzex.event.TickEvent;
import kryzex.gui.ClickGuiScreen;
import kryzex.gui.Pixel;
import kryzex.gui.Theme;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;
import kryzex.modules.client.PlusStyle;
import kryzex.util.SecureString;
import net.minecraft.class_437;
import net.minecraft.class_490;

public final class KryzexPlus
extends Module {
    public static CycleSetting<Pixel> dropdownFont;
    public static CycleSetting<Theme> theme;
    public static BoolSetting bodyTracers;
    public static BoolSetting uiSounds;
    public static NumberSetting uiVolume;
    public static BoolSetting halloweenMusic;
    public static NumberSetting halloweenVolume;
    public static BoolSetting beatShake;
    public static NumberSetting shakeStrength;
    public static NumberSetting guiSize;
    public static BoolSetting renderBackground;
    public static CycleSetting<PlusStyle> animationMode;
    public boolean shouldPreventClose;
    private static String[] a;
    private static final long KHhCxz1DBQbp8y4JSU = 2465578697929419779L;

    public KryzexPlus() {
        super(SecureString.of("Kryzex+"), SecureString.of("Settings for the client"), 344, Category.CLIENT);
        this.addSettings(new Setting[]{theme, uiSounds, uiVolume, halloweenMusic, halloweenVolume, beatShake, shakeStrength, guiSize, bodyTracers, animationMode});
    }

    @Override
    public void onEnable() {
        if (CinematicDirector.guiLocked()) {
            this.setEnabled(false);
            CinematicDirector.lockedNotice();
            return;
        } else {
            if (!(this.mc.field_1755 instanceof ClickGuiScreen)) {
                KryzexClient.INSTANCE.screen = this.mc.field_1755;
            }
            if (KryzexClient.INSTANCE.GUI != null) {
                KryzexClient.INSTANCE.GUI.prepareOpen();
                this.mc.method_29970((class_437)KryzexClient.INSTANCE.GUI);
            } else if (this.mc.field_1724 != null && this.mc.field_1755 instanceof class_490) {
                this.shouldPreventClose = true;
            }
            super.onEnable();
        }
    }

    @Override
    public void onDisable() {
        if (this.mc.field_1755 instanceof ClickGuiScreen) {
            KryzexClient.INSTANCE.GUI.requestClose();
        } else if (this.mc.field_1755 instanceof class_490) {
            this.shouldPreventClose = false;
        }
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (KryzexClient.INSTANCE.GUI == null) return;
        KryzexClient.INSTANCE.GUI.syncAmbience();
    }

    static {
        String[] stringArray = a = new String[]{"Halloween Music", "GUI Style", "Switch between the Original Kryzex GUI and the Dropdown glass panels", "Kryzex+", "Beat Shake", "Theme", "Soft sounds for clicks, toggles and menus", "Body Tracers", "The backdrop moves gently with the beat", "Font of the Dropdown GUI: Minecraft Ten, the vanilla pixel font or Kryzex's font", "Halloween song in the menu (Halloween theme)", "Settings for the client", "UI Volume", "Use body tracers in Freecam, Freelook and third person; first person stays normal", "Beat Shake Strength", "Animations", "GUI Size", "Halloween Music Volume", "Background", "Accent, gradient and lighting colors of the client", "Scale of the Kryzex menu in percent", "How strongly the background reacts to the beat", "How loud the Halloween menu music is", "Volume of the interface sounds in percent", "Dropdown Font", "UI Sounds", "Dims the world behind Kryzex editor screens"};
        dropdownFont = new CycleSetting<Pixel>(SecureString.of(stringArray[24]), Pixel.Minecraft, Pixel.class).setDescription(SecureString.of(stringArray[9]));
        theme = new CycleSetting<Theme>(SecureString.of(stringArray[5]), Theme.Purple, Theme.class).setDescription(SecureString.of(stringArray[19]));
        bodyTracers = new BoolSetting(SecureString.of(stringArray[7]), true).setDescription(SecureString.of(stringArray[13]));
        uiSounds = new BoolSetting(SecureString.of(stringArray[25]), true).setDescription(SecureString.of(stringArray[6]));
        uiVolume = new NumberSetting(SecureString.of(stringArray[12]), 0.0, 100.0, 70.0, 1.0).getValue(SecureString.of(stringArray[23]));
        halloweenMusic = new BoolSetting(SecureString.of(stringArray[0]), true).setDescription(SecureString.of(stringArray[10]));
        halloweenVolume = new NumberSetting(SecureString.of(stringArray[17]), 0.0, 100.0, 35.0, 1.0).getValue(SecureString.of(stringArray[22]));
        beatShake = new BoolSetting(SecureString.of(stringArray[4]), true).setDescription(SecureString.of(stringArray[8]));
        shakeStrength = new NumberSetting(SecureString.of(stringArray[14]), 0.0, 100.0, 50.0, 5.0).getValue(SecureString.of(stringArray[21]));
        guiSize = new NumberSetting(SecureString.of(stringArray[16]), 70.0, 140.0, 100.0, 5.0).getValue(SecureString.of(stringArray[20]));
        renderBackground = new BoolSetting(SecureString.of(stringArray[18]), true).setDescription(SecureString.of(stringArray[26]));
        animationMode = new CycleSetting<PlusStyle>(SecureString.of(stringArray[15]), PlusStyle.NORMAL, PlusStyle.class);
    }
}
