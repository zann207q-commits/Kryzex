package kryzex.fx;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Random;
import kryzex.cinematic.HalloweenParticles;
import kryzex.fx.NextSpawn;
import kryzex.fx.ItemFxAccess;
import kryzex.fx.ItemFxRenderer;
import kryzex.mixin.TRANSFORMMixin;
import kryzex.modules.render.CustomTools;
import kryzex.modules.render.CustomTotem;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_9334;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

public final class TotemUndying {
    static final int KIND_TOTEM = 1;
    static final int KIND_TOOL = 2;
    private static final Map<class_1792, Integer> CLASSES;
    private static final Map<Integer, Object> KEYS;
    private static String[] TIERS;
    private static Random RANDOM;
    private static long START;
    private static long lastFrame;
    private static long frames;
    private static float time;
    private static float floatingAct;
    private static int dripModel;

    private TotemUndying() {
    }

    static int kind(int n) {
        return n & 0xF;
    }

    static int type(int n) {
        return n >> 4 & 0xF;
    }

    static int tier(int n) {
        return n >> 8 & 0xF;
    }

    static int style(int n) {
        return n >> 12 & 0xF;
    }

    static boolean animations(int n) {
        if ((n >> 16 & 1) == 0) return false;
        return true;
    }

    static boolean particles(int n) {
        if ((n >> 17 & 1) == 0) return false;
        return true;
    }

    static boolean popFx(int n) {
        if ((n >> 18 & 1) == 0) return false;
        return true;
    }

    static int design(int n) {
        int n2 = TotemUndying.style(n);
        if (TotemUndying.kind(n) == 1) {
            switch (n2) {
                case 1: {
                    return 5;
                }
                case 2: {
                    return 1;
                }
                case 3: {
                    return 2;
                }
                default: {
                    return 4;
                }
            }
        }
        if (n2 != 0) return 3;
        return 6;
    }

    static float shaderStyle(int n) {
        if (TotemUndying.kind(n) != 2) return 0.0f;
        if (TotemUndying.style(n) != 2) return 0.0f;
        return 1.0f;
    }

    static float intensity(int n) {
        return (float)(n >> 20 & 0x7F) / 100.0f * 1.3f;
    }

    static boolean spookyLike(int n) {
        if (n == 1) return true;
        if (n != 4) return false;
        return true;
    }

    static boolean chromeLike(int n) {
        if (n == 2) return true;
        if (n != 5) return false;
        return true;
    }

    static float tint(int n) {
        int n2 = TotemUndying.tier(n);
        if (n2 == 3) return 1.0f;
        if (n2 == 5) return 1.0f;
        if (n2 != 6) return 0.0f;
        return 1.0f;
    }

    static int glowCount(int n, float f) {
        boolean bl = f >= 0.0f && TotemUndying.popFx(n);
        boolean bl2 = TotemUndying.particles(n);
        int n2 = TotemUndying.design(n);
        if (n2 == 6) {
            if (!bl2) return 0;
            return 10;
        }
        switch (n2) {
            case 1:
            case 4: {
                if (bl) {
                    return 65;
                }
                if (!bl2) return 0;
                return 32;
            }
            case 2:
            case 5: {
                if (bl) {
                    return 30;
                }
                if (!bl2) return 0;
                return 8;
            }
            default: {
                if (!bl2) {
                    return 0;
                }
                if (TotemUndying.shaderStyle(n) == 1.0f) {
                    return 10;
                }
                switch (TotemUndying.tier(n)) {
                    case 6: {
                        return 7;
                    }
                    case 5: {
                        return 4;
                    }
                    case 4: {
                        return 3;
                    }
                    case 2:
                    case 3: {
                        return 2;
                    }
                }
                return 0;
            }
        }
    }

    static int smokeCount(int n, float f) {
        boolean bl;
        if (!TotemUndying.spookyLike(TotemUndying.design(n))) {
            return 0;
        }
        if (f >= 0.0f && TotemUndying.popFx(n)) {
            return 20;
        }
        boolean bl2 = bl = false;
        if (bl) {
            return 20;
        }
        if (!TotemUndying.particles(n)) return 0;
        return 8;
    }

    public static void frame() {
        float[] fArray;
        int n;
        long l = System.nanoTime();
        float f = lastFrame == 0L ? 0.016f : Math.min(0.1f, (float)(l - lastFrame) / 1.0E9f);
        lastFrame = l;
        ++frames;
        time = (float)((double)(l - START) / 1.0E9 % 3600.0);
        if (!CustomTotem.R()) return;
        int n2 = n = CustomTotem.b() == 1 ? 202 : 2;
        if (n != dripModel && (fArray = ItemFxRenderer.anchors(n)) != null) {
            NextSpawn.reset();
            NextSpawn.setAnchors(fArray);
            dripModel = n;
        }
        NextSpawn.update(f);
    }

    static float time() {
        return time;
    }

    static long frameIndex() {
        return frames;
    }

    public static void floating(float f) {
        floatingAct = f;
    }

    private static int classOf(class_1792 class_17922) {
        String string;
        int n;
        class_2960 class_29602 = class_7923.field_41178.method_10221((class_1792)class_17922);
        if (!"minecraft".equals(class_29602.method_12836())) {
            return 0;
        }
        String string2 = class_29602.method_12832();
        if (string2.equals("totem_of_undying")) {
            return 1;
        }
        if (string2.endsWith("_sword")) {
            n = 0;
            string = string2.substring(0, string2.length() - 5);
        } else if (string2.endsWith("_pickaxe")) {
            n = 1;
            string = string2.substring(0, string2.length() - 7);
        } else if (string2.endsWith("_axe")) {
            n = 2;
            string = string2.substring(0, string2.length() - 3);
        } else if (string2.endsWith("_shovel")) {
            n = 3;
            string = string2.substring(0, string2.length() - 6);
        } else {
            if (!string2.endsWith("_hoe")) return 0;
            n = 4;
            string = string2.substring(0, string2.length() - 3);
        }
        for (int i = 0; i < TIERS.length; ++i) {
            if (!string.equals(TIERS[i])) continue;
            return 2 | n << 4 | i << 8;
        }
        return 0;
    }

    static int classify(class_1799 class_17992) {
        class_1792 class_17922 = class_17992.method_7909();
        Integer n = CLASSES.get(class_17922);
        if (n == null) {
            n = TotemUndying.classOf(class_17922);
            CLASSES.put(class_17922, n);
        }
        if (n == 0) {
            return 0;
        }
        class_2960 class_29602 = (class_2960)class_17992.method_58694(class_9334.field_54199);
        if (class_29602 == null) return 0;
        if (!class_29602.equals(class_7923.field_41178.method_10221((class_1792)class_17922))) return 0;
        int n2 = n;
        return n2;
    }

    public static void tag(class_10444 class_104442, class_1799 class_17992, class_811 class_8112) {
        boolean bl;
        int n;
        int n2;
        ItemFxAccess pi = (ItemFxAccess)class_104442;
        pi.kryzex$setFx(0);
        if (class_104442.method_65606() || class_17992.method_7960()) {
            return;
        }
        int n3 = TotemUndying.classify(class_17992);
        if (n3 == 0) {
            return;
        }
        if (TotemUndying.kind(n3) == 1) {
            if (!CustomTotem.C()) {
                return;
            }
            n2 = (int)Math.round(CustomTotem.glow.getValue());
            n = n3 | CustomTotem.b() << 12 | (CustomTotem.animations.getValue() ? 65536 : 0) | (CustomTotem.particles.getValue() ? 131072 : 0) | (CustomTotem.popEffects.getValue() ? 262144 : 0) | Math.max(0, Math.min(100, n2)) << 20;
            bl = true;
        } else {
            if (!CustomTools.I()) {
                return;
            }
            n2 = CustomTools.F();
            if (n2 == 0 && (TotemUndying.type(n3) != 1 || TotemUndying.tier(n3) != 5 && TotemUndying.tier(n3) != 6)) {
                return;
            }
            int n4 = (int)Math.round(CustomTools.strength.getValue());
            n = n3 | n2 << 12 | (CustomTools.animations.getValue() ? 65536 : 0) | (CustomTools.effects.getValue() ? 131072 : 0) | Math.max(0, Math.min(100, n4)) << 20;
            bl = n2 == 0 || CustomTools.animations.getValue() || CustomTools.effects.getValue() || class_17992.method_7958();
        }
        pi.kryzex$setFx(n);
        class_104442.method_70946(KEYS.computeIfAbsent(n, TotemUndying::lmbd$tag$0));
        n2 = ItemFxRenderer.meshKey(TotemUndying.design(n), TotemUndying.type(n), TotemUndying.tier(n));
        if (bl || !ItemFxRenderer.ready(n2)) {
            class_104442.method_70947();
        }
        pi.kryzex$layer0().method_67996(true);
    }

    public static boolean render(int n, class_811 class_8112, class_10444.class_10446 class_104462, class_4587 class_45872, class_11659 class_116592, int n2) {
        int n3 = ItemFxRenderer.meshKey(TotemUndying.design(n), TotemUndying.type(n), TotemUndying.tier(n));
        if (!ItemFxRenderer.prepare(n3)) {
            return false;
        }
        TRANSFORMMixin tRANSFORMMixin = (TRANSFORMMixin)class_104462;
        int n4 = floatingAct >= 0.0f ? 3 : (class_8112 == class_811.field_4317 ? 2 : (class_8112 == class_811.field_4321 || class_8112 == class_811.field_4322 ? 1 : 0));
        class_45872.method_22903();
        try {
            tRANSFORMMixin.kryzex$transform().method_23075(class_8112.method_67675(), class_45872.method_23760());
            class_45872.method_46416(0.5f, 0.5f, 0.5f);
            if (n4 == 2 && TotemUndying.design(n) <= 3) {
                if (TotemUndying.kind(n) == 1) {
                    class_45872.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(-20.0f));
                    class_45872.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(7.0f));
                } else {
                    class_45872.method_22907((Quaternionfc)new Quaternionf().rotationAxis((float)Math.toRadians(26.0), 0.70710677f, 0.70710677f, 0.0f));
                }
            }
            boolean bl = tRANSFORMMixin.kryzex$glint() != class_10444.class_10445.field_55341;
            ItemFxRenderer.submit(class_116592, class_45872, n, n4, n2, bl, n4 == 3 ? floatingAct : -1.0f);
            return true;
        }
        finally {
            class_45872.method_22909();
        }
    }

    static void anim(Matrix4f matrix4f, int n, int n2, float f, float f2) {
        float f3;
        matrix4f.identity();
        if (TotemUndying.kind(n) != 1) {
            return;
        }
        if (TotemUndying.animations(n)) {
            f3 = n2 == 2 ? 0.55f : 1.0f;
            matrix4f.translate(0.0f, 0.018f * f3 * (float)Math.sin(f2 * 1.6f), 0.0f);
            matrix4f.rotateY(0.13f * f3 * (float)Math.sin(f2 * 0.7f));
            matrix4f.rotateZ(0.025f * f3 * (float)Math.sin(f2 * 1.1f));
        }
        if (!(f >= 0.0f) || !TotemUndying.popFx(n)) return;
        f3 = 1.0f + 0.12f * (float)Math.exp(-f * 6.0f) * (float)Math.sin(f * 28.0f);
        matrix4f.scale(f3);
    }

    public static boolean totemPop(class_1297 class_12972, class_2394 class_23942) {
        if (class_23942 != class_2398.field_11220 || !CustomTotem.C() || !CustomTotem.popEffects.getValue()) {
            return false;
        }
        double d = class_12972.method_23317();
        double d2 = class_12972.method_23318() + (double)class_12972.method_17682() * 0.55;
        double d3 = class_12972.method_23321();
        Random random = RANDOM;
        int n = CustomTotem.b();
        if (n == 0 || n == 2) {
            float[] fArray;
            int n2;
            for (n2 = 0; n2 < 40; ++n2) {
                fArray = TotemUndying.dir(random, 1.4f + random.nextFloat() * 2.2f);
                HalloweenParticles.spawn(3, d + (double)fArray[0] * 0.15, d2 + (double)fArray[1] * 0.15, d3 + (double)fArray[2] * 0.15, fArray[0], fArray[1] + 0.8f, fArray[2], 0.035f + random.nextFloat() * 0.03f, 0.6f, 1.1f + random.nextFloat() * 1.0f, 1.0f, 0.42f + random.nextFloat() * 0.25f, 0.08f, 1.0f);
            }
            for (n2 = 0; n2 < 18; ++n2) {
                fArray = TotemUndying.dir(random, 0.8f + random.nextFloat() * 1.4f);
                HalloweenParticles.spawn(1, d, d2, d3, fArray[0], fArray[1], fArray[2], 0.09f + random.nextFloat() * 0.06f, 0.4f, 1.2f + random.nextFloat() * 0.6f, 0.62f, 0.25f, 1.0f, 0.9f);
            }
            for (n2 = 0; n2 < 12; ++n2) {
                fArray = TotemUndying.dir(random, 0.5f + random.nextFloat() * 0.8f);
                HalloweenParticles.spawn(0, d + (double)fArray[0] * 0.3, d2 - 0.3 + (double)fArray[1] * 0.3, d3 + (double)fArray[2] * 0.3, fArray[0], fArray[1] * 0.4f + 0.3f, fArray[2], 0.3f + random.nextFloat() * 0.2f, 2.6f, 2.2f + random.nextFloat() * 1.0f, 0.16f, 0.09f, 0.18f, 0.4f);
            }
            for (n2 = 0; n2 < 14; ++n2) {
                fArray = TotemUndying.dir(random, 3.0f + random.nextFloat() * 2.5f);
                HalloweenParticles.spawn(2, d, d2, d3, fArray[0], fArray[1] + 1.0f, fArray[2], 0.025f, 0.5f, 0.5f + random.nextFloat() * 0.3f, 1.0f, 0.6f, 0.15f, 1.0f);
            }
            return true;
        } else {
            float[] fArray;
            int n3;
            for (n3 = 0; n3 < 34; ++n3) {
                fArray = TotemUndying.dir(random, 2.6f + random.nextFloat() * 2.8f);
                HalloweenParticles.spawn(2, d, d2, d3, fArray[0], fArray[1] + 1.2f, fArray[2], 0.028f, 0.5f, 0.6f + random.nextFloat() * 0.4f, 0.92f, 0.95f, 1.0f, 1.0f);
            }
            for (n3 = 0; n3 < 20; ++n3) {
                fArray = TotemUndying.dir(random, 0.8f + random.nextFloat() * 1.5f);
                HalloweenParticles.spawn(1, d, d2, d3, fArray[0], fArray[1], fArray[2], 0.08f + random.nextFloat() * 0.06f, 0.4f, 1.0f + random.nextFloat() * 0.6f, 0.8f, 0.9f, 1.0f, 0.8f);
            }
            for (n3 = 0; n3 < 18; ++n3) {
                fArray = TotemUndying.dir(random, 0.6f + random.nextFloat());
                HalloweenParticles.spawn(4, d + (double)fArray[0] * 0.4, d2 + (double)fArray[1] * 0.4, d3 + (double)fArray[2] * 0.4, fArray[0] * 0.3f, fArray[1] * 0.3f, fArray[2] * 0.3f, 0.03f, 1.0f, 1.6f + random.nextFloat(), 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
        return true;
    }

    private static float[] dir(Random random, float f) {
        double d = random.nextDouble() * Math.PI * 2.0;
        double d2 = random.nextDouble() * 2.0 - 1.0;
        double d3 = Math.sqrt(1.0 - d2 * d2);
        return new float[]{(float)(Math.cos(d) * d3) * f, (float)d2 * f * 0.7f, (float)(Math.sin(d) * d3) * f};
    }

    public static void moduleOff() {
        if (CustomTotem.C() || CustomTools.I()) return;
        ItemFxRenderer.releaseModels();
        NextSpawn.reset();
    }

    private static Object lmbd$tag$0(Integer n) {
        return new Object();
    }

    static {
        TIERS = new String[]{"wooden_", "stone_", "copper_", "iron_", "golden_", "diamond_", "netherite_"};
        CLASSES = new IdentityHashMap<class_1792, Integer>();
        KEYS = new HashMap<Integer, Object>();
        RANDOM = new Random();
        START = System.nanoTime();
        floatingAct = -1.0f;
    }
}
