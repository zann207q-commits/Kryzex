package kryzex.fx;

public interface ScalarField {
    public float at(float var1, float var2, float var3);
}
