package kryzex.fx;

public final class Sdf {
    private Sdf() {
    }

    public static float len(float f, float f2) {
        return (float)Math.sqrt(f * f + f2 * f2);
    }

    public static float len(float f, float f2, float f3) {
        return (float)Math.sqrt(f * f + f2 * f2 + f3 * f3);
    }

    public static float clamp(float f, float f2, float f3) {
        return f < f2 ? f2 : (f > f3 ? f3 : f);
    }

    public static float mix(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }

    public static float smoothstep(float f, float f2, float f3) {
        float f4 = Sdf.clamp((f3 - f) / (f2 - f), 0.0f, 1.0f);
        return f4 * f4 * (3.0f - 2.0f * f4);
    }

    public static float smin(float f, float f2, float f3) {
        if (f3 <= 0.0f) {
            return Math.min(f, f2);
        }
        float f4 = Math.max(f3 - Math.abs(f - f2), 0.0f) / f3;
        return Math.min(f, f2) - f4 * f4 * f3 * 0.25f;
    }

    public static float smax(float f, float f2, float f3) {
        return -Sdf.smin(-f, -f2, f3);
    }

    public static float ssub(float f, float f2, float f3) {
        return Sdf.smax(f, -f2, f3);
    }

    public static float sphere(float f, float f2, float f3, float f4) {
        return Sdf.len(f, f2, f3) - f4;
    }

    public static float ellipsoid(float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = Sdf.len(f / f4, f2 / f5, f3 / f6);
        float f8 = Sdf.len(f / (f4 * f4), f2 / (f5 * f5), f3 / (f6 * f6));
        return f8 < 1.0E-6f ? -Math.min(f4, Math.min(f5, f6)) : f7 * (f7 - 1.0f) / f8;
    }

    public static float box(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = Math.abs(f) - f4 + f7;
        float f9 = Math.abs(f2) - f5 + f7;
        float f10 = Math.abs(f3) - f6 + f7;
        float f11 = Sdf.len(Math.max(f8, 0.0f), Math.max(f9, 0.0f), Math.max(f10, 0.0f));
        return f11 + Math.min(Math.max(f8, Math.max(f9, f10)), 0.0f) - f7;
    }

    public static float capsule(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        float f11 = f - f4;
        float f12 = f2 - f5;
        float f13 = f3 - f6;
        float f14 = f7 - f4;
        float f15 = f8 - f5;
        float f16 = f9 - f6;
        float f17 = Sdf.clamp((f11 * f14 + f12 * f15 + f13 * f16) / (f14 * f14 + f15 * f15 + f16 * f16), 0.0f, 1.0f);
        return Sdf.len(f11 - f14 * f17, f12 - f15 * f17, f13 - f16 * f17) - f10;
    }

    public static float roundCone(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11) {
        float f12 = f7 - f4;
        float f13 = f8 - f5;
        float f14 = f9 - f6;
        float f15 = f12 * f12 + f13 * f13 + f14 * f14;
        float f16 = f10 - f11;
        float f17 = f15 - f16 * f16;
        float f18 = 1.0f / f15;
        float f19 = f - f4;
        float f20 = f2 - f5;
        float f21 = f3 - f6;
        float f22 = f19 * f12 + f20 * f13 + f21 * f14;
        float f23 = f22 - f15;
        float f24 = f19 * f15 - f12 * f22;
        float f25 = f20 * f15 - f13 * f22;
        float f26 = f21 * f15 - f14 * f22;
        float f27 = f24 * f24 + f25 * f25 + f26 * f26;
        float f28 = f22 * f22 * f15;
        float f29 = f23 * f23 * f15;
        float f30 = Math.signum(f16) * f16 * f16 * f27;
        if (Math.signum(f23) * f17 * f29 > f30) {
            return (float)Math.sqrt(f27 + f29) * f18 - f11;
        }
        if (!(Math.signum(f22) * f17 * f28 < f30)) return ((float)Math.sqrt(f27 * f17 * f18) + f22 * f16) * f18 - f10;
        return (float)Math.sqrt(f27 + f28) * f18 - f10;
    }

    public static float torus(float f, float f2, float f3, float f4, float f5) {
        return Sdf.len(Sdf.len(f, f3) - f4, f2) - f5;
    }

    public static float octahedron(float f, float f2, float f3, float f4) {
        return (Math.abs(f) + Math.abs(f2) + Math.abs(f3) - f4) * 0.57735026f;
    }

    public static float segment(float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = f - f3;
        float f8 = f2 - f4;
        float f9 = f5 - f3;
        float f10 = f6 - f4;
        float f11 = Sdf.clamp((f7 * f9 + f8 * f10) / (f9 * f9 + f10 * f10), 0.0f, 1.0f);
        return Sdf.len(f7 - f9 * f11, f8 - f10 * f11);
    }

    public static float polygon(float f, float f2, float[] fArray) {
        int n = fArray.length / 2;
        float f3 = (f - fArray[0]) * (f - fArray[0]) + (f2 - fArray[1]) * (f2 - fArray[1]);
        float f4 = 1.0f;
        int n2 = n - 1;
        int n3 = 0;
        while (n3 < n) {
            boolean bl;
            float f5 = fArray[n3 * 2];
            float f6 = fArray[n3 * 2 + 1];
            float f7 = fArray[n2 * 2];
            float f8 = fArray[n2 * 2 + 1];
            float f9 = f7 - f5;
            float f10 = f8 - f6;
            float f11 = f - f5;
            float f12 = f2 - f6;
            float f13 = Sdf.clamp((f11 * f9 + f12 * f10) / (f9 * f9 + f10 * f10), 0.0f, 1.0f);
            float f14 = f11 - f9 * f13;
            float f15 = f12 - f10 * f13;
            f3 = Math.min(f3, f14 * f14 + f15 * f15);
            boolean bl2 = f2 >= f6;
            boolean bl3 = f2 < f8;
            boolean bl4 = bl = f9 * f12 > f10 * f11;
            if (bl2 && bl3 && bl || !bl2 && !bl3 && !bl) {
                f4 = -f4;
            }
            n2 = n3++;
        }
        return f4 * (float)Math.sqrt(f3);
    }

    private static float hash(int n, int n2, int n3) {
        int n4 = n * 374761393 + n2 * 668265263 + n3 * 1274126177;
        n4 = (n4 ^ n4 >>> 13) * 1274126177;
        return (float)((n4 ^ n4 >>> 16) & 0xFFFFFF) / 1.6777215E7f;
    }

    public static float noise(float f, float f2, float f3) {
        int n = (int)Math.floor(f);
        int n2 = (int)Math.floor(f2);
        int n3 = (int)Math.floor(f3);
        float f4 = f - (float)n;
        float f5 = f2 - (float)n2;
        float f6 = f3 - (float)n3;
        f4 = f4 * f4 * (3.0f - 2.0f * f4);
        f5 = f5 * f5 * (3.0f - 2.0f * f5);
        f6 = f6 * f6 * (3.0f - 2.0f * f6);
        float f7 = Sdf.mix(Sdf.hash(n, n2, n3), Sdf.hash(n + 1, n2, n3), f4);
        float f8 = Sdf.mix(Sdf.hash(n, n2 + 1, n3), Sdf.hash(n + 1, n2 + 1, n3), f4);
        float f9 = Sdf.mix(Sdf.hash(n, n2, n3 + 1), Sdf.hash(n + 1, n2, n3 + 1), f4);
        float f10 = Sdf.mix(Sdf.hash(n, n2 + 1, n3 + 1), Sdf.hash(n + 1, n2 + 1, n3 + 1), f4);
        return Sdf.mix(Sdf.mix(f7, f8, f5), Sdf.mix(f9, f10, f5), f6);
    }

    public static float fbm(float f, float f2, float f3, int n) {
        float f4 = 0.0f;
        float f5 = 0.5f;
        float f6 = 0.0f;
        for (int i = 0; i < n; ++i) {
            f4 += Sdf.noise(f, f2, f3) * f5;
            f6 += f5;
            f = f * 2.03f + 17.1f;
            f2 = f2 * 2.03f + 3.7f;
            f3 = f3 * 2.03f + 9.3f;
            f5 *= 0.5f;
        }
        return f4 / f6;
    }
}
