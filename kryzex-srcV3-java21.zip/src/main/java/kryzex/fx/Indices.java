package kryzex.fx;

import java.util.Arrays;
import kryzex.fx.ItemFXAtlas;
import kryzex.fx.VertexCount;
import kryzex.fx.FxPalette;

final class Indices {
    private float[] pos = new float[4096];
    private float[] nrm = new float[4096];
    private float[] uv = new float[4096];
    private short[] mat = new short[2048];
    private short[] region = new short[2048];
    private short[] p1 = new short[2048];
    private short[] p2 = new short[2048];
    private int[] idx = new int[4096];
    private int verts;
    private int indices;

    Indices() {
    }

    int indexCount() {
        return this.indices;
    }

    int vert(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n, int n2, int n3, int n4) {
        if (this.verts * 3 + 3 > this.pos.length) {
            this.pos = Arrays.copyOf(this.pos, this.pos.length * 2);
            this.nrm = Arrays.copyOf(this.nrm, this.nrm.length * 2);
            this.uv = Arrays.copyOf(this.uv, this.uv.length * 2);
            this.mat = Arrays.copyOf(this.mat, this.mat.length * 2);
            this.region = Arrays.copyOf(this.region, this.region.length * 2);
            this.p1 = Arrays.copyOf(this.p1, this.p1.length * 2);
            this.p2 = Arrays.copyOf(this.p2, this.p2.length * 2);
        }
        int n5 = this.verts++;
        this.pos[n5 * 3] = f;
        this.pos[n5 * 3 + 1] = f2;
        this.pos[n5 * 3 + 2] = f3;
        this.nrm[n5 * 3] = f4;
        this.nrm[n5 * 3 + 1] = f5;
        this.nrm[n5 * 3 + 2] = f6;
        this.uv[n5 * 2] = f7;
        this.uv[n5 * 2 + 1] = f8;
        this.mat[n5] = (short)n;
        this.region[n5] = (short)n2;
        this.p1[n5] = (short)n3;
        this.p2[n5] = (short)n4;
        return n5;
    }

    void quad(int n, int n2, int n3, int n4) {
        if (this.indices + 6 > this.idx.length) {
            this.idx = Arrays.copyOf(this.idx, this.idx.length * 2);
        }
        this.idx[this.indices++] = n;
        this.idx[this.indices++] = n2;
        this.idx[this.indices++] = n3;
        this.idx[this.indices++] = n;
        this.idx[this.indices++] = n3;
        this.idx[this.indices++] = n4;
    }

    void sprite(int[] nArray, int[] nArray2, boolean bl, boolean bl2, float f, float f2, float f3, float f4, float f5, int n, int n2, float f6, float f7, float f8) {
        int n3 = nArray2[2];
        int n4 = nArray2[3];
        float f9 = (float)Math.cos(f6);
        float f10 = (float)Math.sin(f6);
        float f11 = 0.0078125f;
        float f12 = (float)nArray2[0] * f11;
        float f13 = (float)(nArray2[0] + n3) * f11;
        float f14 = (float)nArray2[1] * f11;
        float f15 = (float)(nArray2[1] + n4) * f11;
        float f16 = bl ? f13 : f12;
        float f17 = bl ? f12 : f13;
        float f18 = bl2 ? f15 : f14;
        float f19 = bl2 ? f14 : f15;
        float f20 = f;
        float f21 = f + (float)n3 * f3;
        float f22 = f2;
        float f23 = f2 - (float)n4 * f3;
        int n5 = this.vRot(f20, f22, f5, 0.0f, 0.0f, 1.0f, f16, f18, n, n2, f9, f10, f7, f8);
        int n6 = this.vRot(f21, f22, f5, 0.0f, 0.0f, 1.0f, f17, f18, n, n2, f9, f10, f7, f8);
        int n7 = this.vRot(f21, f23, f5, 0.0f, 0.0f, 1.0f, f17, f19, n, n2, f9, f10, f7, f8);
        int n8 = this.vRot(f20, f23, f5, 0.0f, 0.0f, 1.0f, f16, f19, n, n2, f9, f10, f7, f8);
        this.quad(n8, n7, n6, n5);
        int n9 = this.vRot(f20, f22, f4, 0.0f, 0.0f, -1.0f, f16, f18, n, n2, f9, f10, f7, f8);
        int n10 = this.vRot(f21, f22, f4, 0.0f, 0.0f, -1.0f, f17, f18, n, n2, f9, f10, f7, f8);
        int n11 = this.vRot(f21, f23, f4, 0.0f, 0.0f, -1.0f, f17, f19, n, n2, f9, f10, f7, f8);
        int n12 = this.vRot(f20, f23, f4, 0.0f, 0.0f, -1.0f, f16, f19, n, n2, f9, f10, f7, f8);
        this.quad(n9, n10, n11, n12);
        for (int i = 0; i < n4; ++i) {
            for (int j = 0; j < n3; ++j) {
                int n13;
                int n14 = bl ? n3 - 1 - j : j;
                int n15 = n13 = bl2 ? n4 - 1 - i : i;
                if (!ItemFXAtlas.opaque(nArray, nArray2, n14, n13)) continue;
                float f24 = ((float)(nArray2[0] + n14) + 0.5f) * f11;
                float f25 = ((float)(nArray2[1] + n13) + 0.5f) * f11;
                float f26 = f + (float)j * f3;
                float f27 = f26 + f3;
                float f28 = f2 - (float)i * f3;
                float f29 = f28 - f3;
                if (!this.occ(nArray, nArray2, bl, bl2, j - 1, i)) {
                    this.side(f26, f29, f26, f28, f4, f5, -1.0f, 0.0f, f24, f25, n, n2, f9, f10, f7, f8);
                }
                if (!this.occ(nArray, nArray2, bl, bl2, j + 1, i)) {
                    this.side(f27, f28, f27, f29, f4, f5, 1.0f, 0.0f, f24, f25, n, n2, f9, f10, f7, f8);
                }
                if (!this.occ(nArray, nArray2, bl, bl2, j, i - 1)) {
                    this.side(f26, f28, f27, f28, f4, f5, 0.0f, 1.0f, f24, f25, n, n2, f9, f10, f7, f8);
                }
                if (this.occ(nArray, nArray2, bl, bl2, j, i + 1)) continue;
                this.side(f27, f29, f26, f29, f4, f5, 0.0f, -1.0f, f24, f25, n, n2, f9, f10, f7, f8);
            }
        }
    }

    private boolean occ(int[] nArray, int[] nArray2, boolean bl, boolean bl2, int n, int n2) {
        int n3 = nArray2[2];
        int n4 = nArray2[3];
        if (n >= 0 && n2 >= 0 && n < n3 && n2 < n4) return ItemFXAtlas.opaque(nArray, nArray2, bl ? n3 - 1 - n : n, bl2 ? n4 - 1 - n2 : n2);
        return false;
    }

    private void side(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, int n, int n2, float f11, float f12, float f13, float f14) {
        int n3 = this.vRot(f, f2, f5, f7, f8, 0.0f, f9, f10, n, n2, f11, f12, f13, f14);
        int n4 = this.vRot(f3, f4, f5, f7, f8, 0.0f, f9, f10, n, n2, f11, f12, f13, f14);
        int n5 = this.vRot(f3, f4, f6, f7, f8, 0.0f, f9, f10, n, n2, f11, f12, f13, f14);
        int n6 = this.vRot(f, f2, f6, f7, f8, 0.0f, f9, f10, n, n2, f11, f12, f13, f14);
        this.quad(n3, n4, n5, n6);
    }

    private int vRot(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n, int n2, float f9, float f10, float f11, float f12) {
        float f13 = f - f11;
        float f14 = f2 - f12;
        return this.vert(f11 + f13 * f9 - f14 * f10, f12 + f13 * f10 + f14 * f9, f3, f4 * f9 - f5 * f10, f4 * f10 + f5 * f9, f6, f7, f8, n, n2, 0, 0);
    }

    void thread(int[] nArray, float f, float f2, float f3, float f4) {
        float f5 = ((float)FxPalette.WEB_CELL[0] + 0.5f) / 128.0f;
        float f6 = ((float)FxPalette.WEB_CELL[1] + 0.5f) / 128.0f;
        int n = this.vert(f - f4 * 0.5f, f2, 0.0f, 0.0f, 0.0f, 1.0f, f5, f6, 23, 13, 0, 0);
        int n2 = this.vert(f + f4 * 0.5f, f2, 0.0f, 0.0f, 0.0f, 1.0f, f5, f6, 23, 13, 0, 0);
        int n3 = this.vert(f + f4 * 0.5f, f3, 0.0f, 0.0f, 0.0f, 1.0f, f5, f6, 23, 13, 0, 1);
        int n4 = this.vert(f - f4 * 0.5f, f3, 0.0f, 0.0f, 0.0f, 1.0f, f5, f6, 23, 13, 0, 1);
        this.quad(n4, n3, n2, n);
    }

    void halo(int[] nArray, float f, float f2, float f3, float f4, float f5, int n) {
        float f6 = 0.0078125f;
        float f7 = (float)(nArray[0] - n) * f6;
        float f8 = (float)(nArray[0] + nArray[2] + n) * f6;
        float f9 = (float)(nArray[1] - n) * f6;
        float f10 = (float)(nArray[1] + nArray[3] + n) * f6;
        float f11 = f - (float)n * f3;
        float f12 = f + (float)(nArray[2] + n) * f3;
        float f13 = f2 + (float)n * f3;
        float f14 = f2 - (float)(nArray[3] + n) * f3;
        for (int i = 0; i < 2; ++i) {
            float f15 = i == 0 ? f4 : f5;
            float f16 = i == 0 ? 1.0f : -1.0f;
            int n2 = this.vert(f11, f13, f15, 0.0f, 0.0f, f16, f7, f9, 24, 0, nArray[0], nArray[1]);
            int n3 = this.vert(f12, f13, f15, 0.0f, 0.0f, f16, f8, f9, 24, 0, nArray[0], nArray[1]);
            int n4 = this.vert(f12, f14, f15, 0.0f, 0.0f, f16, f8, f10, 24, 0, nArray[0], nArray[1]);
            int n5 = this.vert(f11, f14, f15, 0.0f, 0.0f, f16, f7, f10, 24, 0, nArray[0], nArray[1]);
            if (i == 0) {
                this.quad(n5, n4, n3, n2);
                continue;
            }
            this.quad(n2, n3, n4, n5);
        }
    }

    VertexCount build() {
        VertexCount vertexCount = new VertexCount(this.verts, this.indices / 3);
        System.arraycopy(this.pos, 0, vertexCount.pos, 0, this.verts * 3);
        System.arraycopy(this.nrm, 0, vertexCount.nrm, 0, this.verts * 3);
        System.arraycopy(this.uv, 0, vertexCount.uv, 0, this.verts * 2);
        System.arraycopy(this.mat, 0, vertexCount.mat, 0, this.verts);
        System.arraycopy(this.region, 0, vertexCount.region, 0, this.verts);
        System.arraycopy(this.p1, 0, vertexCount.p1, 0, this.verts);
        System.arraycopy(this.p2, 0, vertexCount.p2, 0, this.verts);
        Arrays.fill(vertexCount.rgba, -1);
        System.arraycopy(this.idx, 0, vertexCount.indices, 0, this.indices);
        return vertexCount;
    }
}
