package kryzex.fx;

public final class VertexCount {
    public final int vertexCount;
    public final float[] pos;
    public final float[] nrm;
    public final float[] uv;
    public final int[] rgba;
    public final short[] mat;
    public final short[] region;
    public final short[] p1;
    public final short[] p2;
    public final int[] indices;

    public VertexCount(int n, int n2) {
        this.vertexCount = n;
        this.pos = new float[n * 3];
        this.nrm = new float[n * 3];
        this.uv = new float[n * 2];
        this.rgba = new int[n];
        this.mat = new short[n];
        this.region = new short[n];
        this.p1 = new short[n];
        this.p2 = new short[n];
        this.indices = new int[n2 * 3];
    }

    public int triangleCount() {
        return this.indices.length / 3;
    }

    public static VertexCount join(VertexCount ... vertexCountArray) {
        int n = 0;
        int n2 = 0;
        for (VertexCount vertexCount : vertexCountArray) {
            n += vertexCount.vertexCount;
            n2 += vertexCount.triangleCount();
        }
        VertexCount vertexCount = new VertexCount(n, n2);
        int n3 = 0;
        int n4 = 0;
        for (VertexCount vertexCount2 : vertexCountArray) {
            System.arraycopy(vertexCount2.pos, 0, vertexCount.pos, n3 * 3, vertexCount2.vertexCount * 3);
            System.arraycopy(vertexCount2.nrm, 0, vertexCount.nrm, n3 * 3, vertexCount2.vertexCount * 3);
            System.arraycopy(vertexCount2.uv, 0, vertexCount.uv, n3 * 2, vertexCount2.vertexCount * 2);
            System.arraycopy(vertexCount2.rgba, 0, vertexCount.rgba, n3, vertexCount2.vertexCount);
            System.arraycopy(vertexCount2.mat, 0, vertexCount.mat, n3, vertexCount2.vertexCount);
            System.arraycopy(vertexCount2.region, 0, vertexCount.region, n3, vertexCount2.vertexCount);
            System.arraycopy(vertexCount2.p1, 0, vertexCount.p1, n3, vertexCount2.vertexCount);
            System.arraycopy(vertexCount2.p2, 0, vertexCount.p2, n3, vertexCount2.vertexCount);
            for (int i = 0; i < vertexCount2.indices.length; ++i) {
                vertexCount.indices[n4 + i] = vertexCount2.indices[i] + n3;
            }
            n3 += vertexCount2.vertexCount;
            n4 += vertexCount2.indices.length;
        }
        return vertexCount;
    }
}
