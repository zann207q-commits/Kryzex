package kryzex.fx;

public final class Region {
    public int rgb = 0xFFFFFF;
    public int mat;
    public int region;
    public float p1;
    public float p2;
    public float u;
    public float v;
    public float ao = 1.0f;

    void reset() {
        this.rgb = 0xFFFFFF;
        this.mat = 0;
        this.region = 0;
        this.p1 = 0.0f;
        this.p2 = 0.0f;
        this.u = 0.0f;
        this.v = 0.0f;
        this.ao = 1.0f;
    }
}
