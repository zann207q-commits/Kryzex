package kryzex.fx;

import kryzex.fx.Region;

public interface SurfacePainter {
    public void paint(float var1, float var2, float var3, float var4, float var5, float var6, Region var7);
}
