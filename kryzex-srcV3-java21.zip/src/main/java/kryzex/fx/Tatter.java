package kryzex.fx;

import kryzex.fx.Sdf;

public final class Tatter {
    public static final float HEAD_Y = 0.292f;
    public static final float BELT_Y = -0.125f;
    public static final float HEM_Y = -0.455f;
    private static final float[] SLEEVE = new float[]{0.105f, 0.088f, 0.345f, 0.098f, 0.335f, 0.035f, 0.25f, 0.0f, 0.125f, -0.05f};
    private static final float[] SLEEVE_TORN = new float[]{0.105f, 0.088f, 0.345f, 0.098f, 0.335f, 0.032f, 0.312f, 0.004f, 0.291f, 0.026f, 0.262f, -0.024f, 0.236f, 0.006f, 0.206f, -0.05f, 0.181f, -0.014f, 0.152f, -0.074f, 0.128f, -0.04f, 0.105f, -0.056f};
    public final float round;
    public final float blend;
    public final float melt;
    public final float tatter;

    public Tatter(float f, float f2, float f3, float f4) {
        this.round = f;
        this.blend = f2;
        this.melt = f3;
        this.tatter = f4;
    }

    public float head(float f, float f2, float f3) {
        return Sdf.box(f, f2 - 0.292f, f3, 0.135f, 0.145f, 0.112f, this.round);
    }

    public float torso(float f, float f2, float f3) {
        float f4 = 1.0f + 0.16f * Sdf.clamp((0.14f - f2) / 0.27f, 0.0f, 1.0f);
        return Sdf.box(f / f4, f2 - 0.005f, f3, 0.098f, 0.135f, 0.082f, Math.min(0.06f, this.round * 0.8f + 0.01f));
    }

    public float arms(float f, float f2, float f3) {
        float f4 = Math.abs(f);
        if (f2 < -0.14f) {
            return 1.0f;
        }
        float f5 = Sdf.roundCone(f4, f2, f3, 0.085f, 0.09f, 0.0f, 0.355f, 0.106f, 0.0f, 0.058f, 0.043f);
        float f6 = Sdf.ellipsoid(f4 - 0.392f, f2 - 0.112f, f3, 0.046f, 0.05f, 0.042f);
        return Sdf.smin(f5, f6, 0.03f);
    }

    public float sleeves(float f, float f2, float f3) {
        float f4 = Math.abs(f);
        if (f2 < -0.14f || f4 < 0.08f) {
            return 1.0f;
        }
        float f5 = Math.max(Sdf.polygon(f4, f2, this.tatter > 0.0f ? SLEEVE_TORN : SLEEVE), Math.abs(f3) - 0.03f);
        return Sdf.smax(f5, -f2 - 0.1f, 0.01f) - 0.004f;
    }

    public float sleeveOutline(float f, float f2) {
        return Sdf.polygon(f, f2, this.tatter > 0.0f ? SLEEVE_TORN : SLEEVE);
    }

    public float hemY(float f) {
        if (this.tatter <= 0.0f) {
            return -0.455f;
        }
        double d = 0.5 + 0.5 * Math.cos((double)(f * 9.0f) + (double)0.8f * Math.sin(f * 4.0f));
        return -0.44300002f - this.tatter * 0.045f * (float)(d * d * d);
    }

    public float skirt(float f, float f2, float f3) {
        if (f2 > -0.05f) {
            return 0.2f;
        }
        float f4 = Sdf.clamp((-0.12f - f2) / 0.34f, 0.0f, 1.0f);
        float f5 = (float)Math.atan2(f3, f);
        float f6 = f4 * f4 * 0.4f + f4 * 0.6f;
        float f7 = Sdf.mix(0.125f, 0.205f, f6) * (1.0f + 0.035f * (float)Math.cos(f5 * 10.0f) * f4);
        float f8 = Sdf.mix(0.095f, 0.15f, f6);
        float f9 = (Sdf.len(f / f7, f3 / f8) - 1.0f) * Math.min(f7, f8);
        f9 = Sdf.smax(f9, this.hemY(f5) - f2, 0.02f);
        return Sdf.smax(f9, f2 + 0.08f, 0.02f);
    }

    public float belt(float f, float f2, float f3) {
        return Sdf.torus(f, f2 - -0.125f, f3 / 0.8f, 0.122f, 0.021f) * 0.8f;
    }

    public float body(float f, float f2, float f3) {
        float f4 = this.blend;
        float f5 = this.head(f, f2, f3);
        f5 = Sdf.smin(f5, this.torso(f, f2, f3), 0.04f + f4);
        f5 = Sdf.smin(f5, this.arms(f, f2, f3), 0.03f + f4);
        f5 = Sdf.smin(f5, this.sleeves(f, f2, f3), 0.035f + f4);
        f5 = Sdf.smin(f5, this.skirt(f, f2, f3), 0.03f + f4);
        if (!(this.melt > 0.0f) || !(f5 < 0.05f)) return f5;
        f5 -= this.melt * (Sdf.fbm(f * 6.0f + 3.1f, f2 * 6.0f, f3 * 6.0f, 2) - 0.5f);
        return f5;
    }
}
