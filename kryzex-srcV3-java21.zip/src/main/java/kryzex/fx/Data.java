package kryzex.fx;

import java.util.Arrays;

final class Data {
    int[] data;
    int size;

    Data(int n) {
        this.data = new int[n];
    }

    void add(int n) {
        if (this.size == this.data.length) {
            this.data = Arrays.copyOf(this.data, this.size * 2);
        }
        this.data[this.size++] = n;
    }

    int size() {
        return this.size;
    }
}
