package kryzex.fx;

import java.util.Arrays;
import java.util.HashSet;
import kryzex.fx.MeshBuilder;
import kryzex.fx.Region;
import kryzex.fx.Tatter;
import kryzex.fx.Sdf;
import kryzex.fx.VertexCount;
import kryzex.fx.FxPalette;

public final class GhostDesign {
    private static final Tatter SHAPE = new Tatter(0.08f, 0.045f, 0.0f, 0.0f);
    private static final float FACE_Z = 0.112f;
    private static final float EYE_X = 0.052f;
    private static final float EYE_Y = 0.305f;

    private GhostDesign() {
    }

    public static VertexCount build() {
        return MeshBuilder.build(GhostDesign::field, GhostDesign::paint, -0.47f, -0.49f, -0.18f, 0.47f, 0.47f, 0.18f, 0.008333334f, 0.07f);
    }

    static float face(float f, float f2, float f3) {
        if (f3 < 0.05f || f2 < 0.17f || f2 > 0.38f) {
            return 1.0f;
        }
        float f4 = Sdf.box(f, f2 - 0.346f, f3 - 0.112f + 0.004f, 0.1f, 0.012f, 0.014f, 0.011f);
        float f5 = Sdf.box(f, f2 - 0.262f, f3 - 0.112f, 0.015f, 0.032f, 0.014f, 0.011f);
        return Math.min(f4, f5);
    }

    static float hollows(float f, float f2, float f3) {
        if (f3 < 0.05f || f2 < 0.17f || f2 > 0.38f) {
            return 1.0f;
        }
        float f4 = Sdf.ellipsoid(Math.abs(f) - 0.052f, f2 - 0.305f, f3 - 0.112f - 0.004f, 0.036f, 0.026f, 0.03f);
        float f5 = Sdf.box(f, f2 - 0.205f, f3 - 0.112f - 0.004f, 0.06f, 0.009f, 0.022f, 0.008f);
        return Math.min(f4, f5);
    }

    static float eyes(float f, float f2, float f3) {
        return Sdf.ellipsoid(Math.abs(f) - 0.052f, f2 - 0.305f, f3 - 0.094f, 0.026f, 0.018f, 0.014f);
    }

    static float body(float f, float f2, float f3) {
        float f4 = SHAPE.body(f, f2, f3);
        f4 = Sdf.smin(f4, SHAPE.belt(f, f2, f3), 0.02f);
        f4 = Sdf.smin(f4, GhostDesign.face(f, f2, f3), 0.014f);
        if (!((f4 = Sdf.ssub(f4, GhostDesign.hollows(f, f2, f3), 0.012f)) < 0.05f)) return f4;
        float f5 = GhostDesign.faceMask(f, f2, f3);
        f4 -= 0.02f * (1.0f - 0.85f * f5) * (Sdf.fbm(f * 5.5f + 3.1f, f2 * 4.0f, f3 * 5.5f, 2) - 0.5f);
        return f4;
    }

    public static float field(float f, float f2, float f3) {
        return Math.min(GhostDesign.body(f, f2, f3), GhostDesign.eyes(f, f2, f3));
    }

    public static float faceMask(float f, float f2, float f3) {
        return Sdf.smoothstep(0.05f, 0.09f, f3) * (1.0f - Sdf.smoothstep(0.112f, 0.14f, Math.abs(f))) * Sdf.smoothstep(0.165f, 0.19f, f2) * (1.0f - Sdf.smoothstep(0.392f, 0.42f, f2));
    }

    public static void paint(float f, float f2, float f3, float f4, float f5, float f6, Region region) {
        float f7 = Math.abs(GhostDesign.eyes(f, f2, f3));
        float f8 = Math.abs(GhostDesign.body(f, f2, f3));
        region.u = (float)(Math.atan2(f3, f) / (Math.PI * 2) + 0.5);
        region.v = f2;
        if (f7 < f8 && f7 < 0.008f) {
            region.mat = 4;
            region.rgb = FxPalette.rgb(0.1f, 0.95f, 0.42f);
            region.p1 = 0.8f;
            return;
        }
        region.mat = 2;
        region.rgb = FxPalette.rgb(0.92f, 0.93f, 0.95f);
        region.p1 = 1.0f - 0.8f * GhostDesign.faceMask(f, f2, f3);
        region.region = 5;
    }

    public static float[] dripAnchors(VertexCount vertexCount) {
        float f = 0.035f;
        HashSet<Long> hashSet = new HashSet<Long>();
        float[] fArray = new float[288];
        int n = 0;
        for (int i = 0; i < vertexCount.vertexCount && n < 96; ++i) {
            long l;
            float f2 = vertexCount.nrm[i * 3 + 1];
            if (f2 > -0.8f || vertexCount.p1[i] < 900 || vertexCount.mat[i] != 2) continue;
            float f3 = vertexCount.pos[i * 3];
            float f4 = vertexCount.pos[i * 3 + 1];
            float f5 = vertexCount.pos[i * 3 + 2];
            if (f5 < -0.07f || !hashSet.add(l = (long)Math.floor(f3 / f) * 1000003L + (long)Math.floor(f4 / f) * 1009L + (long)Math.floor(f5 / f))) continue;
            fArray[n * 3] = f3;
            fArray[n * 3 + 1] = f4;
            fArray[n * 3 + 2] = f5;
            ++n;
        }
        return Arrays.copyOf(fArray, n * 3);
    }
}
