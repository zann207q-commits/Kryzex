package kryzex.fx;

import kryzex.fx.ItemFxRenderer;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix3fc;
import org.joml.Matrix4fc;

final class Light
implements class_11659.class_11660 {
    int fx;
    int ctx;
    int light;
    boolean glint;
    float act;

    public Light() {
    }

    public void render(class_4587.class_4665 class_46652, class_4588 class_45882) {
        int n;
        if (ItemFxRenderer.pending < 128) {
            n = ItemFxRenderer.pending++;
            ItemFxRenderer.POSE[n].set((Matrix4fc)class_46652.method_23761());
            ItemFxRenderer.NRM[n].set((Matrix3fc)class_46652.method_23762());
            ItemFxRenderer.FX[n] = this.fx;
            ItemFxRenderer.CTX[n] = this.ctx;
            ItemFxRenderer.LIGHT[n] = this.light;
            ItemFxRenderer.GLINT[n] = this.glint;
            ItemFxRenderer.ACT[n] = this.act;
        }
        for (n = 0; n < 4; ++n) {
            class_45882.method_23919(0.0f, 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0, 0.0f, 1.0f, 0.0f);
        }
    }
}
