package kryzex.fx;

import java.util.Arrays;

final class Data2 {
    float[] data;
    int size;

    Data2(int n) {
        this.data = new float[n];
    }

    void add(float f) {
        if (this.size == this.data.length) {
            this.data = Arrays.copyOf(this.data, this.size * 2);
        }
        this.data[this.size++] = f;
    }

    int size() {
        return this.size;
    }
}
