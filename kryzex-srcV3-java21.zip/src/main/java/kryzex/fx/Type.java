package kryzex.fx;

import kryzex.fx.MeshBuilder;
import kryzex.fx.Region;
import kryzex.fx.Sdf;
import kryzex.fx.VertexCount;
import kryzex.fx.FxPalette;

public final class Type {
    public static final int SWORD = 0;
    public static final int PICKAXE = 1;
    public static final int AXE = 2;
    public static final int SHOVEL = 3;
    public static final int HOE = 4;
    public static final int TYPES = 5;
    public static final int WOOD = 0;
    public static final int STONE = 1;
    public static final int COPPER = 2;
    public static final int IRON = 3;
    public static final int GOLD = 4;
    public static final int DIAMOND = 5;
    public static final int NETHERITE = 6;
    public static final int TIERS = 7;
    public static final int R_TOOL_HEAD = 6;
    private static final float[] AXE_BIT = new float[]{-0.03f, 0.975f, -0.17f, 0.992f, -0.3f, 1.062f, -0.338f, 1.03f, -0.362f, 0.96f, -0.37f, 0.88f, -0.36f, 0.8f, -0.33f, 0.735f, -0.3f, 0.7f, -0.17f, 0.795f, -0.03f, 0.83f};
    private static final float[] SPADE = new float[]{-0.15f, 0.825f, -0.156f, 1.04f, -0.122f, 1.118f, -0.055f, 1.16f, 0.0f, 1.168f, 0.055f, 1.16f, 0.122f, 1.118f, 0.156f, 1.04f, 0.15f, 0.825f, 0.09f, 0.785f, 0.0f, 0.77f, -0.09f, 0.785f};
    private static final float[] HOE_BLADE = new float[]{-0.196f, 1.0f, -0.33f, 1.004f, -0.346f, 0.8f, -0.318f, 0.758f, -0.222f, 0.812f};
    private static final int ARC = 30;
    private final int type;
    private final int tier;
    private final float[] arc = new float[93];

    private Type(int n, int n2) {
        this.type = n;
        this.tier = n2;
        for (int i = 0; i <= 30; ++i) {
            float f = -0.465f + 0.93f * (float)i / 30.0f;
            float f2 = Math.abs(f);
            this.arc[i * 3] = f;
            this.arc[i * 3 + 1] = 0.938f - 0.5f * f * f - 0.35f * f * f * f * f;
            float f3 = (float)Math.pow(Math.max(0.0f, 1.0f - (float)Math.pow(f2 / 0.47f, 1.7f)), 0.62f);
            this.arc[i * 3 + 2] = 0.05f * f3 + 0.0035f;
        }
    }

    public static VertexCount build(int n, int n2) {
        float f = n == 3 ? 1.19f : 1.09f;
        Type type = new Type(n, n2);
        float f2 = n == 0 ? 1.24f : f;
        float f3 = n == 1 ? 0.5f : (n == 0 ? 0.27f : (n == 3 ? 0.19f : 0.4f));
        VertexCount vertexCount = MeshBuilder.build(type::field, type::paint, -f3, -0.04f, -0.075f, f3, f, 0.075f, 0.006666667f, 0.05f);
        float f4 = 0.70710677f;
        float f5 = n == 0 ? 1.235f : f - 0.02f;
        float f6 = -f5 * f4 * 0.5f;
        for (int i = 0; i < vertexCount.vertexCount; ++i) {
            float f7 = vertexCount.pos[i * 3];
            float f8 = vertexCount.pos[i * 3 + 1];
            vertexCount.pos[i * 3] = f4 * f7 + f4 * f8 + f6 - 0.012f;
            vertexCount.pos[i * 3 + 1] = -f4 * f7 + f4 * f8 + f6 - 0.012f;
            float f9 = vertexCount.nrm[i * 3];
            float f10 = vertexCount.nrm[i * 3 + 1];
            vertexCount.nrm[i * 3] = f4 * f9 + f4 * f10;
            vertexCount.nrm[i * 3 + 1] = -f4 * f9 + f4 * f10;
        }
        float f11 = 0.0f;
        for (int i = 0; i < vertexCount.vertexCount; ++i) {
            f11 = Math.max(f11, Math.max(Math.abs(vertexCount.pos[i * 3]), Math.abs(vertexCount.pos[i * 3 + 1])));
        }
        if (!(f11 > 0.475f)) return vertexCount;
        float f12 = 0.475f / f11;
        int n3 = 0;
        while (n3 < vertexCount.vertexCount * 3) {
            int n4 = n3++;
            vertexCount.pos[n4] = vertexCount.pos[n4] * f12;
        }
        return vertexCount;
    }

    private float handleTop() {
        switch (this.type) {
            case 0: {
                return 0.27f;
            }
            case 3: {
                return 0.8f;
            }
            default: {
                return 0.952f;
            }
        }
    }

    private float haft(float f, float f2, float f3) {
        float f4 = this.handleTop();
        if (this.type == 0) {
            return Sdf.capsule(f, f2, f3, 0.0f, 0.06f, 0.0f, 0.0f, f4, 0.0f, 0.03f);
        }
        float f5 = 0.029f + 0.003f * (float)Math.sin(Math.PI * (double)Sdf.clamp(f2 / f4, 0.0f, 1.0f));
        return Sdf.capsule(f, f2, f3, 0.0f, 0.02f, 0.0f, 0.0f, f4, 0.0f, f5);
    }

    private float grip(float f, float f2, float f3) {
        if (this.type != 0) return Sdf.capsule(f, f2, f3, 0.0f, 0.07f, 0.0f, 0.0f, 0.39f, 0.0f, 0.0355f);
        return Sdf.capsule(f, f2, f3, 0.0f, 0.065f, 0.0f, 0.0f, 0.262f, 0.0f, 0.035f);
    }

    private float fittings(float f, float f2, float f3) {
        if (this.type == 0) {
            float f4 = Sdf.ellipsoid(f, f2 - 0.034f, f3, 0.05f, 0.044f, 0.04f);
            f4 = Sdf.smin(f4, Sdf.roundCone(f, f2, f3, 0.0f, 0.01f, 0.0f, 0.0f, -0.022f, 0.0f, 0.016f, 0.004f), 0.008f);
            float f5 = Math.abs(f);
            float f6 = Sdf.box(f, f2 - 0.3f, f3, 0.05f, 0.028f, 0.034f, 0.014f);
            f6 = Sdf.smin(f6, Sdf.roundCone(f5, f2, f3, 0.03f, 0.298f, 0.0f, 0.195f, 0.318f, 0.0f, 0.024f, 0.017f), 0.012f);
            f6 = Sdf.smin(f6, Sdf.roundCone(f5, f2, f3, 0.195f, 0.318f, 0.0f, 0.232f, 0.362f, 0.0f, 0.017f, 0.008f), 0.008f);
            return Math.min(f4, f6);
        }
        float f7 = Sdf.ellipsoid(f, f2 - 0.018f, f3, 0.04f, 0.032f, 0.04f);
        f7 = Math.min(f7, Sdf.torus(f, f2 - 0.045f, f3, 0.032f, 0.0075f));
        float f8 = this.handleTop() - (this.type == 3 ? 0.03f : 0.115f);
        f7 = Math.min(f7, Sdf.torus(f, f2 - f8, f3, 0.033f, 0.0085f));
        return Math.min(f7, Sdf.torus(f, f2 - 0.4f, f3, 0.037f, 0.006f));
    }

    private float headShape(float f, float f2, float f3) {
        float f4;
        switch (this.type) {
            case 1: {
                f4 = this.pick(f, f2, f3);
                return f4;
            }
            case 2: {
                f4 = Type.axe(f, f2, f3);
                return f4;
            }
            case 3: {
                f4 = Type.shovel(f, f2, f3);
                return f4;
            }
            case 4: {
                f4 = Type.hoe(f, f2, f3);
                return f4;
            }
            default: {
                f4 = Type.blade(f, f2, f3);
            }
        }
        return f4;
    }

    private float head(float f, float f2, float f3) {
        float f4 = this.headShape(f, f2, f3);
        if (this.tier != 1 || !(f4 < 0.02f)) return f4;
        f4 += 0.0075f * (Sdf.fbm(f * 22.0f, f2 * 22.0f, f3 * 22.0f, 3) - 0.5f);
        return f4;
    }

    private float pick(float f, float f2, float f3) {
        if (f2 < 0.7f) {
            if (f2 < 0.6f) {
                return 0.2f;
            }
            float f4 = 0.7f - f2 + 0.05f;
            return f4;
        }
        float f5 = Sdf.box(f, f2 - 0.936f, f3, 0.05f, 0.074f, 0.046f, 0.02f);
        int n = 0;
        while (n < 30) {
            float[] fArray = this.arc;
            float f6 = Sdf.roundCone(f, f2, f3 / 0.74f, fArray[n * 3], fArray[n * 3 + 1], 0.0f, fArray[n * 3 + 3], fArray[n * 3 + 4], 0.0f, fArray[n * 3 + 2], fArray[n * 3 + 5]) * 0.74f;
            f5 = Sdf.smin(f5, f6, 0.018f);
            ++n;
        }
        return f5;
    }

    private static float axe(float f, float f2, float f3) {
        if (f2 < 0.66f) {
            return 0.7f - f2;
        }
        float f4 = Sdf.box(f, f2 - 0.905f, f3, 0.042f, 0.086f, 0.046f, 0.016f);
        float f5 = Sdf.box(f - 0.066f, f2 - 0.905f, f3, 0.032f, 0.058f, 0.041f, 0.016f);
        float f6 = Sdf.smoothstep(-0.03f, -0.365f, f);
        float f7 = Sdf.mix(0.043f, 0.0035f, (float)Math.pow(f6, 0.85f));
        float f8 = Math.max(Sdf.polygon(f, f2, AXE_BIT), Math.abs(f3) - f7);
        return Sdf.smin(Sdf.smin(f4, f5, 0.012f), f8, 0.018f);
    }

    private static float shovel(float f, float f2, float f3) {
        if (f2 < 0.62f) {
            return 0.66f - f2;
        }
        float f4 = Sdf.roundCone(f, f2, f3 / 0.8f, 0.0f, 0.68f, 0.0f, 0.0f, 0.8f, 0.0f, 0.034f, 0.05f) * 0.8f;
        float f5 = 0.065f * (f / 0.156f) * (f / 0.156f) - 0.025f + 0.03f * Sdf.smoothstep(1.0f, 1.17f, f2);
        float f6 = Math.max(Sdf.polygon(f, f2, SPADE), (Math.abs(f3 - f5) - 0.0115f) * 0.62f);
        return Sdf.smin(f4, f6, 0.03f);
    }

    private static float hoe(float f, float f2, float f3) {
        if (f2 < 0.7f) {
            return 0.74f - f2;
        }
        float f4 = Sdf.box(f, f2 - 0.935f, f3, 0.04f, 0.062f, 0.045f, 0.015f);
        float f5 = Sdf.roundCone(f, f2, f3, -0.03f, 0.958f, 0.0f, -0.215f, 0.975f, 0.0f, 0.03f, 0.021f);
        float f6 = Math.max(Sdf.polygon(f, f2, HOE_BLADE), Math.abs(f3) - Sdf.mix(0.016f, 0.004f, Sdf.smoothstep(0.93f, 0.76f, f2)));
        return Sdf.smin(Sdf.smin(f4, f5, 0.014f), f6, 0.016f);
    }

    private static float bladeWidth(float f) {
        float f2 = Sdf.mix(0.08f, 0.06f, Sdf.clamp((f - 0.33f) / 0.7f, 0.0f, 1.0f));
        float f3 = Sdf.smoothstep(1.225f, 1.02f, f);
        return f2 * (float)Math.sqrt(f3);
    }

    private static float blade(float f, float f2, float f3) {
        if (f2 < 0.28f) {
            return 0.31f - f2;
        }
        float f4 = Type.bladeWidth(f2);
        float f5 = Math.abs(f);
        float f6 = Math.max(f5 - f4, f2 - 1.228f);
        float f7 = 0.025f * Sdf.clamp((1.24f - f2) / 0.25f, 0.25f, 1.0f);
        float f8 = f7 * (float)Math.pow(Sdf.clamp(1.0f - f5 / Math.max(f4, 1.0E-4f), 0.0f, 1.0f), 0.85f) + 0.0016f;
        float f9 = Math.max(Math.max(f6, Math.abs(f3) - f8), 0.32f - f2);
        float f10 = Math.max(Math.max(f5 - 0.0115f, f7 - 0.0072f - Math.abs(f3)), Math.max(0.36f - f2, f2 - 0.9f));
        return Sdf.ssub(f9, f10, 0.004f);
    }

    private float field(float f, float f2, float f3) {
        float f4 = Sdf.smin(this.haft(f, f2, f3), this.grip(f, f2, f3), 0.006f);
        f4 = Sdf.smin(f4, this.fittings(f, f2, f3), 0.006f);
        return Sdf.smin(f4, this.head(f, f2, f3), 0.008f);
    }

    private float edge(float f, float f2, float f3) {
        float f4;
        switch (this.type) {
            case 1: {
                float f5 = 1.0f;
                for (int i = 0; i <= 30; ++i) {
                    f5 = Math.min(f5, Sdf.len(f - this.arc[i * 3], f2 - this.arc[i * 3 + 1]) - this.arc[i * 3 + 2]);
                }
                float f6 = Sdf.smoothstep(0.25f, 0.45f, Math.abs(f));
                f4 = f6 * (1.0f - Sdf.smoothstep(-0.004f, 0.02f, -f5));
                return f4;
            }
            case 2: {
                f4 = Sdf.smoothstep(-0.3f, -0.36f, f);
                return f4;
            }
            case 3: {
                f4 = Sdf.smoothstep(1.1f, 1.165f, f2) + (1.0f - Sdf.smoothstep(0.0f, 0.02f, -Sdf.polygon(f, f2, SPADE))) * Sdf.smoothstep(1.0f, 1.12f, f2);
                return f4;
            }
            case 4: {
                f4 = Sdf.smoothstep(0.8f, 0.765f, f2) * Sdf.smoothstep(-0.22f, -0.3f, f);
                return f4;
            }
            default: {
                f4 = 1.0f - Sdf.smoothstep(0.004f, 0.02f, Type.bladeWidth(f2) - Math.abs(f));
            }
        }
        return f4;
    }

    private void headMaterial(Region region) {
        switch (this.tier) {
            case 0: {
                region.mat = 9;
                region.rgb = FxPalette.rgb(0.7f, 0.52f, 0.31f);
                region.p1 = 0.6f;
                return;
            }
            case 1: {
                region.mat = 11;
                region.rgb = FxPalette.rgb(0.5f, 0.5f, 0.52f);
                region.p1 = 0.8f;
                return;
            }
            case 2: {
                region.mat = 14;
                region.rgb = FxPalette.rgb(0.95f, 0.58f, 0.42f);
                region.p1 = 0.3f;
                return;
            }
            case 3: {
                region.mat = 14;
                region.rgb = FxPalette.rgb(0.76f, 0.77f, 0.8f);
                region.p1 = 0.18f;
                return;
            }
            case 4: {
                region.mat = 14;
                region.rgb = FxPalette.rgb(1.0f, 0.78f, 0.34f);
                region.p1 = 0.12f;
                return;
            }
            case 5: {
                region.mat = 12;
                region.rgb = FxPalette.rgb(0.32f, 0.94f, 0.88f);
                region.p1 = 0.05f;
                return;
            }
            default: {
                region.mat = 14;
                region.rgb = FxPalette.rgb(0.25f, 0.215f, 0.24f);
                region.p1 = 0.26f;
            }
        }
    }

    private void fittingMaterial(Region region) {
        region.mat = 1;
        switch (this.tier) {
            case 0:
            case 1: {
                region.rgb = FxPalette.rgb(0.42f, 0.42f, 0.45f);
                region.p1 = 0.45f;
                return;
            }
            case 2: {
                region.rgb = FxPalette.rgb(0.93f, 0.6f, 0.44f);
                region.p1 = 0.35f;
                return;
            }
            case 3: {
                region.rgb = FxPalette.rgb(0.62f, 0.63f, 0.66f);
                region.p1 = 0.25f;
                return;
            }
            case 4:
            case 5: {
                region.rgb = FxPalette.rgb(1.0f, 0.77f, 0.36f);
                region.p1 = 0.18f;
                return;
            }
            default: {
                region.rgb = FxPalette.rgb(0.34f, 0.29f, 0.31f);
                region.p1 = 0.3f;
            }
        }
    }

    private void paint(float f, float f2, float f3, float f4, float f5, float f6, Region region) {
        float f7 = Math.abs(this.haft(f, f2, f3));
        float f8 = Math.abs(this.grip(f, f2, f3));
        float f9 = Math.abs(this.fittings(f, f2, f3));
        float f10 = Math.abs(this.head(f, f2, f3));
        float f11 = Math.min(Math.min(f7, f8), Math.min(f9, f10));
        region.u = (float)(Math.atan2(f3, f) / (Math.PI * 2) + 0.5);
        region.v = f2;
        if (f11 == f10) {
            this.headMaterial(region);
            region.p2 = Sdf.clamp(this.edge(f, f2, f3), 0.0f, 1.0f);
            region.region = 6;
            region.u = f * 4.0f;
            return;
        } else if (f11 == f9) {
            this.fittingMaterial(region);
            return;
        } else if (f11 == f8) {
            region.mat = 10;
            region.rgb = this.tier == 6 ? FxPalette.rgb(0.1f, 0.07f, 0.08f) : FxPalette.rgb(0.26f, 0.14f, 0.075f);
            region.p1 = 0.75f;
            return;
        } else {
            region.mat = 9;
            region.rgb = this.tier == 6 ? FxPalette.rgb(0.14f, 0.09f, 0.075f) : FxPalette.rgb(0.4f, 0.245f, 0.13f);
            region.p1 = 0.55f;
        }
    }
}
