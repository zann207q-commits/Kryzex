package kryzex.fx;

import java.nio.ByteBuffer;
import java.util.Random;

final class NextSpawn {
    static final int SLOTS = 10;
    static final int ENTRIES = 48;
    private static final int GROW = 0;
    private static final int PINCH = 1;
    private static final int RETRACT = 2;
    private static final Random RANDOM = new Random();
    private static float[] anchors = new float[0];
    private static final boolean[] alive = new boolean[10];
    private static final int[] stage = new int[10];
    private static final float[] ax = new float[10];
    private static final float[] ay = new float[10];
    private static final float[] az = new float[10];
    private static final float[] age = new float[10];
    private static final float[] growTime = new float[10];
    private static final float[] maxLen = new float[10];
    private static final float[] maxR = new float[10];
    private static final float[] len = new float[10];
    private static final float[] rad = new float[10];
    private static final float[] neck = new float[10];
    private static final boolean[] falling = new boolean[10];
    private static final float[] fy = new float[10];
    private static final float[] fv = new float[10];
    private static final float[] fr = new float[10];
    private static final float[] fage = new float[10];
    private static float nextSpawn = 0.3f;

    private NextSpawn() {
    }

    static void setAnchors(float[] fArray) {
        anchors = fArray;
    }

    static void reset() {
        for (int i = 0; i < 10; ++i) {
            NextSpawn.alive[i] = false;
            NextSpawn.falling[i] = false;
        }
    }

    static void update(float f) {
        if (f <= 0.0f || anchors.length < 3) {
            return;
        }
        if ((nextSpawn -= (f = Math.min(f, 0.1f))) <= 0.0f) {
            nextSpawn = 0.35f + RANDOM.nextFloat() * 0.9f;
            NextSpawn.spawn();
        }
        block4: for (int i = 0; i < 10; ++i) {
            if (falling[i]) {
                int n = i;
                fage[n] = fage[n] + f;
                int n2 = i;
                fv[n2] = fv[n2] + 1.9f * f;
                int n3 = i;
                fy[n3] = fy[n3] - fv[i] * f;
                if (fage[i] > 0.75f || fy[i] < -0.62f) {
                    NextSpawn.falling[i] = false;
                }
            }
            if (!alive[i]) continue;
            int n = i;
            age[n] = age[n] + f;
            switch (stage[i]) {
                case 0: {
                    float f2 = Math.min(1.0f, age[i] / growTime[i]);
                    float f3 = 1.0f - (1.0f - f2) * (1.0f - f2);
                    NextSpawn.len[i] = 0.006f + (maxLen[i] - 0.006f) * f3;
                    NextSpawn.rad[i] = 0.005f + (maxR[i] - 0.005f) * (float)Math.sqrt(f2);
                    NextSpawn.neck[i] = rad[i] * (0.75f - 0.3f * f2);
                    if (!(f2 >= 1.0f)) continue block4;
                    NextSpawn.stage[i] = 1;
                    NextSpawn.age[i] = 0.0f;
                    continue block4;
                }
                case 1: {
                    float f2 = Math.min(1.0f, age[i] / 0.28f);
                    NextSpawn.len[i] = maxLen[i] * (1.0f + 0.18f * f2);
                    NextSpawn.neck[i] = maxR[i] * 0.45f * (1.0f - f2);
                    if (!(f2 >= 1.0f)) continue block4;
                    NextSpawn.falling[i] = true;
                    NextSpawn.fage[i] = 0.0f;
                    NextSpawn.fv[i] = 0.05f;
                    NextSpawn.fr[i] = rad[i] * 0.95f;
                    NextSpawn.fy[i] = ay[i] - len[i] + rad[i];
                    NextSpawn.stage[i] = 2;
                    NextSpawn.age[i] = 0.0f;
                    continue block4;
                }
                default: {
                    float f2 = Math.min(1.0f, age[i] / 0.45f);
                    float f3 = f2 * f2 * (3.0f - 2.0f * f2);
                    NextSpawn.len[i] = Math.max(0.004f, maxLen[i] * 0.55f * (1.0f - f3));
                    NextSpawn.rad[i] = Math.max(0.003f, maxR[i] * 0.55f * (1.0f - f3));
                    NextSpawn.neck[i] = rad[i] * 0.7f;
                    if (!(f2 >= 1.0f)) continue block4;
                    NextSpawn.alive[i] = false;
                }
            }
        }
    }

    private static void spawn() {
        int n;
        int n2 = -1;
        for (n = 0; n < 10; ++n) {
            if (alive[n] || falling[n]) continue;
            n2 = n;
            break;
        }
        if (n2 < 0) {
            return;
        }
        n = anchors.length / 3;
        int n3 = RANDOM.nextInt(n);
        NextSpawn.alive[n2] = true;
        NextSpawn.stage[n2] = 0;
        NextSpawn.age[n2] = 0.0f;
        NextSpawn.ax[n2] = anchors[n3 * 3];
        NextSpawn.ay[n2] = anchors[n3 * 3 + 1] + 0.003f;
        NextSpawn.az[n2] = anchors[n3 * 3 + 2];
        NextSpawn.growTime[n2] = 1.3f + RANDOM.nextFloat() * 1.6f;
        NextSpawn.maxLen[n2] = 0.032f + RANDOM.nextFloat() * 0.045f;
        NextSpawn.maxR[n2] = 0.0095f + RANDOM.nextFloat() * 0.0065f;
        NextSpawn.len[n2] = 0.006f;
        NextSpawn.rad[n2] = 0.005f;
        NextSpawn.neck[n2] = 0.004f;
    }

    static int write(ByteBuffer byteBuffer, int n) {
        int n2 = 0;
        for (int i = 0; i < 10 && n2 < 24; ++i) {
            int n3;
            if (alive[i]) {
                n3 = n + 16 + n2 * 32;
                NextSpawn.put4(byteBuffer, n3, ax[i], ay[i], az[i], 0.0f);
                NextSpawn.put4(byteBuffer, n3 + 16, len[i], rad[i], neck[i], 0.017f);
                ++n2;
            }
            if (!falling[i] || n2 >= 24) continue;
            n3 = n + 16 + n2 * 32;
            float f = Math.min(0.7f, fv[i] * 0.35f);
            float f2 = 1.0f - Math.max(0.0f, (fage[i] - 0.5f) / 0.25f);
            float f3 = fr[i] * Math.max(0.0f, f2);
            float f4 = fy[i] + f3 * (1.0f + f);
            NextSpawn.put4(byteBuffer, n3, ax[i], f4, az[i], 1.0f);
            NextSpawn.put4(byteBuffer, n3 + 16, f, f3, 0.0f, 0.0f);
            ++n2;
        }
        NextSpawn.put4(byteBuffer, n, n2, 0.0f, 0.0f, 0.0f);
        return n2;
    }

    private static void put4(ByteBuffer byteBuffer, int n, float f, float f2, float f3, float f4) {
        byteBuffer.putFloat(n, f);
        byteBuffer.putFloat(n + 4, f2);
        byteBuffer.putFloat(n + 8, f3);
        byteBuffer.putFloat(n + 12, f4);
    }
}
