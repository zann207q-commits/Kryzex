package kryzex.fx;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;
import kryzex.fx.Anchors;
import kryzex.fx.Count;
import kryzex.fx.Flat;
import kryzex.fx.ItemFXAtlas;
import kryzex.fx.Light;
import kryzex.fx.MainIndices;
import kryzex.fx.NextSpawn;
import kryzex.fx.TotemUndying;
import kryzex.fx.Type;
import kryzex.fx.VertexCount;
import kryzex.fx.SpookyDesign;
import kryzex.fx.GhostDesign;
import kryzex.mixin.GetRenderSetUPMixin;
import net.minecraft.class_1011;
import net.minecraft.class_10789;
import net.minecraft.class_11219;
import net.minecraft.class_11659;
import net.minecraft.class_12137;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix3f;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.BufferUtils;

public final class ItemFxRenderer {
    static final int DESIGN_SPOOKY = 1;
    static final int DESIGN_CHROME = 2;
    static final int DESIGN_TOOL = 3;
    static final int DESIGN_SPOOKY_PX = 4;
    static final int DESIGN_CHROME_PX = 5;
    static final int DESIGN_GHOST = 6;
    static final int CTX_WORLD = 0;
    static final int CTX_HAND = 1;
    static final int CTX_GUI = 2;
    static final int CTX_FLOATING = 3;
    private static final int MAX = 128;
    private static final int CHUNK = 32;
    private static final int INSTANCE_SIZE = 272;
    private static final int DRIPS_SIZE = 784;
    private static VertexFormat FORMAT;
    private static RenderPipeline MESH_PIPE;
    private static RenderPipeline DRIP_PIPE;
    private static RenderPipeline GLOW_PIPE;
    private static RenderPipeline SMOKE_PIPE;
    private static BlendFunction ADD;
    private static RenderPipeline SPRITE_PIPE;
    private static RenderPipeline GHOST_BACK_PIPE;
    private static RenderPipeline GHOST_FRONT_PIPE;
    private static RenderPipeline HALO_PIPE;
    private static RenderPipeline SKULL_PIPE;
    private static RenderPipeline MARKER_PIPE;
    private static class_1921 layer;
    private static boolean layerFailed;
    public static Matrix4f[] POSE;
    public static Matrix3f[] NRM;
    public static int[] FX;
    public static int[] CTX;
    public static int[] LIGHT;
    public static float[] ACT;
    public static boolean[] GLINT;
    public static int pending;
    private static Light[] COMMANDS;
    private static int nextCommand;
    private static final Map<Integer, Count> MESHES;
    private static final Map<Integer, CompletableFuture<Anchors>> BUILDS;
    private static final Map<Integer, float[]> ANCHORS;
    private static ExecutorService BUILDER;
    private static GpuTexture atlas;
    private static GpuTextureView atlasView;
    private static GpuBuffer quadVbo;
    private static GpuBuffer quadIbo;
    private static GpuBuffer dripVbo;
    private static GpuBuffer dripIbo;
    private static int dripIndices;
    private static GpuBuffer ubo;
    private static GpuBuffer dripUbo;
    private static int stride;
    private static ByteBuffer data;
    private static ByteBuffer dripData;
    private static long dripFrame;
    private static boolean failed;
    private static Matrix4f TMP;
    private static Matrix4f ANIM;
    private static Matrix4f MV;
    private static Matrix4f NM;
    private static Matrix3f TMP3;
    private static Matrix3f ANIM3;

    private ItemFxRenderer() {
    }

    private static RenderPipeline.Builder base(String string, class_2960 class_29602, VertexFormat vertexFormat) {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)string)).withVertexShader(class_29602).withFragmentShader(class_29602).withUniform("Projection", class_10789.field_60031).withUniform("Fog", class_10789.field_60031).withUniform("ItemFx", class_10789.field_60031).withCull(false).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withVertexFormat(vertexFormat, VertexFormat.class_5596.field_27379);
    }

    static class_1921 layer() {
        if (layer != null || layerFailed) return layer;
        try {
            layer = GetRenderSetUPMixin.kryzex$create("kryzex_item_fx", class_12247.method_75927((RenderPipeline)MARKER_PIPE).method_75938());
            return layer;
        }
        catch (Throwable throwable) {
            layerFailed = true;
            System.err.println("Kryzex: item fx layer unavailable: " + String.valueOf(throwable));
        }
        return layer;
    }

    public static boolean isMarker(Object object) {
        if (object == null) return false;
        if (object != layer) return false;
        return true;
    }

    static int meshKey(int n, int n2, int n3) {
        int n4;
        switch (n) {
            case 3: {
                n4 = 100 + n2 * 10 + n3;
                return n4;
            }
            case 4: {
                return 201;
            }
            case 5: {
                return 202;
            }
            case 6: {
                return 203;
            }
            default: {
                n4 = n;
            }
        }
        return n4;
    }

    private static Anchors buildModel(int n) {
        if (n == 1) {
            VertexCount vertexCount = SpookyDesign.build();
            return new Anchors(vertexCount, vertexCount.indices.length, null);
        }
        if (n == 2) {
            VertexCount vertexCount = GhostDesign.build();
            return new Anchors(vertexCount, vertexCount.indices.length, GhostDesign.dripAnchors(vertexCount));
        }
        if (n > 200) {
            MainIndices mainIndices = ItemFXAtlas.build(n == 201 ? 1 : (n == 202 ? 2 : 3));
            return new Anchors(mainIndices.mesh, mainIndices.mainIndices, n == 202 ? mainIndices.anchors : null);
        }
        VertexCount vertexCount = Type.build((n - 100) / 10, (n - 100) % 10);
        return new Anchors(vertexCount, vertexCount.indices.length, null);
    }

    static float[] anchors(int n) {
        return ANCHORS.get(n);
    }

    static boolean ready(int n) {
        if (failed) {
            return false;
        }
        if (MESHES.containsKey(n)) {
            return true;
        }
        CompletableFuture completableFuture = BUILDS.computeIfAbsent(n, ItemFxRenderer::lmbd$ready$0);
        if (!completableFuture.isDone()) {
            return false;
        }
        try {
            Anchors anchors = (Anchors)completableFuture.join();
            MESHES.put(n, ItemFxRenderer.upload(anchors.mesh(), anchors.main(), n));
            if (anchors.anchors() != null) {
                ANCHORS.put(n, anchors.anchors());
            }
            BUILDS.remove(n);
            return true;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: item model " + n + " failed: " + String.valueOf(throwable));
            failed = true;
            return false;
        }
    }

    static boolean prepare(int n) {
        if (failed) return false;
        if (ItemFxRenderer.layer() == null) {
            return false;
        }
        if (!ItemFxRenderer.ready(n)) return false;
        if (!Flat.ready(GLOW_PIPE)) return false;
        if (!Flat.ready(SMOKE_PIPE)) {
            return false;
        }
        if (n > 200) {
            boolean bl;
            boolean bl2 = bl = Flat.ready(HALO_PIPE) && ItemFxRenderer.ensureAtlas();
            if (n == 203) {
                if (!bl) return false;
                if (!Flat.ready(GHOST_BACK_PIPE)) return false;
                if (!Flat.ready(GHOST_FRONT_PIPE)) return false;
                if (!Flat.ready(SKULL_PIPE)) return false;
                return true;
            }
            if (!bl) return false;
            if (!Flat.ready(SPRITE_PIPE)) return false;
            if (n != 202) return true;
            if (!Flat.ready(DRIP_PIPE)) return false;
            return true;
        }
        if (!Flat.ready(MESH_PIPE)) return false;
        if (n != 2) return true;
        if (!Flat.ready(DRIP_PIPE)) return false;
        return true;
    }

    private static boolean ensureAtlas() {
        if (atlasView != null) {
            return true;
        }
        try {
            BufferedImage bufferedImage;
            GpuDevice gpuDevice = RenderSystem.getDevice();
            try (InputStream inputStream = ItemFxRenderer.class.getResourceAsStream("/assets/r87f4560b4c09f4/rb52d8d2fd2d9d6/atlas.png");){
                bufferedImage = ImageIO.read(inputStream);
            }
            int n = bufferedImage.getWidth();
            int n2 = bufferedImage.getHeight();
            atlas = gpuDevice.createTexture(ItemFxRenderer::lmbd$ensureAtlas$0, 5, TextureFormat.RGBA8, n, n2, 1, 1);
            try (class_1011 class_10112 = new class_1011(n, n2, false);){
                for (int i = 0; i < n2; ++i) {
                    for (int j = 0; j < n; ++j) {
                        class_10112.method_61941(j, i, bufferedImage.getRGB(j, i));
                    }
                }
                gpuDevice.createCommandEncoder().writeToTexture(atlas, class_10112);
            }
            atlasView = gpuDevice.createTextureView(atlas);
            return true;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: item atlas failed: " + String.valueOf(throwable));
            failed = true;
            return false;
        }
    }

    private static Count upload(VertexCount vertexCount, int n, int n2) {
        GpuDevice gpuDevice = RenderSystem.getDevice();
        int n3 = FORMAT.getVertexSize();
        int n4 = FORMAT.getOffset(VertexFormatElement.POSITION);
        int n5 = FORMAT.getOffset(VertexFormatElement.COLOR);
        int n6 = FORMAT.getOffset(VertexFormatElement.UV0);
        int n7 = FORMAT.getOffset(VertexFormatElement.UV1);
        int n8 = FORMAT.getOffset(VertexFormatElement.UV2);
        int n9 = FORMAT.getOffset(VertexFormatElement.NORMAL);
        ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)(n3 * vertexCount.vertexCount)).order(ByteOrder.nativeOrder());
        for (int i = 0; i < vertexCount.vertexCount; ++i) {
            int n10 = i * n3;
            byteBuffer.putFloat(n10 + n4, vertexCount.pos[i * 3]);
            byteBuffer.putFloat(n10 + n4 + 4, vertexCount.pos[i * 3 + 1]);
            byteBuffer.putFloat(n10 + n4 + 8, vertexCount.pos[i * 3 + 2]);
            int n11 = vertexCount.rgba[i];
            byteBuffer.put(n10 + n5, (byte)(n11 >> 16));
            byteBuffer.put(n10 + n5 + 1, (byte)(n11 >> 8));
            byteBuffer.put(n10 + n5 + 2, (byte)n11);
            byteBuffer.put(n10 + n5 + 3, (byte)(n11 >>> 24));
            byteBuffer.putFloat(n10 + n6, vertexCount.uv[i * 2]);
            byteBuffer.putFloat(n10 + n6 + 4, vertexCount.uv[i * 2 + 1]);
            byteBuffer.putShort(n10 + n7, vertexCount.mat[i]);
            byteBuffer.putShort(n10 + n7 + 2, vertexCount.region[i]);
            byteBuffer.putShort(n10 + n8, vertexCount.p1[i]);
            byteBuffer.putShort(n10 + n8 + 2, vertexCount.p2[i]);
            byteBuffer.put(n10 + n9, (byte)Math.round(vertexCount.nrm[i * 3] * 127.0f));
            byteBuffer.put(n10 + n9 + 1, (byte)Math.round(vertexCount.nrm[i * 3 + 1] * 127.0f));
            byteBuffer.put(n10 + n9 + 2, (byte)Math.round(vertexCount.nrm[i * 3 + 2] * 127.0f));
        }
        byteBuffer.position(0);
        byteBuffer.limit(n3 * vertexCount.vertexCount);
        GpuBuffer gpuBuffer = gpuDevice.createBuffer(() -> ItemFxRenderer.lmbd$upload$0(n2), 32, byteBuffer);
        ByteBuffer byteBuffer2 = BufferUtils.createByteBuffer((int)(vertexCount.indices.length * 4)).order(ByteOrder.nativeOrder());
        for (int n10 : vertexCount.indices) {
            byteBuffer2.putInt(n10);
        }
        byteBuffer2.flip();
        GpuBuffer gpuBuffer2 = gpuDevice.createBuffer(() -> ItemFxRenderer.lmbd$upload$1(n2), 64, byteBuffer2);
        return new Count(gpuBuffer, gpuBuffer2, vertexCount.indices.length, n);
    }

    private static void ensureStatic() {
        int n;
        if (ubo != null) {
            return;
        }
        GpuDevice gpuDevice = RenderSystem.getDevice();
        int n2 = Math.max(16, gpuDevice.getUniformOffsetAlignment());
        stride = (272 + n2 - 1) / n2 * n2;
        ubo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$0, 136, (long)stride * 32L);
        dripUbo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$1, 136, 784L);
        data = BufferUtils.createByteBuffer((int)(stride * 32)).order(ByteOrder.nativeOrder());
        dripData = BufferUtils.createByteBuffer(784).order(ByteOrder.nativeOrder());
        ByteBuffer byteBuffer = BufferUtils.createByteBuffer(48).order(ByteOrder.nativeOrder());
        float[] fArray = new float[]{-1.0f, -1.0f, 1.0f, -1.0f, 1.0f, 1.0f, -1.0f, 1.0f};
        for (int i = 0; i < 4; ++i) {
            byteBuffer.putFloat(fArray[i * 2]);
            byteBuffer.putFloat(fArray[i * 2 + 1]);
            byteBuffer.putFloat(0.0f);
        }
        byteBuffer.flip();
        quadVbo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$2, 32, byteBuffer);
        ByteBuffer byteBuffer2 = BufferUtils.createByteBuffer(24).order(ByteOrder.nativeOrder());
        for (int n3 : new int[]{0, 1, 2, 0, 2, 3}) {
            byteBuffer2.putInt(n3);
        }
        byteBuffer2.flip();
        quadIbo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$3, 64, byteBuffer2);
        int n4 = 16;
        int n5 = 26;
        ByteBuffer byteBuffer3 = BufferUtils.createByteBuffer((int)((n4 + 1) * (n5 + 1) * 12)).order(ByteOrder.nativeOrder());
        for (int n3 = 0; n3 <= n5; ++n3) {
            for (n = 0; n <= n4; ++n) {
                byteBuffer3.putFloat((float)n / (float)n4);
                float f = (float)n3 / (float)n5;
                byteBuffer3.putFloat(f);
                byteBuffer3.putFloat(0.0f);
            }
        }
        byteBuffer3.flip();
        dripVbo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$4, 32, byteBuffer3);
        ByteBuffer byteBuffer4 = BufferUtils.createByteBuffer((int)(n4 * n5 * 6 * 4)).order(ByteOrder.nativeOrder());
        for (n = 0; n < n5; ++n) {
            for (int i = 0; i < n4; ++i) {
                int n6 = n * (n4 + 1) + i;
                int n7 = n6 + 1;
                int n8 = n6 + n4 + 1;
                int n9 = n8 + 1;
                byteBuffer4.putInt(n6);
                byteBuffer4.putInt(n8);
                byteBuffer4.putInt(n7);
                byteBuffer4.putInt(n7);
                byteBuffer4.putInt(n8);
                byteBuffer4.putInt(n9);
            }
        }
        byteBuffer4.flip();
        dripIndices = n4 * n5 * 6;
        dripIbo = gpuDevice.createBuffer(ItemFxRenderer::lmbd$ensureStatic$5, 64, byteBuffer4);
    }

    static void submit(class_11659 class_116592, class_4587 class_45872, int n, int n2, int n3, boolean bl, float f) {
        Light light = COMMANDS[nextCommand];
        nextCommand = (nextCommand + 1) % COMMANDS.length;
        light.fx = n;
        light.ctx = n2;
        light.light = n3;
        light.glint = bl;
        light.act = f;
        class_116592.method_73483(class_45872, layer, (class_11659.class_11660)light);
    }

    public static void flush(class_9801 class_98012) {
        try {
            class_98012.close();
        }
        catch (Throwable throwable) {

        }
        int n = pending;
        pending = 0;
        if (n == 0 || failed) {
            return;
        }
        try {
            ItemFxRenderer.draw(n);
            return;
        }
        catch (Throwable throwable) {
            failed = true;
            System.err.println("Kryzex: custom item rendering disabled after an error: " + String.valueOf(throwable));
            throwable.printStackTrace();
        }
    }

    private static void draw(int n) {
        class_310 class_3102 = class_310.method_1551();
        class_276 class_2762 = class_3102.method_1522();
        GpuTextureView gpuTextureView2 = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_2762.method_71639();
        GpuTextureView gpuTextureView = RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : (class_2762.field_1478 ? class_2762.method_71640() : null);
        if (gpuTextureView2 == null || !Flat.ready(GLOW_PIPE) || !Flat.ready(SMOKE_PIPE)) {
            return;
        }
        ItemFxRenderer.ensureStatic();
        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        MV.set((Matrix4fc)RenderSystem.getModelViewMatrix());
        boolean bl = Flat.ready(DRIP_PIPE);
        long l = TotemUndying.frameIndex();
        if (l != dripFrame) {
            dripFrame = l;
            dripData.clear();
            NextSpawn.write(dripData, 0);
            dripData.position(0);
            dripData.limit(784);
            commandEncoder.writeToBuffer(dripUbo.slice(), dripData);
        }
        int n2 = Math.round(dripData.getFloat(0));
        GpuTextureView gpuTextureView4 = class_3102.field_1773.method_22974().method_71650();
        class_12137 class_121372 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
        class_11219 class_112192 = RenderSystem.getScissorStateForRenderTypeDraws();
        class_12137 class_121373 = RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.NEAREST, FilterMode.NEAREST, false);
        class_12137 class_121374 = RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
        for (int i = 0; i < n; i += 32) {
            int n3 = Math.min(32, n - i);
            data.clear();
            for (int j = 0; j < n3; ++j) {
                ItemFxRenderer.writeInstance(i + j, j * stride);
            }
            data.position(0);
            data.limit(n3 * stride);
            commandEncoder.writeToBuffer(ubo.slice(0L, (long)n3 * (long)stride), data);
            try (RenderPass renderPass = commandEncoder.createRenderPass(ItemFxRenderer::lmbd$draw$0, gpuTextureView2, OptionalInt.empty(), gpuTextureView, OptionalDouble.empty());){
                Count count;
                int n4;
                int n5;
                int n6;
                if (class_112192.method_72091()) {
                    renderPass.enableScissor(class_112192.method_72092(), class_112192.method_72093(), class_112192.method_72094(), class_112192.method_72095());
                }
                boolean bl2 = false;
                for (n6 = 0; n6 < n3; ++n6) {
                    n5 = FX[i + n6];
                    n4 = TotemUndying.design(n5);
                    count = MESHES.get(ItemFxRenderer.meshKey(n4, TotemUndying.type(n5), TotemUndying.tier(n5)));
                    if (count == null || n4 > 3) continue;
                    if (!bl2) {
                        renderPass.setPipeline(MESH_PIPE);
                        RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                        renderPass.bindTexture("Sampler2", gpuTextureView4, class_121372);
                        bl2 = true;
                    }
                    renderPass.setUniform("ItemFx", ubo.slice((long)n6 * (long)stride, 272L));
                    renderPass.setVertexBuffer(0, count.vbo());
                    renderPass.setIndexBuffer(count.ibo(), VertexFormat.class_5595.field_27373);
                    renderPass.drawIndexed(0, 0, count.count(), 1);
                }
                bl2 = false;
                for (n6 = 0; n6 < n3; ++n6) {
                    n5 = FX[i + n6];
                    n4 = TotemUndying.design(n5);
                    count = MESHES.get(ItemFxRenderer.meshKey(n4, TotemUndying.type(n5), TotemUndying.tier(n5)));
                    if (count == null || n4 != 4 && n4 != 5) continue;
                    if (!bl2) {
                        renderPass.setPipeline(SPRITE_PIPE);
                        RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                        renderPass.bindTexture("Sampler0", atlasView, class_121373);
                        renderPass.bindTexture("Sampler2", gpuTextureView4, class_121372);
                        bl2 = true;
                    }
                    renderPass.setUniform("ItemFx", ubo.slice((long)n6 * (long)stride, 272L));
                    renderPass.setVertexBuffer(0, count.vbo());
                    renderPass.setIndexBuffer(count.ibo(), VertexFormat.class_5595.field_27373);
                    renderPass.drawIndexed(0, 0, count.main(), 1);
                }
                if (bl) {
                    bl2 = false;
                    for (n6 = 0; n6 < n3; ++n6) {
                        n5 = FX[i + n6];
                        if (TotemUndying.design(n5) != 2 && TotemUndying.design(n5) != 5 || (n4 = (TotemUndying.animations(n5) ? n2 : 0) + (ACT[i + n6] >= 0.0f && TotemUndying.popFx(n5) ? 18 : 0)) <= 0) continue;
                        if (!bl2) {
                            renderPass.setPipeline(DRIP_PIPE);
                            RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                            renderPass.bindTexture("Sampler2", gpuTextureView4, class_121372);
                            renderPass.setUniform("ItemFxDrips", dripUbo);
                            renderPass.setVertexBuffer(0, dripVbo);
                            renderPass.setIndexBuffer(dripIbo, VertexFormat.class_5595.field_27373);
                            bl2 = true;
                        }
                        renderPass.setUniform("ItemFx", ubo.slice((long)n6 * (long)stride, 272L));
                        renderPass.drawIndexed(0, 0, dripIndices, n4);
                    }
                }
                for (n6 = 0; n6 < n3; ++n6) {
                    Count count2;
                    n5 = FX[i + n6];
                    if (TotemUndying.design(n5) != 6 || (count2 = MESHES.get(ItemFxRenderer.meshKey(6, 0, 0))) == null) continue;
                    renderPass.setPipeline(GHOST_BACK_PIPE);
                    RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                    renderPass.bindTexture("Sampler0", atlasView, class_121373);
                    renderPass.bindTexture("Sampler2", gpuTextureView4, class_121372);
                    renderPass.setUniform("ItemFx", ubo.slice((long)n6 * (long)stride, 272L));
                    renderPass.setVertexBuffer(0, count2.vbo());
                    renderPass.setIndexBuffer(count2.ibo(), VertexFormat.class_5595.field_27373);
                    renderPass.drawIndexed(0, 0, count2.main(), 1);
                    if (TotemUndying.particles(n5)) {
                        renderPass.setPipeline(SKULL_PIPE);
                        RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                        renderPass.bindTexture("Sampler0", atlasView, class_121373);
                        renderPass.setVertexBuffer(0, quadVbo);
                        renderPass.setIndexBuffer(quadIbo, VertexFormat.class_5595.field_27373);
                        renderPass.drawIndexed(0, 0, 6, 5);
                    }
                    renderPass.setPipeline(GHOST_FRONT_PIPE);
                    RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                    renderPass.bindTexture("Sampler0", atlasView, class_121373);
                    renderPass.bindTexture("Sampler2", gpuTextureView4, class_121372);
                    renderPass.setVertexBuffer(0, count2.vbo());
                    renderPass.setIndexBuffer(count2.ibo(), VertexFormat.class_5595.field_27373);
                    renderPass.drawIndexed(0, 0, count2.main(), 1);
                }
                bl2 = false;
                for (n6 = 0; n6 < n3; ++n6) {
                    n5 = FX[i + n6];
                    int n7 = TotemUndying.design(n5);
                    if (n7 < 4 || (count = MESHES.get(ItemFxRenderer.meshKey(n7, TotemUndying.type(n5), TotemUndying.tier(n5)))) == null || count.count() <= count.main()) continue;
                    if (!bl2) {
                        renderPass.setPipeline(HALO_PIPE);
                        RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                        renderPass.bindTexture("Sampler0", atlasView, class_121374);
                        bl2 = true;
                    }
                    renderPass.setUniform("ItemFx", ubo.slice((long)n6 * (long)stride, 272L));
                    renderPass.setVertexBuffer(0, count.vbo());
                    renderPass.setIndexBuffer(count.ibo(), VertexFormat.class_5595.field_27373);
                    renderPass.drawIndexed(0, count.main(), count.count() - count.main(), 1);
                }
                ItemFxRenderer.particles(renderPass, i, n3, true);
                ItemFxRenderer.particles(renderPass, i, n3, false);
                continue;
            }
        }
    }

    private static void particles(RenderPass renderPass, int n, int n2, boolean bl) {
        boolean bl2 = false;
        for (int i = 0; i < n2; ++i) {
            int n3;
            int n4 = FX[n + i];
            int n5 = n3 = bl ? TotemUndying.glowCount(n4, ACT[n + i]) : TotemUndying.smokeCount(n4, ACT[n + i]);
            if (n3 <= 0) continue;
            if (!bl2) {
                renderPass.setPipeline(bl ? GLOW_PIPE : SMOKE_PIPE);
                RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                renderPass.setVertexBuffer(0, quadVbo);
                renderPass.setIndexBuffer(quadIbo, VertexFormat.class_5595.field_27373);
                bl2 = true;
            }
            renderPass.setUniform("ItemFx", ubo.slice((long)i * (long)stride, 272L));
            renderPass.drawIndexed(0, 0, 6, n3);
        }
    }

    private static void writeInstance(int n, int n2) {
        int n3 = FX[n];
        int n4 = TotemUndying.design(n3);
        int n5 = CTX[n];
        float f = ACT[n];
        float f2 = TotemUndying.time();
        TotemUndying.anim(ANIM, n3, n5, f, f2);
        TMP.set((Matrix4fc)POSE[n]).mul((Matrix4fc)ANIM);
        TMP3.set((Matrix3fc)NRM[n]).mul((Matrix3fc)ANIM.get3x3(ANIM3));
        NM.identity().set((Matrix3fc)TMP3);
        ByteBuffer byteBuffer = data;
        MV.get(n2, byteBuffer);
        TMP.get(n2 + 64, byteBuffer);
        NM.get(n2 + 128, byteBuffer);
        int n6 = LIGHT[n];
        boolean bl = n5 == 2 || n5 == 3;
        ItemFxRenderer.put4(byteBuffer, n2 + 192, f2, f, n4, n5);
        ItemFxRenderer.put4(byteBuffer, n2 + 208, (n6 & 0xFFFF) >> 4, n6 >>> 16 >> 4, bl ? 0.0f : 1.0f, GLINT[n] ? 1.0f : 0.0f);
        float f3 = (float)Math.sqrt(TMP.m00() * TMP.m00() + TMP.m01() * TMP.m01() + TMP.m02() * TMP.m02());
        ItemFxRenderer.put4(byteBuffer, n2 + 224, 0.0f, n5 == 2 ? -1.0f : 1.0f, 0.0f, f3);
        ItemFxRenderer.put4(byteBuffer, n2 + 240, TotemUndying.tier(n3), TotemUndying.shaderStyle(n3), TotemUndying.type(n3), TotemUndying.animations(n3) ? 1.0f : 0.0f);
        ItemFxRenderer.put4(byteBuffer, n2 + 256, TotemUndying.particles(n3) ? 1.0f : 0.0f, TotemUndying.intensity(n3), n4 == 3 ? 0.17f * (float)TotemUndying.type(n3) + 0.05f * (float)TotemUndying.tier(n3) : 0.37f, TotemUndying.tint(n3));
    }

    private static void put4(ByteBuffer byteBuffer, int n, float f, float f2, float f3, float f4) {
        byteBuffer.putFloat(n, f);
        byteBuffer.putFloat(n + 4, f2);
        byteBuffer.putFloat(n + 8, f3);
        byteBuffer.putFloat(n + 12, f4);
    }

    public static void releaseModels() {
        for (Count count : MESHES.values()) {
            try {
                count.close();
            }
            catch (Throwable throwable) {}
        }
        MESHES.clear();
        pending = 0;
        if (atlasView == null) return;
        atlasView.close();
        atlas.close();
        atlasView = null;
        atlas = null;
    }

    private static String lmbd$draw$0() {
        return "Kryzex items";
    }

    private static String lmbd$ensureStatic$5() {
        return "Kryzex drip indices";
    }

    private static String lmbd$ensureStatic$4() {
        return "Kryzex drip";
    }

    private static String lmbd$ensureStatic$3() {
        return "Kryzex fx quad indices";
    }

    private static String lmbd$ensureStatic$2() {
        return "Kryzex fx quad";
    }

    private static String lmbd$ensureStatic$1() {
        return "Kryzex item fx drips";
    }

    private static String lmbd$ensureStatic$0() {
        return "Kryzex item fx instances";
    }

    private static String lmbd$upload$1(int n) {
        return "Kryzex item model indices " + n;
    }

    private static String lmbd$upload$0(int n) {
        return "Kryzex item model " + n;
    }

    private static String lmbd$ensureAtlas$0() {
        return "Kryzex item atlas";
    }

    private static CompletableFuture lmbd$ready$0(Integer n) {
        return CompletableFuture.supplyAsync(() -> ItemFxRenderer.lmbd$ready$1(n), BUILDER);
    }

    private static Anchors lmbd$ready$1(Integer n) {
        return ItemFxRenderer.buildModel(n);
    }

    private static Thread lmbd$static$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "Kryzex item models");
        thread.setDaemon(true);
        thread.setPriority(1);
        return thread;
    }

    static {
        int n;
        FORMAT = class_290.field_1580;
        MESH_PIPE = ItemFxRenderer.base("pipeline/fx_item", Flat.MESH, FORMAT).withUniform("Lighting", class_10789.field_60031).withSampler("Sampler2").withDepthWrite(true).build();
        DRIP_PIPE = ItemFxRenderer.base("pipeline/fx_drip", Flat.DRIP, class_290.field_1592).withUniform("Lighting", class_10789.field_60031).withUniform("ItemFxDrips", class_10789.field_60031).withSampler("Sampler2").withDepthWrite(true).build();
        GLOW_PIPE = ItemFxRenderer.base("pipeline/fx_glow", Flat.GLOW, class_290.field_1592).withBlend(new BlendFunction(SourceFactor.ONE, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE)).withDepthWrite(false).build();
        SMOKE_PIPE = ItemFxRenderer.base("pipeline/fx_smoke", Flat.SMOKE, class_290.field_1592).withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withDepthWrite(false).build();
        ADD = new BlendFunction(SourceFactor.ONE, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE);
        SPRITE_PIPE = ItemFxRenderer.base("pipeline/fx_sprite", Flat.SPRITE, FORMAT).withUniform("Lighting", class_10789.field_60031).withSampler("Sampler0").withSampler("Sampler2").withDepthWrite(true).build();
        GHOST_BACK_PIPE = ItemFxRenderer.base("pipeline/fx_ghost_back", Flat.GHOST_BACK, FORMAT).withSampler("Sampler0").withSampler("Sampler2").withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withDepthWrite(true).build();
        GHOST_FRONT_PIPE = ItemFxRenderer.base("pipeline/fx_ghost_front", Flat.GHOST_FRONT, FORMAT).withSampler("Sampler0").withSampler("Sampler2").withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withDepthWrite(true).build();
        HALO_PIPE = ItemFxRenderer.base("pipeline/fx_halo", Flat.HALO, FORMAT).withSampler("Sampler0").withBlend(ADD).withDepthWrite(false).build();
        SKULL_PIPE = ItemFxRenderer.base("pipeline/fx_skull", Flat.SKULL, class_290.field_1592).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withDepthWrite(true).build();
        MARKER_PIPE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/fx_marker")).withVertexShader(Flat.MESH).withFragmentShader(Flat.MESH).withVertexFormat(FORMAT, VertexFormat.class_5596.field_27382).build();
        POSE = new Matrix4f[128];
        NRM = new Matrix3f[128];
        FX = new int[128];
        CTX = new int[128];
        LIGHT = new int[128];
        ACT = new float[128];
        GLINT = new boolean[128];
        COMMANDS = new Light[512];
        MESHES = new HashMap<Integer, Count>();
        BUILDS = new HashMap<Integer, CompletableFuture<Anchors>>();
        ANCHORS = new HashMap<Integer, float[]>();
        BUILDER = Executors.newSingleThreadExecutor(ItemFxRenderer::lmbd$static$0);
        dripFrame = -1L;
        TMP = new Matrix4f();
        ANIM = new Matrix4f();
        MV = new Matrix4f();
        NM = new Matrix4f();
        TMP3 = new Matrix3f();
        ANIM3 = new Matrix3f();
        for (n = 0; n < 128; ++n) {
            ItemFxRenderer.POSE[n] = new Matrix4f();
            ItemFxRenderer.NRM[n] = new Matrix3f();
        }
        for (n = 0; n < COMMANDS.length; ++n) {
            ItemFxRenderer.COMMANDS[n] = new Light();
        }
    }
}
