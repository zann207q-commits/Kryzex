package kryzex.fx;

import kryzex.fx.VertexCount;

class Anchors {
    public final VertexCount mesh;
    public final int main;
    public final float[] anchors;

    public Anchors(VertexCount mesh, int main, float[] anchors) {
        this.mesh = mesh;
        this.main = main;
        this.anchors = anchors;
    }

    public VertexCount mesh() {
        return this.mesh;
    }

    public int main() {
        return this.main;
    }

    public float[] anchors() {
        return this.anchors;
    }
}
