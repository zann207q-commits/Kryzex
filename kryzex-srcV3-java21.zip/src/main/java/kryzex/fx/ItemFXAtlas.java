package kryzex.fx;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.Arrays;
import javax.imageio.ImageIO;
import kryzex.fx.Indices;
import kryzex.fx.MainIndices;
import kryzex.fx.FxPalette;

public final class ItemFXAtlas {
    public static final int SPOOKY = 1;
    public static final int CHROME = 2;
    public static final int GHOST = 3;
    private static int[] atlas;

    private ItemFXAtlas() {
    }

    static synchronized int[] atlas() {
        if (atlas != null) return atlas;
        try (InputStream inputStream = ItemFXAtlas.class.getResourceAsStream("/assets/r87f4560b4c09f4/rb52d8d2fd2d9d6/atlas.png");){
            BufferedImage bufferedImage = ImageIO.read(inputStream);
            atlas = bufferedImage.getRGB(0, 0, 128, 128, null, 0, 128);
            return atlas;
        }
        catch (Exception exception) {
            throw new IllegalStateException("item fx atlas missing", exception);
        }
    }

    public static MainIndices build(int n) {
        int[] nArray = ItemFXAtlas.atlas();
        Indices indices = new Indices();
        float[] fArray = new float[]{};
        if (n == 1) {
            float f = 0.025f;
            float f2 = -0.4f;
            float f3 = 0.315f;
            indices.sprite(nArray, FxPalette.SPOOKY_CELL, false, false, f2, f3, f, -0.025f, 0.025f, 20, 0, 0.0f, 0.0f, 0.0f);
            float f4 = f * 0.82f;
            float f5 = f3 - 2.0f * f;
            float f6 = f5 - 3.0f * f + 14.5f * f4;
            float f7 = -8.0f * f4;
            indices.sprite(nArray, FxPalette.HAT_CELL, false, false, f7, f6, f4, -0.031f, 0.031f, 23, 11, (float)Math.toRadians(-8.0), 0.0f, f5 - 2.0f * f);
            float f8 = f * 0.62f;
            float f9 = f2 + 8.0f * f;
            float f10 = f3 - 16.0f * f;
            indices.sprite(nArray, FxPalette.WEB_CELL, true, true, f9 - 16.0f * f8, f10 + 16.0f * f8, f8, -0.004f, 0.004f, 23, 0, 0.0f, 0.0f, 0.0f);
            float f11 = f * 0.75f;
            float f12 = f2 + 26.5f * f;
            float f13 = f3 - 21.0f * f;
            float f14 = 0.12f;
            indices.thread(nArray, f12, f13, f13 - f14, f11 * 0.45f);
            indices.sprite(nArray, FxPalette.SPIDER_CELL, false, false, f12 - 3.5f * f11, f13 - f14 + 0.5f * f11, f11, -0.012f, 0.012f, 23, 12, 0.0f, 0.0f, 0.0f);
            float f15 = f * 0.8f;
            indices.sprite(nArray, FxPalette.BAT_A_CELL, false, false, -6.0f * f15, 3.5f * f15, f15, -0.01f, 0.01f, 23, 14, 0.0f, 0.0f, 0.0f);
            indices.sprite(nArray, FxPalette.BAT_A_CELL, false, false, -6.0f * f15, 3.5f * f15, f15, -0.01f, 0.01f, 23, 15, 0.0f, 0.0f, 0.0f);
            int n2 = indices.indexCount();
            indices.halo(FxPalette.SPOOKY_CELL, f2, f3, f, 0.028f, -0.028f, 6);
            return new MainIndices(indices.build(), n2, fArray);
        }
        if (n == 2) {
            float f = 0.03125f;
            indices.sprite(nArray, FxPalette.CHROME_CELL, false, false, -0.5f, 0.5f, f, -0.03125f, 0.03125f, 21, 0, 0.0f, 0.0f, 0.0f);
            int n3 = indices.indexCount();
            indices.halo(FxPalette.CHROME_CELL, -0.5f, 0.5f, f, 0.034f, -0.034f, 5);
            fArray = ItemFXAtlas.bottomEdges(nArray, FxPalette.CHROME_CELL, -0.5f, 0.5f, f);
            return new MainIndices(indices.build(), n3, fArray);
        }
        float f = 0.03125f;
        indices.sprite(nArray, FxPalette.PICK_CELL, false, false, -0.5f, 0.5f, f, -0.075f, 0.075f, 22, 0, 0.0f, 0.0f, 0.0f);
        int n4 = indices.indexCount();
        indices.halo(FxPalette.PICK_CELL, -0.5f, 0.5f, f, 0.078f, -0.078f, 7);
        return new MainIndices(indices.build(), n4, fArray);
    }

    static float[] bottomEdges(int[] nArray, int[] nArray2, float f, float f2, float f3) {
        float[] fArray = new float[nArray2[2] * nArray2[3] * 3];
        int n = 0;
        for (int i = 0; i < nArray2[3]; ++i) {
            for (int j = 0; j < nArray2[2]; ++j) {
                if (!ItemFXAtlas.opaque(nArray, nArray2, j, i) || ItemFXAtlas.opaque(nArray, nArray2, j, i + 1)) continue;
                fArray[n++] = f + ((float)j + 0.5f) * f3;
                fArray[n++] = f2 - ((float)i + 1.0f) * f3;
                fArray[n++] = 0.0f;
            }
        }
        return Arrays.copyOf(fArray, n);
    }

    static boolean opaque(int[] nArray, int[] nArray2, int n, int n2) {
        if (n < 0) return false;
        if (n2 < 0) return false;
        if (n >= nArray2[2]) return false;
        if (n2 >= nArray2[3]) {
            return false;
        }
        if (nArray[(nArray2[1] + n2) * 128 + nArray2[0] + n] >>> 24 <= 0) return false;
        return true;
    }
}
