package kryzex.fx;

import com.mojang.blaze3d.buffers.GpuBuffer;

record Count(GpuBuffer vbo, GpuBuffer ibo, int count, int main) implements AutoCloseable
{
    @Override
    public void close() {
        this.vbo.close();
        this.ibo.close();
    }
}
