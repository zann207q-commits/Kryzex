package kryzex.fx;

import net.minecraft.class_10444;

public interface ItemFxAccess {
    public int kryzex$fx();

    public void kryzex$setFx(int var1);

    public class_10444.class_10446 kryzex$layer0();
}
