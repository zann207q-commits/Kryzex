package kryzex.fx;

import kryzex.fx.VertexCount;

public final class MainIndices {
    public final VertexCount mesh;
    public final int mainIndices;
    public final float[] anchors;

    MainIndices(VertexCount vertexCount, int n, float[] fArray) {
        this.mesh = vertexCount;
        this.mainIndices = n;
        this.anchors = fArray;
    }
}
