package kryzex.fx;

import java.util.Arrays;
import kryzex.fx.Data;
import kryzex.fx.Data2;
import kryzex.fx.Region;
import kryzex.fx.Sdf;
import kryzex.fx.VertexCount;
import kryzex.fx.SurfacePainter;
import kryzex.fx.ScalarField;

public final class MeshBuilder {
    private static final int[] EDGE_A = new int[]{0, 2, 4, 6, 0, 1, 4, 5, 0, 1, 2, 3};
    private static final int[] EDGE_B = new int[]{1, 3, 5, 7, 2, 3, 6, 7, 4, 5, 6, 7};

    private MeshBuilder() {
    }

    public static VertexCount build(ScalarField mr2, SurfacePainter dd2, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        float f15;
        float f16;
        float f17;
        float f18;
        int n;
        float f19;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7 = (int)Math.ceil((f4 - f) / f7) + 1;
        int n8 = (int)Math.ceil((f5 - f2) / f7) + 1;
        int n9 = (int)Math.ceil((f6 - f3) / f7) + 1;
        float[] fArray = new float[n7 * n8 * n9];
        for (n6 = 0; n6 < n9; ++n6) {
            float f20 = f3 + (float)n6 * f7;
            for (n5 = 0; n5 < n8; ++n5) {
                float f21 = f2 + (float)n5 * f7;
                int n10 = n7 * (n5 + n8 * n6);
                for (int i = 0; i < n7; ++i) {
                    fArray[n10 + i] = mr2.at(f + (float)i * f7, f21, f20);
                }
            }
        }
        n6 = n7 - 1;
        int n11 = n8 - 1;
        n5 = n9 - 1;
        int[] nArray = new int[n6 * n11 * n5];
        Arrays.fill(nArray, -1);
        Data2 data2 = new Data2(16384);
        float[] fArray2 = new float[8];
        for (int i = 0; i < n5; ++i) {
            for (n4 = 0; n4 < n11; ++n4) {
                for (n3 = 0; n3 < n6; ++n3) {
                    n2 = 0;
                    for (int j = 0; j < 8; ++j) {
                        fArray2[j] = fArray[n3 + (j & 1) + n7 * (n4 + (j >> 1 & 1) + n8 * (i + (j >> 2 & 1)))];
                        if (!(fArray2[j] < 0.0f)) continue;
                        n2 |= 1 << j;
                    }
                    if (n2 == 0 || n2 == 255) continue;
                    float f22 = 0.0f;
                    f19 = 0.0f;
                    float f23 = 0.0f;
                    n = 0;
                    for (int j = 0; j < 12; ++j) {
                        int n12 = EDGE_A[j];
                        int n13 = EDGE_B[j];
                        if ((n2 >> n12 & 1) == (n2 >> n13 & 1)) continue;
                        f18 = fArray2[n12] / (fArray2[n12] - fArray2[n13]);
                        f17 = n12 & 1;
                        f16 = n12 >> 1 & 1;
                        f15 = n12 >> 2 & 1;
                        f14 = n13 & 1;
                        f13 = n13 >> 1 & 1;
                        float f24 = n13 >> 2 & 1;
                        f22 += f17 + (f14 - f17) * f18;
                        f19 += f16 + (f13 - f16) * f18;
                        f23 += f15 + (f24 - f15) * f18;
                        ++n;
                    }
                    float f25 = f + ((float)n3 + f22 / (float)n) * f7;
                    float f26 = f2 + ((float)n4 + f19 / (float)n) * f7;
                    f12 = f3 + ((float)i + f23 / (float)n) * f7;
                    f18 = f + ((float)n3 - 0.5f) * f7;
                    f17 = f2 + ((float)n4 - 0.5f) * f7;
                    f16 = f3 + ((float)i - 0.5f) * f7;
                    f15 = f18 + 2.0f * f7;
                    f14 = f17 + 2.0f * f7;
                    f13 = f16 + 2.0f * f7;
                    for (int j = 0; j < 3; ++j) {
                        float f27;
                        float f28;
                        f11 = mr2.at(f25, f26, f12);
                        f10 = f7 * 0.25f;
                        f9 = mr2.at(f25 + f10, f26, f12) - mr2.at(f25 - f10, f26, f12);
                        float f29 = f9 * f9 + (f28 = mr2.at(f25, f26 + f10, f12) - mr2.at(f25, f26 - f10, f12)) * f28 + (f27 = mr2.at(f25, f26, f12 + f10) - mr2.at(f25, f26, f12 - f10)) * f27;
                        if (f29 < 1.0E-12f) break;
                        float f30 = f11 * 2.0f * f10 / f29;
                        f25 = Sdf.clamp(f25 - f9 * f30, f18, f15);
                        f26 = Sdf.clamp(f26 - f28 * f30, f17, f14);
                        f12 = Sdf.clamp(f12 - f27 * f30, f16, f13);
                    }
                    nArray[n3 + n6 * (n4 + n11 * i)] = data2.size() / 3;
                    data2.add(f25);
                    data2.add(f26);
                    data2.add(f12);
                }
            }
        }
        Data data = new Data(32768);
        for (n4 = 1; n4 < n9 - 1; ++n4) {
            for (n3 = 1; n3 < n8 - 1; ++n3) {
                for (n2 = 0; n2 < n7 - 1; ++n2) {
                    float f31 = fArray[n2 + n7 * (n3 + n8 * n4)];
                    if (f31 < 0.0f == (f19 = fArray[n2 + 1 + n7 * (n3 + n8 * n4)]) < 0.0f) continue;
                    MeshBuilder.quad(data, f31 < 0.0f, nArray, n6, n11, n2, n3 - 1, n4 - 1, n2, n3, n4 - 1, n2, n3, n4, n2, n3 - 1, n4);
                }
            }
        }
        for (n4 = 1; n4 < n9 - 1; ++n4) {
            for (n3 = 0; n3 < n8 - 1; ++n3) {
                for (n2 = 1; n2 < n7 - 1; ++n2) {
                    float f32 = fArray[n2 + n7 * (n3 + n8 * n4)];
                    if (f32 < 0.0f == (f19 = fArray[n2 + n7 * (n3 + 1 + n8 * n4)]) < 0.0f) continue;
                    MeshBuilder.quad(data, f32 < 0.0f, nArray, n6, n11, n2 - 1, n3, n4 - 1, n2 - 1, n3, n4, n2, n3, n4, n2, n3, n4 - 1);
                }
            }
        }
        for (n4 = 0; n4 < n9 - 1; ++n4) {
            for (n3 = 1; n3 < n8 - 1; ++n3) {
                for (n2 = 1; n2 < n7 - 1; ++n2) {
                    float f33 = fArray[n2 + n7 * (n3 + n8 * n4)];
                    if (f33 < 0.0f == (f19 = fArray[n2 + n7 * (n3 + n8 * (n4 + 1))]) < 0.0f) continue;
                    MeshBuilder.quad(data, f33 < 0.0f, nArray, n6, n11, n2 - 1, n3 - 1, n4, n2, n3 - 1, n4, n2, n3, n4, n2 - 1, n3, n4);
                }
            }
        }
        n4 = data2.size() / 3;
        n3 = data.size() / 4 * 2;
        VertexCount vertexCount = new VertexCount(n4, n3);
        System.arraycopy(data2.data, 0, vertexCount.pos, 0, n4 * 3);
        int n14 = 0;
        for (int i = 0; i < data.size(); i += 4) {
            int n15 = data.data[i];
            n = data.data[i + 1];
            int n16 = data.data[i + 2];
            int n17 = data.data[i + 3];
            if (MeshBuilder.dist2(vertexCount.pos, n15, n16) <= MeshBuilder.dist2(vertexCount.pos, n, n17)) {
                n14 = MeshBuilder.tri(vertexCount.indices, n14, n15, n, n16);
                n14 = MeshBuilder.tri(vertexCount.indices, n14, n15, n16, n17);
                continue;
            }
            n14 = MeshBuilder.tri(vertexCount.indices, n14, n15, n, n17);
            n14 = MeshBuilder.tri(vertexCount.indices, n14, n, n16, n17);
        }
        Region region = new Region();
        float f34 = f7 * 0.35f;
        for (n = 0; n < n4; ++n) {
            float f35 = vertexCount.pos[n * 3];
            float f36 = vertexCount.pos[n * 3 + 1];
            f12 = vertexCount.pos[n * 3 + 2];
            f18 = mr2.at(f35 + f34, f36, f12) - mr2.at(f35 - f34, f36, f12);
            f15 = (float)Math.sqrt(f18 * f18 + (f17 = mr2.at(f35, f36 + f34, f12) - mr2.at(f35, f36 - f34, f12)) * f17 + (f16 = mr2.at(f35, f36, f12 + f34) - mr2.at(f35, f36, f12 - f34)) * f16);
            if (f15 < 1.0E-9f) {
                f18 = 0.0f;
                f17 = 1.0f;
                f16 = 0.0f;
            } else {
                f18 /= f15;
                f17 /= f15;
                f16 /= f15;
            }
            vertexCount.nrm[n * 3] = f18;
            vertexCount.nrm[n * 3 + 1] = f17;
            vertexCount.nrm[n * 3 + 2] = f16;
            f14 = 0.0f;
            f13 = 0.0f;
            for (int i = 1; i <= 5; ++i) {
                f11 = f8 * (float)i / 5.0f;
                f10 = mr2.at(f35 + f18 * f11, f36 + f17 * f11, f12 + f16 * f11);
                f9 = 1.0f / (float)i;
                f14 += f9 * Sdf.clamp((f11 - f10) / f11, 0.0f, 1.0f);
                f13 += f9;
            }
            float f37 = 1.0f - f14 / f13;
            region.reset();
            dd2.paint(f35, f36, f12, f18, f17, f16, region);
            f37 = Sdf.clamp(f37 * region.ao, 0.0f, 1.0f);
            vertexCount.rgba[n] = (Math.round(f37 * 255.0f) & 0xFF) << 24 | region.rgb & 0xFFFFFF;
            vertexCount.mat[n] = (short)region.mat;
            vertexCount.region[n] = (short)region.region;
            vertexCount.p1[n] = (short)Math.round(Sdf.clamp(region.p1, 0.0f, 1.0f) * 1000.0f);
            vertexCount.p2[n] = (short)Math.round(Sdf.clamp(region.p2, 0.0f, 1.0f) * 1000.0f);
            vertexCount.uv[n * 2] = region.u;
            vertexCount.uv[n * 2 + 1] = region.v;
        }
        return vertexCount;
    }

    private static void quad(Data data, boolean bl, int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14) {
        int n15 = nArray[n3 + n * (n4 + n2 * n5)];
        int n16 = nArray[n6 + n * (n7 + n2 * n8)];
        int n17 = nArray[n9 + n * (n10 + n2 * n11)];
        int n18 = nArray[n12 + n * (n13 + n2 * n14)];
        if (n15 < 0 || n16 < 0 || n17 < 0 || n18 < 0) {
            return;
        }
        if (bl) {
            data.add(n15);
            data.add(n16);
            data.add(n17);
            data.add(n18);
            return;
        } else {
            data.add(n18);
            data.add(n17);
            data.add(n16);
            data.add(n15);
        }
    }

    private static int tri(int[] nArray, int n, int n2, int n3, int n4) {
        nArray[n] = n2;
        nArray[n + 1] = n3;
        nArray[n + 2] = n4;
        return n + 3;
    }

    private static float dist2(float[] fArray, int n, int n2) {
        float f = fArray[n * 3] - fArray[n2 * 3];
        float f2 = fArray[n * 3 + 1] - fArray[n2 * 3 + 1];
        float f3 = fArray[n * 3 + 2] - fArray[n2 * 3 + 2];
        return f * f + f2 * f2 + f3 * f3;
    }
}
