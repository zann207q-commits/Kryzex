package kryzex.fx;

import kryzex.fx.MeshBuilder;
import kryzex.fx.Region;
import kryzex.fx.Tatter;
import kryzex.fx.Sdf;
import kryzex.fx.VertexCount;
import kryzex.fx.FxPalette;

public final class SpookyDesign {
    private static final Tatter SHAPE = new Tatter(0.042f, 0.0f, 0.0f, 1.0f);
    private static final float FACE_Z = 0.112f;
    private static final float CARVE_DEPTH = 0.046f;
    private static final float[] EYE_L = new float[]{-0.1f, 0.32f, -0.021f, 0.3f, -0.025f, 0.276f, -0.092f, 0.284f};
    private static final float[] EYE_R = new float[]{0.1f, 0.32f, 0.092f, 0.284f, 0.025f, 0.276f, 0.021f, 0.3f};
    private static final float[] MOUTH = new float[]{-0.09f, 0.214f, -0.06f, 0.192f, -0.035f, 0.187f, -0.025f, 0.204f, -0.015f, 0.187f, 0.015f, 0.187f, 0.025f, 0.204f, 0.035f, 0.187f, 0.06f, 0.192f, 0.09f, 0.214f, 0.066f, 0.229f, 0.056f, 0.229f, 0.048f, 0.207f, 0.04f, 0.229f, -0.04f, 0.229f, -0.048f, 0.207f, -0.056f, 0.229f, -0.066f, 0.229f};
    private static final float GEM_Z = 0.112f;

    private SpookyDesign() {
    }

    public static VertexCount build() {
        return MeshBuilder.build(SpookyDesign::field, SpookyDesign::paint, -0.47f, -0.51f, -0.18f, 0.47f, 0.46f, 0.18f, 0.008333334f, 0.07f);
    }

    static float carve(float f, float f2, float f3) {
        if (f3 < 0.046f || f2 < 0.16f || f2 > 0.36f) {
            return 1.0f;
        }
        float f4 = Math.min(Math.min(Sdf.polygon(f, f2, EYE_L), Sdf.polygon(f, f2, EYE_R)), Sdf.polygon(f, f2, MOUTH));
        return Math.max(f4, 0.066f - f3);
    }

    static float features(float f, float f2, float f3) {
        if (f3 < 0.07f || f2 < 0.22f || f2 > 0.37f) {
            return 1.0f;
        }
        float f4 = Math.abs(f);
        float f5 = Sdf.roundCone(f4, f2, f3, 0.104f, 0.338f, 0.108f, 0.02f, 0.316f, 0.112f, 0.0115f, 0.0125f);
        float f6 = Sdf.box(f, f2 - 0.258f, f3 - 0.112f, 0.013f, 0.026f, 0.012f, 0.008f);
        return Math.min(f5, f6);
    }

    static float plainHead(float f, float f2, float f3) {
        return Sdf.smin(SHAPE.head(f, f2, f3), SpookyDesign.features(f, f2, f3), 0.008f);
    }

    static float head(float f, float f2, float f3) {
        return Sdf.ssub(SpookyDesign.plainHead(f, f2, f3), SpookyDesign.carve(f, f2, f3), 0.004f);
    }

    static float gem(float f, float f2, float f3) {
        if (!(Math.abs(f) > 0.08f) && !(Math.abs(f2 - -0.125f) > 0.08f)) return Sdf.octahedron(f, (f2 - -0.125f) / 1.25f, f3 - 0.112f, 0.036f);
        return 1.0f;
    }

    static float bodyNoHead(float f, float f2, float f3) {
        float f4 = SHAPE.torso(f, f2, f3);
        f4 = Sdf.smin(f4, SHAPE.arms(f, f2, f3), 0.03f);
        f4 = Sdf.smin(f4, SHAPE.sleeves(f, f2, f3), 0.035f);
        return Sdf.smin(f4, SHAPE.skirt(f, f2, f3), 0.03f);
    }

    public static float field(float f, float f2, float f3) {
        float f4 = Sdf.smin(SpookyDesign.head(f, f2, f3), SpookyDesign.bodyNoHead(f, f2, f3), 0.04f);
        f4 = Sdf.smin(f4, SHAPE.belt(f, f2, f3), 0.008f);
        return Math.min(f4, SpookyDesign.gem(f, f2, f3));
    }

    public static void paint(float f, float f2, float f3, float f4, float f5, float f6, Region region) {
        float f7 = Math.abs(SpookyDesign.gem(f, f2, f3));
        float f8 = Math.abs(SHAPE.belt(f, f2, f3));
        float f9 = Math.abs(SpookyDesign.head(f, f2, f3));
        float f10 = Math.abs(SpookyDesign.bodyNoHead(f, f2, f3));
        region.u = (float)(Math.atan2(f3, f) / (Math.PI * 2) + 0.5);
        region.v = f2;
        if (f7 <= f8 && f7 < 0.006f) {
            region.mat = 4;
            region.rgb = FxPalette.rgb(0.62f, 0.16f, 1.0f);
            region.p1 = 1.0f;
            return;
        }
        if (f8 < f10 && f8 < f9 && f8 < 0.006f) {
            region.mat = 1;
            region.rgb = FxPalette.rgb(0.36f, 0.13f, 0.48f);
            region.p1 = 0.3f;
            return;
        }
        boolean bl = f9 <= f10 && f2 > 0.12f;
        float f11 = Math.abs(f);
        region.mat = 5;
        float f12 = bl ? Sdf.smoothstep(0.06f, 0.1f, f3) : 0.0f;
        region.rgb = FxPalette.rgb(0.062f + 0.045f * f12, 0.052f + 0.034f * f12, 0.06f + 0.036f * f12);
        region.p2 = bl ? Sdf.clamp(-SpookyDesign.plainHead(f, f2, f3) / 0.046f, 0.0f, 1.0f) : 0.0f;
        float f13 = (float)Math.atan2(f3, f);
        float f14 = f2 < -0.36f ? 1.0f - Sdf.smoothstep(0.0f, 0.032f, f2 - SHAPE.hemY(f13)) : 0.0f;
        float f15 = 0.0f;
        if (!bl && f11 > 0.11f && f11 < 0.35f && f2 < 0.05f && f2 > -0.11f && Math.abs(SHAPE.sleeves(f, f2, f3)) < 0.012f) {
            f15 = (1.0f - Sdf.smoothstep(0.0f, 0.022f, Math.abs(SHAPE.sleeveOutline(f11, f2)))) * Sdf.smoothstep(0.05f, 0.025f, f2);
        }
        region.p1 = Math.max(f14, f15);
        region.region = bl ? 4 : (f2 < -0.3f ? 3 : (f11 > 0.11f && f2 < 0.075f ? (f < 0.0f ? 1 : 2) : 0));
    }
}
