package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class LookEvent
extends CancellableEvent {
    public class_1297 entity;
    public CallbackInfoReturnable<Float> cir;

    public LookEvent(class_1297 class_12972, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        this.entity = class_12972;
        this.cir = callbackInfoReturnable;
    }
}
