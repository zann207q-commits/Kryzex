package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockStateChangeEvent
extends CancellableEvent {
    public class_2338 pos;
    public class_2680 newState;
    public class_2680 oldState;

    public BlockStateChangeEvent(class_2338 class_23382, class_2680 class_26802, class_2680 class_26803) {
        this.pos = class_23382;
        this.newState = class_26803;
        this.oldState = class_26802;
    }
}
