package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_1041;

public class ResolutionEvent
extends CancellableEvent {
    public class_1041 window;

    public ResolutionEvent(class_1041 class_10412) {
        this.window = class_10412;
    }
}
