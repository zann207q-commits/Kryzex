package kryzex.event;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import kryzex.event.Event;
import kryzex.event.EventInvoker;
import kryzex.event.EventPriority;
import kryzex.module.Module;

public class EventListener {
    private static final MethodType INVOKER_TYPE = MethodType.methodType(Void.TYPE, Object.class, Event.class);
    private final Object instance;
    private final Module module;
    private final EventPriority priority;
    private final EventInvoker invoker;

    public EventListener(Object object, Method method, EventPriority eventPriority) {
        Module module;
        this.instance = object;
        this.module = object instanceof Module ? (module = (Module)object) : null;
        this.priority = eventPriority;
        this.invoker = EventListener.createInvoker(method);
    }

    public void invoke(Event event) throws Throwable {
        this.invoker.invoke(this.instance, event);
    }

    public boolean isActive() {
        if (this.module == null) return true;
        if (!this.module.isEnabled()) return false;
        return true;
    }

    public Object getInstance() {
        return this.instance;
    }

    public EventPriority getPriority() {
        return this.priority;
    }

    private static EventInvoker createInvoker(Method method) {
        try {
            Class<?> clazz = method.getDeclaringClass();
            MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(clazz, MethodHandles.lookup());
            MethodHandle methodHandle = lookup.unreflect(method);
            CallSite callSite = LambdaMetafactory.metafactory(lookup, "invoke", MethodType.methodType(EventInvoker.class), INVOKER_TYPE, methodHandle, MethodType.methodType(Void.TYPE, clazz, method.getParameterTypes()[0]));
            return (EventInvoker)callSite.getTarget().invoke();
        }
        catch (Throwable throwable) {
            try {
                MethodHandle methodHandle = MethodHandles.privateLookupIn(method.getDeclaringClass(), MethodHandles.lookup()).unreflect(method).asType(INVOKER_TYPE);
                return (arg_0, arg_1) -> EventListener.lmbd$createInvoker$0(methodHandle, arg_0, arg_1);
            }
            catch (Throwable throwable2) {
                method.setAccessible(true);
                return (arg_0, arg_1) -> EventListener.lmbd$createInvoker$1(method, arg_0, arg_1);
            }
        }
    }

    private static void lmbd$createInvoker$1(Method method, Object object, Event event) throws Throwable {
        method.invoke(object, event);
    }

    private static void lmbd$createInvoker$0(MethodHandle methodHandle, Object object, Event event) throws Throwable {
        methodHandle.invokeExact(object, event);
    }
}
