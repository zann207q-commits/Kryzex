package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2672;

public class ChunkDataEvent
extends CancellableEvent {
    public class_2672 packet;

    public ChunkDataEvent(class_2672 class_26722) {
        this.packet = class_26722;
    }
}
