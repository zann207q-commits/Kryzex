package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2604;

public class EntitySpawnEvent
extends CancellableEvent {
    public class_2604 packet;

    public EntitySpawnEvent(class_2604 class_26042) {
        this.packet = class_26042;
    }
}
