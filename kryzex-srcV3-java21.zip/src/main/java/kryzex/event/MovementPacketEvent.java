package kryzex.event;

import kryzex.event.CancellableEvent;

public class MovementPacketEvent
extends CancellableEvent {
}
