package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_1297;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class GetPoseEvent
extends CancellableEvent {
    public class_1297 entity;
    public CallbackInfoReturnable<class_4050> cir;

    public GetPoseEvent(class_1297 class_12972, CallbackInfoReturnable<class_4050> callbackInfoReturnable) {
        this.entity = class_12972;
        this.cir = callbackInfoReturnable;
    }
}
