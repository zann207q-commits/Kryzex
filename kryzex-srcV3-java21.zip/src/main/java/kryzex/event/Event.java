package kryzex.event;

public interface Event {
    default public boolean isCancelled() {
        return false;
    }
}
