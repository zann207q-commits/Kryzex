package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_437;

public class ScreenOpenEvent
extends CancellableEvent {
    public class_437 screen;

    public ScreenOpenEvent(class_437 class_4372) {
        this.screen = class_4372;
    }
}
