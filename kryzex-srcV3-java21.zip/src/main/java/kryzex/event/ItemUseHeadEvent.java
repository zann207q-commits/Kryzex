package kryzex.event;

import kryzex.event.CancellableEvent;

public class ItemUseHeadEvent
extends CancellableEvent {
    public int cooldown;

    public ItemUseHeadEvent(int n) {
        this.cooldown = n;
    }
}
