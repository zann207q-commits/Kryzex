package kryzex.event;

import kryzex.event.CancellableEvent;

public class KeyEvent
extends CancellableEvent {
    public int key;
    public int mode;
    public long window;

    public KeyEvent(int n, long l, int n2) {
        this.key = n;
        this.window = l;
        this.mode = n2;
    }
}
