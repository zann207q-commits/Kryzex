package kryzex.event;

import kryzex.event.Event;

@FunctionalInterface
public interface EventInvoker {
    public void invoke(Object var1, Event var2) throws Throwable;
}
