package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2596;

public class PacketSendEvent
extends CancellableEvent {
    public class_2596<?> packet;

    public PacketSendEvent(class_2596<?> class_25962) {
        this.packet = class_25962;
    }
}
