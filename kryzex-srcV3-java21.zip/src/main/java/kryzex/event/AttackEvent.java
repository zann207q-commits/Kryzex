package kryzex.event;

import kryzex.event.CancellableEvent;

public class AttackEvent
extends CancellableEvent {
}
