package kryzex.event;

import kryzex.event.MacroEvent;
import kryzex.event.MacroEventType;
import net.minecraft.class_2596;

public final class MacroPacketSendEvent
extends MacroEvent {
    public static final MacroEventType<MacroPacketSendEvent> TYPE = new MacroEventType<MacroPacketSendEvent>(MacroPacketSendEvent.class);
    public class_2596<?> packet;

    public MacroPacketSendEvent(class_2596<?> class_25962) {
        this.packet = class_25962;
    }
}
