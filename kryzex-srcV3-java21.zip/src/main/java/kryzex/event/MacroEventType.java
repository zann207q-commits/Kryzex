package kryzex.event;

public final class MacroEventType<E> {
    private final Class<E> type;

    public MacroEventType(Class<E> clazz) {
        this.type = clazz;
    }

    public Class<E> type() {
        return this.type;
    }
}
