package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public class WorldRenderEvent
extends CancellableEvent {
    public class_4587 matrixStack;
    public Matrix4f matrix4f;
    public float tickDelta;

    public WorldRenderEvent(class_4587 class_45872, Matrix4f matrix4f, float f) {
        this.matrixStack = class_45872;
        this.matrix4f = matrix4f;
        this.tickDelta = f;
    }
}
