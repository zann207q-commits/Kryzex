package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2596;

public class PacketReceiveEvent
extends CancellableEvent {
    public class_2596<?> packet;
    public final boolean crystalFastHandled;

    public PacketReceiveEvent(class_2596<?> class_25962) {
        this(class_25962, false);
    }

    public PacketReceiveEvent(class_2596<?> class_25962, boolean bl) {
        this.packet = class_25962;
        this.crystalFastHandled = bl;
    }
}
