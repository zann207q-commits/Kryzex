package kryzex.event;

public enum EventPriority {
    HIGHEST(0),
    HIGH(1),
    NORMAL(2),
    LOW(3),
    LOWEST(4);

    private final int value;

    private EventPriority(int n2) {
        this.value = n2;
    }

    public int getValue() {
        return this.value;
    }
}
