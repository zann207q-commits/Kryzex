package kryzex.event;

import kryzex.event.MacroEvent;
import kryzex.event.MacroEventType;
import net.minecraft.class_2596;

public final class MacroPacketReceiveEvent
extends MacroEvent {
    public static final MacroEventType<MacroPacketReceiveEvent> TYPE = new MacroEventType<MacroPacketReceiveEvent>(MacroPacketReceiveEvent.class);
    public class_2596<?> packet;

    public MacroPacketReceiveEvent(class_2596<?> class_25962) {
        this.packet = class_25962;
    }
}
