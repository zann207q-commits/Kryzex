package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_332;

public class HudRenderEvent
extends CancellableEvent {
    public class_332 context;
    public float tickDelta;

    public HudRenderEvent(class_332 class_3322, float f) {
        this.context = class_3322;
        this.tickDelta = f;
    }
}
