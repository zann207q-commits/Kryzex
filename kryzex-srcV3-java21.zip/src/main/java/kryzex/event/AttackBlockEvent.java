package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class AttackBlockEvent
extends CancellableEvent {
    public class_2338 pos;
    public class_2350 direction;

    public AttackBlockEvent(class_2338 class_23382, class_2350 class_23502) {
        this.pos = class_23382;
        this.direction = class_23502;
    }
}
