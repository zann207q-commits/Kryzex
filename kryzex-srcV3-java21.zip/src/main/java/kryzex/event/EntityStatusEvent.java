package kryzex.event;

import kryzex.event.Event;

public final class EntityStatusEvent
implements Event {
}
