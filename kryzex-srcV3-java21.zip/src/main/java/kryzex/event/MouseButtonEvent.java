package kryzex.event;

import kryzex.event.CancellableEvent;

public class MouseButtonEvent
extends CancellableEvent {
    public int button;
    public int actions;
    public long window;

    public MouseButtonEvent(int n, long l, int n2) {
        this.button = n;
        this.window = l;
        this.actions = n2;
    }
}
