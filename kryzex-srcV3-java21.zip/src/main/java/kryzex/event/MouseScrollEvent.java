package kryzex.event;

import kryzex.event.CancellableEvent;

public class MouseScrollEvent
extends CancellableEvent {
    public double amount;

    public MouseScrollEvent(double d) {
        this.amount = d;
    }
}
