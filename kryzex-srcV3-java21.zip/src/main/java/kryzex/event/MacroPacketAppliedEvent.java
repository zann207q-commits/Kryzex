package kryzex.event;

import kryzex.event.MacroEventType;
import net.minecraft.class_2596;

public final class MacroPacketAppliedEvent {
    public static final MacroEventType<MacroPacketAppliedEvent> TYPE = new MacroEventType<MacroPacketAppliedEvent>(MacroPacketAppliedEvent.class);
    public final class_2596<?> packet;

    public MacroPacketAppliedEvent(class_2596<?> class_25962) {
        this.packet = class_25962;
    }
}
