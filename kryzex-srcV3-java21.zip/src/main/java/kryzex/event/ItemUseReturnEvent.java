package kryzex.event;

import kryzex.event.CancellableEvent;

public class ItemUseReturnEvent
extends CancellableEvent {
    public int cooldown;

    public ItemUseReturnEvent(int n) {
        this.cooldown = n;
    }
}
