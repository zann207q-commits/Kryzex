package kryzex.event;

public abstract class MacroEvent {
    private boolean cancelled;

    public void cancel() {
        this.cancelled = true;
    }

    public void setCancelled(boolean bl) {
        this.cancelled = bl;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }
}
