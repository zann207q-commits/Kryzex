package kryzex.event;

import kryzex.event.MacroEventType;

public final class MacroTickEvent {
    public static final MacroEventType<MacroTickEvent> TYPE = new MacroEventType<MacroTickEvent>(MacroTickEvent.class);
}
