package kryzex.event;

import kryzex.event.MacroEventType;
import net.minecraft.class_4604;

public final class MacroRender3DEvent {
    public static final MacroEventType<MacroRender3DEvent> TYPE = new MacroEventType<MacroRender3DEvent>(MacroRender3DEvent.class);
    public float partialTick;
    public class_4604 frustum;

    public MacroRender3DEvent(float f, class_4604 class_46042) {
        this.partialTick = f;
        this.frustum = class_46042;
    }
}
