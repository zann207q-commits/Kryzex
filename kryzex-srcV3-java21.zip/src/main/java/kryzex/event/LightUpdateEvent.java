package kryzex.event;

import kryzex.event.CancellableEvent;
import net.minecraft.class_2676;

public final class LightUpdateEvent
extends CancellableEvent {
    public final class_2676 packet;

    public LightUpdateEvent(class_2676 class_26762) {
        this.packet = class_26762;
    }
}
