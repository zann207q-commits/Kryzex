package kryzex.event;

import kryzex.event.CancellableEvent;

public class BlockBreakingEvent
extends CancellableEvent {
}
