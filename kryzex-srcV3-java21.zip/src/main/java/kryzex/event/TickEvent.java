package kryzex.event;

import kryzex.event.CancellableEvent;

public class TickEvent
extends CancellableEvent {
}
