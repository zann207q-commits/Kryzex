package kryzex.event;

import kryzex.event.CancellableEvent;

public class MarkClosedEvent
extends CancellableEvent {
}
