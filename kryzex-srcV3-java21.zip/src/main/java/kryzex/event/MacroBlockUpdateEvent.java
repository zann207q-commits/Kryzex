package kryzex.event;

import kryzex.event.MacroEventType;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class MacroBlockUpdateEvent {
    public static final MacroEventType<MacroBlockUpdateEvent> TYPE = new MacroEventType<MacroBlockUpdateEvent>(MacroBlockUpdateEvent.class);
    public class_2338 pos;
    public class_2680 oldState;
    public class_2680 newState;

    public MacroBlockUpdateEvent(class_2338 class_23382, class_2680 class_26802, class_2680 class_26803) {
        this.pos = class_23382;
        this.oldState = class_26802;
        this.newState = class_26803;
    }
}
