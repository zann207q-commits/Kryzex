package kryzex.module;

import kryzex.module.Category;

public final class MacroCategories {
    public static final MacroCategories COMBAT = new MacroCategories(Category.COMBAT);
    public static final MacroCategories MISC = new MacroCategories(Category.MISC);
    public static final MacroCategories DONUT = new MacroCategories(Category.DONUT);
    public static final MacroCategories RENDER = new MacroCategories(Category.RENDER);
    public static final MacroCategories CLIENT = new MacroCategories(Category.CLIENT);
    public static final MacroCategories MOVEMENT = MISC;
    public static final MacroCategories BASE_RAID = DONUT;
    public static final MacroCategories VISUALS = RENDER;
    public static final MacroCategories DONUT_MACROS = new MacroCategories(Category.MACROS);
    private final Category kryzex;

    private MacroCategories(Category category) {
        this.kryzex = category;
    }

    public Category kryzex() {
        return this.kryzex;
    }
}
