package kryzex.module;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import kryzex.event.MacroBlockUpdateEvent;
import kryzex.event.MacroPacketAppliedEvent;
import kryzex.event.MacroPacketReceiveEvent;
import kryzex.event.MacroPacketSendEvent;
import kryzex.event.MacroRender3DEvent;
import kryzex.event.MacroTickEvent;
import kryzex.module.MacroSubscribe;
import kryzex.module.Owner;
import kryzex.module.Phase;
import kryzex.module.settings.MacroSetting;
import kryzex.modules.misc.MacroModule;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_4604;

public final class MacroEventBus {
    private static final List<MacroModule> MODULES = new CopyOnWriteArrayList<MacroModule>();
    private static final Map<Class<?>, List<Owner>> HANDLERS = new ConcurrentHashMap();
    private static final ConcurrentLinkedQueue<Runnable> LATER = new ConcurrentLinkedQueue();
    private static final MacroTickEvent TICK = new MacroTickEvent();

    private MacroEventBus() {
    }

    public static void track(MacroModule macroModule) {
        MODULES.add(macroModule);
        for (Class<?> clazz = macroModule.getClass(); clazz != null && clazz != MacroModule.class; clazz = clazz.getSuperclass()) {
            for (Method method : clazz.getDeclaredMethods()) {
                MacroSubscribe macroSubscribe = method.getAnnotation(MacroSubscribe.class);
                if (macroSubscribe == null || method.getParameterCount() != 1) continue;
                method.setAccessible(true);
                Class<?> clazz2 = method.getParameterTypes()[0];
                MacroEventBus.add(clazz2, new Owner(macroModule, macroSubscribe.stage(), arg_0 -> MacroEventBus.lmbd$track$0(method, macroModule, arg_0), false));
            }
        }
    }

    public static <E> void subscribe(MacroModule macroModule, Class<E> clazz, Phase sA2, Consumer<E> consumer, boolean bl) {
        MacroEventBus.add(clazz, new Owner(macroModule, sA2, arg_0 -> MacroEventBus.lmbd$subscribe$0(consumer, clazz, arg_0), bl));
    }

    public static void dropOwned(MacroModule macroModule) {
        for (List<Owner> list : HANDLERS.values()) {
            list.removeIf(arg_0 -> MacroEventBus.lmbd$dropOwned$0(macroModule, arg_0));
        }
    }

    private static void add(Class<?> clazz, Owner owner) {
        HANDLERS.computeIfAbsent(clazz, MacroEventBus::lmbd$add$0).add(owner);
    }

    public static void later(Runnable runnable) {
        LATER.add(runnable);
    }

    public static boolean wants(Class<?> clazz) {
        List<Owner> list = HANDLERS.get(clazz);
        if (list == null) return false;
        for (Owner owner : list) {
            if (!owner.owner().isEnabled()) continue;
            return true;
        }
        return false;
    }

    private static void post(Object object, Phase sA2) {
        List<Owner> list = HANDLERS.get(object.getClass());
        if (list == null) return;
        for (Owner owner : list) {
            if (owner.stage() != sA2 || !owner.owner().isEnabled()) continue;
            try {
                owner.fn().accept(object);
            }
            catch (Throwable throwable) {
                System.err.println("Kryzex: " + owner.owner().name() + " failed handling " + object.getClass().getSimpleName() + ": " + String.valueOf(throwable));
            }
        }
    }

    public static void tick(Phase sA2) {
        if (sA2 == Phase.PRE) {
            Runnable runnable;
            while ((runnable = LATER.poll()) != null) {
                try {
                    runnable.run();
                }
                catch (Throwable throwable) {
                    System.err.println("Kryzex: deferred task failed: " + String.valueOf(throwable));
                }
            }
            for (MacroModule macroModule : MODULES) {
                for (MacroSetting macroSetting : macroModule.extSettings()) {
                    macroSetting.poll();
                }
            }
        }
        MacroEventBus.post(TICK, sA2);
    }

    public static void render3D(float f, class_4604 class_46042) {
        if (!MacroEventBus.wants(MacroRender3DEvent.class)) return;
        MacroEventBus.post(new MacroRender3DEvent(f, class_46042), Phase.PRE);
    }

    public static boolean packetReceive(class_2596<?> class_25962) {
        if (!MacroEventBus.wants(MacroPacketReceiveEvent.class)) {
            return false;
        }
        MacroPacketReceiveEvent macroPacketReceiveEvent = new MacroPacketReceiveEvent(class_25962);
        MacroEventBus.post(macroPacketReceiveEvent, Phase.PRE);
        return macroPacketReceiveEvent.isCancelled();
    }

    public static void packetApplied(class_2596<?> class_25962) {
        if (!MacroEventBus.wants(MacroPacketAppliedEvent.class)) return;
        MacroEventBus.post(new MacroPacketAppliedEvent(class_25962), Phase.PRE);
    }

    public static boolean packetSend(class_2596<?> class_25962) {
        if (!MacroEventBus.wants(MacroPacketSendEvent.class)) {
            return false;
        }
        MacroPacketSendEvent macroPacketSendEvent = new MacroPacketSendEvent(class_25962);
        MacroEventBus.post(macroPacketSendEvent, Phase.PRE);
        return macroPacketSendEvent.isCancelled();
    }

    public static void blockUpdate(class_2338 class_23382, class_2680 class_26802, class_2680 class_26803) {
        if (!MacroEventBus.wants(MacroBlockUpdateEvent.class)) return;
        MacroEventBus.post(new MacroBlockUpdateEvent(class_23382, class_26802, class_26803), Phase.PRE);
    }

    private static List lmbd$add$0(Class clazz) {
        return new CopyOnWriteArrayList();
    }

    private static boolean lmbd$dropOwned$0(MacroModule macroModule, Owner owner) {
        if (!owner.owned()) return false;
        if (owner.owner() != macroModule) return false;
        return true;
    }

    private static void lmbd$subscribe$0(Consumer consumer, Class clazz, Object object) {
        consumer.accept(clazz.cast(object));
    }

    private static void lmbd$track$0(Method method, MacroModule macroModule, Object object) {
        try {
            method.invoke((Object)macroModule, object);
            return;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException(reflectiveOperationException.getCause() != null ? reflectiveOperationException.getCause() : reflectiveOperationException);
        }
    }
}
