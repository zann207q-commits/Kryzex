package kryzex.module;

import java.util.function.Consumer;
import kryzex.module.Phase;
import kryzex.modules.misc.MacroModule;

class Owner {
    public final MacroModule owner;
    public final Phase stage;
    public final Consumer<Object> fn;
    public final boolean owned;

    public Owner(MacroModule owner, Phase stage, Consumer<Object> fn, boolean owned) {
        this.owner = owner;
        this.stage = stage;
        this.fn = fn;
        this.owned = owned;
    }

    public MacroModule owner() {
        return this.owner;
    }

    public Phase stage() {
        return this.stage;
    }

    public Consumer<Object> fn() {
        return this.fn;
    }

    public boolean owned() {
        return this.owned;
    }
}
