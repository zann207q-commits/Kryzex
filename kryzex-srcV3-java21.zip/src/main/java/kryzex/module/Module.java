package kryzex.module;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kryzex.client.KryzexClient;
import kryzex.config.EventBus;
import kryzex.module.Category;
import kryzex.module.settings.Setting;
import net.minecraft.class_310;

public abstract class Module
implements Serializable {
    private final List<Setting> settings = new ArrayList<Setting>();
    protected final EventBus EVENT_BUS = KryzexClient.INSTANCE.getEventBus();
    protected class_310 mc = class_310.method_1551();
    private CharSequence name;
    private CharSequence description;
    private boolean enabled;
    private int keybind;
    private Category category;
    private final boolean i = false;

    public Module(CharSequence charSequence, CharSequence charSequence2, int n, Category category) {
        this.name = charSequence;
        this.description = charSequence2;
        this.enabled = false;
        this.keybind = n;
        this.category = category;
    }

    public void toggle() {
        boolean bl = this.enabled = !this.enabled;
        if (this.enabled) {
            this.onEnable();
            return;
        } else {
            this.onDisable();
        }
    }

    public CharSequence getName() {
        return this.name;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public CharSequence getDescription() {
        return this.description;
    }

    public int getKeybind() {
        return this.keybind;
    }

    public Category getCategory() {
        return this.category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setName(CharSequence charSequence) {
        this.name = charSequence;
    }

    public void setDescription(CharSequence charSequence) {
        this.description = charSequence;
    }

    public void setKeybind(int n) {
        this.keybind = n;
    }

    public List<Setting> getSettings() {
        return this.settings;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void addSetting(Setting setting) {
        this.settings.add(setting);
    }

    public void addSettings(Setting ... settingArray) {
        this.settings.addAll(Arrays.asList(settingArray));
    }

    public void toggle(boolean bl) {
        if (this.enabled == bl) return;
        this.enabled = bl;
        if (bl) {
            this.onEnable();
            return;
        } else {
            this.onDisable();
        }
    }

    public void setEnabled(boolean bl) {
        this.enabled = bl;
    }
}
