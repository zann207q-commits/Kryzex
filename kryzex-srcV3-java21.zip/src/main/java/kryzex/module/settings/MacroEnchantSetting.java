package kryzex.module.settings;

import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.StringSetting;

public final class MacroEnchantSetting
extends MacroSetting {
    private final StringSetting backing;
    private boolean sessionOnly;
    private boolean privateValue;
    private boolean items;
    private MacroEnchantSetting enchantItem;

    public MacroEnchantSetting(String string, String string2) {
        super(string);
        this.backing = new StringSetting(string, string2);
    }

    public StringSetting kryzex() {
        return this.backing;
    }

    public String get() {
        String string = this.backing.getValue();
        if (string == null) {
            return "";
        }
        String string2 = string;
        return string2;
    }

    public void set(String string) {
        this.backing.setValue(string == null ? "" : string);
        this.notifyChanged();
    }

    public MacroEnchantSetting hint(String string) {
        this.backing.setDescription(string);
        return this;
    }

    public MacroEnchantSetting itemPicker() {
        this.items = true;
        return this.hint("Item ID, e.g. minecraft:diamond_block");
    }

    public MacroEnchantSetting enchantsFor(MacroEnchantSetting macroEnchantSetting) {
        this.enchantItem = macroEnchantSetting;
        return this.hint("Enchantments and levels, e.g. protection:4");
    }

    public MacroEnchantSetting privateValue() {
        this.privateValue = true;
        return this;
    }

    public MacroEnchantSetting sessionOnly() {
        this.sessionOnly = true;
        this.privateValue = true;
        return this;
    }

    public boolean isSessionOnly() {
        return this.sessionOnly;
    }

    public boolean isPrivateValue() {
        return this.privateValue;
    }

    public boolean isItemPicker() {
        return this.items;
    }

    public MacroEnchantSetting enchantItem() {
        return this.enchantItem;
    }

    @Override
    protected Object snapshot() {
        return this.get();
    }
}
