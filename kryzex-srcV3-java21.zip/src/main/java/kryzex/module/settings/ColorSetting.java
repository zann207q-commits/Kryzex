package kryzex.module.settings;

import kryzex.module.settings.Setting;

public final class ColorSetting
extends Setting {
    private int argb;
    private final int defaultArgb;

    public ColorSetting(CharSequence charSequence, int n) {
        super(charSequence);
        this.argb = n;
        this.defaultArgb = n;
    }

    public int getArgb() {
        return this.argb;
    }

    public void setArgb(int n) {
        this.argb = n;
    }

    public int getDefault() {
        return this.defaultArgb;
    }
}
