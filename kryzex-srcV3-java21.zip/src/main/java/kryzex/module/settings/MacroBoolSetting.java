package kryzex.module.settings;

import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

public final class MacroBoolSetting
extends MacroSetting {
    private final BoolSetting backing;

    public MacroBoolSetting(String string, boolean bl) {
        super(string);
        this.backing = new BoolSetting(SecureString.of(string), bl);
    }

    public boolean get() {
        return this.backing.getValue();
    }

    public void set(boolean bl) {
        if (this.backing.getValue() == bl) return;
        this.backing.setValue(bl);
        this.notifyChanged();
    }

    @Override
    public Setting kryzex() {
        return this.backing;
    }

    @Override
    protected Object snapshot() {
        return this.backing.getValue();
    }
}
