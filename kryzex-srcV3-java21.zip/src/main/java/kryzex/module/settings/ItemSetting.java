package kryzex.module.settings;

import kryzex.module.settings.Setting;
import net.minecraft.class_1792;

public class ItemSetting
extends Setting {
    private final class_1792 defaultValue;
    private class_1792 value;

    public ItemSetting(CharSequence charSequence, class_1792 class_17922) {
        super(charSequence);
        this.value = class_17922;
        this.defaultValue = class_17922;
    }

    public class_1792 getItem() {
        return this.value;
    }

    public void setItem(class_1792 class_17922) {
        this.value = class_17922;
    }

    public class_1792 getDefaultValue() {
        return this.defaultValue;
    }

    public void resetValue() {
        this.value = this.defaultValue;
    }
}
