package kryzex.module.settings;

import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

public final class MacroColorSetting
extends MacroSetting {
    private final ColorSetting backing;

    public MacroColorSetting(String string, int n) {
        super(string);
        this.backing = new ColorSetting(SecureString.of(string), n);
    }

    public int argb() {
        return this.backing.getArgb();
    }

    public int rgb() {
        return this.argb() & 0xFFFFFF;
    }

    public int argbWithAlpha(int n) {
        return Math.max(0, Math.min(255, n)) << 24 | this.rgb();
    }

    public void setArgb(int n) {
        if (this.argb() == n) return;
        this.backing.setArgb(n);
        this.notifyChanged();
    }

    public float[] value() {
        int n = this.argb();
        return new float[]{(float)(n >> 16 & 0xFF) / 255.0f, (float)(n >> 8 & 0xFF) / 255.0f, (float)(n & 0xFF) / 255.0f, (float)(n >>> 24) / 255.0f};
    }

    @Override
    public Setting kryzex() {
        return this.backing;
    }

    @Override
    protected Object snapshot() {
        return this.argb();
    }
}
