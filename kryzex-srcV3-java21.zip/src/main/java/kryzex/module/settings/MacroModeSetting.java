package kryzex.module.settings;

import java.util.List;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

public final class MacroModeSetting
extends MacroSetting {
    private final ModeSetting backing;

    public MacroModeSetting(String string, String string2, String ... stringArray) {
        super(string);
        this.backing = new ModeSetting(SecureString.of(string), string2, List.of(stringArray));
    }

    public String get() {
        return this.backing.getMode();
    }

    public boolean is(String string) {
        return this.get().equals(string);
    }

    public void set(String string) {
        String string2 = this.get();
        if (!this.backing.setMode(string) || string2.equals(string)) return;
        this.notifyChanged();
    }

    public String value() {
        return this.get();
    }

    public List<String> modes() {
        return this.backing.getModes();
    }

    public void setModes(List<String> list) {
        String string = this.get();
        this.backing.setModes(list);
        if (string.equals(this.get())) return;
        this.notifyChanged();
    }

    public void next() {
        this.backing.cycleUp();
        this.notifyChanged();
    }

    @Override
    public Setting kryzex() {
        return this.backing;
    }

    @Override
    protected Object snapshot() {
        return this.get();
    }
}
