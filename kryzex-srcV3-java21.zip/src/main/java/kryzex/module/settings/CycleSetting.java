package kryzex.module.settings;

import kryzex.module.settings.Setting;
import java.util.Arrays;
import java.util.List;

public final class CycleSetting<T extends Enum<T>>
extends Setting {
    public int index;
    private final List<T> possibleValues;
    private final int originalValue;

    public CycleSetting(CharSequence charSequence, T t, Class<T> clazz) {
        super(charSequence);
        this.possibleValues = Arrays.asList(clazz.getEnumConstants());
        this.originalValue = this.index = this.possibleValues.indexOf(t);
    }

    public Enum<T> getValue() {
        return (Enum)this.possibleValues.get(this.index);
    }

    public void setMode(Enum<T> enum_) {
        this.index = this.possibleValues.indexOf(enum_);
    }

    public void setModeIndex(int n) {
        this.index = n;
    }

    public int getModeIndex() {
        return this.index;
    }

    public int getOriginalValue() {
        return this.originalValue;
    }

    public void cycleUp() {
        this.index = this.index < this.possibleValues.size() - 1 ? ++this.index : 0;
    }

    public void cycleDown() {
        this.index = this.index > 0 ? --this.index : this.possibleValues.size() - 1;
    }

    public boolean isMode(Enum<T> enum_) {
        if (this.index != this.possibleValues.indexOf(enum_)) return false;
        return true;
    }

    public List<T> getPossibleValues() {
        return this.possibleValues;
    }

    public CycleSetting<T> setDescription(CharSequence charSequence) {
        super.setDescription(charSequence);
        return this;
    }
}
