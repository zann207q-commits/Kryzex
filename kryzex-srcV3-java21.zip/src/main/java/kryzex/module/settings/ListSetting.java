package kryzex.module.settings;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import kryzex.module.settings.Setting;
import kryzex.module.settings.ToggleEntry;
import net.minecraft.class_1792;

public final class ListSetting
extends Setting {
    private final List<ToggleEntry> entries = new ArrayList<ToggleEntry>();
    private boolean colorOnly;
    private boolean pickerOnly;

    public ListSetting(CharSequence charSequence) {
        super(charSequence);
    }

    public ListSetting colorOnly() {
        this.colorOnly = true;
        return this;
    }

    public boolean isColorOnly() {
        if (!this.colorOnly) return false;
        if (this.entries.isEmpty()) return false;
        return true;
    }

    public ListSetting pickerOnly() {
        this.pickerOnly = true;
        return this;
    }

    public boolean isPickerOnly() {
        return this.pickerOnly;
    }

    public ListSetting add(String string, String string2, class_1792 class_17922, boolean bl, Color color) {
        this.entries.add(new ToggleEntry(string, string2, class_17922, bl, color));
        return this;
    }

    public List<ToggleEntry> entries() {
        return Collections.unmodifiableList(this.entries);
    }

    public ToggleEntry get(String string) {
        for (ToggleEntry toggleEntry : this.entries) {
            if (!toggleEntry.id().equals(string)) continue;
            return toggleEntry;
        }
        return null;
    }

    public int selectedCount() {
        int n = 0;
        for (ToggleEntry toggleEntry : this.entries) {
            if (!toggleEntry.enabled) continue;
            ++n;
        }
        return n;
    }

    public void clear() {
        for (ToggleEntry toggleEntry : this.entries) {
            toggleEntry.enabled = false;
        }
    }

    public void reset() {
        for (ToggleEntry toggleEntry : this.entries) {
            toggleEntry.reset();
        }
    }
}
