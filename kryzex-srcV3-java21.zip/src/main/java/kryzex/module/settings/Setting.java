package kryzex.module.settings;

public abstract class Setting {
    private CharSequence name;
    public CharSequence description;

    public Setting(CharSequence charSequence) {
        this.name = charSequence;
    }

    public void getDescription(CharSequence charSequence) {
        this.name = charSequence;
    }

    public CharSequence getName() {
        return this.name;
    }

    public CharSequence getDescription() {
        return this.description;
    }

    public Setting setDescription(CharSequence charSequence) {
        this.description = charSequence;
        return this;
    }
}
