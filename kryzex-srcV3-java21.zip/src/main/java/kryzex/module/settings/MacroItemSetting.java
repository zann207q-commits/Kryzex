package kryzex.module.settings;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.StringSetting;

public final class MacroItemSetting
extends MacroSetting {
    private final StringSetting backing;
    private String cached;
    private List<String> values = List.of();

    public MacroItemSetting(String string, String ... stringArray) {
        super(string);
        this.backing = new StringSetting(string, String.join((CharSequence)", ", stringArray));
    }

    public MacroItemSetting itemPicker() {
        this.backing.setDescription("Item IDs separated by commas, e.g. totem_of_undying, netherite_sword");
        return this;
    }

    public StringSetting kryzex() {
        return this.backing;
    }

    public List<String> get() {
        String string;
        String string2 = string = this.backing.getValue() == null ? "" : this.backing.getValue();
        if (string.equals(this.cached)) return this.values;
        this.cached = string;
        this.values = Arrays.stream(string.split("[,;\\n]")).map(String::trim).filter(MacroItemSetting::lmbd$get$0).map(MacroItemSetting::lmbd$get$1).distinct().toList();
        return this.values;
    }

    public void set(List<String> list) {
        this.backing.setValue(String.join((CharSequence)", ", list));
        this.notifyChanged();
    }

    @Override
    protected Object snapshot() {
        return this.backing.getValue();
    }

    private static String lmbd$get$1(String string) {
        return string.toLowerCase(Locale.ROOT);
    }

    private static boolean lmbd$get$0(String string) {
        if (string.isEmpty()) return false;
        return true;
    }
}
