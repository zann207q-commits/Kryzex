package kryzex.module.settings;

import java.awt.Color;
import net.minecraft.class_1792;

public final class ToggleEntry {
    private final String id;
    private final String displayName;
    private final class_1792 item;
    private final boolean defaultEnabled;
    private final Color defaultColor;
    public boolean enabled;
    private Color color;

    public ToggleEntry(String string, String string2, class_1792 class_17922, boolean bl, Color color) {
        this.id = string;
        this.displayName = string2;
        this.item = class_17922;
        this.defaultEnabled = bl;
        this.defaultColor = color;
        this.enabled = bl;
        this.color = color;
    }

    public String id() {
        return this.id;
    }

    public String displayName() {
        return this.displayName;
    }

    public class_1792 item() {
        return this.item;
    }

    public boolean enabled() {
        return this.enabled;
    }

    public Color color() {
        return this.color;
    }

    public void setEnabled(boolean bl) {
        this.enabled = bl;
    }

    public void toggle() {
        this.enabled = !this.enabled;
    }

    public void setColor(Color color) {
        this.color = new Color(color.getRed(), color.getGreen(), color.getBlue());
    }

    public void reset() {
        this.enabled = this.defaultEnabled;
        this.color = this.defaultColor;
    }
}
