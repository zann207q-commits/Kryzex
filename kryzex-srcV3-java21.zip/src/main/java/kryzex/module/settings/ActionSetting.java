package kryzex.module.settings;

import kryzex.module.settings.Setting;

public final class ActionSetting
extends Setting {
    private final Runnable action;

    public ActionSetting(CharSequence charSequence, Runnable runnable) {
        super(charSequence);
        this.action = runnable;
    }

    public void run() {
        try {
            this.action.run();
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: action failed: " + String.valueOf(throwable));
        }
    }
}
