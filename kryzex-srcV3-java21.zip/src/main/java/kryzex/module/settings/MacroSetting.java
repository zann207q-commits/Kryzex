package kryzex.module.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import kryzex.module.settings.Setting;
import kryzex.module.settings.SettingGroup;

public abstract class MacroSetting {
    private final String name;
    private String id;
    private final List<Runnable> listeners = new ArrayList<Runnable>();
    private BooleanSupplier visible;
    private Object lastSeen;

    protected MacroSetting(String string) {
        this.name = string;
        this.id = string;
    }

    public final String id() {
        return this.id;
    }

    public final void bindId(String string) {
        this.id = string;
    }

    public final String name() {
        return this.name;
    }

    public final MacroSetting onChange(Runnable runnable) {
        this.listeners.add(runnable);
        return this;
    }

    public final MacroSetting visibleWhen(BooleanSupplier booleanSupplier) {
        this.visible = booleanSupplier;
        SettingGroup.set(this.kryzex(), booleanSupplier);
        return this;
    }

    public final boolean isVisible() {
        try {
            if (this.visible == null) return true;
            if (!this.visible.getAsBoolean()) return false;
            return true;
        }
        catch (Throwable throwable) {
            return true;
        }
    }

    public abstract Setting kryzex();

    protected abstract Object snapshot();

    public final void notifyChanged() {
        this.lastSeen = this.snapshot();
        this.fire();
    }

    public final void poll() {
        Object object = this.snapshot();
        if (this.lastSeen == null) {
            this.lastSeen = object;
            return;
        } else {
            if (Objects.equals(object, this.lastSeen)) return;
            this.lastSeen = object;
            this.fire();
        }
    }

    private void fire() {
        for (int i = 0; i < this.listeners.size(); ++i) {
            try {
                this.listeners.get(i).run();
                continue;
            }
            catch (Throwable throwable) {
                System.err.println("Kryzex: setting listener failed for " + this.name + ": " + String.valueOf(throwable));
            }
        }
    }
}
