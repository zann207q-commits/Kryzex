package kryzex.module.settings;

import kryzex.module.settings.Setting;

public final class NumberSetting
extends Setting {
    private final double min;
    private final double max;
    private double value;
    private final double format;
    private final double defaultValue;

    public NumberSetting(CharSequence charSequence, double d, double d2, double d3, double d4) {
        super(charSequence);
        this.min = d;
        this.max = d2;
        this.value = d3;
        this.format = d4;
        this.defaultValue = d3;
    }

    public double getValue() {
        return this.value;
    }

    public double getDefaultValue() {
        return this.defaultValue;
    }

    public double getFormat() {
        return this.format;
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public int getIntValue() {
        return (int)this.value;
    }

    public float getFloatValue() {
        return (float)this.value;
    }

    public long getLongValue() {
        return (long)this.value;
    }

    public void getValue(double d) {
        double d2 = 1.0 / this.format;
        this.value = (double)Math.round(Math.max(this.min, Math.min(this.max, d)) * d2) / d2;
    }

    public NumberSetting getValue(CharSequence charSequence) {
        super.setDescription(charSequence);
        return this;
    }
}
