package kryzex.module.settings;

import kryzex.module.settings.ActionSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.Setting;
import kryzex.util.SecureString;

public final class MacroActionSetting
extends MacroSetting {
    private final ActionSetting backing;

    public MacroActionSetting(String string, Runnable runnable) {
        super(string);
        this.backing = new ActionSetting(SecureString.of(string), runnable);
    }

    public void run() {
        this.backing.run();
    }

    @Override
    public Setting kryzex() {
        return this.backing;
    }

    @Override
    protected Object snapshot() {
        return Boolean.TRUE;
    }
}
