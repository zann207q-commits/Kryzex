package kryzex.module.settings;

import kryzex.module.settings.Setting;

public final class KeybindSetting
extends Setting {
    private final boolean moduleKey;
    private final int defaultValue;
    private boolean listening;
    private int value;

    public KeybindSetting(CharSequence charSequence, int n, boolean bl) {
        super(charSequence);
        this.value = n;
        this.defaultValue = n;
        this.moduleKey = bl;
    }

    public boolean isModuleKey() {
        return this.moduleKey;
    }

    public boolean isListening() {
        return this.listening;
    }

    public int getDefaultValue() {
        return this.defaultValue;
    }

    public void setListening(boolean bl) {
        this.listening = bl;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int n) {
        this.value = n;
    }

    public void toggleListening() {
        this.listening = !this.listening;
    }

    public KeybindSetting setDescription(CharSequence charSequence) {
        super.setDescription(charSequence);
        return this;
    }
}
