package kryzex.module.settings;

import java.math.BigDecimal;
import java.util.Locale;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.util.SecureString;

public final class MacroNumberSetting
extends MacroSetting {
    private final float initial;
    private final float min;
    private final float max;
    private float step;
    private NumberSetting backing;

    public MacroNumberSetting(String string, float f, float f2, float f3) {
        super(string);
        this.initial = f;
        this.min = f2;
        this.max = f3;
    }

    public MacroNumberSetting step(float f) {
        if (!(f >= 0.0f) || Float.isInfinite(f)) return this;
        this.step = f;
        return this;
    }

    public float step() {
        return this.step;
    }

    @Override
    public NumberSetting kryzex() {
        if (this.backing != null) return this.backing;
        double d = this.step > 0.0f ? (double)this.step : 0.01;
        this.backing = new NumberSetting(SecureString.of(this.name()), this.min, this.max, this.initial, d);
        return this.backing;
    }

    public float get() {
        return (float)this.kryzex().getValue();
    }

    public int getInt() {
        return Math.round(this.get());
    }

    public void set(float f) {
        float f2 = this.snap(f);
        if (f2 == this.get()) return;
        this.kryzex().getValue(f2);
        this.notifyChanged();
    }

    public float snap(float f) {
        float f2 = Math.max(this.min, Math.min(this.max, f));
        return this.step > 0.0f ? this.min + (float)Math.round((f2 - this.min) / this.step) * this.step : f2;
    }

    public int decimals() {
        if (!(this.step > 0.0f)) return 2;
        int n = Math.max(0, new BigDecimal(Float.toString(this.step)).stripTrailingZeros().scale());
        return n;
    }

    public String formatted() {
        return String.format(Locale.ROOT, "%." + this.decimals() + "f", Float.valueOf(this.get()));
    }

    public float min() {
        return this.min;
    }

    public float max() {
        return this.max;
    }

    @Override
    protected Object snapshot() {
        return this.kryzex().getValue();
    }
}
