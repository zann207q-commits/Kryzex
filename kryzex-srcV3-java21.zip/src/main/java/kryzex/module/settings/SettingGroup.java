package kryzex.module.settings;

import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.BooleanSupplier;
import kryzex.module.settings.Setting;

public final class SettingGroup {
    private static final Map<Setting, BooleanSupplier> RULES = new WeakHashMap<Setting, BooleanSupplier>();

    private SettingGroup() {
    }

    public static void set(Setting setting, BooleanSupplier booleanSupplier) {
        if (setting == null) return;
        RULES.put(setting, booleanSupplier);
    }

    public static boolean visible(Setting setting) {
        BooleanSupplier booleanSupplier = RULES.get(setting);
        try {
            if (booleanSupplier == null) return true;
            if (!booleanSupplier.getAsBoolean()) return false;
            return true;
        }
        catch (Throwable throwable) {
            return true;
        }
    }
}
