package kryzex.module.settings;

import kryzex.module.settings.Setting;

public final class BoolSetting
extends Setting {
    private boolean value;
    private final boolean defaultValue;

    public BoolSetting(CharSequence charSequence, boolean bl) {
        super(charSequence);
        this.value = bl;
        this.defaultValue = bl;
    }

    public void toggle() {
        this.setValue(!this.value);
    }

    public void setValue(boolean bl) {
        this.value = bl;
    }

    public boolean getDefaultValue() {
        return this.defaultValue;
    }

    public boolean getValue() {
        return this.value;
    }

    public BoolSetting setDescription(CharSequence charSequence) {
        super.setDescription(charSequence);
        return this;
    }
}
