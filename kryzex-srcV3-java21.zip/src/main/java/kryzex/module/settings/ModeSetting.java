package kryzex.module.settings;

import java.util.List;
import kryzex.module.settings.Setting;

public final class ModeSetting
extends Setting {
    private List<String> modes;
    private int index;
    private final String defaultMode;

    public ModeSetting(CharSequence charSequence, String string, List<String> list) {
        super(charSequence);
        this.modes = List.copyOf(list);
        this.defaultMode = string;
        this.index = Math.max(0, this.modes.indexOf(string));
    }

    public String getMode() {
        if (this.modes.isEmpty()) {
            return "";
        }
        String string = this.modes.get(Math.min(this.index, this.modes.size() - 1));
        return string;
    }

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int n) {
        if (this.modes.isEmpty()) return;
        this.index = Math.floorMod(n, this.modes.size());
    }

    public boolean setMode(String string) {
        int n = this.modes.indexOf(string);
        if (n < 0) return false;
        this.index = n;
        return true;
    }

    public List<String> getModes() {
        return this.modes;
    }

    public void setModes(List<String> list) {
        if (list.isEmpty() || list.equals(this.modes)) return;
        String string = this.getMode();
        this.modes = List.copyOf(list);
        int n = this.modes.indexOf(string);
        this.index = Math.max(0, n);
    }

    public void cycleUp() {
        this.setIndex(this.index + 1);
    }

    public void cycleDown() {
        this.setIndex(this.index - 1);
    }

    public String getDefaultMode() {
        return this.defaultMode;
    }
}
