package kryzex.module.settings;

import kryzex.module.settings.Setting;

public class StringSetting
extends Setting {
    public String value;

    public StringSetting(CharSequence charSequence, String string) {
        super(charSequence);
        this.value = string;
    }

    public void setValue(String string) {
        this.value = string;
    }

    public String getValue() {
        return this.value;
    }

    public StringSetting setDescription(CharSequence charSequence) {
        super.setDescription(charSequence);
        return this;
    }
}
