package kryzex.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import kryzex.client.KryzexClient;
import kryzex.event.KeyEvent;
import kryzex.event.MouseButtonEvent;
import kryzex.event.Subscribe;
import kryzex.gui.ClickGuiScreen;
import kryzex.gui.FriendsScreen;
import kryzex.gui.ModuleToggle;
import kryzex.module.Category;
import kryzex.module.Module;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.client.Friends;
import kryzex.modules.client.KryzexPlus;
import kryzex.modules.combat.AnchorMacro;
import kryzex.modules.combat.AutoCrystal;
import kryzex.modules.combat.AutoInvTotem;
import kryzex.modules.combat.AutoTotem;
import kryzex.modules.combat.CrystalOptimizer;
import kryzex.modules.combat.DoubleAnchor;
import kryzex.modules.combat.ElytraSwap;
import kryzex.modules.combat.HitBox;
import kryzex.modules.combat.HoverTotem;
import kryzex.modules.combat.MaceBomber;
import kryzex.modules.combat.MaceSwap;
import kryzex.modules.combat.KillAura;
import kryzex.modules.combat.NoHitDelay;
import kryzex.modules.combat.ShieldBreaker;
import kryzex.modules.combat.SpearSwap;
import kryzex.modules.combat.StaticHitBoxes;
import kryzex.modules.combat.TotemOffhand;
import kryzex.modules.combat.TriggerBot;
import kryzex.modules.donut.NoGeodeFinder;
import kryzex.modules.donut.ChunkFinder;
import kryzex.modules.donut.SusChunkV2;
import kryzex.modules.donut.AntiTrap;
import kryzex.modules.donut.AuctionSniper;
import kryzex.modules.donut.AutoRTP;
import kryzex.modules.donut.AutoSpawnerSell;
import kryzex.modules.donut.ChunkFinderBetter;
import kryzex.modules.donut.FakeScoreboard;
import kryzex.modules.donut.AutoSell;
import kryzex.modules.donut.OGScoreboard;
import kryzex.modules.donut.PlayerBypass;
import kryzex.modules.donut.PrimeChunkFinder;
import kryzex.modules.donut.RegionMap;
import kryzex.modules.donut.ShulkerDropper;
import kryzex.modules.donut.SpawnerDropper;
import kryzex.modules.donut.SpawnerOrder;
import kryzex.modules.donut.StaffList;
import kryzex.modules.donut.SusChunkFinder;
import kryzex.modules.donut.BlockEntityDebug;
import kryzex.modules.macros.AutoMineSell;
import kryzex.modules.macros.SpawnerProtect;
import kryzex.modules.macros.h.AHSell;
import kryzex.modules.macros.h.MarketFlipper;
import kryzex.modules.macros.h.OrderDropper;
import kryzex.modules.macros.h.PanicPay;
import kryzex.modules.macros.h.TPMacro;
import kryzex.modules.misc.SwingSpeed;
import kryzex.modules.misc.AutoEat;
import kryzex.modules.misc.AutoFirework;
import kryzex.modules.misc.AutoMine;
import kryzex.modules.misc.AutoTool;
import kryzex.modules.misc.AutoTpa;
import kryzex.modules.misc.CordSnapper;
import kryzex.modules.misc.ElytraGlide;
import kryzex.modules.misc.FakePay;
import kryzex.modules.misc.FastPlace;
import kryzex.modules.misc.Freecam;
import kryzex.modules.misc.Freelook;
import kryzex.modules.misc.NameProtect;
import kryzex.modules.misc.PlayerDetection;
import kryzex.modules.misc.SkinProtect;
import kryzex.modules.render.AntiLag;
import kryzex.modules.render.SkyShaders;
import kryzex.modules.render.BedrockESP;
import kryzex.modules.render.BlockESP;
import kryzex.modules.render.BlockNotifier;
import kryzex.modules.render.CustomTools;
import kryzex.modules.render.CustomTotem;
import kryzex.modules.render.StorageESP;
import kryzex.modules.render.HUD;
import kryzex.modules.render.Halloween;
import kryzex.modules.render.HoleESP;
import kryzex.modules.render.HandAura;
import kryzex.modules.render.BlockOverlay;
import kryzex.modules.render.PlayerESP;
import kryzex.modules.render.SpawnerNotify;
import kryzex.modules.render.CSGOKnifes;
import kryzex.modules.render.SwingAnimations;
import kryzex.modules.render.TargetHUD;
import kryzex.modules.render.j.Character3D;
import kryzex.util.SecureString;
import net.minecraft.class_408;
import net.minecraft.class_437;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();
    private final Map<Class<?>, Module> modulesByClass = new HashMap();
    private final Map<Category, List<Module>> modulesByCategory = new EnumMap<Category, List<Module>>(Category.class);

    public ModuleManager() {
        this.a();
        this.initKeybinds();
    }

    public void a() {
        this.register(new SwingAnimations());
        this.register(new Friends());
        this.register(new AntiLag());
        this.register(new ElytraSwap());
        this.register(new MaceSwap());
        this.register(new HitBox());
        this.register(new StaticHitBoxes());
        this.register(new AutoTotem());
        this.register(new HoverTotem());
        this.register(new AutoInvTotem());
        this.register(new AnchorMacro());
        this.register(new AutoCrystal());
        this.register(new DoubleAnchor());
        this.register(new KillAura());
        this.register(new MaceBomber());
        this.register(new SpearSwap());
        this.register(new ShieldBreaker());
        this.register(new NoHitDelay());
        this.register(new TotemOffhand());
        this.register(new TriggerBot());
        this.register(new CrystalOptimizer());
        this.register(new FastPlace());
        this.register(new Freecam());
        this.register(new Freelook());
        this.register(new AutoFirework());
        this.register(new ElytraGlide());
        this.register(new AutoTool());
        this.register(new SwingSpeed());
        this.register(new AutoEat());
        this.register(new AutoMine());
        this.register(new CordSnapper());
        this.register(new NameProtect());
        this.register(new SkinProtect());
        this.register(new PlayerDetection());
        this.register(new FakePay());
        this.macro(new AutoTpa());
        this.macro(new AutoRTP());
        this.macro(new SpawnerProtect());
        this.macro(new AutoMineSell());
        this.register(new ChunkFinder());
        this.macro(new SpawnerOrder());
        this.macro(new SpawnerDropper());
        this.macro(new AutoSell());
        this.macro(new ShulkerDropper());
        this.register(new AntiTrap());
        try {
            this.macro(new AuctionSniper());
        }
        catch (RuntimeException runtimeException) {
            System.err.println("Kryzex: Auction Sniper unavailable: " + runtimeException.getMessage());
        }
        this.macro(new AutoSpawnerSell());
        this.register(new FakeScoreboard());
        this.register(new OGScoreboard());
        this.register(new RegionMap());
        this.register(new PlayerBypass());
        this.register(new SusChunkFinder());
        this.register(new SusChunkV2());
        this.register(new ChunkFinderBetter());
        this.safe("Prime Chunk Finder", PrimeChunkFinder::new);
        this.register(new BlockEntityDebug());
        this.register(new HoleESP());
        this.safe("Halloween", Halloween::new);
        this.safe("Custom Totem", CustomTotem::new);
        this.safe("Custom Tools", CustomTools::new);
        this.safe("CSGO Knifes", CSGOKnifes::new);
        this.register(new PlayerESP());
        this.register(new StorageESP());
        this.register(new BlockESP());
        this.register(new BlockNotifier());
        this.register(new BedrockESP());
        this.register(new SpawnerNotify());
        this.register(new TargetHUD());
        this.safe("3D Character", Character3D::new);
        this.safe("Block Overlay", BlockOverlay::new);
        this.safe("Hand Aura", HandAura::new);
        this.register(new KryzexPlus());
        this.register(new HUD());
        this.register(new SkyShaders());
        this.register(new StaffList());
        this.register(new NoGeodeFinder());
        this.macro(new MarketFlipper());
        this.macro(new AHSell());
        this.macro(new PanicPay());
        this.macro(new TPMacro());
        this.macro(new OrderDropper());
    }

    public List<Module> getEnabledModules() {
        return this.modules.stream().filter(Module::isEnabled).toList();
    }

    public List<Module> getAllModules() {
        return this.modules;
    }

    public void initKeybinds() {
        KryzexClient.INSTANCE.getEventBus().register(this);
        for (Module module : this.modules) {
            module.addSetting((Setting)((Object)new KeybindSetting(SecureString.of("Keybind"), module.getKeybind(), true).setDescription(SecureString.of("Key to enabled the module"))));
        }
    }

    public List<Module> getByCategory(Category category) {
        return this.modulesByCategory.getOrDefault((Object)category, List.of());
    }

    public Module getModuleByClass(Class<? extends Module> clazz) {
        Module module = this.modulesByClass.get(clazz);
        if (module != null) {
            return module;
        }
        for (Module module2 : this.modules) {
            if (!clazz.isInstance(module2)) continue;
            return module2;
        }
        return null;
    }

    private void safe(String string, Supplier<? extends Module> supplier) {
        try {
            this.register(supplier.get());
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: " + string + " unavailable: " + String.valueOf(throwable));
        }
    }

    private void macro(Module module) {
        module.setCategory(Category.MACROS);
        this.register(module);
    }

    public void register(Module module) {
        KryzexClient.INSTANCE.getEventBus().register(module);
        this.modules.add(module);
        this.modulesByClass.put(module.getClass(), module);
        this.modulesByCategory.computeIfAbsent(module.getCategory(), ModuleManager::lmbd$a$0).add(module);
    }

    @Subscribe
    public void onKey(KeyEvent keyEvent) {
        ClickGuiScreen clickGuiScreen;
        class_437 class_4372;
        if (KryzexClient.mc.field_1755 instanceof FriendsScreen || keyEvent.mode != 1 || KryzexClient.mc != null && (class_4372 = KryzexClient.mc.field_1755) instanceof ClickGuiScreen && (clickGuiScreen = (ClickGuiScreen)class_4372).isTyping()) return;
        this.modules.forEach(arg_0 -> ModuleManager.lmbd$a$1(keyEvent, arg_0));
    }

    @Subscribe
    public void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (mouseButtonEvent.actions != 1 || mouseButtonEvent.button < 0 || mouseButtonEvent.button > 7 || KryzexClient.mc.field_1755 instanceof FriendsScreen || KryzexClient.mc.field_1755 instanceof ClickGuiScreen || KryzexClient.mc.field_1755 instanceof class_408) return;
        this.modules.forEach(arg_0 -> ModuleManager.lmbd$onMouseButton$0(mouseButtonEvent, arg_0));
    }

    private static void lmbd$onMouseButton$0(MouseButtonEvent mouseButtonEvent, Module module) {
        boolean bl;
        if (module.getKeybind() != mouseButtonEvent.button || !(bl = module instanceof KryzexPlus) && (KryzexClient.mc.field_1724 == null || KryzexClient.mc.field_1690 == null)) return;
        ModuleToggle.toggle(module);
    }

    private static void lmbd$a$1(KeyEvent keyEvent, Module module) {
        boolean bl;
        if (module.getKeybind() != keyEvent.key || !(bl = module instanceof KryzexPlus) && (KryzexClient.mc.field_1724 == null || KryzexClient.mc.field_1690 == null || KryzexClient.mc.field_1755 instanceof class_408)) return;
        ModuleToggle.toggle(module);
    }

    private static List lmbd$a$0(Category category) {
        return new ArrayList();
    }
}
