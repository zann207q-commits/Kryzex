package kryzex.module;

public enum Phase {
    PRE,
    POST;

}
