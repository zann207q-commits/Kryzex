package kryzex.module;

import kryzex.client.KryzexClient;
import kryzex.module.Module;

public final class StaticModules {
    private StaticModules() {
    }

    public static <T extends Module> T get(Class<T> clazz) {
        try {
            Module module = KryzexClient.INSTANCE.getModuleManager().getModuleByClass(clazz);
            return (T)(clazz.isInstance(module) ? (Module)clazz.cast(module) : null);
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}
