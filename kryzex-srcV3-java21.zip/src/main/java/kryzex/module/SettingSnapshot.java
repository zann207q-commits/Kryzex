package kryzex.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import kryzex.module.Module;
import kryzex.module.settings.MacroEnchantSetting;
import kryzex.module.settings.MacroSetting;
import kryzex.module.settings.Setting;
import kryzex.modules.misc.MacroModule;

public final class SettingSnapshot {
    private SettingSnapshot() {
    }

    public static boolean included(Module module) {
        if (!(module instanceof MacroModule)) return true;
        MacroModule macroModule = (MacroModule)module;
        if (!macroModule.inConfigs()) return false;
        return true;
    }

    public static boolean restoreEnabled(Module module) {
        if (!(module instanceof MacroModule)) return true;
        MacroModule macroModule = (MacroModule)module;
        if (!macroModule.inConfigs()) return false;
        if (!macroModule.persistEnabled()) return false;
        return true;
    }

    public static boolean persistent(Module module, Setting setting) {
        if (!(module instanceof MacroModule)) return true;
        MacroModule macroModule = (MacroModule)module;
        for (MacroSetting macroSetting : macroModule.extSettings()) {
            MacroEnchantSetting macroEnchantSetting;
            if (macroSetting.kryzex() != setting || !(macroSetting instanceof MacroEnchantSetting) || !(macroEnchantSetting = (MacroEnchantSetting)macroSetting).isSessionOnly()) continue;
            return false;
        }
        return true;
    }

    public static String key(Module module, Setting setting) {
        if (!(module instanceof MacroModule)) return setting.getName().toString();
        MacroModule macroModule = (MacroModule)module;
        for (MacroSetting macroSetting : macroModule.extSettings()) {
            if (macroSetting.kryzex() != setting) continue;
            return "$setting:" + macroSetting.id();
        }
        return setting.getName().toString();
    }

    public static JsonElement value(JsonObject jsonObject, Module module, Setting setting) {
        JsonElement jsonElement = jsonObject.get(SettingSnapshot.key(module, setting));
        return jsonElement != null ? jsonElement : jsonObject.get(setting.getName().toString());
    }
}
