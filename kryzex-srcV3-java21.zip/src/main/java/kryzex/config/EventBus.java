package kryzex.config;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import kryzex.client.KryzexClient;
import kryzex.event.CancellableEvent;
import kryzex.event.Event;
import kryzex.event.EventListener;
import kryzex.event.Subscribe;

public final class EventBus {
    private static final EventListener[] NONE = new EventListener[0];
    private final Map<Class<?>, EventListener[]> EVENTS = new ConcurrentHashMap();

    public void register(Object object) {
        Method[] methodArray;
        for (Method method : methodArray = object.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(Subscribe.class) || method.getParameterCount() != 1 || !Event.class.isAssignableFrom(method.getParameterTypes()[0])) continue;
            this.addListener(object, method, method.getAnnotation(Subscribe.class));
        }
    }

    private synchronized void addListener(Object object, Method method, Subscribe subscribe) {
        Class<?> clazz = method.getParameterTypes()[0];
        ArrayList<EventListener> arrayList = new ArrayList<EventListener>(Arrays.asList(this.EVENTS.getOrDefault(clazz, NONE)));
        arrayList.add(new EventListener(object, method, subscribe.priority()));
        arrayList.sort(Comparator.comparingInt(EventBus::lmbd$addListener$0));
        this.EVENTS.put(clazz, arrayList.toArray(NONE));
    }

    public synchronized void unregister(Object object) {
        for (Map.Entry<Class<?>, EventListener[]> entry : this.EVENTS.entrySet()) {
            EventListener[] eventListenerArray = (EventListener[])Arrays.stream(entry.getValue()).filter(arg_0 -> EventBus.lmbd$unregister$0(object, arg_0)).toArray(EventBus::lmbd$unregister$1);
            if (eventListenerArray.length == entry.getValue().length) continue;
            entry.setValue(eventListenerArray);
        }
    }

    public synchronized void clear() {
        this.EVENTS.clear();
    }

    public void a(Event event) {
        EventListener[] eventListenerArray = this.EVENTS.get(event.getClass());
        if (eventListenerArray == null) return;
        for (EventListener eventListener : eventListenerArray) {
            try {
                if (!eventListener.isActive() || event.isCancelled() && !(event instanceof CancellableEvent)) continue;
                eventListener.invoke(event);
            }
            catch (Throwable throwable) {
                System.err.println("Error dispatching event " + event.getClass().getSimpleName() + " to " + (eventListener.getInstance() != null ? eventListener.getInstance().getClass().getSimpleName() : "unknown"));
                throwable.printStackTrace(System.err);
            }
        }
    }

    private boolean hasActive(Class<? extends Event> clazz) {
        EventListener[] eventListenerArray = this.EVENTS.get(clazz);
        if (eventListenerArray == null) return false;
        for (EventListener eventListener : eventListenerArray) {
            if (!eventListener.isActive()) continue;
            return true;
        }
        return false;
    }

    public static void b(Event event) {
        if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.getEventBus() == null) return;
        KryzexClient.INSTANCE.getEventBus().a(event);
    }

    public static boolean hasActiveListener(Class<? extends Event> clazz) {
        if (KryzexClient.INSTANCE == null) return false;
        if (KryzexClient.INSTANCE.getEventBus() == null) return false;
        if (!KryzexClient.INSTANCE.getEventBus().hasActive(clazz)) return false;
        return true;
    }

    private static EventListener[] lmbd$unregister$1(int n) {
        return new EventListener[n];
    }

    private static boolean lmbd$unregister$0(Object object, EventListener eventListener) {
        if (eventListener.getInstance() == object) return false;
        return true;
    }

    private static int lmbd$addListener$0(EventListener eventListener) {
        return eventListener.getPriority().getValue();
    }
}
