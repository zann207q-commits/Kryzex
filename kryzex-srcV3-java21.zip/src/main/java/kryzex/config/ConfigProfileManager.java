package kryzex.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.InflaterInputStream;
import kryzex.config.ConfigProfile;

public final class ConfigProfileManager {
    public static final int LIMIT = 5;
    private static final int MAX_BYTES = 0x100000;
    private static final int MAX_CODE = 131072;
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file;
    private final Supplier<JsonObject> capture;
    private final Consumer<JsonObject> apply;
    private final Consumer<JsonObject> validate;
    private final Runnable reset;
    private List<ConfigProfile> profiles = new ArrayList<ConfigProfile>();
    private String selected;
    private boolean loaded;

    public ConfigProfileManager(Path path, Supplier<JsonObject> supplier, Consumer<JsonObject> consumer, Consumer<JsonObject> consumer2, Runnable runnable) {
        this.file = path;
        this.capture = supplier;
        this.apply = consumer;
        this.validate = consumer2;
        this.reset = runnable;
    }

    public synchronized List<ConfigProfile> profiles() {
        this.load();
        return List.copyOf(this.profiles);
    }

    public synchronized String selected() {
        this.load();
        return this.selected;
    }

    public synchronized void select(String string) {
        this.load();
        this.find(string);
        if (Objects.equals(this.selected, string)) return;
        this.commit(this.profiles, string);
    }

    public synchronized String create(String string) {
        this.load();
        this.capacity();
        string = ConfigProfileManager.cleanName(string);
        this.unique(string, null);
        JsonObject jsonObject = this.capture.get().deepCopy();
        this.validate.accept(jsonObject);
        ConfigProfileManager.size(jsonObject);
        ConfigProfile configProfile = new ConfigProfile(UUID.randomUUID().toString(), string, System.currentTimeMillis(), jsonObject);
        ArrayList<ConfigProfile> arrayList = new ArrayList<ConfigProfile>(this.profiles);
        arrayList.add(configProfile);
        this.commit(arrayList, configProfile.id());
        return configProfile.id();
    }

    public synchronized void saveCurrent(String string) {
        this.load();
        ConfigProfile configProfile = this.find(string);
        JsonObject jsonObject = this.capture.get().deepCopy();
        this.validate.accept(jsonObject);
        ConfigProfileManager.size(jsonObject);
        this.replace(new ConfigProfile(configProfile.id(), configProfile.name(), System.currentTimeMillis(), jsonObject));
    }

    public synchronized void rename(String string, String string2) {
        this.load();
        ConfigProfile configProfile = this.find(string);
        string2 = ConfigProfileManager.cleanName(string2);
        this.unique(string2, string);
        this.replace(new ConfigProfile(string, string2, configProfile.updated(), configProfile.data()));
    }

    public synchronized void delete(String string) {
        this.load();
        this.find(string);
        ArrayList<ConfigProfile> arrayList = new ArrayList<ConfigProfile>(this.profiles);
        arrayList.removeIf(arg_0 -> ConfigProfileManager.lmbd$delete$0(string, arg_0));
        String string2 = Objects.equals(this.selected, string) ? (arrayList.isEmpty() ? null : ((ConfigProfile)arrayList.get(0)).id()) : this.selected;
        this.commit(arrayList, string2);
    }

    public synchronized void loadConfig(String string) {
        this.load();
        ConfigProfile configProfile = this.find(string);
        this.validate.accept(configProfile.data());
        this.apply.accept(configProfile.data().deepCopy());
        this.commit(this.profiles, string);
    }

    public void resetCurrent() {
        this.reset.run();
    }

    public synchronized String copyCode(String string) {
        this.load();
        ConfigProfile configProfile = this.find(string);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("version", 1);
        jsonObject.addProperty("name", configProfile.name());
        jsonObject.add("settings", configProfile.data());
        try {
            byte[] byArray = jsonObject.toString().getBytes(StandardCharsets.UTF_8);
            if (byArray.length > 0x100000) {
                throw new IllegalArgumentException("Config is too large to share.");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream);){
                gzipOutputStream.write(byArray);
            }
            byte[] object = byteArrayOutputStream.toByteArray();
            String string2 = "KRSP1:" + Base64.getUrlEncoder().withoutPadding().encodeToString(object) + "." + ConfigProfileManager.digest(object);
            if (string2.length() <= 131072) return string2;
            throw new IllegalArgumentException("Config is too large to share.");
        }
        catch (IOException iOException) {
            throw new IllegalStateException("Couldn't create the config code.", iOException);
        }
    }

    public synchronized String pasteCode(String string) {
        this.load();
        this.capacity();
        JsonObject jsonObject = ConfigProfileManager.decode(string);
        String object2 = ConfigProfileManager.cleanName(jsonObject.get("name").getAsString());
        String object;
        String string2 = object2;
        int n = 2;
        while (this.taken((String)object2, null)) {
            object = " (" + n + ")";
            object2 = string2.substring(0, Math.min(string2.length(), 32 - object.length())) + object;
            ++n;
        }
        JsonObject jsonObject2 = jsonObject.getAsJsonObject("settings");
        this.validate.accept(jsonObject2);
        ConfigProfile configProfile = new ConfigProfile(UUID.randomUUID().toString(), object2, System.currentTimeMillis(), jsonObject2.deepCopy());
        ArrayList<ConfigProfile> arrayList = new ArrayList<ConfigProfile>(this.profiles);
        arrayList.add(configProfile);
        this.commit(arrayList, configProfile.id());
        return configProfile.id();
    }

    private static JsonObject decode(String string) {
        try {
            byte[] byArray;
            if (string == null || string.length() > 131072) {
                throw new IllegalArgumentException();
            }
            String string2 = string.strip();
            if (!string2.startsWith("KRSP1:")) {
                throw new IllegalArgumentException();
            }
            int n = string2.lastIndexOf(46);
            if (n < 6 || string2.length() - n != 17) {
                throw new IllegalArgumentException();
            }
            byte[] byArray2 = Base64.getUrlDecoder().decode(string2.substring(6, n));
            if (!MessageDigest.isEqual(ConfigProfileManager.digest(byArray2).getBytes(StandardCharsets.US_ASCII), string2.substring(n + 1).getBytes(StandardCharsets.US_ASCII))) {
                throw new IllegalArgumentException();
            }
            try (GZIPInputStream gzipInputStream = new GZIPInputStream(new ByteArrayInputStream(byArray2));){
                byArray = gzipInputStream.readNBytes(0x100001);
                if (byArray.length > 0x100000 || gzipInputStream.read() != -1) {
                    throw new IllegalArgumentException();
                }
            }
            JsonObject jsonObject = ConfigProfileManager.parse(new String(byArray, StandardCharsets.UTF_8));
            if (jsonObject.get("version").getAsInt() == 1 && jsonObject.get("name").getAsJsonPrimitive().isString() && jsonObject.get("settings").isJsonObject()) return jsonObject;
            throw new IllegalArgumentException();
        }
        catch (Exception exception) {
            throw new IllegalArgumentException("Invalid config code. Copy the complete code and try again.");
        }
    }

    private static String digest(byte[] byArray) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(byArray), 0, 8);
        }
        catch (Exception exception) {
            throw new IllegalStateException(exception);
        }
    }

    private static JsonObject parse(String string) {
        int n = 0;
        boolean bl = false;
        boolean bl2 = false;
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            if (bl) {
                if (bl2) {
                    bl2 = false;
                    continue;
                }
                if (c == '\\') {
                    bl2 = true;
                    continue;
                }
                if (c != '\"') continue;
                bl = false;
                continue;
            }
            if (c == '\"') {
                bl = true;
                continue;
            }
            if (c == '{' || c == '[') {
                if (++n <= 32) continue;
                throw new IllegalArgumentException("Config data is nested too deeply.");
            }
            if (c != '}' && c != ']') continue;
            --n;
        }
        return JsonParser.parseString(string).getAsJsonObject();
    }

    public static String cleanName(String string) {
        if (string == null) {
            throw new IllegalArgumentException("Enter a config name.");
        }
        String string2 = string.strip().replaceAll("\\s+", " ");
        if (!string2.isEmpty() && string2.length() <= 32 && !string2.chars().anyMatch(Character::isISOControl)) return string2;
        throw new IllegalArgumentException("Use a name between 1 and 32 characters.");
    }

    private void capacity() {
        if (this.profiles.size() < 5) return;
        throw new IllegalArgumentException("You already have five configs. Delete one first.");
    }

    private static void size(JsonObject jsonObject) {
        if (jsonObject.toString().getBytes(StandardCharsets.UTF_8).length <= 0x100000) return;
        throw new IllegalArgumentException("This config is too large to save.");
    }

    private boolean taken(String string, String string2) {
        return this.profiles.stream().anyMatch(arg_0 -> ConfigProfileManager.lmbd$taken$0(string2, string, arg_0));
    }

    private void unique(String string, String string2) {
        if (!this.taken(string, string2)) return;
        throw new IllegalArgumentException("A config with that name already exists.");
    }

    private ConfigProfile find(String string) {
        return this.profiles.stream().filter(arg_0 -> ConfigProfileManager.lmbd$find$0(string, arg_0)).findFirst().orElseThrow(ConfigProfileManager::lmbd$find$1);
    }

    private void replace(ConfigProfile configProfile) {
        ArrayList<ConfigProfile> arrayList = new ArrayList<ConfigProfile>(this.profiles);
        for (int i = 0; i < arrayList.size(); ++i) {
            if (!((ConfigProfile)arrayList.get(i)).id().equals(configProfile.id())) continue;
            arrayList.set(i, configProfile);
        }
        this.commit(arrayList, this.selected);
    }

    private void load() {
        if (this.loaded) {
            return;
        }
        if (Files.isRegularFile(this.file, new LinkOption[0])) {
            try {
                if (Files.size(this.file) > 0x1400000L) {
                    throw new IOException("Oversized config library");
                }
                JsonObject jsonObject = ConfigProfileManager.parse(Files.readString(this.file));
                if (jsonObject.get("version").getAsInt() != 1) {
                    throw new IOException("Unsupported config version");
                }
                JsonArray jsonArray = jsonObject.getAsJsonArray("configs");
                if (jsonArray.size() > 5) {
                    throw new IOException("Too many configs");
                }
                ArrayList<ConfigProfile> arrayList = new ArrayList<ConfigProfile>();
                HashSet<String> hashSet = new HashSet<String>();
                HashSet<String> hashSet2 = new HashSet<String>();
                for (JsonElement jsonElement : jsonArray) {
                    JsonObject jsonObject2 = jsonElement.getAsJsonObject();
                    String string = jsonObject2.get("id").getAsString();
                    UUID.fromString(string);
                    String string2 = ConfigProfileManager.cleanName(jsonObject2.get("name").getAsString());
                    if (!hashSet.add(string) || !hashSet2.add(string2.toLowerCase(Locale.ROOT))) {
                        throw new IOException("Duplicate config");
                    }
                    JsonObject jsonObject3 = jsonObject2.getAsJsonObject("data");
                    ConfigProfileManager.size(jsonObject3);
                    arrayList.add(new ConfigProfile(string, string2, jsonObject2.get("updated").getAsLong(), jsonObject3.deepCopy()));
                }
                String iterator = jsonObject.has("selected") && !jsonObject.get("selected").isJsonNull() ? jsonObject.get("selected").getAsString() : null;
                this.profiles = arrayList;
                this.selected = hashSet.contains(iterator) ? iterator : (arrayList.isEmpty() ? null : ((ConfigProfile)arrayList.get(0)).id());
            }
            catch (Exception exception) {
                throw new IllegalStateException("Couldn't read saved configs. Your file was kept safe.", exception);
            }
        }
        this.loaded = true;
    }

    private void commit(List<ConfigProfile> list, String string) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("version", 1);
        jsonObject.addProperty("selected", string);
        JsonArray jsonArray = new JsonArray();
        for (ConfigProfile configProfile : list) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("id", configProfile.id());
            jsonObject2.addProperty("name", configProfile.name());
            jsonObject2.addProperty("updated", configProfile.updated());
            jsonObject2.add("data", configProfile.data());
            jsonArray.add(jsonObject2);
        }
        jsonObject.add("configs", jsonArray);
        try {
            ConfigProfileManager.writeAtomic(this.file, JSON.toJson(jsonObject));
        }
        catch (IOException iOException) {
            throw new IllegalStateException("Couldn't save configs. Check the config folder.", iOException);
        }
        this.profiles = new ArrayList<ConfigProfile>(list);
        this.selected = string;
    }

    public static void writeAtomic(Path path, String string) throws IOException {
        Files.createDirectories(path.getParent(), new FileAttribute[0]);
        Path path2 = Files.createTempFile(path.getParent(), path.getFileName().toString(), ".tmp", new FileAttribute[0]);
        try {
            Files.writeString(path2, (CharSequence)string, StandardCharsets.UTF_8, new OpenOption[0]);
            try {
                Files.move(path2, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                return;
            }
            catch (AtomicMoveNotSupportedException atomicMoveNotSupportedException) {
                Files.move(path2, path, StandardCopyOption.REPLACE_EXISTING);
            }
            return;
        }
        finally {
            Files.deleteIfExists(path2);
        }
    }

    private static IllegalArgumentException lmbd$find$1() {
        return new IllegalArgumentException("Select a config first.");
    }

    private static boolean lmbd$find$0(String string, ConfigProfile configProfile) {
        return configProfile.id().equals(string);
    }

    private static boolean lmbd$taken$0(String string, String string2, ConfigProfile configProfile) {
        if (Objects.equals(configProfile.id(), string)) return false;
        if (!configProfile.name().equalsIgnoreCase(string2)) return false;
        return true;
    }

    private static boolean lmbd$delete$0(String string, ConfigProfile configProfile) {
        return configProfile.id().equals(string);
    }
}
