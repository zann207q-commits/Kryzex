package kryzex.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.awt.Color;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kryzex.client.KryzexClient;
import kryzex.config.ConfigProfileManager;
import kryzex.config.HudLayoutUtil;
import kryzex.module.Module;
import kryzex.module.SettingSnapshot;
import kryzex.module.settings.BoolSetting;
import kryzex.module.settings.ColorSetting;
import kryzex.module.settings.CycleSetting;
import kryzex.module.settings.ItemSetting;
import kryzex.module.settings.KeybindSetting;
import kryzex.module.settings.ListSetting;
import kryzex.module.settings.ModeSetting;
import kryzex.module.settings.NumberSetting;
import kryzex.module.settings.RangeSetting;
import kryzex.module.settings.Setting;
import kryzex.module.settings.StringSetting;
import kryzex.module.settings.ToggleEntry;
import kryzex.modules.client.KryzexPlus;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class SettingsManager {
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path settingsPath;
    private final JsonObject defaults;
    private final ConfigProfileManager configs;

    public SettingsManager() {
        Path path = FabricLoader.getInstance().getConfigDir();
        this.settingsPath = path.resolve("kryzex.json");
        this.defaults = this.captureModules();
        for (Map.Entry<String, JsonElement> entry : this.defaults.entrySet()) {
            entry.getValue().getAsJsonObject().addProperty("enabled", false);
        }
        this.defaults.add("_layout", HudLayoutUtil.defaults());
        this.configs = new ConfigProfileManager(path.resolve("kryzex-configs.json"), this::capture, this::apply, this::validate, this::resetAll);
    }

    public ConfigProfileManager configs() {
        return this.configs;
    }

    private List<Module> modules() {
        return KryzexClient.INSTANCE.getModuleManager().getAllModules();
    }

    private static boolean client(Module module) {
        return module instanceof KryzexPlus;
    }

    public synchronized JsonObject capture() {
        JsonObject jsonObject = this.captureModules();
        jsonObject.add("_layout", HudLayoutUtil.capture());
        return jsonObject;
    }

    private JsonObject captureModules() {
        JsonObject jsonObject = new JsonObject();
        for (Module module : this.modules()) {
            if (!SettingSnapshot.included(module)) continue;
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("enabled", !SettingsManager.client(module) && SettingSnapshot.restoreEnabled(module) && module.isEnabled());
            jsonObject2.addProperty("$keybind", module.getKeybind());
            for (Setting setting : module.getSettings()) {
                JsonElement jsonElement;
                if (!SettingSnapshot.persistent(module, setting) || (jsonElement = SettingsManager.encode(setting)) == null) continue;
                jsonObject2.add(SettingSnapshot.key(module, setting), jsonElement);
            }
            jsonObject.add(module.getName().toString(), jsonObject2);
        }
        return jsonObject;
    }

    private static JsonElement encode(Setting setting) {
        if (setting instanceof BoolSetting) {
            BoolSetting boolSetting = (BoolSetting)((Object)setting);
            return new JsonPrimitive(boolSetting.getValue());
        }
        if (setting instanceof CycleSetting) {
            CycleSetting cycleSetting = (CycleSetting)((Object)setting);
            return new JsonPrimitive(cycleSetting.getModeIndex());
        }
        if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            return new JsonPrimitive(numberSetting.getValue());
        }
        if (setting instanceof KeybindSetting) {
            KeybindSetting keybindSetting = (KeybindSetting)((Object)setting);
            return new JsonPrimitive(keybindSetting.getValue());
        }
        if (setting instanceof StringSetting) {
            StringSetting stringSetting = (StringSetting)((Object)setting);
            return new JsonPrimitive(stringSetting.getValue() == null ? "" : stringSetting.getValue());
        }
        if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("min", rangeSetting.getCurrentMin());
            jsonObject.addProperty("max", rangeSetting.getCurrentMax());
            return jsonObject;
        }
        if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            return new JsonPrimitive(class_7923.field_41178.method_10221((class_1792)itemSetting.getItem()).toString());
        }
        if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            return new JsonPrimitive(modeSetting.getMode());
        }
        if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            return new JsonPrimitive(String.format(Locale.ROOT, "%08X", colorSetting.getArgb()));
        }
        if (!(setting instanceof ListSetting)) {
            return null;
        }
        ListSetting listSetting = (ListSetting)setting;
        JsonObject jsonObject = new JsonObject();
        for (ToggleEntry toggleEntry : listSetting.entries()) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("enabled", toggleEntry.enabled());
            jsonObject2.addProperty("color", toggleEntry.color().getRGB() & 0xFFFFFF);
            jsonObject.add(toggleEntry.id(), jsonObject2);
        }
        return jsonObject;
    }

    public synchronized void validate(JsonObject jsonObject) {
        if (jsonObject == null || jsonObject.size() > 512) throw new IllegalArgumentException("Invalid config.");
        for (Module module : this.modules()) {
            JsonElement jsonElement;
            if (!SettingSnapshot.included(module) || (jsonElement = jsonObject.get(module.getName().toString())) == null) continue;
            if (!jsonElement.isJsonObject()) {
                throw new IllegalArgumentException("Invalid module settings.");
            }
            JsonObject jsonObject2 = jsonElement.getAsJsonObject();
            if (jsonObject2.has("enabled")) {
                SettingsManager.bool(jsonObject2.get("enabled"));
            }
            if (jsonObject2.has("$keybind")) {
                SettingsManager.integer(jsonObject2.get("$keybind"), -1, 512);
            }
            for (Setting setting : module.getSettings()) {
                JsonElement jsonElement2;
                if (!SettingSnapshot.persistent(module, setting) || (jsonElement2 = SettingSnapshot.value(jsonObject2, module, setting)) == null) continue;
                try {
                    SettingsManager.validateSetting(setting, jsonElement2);
                }
                catch (RuntimeException runtimeException) {
                    throw new IllegalArgumentException("Invalid value: " + String.valueOf(module.getName()) + " / " + String.valueOf(setting.getName()));
                }
            }
        }
        if (!jsonObject.has("_layout")) return;
        HudLayoutUtil.validate(jsonObject.getAsJsonObject("_layout"));
    }

    private static void validateSetting(Setting setting, JsonElement jsonElement) {
        if (setting instanceof BoolSetting) {
            SettingsManager.bool(jsonElement);
            return;
        } else if (setting instanceof CycleSetting) {
            CycleSetting cycleSetting = (CycleSetting)((Object)setting);
            SettingsManager.integer(jsonElement, -1, cycleSetting.getPossibleValues().size() - 1);
            return;
        } else if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            SettingsManager.number(jsonElement, numberSetting.getMin(), numberSetting.getMax());
            return;
        } else if (setting instanceof KeybindSetting) {
            SettingsManager.integer(jsonElement, -1, 512);
            return;
        } else {
            if (setting instanceof StringSetting) {
                if (SettingsManager.string(jsonElement).length() <= 4096) return;
                throw new IllegalArgumentException();
            }
            if (setting instanceof RangeSetting) {
                double d;
                RangeSetting rangeSetting = (RangeSetting)setting;
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                double d2 = SettingsManager.number(jsonObject.get("min"), rangeSetting.getMinValue(), rangeSetting.getMaxValue());
                if (!(d2 > (d = SettingsManager.number(jsonObject.get("max"), rangeSetting.getMinValue(), rangeSetting.getMaxValue())))) return;
                throw new IllegalArgumentException();
            }
            if (setting instanceof ItemSetting) {
                class_2960 class_29602 = class_2960.method_12829((String)SettingsManager.string(jsonElement));
                if (class_29602 != null && !class_7923.field_41178.method_10223(class_29602).isEmpty()) return;
                throw new IllegalArgumentException();
            }
            if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                if (modeSetting.getModes().contains(SettingsManager.string(jsonElement))) return;
                throw new IllegalArgumentException();
            }
            if (setting instanceof ColorSetting) {
                if (SettingsManager.string(jsonElement).matches("[0-9a-fA-F]{6,8}")) return;
                throw new IllegalArgumentException();
            }
            if (!(setting instanceof ListSetting)) return;
            ListSetting listSetting = (ListSetting)setting;
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            for (ToggleEntry toggleEntry : listSetting.entries()) {
                if (!jsonObject.has(toggleEntry.id())) continue;
                JsonObject jsonObject2 = jsonObject.getAsJsonObject(toggleEntry.id());
                if (jsonObject2.has("enabled")) {
                    SettingsManager.bool(jsonObject2.get("enabled"));
                }
                if (!jsonObject2.has("color")) continue;
                SettingsManager.integer(jsonObject2.get("color"), 0, 0xFFFFFF);
            }
        }
    }

    private static String string(JsonElement jsonElement) {
        if (jsonElement == null || !jsonElement.isJsonPrimitive() || !jsonElement.getAsJsonPrimitive().isString()) throw new IllegalArgumentException();
        return jsonElement.getAsString();
    }

    private static boolean bool(JsonElement jsonElement) {
        if (jsonElement == null || !jsonElement.isJsonPrimitive() || !jsonElement.getAsJsonPrimitive().isBoolean()) throw new IllegalArgumentException();
        return jsonElement.getAsBoolean();
    }

    private static double number(JsonElement jsonElement, double d, double d2) {
        if (jsonElement == null || !jsonElement.isJsonPrimitive() || !jsonElement.getAsJsonPrimitive().isNumber()) throw new IllegalArgumentException();
        double d3 = jsonElement.getAsDouble();
        if (!Double.isFinite(d3) || d3 < d || d3 > d2) throw new IllegalArgumentException();
        return d3;
    }

    private static int integer(JsonElement jsonElement, int n, int n2) {
        double d = SettingsManager.number(jsonElement, n, n2);
        if (d == Math.rint(d)) return (int)d;
        throw new IllegalArgumentException();
    }

    private static void set(Setting setting, JsonElement jsonElement, Module module) {
        if (setting instanceof BoolSetting) {
            BoolSetting boolSetting = (BoolSetting)((Object)setting);
            boolSetting.setValue(jsonElement.getAsBoolean());
            return;
        } else if (setting instanceof CycleSetting) {
            CycleSetting cycleSetting = (CycleSetting)((Object)setting);
            int n = jsonElement.getAsInt();
            cycleSetting.setModeIndex(n == -1 ? cycleSetting.getOriginalValue() : n);
            return;
        } else if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            numberSetting.getValue(jsonElement.getAsDouble());
            return;
        } else if (setting instanceof KeybindSetting) {
            KeybindSetting keybindSetting = (KeybindSetting)((Object)setting);
            keybindSetting.setValue(jsonElement.getAsInt());
            keybindSetting.setListening(false);
            if (!keybindSetting.isModuleKey()) return;
            module.setKeybind(keybindSetting.getValue());
            return;
        } else if (setting instanceof StringSetting) {
            StringSetting stringSetting = (StringSetting)((Object)setting);
            stringSetting.setValue(jsonElement.getAsString());
            return;
        } else if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            rangeSetting.setCurrentMin(jsonObject.get("min").getAsDouble());
            rangeSetting.setCurrentMax(jsonObject.get("max").getAsDouble());
            return;
        } else if (setting instanceof ItemSetting) {
            ItemSetting itemSetting = (ItemSetting)setting;
            itemSetting.setItem((class_1792)((class_6880.class_6883)class_7923.field_41178.method_10223(class_2960.method_60654((String)jsonElement.getAsString())).orElseThrow()).comp_349());
            return;
        } else if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            modeSetting.setMode(jsonElement.getAsString());
            return;
        } else if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            colorSetting.setArgb((int)Long.parseLong(jsonElement.getAsString(), 16));
            return;
        } else {
            if (!(setting instanceof ListSetting)) return;
            ListSetting listSetting = (ListSetting)setting;
            for (ToggleEntry toggleEntry : listSetting.entries()) {
                JsonElement jsonElement2 = jsonElement.getAsJsonObject().get(toggleEntry.id());
                if (jsonElement2 == null) continue;
                JsonObject jsonObject = jsonElement2.getAsJsonObject();
                if (jsonObject.has("enabled")) {
                    toggleEntry.setEnabled(jsonObject.get("enabled").getAsBoolean());
                }
                if (!jsonObject.has("color")) continue;
                toggleEntry.setColor(new Color(jsonObject.get("color").getAsInt()));
            }
        }
    }

    public synchronized void apply(JsonObject jsonObject) {
        this.validate(jsonObject);
        JsonObject jsonObject2 = this.capture();
        try {
            this.applyInternal(jsonObject);
            this.writeCurrent();
            return;
        }
        catch (RuntimeException runtimeException) {
            try {
                this.applyInternal(jsonObject2);
                throw new IllegalStateException("Couldn't apply this config; previous settings were restored.", runtimeException);
            }
            catch (RuntimeException runtimeException2) {
                runtimeException.addSuppressed(runtimeException2);
                throw new IllegalStateException("Couldn't apply the config. Some module states could not be restored.", runtimeException);
            }
        }
    }

    private void applyInternal(JsonObject jsonObject) {
        Object object;
        for (Module module : this.modules()) {
            if (SettingsManager.client(module)) {
                module.setEnabled(false);
                continue;
            }
            module.toggle(false);
        }
        for (Module module : this.modules()) {
            JsonElement jsonElement;
            if (!SettingSnapshot.included(module)) continue;
            object = module.getName().toString();
            JsonObject jsonObject2 = this.defaults.getAsJsonObject((String)object).deepCopy();
            JsonElement jsonElement2 = jsonObject.get((String)object);
            if (jsonElement2 != null) {
                for (Map.Entry<String, JsonElement> entry : jsonElement2.getAsJsonObject().entrySet()) {
                    jsonObject2.add(entry.getKey(), entry.getValue());
                }
            }
            if (jsonElement2 != null && jsonElement2.isJsonObject()) {
                for (Setting setting : module.getSettings()) {
                    jsonElement = SettingSnapshot.value(jsonElement2.getAsJsonObject(), module, setting);
                    if (jsonElement == null || !SettingSnapshot.persistent(module, setting)) continue;
                    jsonObject2.add(SettingSnapshot.key(module, setting), jsonElement);
                }
            }
            module.setKeybind(jsonObject2.get("$keybind").getAsInt());
            for (Setting setting : module.getSettings()) {
                if (!SettingSnapshot.persistent(module, setting) || (jsonElement = SettingSnapshot.value(jsonObject2, module, setting)) == null) continue;
                SettingsManager.set(setting, jsonElement, module);
            }
        }
        if (jsonObject.has("_layout")) {
            HudLayoutUtil.apply(jsonObject.getAsJsonObject("_layout"));
        }
        for (Module module : this.modules()) {
            if (SettingsManager.client(module) || !SettingSnapshot.restoreEnabled(module)) continue;
            object = jsonObject.get(module.getName().toString());
            boolean bl = object != null && ((JsonElement)object).isJsonObject() && ((JsonElement)object).getAsJsonObject().has("enabled") && ((JsonElement)object).getAsJsonObject().get("enabled").getAsBoolean();
            module.toggle(bl);
        }
    }

    public synchronized void resetAll() {
        this.apply(this.defaults.deepCopy());
    }

    public synchronized void loadProfile() {
        try {
            if (!Files.isRegularFile(this.settingsPath, new LinkOption[0])) return;
            if (Files.size(this.settingsPath) > 0x100000L) {
                throw new IllegalArgumentException("Settings file is too large");
            }
            JsonObject jsonObject = JsonParser.parseString(Files.readString(this.settingsPath)).getAsJsonObject();
            this.validate(jsonObject);
            this.applyInternal(jsonObject);
            return;
        }
        catch (Exception exception) {
            System.err.println("Kryzex: couldn't load settings: " + exception.getMessage());
        }
    }

    private void writeCurrent() {
        try {
            ConfigProfileManager.writeAtomic(this.settingsPath, JSON.toJson(this.capture()));
            return;
        }
        catch (Exception exception) {
            throw new IllegalStateException("Couldn't save client settings.", exception);
        }
    }

    public synchronized void saveNow() {
        this.writeCurrent();
    }

    public synchronized void shutdown() {
        try {
            this.writeCurrent();
            return;
        }
        catch (Exception exception) {
            System.err.println("Kryzex: couldn't save settings: " + exception.getMessage());
        }
    }
}
