package kryzex.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Map;

public class ConfigProfile {
    public final String id;
    public final String name;
    public final long updated;
    public final JsonObject data;

    public ConfigProfile(String id, String name, long updated, JsonObject data) {
        this.id = id;
        this.name = name;
        this.updated = updated;
        this.data = data;
    }

    public String id() {
        return this.id;
    }

    public String name() {
        return this.name;
    }

    public long updated() {
        return this.updated;
    }

    public JsonObject data() {
        return this.data;
    }
    public int enabledCount() {
        int n = 0;
        for (Map.Entry<String, JsonElement> entry : this.data.entrySet()) {
            JsonElement jsonElement;
            if (!entry.getValue().isJsonObject() || (jsonElement = entry.getValue().getAsJsonObject().get("enabled")) == null || !jsonElement.isJsonPrimitive() || !jsonElement.getAsJsonPrimitive().isBoolean() || !jsonElement.getAsBoolean()) continue;
            ++n;
        }
        return n;
    }
}
