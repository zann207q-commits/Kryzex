package kryzex.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import kryzex.client.KryzexClient;
import kryzex.gui.PhaseTime;
import kryzex.modules.render.HUD;

final class HudLayoutUtil {
    HudLayoutUtil() {
    }

    private static Object field(Object object, String string) throws ReflectiveOperationException {
        Field field = object.getClass().getDeclaredField(string);
        field.setAccessible(true);
        return field.get(object);
    }

    private static void field(Object object, String string, Object object2) throws ReflectiveOperationException {
        Field field = object.getClass().getDeclaredField(string);
        field.setAccessible(true);
        field.set(object, object2);
    }

    private static void save(Object object, String string) throws ReflectiveOperationException {
        Method method = object.getClass().getDeclaredMethod(string, new Class[0]);
        method.setAccessible(true);
        method.invoke(object, new Object[0]);
    }

    static JsonObject capture() {
        JsonObject jsonObject = new JsonObject();
        try {
            Object object = ((PhaseTime)HudLayoutUtil.field(KryzexClient.INSTANCE.GUI, "ui")).layoutState();
            HudLayoutUtil.save(object, "loadPosition");
            jsonObject.addProperty("x", (Float)HudLayoutUtil.field(object, "offX"));
            jsonObject.addProperty("y", (Float)HudLayoutUtil.field(object, "offY"));
            HUD hUD = (HUD)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(HUD.class);
            Object object2 = HudLayoutUtil.field(hUD, "hud");
            HudLayoutUtil.save(object2, "load");
            Map map = (Map)HudLayoutUtil.field(object2, "places");
            JsonObject jsonObject2 = new JsonObject();
            for (Map.Entry<?, ?> entry : ((Map<?, ?>)map).entrySet()) {
                Object v = entry.getValue();
                JsonObject jsonObject3 = new JsonObject();
                jsonObject3.addProperty("moved", (Boolean)HudLayoutUtil.field(v, "moved"));
                jsonObject3.addProperty("right", (Boolean)HudLayoutUtil.field(v, "right"));
                jsonObject3.addProperty("bottom", (Boolean)HudLayoutUtil.field(v, "bottom"));
                jsonObject3.addProperty("x", (Float)HudLayoutUtil.field(v, "ox"));
                jsonObject3.addProperty("y", (Float)HudLayoutUtil.field(v, "oy"));
                jsonObject2.add(((Enum)entry.getKey()).name(), jsonObject3);
            }
            jsonObject.add("hud", jsonObject2);
            return jsonObject;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Couldn't read the HUD layout.", reflectiveOperationException);
        }
    }

    static JsonObject defaults() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("x", 0);
        jsonObject.addProperty("y", 0);
        jsonObject.add("hud", new JsonObject());
        return jsonObject;
    }

    static void validate(JsonObject jsonObject) {
        HudLayoutUtil.number(jsonObject.get("x"));
        HudLayoutUtil.number(jsonObject.get("y"));
        JsonObject jsonObject2 = jsonObject.getAsJsonObject("hud");
        if (jsonObject2 == null || jsonObject2.size() > 32) throw new IllegalArgumentException("Invalid HUD layout.");
        for (Map.Entry<String, JsonElement> entry : jsonObject2.entrySet()) {
            JsonObject jsonObject3 = entry.getValue().getAsJsonObject();
            HudLayoutUtil.number(jsonObject3.get("x"));
            HudLayoutUtil.number(jsonObject3.get("y"));
            for (String string : List.of("moved", "right", "bottom")) {
                JsonElement jsonElement = jsonObject3.get(string);
                if (jsonElement != null && jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isBoolean()) continue;
                throw new IllegalArgumentException("Invalid HUD layout.");
            }
        }
    }

    private static float number(JsonElement jsonElement) {
        if (jsonElement == null || !jsonElement.isJsonPrimitive() || !jsonElement.getAsJsonPrimitive().isNumber()) throw new IllegalArgumentException("Invalid layout position.");
        float f = jsonElement.getAsFloat();
        if (!Float.isFinite(f) || Math.abs(f) > 10000.0f) throw new IllegalArgumentException("Invalid layout position.");
        return f;
    }

    static void apply(JsonObject jsonObject) {
        HudLayoutUtil.validate(jsonObject);
        try {
            Object object = ((PhaseTime)HudLayoutUtil.field(KryzexClient.INSTANCE.GUI, "ui")).layoutState();
            HudLayoutUtil.field(object, "offX", Float.valueOf(HudLayoutUtil.number(jsonObject.get("x"))));
            HudLayoutUtil.field(object, "offY", Float.valueOf(HudLayoutUtil.number(jsonObject.get("y"))));
            HudLayoutUtil.field(object, "posLoaded", true);
            HudLayoutUtil.field(object, "dragging", false);
            HudLayoutUtil.save(object, "savePosition");
            HUD hUD = (HUD)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(HUD.class);
            Object object2 = HudLayoutUtil.field(hUD, "hud");
            Map map = (Map)HudLayoutUtil.field(object2, "places");
            map.clear();
            HudLayoutUtil.field(object2, "dragging", null);
            Class<?> clazz = Class.forName("kryzex.gui.Watermark");
            Constructor<?> constructor = Class.forName("kryzex.gui.Bottom").getDeclaredConstructor(new Class[0]);
            constructor.setAccessible(true);
            for (Map.Entry<String, JsonElement> entry : jsonObject.getAsJsonObject("hud").entrySet()) {
                Object obj;
                try {
                    obj = Enum.valueOf((Class)clazz, entry.getKey());
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    continue;
                }
                JsonObject jsonObject2 = entry.getValue().getAsJsonObject();
                Object obj2 = constructor.newInstance(new Object[0]);
                HudLayoutUtil.field(obj2, "moved", jsonObject2.get("moved").getAsBoolean());
                HudLayoutUtil.field(obj2, "right", jsonObject2.get("right").getAsBoolean());
                HudLayoutUtil.field(obj2, "bottom", jsonObject2.get("bottom").getAsBoolean());
                HudLayoutUtil.field(obj2, "ox", Float.valueOf(HudLayoutUtil.number(jsonObject2.get("x"))));
                HudLayoutUtil.field(obj2, "oy", Float.valueOf(HudLayoutUtil.number(jsonObject2.get("y"))));
                map.put(obj, obj2);
            }
            HudLayoutUtil.field(object2, "loaded", true);
            HudLayoutUtil.save(object2, "save");
            return;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Couldn't restore the HUD layout.", reflectiveOperationException);
        }
    }
}
