package kryzex.misc;

import org.joml.Quaternionf;

public final class Rotation {
    public float x;
    public float y;
    public float z;
    public final Quaternionf rotation = new Quaternionf();
}
