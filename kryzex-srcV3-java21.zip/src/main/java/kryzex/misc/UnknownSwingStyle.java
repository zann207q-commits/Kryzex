package kryzex.misc;

import kryzex.misc.Rotation;
import kryzex.misc.Smooth;

public final class UnknownSwingStyle {
    private static final float[][] BOP_KEYS = new float[][]{{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f},new float[]{0.06f, 0.012f, 0.018f, -0.005f, 6.0f, -2.0f, 4.0f},new float[]{0.24f, -0.16f, -0.115f, -0.24f, -46.0f, 12.0f, -28.0f},new float[]{0.48f, -0.06f, -0.04f, -0.09f, -15.0f, 4.0f, -8.0f},new float[]{0.68f, 0.018f, 0.045f, -0.012f, 9.0f, -2.0f, 5.0f},new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f}};

    private UnknownSwingStyle() {
    }

    public static void sample(Smooth smooth, float f, int n, Rotation rotation) {
        float f2;
        float f3;
        rotation.z = 0.0f;
        rotation.y = 0.0f;
        rotation.x = 0.0f;
        rotation.rotation.identity();
        if (smooth == null || !Float.isFinite(f) || f <= 0.0f || f >= 1.0f) {
            return;
        }
        if (smooth == Smooth.Bop) {
            UnknownSwingStyle.bop(f, n < 0 ? -1 : 1, rotation);
            return;
        }
        float f4 = f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
        float f5 = (float)Math.sin(Math.PI * (double)f4);
        float f6 = (float)Math.sin(Math.PI * 2 * (double)f4);
        float f7 = n < 0 ? -1.0f : 1.0f;
        float f8 = switch (smooth.ordinal()) {
            case 0 -> {
                rotation.x = -0.16f * f7 * f5;
                rotation.y = 0.06f * f6 - 0.035f * f5;
                rotation.z = -0.12f * f5;
                f3 = -42.0f * f5;
                f2 = -18.0f * f7 * f5;
                yield -12.0f * f7 * f6;
            }
            case 1 -> {
                rotation.x = -0.3f * f7 * f5;
                rotation.y = 0.13f * f6 - 0.08f * f5;
                rotation.z = -0.14f * f5;
                f3 = -65.0f * f5;
                f2 = 25.0f * f7 * f6;
                yield -60.0f * f7 * f5;
            }
            case 2 -> {
                rotation.x = 0.025f * f7 * f5;
                rotation.y = 0.035f * f5;
                rotation.z = -0.34f * f5;
                f3 = -14.0f * f5;
                f2 = 5.0f * f7 * f5;
                yield 10.0f * f7 * f5;
            }
            case 3 -> {
                rotation.x = 0.07f * f7 * f5;
                rotation.y = 0.07f * f5;
                rotation.z = -0.08f * f5;
                f3 = -18.0f * f5;
                f2 = 0.0f;
                yield 360.0f * f7 * f4;
            }
            case 4 -> {
                rotation.x = -0.28f * f7 * f5;
                rotation.y = 0.1f * f6;
                rotation.z = -0.16f * f5;
                f3 = -80.0f * f5;
                f2 = -20.0f * f7 * (float)Math.sin(Math.PI * (double)f4 * (double)f4);
                yield -20.0f * f7 * f5;
            }
            default -> throw new IllegalStateException("Unknown swing style");
        };
        float f9 = (float)Math.PI / 180;
        rotation.rotation.rotationXYZ(f3 * f9, f2 * f9, f8 * f9);
    }

    private static void bop(float f, int n, Rotation rotation) {
        int n2;
        for (n2 = 0; n2 < BOP_KEYS.length - 2 && f > BOP_KEYS[n2 + 1][0]; ++n2) {
        }
        float[] fArray = BOP_KEYS[n2];
        float[] fArray2 = BOP_KEYS[n2 + 1];
        float f2 = (f - fArray[0]) / (fArray2[0] - fArray[0]);
        f2 = f2 * f2 * (3.0f - 2.0f * f2);
        rotation.x = (float)n * UnknownSwingStyle.blend(fArray[1], fArray2[1], f2);
        rotation.y = UnknownSwingStyle.blend(fArray[2], fArray2[2], f2);
        rotation.z = UnknownSwingStyle.blend(fArray[3], fArray2[3], f2);
        float f3 = (float)Math.PI / 180;
        rotation.rotation.rotationXYZ(UnknownSwingStyle.blend(fArray[4], fArray2[4], f2) * f3, (float)n * UnknownSwingStyle.blend(fArray[5], fArray2[5], f2) * f3, (float)n * UnknownSwingStyle.blend(fArray[6], fArray2[6], f2) * f3);
    }

    private static float blend(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }
}
