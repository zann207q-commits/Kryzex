package kryzex.misc;

public enum Smooth {
    Smooth,
    Slash,
    Stab,
    Spin,
    Classic,
    Bop;

}
