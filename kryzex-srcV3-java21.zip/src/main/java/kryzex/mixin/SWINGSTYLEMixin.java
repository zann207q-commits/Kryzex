package kryzex.mixin;

import kryzex.modules.render.SwingAnimations;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_759.class})
public abstract class SWINGSTYLEMixin {
    @Inject(method={"method_65816"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$swingStyle(float f, class_4587 class_45872, int n, class_1306 class_13062, CallbackInfo callbackInfo) {
        if (!SwingAnimations.j(class_45872, class_13062, f)) return;
        callbackInfo.cancel();
    }
}
