package kryzex.mixin;

import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_412;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_412.class})
public abstract class CONNECTMixin {
    @Shadow
    private class_2561 field_2413;

    @Inject(method={"method_25394"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$connect(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        LoadingScreenLogo.screen(class_3322, -1.0f, this.field_2413 == null ? "Connecting to server" : this.field_2413.getString());
        class_3322.method_71048();
        class_437 class_4372 = (class_437)(Object)this;
        int n3 = LoadingScreenLogo.buttonTop(class_4372.field_22790);
        for (class_364 class_3642 : class_4372.method_25396()) {
            if (!(class_3642 instanceof class_4068)) continue;
            class_4068 class_40682 = (class_4068)class_3642;
            if (class_3642 instanceof class_339) {
                class_339 class_3392 = (class_339)class_3642;
                class_3392.method_46419(n3);
            }
            class_40682.method_25394(class_3322, n, n2, f);
        }
        callbackInfo.cancel();
    }
}
