package kryzex.mixin;

import kryzex.modules.render.j.Character3D;
import kryzex.modules.render.j.CharacterRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1007.class})
public abstract class CharacterFIRSTPERSONHANDMixin<T extends class_11890>
extends class_922<T, class_10055, class_591> {
    protected CharacterFIRSTPERSONHANDMixin(class_5617.class_5618 class_56182, class_591 class_5912, float f) {
        super(class_56182, class_5912, f);
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void kryzex$addCharacterLayer(class_5617.class_5618 class_56182, boolean bl, CallbackInfo callbackInfo) {
        this.method_4046(new CharacterRenderer((class_3883<class_10055, class_591>)this));
    }

    @Inject(method={"method_62604"}, at={@At(value="TAIL")})
    private void kryzex$extractCharacter(class_11890 class_118902, class_10055 class_100552, float f, CallbackInfo callbackInfo) {
        Character3D.Y((class_1297)class_118902, (class_10055)class_100552);
    }

    @Inject(method={"method_23205"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$characterFirstPersonHand(class_4587 class_45872, class_11659 class_116592, int n, class_2960 class_29602, class_630 class_6302, boolean bl, CallbackInfo callbackInfo) {
        if (!CharacterRenderer.L((class_591)(Object)this.method_4038(), class_45872, class_116592, n, class_6302)) return;
        callbackInfo.cancel();
    }
}
