package kryzex.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import kryzex.util.EntityGenericExplode;
import net.minecraft.class_1297;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_761.class}, remap=false)
public abstract class FilterHEAVYENTITIESMixin {
    @ModifyExpressionValue(method={"method_72917"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_638;method_18112()Ljava/lang/Iterable;")}, remap=false)
    private Iterable<class_1297> kryzex$filterHeavyEntities(Iterable<class_1297> iterable) {
        return EntityGenericExplode.renderEntities(iterable);
    }
}
