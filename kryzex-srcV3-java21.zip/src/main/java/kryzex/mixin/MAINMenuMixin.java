package kryzex.mixin;

import kryzex.gui.MenuPlaydemo;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_310.class})
public abstract class MAINMenuMixin {
    @ModifyVariable(method={"method_1507"}, at=@At(value="HEAD"), argsOnly=true)
    private class_437 kryzex$mainMenu(class_437 class_4372) {
        return class_4372 instanceof class_442 && !(class_4372 instanceof MenuPlaydemo) ? new MenuPlaydemo() : class_4372;
    }
}
