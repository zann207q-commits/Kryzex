package kryzex.mixin;

import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class REVEALMixin {
    @Inject(method={"method_39192"}, at={@At(value="HEAD")})
    private void kryzex$reveal(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        LoadingScreenLogo.reveal(class_3322);
    }
}
