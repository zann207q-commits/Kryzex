package kryzex.mixin;

import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_435;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_435.class})
public abstract class ProgressMixin {
    @Shadow
    private class_2561 field_2541;
    @Shadow
    private class_2561 field_2544;
    @Shadow
    private int field_2542;
    @Shadow
    private boolean field_2543;

    @Inject(method={"method_25394"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$progress(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (this.field_2543) return;
        String string = this.field_2544 != null && !this.field_2544.getString().isBlank() ? this.field_2544.getString() : (this.field_2541 != null ? this.field_2541.getString() : "Preparing your experience");
        LoadingScreenLogo.screen(class_3322, this.field_2542 == 0 ? -1.0f : (float)this.field_2542 / 100.0f, string);
        callbackInfo.cancel();
    }
}
