package kryzex.mixin;

import net.minecraft.class_241;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_744.class})
public interface SetMovementVECTORMixin {
    @Accessor(value="field_55868")
    public void kryzex$setMovementVector(class_241 var1);
}
