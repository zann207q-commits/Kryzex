package kryzex.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_310.class})
public interface InvokeDOItemUseMixin {
    @Invoker(value="method_1583")
    public void invokeDoItemUse();
}
