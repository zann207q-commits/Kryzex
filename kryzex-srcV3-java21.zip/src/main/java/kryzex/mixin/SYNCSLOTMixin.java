package kryzex.mixin;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_636.class})
public interface SYNCSLOTMixin {
    @Invoker(value="method_2911")
    public void syncSlot();
}
