package kryzex.mixin;

import net.minecraft.class_6017;
import net.minecraft.class_6793;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_6793.class})
public interface GetCOUNTMixin {
    @Accessor(value="field_35719")
    public class_6017 getCount();
}
