package kryzex.mixin;

import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_11653;
import net.minecraft.class_156;
import net.minecraft.class_332;
import net.minecraft.class_3928;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_3928.class})
public abstract class BackgroundMixin2 {
    @Shadow
    private class_11653 field_61631;
    @Shadow
    private float field_61632;
    @Shadow
    private long field_19101;

    @Inject(method={"method_25394"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$terrain(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        long l = class_156.method_658();
        if (l - this.field_19101 > 2000L) {
            this.field_19101 = l;
            ((class_437)(Object)this).method_37064(true);
        }
        boolean bl = this.field_61631 != null && this.field_61631.method_72906();
        LoadingScreenLogo.screen(class_3322, bl ? this.field_61632 : -1.0f, "Loading terrain");
        callbackInfo.cancel();
    }

    @Inject(method={"method_25420"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$background(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        callbackInfo.cancel();
    }
}
