package kryzex.mixin;

import kryzex.modules.render.j.CharacterRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_591.class})
public abstract class CharacterHANDMixin {
    @Inject(method={"method_72859"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$characterHand(class_10055 class_100552, class_1306 class_13062, class_4587 class_45872, CallbackInfo callbackInfo) {
        if (!CharacterRenderer.F((class_591)(Object)this, class_100552, class_13062, class_45872)) return;
        callbackInfo.cancel();
    }
}
