package kryzex.mixin;

import kryzex.modules.misc.SwingSpeed;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1309.class})
public abstract class ADJUSTSWINGDURATIONMixin {
    @Inject(method={"method_6028"}, at={@At(value="RETURN")}, cancellable=true)
    private void kryzex$adjustSwingDuration(CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue(SwingSpeed.R(callbackInfoReturnable.getReturnValueI()));
    }
}
