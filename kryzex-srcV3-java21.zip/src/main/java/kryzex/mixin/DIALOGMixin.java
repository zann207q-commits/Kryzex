package kryzex.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11419;
import net.minecraft.class_11473;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_11473.class})
public interface DIALOGMixin {
    @Accessor(value="field_60761")
    public class_11419 kryzex$dialog();
}
