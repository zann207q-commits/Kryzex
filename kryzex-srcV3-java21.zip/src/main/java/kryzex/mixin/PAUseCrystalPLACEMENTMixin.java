package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.AttackBlockEvent;
import kryzex.modules.combat.AutoCrystal;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_636.class})
public class PAUseCrystalPLACEMENTMixin {
    @Inject(method={"method_2896"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$pauseCrystalPlacement(class_746 class_7462, class_1268 class_12682, class_3965 class_39652, CallbackInfoReturnable<class_1269> callbackInfoReturnable) {
        if (!AutoCrystal.X(class_12682)) return;
        callbackInfoReturnable.setReturnValue(class_1269.field_5814);
    }

    @Inject(method={"method_2919"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$pauseCrystalItemUse(class_1657 class_16572, class_1268 class_12682, CallbackInfoReturnable<class_1269> callbackInfoReturnable) {
        if (!AutoCrystal.X(class_12682)) return;
        callbackInfoReturnable.setReturnValue(class_1269.field_5814);
    }

    @Inject(method={"method_2918"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$pauseCrystalAttack(class_1657 class_16572, class_1297 class_12972, CallbackInfo callbackInfo) {
        if (!AutoCrystal.r(class_12972)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_2910"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttackBlock(class_2338 class_23382, class_2350 class_23502, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        AttackBlockEvent attackBlockEvent = new AttackBlockEvent(class_23382, class_23502);
        EventBus.b(attackBlockEvent);
        if (!attackBlockEvent.isCancelled()) return;
        callbackInfoReturnable.setReturnValue(false);
    }
}
