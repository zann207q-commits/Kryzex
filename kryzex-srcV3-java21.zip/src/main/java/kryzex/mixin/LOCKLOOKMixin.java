package kryzex.mixin;

import kryzex.cinematic.InputLocked;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1297.class})
public abstract class LOCKLOOKMixin {
    @Inject(method={"method_5872"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$lockLook(double d, double d2, CallbackInfo callbackInfo) {
        if (!InputLocked.inputLocked() || (Object)this != class_310.method_1551().field_1724) return;
        callbackInfo.cancel();
    }
}
