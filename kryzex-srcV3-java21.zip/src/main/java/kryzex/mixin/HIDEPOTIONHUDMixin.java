package kryzex.mixin;

import kryzex.modules.render.HUD;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class HIDEPOTIONHUDMixin {
    @Inject(method={"method_1765"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$hidePotionHud(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        if (!HUD.HIDE_POTION_HUD.getValue()) return;
        callbackInfo.cancel();
    }
}
