package kryzex.mixin;

import kryzex.cinematic.InputLocked;
import kryzex.mixin.SetMovementVECTORMixin;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_743.class})
public abstract class FREEZEMixin {
    @Inject(method={"method_3129"}, at={@At(value="TAIL")})
    private void kryzex$freeze(CallbackInfo callbackInfo) {
        if (!InputLocked.inputLocked()) return;
        ((class_744)(Object)this).field_54155 = class_10185.field_54098;
        ((SetMovementVECTORMixin)((Object)this)).kryzex$setMovementVector(class_241.field_1340);
    }
}
