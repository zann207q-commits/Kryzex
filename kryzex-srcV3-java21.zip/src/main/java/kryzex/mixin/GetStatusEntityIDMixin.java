package kryzex.mixin;

import net.minecraft.class_2663;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_2663.class})
public interface GetStatusEntityIDMixin {
    @Accessor(value="field_12175", remap=false)
    public int kryzex$getStatusEntityId();
}
