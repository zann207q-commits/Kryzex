package kryzex.mixin;

import kryzex.fx.ItemFxAccess;
import kryzex.fx.TotemUndying;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_10444.class})
public abstract class RenderFXMixin
implements ItemFxAccess {
    @Shadow
    class_811 field_55337;
    @Shadow
    private int field_55339;
    @Shadow
    private class_10444.class_10446[] field_55340;
    @Unique
    private int kryzex$fx;

    @Override
    public int kryzex$fx() {
        return this.kryzex$fx;
    }

    @Override
    public void kryzex$setFx(int n) {
        this.kryzex$fx = n;
    }

    @Override
    public class_10444.class_10446 kryzex$layer0() {
        return this.field_55340[0];
    }

    @Inject(method={"method_65605"}, at={@At(value="HEAD")})
    private void kryzex$clearFx(CallbackInfo callbackInfo) {
        this.kryzex$fx = 0;
    }

    @Inject(method={"method_65604"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$renderFx(class_4587 class_45872, class_11659 class_116592, int n, int n2, int n3, CallbackInfo callbackInfo) {
        if (this.kryzex$fx == 0 || this.field_55339 <= 0) return;
        try {
            if (!TotemUndying.render(this.kryzex$fx, this.field_55337, this.field_55340[0], class_45872, class_116592, n)) return;
            callbackInfo.cancel();
            return;
        }
        catch (Throwable throwable) {
            this.kryzex$fx = 0;
            System.err.println("Kryzex: custom item render failed: " + String.valueOf(throwable));
        }
    }
}
