package kryzex.mixin;

import kryzex.gui.ClickGuiScreen;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={class_757.class})
public abstract class FadeMenuBlurMixin {
    @ModifyArg(method={"method_3192"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_11284;method_71116(IIDJLnet/minecraft/class_9779;ILnet/minecraft/class_4184;Z)V"), index=5)
    private int kryzex$fadeMenuBlur(int n) {
        return ClickGuiScreen.blurRadius(n);
    }
}
