package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.BlockStateChangeEvent;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_2818.class})
public class ONSetBlockStateMixin {
    @Shadow
    @Final
    class_1937 field_12858;

    @Inject(method={"method_12010"}, at={@At(value="TAIL")})
    private void onSetBlockState(class_2338 class_23382, class_2680 class_26802, int n, CallbackInfoReturnable<class_2680> callbackInfoReturnable) {
        if (!this.field_12858.method_8608() || !EventBus.hasActiveListener(BlockStateChangeEvent.class)) return;
        EventBus.b(new BlockStateChangeEvent(class_23382, (class_2680)callbackInfoReturnable.getReturnValue(), class_26802));
    }
}
