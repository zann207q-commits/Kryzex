package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_332;
import net.minecraft.class_357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_357.class})
public abstract class SLIDERMixin {
    @Shadow
    protected double field_22753;

    @Inject(method={"method_48579"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$slider(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        class_357 class_3572 = (class_357)(Object)this;
        if (!KryzexClient.active() || !KryzexClient.supports(class_3572.method_25369().getString())) return;
        KryzexClient.slider(class_3322, class_3572, this.field_22753);
        callbackInfo.cancel();
    }
}
