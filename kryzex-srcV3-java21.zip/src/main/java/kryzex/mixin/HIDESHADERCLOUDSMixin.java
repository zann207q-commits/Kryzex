package kryzex.mixin;

import kryzex.modules.render.SkyShaders;
import kryzex.util.ShaderCompileFailed;
import net.minecraft.class_9955;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9955.class})
public abstract class HIDESHADERCLOUDSMixin {
    @Inject(method={"method_62168"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$hideShaderClouds(CallbackInfo callbackInfo) {
        if (!ShaderCompileFailed.active() || !SkyShaders.H()) return;
        callbackInfo.cancel();
    }
}
