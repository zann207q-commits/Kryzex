package kryzex.mixin;

import kryzex.cinematic.InputLocked;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public abstract class SWALLOWINPUTMixin {
    @Inject(method={"method_1508"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$swallowInput(CallbackInfo callbackInfo) {
        if (!InputLocked.inputLocked()) return;
        class_310 class_3102 = (class_310)(Object)this;
        if (class_3102.field_1690 != null) {
            for (class_304 class_3042 : class_3102.field_1690.field_1839) {
                while (class_3042.method_1436()) {
                }
            }
        }
        callbackInfo.cancel();
    }
}
