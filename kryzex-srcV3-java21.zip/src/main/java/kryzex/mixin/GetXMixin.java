package kryzex.mixin;

import net.minecraft.class_4604;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_4604.class})
public interface GetXMixin {
    @Accessor(value="field_20995")
    public double getX();

    @Accessor(value="field_20995")
    public void setX(double var1);

    @Accessor(value="field_20996")
    public double getY();

    @Accessor(value="field_20996")
    public void setY(double var1);

    @Accessor(value="field_20997")
    public double getZ();

    @Accessor(value="field_20997")
    public void setZ(double var1);
}
