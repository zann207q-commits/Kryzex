package kryzex.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_636.class})
public interface BlockOverlayDestroyProgressMixin {
    @Accessor(value="field_3715")
    public float kryzex$blockOverlayDestroyProgress();

    @Accessor(value="field_3714")
    public class_2338 kryzex$blockOverlayDestroyPos();
}
