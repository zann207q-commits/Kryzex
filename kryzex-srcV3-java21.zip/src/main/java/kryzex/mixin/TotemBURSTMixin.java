package kryzex.mixin;

import kryzex.fx.TotemUndying;
import net.minecraft.class_1297;
import net.minecraft.class_2394;
import net.minecraft.class_634;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_634.class})
public abstract class TotemBURSTMixin {
    @Redirect(method={"method_11148"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_702;method_3051(Lnet/minecraft/class_1297;Lnet/minecraft/class_2394;I)V"))
    private void kryzex$totemBurst(class_702 class_7022, class_1297 class_12972, class_2394 class_23942, int n) {
        boolean bl = false;
        try {
            bl = TotemUndying.totemPop(class_12972, class_23942);
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: totem burst failed: " + String.valueOf(throwable));
        }
        if (bl) return;
        class_7022.method_3051(class_12972, class_23942, n);
    }
}
