package kryzex.mixin;

import com.mojang.authlib.GameProfile;
import kryzex.client.KryzexClient;
import kryzex.modules.misc.SkinProtect;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_640.class})
public abstract class REPLACESKINTextURESMixin {
    @Inject(method={"method_52810"}, at={@At(value="RETURN")}, cancellable=true, remap=false)
    private void kryzex$replaceSkinTextures(CallbackInfoReturnable<class_8685> callbackInfoReturnable) {
        if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.MODULE_MANAGER == null) {
            return;
        }
        SkinProtect skinProtect = (SkinProtect)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(SkinProtect.class);
        if (skinProtect == null || !skinProtect.isEnabled()) {
            return;
        }
        GameProfile gameProfile = ((class_640)(Object)this).method_2966();
        callbackInfoReturnable.setReturnValue(skinProtect.R(gameProfile.id(), gameProfile.name(), (class_8685)callbackInfoReturnable.getReturnValue()));
    }
}
