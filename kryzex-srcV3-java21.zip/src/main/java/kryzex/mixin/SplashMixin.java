package kryzex.mixin;

import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_425.class})
public abstract class SplashMixin {
    @Shadow
    @Final
    private class_310 field_18217;
    @Shadow
    @Final
    private class_4011 field_17767;
    @Shadow
    @Final
    private boolean field_18219;
    @Shadow
    private float field_17770;
    @Shadow
    private long field_17771;
    @Shadow
    private long field_18220;
    @Unique
    private long kryzex$last;

    @Inject(method={"method_25394"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$splash(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        float f2;
        long l = class_156.method_658();
        if (this.field_18219 && this.field_18220 == -1L) {
            this.field_18220 = l;
        }
        float f3 = f2 = this.field_17771 < 0L ? -1.0f : (float)(l - this.field_17771) / 1000.0f;
        if (f2 >= 2.0f) {
            this.field_18217.method_18502(null);
            callbackInfo.cancel();
            return;
        } else {
            if (f2 >= 1.0f && this.field_18217.field_1755 != null) {
                this.field_18217.field_1755.method_47413(class_3322, n, n2, f);
            }
            float f4 = f2 >= 1.0f ? 1.0f - Math.clamp(f2 - 1.0f, 0.0f, 1.0f) : 1.0f;
            float f5 = this.kryzex$last == 0L ? 0.016f : Math.min(0.1f, (float)(l - this.kryzex$last) / 1000.0f);
            this.kryzex$last = l;
            this.field_17770 += (this.field_17767.method_18229() - this.field_17770) * (1.0f - (float)Math.exp(-8.0f * f5));
            class_3322.method_71048();
            LoadingScreenLogo.splash(class_3322, this.field_17770, f4);
            callbackInfo.cancel();
        }
    }
}
