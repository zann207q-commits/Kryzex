package kryzex.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_10799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_10799.class})
public interface GetTRANSFORMSSNIPPETMixin {
    @Invoker(value="method_67887")
    public static RenderPipeline kryzex$register(RenderPipeline renderPipeline) {
        throw new AssertionError();
    }

    @Accessor(value="field_60125", remap=false)
    public static RenderPipeline.Snippet kryzex$getTransformsSnippet() {
        throw new AssertionError();
    }

    @Accessor(value="field_56892", remap=false)
    public static RenderPipeline.Snippet kryzex$getOutlineSnippet() {
        throw new AssertionError();
    }
}
