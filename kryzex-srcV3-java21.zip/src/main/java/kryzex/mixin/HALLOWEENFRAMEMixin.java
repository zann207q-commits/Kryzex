package kryzex.mixin;

import kryzex.cinematic.BarsWanted;
import kryzex.cinematic.CinematicDirector;
import kryzex.cinematic.InputLocked;
import kryzex.gui.WorldPitch;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_757.class})
public abstract class HALLOWEENFRAMEMixin {
    @Inject(method={"method_3192"}, at={@At(value="HEAD")})
    private void kryzex$halloweenFrame(class_9779 class_97792, boolean bl, CallbackInfo callbackInfo) {
        try {
            CinematicDirector.frame();
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: Halloween frame failed: " + String.valueOf(throwable));
        }
    }

    @Inject(method={"method_3196"}, at={@At(value="RETURN")}, cancellable=true)
    private void kryzex$cinematicZoom(class_4184 class_41842, float f, boolean bl, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        if (!bl || !InputLocked.active()) return;
        callbackInfoReturnable.setReturnValue(Float.valueOf(InputLocked.fov(callbackInfoReturnable.getReturnValueF())));
    }

    @Inject(method={"method_3198"}, at={@At(value="HEAD")})
    private void kryzex$beatShake(class_4587 class_45872, float f, CallbackInfo callbackInfo) {
        float f2 = WorldPitch.worldRoll();
        float f3 = WorldPitch.worldPitch();
        if (f2 == 0.0f && f3 == 0.0f) return;
        class_45872.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(f2));
        class_45872.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(f3));
    }

    @Inject(method={"method_3172"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$hideHand(float f, boolean bl, Matrix4f matrix4f, CallbackInfo callbackInfo) {
        if (!BarsWanted.hideHud()) return;
        callbackInfo.cancel();
    }
}
