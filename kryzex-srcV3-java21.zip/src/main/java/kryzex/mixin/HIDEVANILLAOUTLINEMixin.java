package kryzex.mixin;

import kryzex.module.StaticModules;
import kryzex.modules.render.BlockOverlay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_761.class})
public abstract class HIDEVANILLAOUTLINEMixin {
    @Inject(method={"method_62210"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$hideVanillaOutline(CallbackInfo callbackInfo) {
        BlockOverlay outline2 = StaticModules.get(BlockOverlay.class);
        if (outline2 == null || !outline2.isEnabled()) return;
        callbackInfo.cancel();
    }
}
