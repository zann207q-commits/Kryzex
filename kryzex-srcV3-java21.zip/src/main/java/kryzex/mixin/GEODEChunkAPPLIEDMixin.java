package kryzex.mixin;

import kryzex.module.MacroEventBus;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public abstract class GEODEChunkAPPLIEDMixin {
    @Inject(method={"method_11128"}, at={@At(value="TAIL")})
    private void kryzex$geodeChunkApplied(class_2672 class_26722, CallbackInfo callbackInfo) {
        MacroEventBus.packetApplied(class_26722);
    }

    @Inject(method={"method_11143"}, at={@At(value="TAIL")})
    private void kryzex$geodeLightApplied(class_2676 class_26762, CallbackInfo callbackInfo) {
        MacroEventBus.packetApplied(class_26762);
    }
}
