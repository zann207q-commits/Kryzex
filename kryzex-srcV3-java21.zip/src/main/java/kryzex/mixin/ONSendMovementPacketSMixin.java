package kryzex.mixin;

import com.mojang.authlib.GameProfile;
import kryzex.config.EventBus;
import kryzex.event.MovementPacketEvent;
import kryzex.event.TickEvent;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_746.class})
public class ONSendMovementPacketSMixin
extends class_742 {
    @Shadow
    @Final
    protected class_310 field_3937;

    public ONSendMovementPacketSMixin(class_638 class_6382, GameProfile gameProfile) {
        super(class_6382, gameProfile);
    }

    @Inject(method={"method_3136"}, at={@At(value="HEAD")})
    private void onSendMovementPackets(CallbackInfo callbackInfo) {
        EventBus.b(new MovementPacketEvent());
    }

    @Inject(method={"method_5773"}, at={@At(value="HEAD")})
    private void onPlayerTick(CallbackInfo callbackInfo) {
        EventBus.b(new TickEvent());
    }
}
