package kryzex.mixin;

import kryzex.fx.ItemFxRenderer;
import net.minecraft.class_1921;
import net.minecraft.class_9801;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1921.class})
public abstract class DrawFXMixin {
    @Inject(method={"method_60895"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$drawFx(class_9801 class_98012, CallbackInfo callbackInfo) {
        if (!ItemFxRenderer.isMarker(this)) return;
        ItemFxRenderer.flush(class_98012);
        callbackInfo.cancel();
    }
}
