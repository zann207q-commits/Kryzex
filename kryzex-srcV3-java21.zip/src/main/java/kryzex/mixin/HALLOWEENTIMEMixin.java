package kryzex.mixin;

import kryzex.cinematic.UnderValid;
import net.minecraft.class_1937;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1937.class})
public abstract class HALLOWEENTIMEMixin {
    @Inject(method={"method_8532"}, at={@At(value="RETURN")}, cancellable=true)
    private void kryzex$halloweenTime(CallbackInfoReturnable<Long> callbackInfoReturnable) {
        if (!(((Object)this) instanceof class_638) || !UnderValid.overridingTime()) return;
        callbackInfoReturnable.setReturnValue(UnderValid.timeOfDay((class_1937)(Object)this, callbackInfoReturnable.getReturnValueJ()));
    }
}
