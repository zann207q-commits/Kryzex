package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.modules.misc.Freecam;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_743.class}, remap=false)
public abstract class ContinueBODYINPUTMixin {
    @Inject(method={"method_3129"}, at={@At(value="TAIL")}, remap=false)
    private void kryzex$continueBodyInput(CallbackInfo callbackInfo) {
        if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.getModuleManager() == null) {
            return;
        }
        Freecam freecam = (Freecam)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(Freecam.class);
        if (freecam == null || !freecam.isEnabled()) return;
        freecam.d((class_744)(Object)this);
    }
}
