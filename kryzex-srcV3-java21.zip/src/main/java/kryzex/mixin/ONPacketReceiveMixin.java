package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.PacketReceiveEvent;
import kryzex.event.PacketSendEvent;
import kryzex.modules.combat.AutoCrystal;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2535.class})
public class ONPacketReceiveMixin {
    @Inject(method={"method_10759"}, at={@At(value="HEAD")}, cancellable=true)
    private static void onPacketReceive(class_2596<?> class_25962, class_2547 class_25472, CallbackInfo callbackInfo) {
        boolean bl = AutoCrystal.U(class_25962);
        PacketReceiveEvent packetReceiveEvent = new PacketReceiveEvent(class_25962, bl);
        EventBus.b(packetReceiveEvent);
        if (!packetReceiveEvent.isCancelled()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_10743(Lnet/minecraft/class_2596;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPacketSend(class_2596<?> class_25962, CallbackInfo callbackInfo) {
        PacketSendEvent packetSendEvent = new PacketSendEvent(class_25962);
        EventBus.b(packetSendEvent);
        if (!packetSendEvent.isCancelled()) return;
        callbackInfo.cancel();
    }
}
