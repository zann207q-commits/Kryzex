package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_1297;
import net.minecraft.class_2394;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_702.class}, remap=false)
public abstract class SkipParticleWORKMixin {
    @Inject(method={"method_3056"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipFactory(class_2394 class_23942, double d, double d2, double d3, double d4, double d5, double d6, CallbackInfoReturnable<class_703> callbackInfoReturnable) {
        if (!EntityGenericExplode.hideEffect(class_23942)) return;
        callbackInfoReturnable.setReturnValue(null);
    }

    @Inject(method={"method_3058"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipParticle(class_703 class_7032, CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.hideParticle(class_7032)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_3061"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipEmitter(class_1297 class_12972, class_2394 class_23942, CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.hideEffect(class_23942)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_3051"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipEmitterLong(class_1297 class_12972, class_2394 class_23942, int n, CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.hideEffect(class_23942)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_3057", "method_74283"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipParticleWork(CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.enabled(16)) return;
        callbackInfo.cancel();
    }
}
