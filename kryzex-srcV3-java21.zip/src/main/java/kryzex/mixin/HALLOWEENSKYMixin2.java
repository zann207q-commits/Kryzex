package kryzex.mixin;

import kryzex.cinematic.UnderValid;
import net.minecraft.class_12197;
import net.minecraft.class_12202;
import net.minecraft.class_12206;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_12202.class})
public abstract class HALLOWEENSKYMixin2 {
    @Inject(method={"method_75689"}, at={@At(value="RETURN")}, cancellable=true)
    private void kryzex$halloweenSky(class_12197<?> class_121972, float f, CallbackInfoReturnable<Object> callbackInfoReturnable) {
        if (UnderValid.strength() <= 0.0f) {
            return;
        }
        Object object = callbackInfoReturnable.getReturnValue();
        if (class_121972 == class_12206.field_63746 && object instanceof Integer) {
            Integer n = (Integer)object;
            callbackInfoReturnable.setReturnValue(UnderValid.skyColor(n));
            return;
        } else if (class_121972 == class_12206.field_64339 && object instanceof Integer) {
            Integer n = (Integer)object;
            callbackInfoReturnable.setReturnValue(UnderValid.sunset(n));
            return;
        } else if (class_121972 == class_12206.field_64126 && object instanceof Integer) {
            Integer n = (Integer)object;
            callbackInfoReturnable.setReturnValue(UnderValid.clouds(n));
            return;
        } else {
            if (class_121972 != class_12206.field_64344 || !(object instanceof Float)) return;
            Float f2 = (Float)object;
            callbackInfoReturnable.setReturnValue(Float.valueOf(UnderValid.stars(f2.floatValue())));
        }
    }
}
