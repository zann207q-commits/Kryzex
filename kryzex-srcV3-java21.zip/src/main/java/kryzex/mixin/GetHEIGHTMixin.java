package kryzex.mixin;

import net.minecraft.class_6122;
import net.minecraft.class_6795;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_6795.class})
public interface GetHEIGHTMixin {
    @Accessor(value="field_35726")
    public class_6122 getHeight();
}
