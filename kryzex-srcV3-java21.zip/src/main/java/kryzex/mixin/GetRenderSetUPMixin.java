package kryzex.mixin;

import net.minecraft.class_12247;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_1921.class})
public interface GetRenderSetUPMixin {
    @Invoker(value="method_75940")
    public static class_1921 kryzex$create(String string, class_12247 class_122472) {
        throw new AssertionError();
    }

    @Accessor(value="field_64013", remap=false)
    public class_12247 kryzex$getRenderSetup();
}
