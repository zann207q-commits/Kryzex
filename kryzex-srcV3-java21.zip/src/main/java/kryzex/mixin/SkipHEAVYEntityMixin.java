package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_898.class}, remap=false)
public abstract class SkipHEAVYEntityMixin {
    @Inject(method={"method_3950"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipHeavyEntity(class_1297 class_12972, class_4604 class_46042, double d, double d2, double d3, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (!EntityGenericExplode.hideEntity(class_12972)) return;
        callbackInfoReturnable.setReturnValue(false);
    }
}
