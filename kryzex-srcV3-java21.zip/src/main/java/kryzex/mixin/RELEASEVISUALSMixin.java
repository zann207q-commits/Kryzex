package kryzex.mixin;

import kryzex.gui.KryzexMenuVideo;
import kryzex.gui.MainMenuScene;
import kryzex.util.StorageBloom;
import kryzex.util.ShaderCompileFailed;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_757.class})
public abstract class RELEASEVISUALSMixin {
    @Inject(method={"close"}, at={@At(value="HEAD")})
    private void kryzex$releaseVisuals(CallbackInfo callbackInfo) {
        ShaderCompileFailed.release();
        StorageBloom.release();
        MainMenuScene.release();
        KryzexMenuVideo.close();
    }
}
