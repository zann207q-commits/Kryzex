package kryzex.mixin;

import kryzex.modules.render.j.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_308.class})
public abstract class TrackCharacterLightingMixin {
    @Inject(method={"method_71034"}, at={@At(value="HEAD")})
    private void kryzex$trackCharacterLighting(class_308.class_11274 class_112742, CallbackInfo callbackInfo) {
        Entry.T(class_112742);
    }
}
