package kryzex.mixin;

import kryzex.cinematic.UnderValid;
import net.minecraft.class_765;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={class_765.class})
public abstract class NightVisionMixin {
    private static final String PUT = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;";
    private static final String VEC = "Lcom/mojang/blaze3d/buffers/Std140Builder;putVec3(Lorg/joml/Vector3fc;)Lcom/mojang/blaze3d/buffers/Std140Builder;";

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=1))
    private float kryzex$sky(float f) {
        return UnderValid.lightmap(1, f);
    }

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=2))
    private float kryzex$block(float f) {
        return UnderValid.lightmap(2, f);
    }

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=3))
    private float kryzex$nightVision(float f) {
        return UnderValid.lightmap(3, f);
    }

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=5))
    private float kryzex$darken(float f) {
        return UnderValid.lightmap(5, f);
    }

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=6))
    private float kryzex$gamma(float f) {
        return UnderValid.lightmap(6, f);
    }

    @ModifyArg(method={"method_3313"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/buffers/Std140Builder;putVec3(Lorg/joml/Vector3fc;)Lcom/mojang/blaze3d/buffers/Std140Builder;", ordinal=0))
    private Vector3fc kryzex$moonlight(Vector3fc vector3fc) {
        return UnderValid.strength() > 0.0f ? UnderValid.skyLight(new Vector3f(vector3fc)) : vector3fc;
    }
}
