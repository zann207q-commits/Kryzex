package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.ChunkDataEvent;
import kryzex.event.EntitySpawnEvent;
import kryzex.event.EntityStatusEvent;
import kryzex.event.LightUpdateEvent;
import kryzex.util.FlaggedSnapshot;
import net.minecraft.class_1937;
import net.minecraft.class_2604;
import net.minecraft.class_2663;
import net.minecraft.class_2666;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public abstract class ONEntityStatusMixin {
    @Inject(method={"method_11148"}, at={@At(value="TAIL")}, remap=false)
    private void onEntityStatus(class_2663 class_26632, CallbackInfo callbackInfo) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_26632.method_11470() != 35 || class_26632.method_11469((class_1937)class_3102.field_1687) != class_3102.field_1724) return;
        EventBus.b(new EntityStatusEvent());
    }

    @Inject(method={"method_11128"}, at={@At(value="TAIL")}, remap=false)
    private void onChunkData(class_2672 class_26722, CallbackInfo callbackInfo) {
        FlaggedSnapshot.ingest(class_26722.method_11523(), class_26722.method_11524(), class_26722.method_38599());
        EventBus.b(new ChunkDataEvent(class_26722));
    }

    @Inject(method={"method_11143"}, at={@At(value="TAIL")}, remap=false)
    private void onLightUpdate(class_2676 class_26762, CallbackInfo callbackInfo) {
        FlaggedSnapshot.ingest(class_26762.method_11558(), class_26762.method_11554(), class_26762.method_38600());
        EventBus.b(new LightUpdateEvent(class_26762));
    }

    @Inject(method={"method_11107"}, at={@At(value="TAIL")}, remap=false)
    private void onUnloadChunk(class_2666 class_26662, CallbackInfo callbackInfo) {
        FlaggedSnapshot.unload(class_26662.comp_1726().field_9181, class_26662.comp_1726().field_9180);
    }

    @Inject(method={"method_11112"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void onEntitySpawn(class_2604 class_26042, CallbackInfo callbackInfo) {
        EntitySpawnEvent entitySpawnEvent = new EntitySpawnEvent(class_26042);
        EventBus.b(entitySpawnEvent);
        if (!entitySpawnEvent.isCancelled()) return;
        callbackInfo.cancel();
    }
}
