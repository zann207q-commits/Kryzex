package kryzex.mixin;

import kryzex.fx.TotemUndying;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4603.class})
public abstract class FLOATSTARTMixin {
    @Shadow
    private int field_59973;

    @Inject(method={"method_70939"}, at={@At(value="HEAD")})
    private void kryzex$floatStart(class_4587 class_45872, float f, class_11659 class_116592, CallbackInfo callbackInfo) {
        TotemUndying.floating(Math.max(0.0f, Math.min(1.0f, ((float)(40 - this.field_59973) + f) / 40.0f)));
    }

    @Inject(method={"method_70939"}, at={@At(value="RETURN")})
    private void kryzex$floatEnd(class_4587 class_45872, float f, class_11659 class_116592, CallbackInfo callbackInfo) {
        TotemUndying.floating(-1.0f);
    }
}
