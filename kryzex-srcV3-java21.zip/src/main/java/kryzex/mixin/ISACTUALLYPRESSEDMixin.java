package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.util.PressableKey;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={class_304.class})
public abstract class ISACTUALLYPRESSEDMixin
implements PressableKey {
    @Shadow
    private class_3675.class_306 field_1655;

    @Shadow
    public abstract void method_23481(boolean var1);

    @Override
    public boolean kryzex$isActuallyPressed() {
        return class_3675.method_15987((class_1041)KryzexClient.mc.method_22683(), (int)this.field_1655.method_1444());
    }

    @Override
    public void kryzex$resetPressed() {
        this.method_23481(this.kryzex$isActuallyPressed());
    }
}
