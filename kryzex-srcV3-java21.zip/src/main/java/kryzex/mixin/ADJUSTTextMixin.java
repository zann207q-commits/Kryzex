package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.modules.misc.NameProtect;
import net.minecraft.class_5223;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={class_5223.class})
public class ADJUSTTextMixin {
    @ModifyArg(at=@At(value="INVOKE", target="Lnet/minecraft/class_5223;method_27473(Ljava/lang/String;ILnet/minecraft/class_2583;Lnet/minecraft/class_2583;Lnet/minecraft/class_5224;)Z", ordinal=0), method={"method_27472(Ljava/lang/String;ILnet/minecraft/class_2583;Lnet/minecraft/class_5224;)Z"}, index=0)
    private static String adjustText(String string) {
        if (KryzexClient.INSTANCE != null && KryzexClient.INSTANCE.MODULE_MANAGER != null) {
            NameProtect nameProtect;
            return (nameProtect = (NameProtect)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(NameProtect.class)) != null && nameProtect.isEnabled() && string.contains(KryzexClient.mc.method_1548().method_1676()) ? string.replace(KryzexClient.mc.method_1548().method_1676(), nameProtect.S()) : string;
        }
        return string;
    }
}
