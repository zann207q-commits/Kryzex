package kryzex.mixin;

import kryzex.cinematic.Mistdata;
import kryzex.cinematic.HalloweenParticles;
import net.minecraft.class_12077;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4597;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9976.class})
public abstract class MistMixin {
    @Inject(method={"method_62320"}, at={@At(value="TAIL")})
    private void kryzex$mist(class_4597 class_45972, class_243 class_2432, class_12077 class_120772, CallbackInfo callbackInfo) {
        Mistdata.draw(class_310.method_1551().field_1773.method_19418());
        HalloweenParticles.render(class_310.method_1551().field_1773.method_19418());
    }
}
