package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.modules.misc.Freecam;
import kryzex.modules.misc.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(value={class_4184.class})
public class ALLOWFREELOOKTHROUGHWALLSMixin {
    @Shadow
    private boolean field_18719;
    @Unique
    private float tickDelta;

    @Unique
    private static Freecam kryzex$freecam() {
        try {
            if (KryzexClient.INSTANCE != null && KryzexClient.INSTANCE.MODULE_MANAGER != null) return (Freecam)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(Freecam.class);
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    @Unique
    private static Freelook kryzex$freelook() {
        try {
            if (KryzexClient.INSTANCE != null && KryzexClient.INSTANCE.MODULE_MANAGER != null) return (Freelook)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(Freelook.class);
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    @Inject(method={"method_19321"}, at={@At(value="HEAD")})
    private void onUpdateHead(class_1937 class_19372, class_1297 class_12972, boolean bl, boolean bl2, float f, CallbackInfo callbackInfo) {
        this.tickDelta = f;
        Freecam freecam = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freecam();
        if (freecam == null || !freecam.isEnabled()) return;
        freecam.T();
    }

    @Inject(method={"method_19321"}, at={@At(value="TAIL")})
    private void keepPlayerVisible(class_1937 class_19372, class_1297 class_12972, boolean bl, boolean bl2, float f, CallbackInfo callbackInfo) {
        Freecam freecam = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freecam();
        if (freecam == null || !freecam.isEnabled()) return;
        this.field_18719 = true;
    }

    @ModifyArgs(method={"method_19321"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_4184;method_19327(DDD)V"))
    private void update(Args args) {
        Freecam freecam = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freecam();
        if (freecam == null || !freecam.isEnabled()) return;
        args.set(0, (Object)freecam.F(this.tickDelta));
        args.set(1, (Object)freecam.t(this.tickDelta));
        args.set(2, (Object)freecam.n(this.tickDelta));
    }

    @ModifyArgs(method={"method_19321"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_4184;method_19325(FF)V"))
    private void onUpdateSetRotationArgs(Args args) {
        Freecam freecam = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freecam();
        if (freecam != null && freecam.isEnabled()) {
            args.set(0, (Object)Float.valueOf((float)freecam.A(this.tickDelta)));
            args.set(1, (Object)Float.valueOf((float)freecam.e(this.tickDelta)));
            return;
        }
        Freelook freelook = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freelook();
        if (freelook == null || !freelook.isEnabled()) return;
        args.set(0, (Object)Float.valueOf(freelook.o()));
        args.set(1, (Object)Float.valueOf(freelook.r()));
    }

    @ModifyArg(method={"method_19321"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_4184;method_19318(F)F"), index=0)
    private float useFreelookDistance(float f) {
        Freelook freelook = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freelook();
        return freelook != null && freelook.isEnabled() ? freelook.W() : f;
    }

    @Inject(method={"method_19318"}, at={@At(value="HEAD")}, cancellable=true)
    private void allowFreelookThroughWalls(float f, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        Freelook freelook = ALLOWFREELOOKTHROUGHWALLSMixin.kryzex$freelook();
        if (freelook == null || !freelook.isEnabled() || !freelook.X()) return;
        callbackInfoReturnable.setReturnValue(Float.valueOf(f));
    }
}
