package kryzex.mixin;

import kryzex.modules.render.j.Model;
import kryzex.modules.render.j.CharacterHolder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_10055.class})
public abstract class SetCharacterMixin
implements CharacterHolder {
    @Unique
    private Model kryzex$character;
    @Unique
    private float kryzex$seat;

    @Override
    public Model kryzex$character() {
        return this.kryzex$character;
    }

    @Override
    public void kryzex$setCharacter(Model model) {
        this.kryzex$character = model;
    }

    @Override
    public float kryzex$seat() {
        return this.kryzex$seat;
    }

    @Override
    public void kryzex$setSeat(float f) {
        this.kryzex$seat = f;
    }
}
