package kryzex.mixin;

import net.minecraft.class_2824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_2824.class})
public interface GetEntityIDMixin {
    @Accessor(value="field_12870")
    public int kryzex$getEntityId();
}
