package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.HudRenderEvent;
import kryzex.modules.donut.OGScoreboard;
import kryzex.util.InverseProjectionScratch;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public class HIDEVANILLASidebarMixin {
    @Inject(method={"method_1753"}, at={@At(value="HEAD")})
    private void onRenderHud(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        InverseProjectionScratch.setContext(class_3322);
        EventBus.b(new HudRenderEvent(class_3322, class_97792.method_60637(true)));
    }

    @Inject(method={"method_55803(Lnet/minecraft/class_332;Lnet/minecraft/class_9779;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hideVanillaSidebar(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        if (!OGScoreboard.j()) return;
        callbackInfo.cancel();
    }
}
