package kryzex.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import kryzex.mixin.SHOULDRenderBlockOUTLINEMixin;
import kryzex.module.MacroEventBus;
import kryzex.util.Iris;
import kryzex.util.ViewProjection;
import net.minecraft.class_12180;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import net.minecraft.class_761;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public abstract class EXTOverlayAFTERSHADERPACKMixin {
    @ModifyArg(method={"method_22710"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_863;method_23099(Lnet/minecraft/class_4604;DDDF)V"), index=0)
    private class_4604 kryzex$extRender3D(class_4604 class_46042, @Local(argsOnly=true, ordinal=0) Matrix4f matrix4f, @Local(argsOnly=true, ordinal=1) Matrix4f matrix4f2) {
        float f = class_310.method_1551().method_61966().method_60637(false);
        ViewProjection.beginFrame((Matrix4fc)matrix4f, (Matrix4fc)matrix4f2);
        try (class_12180.class_12181 class_121812 = Iris.capture();){
            MacroEventBus.render3D(f, class_46042);
            return class_46042;
        }
    }

    @Inject(method={"method_22710"}, at={@At(value="TAIL")})
    private void kryzex$extOverlayAfterShaderPack(CallbackInfo callbackInfo, @Local(argsOnly=true) GpuBufferSlice gpuBufferSlice, @Local(argsOnly=true) class_4184 class_41842, @Local(argsOnly=true, ordinal=0) Matrix4f matrix4f, @Local(argsOnly=true, ordinal=1) Matrix4f matrix4f2) {
        if (!Iris.pending()) return;
        Iris.render(class_41842, matrix4f, matrix4f2, gpuBufferSlice, EXTOverlayAFTERSHADERPACKMixin.kryzex$onTopFog(gpuBufferSlice, class_41842));
    }

    @Unique
    private static GpuBufferSlice kryzex$onTopFog(GpuBufferSlice gpuBufferSlice, class_4184 class_41842) {
        return class_41842.method_19334() == class_5636.field_27888 ? gpuBufferSlice : ((SHOULDRenderBlockOUTLINEMixin)class_310.method_1551().field_1773).kryzex$getFogRenderer().method_71109(class_758.class_4596.field_60101);
    }
}
