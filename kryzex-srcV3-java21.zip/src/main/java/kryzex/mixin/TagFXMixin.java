package kryzex.mixin;

import kryzex.fx.TotemUndying;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_10442.class})
public abstract class TagFXMixin {
    @Inject(method={"method_65598"}, at={@At(value="TAIL")})
    private void kryzex$tagFx(class_10444 class_104442, class_1799 class_17992, class_811 class_8112, class_1937 class_19372, class_11566 class_115662, int n, CallbackInfo callbackInfo) {
        try {
            TotemUndying.tag(class_104442, class_17992, class_8112);
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: custom item tagging failed: " + String.valueOf(throwable));
        }
    }
}
