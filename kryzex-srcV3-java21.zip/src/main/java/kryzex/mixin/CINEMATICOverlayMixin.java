package kryzex.mixin;

import kryzex.cinematic.BarsWanted;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class CINEMATICOverlayMixin {
    @Inject(method={"method_1753"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$cinematicHud(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        if (!BarsWanted.hideHud()) return;
        BarsWanted.render(class_3322);
        callbackInfo.cancel();
    }

    @Inject(method={"method_1753"}, at={@At(value="TAIL")})
    private void kryzex$cinematicOverlay(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        BarsWanted.render(class_3322);
    }
}
