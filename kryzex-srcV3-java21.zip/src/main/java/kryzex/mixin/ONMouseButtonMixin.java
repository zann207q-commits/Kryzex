package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.MouseButtonEvent;
import kryzex.event.MouseScrollEvent;
import net.minecraft.class_11910;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_312.class})
public abstract class ONMouseButtonMixin {
    @Inject(method={"method_1601"}, at={@At(value="HEAD")}, cancellable=true)
    private void onMouseButton(long l, class_11910 class_119102, int n, CallbackInfo callbackInfo) {
        int n2 = class_119102.comp_4801();
        if (n2 == -1) return;
        MouseButtonEvent mouseButtonEvent = new MouseButtonEvent(n2, l, n);
        EventBus.b(mouseButtonEvent);
        if (!mouseButtonEvent.isCancelled()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_1598"}, at={@At(value="HEAD")}, cancellable=true)
    private void onMouseScroll(long l, double d, double d2, CallbackInfo callbackInfo) {
        MouseScrollEvent mouseScrollEvent = new MouseScrollEvent(d2);
        EventBus.b(mouseScrollEvent);
        if (!mouseScrollEvent.isCancelled()) return;
        callbackInfo.cancel();
    }
}
