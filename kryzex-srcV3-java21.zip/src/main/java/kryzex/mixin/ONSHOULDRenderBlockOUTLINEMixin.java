package kryzex.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import kryzex.client.KryzexClient;
import kryzex.config.EventBus;
import kryzex.event.WorldRenderEvent;
import kryzex.modules.misc.Freecam;
import kryzex.util.InverseProjectionScratch;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_757.class})
public abstract class ONSHOULDRenderBlockOUTLINEMixin {
    @Shadow
    @Final
    private class_4184 field_18765;

    @Shadow
    protected abstract float method_3196(class_4184 var1, float var2, boolean var3);

    @Shadow
    public abstract Matrix4f method_22973(float var1);

    @Unique
    private static Freecam kryzex$freecam() {
        try {
            if (KryzexClient.INSTANCE != null && KryzexClient.INSTANCE.getModuleManager() != null) return (Freecam)KryzexClient.INSTANCE.getModuleManager().getModuleByClass(Freecam.class);
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    @Inject(method={"method_3188"}, at={@At(value="INVOKE_STRING", target="Lnet/minecraft/class_3695;method_15405(Ljava/lang/String;)V", args={"ldc=hand"})})
    private void onWorldRender(class_9779 class_97792, CallbackInfo callbackInfo, @Local(ordinal=0) Matrix4f matrix4f, @Local(ordinal=1) Matrix4f matrix4f2) {
        InverseProjectionScratch.updateScreenCenter(matrix4f, matrix4f2);
        EventBus.b(new WorldRenderEvent(new class_4587(), new Matrix4f((Matrix4fc)matrix4f), class_97792.method_60637(true)));
    }

    @Inject(method={"method_3202"}, at={@At(value="HEAD")}, cancellable=true)
    private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        Freecam freecam = ONSHOULDRenderBlockOUTLINEMixin.kryzex$freecam();
        if (freecam == null || !freecam.isEnabled()) return;
        callbackInfoReturnable.setReturnValue(false);
    }
}
