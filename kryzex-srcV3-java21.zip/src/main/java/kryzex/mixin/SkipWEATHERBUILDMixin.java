package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_12077;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9976.class}, remap=false)
public abstract class SkipWEATHERBUILDMixin {
    @Inject(method={"method_62315"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipWeatherBuild(class_1937 class_19372, int n, float f, class_243 class_2432, class_12077 class_120772, CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.enabled(4096)) return;
        class_120772.method_74938();
        callbackInfo.cancel();
    }

    @Inject(method={"method_62320"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipWeatherDraw(CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.enabled(4096)) return;
        callbackInfo.cancel();
    }
}
