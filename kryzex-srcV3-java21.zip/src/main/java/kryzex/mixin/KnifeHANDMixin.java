package kryzex.mixin;

import kryzex.weapon.KnifeManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_759.class})
public abstract class KnifeHANDMixin {
    @Inject(method={"method_3228"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$knifeHand(class_742 class_7422, float f, float f2, class_1268 class_12682, float f3, class_1799 class_17992, float f4, class_4587 class_45872, class_11659 class_116592, int n, CallbackInfo callbackInfo) {
        if (class_12682 != class_1268.field_5808) {
            return;
        }
        try {
            if (!KnifeManager.renderMainHand(class_7422, f, f3, class_17992, f4, class_45872, n)) return;
            callbackInfo.cancel();
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: knife viewmodel failed: " + String.valueOf(throwable));
        }
    }
}
