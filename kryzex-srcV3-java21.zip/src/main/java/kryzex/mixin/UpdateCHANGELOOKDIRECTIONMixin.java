package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.config.EventBus;
import kryzex.event.GetPoseEvent;
import kryzex.event.LookEvent;
import kryzex.modules.misc.Freecam;
import kryzex.modules.misc.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public class UpdateCHANGELOOKDIRECTIONMixin {
    @Inject(method={"method_5871"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSendMovementPackets(CallbackInfoReturnable<Float> callbackInfoReturnable) {
        if (!EventBus.hasActiveListener(LookEvent.class)) return;
        EventBus.b(new LookEvent((class_1297)class_1297.class.cast(this), callbackInfoReturnable));
    }

    @Inject(method={"method_18376"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetPose(CallbackInfoReturnable<class_4050> callbackInfoReturnable) {
        if (!EventBus.hasActiveListener(GetPoseEvent.class)) return;
        EventBus.b(new GetPoseEvent((class_1297)class_1297.class.cast(this), callbackInfoReturnable));
    }

    @Inject(method={"method_5872"}, at={@At(value="HEAD")}, cancellable=true)
    private void updateChangeLookDirection(double d, double d2, CallbackInfo callbackInfo) {
        try {
            if (KryzexClient.mc == null || KryzexClient.mc.field_1724 == null) return;
            if (class_1297.class.cast(this) != KryzexClient.mc.field_1724) return;
            if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.MODULE_MANAGER == null) return;
            Freecam freecam = (Freecam)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(Freecam.class);
            if (freecam != null && freecam.isEnabled()) {
                freecam.k(d * 0.15, d2 * 0.15);
                callbackInfo.cancel();
                return;
            }
            Freelook freelook = (Freelook)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(Freelook.class);
            if (freelook == null || !freelook.isEnabled()) return;
            freelook.R(d, d2);
            callbackInfo.cancel();
        }
        catch (Throwable throwable) {

        }
    }
}
