package kryzex.mixin;

import net.minecraft.class_10444;
import net.minecraft.class_804;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_10444.class_10446.class})
public interface TRANSFORMMixin {
    @Accessor(value="field_56967", remap=false)
    public class_804 kryzex$transform();

    @Accessor(value="field_55348", remap=false)
    public class_10444.class_10445 kryzex$glint();
}
