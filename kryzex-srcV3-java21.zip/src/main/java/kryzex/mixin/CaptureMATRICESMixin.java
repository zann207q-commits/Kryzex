package kryzex.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import kryzex.cinematic.Skydata;
import kryzex.cinematic.WitchActor;
import net.minecraft.class_11658;
import net.minecraft.class_11659;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public abstract class CaptureMATRICESMixin {
    @Inject(method={"method_22710"}, at={@At(value="HEAD")})
    private void kryzex$captureMatrices(class_9922 class_99222, class_9779 class_97792, boolean bl, class_4184 class_41842, Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3, GpuBufferSlice gpuBufferSlice, Vector4f vector4f, boolean bl2, CallbackInfo callbackInfo) {
        Skydata.capture(matrix4f, matrix4f2);
    }

    @Inject(method={"method_72916"}, at={@At(value="TAIL")})
    private void kryzex$witch(class_4587 class_45872, class_11658 class_116582, class_11659 class_116592, CallbackInfo callbackInfo) {
        if (!WitchActor.running()) return;
        WitchActor.render(class_310.method_1551().field_1773.method_19418().method_71156());
    }
}
