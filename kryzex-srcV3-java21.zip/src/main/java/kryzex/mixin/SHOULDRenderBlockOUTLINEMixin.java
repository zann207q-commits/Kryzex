package kryzex.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_757.class})
public interface SHOULDRenderBlockOUTLINEMixin {
    @Invoker(value="method_3196")
    public float kryzex$getFov(class_4184 var1, float var2, boolean var3);

    @Accessor(value="field_60793")
    public class_758 kryzex$getFogRenderer();

    @Invoker(value="method_3202")
    public boolean kryzex$shouldRenderBlockOutline();
}
