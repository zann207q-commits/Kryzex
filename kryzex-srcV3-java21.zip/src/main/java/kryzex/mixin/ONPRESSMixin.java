package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.KeyEvent;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_309.class})
public class ONPRESSMixin {
    @Inject(method={"method_1466"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPress(long l, int n, class_11908 class_119082, CallbackInfo callbackInfo) {
        int n2 = class_119082.comp_4795();
        if (n2 == -1) return;
        KeyEvent keyEvent = new KeyEvent(n2, l, n);
        EventBus.b(keyEvent);
        if (!keyEvent.isCancelled()) return;
        callbackInfo.cancel();
    }
}
