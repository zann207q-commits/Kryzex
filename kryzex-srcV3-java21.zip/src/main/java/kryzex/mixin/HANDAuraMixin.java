package kryzex.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import kryzex.modules.render.HandAura;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11684;
import net.minecraft.class_310;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_759.class})
public abstract class HANDAuraMixin {

    @WrapOperation(method={"method_22976"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_11684;method_73002()V")})
    private void kryzex$handAura(class_11684 class_116842, Operation<Void> operation) {
        if (HandAura.active != null && HandAura.C()) {
            boolean bl = false;
            try {
                operation.call(new Object[]{class_116842});
                class_310.method_1551().method_22940().method_23000().method_22993();
                bl = true;
                return;
            }
            finally {
                HandAura.F(bl);
            }
        } else {
            operation.call(new Object[]{class_116842});
        }
    }
}
