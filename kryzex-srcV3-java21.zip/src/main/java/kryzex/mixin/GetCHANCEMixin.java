package kryzex.mixin;

import net.minecraft.class_6799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_6799.class})
public interface GetCHANCEMixin {
    @Accessor(value="field_35753")
    public int getChance();
}
