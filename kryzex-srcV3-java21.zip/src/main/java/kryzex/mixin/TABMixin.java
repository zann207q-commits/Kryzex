package kryzex.mixin;

import kryzex.gui.BaseRenderer;
import kryzex.gui.KryzexClient;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_8209;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_8209.class})
public abstract class TABMixin {
    @Inject(method={"method_48579"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$tab(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) {
            return;
        }
        class_8209 class_82092 = (class_8209)(Object)this;
        if (!KryzexClient.button(class_3322, (class_339)class_82092)) return;
        if (class_82092.method_49611()) {
            BaseRenderer baseRenderer = KryzexClient.paint(class_3322);
            baseRenderer.round(class_82092.method_46426() + 7, class_82092.method_46427() + class_82092.method_25364() - 2, Math.max(1, class_82092.method_25368() - 14), 1.5f, 0.75f, -588648449);
        }
        callbackInfo.cancel();
    }
}
