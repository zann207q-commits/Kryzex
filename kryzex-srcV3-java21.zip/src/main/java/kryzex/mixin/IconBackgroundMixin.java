package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4264;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4264.class})
public abstract class IconBackgroundMixin {
    @Inject(method={"method_48579"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$button(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!KryzexClient.button(class_3322, (class_339)(Object)this)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_75794"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$iconBackground(class_332 class_3322, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        class_339 class_3392 = (class_339)(Object)this;
        KryzexClient.glass(KryzexClient.paint(class_3322), class_3392.method_46426(), class_3392.method_46427(), class_3392.method_25368(), class_3392.method_25364(), KryzexClient.hover(class_3392, class_3392.field_22763 && class_3392.method_25367()), false);
        callbackInfo.cancel();
    }
}
