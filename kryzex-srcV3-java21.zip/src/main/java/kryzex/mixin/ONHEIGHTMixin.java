package kryzex.mixin;

import net.minecraft.class_2794;
import net.minecraft.class_5868;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_5868.class})
public abstract class ONHEIGHTMixin {
    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_2794;method_33730()I"))
    private int onMinY(class_2794 class_27942) {
        if (class_27942 == null) {
            return -9999999;
        }
        int n = class_27942.method_33730();
        return n;
    }

    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_2794;method_12104()I"))
    private int onHeight(class_2794 class_27942) {
        if (class_27942 == null) {
            return 100000000;
        }
        int n = class_27942.method_12104();
        return n;
    }
}
