package kryzex.mixin;

import kryzex.gui.KryzexClient;
import kryzex.gui.LoadingScreenLogo;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_424;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_8671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_437.class})
public abstract class BackgroundMixin {
    @Inject(method={"method_47413"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$begin(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        class_437 class_4372 = (class_437)(Object)this;
        if ((class_4372 instanceof class_424 || class_4372 instanceof class_8671) && KryzexClient.themed(class_4372)) {
            LoadingScreenLogo.screen(class_3322, -1.0f, class_4372.method_25440().getString());
            class_3322.method_71048();
            int n3 = LoadingScreenLogo.buttonTop(class_4372.field_22790);
            for (class_364 class_3642 : class_4372.method_25396()) {
                if (!(class_3642 instanceof class_4264)) continue;
                class_4264 class_42642 = (class_4264)class_3642;
                class_42642.method_46419(n3);
                class_42642.method_25394(class_3322, n, n2, f);
            }
            callbackInfo.cancel();
            return;
        } else {
            if (!KryzexClient.backdrop() || KryzexClient.loading(class_4372)) return;
            KryzexClient.background(class_3322);
        }
    }

    @Inject(method={"method_25420"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$background(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!this.kryzex$replaced()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_57734", "method_57735", "method_52752"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$plain(class_332 class_3322, CallbackInfo callbackInfo) {
        if (!this.kryzex$replaced()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_57728"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$panorama(class_332 class_3322, float f, CallbackInfo callbackInfo) {
        if (!this.kryzex$replaced()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_57736"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$rect(class_332 class_3322, int n, int n2, int n3, int n4, CallbackInfo callbackInfo) {
        if (!this.kryzex$replaced()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_57737"}, at={@At(value="HEAD")}, cancellable=true)
    private static void kryzex$texture(class_332 class_3322, class_2960 class_29602, int n, int n2, float f, float f2, int n3, int n4, CallbackInfo callbackInfo) {
        if (!KryzexClient.backdrop()) return;
        callbackInfo.cancel();
    }

    @Unique
    private boolean kryzex$replaced() {
        if (KryzexClient.backdrop()) return true;
        if (!KryzexClient.active()) return false;
        if (!KryzexClient.loading((class_437)(Object)this)) return false;
        return true;
    }
}
