package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_350;
import net.minecraft.class_8021;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_350.class})
public abstract class SEPARATORSMixin {
    @Inject(method={"method_57715"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$list(class_332 class_3322, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        KryzexClient.list(class_3322, (class_339)(Object)this);
        callbackInfo.cancel();
    }

    @Inject(method={"method_57713"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$separators(class_332 class_3322, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_44398"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$selection(class_332 class_3322, @Coerce Object object, int n, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        KryzexClient.selection(class_3322, (class_8021)object);
        callbackInfo.cancel();
    }
}
