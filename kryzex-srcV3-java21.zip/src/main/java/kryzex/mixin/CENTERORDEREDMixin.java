package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_332.class})
public abstract class CENTERORDEREDMixin {
    @Inject(method={"method_51433"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$string(class_327 class_3272, String string, int n, int n2, int n3, boolean bl, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(string)) return;
        KryzexClient.text((class_332)(Object)this, string, n, n2, n3, false);
        callbackInfo.cancel();
    }

    @Inject(method={"method_51439"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$text(class_327 class_3272, class_2561 class_25612, int n, int n2, int n3, boolean bl, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(class_25612)) return;
        KryzexClient.text((class_332)(Object)this, class_25612.method_30937(), n, n2, n3, false);
        callbackInfo.cancel();
    }

    @Inject(method={"method_51430"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$ordered(class_327 class_3272, class_5481 class_54812, int n, int n2, int n3, boolean bl, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(class_54812)) return;
        KryzexClient.text((class_332)(Object)this, class_54812, n, n2, n3, false);
        callbackInfo.cancel();
    }

    @Inject(method={"method_25300"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$centerString(class_327 class_3272, String string, int n, int n2, int n3, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(string)) return;
        KryzexClient.text((class_332)(Object)this, string, n, n2, n3, true);
        callbackInfo.cancel();
    }

    @Inject(method={"method_27534"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$centerText(class_327 class_3272, class_2561 class_25612, int n, int n2, int n3, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(class_25612)) return;
        KryzexClient.text((class_332)(Object)this, class_25612.getString(), n, n2, n3, true);
        callbackInfo.cancel();
    }

    @Inject(method={"method_35719"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$centerOrdered(class_327 class_3272, class_5481 class_54812, int n, int n2, int n3, CallbackInfo callbackInfo) {
        if (!KryzexClient.typography() || !KryzexClient.supports(class_54812)) return;
        KryzexClient.text((class_332)(Object)this, class_54812, n, n2, n3, true);
        callbackInfo.cancel();
    }
}
