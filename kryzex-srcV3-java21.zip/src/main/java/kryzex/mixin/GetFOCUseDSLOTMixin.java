package kryzex.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_465.class})
public interface GetFOCUseDSLOTMixin {
    @Accessor(value="field_2787")
    public class_1735 getFocusedSlot();
}
