package kryzex.mixin;

import kryzex.cinematic.Skydata;
import kryzex.cinematic.UnderValid;
import net.minecraft.class_12076;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9975.class})
public abstract class HALLOWEENSKYMixin {
    @Inject(method={"method_62302"}, at={@At(value="TAIL")})
    private void kryzex$halloweenSky(int n, CallbackInfo callbackInfo) {
        Skydata.draw();
    }

    @Inject(method={"method_74926"}, at={@At(value="TAIL")})
    private void kryzex$moon(class_638 class_6382, float f, class_4184 class_41842, class_12076 class_120762, CallbackInfo callbackInfo) {
        UnderValid.moonAngle(class_120762.field_64465);
    }
}
