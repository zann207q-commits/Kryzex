package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public abstract class MenuSMixin {
    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    private void kryzex$menus(CallbackInfo callbackInfo) {
        KryzexClient.tick((class_310)(Object)this);
    }
}
