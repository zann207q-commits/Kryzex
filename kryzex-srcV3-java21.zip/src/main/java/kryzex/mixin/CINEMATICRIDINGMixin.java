package kryzex.mixin;

import kryzex.cinematic.InputLocked;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(value={class_4184.class})
public abstract class CINEMATICRIDINGMixin {
    @ModifyArgs(method={"method_19321"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_4184;method_19325(FF)V", ordinal=0))
    private void kryzex$cinematicRiding(Args args) {
        CINEMATICRIDINGMixin.kryzex$apply(args);
    }

    @ModifyArgs(method={"method_19321"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_4184;method_19325(FF)V", ordinal=1))
    private void kryzex$cinematic(Args args) {
        CINEMATICRIDINGMixin.kryzex$apply(args);
    }

    @Unique
    private static void kryzex$apply(Args args) {
        if (!InputLocked.active()) return;
        float f = ((Float)args.get(0)).floatValue();
        float f2 = ((Float)args.get(1)).floatValue();
        args.set(0, (Object)Float.valueOf(InputLocked.yaw(f)));
        args.set(1, (Object)Float.valueOf(InputLocked.pitch(f2)));
    }
}
