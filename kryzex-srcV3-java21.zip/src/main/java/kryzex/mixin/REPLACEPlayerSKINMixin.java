package kryzex.mixin;

import com.mojang.authlib.GameProfile;
import kryzex.client.KryzexClient;
import kryzex.modules.misc.SkinProtect;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_742.class})
public abstract class REPLACEPlayerSKINMixin {
    @Inject(method={"method_52814"}, at={@At(value="RETURN")}, cancellable=true, remap=false)
    private void kryzex$replacePlayerSkin(CallbackInfoReturnable<class_8685> callbackInfoReturnable) {
        if (KryzexClient.INSTANCE == null || KryzexClient.INSTANCE.MODULE_MANAGER == null) {
            return;
        }
        SkinProtect skinProtect = (SkinProtect)KryzexClient.INSTANCE.MODULE_MANAGER.getModuleByClass(SkinProtect.class);
        if (skinProtect == null || !skinProtect.isEnabled()) {
            return;
        }
        class_742 class_7422 = (class_742)(Object)this;
        GameProfile gameProfile = class_7422.method_7334();
        callbackInfoReturnable.setReturnValue(skinProtect.R(gameProfile.id(), gameProfile.name(), (class_8685)callbackInfoReturnable.getReturnValue()));
    }
}
