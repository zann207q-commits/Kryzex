package kryzex.mixin;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import kryzex.module.MacroEventBus;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2535.class})
public abstract class EXTPacketReceiveMixin {
    @Shadow
    public abstract class_2598 method_36121();

    @Inject(method={"method_10770"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$extPacketReceive(ChannelHandlerContext channelHandlerContext, class_2596<?> class_25962, CallbackInfo callbackInfo) {
        if (this.method_36121() != class_2598.field_11942 || !MacroEventBus.packetReceive(class_25962)) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_52906"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$extPacketSend(class_2596<?> class_25962, ChannelFutureListener channelFutureListener, boolean bl, CallbackInfo callbackInfo) {
        if (this.method_36121() != class_2598.field_11942 || !MacroEventBus.packetSend(class_25962)) return;
        callbackInfo.cancel();
    }
}
