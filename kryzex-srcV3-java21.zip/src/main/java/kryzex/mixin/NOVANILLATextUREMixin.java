package kryzex.mixin;

import kryzex.gui.KryzexClient;
import net.minecraft.class_332;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_342.class})
public abstract class NOVANILLATextUREMixin {
    @Inject(method={"method_48579"}, at={@At(value="HEAD")})
    private void kryzex$field(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) {
            return;
        }
        class_342 class_3422 = (class_342)(Object)this;
        KryzexClient.editing(true);
        if (!class_3422.method_1851()) return;
        KryzexClient.glass(KryzexClient.paint(class_3322), class_3422.method_46426(), class_3422.method_46427(), class_3422.method_25368(), class_3422.method_25364(), KryzexClient.hover(class_3422, class_3422.method_25370() || class_3422.method_49606()), class_3422.method_25370());
    }

    @Redirect(method={"method_48579"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_342;method_1851()Z", ordinal=0))
    private boolean kryzex$noVanillaTexture(class_342 class_3422) {
        if (KryzexClient.active()) return false;
        if (!class_3422.method_1851()) return false;
        return true;
    }

    @Inject(method={"method_48579"}, at={@At(value="RETURN")})
    private void kryzex$restore(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        KryzexClient.editing(false);
    }
}
