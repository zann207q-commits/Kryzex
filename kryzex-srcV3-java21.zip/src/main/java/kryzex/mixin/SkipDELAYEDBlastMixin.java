package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1144.class}, remap=false)
public abstract class SkipDELAYEDBlastMixin {
    @Inject(method={"method_4873"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipBlastSound(class_1113 class_11132, CallbackInfoReturnable<class_1140.class_11518> callbackInfoReturnable) {
        if (!EntityGenericExplode.hideSound(class_11132)) return;
        callbackInfoReturnable.setReturnValue(class_1140.class_11518.field_60956);
    }

    @Inject(method={"method_4872"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipDelayedBlast(class_1113 class_11132, int n, CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.hideSound(class_11132)) return;
        callbackInfo.cancel();
    }
}
