package kryzex.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import kryzex.modules.render.j.Character3D;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_1921;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_922.class})
public abstract class HIDELAYERSUNDERCharacterMixin {
    @Inject(method={"method_24302"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$hideModelUnderCharacter(class_10042 class_100422, boolean bl, boolean bl2, boolean bl3, CallbackInfoReturnable<class_1921> callbackInfoReturnable) {
        if (!Character3D.M((class_10017)class_100422)) return;
        callbackInfoReturnable.setReturnValue(null);
    }

    @WrapOperation(method={"method_4054"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_3887;method_4199(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_10017;FF)V")})
    private void kryzex$hideLayersUnderCharacter(class_3887<?, ?> class_38872, class_4587 class_45872, class_11659 class_116592, int n, class_10017 class_100172, float f, float f2, Operation<Void> operation) {
        if (Character3D.a(class_38872, class_100172)) return;
        operation.call(new Object[]{class_38872, class_45872, class_116592, n, class_100172, Float.valueOf(f), Float.valueOf(0.0f)});
    }
}
