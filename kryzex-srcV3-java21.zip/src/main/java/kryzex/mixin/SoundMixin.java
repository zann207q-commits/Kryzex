package kryzex.mixin;

import kryzex.gui.GuiAudio;
import kryzex.gui.GuiSoundType;
import kryzex.gui.KryzexClient;
import net.minecraft.class_1144;
import net.minecraft.class_339;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_339.class})
public abstract class SoundMixin {
    @Inject(method={"method_25354"}, at={@At(value="HEAD")}, cancellable=true)
    private void kryzex$sound(class_1144 class_11442, CallbackInfo callbackInfo) {
        if (!KryzexClient.active()) return;
        GuiAudio.play(GuiSoundType.CONFIRM);
        callbackInfo.cancel();
    }
}
