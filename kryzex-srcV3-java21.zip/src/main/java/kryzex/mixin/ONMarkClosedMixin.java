package kryzex.mixin;

import kryzex.config.EventBus;
import kryzex.event.MarkClosedEvent;
import net.minecraft.class_2338;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_852.class})
public abstract class ONMarkClosedMixin {
    @Inject(method={"method_3682"}, at={@At(value="HEAD")}, cancellable=true)
    private void onMarkClosed(class_2338 class_23382, CallbackInfo callbackInfo) {
        if (!EventBus.hasActiveListener(MarkClosedEvent.class)) {
            return;
        }
        MarkClosedEvent markClosedEvent = new MarkClosedEvent();
        EventBus.b(markClosedEvent);
        if (!markClosedEvent.isCancelled()) return;
        callbackInfo.cancel();
    }
}
