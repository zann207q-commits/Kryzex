package kryzex.mixin;

import net.minecraft.class_1917;
import net.minecraft.class_1952;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_1917.class})
public interface GetSpawnEntryMixin {
    @Accessor(value="field_9155")
    public class_1952 getSpawnEntry();
}
