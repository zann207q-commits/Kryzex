package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_9955;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9955.class}, remap=false)
public abstract class SkipCLOUDSMixin {
    @Inject(method={"method_62168"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipClouds(CallbackInfo callbackInfo) {
        if (!EntityGenericExplode.enabled(8192)) return;
        callbackInfo.cancel();
    }
}
