package kryzex.mixin;

import kryzex.util.EntityGenericExplode;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_4970.class_4971.class}, remap=false)
public abstract class SkipTNTMESHMixin {
    @Inject(method={"method_26217"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void kryzex$skipTntMesh(CallbackInfoReturnable<class_2464> callbackInfoReturnable) {
        if (!EntityGenericExplode.hideBlock((class_2680)(Object)this)) return;
        callbackInfoReturnable.setReturnValue(class_2464.field_11455);
    }
}
