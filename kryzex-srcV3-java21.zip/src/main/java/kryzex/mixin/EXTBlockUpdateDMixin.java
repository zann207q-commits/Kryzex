package kryzex.mixin;

import kryzex.module.MacroEventBus;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_638.class})
public abstract class EXTBlockUpdateDMixin {
    @Inject(method={"method_8413"}, at={@At(value="HEAD")})
    private void kryzex$extBlockUpdated(class_2338 class_23382, class_2680 class_26802, class_2680 class_26803, int n, CallbackInfo callbackInfo) {
        MacroEventBus.blockUpdate(class_23382, class_26802, class_26803);
    }
}
