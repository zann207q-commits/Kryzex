package kryzex.mixin;

import kryzex.gui.ClickGuiScreen;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_437.class})
public class DONTRenderBackgroundMixin {
    @Shadow
    @NotNull
    protected class_310 field_22787;

    @Inject(method={"method_25420"}, at={@At(value="HEAD")}, cancellable=true)
    private void dontRenderBackground(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (!(this.field_22787.field_1755 instanceof ClickGuiScreen)) return;
        callbackInfo.cancel();
    }
}
