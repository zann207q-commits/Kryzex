package kryzex.mixin;

import kryzex.client.KryzexClient;
import kryzex.config.EventBus;
import kryzex.event.AttackEvent;
import kryzex.event.BlockBreakingEvent;
import kryzex.event.ItemUseHeadEvent;
import kryzex.event.ItemUseReturnEvent;
import kryzex.event.ResolutionEvent;
import kryzex.event.ScreenOpenEvent;
import kryzex.event.TickEvent;
import kryzex.util.RemainingBeats;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_310.class})
public class ONResolutionCHANGEDMixin {
    @Shadow
    @Nullable
    public class_638 field_1687;
    @Shadow
    @Final
    private class_1041 field_1704;
    @Shadow
    private int field_1752;

    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    private void onTick(CallbackInfo callbackInfo) {
        RemainingBeats.tick((class_310)(Object)this);
        if (this.field_1687 == null) return;
        EventBus.b(new TickEvent());
    }

    @Inject(method={"method_15993"}, at={@At(value="HEAD")})
    private void onResolutionChanged(CallbackInfo callbackInfo) {
        EventBus.b(new ResolutionEvent(this.field_1704));
    }

    @Inject(method={"method_1583"}, at={@At(value="RETURN")}, cancellable=true)
    private void onItemUseReturn(CallbackInfo callbackInfo) {
        ItemUseReturnEvent itemUseReturnEvent = new ItemUseReturnEvent(this.field_1752);
        EventBus.b(itemUseReturnEvent);
        if (itemUseReturnEvent.isCancelled()) {
            callbackInfo.cancel();
        }
        this.field_1752 = itemUseReturnEvent.cooldown;
    }

    @Inject(method={"method_1583"}, at={@At(value="HEAD")}, cancellable=true)
    private void onItemUseHead(CallbackInfo callbackInfo) {
        ItemUseHeadEvent itemUseHeadEvent = new ItemUseHeadEvent(this.field_1752);
        EventBus.b(itemUseHeadEvent);
        if (itemUseHeadEvent.isCancelled()) {
            callbackInfo.cancel();
        }
        this.field_1752 = itemUseHeadEvent.cooldown;
    }

    @Inject(method={"method_1536"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttack(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        AttackEvent attackEvent = new AttackEvent();
        EventBus.b(attackEvent);
        if (!attackEvent.isCancelled()) return;
        callbackInfoReturnable.setReturnValue(false);
    }

    @Inject(method={"method_1590"}, at={@At(value="HEAD")}, cancellable=true)
    private void onBlockBreaking(boolean bl, CallbackInfo callbackInfo) {
        BlockBreakingEvent blockBreakingEvent = new BlockBreakingEvent();
        EventBus.b(blockBreakingEvent);
        if (!blockBreakingEvent.isCancelled()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_1507"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSetScreen(class_437 class_4372, CallbackInfo callbackInfo) {
        ScreenOpenEvent screenOpenEvent = new ScreenOpenEvent(class_4372);
        EventBus.b(screenOpenEvent);
        if (!screenOpenEvent.isCancelled()) return;
        callbackInfo.cancel();
    }

    @Inject(method={"method_1490"}, at={@At(value="HEAD")})
    private void onClose(CallbackInfo callbackInfo) {
        KryzexClient.INSTANCE.getSettingsManager().shutdown();
    }
}
