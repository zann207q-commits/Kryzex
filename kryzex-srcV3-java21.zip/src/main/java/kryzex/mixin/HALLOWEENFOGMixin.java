package kryzex.mixin;

import kryzex.cinematic.UnderValid;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import org.joml.Vector4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(value={class_758.class})
public abstract class HALLOWEENFOGMixin {
    @ModifyArgs(method={"method_3211"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_758;method_71110(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"))
    private void kryzex$halloweenFog(Args args, class_4184 class_41842, int n, class_9779 class_97792, float f, class_638 class_6382) {
        if (UnderValid.fogAmount() <= 0.0f || class_41842.method_19334() != class_5636.field_27888) {
            return;
        }
        class_1297 class_12972 = class_41842.method_19331();
        if (class_12972 instanceof class_1309) {
            class_1309 class_13092 = (class_1309)class_12972;
            if (class_13092.method_6059(class_1294.field_5919) || class_13092.method_6059(class_1294.field_38092)) {
                return;
            }
        }
        float[] object = new float[]{((Float)args.get(3)).floatValue(), ((Float)args.get(4)).floatValue(), ((Float)args.get(5)).floatValue(), ((Float)args.get(6)).floatValue(), ((Float)args.get(7)).floatValue(), ((Float)args.get(8)).floatValue()};
        Vector4f vector4f = new Vector4f((Vector4fc)(Vector4f)args.get(2));
        UnderValid.fog(object, vector4f);
        args.set(2, (Object)vector4f);
        for (int i = 0; i < 6; ++i) {
            args.set(3 + i, (Object)Float.valueOf(object[i]));
        }
    }
}
