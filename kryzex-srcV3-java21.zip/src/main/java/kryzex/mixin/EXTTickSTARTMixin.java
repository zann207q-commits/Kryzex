package kryzex.mixin;

import kryzex.module.MacroEventBus;
import kryzex.module.Phase;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public abstract class EXTTickSTARTMixin {
    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    private void kryzex$extTickStart(CallbackInfo callbackInfo) {
        MacroEventBus.tick(Phase.PRE);
    }

    @Inject(method={"method_1574"}, at={@At(value="RETURN")})
    private void kryzex$extTickEnd(CallbackInfo callbackInfo) {
        MacroEventBus.tick(Phase.POST);
    }
}
