package kryzex.mixin;

import java.util.concurrent.CompletableFuture;
import kryzex.modules.render.j.Listening;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_310.class})
public abstract class EXTRESOURCERELOADMixin {
    @Inject(method={"method_1521"}, at={@At(value="HEAD")})
    private void kryzex$extResourceReload(CallbackInfoReturnable<CompletableFuture<Void>> callbackInfoReturnable) {
        Listening.U();
    }
}
