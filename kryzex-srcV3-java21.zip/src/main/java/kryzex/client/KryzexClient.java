package kryzex.client;

import java.io.File;
import kryzex.config.EventBus;
import kryzex.config.SettingsManager;
import kryzex.gui.ClickGuiScreen;
import kryzex.module.ModuleManager;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class KryzexClient {
    public SettingsManager settingsManager;
    public ModuleManager MODULE_MANAGER;
    public EventBus EVENT_BUS;
    public static class_310 mc;
    public String version;
    public static KryzexClient INSTANCE;
    public boolean shouldPreventClose;
    public ClickGuiScreen GUI;
    public class_437 screen;
    public long modified;
    public File jar;

    public KryzexClient() {
        try {
            INSTANCE = this;
            this.version = " b1.3";
            this.screen = null;
            this.EVENT_BUS = new EventBus();
            this.MODULE_MANAGER = new ModuleManager();
            this.GUI = new ClickGuiScreen();
            this.settingsManager = new SettingsManager();
            this.getSettingsManager().loadProfile();
            this.jar = new File(KryzexClient.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            this.modified = this.jar.lastModified();
            this.shouldPreventClose = false;
            mc = class_310.method_1551();
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace(System.err);
        }
    }

    public SettingsManager getSettingsManager() {
        return this.settingsManager;
    }

    public ModuleManager getModuleManager() {
        return this.MODULE_MANAGER;
    }

    public EventBus getEventBus() {
        return this.EVENT_BUS;
    }

    public void resetModifiedDate() {
        this.jar.setLastModified(this.modified);
    }
}
