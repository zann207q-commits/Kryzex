package kryzex.client;

import kryzex.client.KryzexClient;
import net.fabricmc.api.ModInitializer;

public final class KryzexMod
implements ModInitializer {
    public void onInitialize() {
        new KryzexClient();
    }
}
