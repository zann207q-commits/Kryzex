package kryzex.cinematic;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import javax.imageio.ImageIO;
import kryzex.cinematic.BindRotInv;
import kryzex.cinematic.DissolveScale;
import kryzex.cinematic.NotWitchModel;
import kryzex.cinematic.HalloweenShaders;
import kryzex.cinematic.VertexCount;
import net.minecraft.class_1011;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.BufferUtils;

public final class Projection {
    private static final int MAX_JOINTS = 80;
    private static final int HEADER = 272;
    private static final int UBO_SIZE = 5392;
    private static final VertexFormat FORMAT = class_290.field_1580;
    public static final RenderPipeline COLOR = Projection.base().withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/hw_witch")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(true).build();
    public static final RenderPipeline DEPTH = Projection.base().withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/hw_witch_depth")).withColorWrite(false).withDepthWrite(true).build();
    private static GpuBuffer witchVbo;
    private static GpuBuffer witchIbo;
    private static GpuBuffer broomVbo;
    private static GpuBuffer broomIbo;
    private static int witchIndices;
    private static int broomIndices;
    private static GpuTexture witchTex;
    private static GpuTexture emissiveTex;
    private static GpuTexture broomTex;
    private static GpuTexture blackTex;
    private static GpuTextureView witchView;
    private static GpuTextureView emissiveView;
    private static GpuTextureView broomView;
    private static GpuTextureView blackView;
    private static GpuBuffer witchUbo;
    private static GpuBuffer broomUbo;
    private static ByteBuffer scratch;
    private static boolean failed;

    private Projection() {
    }

    private static RenderPipeline.Builder base() {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withVertexShader(HalloweenShaders.WITCH).withFragmentShader(HalloweenShaders.WITCH).withUniform("Projection", class_10789.field_60031).withUniform("Fog", class_10789.field_60031).withUniform("WitchData", class_10789.field_60031).withSampler("Sampler0").withSampler("Sampler1").withSampler("Sampler2").withCull(false).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withVertexFormat(FORMAT, VertexFormat.class_5596.field_27379);
    }

    public static boolean uploaded() {
        if (witchVbo == null) return false;
        return true;
    }

    public static boolean ensure(NotWitchModel notWitchModel) {
        if (failed) {
            return false;
        }
        if (witchVbo != null) {
            return true;
        }
        try {
            GpuDevice gpuDevice = RenderSystem.getDevice();
            witchVbo = Projection.vertices(gpuDevice, "Kryzex witch", notWitchModel.witch);
            witchIbo = Projection.indices(gpuDevice, "Kryzex witch indices", notWitchModel.witch);
            witchIndices = notWitchModel.witch.indices.length;
            broomVbo = Projection.vertices(gpuDevice, "Kryzex broom", notWitchModel.broom);
            broomIbo = Projection.indices(gpuDevice, "Kryzex broom indices", notWitchModel.broom);
            broomIndices = notWitchModel.broom.indices.length;
            witchTex = Projection.texture(gpuDevice, "/assets/r87f4560b4c09f4/rf7937fcc1c423c/witch.png");
            emissiveTex = Projection.texture(gpuDevice, "/assets/r87f4560b4c09f4/rf7937fcc1c423c/witch_emissive.png");
            broomTex = Projection.texture(gpuDevice, "/assets/r87f4560b4c09f4/rf7937fcc1c423c/broom.png");
            blackTex = gpuDevice.createTexture(Projection::lmbd$ensure$0, 5, TextureFormat.RGBA8, 1, 1, 1, 1);
            try (class_1011 class_10112 = new class_1011(1, 1, false);){
                class_10112.method_61941(0, 0, -16777216);
                gpuDevice.createCommandEncoder().writeToTexture(blackTex, class_10112);
            }
            witchView = gpuDevice.createTextureView(witchTex);
            emissiveView = gpuDevice.createTextureView(emissiveTex);
            broomView = gpuDevice.createTextureView(broomTex);
            blackView = gpuDevice.createTextureView(blackTex);
            witchUbo = gpuDevice.createBuffer(Projection::lmbd$ensure$1, 136, 5392L);
            broomUbo = gpuDevice.createBuffer(Projection::lmbd$ensure$2, 136, 5392L);
            scratch = BufferUtils.createByteBuffer(5392);
            return true;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: witch upload failed: " + String.valueOf(throwable));
            failed = true;
            Projection.release();
            return false;
        }
    }

    private static GpuBuffer vertices(GpuDevice gpuDevice, String string, VertexCount vertexCount) {
        int n = FORMAT.getVertexSize();
        int n2 = FORMAT.getOffset(VertexFormatElement.POSITION);
        int n3 = FORMAT.getOffset(VertexFormatElement.COLOR);
        int n4 = FORMAT.getOffset(VertexFormatElement.UV0);
        int n5 = FORMAT.getOffset(VertexFormatElement.UV1);
        int n6 = FORMAT.getOffset(VertexFormatElement.UV2);
        int n7 = FORMAT.getOffset(VertexFormatElement.NORMAL);
        ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)(n * vertexCount.vertexCount)).order(ByteOrder.nativeOrder());
        for (int i = 0; i < vertexCount.vertexCount; ++i) {
            int n8 = i * n;
            byteBuffer.putFloat(n8 + n2, vertexCount.pos[i * 3]);
            byteBuffer.putFloat(n8 + n2 + 4, vertexCount.pos[i * 3 + 1]);
            byteBuffer.putFloat(n8 + n2 + 8, vertexCount.pos[i * 3 + 2]);
            for (int j = 0; j < 4; ++j) {
                byteBuffer.put(n8 + n3 + j, vertexCount.joints[i * 4 + j]);
            }
            byteBuffer.putFloat(n8 + n4, vertexCount.uv[i * 2]);
            byteBuffer.putFloat(n8 + n4 + 4, vertexCount.uv[i * 2 + 1]);
            byteBuffer.putShort(n8 + n5, vertexCount.weights[i * 4]);
            byteBuffer.putShort(n8 + n5 + 2, vertexCount.weights[i * 4 + 1]);
            byteBuffer.putShort(n8 + n6, vertexCount.weights[i * 4 + 2]);
            byteBuffer.putShort(n8 + n6 + 2, vertexCount.weights[i * 4 + 3]);
            byteBuffer.put(n8 + n7, vertexCount.normal[i * 3]);
            byteBuffer.put(n8 + n7 + 1, vertexCount.normal[i * 3 + 1]);
            byteBuffer.put(n8 + n7 + 2, vertexCount.normal[i * 3 + 2]);
        }
        byteBuffer.position(0);
        byteBuffer.limit(n * vertexCount.vertexCount);
        return gpuDevice.createBuffer(() -> Projection.lmbd$vertices$0(string), 32, byteBuffer);
    }

    private static GpuBuffer indices(GpuDevice gpuDevice, String string, VertexCount vertexCount) {
        ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)(vertexCount.indices.length * 4)).order(ByteOrder.nativeOrder());
        for (int n : vertexCount.indices) {
            byteBuffer.putInt(n);
        }
        byteBuffer.flip();
        return gpuDevice.createBuffer(() -> Projection.lmbd$indices$0(string), 64, byteBuffer);
    }

    private static GpuTexture texture(GpuDevice gpuDevice, String string) throws Exception {
        int n;
        BufferedImage bufferedImage;
        try (InputStream inputStream = Projection.class.getResourceAsStream(string);){
            if (inputStream == null) {
                throw new IllegalStateException("missing " + string);
            }
            bufferedImage = ImageIO.read(inputStream);
        }
        int n2 = bufferedImage.getWidth();
        int n3 = bufferedImage.getHeight();
        int[] nArray = bufferedImage.getRGB(0, 0, n2, n3, null, 0, n2);
        for (n = 1; n2 >> n >= 1 && n3 >> n >= 1 && n < 12; ++n) {
        }
        GpuTexture gpuTexture = gpuDevice.createTexture(() -> Projection.lmbd$texture$0(string), 5, TextureFormat.RGBA8, n2, n3, 1, n);
        CommandEncoder commandEncoder = gpuDevice.createCommandEncoder();
        int n4 = n2;
        int n5 = n3;
        int[] nArray2 = nArray;
        for (int i = 0; i < n; ++i) {
            int n6;
            try (class_1011 class_10112 = new class_1011(n4, n5, false);){
                for (n6 = 0; n6 < n5; ++n6) {
                    for (int j = 0; j < n4; ++j) {
                        class_10112.method_61941(j, n6, nArray2[n6 * n4 + j]);
                    }
                }
                commandEncoder.writeToTexture(gpuTexture, class_10112, i, 0, 0, 0, n4, n5, 0, 0);
            }
            if (i + 1 >= n) continue;
            int n7 = Math.max(1, n4 / 2);
            n6 = Math.max(1, n5 / 2);
            int[] nArray3 = new int[n7 * n6];
            for (int j = 0; j < n6; ++j) {
                for (int k = 0; k < n7; ++k) {
                    long l = 0L;
                    long l2 = 0L;
                    long l3 = 0L;
                    long l4 = 0L;
                    for (int i2 = 0; i2 < 2; ++i2) {
                        for (int i3 = 0; i3 < 2; ++i3) {
                            int n8 = nArray2[Math.min(n5 - 1, j * 2 + i2) * n4 + Math.min(n4 - 1, k * 2 + i3)];
                            l += (long)(n8 >>> 24);
                            l2 += (long)(n8 >> 16 & 0xFF);
                            l3 += (long)(n8 >> 8 & 0xFF);
                            l4 += (long)(n8 & 0xFF);
                        }
                    }
                    nArray3[j * n7 + k] = (int)(l / 4L) << 24 | (int)(l2 / 4L) << 16 | (int)(l3 / 4L) << 8 | (int)(l4 / 4L);
                }
            }
            nArray2 = nArray3;
            n4 = n7;
            n5 = n6;
        }
        return gpuTexture;
    }

    public static void draw(BindRotInv bindRotInv, Matrix4f matrix4f, Matrix4f matrix4f2, DissolveScale dissolveScale) {
        GpuTextureView gpuTextureView;
        boolean bl;
        if (dissolveScale.alpha <= 0.003f || witchVbo == null || !HalloweenShaders.ready(COLOR)) {
            return;
        }
        boolean bl2 = bl = dissolveScale.alpha < 0.995f;
        if (bl && !HalloweenShaders.ready(DEPTH)) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        class_276 class_2762 = class_3102.method_1522();
        GpuTextureView gpuTextureView2 = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_2762.method_71639();
        GpuTextureView gpuTextureView3 = gpuTextureView = RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : class_2762.method_71640();
        if (gpuTextureView2 == null || gpuTextureView == null) {
            return;
        }
        Matrix4f matrix4f3 = new Matrix4f((Matrix4fc)RenderSystem.getModelViewMatrix());
        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        Projection.writeUbo(matrix4f3, matrix4f, dissolveScale, dissolveScale.emissive, dissolveScale.rim, bindRotInv.skin, bindRotInv.count);
        commandEncoder.writeToBuffer(witchUbo.slice(), scratch);
        Matrix4f[] matrix4fArray = new Matrix4f[]{matrix4f2};
        Projection.writeUbo(matrix4f3, matrix4f, dissolveScale, 0.0f, dissolveScale.rim * 0.6f, matrix4fArray, 1);
        commandEncoder.writeToBuffer(broomUbo.slice(), scratch);
        GpuTextureView gpuTextureView4 = class_3102.field_1773.method_22974().method_71650();
        try (RenderPass renderPass = commandEncoder.createRenderPass(Projection::lmbd$draw$0, gpuTextureView2, OptionalInt.empty(), gpuTextureView, OptionalDouble.empty());){
            if (bl) {
                renderPass.setPipeline(DEPTH);
                Projection.bind(renderPass, gpuTextureView4, witchView, witchUbo);
                renderPass.setVertexBuffer(0, witchVbo);
                renderPass.setIndexBuffer(witchIbo, VertexFormat.class_5595.field_27373);
                renderPass.drawIndexed(0, 0, witchIndices, 1);
                Projection.bind(renderPass, gpuTextureView4, broomView, broomUbo);
                renderPass.setVertexBuffer(0, broomVbo);
                renderPass.setIndexBuffer(broomIbo, VertexFormat.class_5595.field_27373);
                renderPass.drawIndexed(0, 0, broomIndices, 1);
            }
            renderPass.setPipeline(COLOR);
            Projection.bind(renderPass, gpuTextureView4, witchView, witchUbo);
            renderPass.bindTexture("Sampler1", emissiveView, RenderSystem.getSamplerCache().method_75293(AddressMode.REPEAT, AddressMode.REPEAT, FilterMode.LINEAR, FilterMode.LINEAR, true));
            renderPass.setVertexBuffer(0, witchVbo);
            renderPass.setIndexBuffer(witchIbo, VertexFormat.class_5595.field_27373);
            renderPass.drawIndexed(0, 0, witchIndices, 1);
            Projection.bind(renderPass, gpuTextureView4, broomView, broomUbo);
            renderPass.setVertexBuffer(0, broomVbo);
            renderPass.setIndexBuffer(broomIbo, VertexFormat.class_5595.field_27373);
            renderPass.drawIndexed(0, 0, broomIndices, 1);
            return;
        }
    }

    private static void bind(RenderPass renderPass, GpuTextureView gpuTextureView, GpuTextureView gpuTextureView2, GpuBuffer gpuBuffer) {
        RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
        renderPass.setUniform("WitchData", gpuBuffer);
        renderPass.bindTexture("Sampler0", gpuTextureView2, RenderSystem.getSamplerCache().method_75293(AddressMode.REPEAT, AddressMode.REPEAT, FilterMode.LINEAR, FilterMode.LINEAR, true));
        renderPass.bindTexture("Sampler1", blackView, RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST));
        renderPass.bindTexture("Sampler2", gpuTextureView, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
    }

    private static void put4(ByteBuffer byteBuffer, int n, float f, float f2, float f3, float f4) {
        byteBuffer.putFloat(n, f);
        byteBuffer.putFloat(n + 4, f2);
        byteBuffer.putFloat(n + 8, f3);
        byteBuffer.putFloat(n + 12, f4);
    }

    private static void writeUbo(Matrix4f matrix4f, Matrix4f matrix4f2, DissolveScale dissolveScale, float f, float f2, Matrix4f[] matrix4fArray, int n) {
        ByteBuffer byteBuffer = scratch;
        byteBuffer.clear();
        matrix4f.get(0, byteBuffer);
        matrix4f2.get(64, byteBuffer);
        Projection.put4(byteBuffer, 128, dissolveScale.alpha, f, f2, 0.0f);
        Projection.put4(byteBuffer, 144, dissolveScale.block, dissolveScale.sky, dissolveScale.worldLight, 0.0f);
        Projection.put4(byteBuffer, 160, dissolveScale.rimColor[0], dissolveScale.rimColor[1], dissolveScale.rimColor[2], f2);
        Projection.put4(byteBuffer, 176, dissolveScale.dissolveAt, dissolveScale.dissolveEdge, dissolveScale.dissolveMode, dissolveScale.dissolveScale);
        Projection.put4(byteBuffer, 192, dissolveScale.dissolveColor[0], dissolveScale.dissolveColor[1], dissolveScale.dissolveColor[2], dissolveScale.dissolveColor[3]);
        Projection.put4(byteBuffer, 208, dissolveScale.keyDir[0], dissolveScale.keyDir[1], dissolveScale.keyDir[2], dissolveScale.keyDir[3]);
        Projection.put4(byteBuffer, 224, dissolveScale.keyColor[0], dissolveScale.keyColor[1], dissolveScale.keyColor[2], 0.0f);
        Projection.put4(byteBuffer, 240, dissolveScale.fillColor[0], dissolveScale.fillColor[1], dissolveScale.fillColor[2], dissolveScale.fillColor[3]);
        Projection.put4(byteBuffer, 256, dissolveScale.ambient[0], dissolveScale.ambient[1], dissolveScale.ambient[2], 0.0f);
        for (int i = 0; i < 80; ++i) {
            Matrix4f matrix4f3 = i < n ? matrix4fArray[i] : matrix4fArray[0];
            matrix4f3.get(272 + i * 64, byteBuffer);
        }
        byteBuffer.position(0);
        byteBuffer.limit(5392);
    }

    public static void release() {
        for (AutoCloseable autoCloseable : new AutoCloseable[]{witchVbo, witchIbo, broomVbo, broomIbo, witchView, emissiveView, broomView, blackView, witchTex, emissiveTex, broomTex, blackTex, witchUbo, broomUbo}) {
            if (autoCloseable == null) continue;
            try {
                autoCloseable.close();
            }
            catch (Throwable throwable) {

            }
        }
        broomIbo = null;
        broomVbo = null;
        witchIbo = null;
        witchVbo = null;
        blackView = null;
        broomView = null;
        emissiveView = null;
        witchView = null;
        blackTex = null;
        broomTex = null;
        emissiveTex = null;
        witchTex = null;
        broomUbo = null;
        witchUbo = null;
        scratch = null;
    }

    private static String lmbd$draw$0() {
        return "Kryzex witch";
    }

    private static String lmbd$texture$0(String string) {
        return "Kryzex " + string;
    }

    private static String lmbd$indices$0(String string) {
        return string;
    }

    private static String lmbd$vertices$0(String string) {
        return string;
    }

    private static String lmbd$ensure$2() {
        return "Kryzex broom joints";
    }

    private static String lmbd$ensure$1() {
        return "Kryzex witch joints";
    }

    private static String lmbd$ensure$0() {
        return "Kryzex black";
    }
}
