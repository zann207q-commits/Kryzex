package kryzex.cinematic;

public enum CinematicPhase {
    IDLE,
    CLOSING,
    TITLE,
    WITCH,
    OUTRO;

}
