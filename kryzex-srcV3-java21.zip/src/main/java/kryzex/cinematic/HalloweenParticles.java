package kryzex.cinematic;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import java.util.Random;
import kryzex.cinematic.HalloweenShaders;
import kryzex.cinematic.Skydata;
import net.minecraft.class_1011;
import net.minecraft.class_10789;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_9801;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.BufferUtils;

public final class HalloweenParticles {
    public static final int SMOKE = 0;
    public static final int GLOW = 1;
    public static final int SPARK = 2;
    public static final int EMBER = 3;
    public static final int DUST = 4;
    private static final int MAX = 1400;
    private static final int UBO_SIZE = 96;
    private static final RenderPipeline SMOKE_PIPE = HalloweenParticles.pipeline("pipeline/hw_particle_smoke", BlendFunction.TRANSLUCENT);
    private static final RenderPipeline GLOW_PIPE = HalloweenParticles.pipeline("pipeline/hw_particle_glow", BlendFunction.LIGHTNING);
    private static final double[] px = new double[1400];
    private static final double[] py = new double[1400];
    private static final double[] pz = new double[1400];
    private static final float[] vx = new float[1400];
    private static final float[] vy = new float[1400];
    private static final float[] vz = new float[1400];
    private static final float[] age = new float[1400];
    private static final float[] life = new float[1400];
    private static final float[] size = new float[1400];
    private static final float[] grow = new float[1400];
    private static final float[] rot = new float[1400];
    private static final float[] spin = new float[1400];
    private static final float[] seed = new float[1400];
    private static final float[] cr = new float[1400];
    private static final float[] cg = new float[1400];
    private static final float[] cb = new float[1400];
    private static final float[] ca = new float[1400];
    private static final int[] kind = new int[1400];
    private static int count;
    private static float clock;
    private static Random RANDOM;
    private static GpuTexture smokeTex;
    private static GpuTextureView smokeView;
    private static GpuTexture glowTex;
    private static GpuTextureView glowView;
    private static GpuBuffer ubo;
    private static ByteBuffer data;

    private HalloweenParticles() {
    }

    private static RenderPipeline pipeline(String string, BlendFunction blendFunction) {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)string)).withVertexShader(HalloweenShaders.PARTICLE).withFragmentShader(HalloweenShaders.PARTICLE).withUniform("Projection", class_10789.field_60031).withUniform("Fog", class_10789.field_60031).withUniform("MistData", class_10789.field_60031).withSampler("Sampler0").withSampler("DepthSampler").withBlend(blendFunction).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382).build();
    }

    public static Random random() {
        return RANDOM;
    }

    public static void spawn(int n, double d, double d2, double d3, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        int n2 = count < 1400 ? count++ : RANDOM.nextInt(1400);
        HalloweenParticles.kind[n2] = n;
        HalloweenParticles.px[n2] = d;
        HalloweenParticles.py[n2] = d2;
        HalloweenParticles.pz[n2] = d3;
        HalloweenParticles.vx[n2] = f;
        HalloweenParticles.vy[n2] = f2;
        HalloweenParticles.vz[n2] = f3;
        HalloweenParticles.size[n2] = f4;
        HalloweenParticles.grow[n2] = f5;
        HalloweenParticles.life[n2] = Math.max(0.05f, f6);
        HalloweenParticles.age[n2] = 0.0f;
        HalloweenParticles.rot[n2] = RANDOM.nextFloat() * 6.2832f;
        HalloweenParticles.spin[n2] = (RANDOM.nextFloat() - 0.5f) * (n == 0 ? 0.9f : 0.0f);
        HalloweenParticles.seed[n2] = RANDOM.nextFloat() * 100.0f;
        HalloweenParticles.cr[n2] = f7;
        HalloweenParticles.cg[n2] = f8;
        HalloweenParticles.cb[n2] = f9;
        HalloweenParticles.ca[n2] = f10;
    }

    public static int count() {
        return count;
    }

    public static void clear() {
        count = 0;
    }

    public static void update(float f) {
        if (f <= 0.0f || count == 0) {
            return;
        }
        float f2 = clock += f;
        for (int i = count - 1; i >= 0; --i) {
            float f3;
            float f4;
            int n = i;
            age[n] = age[n] + f;
            if (age[i] >= life[i]) {
                HalloweenParticles.kill(i);
                continue;
            }
            int n2 = kind[i];
            float f5 = switch (n2) {
                case 0 -> {
                    f4 = 1.5f;
                    f3 = 0.32f;
                    yield 0.55f;
                }
                case 1 -> {
                    f4 = 1.8f;
                    f3 = 0.18f;
                    yield 0.45f;
                }
                case 2 -> {
                    f4 = 1.1f;
                    f3 = -0.9f;
                    yield 0.25f;
                }
                case 3 -> {
                    f4 = 0.9f;
                    f3 = 0.55f;
                    yield 1.1f;
                }
                default -> {
                    f4 = 2.6f;
                    f3 = 0.04f;
                    yield 0.35f;
                }
            };
            float f6 = seed[i];
            float f7 = (float)px[i];
            float f8 = (float)py[i];
            float f9 = (float)pz[i];
            float f10 = (float)(Math.sin((double)f8 * 1.7 + (double)f2 * 1.3 + (double)f6) + Math.sin((double)f9 * 2.3 - (double)f2 * 0.7 + (double)f6 * 0.5)) * 0.5f;
            float f11 = (float)Math.sin((double)f7 * 1.9 + (double)f2 * 0.9 + (double)f6 * 1.3) * 0.35f;
            float f12 = (float)(Math.cos((double)f7 * 1.5 - (double)f2 * 1.1 + (double)f6) + Math.sin((double)f8 * 2.1 + (double)f2 * 0.6)) * 0.5f;
            int n3 = i;
            vx[n3] = vx[n3] + f10 * f5 * f;
            int n4 = i;
            vy[n4] = vy[n4] + (f11 * f5 + f3) * f;
            int n5 = i;
            vz[n5] = vz[n5] + f12 * f5 * f;
            float f13 = (float)Math.exp(-f4 * f);
            int n6 = i;
            vx[n6] = vx[n6] * f13;
            int n7 = i;
            vy[n7] = vy[n7] * f13;
            int n8 = i;
            vz[n8] = vz[n8] * f13;
            int n9 = i;
            px[n9] = px[n9] + (double)(vx[i] * f);
            int n10 = i;
            py[n10] = py[n10] + (double)(vy[i] * f);
            int n11 = i;
            pz[n11] = pz[n11] + (double)(vz[i] * f);
            int n12 = i;
            rot[n12] = rot[n12] + spin[i] * f;
        }
    }

    private static void kill(int n) {
        int n2;
        if (n == (n2 = --count)) return;
        HalloweenParticles.kind[n] = kind[n2];
        HalloweenParticles.px[n] = px[n2];
        HalloweenParticles.py[n] = py[n2];
        HalloweenParticles.pz[n] = pz[n2];
        HalloweenParticles.vx[n] = vx[n2];
        HalloweenParticles.vy[n] = vy[n2];
        HalloweenParticles.vz[n] = vz[n2];
        HalloweenParticles.age[n] = age[n2];
        HalloweenParticles.life[n] = life[n2];
        HalloweenParticles.size[n] = size[n2];
        HalloweenParticles.grow[n] = grow[n2];
        HalloweenParticles.rot[n] = rot[n2];
        HalloweenParticles.spin[n] = spin[n2];
        HalloweenParticles.seed[n] = seed[n2];
        HalloweenParticles.cr[n] = cr[n2];
        HalloweenParticles.cg[n] = cg[n2];
        HalloweenParticles.cb[n] = cb[n2];
        HalloweenParticles.ca[n] = ca[n2];
    }

    public static void render(class_4184 class_41842) {
        if (count == 0 || class_41842 == null || !Skydata.hasMatrices()) {
            return;
        }
        if (!HalloweenShaders.ready(SMOKE_PIPE) || !HalloweenShaders.ready(GLOW_PIPE)) {
            return;
        }
        try {
            HalloweenParticles.ensure();
            class_243 class_2432 = class_41842.method_71156();
            Matrix4f matrix4f = Skydata.view();
            FrustumIntersection frustumIntersection = new FrustumIntersection((Matrix4fc)new Matrix4f((Matrix4fc)Skydata.projection()).mul((Matrix4fc)matrix4f));
            class_310 class_3102 = class_310.method_1551();
            class_276 class_2762 = class_3102.method_1522();
            Matrix4f matrix4f2 = Skydata.projection();
            float f = matrix4f2.m32() / (matrix4f2.m22() - 1.0f);
            float f2 = matrix4f2.m32() / (matrix4f2.m22() + 1.0f);
            data.clear();
            matrix4f.get(0, data);
            Skydata.put4(data, 64, f, f2, 0.35f, 0.0f);
            Skydata.put4(data, 80, class_2762.field_1482, class_2762.field_1481, 0.0f, 0.0f);
            data.position(0);
            data.limit(96);
            CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
            commandEncoder.writeToBuffer(ubo.slice(), data);
            HalloweenParticles.draw(true, class_2432, matrix4f, frustumIntersection, class_2762, commandEncoder);
            HalloweenParticles.draw(false, class_2432, matrix4f, frustumIntersection, class_2762, commandEncoder);
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: Halloween particles skipped: " + String.valueOf(throwable));
        }
    }

    private static void draw(boolean bl, class_243 class_2432, Matrix4f matrix4f, FrustumIntersection frustumIntersection, class_276 class_2762, CommandEncoder commandEncoder) {
        float f = matrix4f.m00();
        float f2 = matrix4f.m10();
        float f3 = matrix4f.m20();
        float f4 = matrix4f.m01();
        float f5 = matrix4f.m11();
        float f6 = matrix4f.m21();
        float f7 = -matrix4f.m02();
        float f8 = -matrix4f.m12();
        float f9 = -matrix4f.m22();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
        int n = 0;
        for (int i = 0; i < count; ++i) {
            float f10;
            float f11;
            float f12;
            float f13;
            float f14;
            float f15;
            float f16;
            float f17;
            float f18;
            float f19;
            float f20;
            float f21;
            float f22;
            float f23;
            float f24;
            float f25;
            float f26;
            if (kind[i] == 0 != bl || !frustumIntersection.testSphere(f26 = (float)(px[i] - class_2432.field_1352), f25 = (float)(py[i] - class_2432.field_1351), f24 = (float)(pz[i] - class_2432.field_1350), (f23 = size[i] * (1.0f + (grow[i] - 1.0f) * (1.0f - (1.0f - (f22 = age[i] / life[i])) * (1.0f - f22)))) * 3.0f + 0.5f)) continue;
            if (kind[i] == 0) {
                f21 = Math.min(1.0f, f22 / 0.18f) * (1.0f - f22) * (1.0f - f22);
            } else {
                float f27 = kind[i] == 3 || kind[i] == 4 ? 0.6f + 0.4f * (float)Math.sin(age[i] * (kind[i] == 4 ? 6.0f : 17.0f) + seed[i]) : 1.0f;
                f21 = Math.min(1.0f, f22 / 0.08f) * (float)Math.pow(1.0f - f22, 1.4f) * f27;
            }
            if ((f21 *= ca[i]) < 0.004f) continue;
            int n2 = Math.min(255, Math.round(cr[i] * 255.0f));
            int n3 = Math.min(255, Math.round(cg[i] * 255.0f));
            int n4 = Math.min(255, Math.round(cb[i] * 255.0f));
            int n5 = Math.min(255, Math.round(f21 * 255.0f));
            if (kind[i] == 2 && (f20 = (float)Math.sqrt((f19 = (f18 = vx[i]) - f7 * (f17 = f18 * f7 + (f16 = vy[i]) * f8 + (f15 = vz[i]) * f9)) * f19 + (f14 = f16 - f8 * f17) * f14 + (f13 = f15 - f9 * f17) * f13)) > 0.05f) {
                f12 = f19 / f20;
                f11 = f14 / f20;
                f10 = f13 / f20;
                float f28 = f11 * f9 - f10 * f8;
                float f29 = f10 * f7 - f12 * f9;
                float f30 = f12 * f8 - f11 * f7;
                float f31 = Math.min(1.4f, f20 * 0.07f) + f23;
                class_2872.method_22912(f26 - f12 * f31 - f28 * f23, f25 - f11 * f31 - f29 * f23, f24 - f10 * f31 - f30 * f23).method_22913(0.0f, 1.0f).method_1336(n2, n3, n4, n5);
                class_2872.method_22912(f26 - f12 * f31 + f28 * f23, f25 - f11 * f31 + f29 * f23, f24 - f10 * f31 + f30 * f23).method_22913(1.0f, 1.0f).method_1336(n2, n3, n4, n5);
                class_2872.method_22912(f26 + f12 * f23 + f28 * f23, f25 + f11 * f23 + f29 * f23, f24 + f10 * f23 + f30 * f23).method_22913(1.0f, 0.0f).method_1336(n2, n3, n4, n5);
                class_2872.method_22912(f26 + f12 * f23 - f28 * f23, f25 + f11 * f23 - f29 * f23, f24 + f10 * f23 - f30 * f23).method_22913(0.0f, 0.0f).method_1336(n2, n3, n4, n5);
                ++n;
                continue;
            }
            f18 = (float)Math.cos(rot[i]);
            f16 = (float)Math.sin(rot[i]);
            f15 = (f * f18 + f4 * f16) * f23;
            f17 = (f2 * f18 + f5 * f16) * f23;
            f19 = (f3 * f18 + f6 * f16) * f23;
            f14 = (f4 * f18 - f * f16) * f23;
            f13 = (f5 * f18 - f2 * f16) * f23;
            f20 = (f6 * f18 - f3 * f16) * f23;
            f12 = 0.0f;
            f11 = 0.0f;
            f10 = 1.0f;
            if (bl) {
                int n6 = (int)(seed[i] * 4.0f) & 3;
                f12 = (float)(n6 & 1) * 0.5f;
                f11 = (float)(n6 >> 1) * 0.5f;
                f10 = 0.5f;
            }
            class_2872.method_22912(f26 - f15 - f14, f25 - f17 - f13, f24 - f19 - f20).method_22913(f12, f11 + f10).method_1336(n2, n3, n4, n5);
            class_2872.method_22912(f26 + f15 - f14, f25 + f17 - f13, f24 + f19 - f20).method_22913(f12 + f10, f11 + f10).method_1336(n2, n3, n4, n5);
            class_2872.method_22912(f26 + f15 + f14, f25 + f17 + f13, f24 + f19 + f20).method_22913(f12 + f10, f11).method_1336(n2, n3, n4, n5);
            class_2872.method_22912(f26 - f15 + f14, f25 - f17 + f13, f24 - f19 + f20).method_22913(f12, f11).method_1336(n2, n3, n4, n5);
            ++n;
        }
        class_9801 class_98012 = class_2872.method_60794();
        if (class_98012 == null) {
            return;
        }
        try (class_9801 class_98013 = class_98012;){
            if (n == 0) {
                return;
            }
            RenderPipeline renderPipeline = bl ? SMOKE_PIPE : GLOW_PIPE;
            GpuBuffer gpuBuffer = renderPipeline.getVertexFormat().uploadImmediateVertexBuffer(class_98012.method_60818());
            RenderSystem.class_5590 class_55902 = RenderSystem.getSequentialBuffer((VertexFormat.class_5596)VertexFormat.class_5596.field_27382);
            GpuBuffer gpuBuffer2 = class_55902.method_68274(class_98012.method_60822().comp_751());
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_2762.method_71639();
            try (RenderPass renderPass = commandEncoder.createRenderPass(HalloweenParticles::lmbd$draw$0, gpuTextureView, OptionalInt.empty());){
                renderPass.setPipeline(renderPipeline);
                RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                renderPass.setUniform("MistData", ubo);
                renderPass.bindTexture("Sampler0", bl ? smokeView : glowView, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
                renderPass.bindTexture("DepthSampler", class_2762.method_71640(), RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST));
                renderPass.setVertexBuffer(0, gpuBuffer);
                renderPass.setIndexBuffer(gpuBuffer2, class_55902.method_31924());
                renderPass.drawIndexed(0, 0, class_98012.method_60822().comp_751(), 1);
                return;
            }
        }
    }

    private static float hash(int n, int n2, int n3) {
        int n4 = n * 73856093 ^ n2 * 19349663 ^ n3 * 83492791;
        n4 = (n4 ^ n4 >>> 13) * 1274126177;
        return (float)((n4 ^ n4 >>> 16) & 0xFFFF) / 65535.0f;
    }

    private static float noise(float f, float f2, int n) {
        int n2 = (int)Math.floor(f);
        int n3 = (int)Math.floor(f2);
        float f3 = f - (float)n2;
        float f4 = f2 - (float)n3;
        f3 = f3 * f3 * (3.0f - 2.0f * f3);
        f4 = f4 * f4 * (3.0f - 2.0f * f4);
        float f5 = HalloweenParticles.hash(n2, n3, n);
        float f6 = HalloweenParticles.hash(n2 + 1, n3, n);
        float f7 = HalloweenParticles.hash(n2, n3 + 1, n);
        float f8 = HalloweenParticles.hash(n2 + 1, n3 + 1, n);
        return f5 + (f6 - f5) * f3 + (f7 - f5) * f4 + (f5 - f6 - f7 + f8) * f3 * f4;
    }

    private static void ensure() {
        float f;
        float f2;
        int n;
        int n2;
        if (smokeTex != null) {
            return;
        }
        GpuDevice gpuDevice = RenderSystem.getDevice();
        int n3 = 96;
        int n4 = n3 * 2;
        smokeTex = gpuDevice.createTexture(HalloweenParticles::lmbd$ensure$0, 5, TextureFormat.RGBA8, n4, n4, 1, 1);
        try (class_1011 class_10112 = new class_1011(n4, n4, false);){
            for (int i = 0; i < 4; ++i) {
                n2 = (i & 1) * n3;
                n = (i >> 1) * n3;
                for (int j = 0; j < n3; ++j) {
                    for (int k = 0; k < n3; ++k) {
                        f2 = ((float)k + 0.5f) / (float)n3 * 2.0f - 1.0f;
                        f = ((float)j + 0.5f) / (float)n3 * 2.0f - 1.0f;
                        float f3 = 0.0f;
                        float f4 = 0.5f;
                        float f5 = 2.2f;
                        for (int i2 = 0; i2 < 4; ++i2) {
                            f3 += f4 * HalloweenParticles.noise(f2 * f5 + (float)i * 7.1f, f * f5 - (float)i * 3.3f, i * 11 + i2);
                            f4 *= 0.5f;
                            f5 *= 2.05f;
                        }
                        float f6 = (float)Math.sqrt(f2 * f2 + f * f) / (0.62f + 0.42f * f3);
                        float f7 = Math.max(0.0f, 1.0f - f6);
                        f7 = f7 * f7 * (3.0f - 2.0f * f7);
                        float f8 = Math.max(0.0f, Math.min(1.0f, f7 * (0.45f + 0.9f * f3)));
                        int n5 = Math.round(f8 * 255.0f);
                        class_10112.method_61941(n2 + k, n + j, n5 << 24 | n5 << 16 | n5 << 8 | n5);
                    }
                }
            }
            gpuDevice.createCommandEncoder().writeToTexture(smokeTex, class_10112);
        }
        smokeView = gpuDevice.createTextureView(smokeTex);
        int n6 = 64;
        glowTex = gpuDevice.createTexture(HalloweenParticles::lmbd$ensure$1, 5, TextureFormat.RGBA8, n6, n6, 1, 1);
        try (class_1011 class_10113 = new class_1011(n6, n6, false);){
            for (n2 = 0; n2 < n6; ++n2) {
                for (n = 0; n < n6; ++n) {
                    float f9 = ((float)n + 0.5f) / (float)n6 * 2.0f - 1.0f;
                    float f10 = ((float)n2 + 0.5f) / (float)n6 * 2.0f - 1.0f;
                    f2 = f9 * f9 + f10 * f10;
                    f = (float)(Math.exp((double)(-f2) * 26.0) * 0.85 + Math.exp((double)(-f2) * 5.0) * 0.32) * Math.max(0.0f, 1.0f - (float)Math.sqrt(f2));
                    int n7 = Math.round(Math.min(1.0f, f) * 255.0f);
                    class_10113.method_61941(n, n2, n7 << 24 | n7 << 16 | n7 << 8 | n7);
                }
            }
            gpuDevice.createCommandEncoder().writeToTexture(glowTex, class_10113);
        }
        glowView = gpuDevice.createTextureView(glowTex);
        ubo = gpuDevice.createBuffer(HalloweenParticles::lmbd$ensure$2, 136, 96L);
        data = BufferUtils.createByteBuffer(96);
    }

    public static void release() {
        count = 0;
        for (AutoCloseable autoCloseable : new AutoCloseable[]{smokeView, smokeTex, glowView, glowTex, ubo}) {
            if (autoCloseable == null) continue;
            try {
                autoCloseable.close();
            }
            catch (Throwable throwable) {

            }
        }
        smokeView = null;
        smokeTex = null;
        glowView = null;
        glowTex = null;
        ubo = null;
        data = null;
    }

    private static String lmbd$ensure$2() {
        return "Kryzex Halloween particles";
    }

    private static String lmbd$ensure$1() {
        return "Kryzex glow";
    }

    private static String lmbd$ensure$0() {
        return "Kryzex smoke";
    }

    private static String lmbd$draw$0() {
        return "Kryzex Halloween particles";
    }

    static {
        RANDOM = new Random();
    }
}
