package kryzex.cinematic;

import kryzex.cinematic.CinematicDirector;
import kryzex.gui.GuiAudio;
import kryzex.gui.GuiRenderer;
import kryzex.gui.GuiSoundType;
import kryzex.gui.WelcomeScreen;
import net.minecraft.class_1041;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class WelcomeKryzexClient
extends class_437 {
    private static final float EXIT_TIME = 0.6f;
    private final WelcomeScreen title = new WelcomeScreen();
    private float t;
    private float exit = -1.0f;
    private long last;
    private boolean done;

    public WelcomeKryzexClient() {
        super((class_2561)class_2561.method_43470((String)"Welcome To Kryzex Client"));
    }

    public boolean method_25421() {
        return false;
    }

    public boolean method_25422() {
        return false;
    }

    public void method_25419() {
        this.proceed();
    }

    public void method_25420(class_332 class_3322, int n, int n2, float f) {
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        if (this.field_22787 == null) {
            return;
        }
        long l = System.nanoTime();
        float f2 = this.last == 0L ? 0.016f : Math.min(0.1f, (float)(l - this.last) / 1.0E9f);
        this.last = l;
        this.t += f2;
        if (this.exit >= 0.0f) {
            this.exit = Math.min(1.0f, this.exit + f2 / 0.6f);
        }
        class_1041 class_10412 = this.field_22787.method_22683();
        int n3 = class_10412.method_4489();
        int n4 = class_10412.method_4506();
        float f3 = class_10412.method_4495();
        double d = this.field_22787.field_1729.method_1603() * (double)n3 / (double)Math.max(1, class_10412.method_4480());
        double d2 = this.field_22787.field_1729.method_1604() * (double)n4 / (double)Math.max(1, class_10412.method_4507());
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().scale(1.0f / f3, 1.0f / f3);
        try {
            this.title.render(new GuiRenderer(class_3322, f3), n3, n4, this.t, f2, Math.max(0.0f, this.exit), d, d2);
        }
        finally {
            class_3322.method_51448().popMatrix();
        }
        if (!(this.exit >= 1.0f) || this.done) return;
        this.done = true;
        CinematicDirector.titleFinished(this);
    }

    private double px(double d) {
        return d * (this.field_22787 == null ? 1.0 : (double)this.field_22787.method_22683().method_4495());
    }

    public boolean method_25402(class_11909 class_119092, boolean bl) {
        if (!this.title.overContinue(this.px(class_119092.comp_4798()), this.px(class_119092.comp_4799()))) return true;
        this.proceed();
        return true;
    }

    public boolean method_25404(class_11908 class_119082) {
        int n = class_119082.comp_4795();
        if (n != 257 && n != 335 && n != 32 && n != 256) return true;
        this.proceed();
        return true;
    }

    public void proceed() {
        if (!(this.exit < 0.0f) || !this.title.continueVisible()) return;
        this.exit = 0.0f;
        this.title.pressed();
        GuiAudio.play(GuiSoundType.CONFIRM);
    }

    public boolean exiting() {
        if (!(this.exit >= 0.0f)) return false;
        return true;
    }
}
