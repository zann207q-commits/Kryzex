package kryzex.cinematic;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import kryzex.cinematic.BindRotInv;
import kryzex.cinematic.DissolveScale;
import kryzex.cinematic.InputLocked;
import kryzex.cinematic.NotWitchModel;
import kryzex.cinematic.Projection;
import kryzex.cinematic.HalloweenParticles;
import kryzex.cinematic.Root;
import kryzex.cinematic.UnderValid;
import kryzex.cinematic.Volume;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class WitchActor {
    private static CompletableFuture<NotWitchModel> loading;
    private static NotWitchModel asset;
    private static BindRotInv rig;
    private static Root perf;
    private static boolean running;
    private static float t;
    private static boolean laughed;
    private static boolean puffed;
    private static float acc;
    private static float trailAcc;
    private static List<Volume> SOUNDS;
    private static class_5819 SOUND_RANDOM;
    private static DissolveScale LOOK;

    private WitchActor() {
    }

    public static void preload() {
        if (asset != null || loading != null) return;
        loading = CompletableFuture.supplyAsync(WitchActor::lmbd$preload$0);
    }

    private static boolean ready() {
        if (asset != null) {
            return true;
        }
        WitchActor.preload();
        try {
            asset = loading.join();
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: witch model failed to load: " + String.valueOf(throwable));
            asset = null;
        }
        loading = null;
        if (asset == null) return false;
        return true;
    }

    public static boolean start() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null || class_3102.field_1687 == null || !WitchActor.ready()) {
            return false;
        }
        rig = new BindRotInv(asset);
        perf = new Root(rig);
        class_243 class_2432 = class_3102.field_1724.method_5836(1.0f);
        class_243 class_2433 = WitchActor.place(class_3102, class_2432);
        class_638 class_6382 = class_3102.field_1687;
        perf.start(new Vector3d(class_2433.field_1352, class_2433.field_1351, class_2433.field_1350), new Vector3d(class_2432.field_1352, class_2432.field_1351, class_2432.field_1350), (arg_0, arg_1) -> WitchActor.lmbd$start$0(class_6382, arg_0, arg_1));
        t = 0.0f;
        laughed = false;
        puffed = false;
        acc = 0.0f;
        trailAcc = 0.0f;
        running = true;
        SOUNDS.clear();
        return true;
    }

    private static class_243 place(class_310 class_3102, class_243 class_2432) {
        class_638 class_6382 = class_3102.field_1687;
        float f = class_3102.field_1724.method_36454();
        double d = -Math.sin(Math.toRadians(f));
        double d2 = Math.cos(Math.toRadians(f));
        block0: for (double d3 = 10.0; d3 >= 5.0; d3 -= 0.5) {
            double d4 = class_2432.field_1352 + d * d3;
            double d5 = class_2432.field_1350 + d2 * d3;
            int n = class_3532.method_15357((double)d4);
            int n2 = class_3532.method_15357((double)d5);
            for (int i = class_3532.method_15357((double)class_2432.field_1351) + 4; i >= class_3532.method_15357((double)class_2432.field_1351) - 10; --i) {
                class_2338 class_23382 = new class_2338(n, i, n2);
                if (class_6382.method_8320(class_23382).method_26220((class_1922)class_6382, class_23382).method_1110() || !class_6382.method_8320(class_23382.method_10084()).method_26220((class_1922)class_6382, class_23382.method_10084()).method_1110() || !class_6382.method_8320(class_23382.method_10086(2)).method_26220((class_1922)class_6382, class_23382.method_10086(2)).method_1110()) continue;
                double d6 = (double)i + class_6382.method_8320(class_23382).method_26220((class_1922)class_6382, class_23382).method_1105(class_2350.class_2351.field_11052);
                class_243 class_2433 = new class_243(d4, d6, d5);
                class_3965 class_39652 = class_6382.method_17742(new class_3959(class_2432, class_2433.method_1031(0.0, 1.2, 0.0), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)class_3102.field_1724));
                if (class_39652.method_17783() != class_239.class_240.field_1333) continue block0;
                return class_2433;
            }
        }
        return new class_243(class_2432.field_1352 + d * 7.0, class_2432.field_1351 - 1.62, class_2432.field_1350 + d2 * 7.0);
    }

    public static boolean running() {
        return running;
    }

    public static void hurry() {
        if (!running || perf == null) return;
        perf.exit();
    }

    private static float smooth(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * (3.0f - 2.0f * f);
    }

    public static void update(float f) {
        float f2;
        float f3;
        float f4;
        Vector3f vector3f;
        double d;
        if (!running) {
            WitchActor.flushSounds(f);
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null || class_3102.field_1687 == null) {
            WitchActor.reset();
            return;
        }
        class_243 class_2432 = class_3102.field_1724.method_5836(1.0f);
        perf.update(t += f, new Vector3d(class_2432.field_1352, class_2432.field_1351, class_2432.field_1350));
        Vector3d vector3d = WitchActor.perf.origin;
        Vector3f vector3f2 = perf.center(new Vector3f());
        class_243 class_2433 = new class_243(vector3d.x + (double)vector3f2.x, vector3d.y + (double)vector3f2.y, vector3d.z + (double)vector3f2.z);
        Random random = HalloweenParticles.random();
        if (t < 2.8000002f) {
            acc += f * 60.0f;
            while (acc >= 1.0f) {
                acc -= 1.0f;
                d = random.nextDouble() * Math.PI * 2.0;
                double d2 = 0.55 + random.nextDouble() * 0.35;
                float f5 = 0.9f;
                if (random.nextFloat() < 0.35f) {
                    HalloweenParticles.spawn(0, vector3d.x + Math.cos(d) * d2, vector3d.y + 0.1 + random.nextDouble() * 0.5, vector3d.z + Math.sin(d) * d2, (float)(-Math.sin(d) * (double)f5), 0.25f + random.nextFloat() * 0.3f, (float)(Math.cos(d) * (double)f5), 0.45f + random.nextFloat() * 0.3f, 2.4f, 2.4f + random.nextFloat(), 0.2f, 0.15f, 0.27f, 0.55f);
                    continue;
                }
                vector3f = perf.bodyAt(Math.max(0.05f, WitchActor.perf.dissolveAt), (float)d, new Vector3f());
                HalloweenParticles.spawn(random.nextFloat() < 0.5f ? 1 : 3, vector3d.x + (double)vector3f.x, vector3d.y + (double)vector3f.y, vector3d.z + (double)vector3f.z, (float)Math.cos(d) * 0.35f, 0.25f + random.nextFloat() * 0.4f, (float)Math.sin(d) * 0.35f, 0.05f + random.nextFloat() * 0.04f, 0.4f, 0.9f + random.nextFloat() * 0.8f, 1.0f, 0.55f + random.nextFloat() * 0.25f, 0.2f, 0.9f);
            }
        }
        if (t > 2.2f && t < 11.9f) {
            trailAcc += f * 7.0f;
            while (trailAcc >= 1.0f) {
                trailAcc -= 1.0f;
                d = random.nextDouble() * Math.PI * 2.0;
                HalloweenParticles.spawn(4, vector3d.x + Math.cos(d) * 0.8, vector3d.y + 0.3 + random.nextDouble() * 1.5, vector3d.z + Math.sin(d) * 0.8, (float)(-Math.sin(d)) * 0.12f, 0.05f, (float)Math.cos(d) * 0.12f, 0.025f, 0.6f, 2.2f + random.nextFloat(), 0.8f, 0.7f, 1.0f, 0.75f);
            }
        }
        if (WitchActor.perf.casting > 0.01f) {
            Vector3f vector3f3 = perf.rightHand(new Vector3f());
            acc += f * 70.0f * WitchActor.perf.casting;
            while (acc >= 1.0f) {
                acc -= 1.0f;
                float f6 = t * 7.0f + random.nextFloat() * 0.6f;
                float f7 = 0.25f + random.nextFloat() * 0.25f;
                f4 = 1.4f + random.nextFloat() * 0.8f;
                boolean bl = random.nextFloat() < 0.55f;
                HalloweenParticles.spawn(random.nextFloat() < 0.4f ? 2 : 1, vector3d.x + (double)vector3f3.x, vector3d.y + (double)vector3f3.y, vector3d.z + (double)vector3f3.z, (float)Math.cos(f6) * f7 * 3.0f, f4, (float)Math.sin(f6) * f7 * 3.0f, 0.04f + random.nextFloat() * 0.04f, 0.5f, 1.1f + random.nextFloat() * 0.9f, bl ? 1.0f : 0.72f, bl ? 0.6f : 0.45f, bl ? 0.25f : 1.0f, 0.95f);
            }
        }
        if (!puffed && t >= 12.799999f) {
            puffed = true;
            for (int i = 0; i < 26; ++i) {
                double d3 = random.nextDouble() * Math.PI * 2.0;
                HalloweenParticles.spawn(0, vector3d.x + Math.cos(d3) * 0.4, vector3d.y + 0.15, vector3d.z + Math.sin(d3) * 0.4, (float)Math.cos(d3) * 1.6f, 0.2f + random.nextFloat() * 0.3f, (float)Math.sin(d3) * 1.6f, 0.4f + random.nextFloat() * 0.3f, 2.6f, 2.0f + random.nextFloat(), 0.22f, 0.17f, 0.28f, 0.5f);
            }
        }
        if (!laughed && t >= 14.7f) {
            laughed = true;
            WitchActor.sound(class_3417.field_19153, class_2433.method_1031(0.0, 0.6, 0.0), 1.9f, 0.86f, 0.0f);
            WitchActor.sound(class_3417.field_19153, class_2433.method_1031(0.0, 2.5, 0.0), 1.3f, 0.84f, 0.22f);
            WitchActor.sound(class_3417.field_19153, class_2433.method_1031(0.0, 5.0, 0.0), 0.95f, 0.81f, 0.5f);
            WitchActor.sound(class_3417.field_14869, class_2433, 0.7f, 0.6f, 0.05f);
        }
        if (t > 13.9f && WitchActor.perf.alpha > 0.02f) {
            Vector3f vector3f4 = perf.broomTail(new Vector3f());
            Vector3f vector3f5 = perf.velocity(new Vector3f());
            float f8 = vector3f5.length();
            trailAcc += f * (8.0f + 40.0f * Math.min(1.0f, f8 / 6.0f)) * WitchActor.perf.alpha;
            while (trailAcc >= 1.0f) {
                trailAcc -= 1.0f;
                f4 = random.nextFloat();
                double d4 = vector3d.x + (double)vector3f4.x + (random.nextDouble() - 0.5) * 0.18;
                double d5 = vector3d.y + (double)vector3f4.y + (random.nextDouble() - 0.5) * 0.18;
                double d6 = vector3d.z + (double)vector3f4.z + (random.nextDouble() - 0.5) * 0.18;
                if (f4 < 0.22f) {
                    HalloweenParticles.spawn(0, d4, d5, d6, -vector3f5.x * 0.15f, -vector3f5.y * 0.15f + 0.1f, -vector3f5.z * 0.15f, 0.18f + random.nextFloat() * 0.12f, 3.0f, 1.4f + random.nextFloat() * 0.8f, 0.24f, 0.19f, 0.3f, 0.42f * WitchActor.perf.alpha);
                    continue;
                }
                if (f4 < 0.62f) {
                    HalloweenParticles.spawn(3, d4, d5, d6, -vector3f5.x * 0.25f + (random.nextFloat() - 0.5f) * 0.6f, -vector3f5.y * 0.2f, -vector3f5.z * 0.25f + (random.nextFloat() - 0.5f) * 0.6f, 0.03f + random.nextFloat() * 0.025f, 0.5f, 1.0f + random.nextFloat() * 1.2f, 1.0f, 0.5f + random.nextFloat() * 0.25f, 0.15f, WitchActor.perf.alpha);
                    continue;
                }
                boolean bl = random.nextFloat() < 0.45f;
                HalloweenParticles.spawn(2, d4, d5, d6, -vector3f5.x * 0.4f + (random.nextFloat() - 0.5f), -vector3f5.y * 0.4f + (random.nextFloat() - 0.5f), -vector3f5.z * 0.4f + (random.nextFloat() - 0.5f), 0.03f + random.nextFloat() * 0.02f, 0.5f, 0.6f + random.nextFloat() * 0.6f, bl ? 0.75f : 1.0f, bl ? 0.5f : 0.7f, bl ? 1.0f : 0.35f, WitchActor.perf.alpha);
            }
        }
        if (WitchActor.perf.dissolveMode < 0.0f && WitchActor.perf.alpha > 0.02f) {
            acc += f * 90.0f;
            while (acc >= 1.0f) {
                acc -= 1.0f;
                float f9 = random.nextFloat() * 6.2832f;
                Vector3f vector3f6 = perf.bodyAt(WitchActor.perf.dissolveAt, f9, new Vector3f());
                boolean bl = random.nextFloat() < 0.4f;
                HalloweenParticles.spawn(random.nextFloat() < 0.5f ? 1 : 4, vector3d.x + (double)vector3f6.x, vector3d.y + (double)vector3f6.y, vector3d.z + (double)vector3f6.z, (float)Math.cos(f9) * 0.5f, 0.4f + random.nextFloat() * 0.5f, (float)Math.sin(f9) * 0.5f, 0.06f + random.nextFloat() * 0.05f, 0.3f, 1.2f + random.nextFloat(), bl ? 0.75f : 1.0f, bl ? 0.5f : 0.62f, bl ? 1.0f : 0.28f, 1.0f);
            }
        }
        WitchActor.flushSounds(f);
        float f10 = (float)class_2433.method_1022(class_2432);
        class_243 class_2434 = class_2433;
        if (t < 11.9f) {
            f3 = 1.0f - 0.16f * WitchActor.smooth((t - 1.0f) / 5.0f) - 0.06f * WitchActor.perf.casting;
            f2 = 4.5f;
            f4 = 1.2f;
            if (WitchActor.perf.casting > 0.0f) {
                class_2434 = class_2433.method_1031(0.0, 0.5 * (double)WitchActor.perf.casting, 0.0);
            }
        } else if (t < 14.7f) {
            f3 = 0.86f;
            f2 = 5.0f;
            f4 = 1.6f;
        } else {
            f3 = Math.max(0.34f, Math.min(0.86f, 9.5f / Math.max(1.0f, f10)));
            f2 = 6.5f;
            f4 = 2.4f;
            vector3f = perf.velocity(new Vector3f());
            class_2434 = class_2433.method_1031((double)vector3f.x * 0.2, (double)vector3f.y * 0.2, (double)vector3f.z * 0.2);
        }
        InputLocked.follow(class_2434, f2, f3, f4);
        if (!WitchActor.perf.finished) return;
        running = false;
    }

    public static boolean finished() {
        if (running) return false;
        return true;
    }

    private static void sound(class_3414 class_34142, class_243 class_2432, float f, float f2, float f3) {
        SOUNDS.add(new Volume(class_34142, class_2432, f, f2, f3));
    }

    private static void flushSounds(float f) {
        class_310 class_3102 = class_310.method_1551();
        for (int i = SOUNDS.size() - 1; i >= 0; --i) {
            Volume volume = SOUNDS.get(i);
            volume.delay -= f;
            if (!(volume.delay <= 0.0f)) continue;
            SOUNDS.remove(i);
            try {
                class_3102.method_1483().method_4873((class_1113)new class_1109(volume.event, class_3419.field_15250, volume.volume, volume.pitch, SOUND_RANDOM, volume.at.field_1352, volume.at.field_1351, volume.at.field_1350));
                continue;
            }
            catch (Throwable throwable) {

            }
        }
    }

    public static void render(class_243 class_2432) {
        if (!running || perf == null || WitchActor.perf.alpha <= 0.003f) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || !Projection.ensure(asset)) {
            return;
        }
        Vector3d vector3d = WitchActor.perf.origin;
        Matrix4f matrix4f = new Matrix4f().translation((float)(vector3d.x - class_2432.field_1352), (float)(vector3d.y - class_2432.field_1351), (float)(vector3d.z - class_2432.field_1350)).mul((Matrix4fc)WitchActor.perf.model);
        Vector3f vector3f = perf.center(new Vector3f());
        class_2338 class_23382 = class_2338.method_49637((double)(vector3d.x + (double)vector3f.x), (double)(vector3d.y + (double)vector3f.y), (double)(vector3d.z + (double)vector3f.z));
        DissolveScale dissolveScale = LOOK;
        dissolveScale.alpha = WitchActor.perf.alpha;
        dissolveScale.block = class_3102.field_1687.method_8314(class_1944.field_9282, class_23382);
        dissolveScale.sky = class_3102.field_1687.method_8314(class_1944.field_9284, class_23382);
        dissolveScale.worldLight = 0.85f;
        dissolveScale.emissive = 1.4f * WitchActor.perf.glow;
        dissolveScale.rim = 0.35f + 0.45f * WitchActor.perf.glow;
        dissolveScale.dissolveMode = WitchActor.perf.dissolveMode;
        dissolveScale.dissolveAt = WitchActor.perf.dissolveAt;
        Vector4f vector4f = UnderValid.moonDir();
        if (vector4f.w > 0.05f) {
            Vector3f vector3f2 = new Vector3f(vector4f.x, Math.max(0.35f, vector4f.y), vector4f.z).normalize();
            dissolveScale.keyDir[0] = vector3f2.x;
            dissolveScale.keyDir[1] = vector3f2.y;
            dissolveScale.keyDir[2] = vector3f2.z;
        } else {
            dissolveScale.keyDir[0] = 0.3f;
            dissolveScale.keyDir[1] = 0.8f;
            dissolveScale.keyDir[2] = 0.4f;
        }
        dissolveScale.keyDir[3] = 1.0f;
        dissolveScale.fillColor[3] = 0.22f + 0.35f * WitchActor.perf.glow;
        Projection.draw(rig, matrix4f, WitchActor.perf.broom, dissolveScale);
    }

    public static void reset() {
        running = false;
        perf = null;
        rig = null;
        SOUNDS.clear();
        Projection.release();
        asset = null;
        if (loading == null) return;
        loading.cancel(true);
        loading = null;
    }

    private static double lmbd$start$0(class_638 class_6382, double d, double d2) {
        int n;
        int n2 = class_3532.method_15357((double)d);
        if (!class_6382.method_8393(n2 >> 4, (n = class_3532.method_15357((double)d2)) >> 4)) return Double.NaN;
        double d3 = class_6382.method_8624(class_2902.class_2903.field_13197, n2, n);
        return d3;
    }

    private static NotWitchModel lmbd$preload$0() {
        NotWitchModel notWitchModel;
        InputStream inputStream = WitchActor.class.getResourceAsStream("/assets/r87f4560b4c09f4/rf7937fcc1c423c/witch.kwm");
        try {
            if (inputStream == null) {
                throw new IllegalStateException("missing witch model");
            }
            notWitchModel = NotWitchModel.load(inputStream);
            if (inputStream == null) return notWitchModel;
        }
        catch (Throwable throwable) {
            try {
                if (inputStream == null) throw throwable;
                try {
                    inputStream.close();
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
            catch (Exception exception) {
                throw new RuntimeException(exception);
            }
        }
        try {
            inputStream.close();
        }
        catch (IOException iOException) {

        }
        return notWitchModel;
    }

    static {
        SOUNDS = new ArrayList<Volume>();
        SOUND_RANDOM = class_5819.method_43047();
        LOOK = new DissolveScale();
    }
}
