package kryzex.cinematic;

import kryzex.cinematic.BindRotInv;
import kryzex.cinematic.NotWitchModel;
import kryzex.cinematic.SurfaceHeight;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class Root {
    public static final float APPEAR_END = 2.2f;
    public static final float NOTICE = 3.7f;
    public static final float TURN_START = 4.1f;
    public static final float WAVE_START = 5.3f;
    public static final float WAVE_END = 8.0f;
    public static final float HAT_START = 8.0f;
    public static final float HAT_END = 9.8f;
    public static final float SPELL_START = 9.7f;
    public static final float SPELL_END = 11.9f;
    public static final float MOUNT_START = 11.9f;
    public static final float MOUNT_END = 13.9f;
    public static final float FLY_START = 14.7f;
    public static final float WAVE_BACK = 19.7f;
    public static final float VANISH_LEN = 2.8f;
    private final BindRotInv rig;
    private final int hips;
    private final int spine1;
    private final int spine2;
    private final int chest;
    private final int neck;
    private final int head;
    private final int jaw;
    private final int eyeR;
    private final int eyeL;
    private final int[] hat;
    private final int[] hair;
    private final int[] cloak;
    private final int shoulderR;
    private final int elbowR;
    private final int wristR;
    private final int shoulderL;
    private final int elbowL;
    private final int wristL;
    private final int[][] fingersR;
    private final int[][] fingersL;
    private final int hipR;
    private final int kneeR;
    private final int ankleR;
    private final int hipL;
    private final int kneeL;
    private final int ankleL;
    private final Quaternionf[] stand;
    private final Quaternionf[] sit;
    private final Quaternionf q = new Quaternionf();
    private final Vector3f v = new Vector3f();
    public final Vector3d origin = new Vector3d();
    public final Matrix4f model = new Matrix4f();
    public final Matrix4f broom = new Matrix4f();
    public float alpha;
    public float glow;
    public float dissolveAt;
    public float dissolveMode;
    public boolean finished;
    public float vanishStart = Float.MAX_VALUE;
    public float casting;
    private SurfaceHeight ground;
    private float bodyYaw;
    private float yawVel;
    private float startYaw;
    private float headYaw;
    private float headYawVel;
    private final Vector3f flyPos = new Vector3f();
    private final Vector3f flyVel = new Vector3f();
    private float flyYaw;
    private float flyYawVel;
    private float flyPitch;
    private float flyPitchVel;
    private float flyRoll;
    private float flyRollVel;
    private float pathS;
    private float lastT = -1.0f;
    private final Matrix4f heldGrip = new Matrix4f();
    private boolean gripReady;
    private Vector3f[] path;
    private float exitFade = 1.0f;
    private boolean exiting;

    public Root(BindRotInv bindRotInv) {
        this.rig = bindRotInv;
        NotWitchModel notWitchModel = bindRotInv.asset;
        this.hips = notWitchModel.joint("Root_M");
        this.spine1 = notWitchModel.joint("Spine1_M");
        this.spine2 = notWitchModel.joint("Spine2_M");
        this.chest = notWitchModel.joint("Chest_M");
        this.neck = notWitchModel.joint("Neck_M");
        this.head = notWitchModel.joint("Head_M");
        this.jaw = notWitchModel.joint("JawJoint_M");
        this.eyeR = notWitchModel.joint("EyeJoint_R");
        this.eyeL = notWitchModel.joint("EyeJoint_L");
        this.hat = Root.joints(notWitchModel, "hat1_M", "hat2_M", "hat3_L", "hat4_L", "hat5_L", "hat6_L");
        this.hair = Root.joints(notWitchModel, "hairstrand20_L", "hairstrand21_L", "hairstrand22_L", "hairstrand23_L", "hairstrand24_L", "hairstrand25_L", "hairstrand26_L", "hairstrand27_L");
        this.cloak = Root.joints(notWitchModel, "cloak1_M", "cloak2_M", "cloak3_M", "cloak4_M", "cloak5_M", "cloak6_M", "cloak7_M");
        this.shoulderR = notWitchModel.joint("Shoulder_R");
        this.elbowR = notWitchModel.joint("Elbow_R");
        this.wristR = notWitchModel.joint("Wrist_R");
        this.shoulderL = notWitchModel.joint("Shoulder_L");
        this.elbowL = notWitchModel.joint("Elbow_L");
        this.wristL = notWitchModel.joint("Wrist_L");
        this.fingersR = Root.fingers(notWitchModel, "_R");
        this.fingersL = Root.fingers(notWitchModel, "_L");
        this.hipR = notWitchModel.joint("Hip_R");
        this.kneeR = notWitchModel.joint("Knee_R");
        this.ankleR = notWitchModel.joint("Ankle_R");
        this.hipL = notWitchModel.joint("Hip_L");
        this.kneeL = notWitchModel.joint("Knee_L");
        this.ankleL = notWitchModel.joint("Ankle_L");
        this.stand = new Quaternionf[bindRotInv.count];
        this.sit = new Quaternionf[bindRotInv.count];
        for (int i = 0; i < bindRotInv.count; ++i) {
            this.stand[i] = new Quaternionf();
            this.sit[i] = new Quaternionf();
        }
    }

    private static int[] joints(NotWitchModel notWitchModel, String ... stringArray) {
        int[] nArray = new int[stringArray.length];
        for (int i = 0; i < stringArray.length; ++i) {
            nArray[i] = notWitchModel.joint(stringArray[i]);
        }
        return nArray;
    }

    private static int[][] fingers(NotWitchModel notWitchModel, String string) {
        String[] stringArray = new String[]{"ThumbFinger", "IndexFinger", "MiddleFinger", "RingFinger", "PinkyFinger"};
        int[][] nArray = new int[5][3];
        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 3; ++j) {
                nArray[i][j] = notWitchModel.joint(stringArray[i] + (j + 1) + string);
            }
        }
        return nArray;
    }

    public void start(Vector3d vector3d, Vector3d vector3d2, SurfaceHeight q2) {
        this.origin.set((Vector3dc)vector3d);
        this.ground = q2;
        float f = (float)Math.atan2(vector3d2.x - vector3d.x, vector3d2.z - vector3d.z);
        this.bodyYaw = this.startYaw = f + 0.95f;
        this.yawVel = 0.0f;
        this.headYaw = 0.0f;
        this.headYawVel = 0.0f;
        this.finished = false;
        this.alpha = 0.0f;
        this.lastT = -1.0f;
        this.gripReady = false;
        this.pathS = 0.0f;
        this.path = null;
        this.vanishStart = Float.MAX_VALUE;
        this.exitFade = 1.0f;
        this.exiting = false;
    }

    public void exit() {
        this.exiting = true;
    }

    static float clamp01(float f) {
        if (f < 0.0f) {
            return 0.0f;
        }
        float f2 = Math.min(f, 1.0f);
        return f2;
    }

    static float span(float f, float f2, float f3) {
        return Root.clamp01((f - f2) / (f3 - f2));
    }

    static float smooth(float f) {
        f = Root.clamp01(f);
        return f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
    }

    static float window(float f, float f2, float f3, float f4, float f5) {
        return Root.smooth(Root.span(f, f2, f2 + f3)) * (1.0f - Root.smooth(Root.span(f, f4 - f5, f4)));
    }

    private static float wrap(float f) {
        while ((double)f > Math.PI) {
            f -= (float)Math.PI * 2;
        }
        while ((double)f < -Math.PI) {
            f += (float)Math.PI * 2;
        }
        return f;
    }

    private static Quaternionf axis(Quaternionf quaternionf, float f, float f2, float f3, float f4) {
        float f5 = (float)Math.sqrt(f * f + f2 * f2 + f3 * f3);
        return quaternionf.rotationAxis((float)Math.toRadians(f4), f / f5, f2 / f5, f3 / f5);
    }

    private void turn(Quaternionf[] quaternionfArray, int n, float f, float f2, float f3, float f4) {
        if (n < 0 || f4 == 0.0f) return;
        quaternionfArray[n].premul((Quaternionfc)Root.axis(this.q, f, f2, f3, f4));
    }

    private static void clear(Quaternionf[] quaternionfArray) {
        for (Quaternionf quaternionf : quaternionfArray) {
            quaternionf.identity();
        }
    }

    private void curl(Quaternionf[] quaternionfArray, int[][] nArray, float f, float f2, float f3) {
        int n;
        for (n = 1; n < 5; ++n) {
            float f4 = ((float)n - 2.5f) * 3.0f * (1.0f - f2);
            for (int i = 0; i < 3; ++i) {
                float f5 = f2 * (i == 0 ? 55.0f : (i == 1 ? 80.0f : 55.0f));
                this.turn(quaternionfArray, nArray[n][i], 0.0f, 0.0f, 1.0f, f * f5);
                if (i != 0) continue;
                this.turn(quaternionfArray, nArray[n][i], 1.0f, 0.0f, 0.0f, f4);
            }
        }
        for (n = 0; n < 3; ++n) {
            this.turn(quaternionfArray, nArray[0][n], 0.0f, 1.0f, 0.0f, -f * f3 * (n == 0 ? 25.0f : 35.0f));
        }
    }

    public void update(float f, Vector3d vector3d) {
        float f2;
        float f3;
        int n;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14 = this.lastT < 0.0f ? 0.0f : Math.max(0.0f, Math.min(0.1f, f - this.lastT));
        this.lastT = f;
        BindRotInv bindRotInv = this.rig;
        Root.clear(this.stand);
        Root.clear(this.sit);
        float f15 = (float)(vector3d.x - this.origin.x);
        float f16 = (float)(vector3d.z - this.origin.z);
        float f17 = (float)Math.atan2(f15, f16);
        float f18 = (float)Math.sqrt(f15 * f15 + f16 * f16);
        float f19 = (float)(vector3d.y - (this.origin.y + 1.5));
        float f20 = (float)Math.toDegrees(Math.atan2(f19, Math.max(0.5f, f18)));
        if (f < 14.7f) {
            f13 = f < 4.1f ? this.startYaw : this.startYaw + Root.wrap(f17 - this.startYaw);
            f12 = 15.0f;
            f11 = Root.wrap(f13 - this.bodyYaw);
            this.yawVel += (f11 * f12 - this.yawVel * 2.0f * (float)Math.sqrt(f12)) * f14;
            this.bodyYaw = Root.wrap(this.bodyYaw + this.yawVel * f14);
            if (f14 == 0.0f) {
                this.bodyYaw = f13;
            }
        }
        f13 = (float)Math.toDegrees(Math.max(-1.15f, Math.min(1.15f, Root.wrap(f17 - this.bodyYaw))));
        f12 = 40.0f * Root.window(f, 2.15f, 0.5f, 3.05f, 0.45f) - 36.0f * Root.window(f, 3.0f, 0.5f, 3.9f, 0.3f);
        f11 = Root.smooth(Root.span(f, 3.7f, 4.15f));
        float f21 = f12 * (1.0f - f11) + f13 * f11;
        float f22 = f > 3.7f && f < 4.2f ? 90.0f : 45.0f;
        this.headYawVel += ((f21 - this.headYaw) * f22 - this.headYawVel * 2.0f * (float)Math.sqrt(f22)) * f14;
        this.headYaw += this.headYawVel * f14;
        if (f14 == 0.0f) {
            this.headYaw = f21;
        }
        float f23 = 1.0f - Root.smooth(Root.span(f, 11.9f, 12.7f));
        float f24 = (float)Math.sin(f * 1.7f);
        float f25 = (float)Math.sin(f * 0.83f + 0.4f);
        Quaternionf[] quaternionfArray = this.stand;
        this.turn(quaternionfArray, this.spine1, 1.0f, 0.0f, 0.0f, 1.2f * f24);
        this.turn(quaternionfArray, this.chest, 1.0f, 0.0f, 0.0f, -1.6f * f24);
        this.turn(quaternionfArray, this.spine2, 0.0f, 0.0f, 1.0f, 1.1f * f25);
        this.turn(quaternionfArray, this.hips, 0.0f, 0.0f, 1.0f, -1.2f * f25);
        this.turn(quaternionfArray, this.chest, 0.0f, 1.0f, 0.0f, this.headYaw * 0.18f * f23);
        this.turn(quaternionfArray, this.neck, 0.0f, 1.0f, 0.0f, this.headYaw * 0.32f * f23);
        this.turn(quaternionfArray, this.head, 0.0f, 1.0f, 0.0f, this.headYaw * 0.5f * f23);
        float f26 = f11 * f23;
        this.turn(quaternionfArray, this.neck, 1.0f, 0.0f, 0.0f, -f20 * 0.35f * f26);
        this.turn(quaternionfArray, this.head, 1.0f, 0.0f, 0.0f, -f20 * 0.45f * f26);
        float f27 = Math.max(-26.0f, Math.min(26.0f, (f21 - this.headYaw) * 1.4f + f13 * 0.15f * f11));
        this.turn(quaternionfArray, this.eyeR, 0.0f, 1.0f, 0.0f, f27 * f23);
        this.turn(quaternionfArray, this.eyeL, 0.0f, 1.0f, 0.0f, f27 * f23);
        this.turn(quaternionfArray, this.shoulderR, 0.0f, 0.0f, 1.0f, 26.0f);
        this.turn(quaternionfArray, this.shoulderR, 1.0f, 0.0f, 0.0f, -6.0f);
        this.turn(quaternionfArray, this.elbowR, 1.0f, 0.0f, 0.0f, -14.0f);
        this.curl(quaternionfArray, this.fingersR, -1.0f, 0.25f, 0.2f);
        this.turn(quaternionfArray, this.shoulderL, 0.0f, 0.0f, 1.0f, -14.0f);
        this.turn(quaternionfArray, this.shoulderL, 1.0f, 0.0f, 0.0f, -16.0f);
        this.turn(quaternionfArray, this.elbowL, 1.0f, 0.0f, 0.0f, -58.0f);
        this.turn(quaternionfArray, this.wristL, 0.0f, 1.0f, 0.0f, 12.0f);
        this.curl(quaternionfArray, this.fingersL, 1.0f, 1.0f, 1.0f);
        float f28 = 1.0f - Root.smooth(Root.span(f, 1.2f, 2.6f));
        if (f28 > 0.0f) {
            this.turn(quaternionfArray, this.neck, 1.0f, 0.0f, 0.0f, 14.0f * f28);
            this.turn(quaternionfArray, this.head, 1.0f, 0.0f, 0.0f, 16.0f * f28);
            this.turn(quaternionfArray, this.spine2, 1.0f, 0.0f, 0.0f, 4.0f * f28);
            this.turn(quaternionfArray, this.shoulderR, 0.0f, 0.0f, 1.0f, -18.0f * f28);
        }
        float f29 = (float)Math.sin(Math.PI * (double)Root.span(f, 3.7f, 4.25f));
        this.turn(quaternionfArray, this.chest, 1.0f, 0.0f, 0.0f, -5.0f * f29);
        this.turn(quaternionfArray, this.head, 1.0f, 0.0f, 0.0f, -4.0f * f29);
        float f30 = Root.window(f, 5.3f, 0.7f, 8.0f, 0.6f);
        float f31 = Root.window(f, 5.25f, 0.47f, 8.05f, 0.55f);
        if (f30 > 0.0f || f31 > 0.0f) {
            f10 = (float)Math.sin((double)(f - 5.3f - 0.5f) * Math.PI * 2.0 * 1.45);
            f9 = Root.window(f, 5.75f, 0.4f, 7.55f, 0.45f);
            this.turn(quaternionfArray, this.shoulderR, 0.0f, 0.0f, 1.0f, -84.0f * f30);
            this.turn(quaternionfArray, this.shoulderR, 1.0f, 0.0f, 0.0f, -26.0f * f30);
            this.turn(quaternionfArray, this.elbowR, 0.0f, 0.0f, 1.0f, -96.0f * f31);
            this.turn(quaternionfArray, this.elbowR, 0.0f, 0.0f, 1.0f, 20.0f * f10 * f9);
            this.turn(quaternionfArray, this.wristR, 0.0f, 0.0f, 1.0f, 16.0f * (float)Math.sin((double)(f - 5.3f - 0.62f) * Math.PI * 2.0 * 1.45) * f9);
            this.curl(quaternionfArray, this.fingersR, -1.0f, -0.25f * f31, -0.4f * f31);
            this.turn(quaternionfArray, this.chest, 0.0f, 0.0f, 1.0f, 3.5f * f30);
            this.turn(quaternionfArray, this.spine2, 0.0f, 1.0f, 0.0f, -4.0f * f30);
            this.turn(quaternionfArray, this.head, 0.0f, 0.0f, 1.0f, -4.0f * f30 + 2.0f * f10 * f9);
            this.turn(quaternionfArray, this.jaw, 1.0f, 0.0f, 0.0f, 4.0f * f30);
        }
        f10 = Root.window(f, 8.0f, 0.5f, 9.8f, 0.55f);
        f9 = Root.window(f, 8.5f, 0.4f, 9.5f, 0.5f);
        if (f10 > 0.0f) {
            this.turn(quaternionfArray, this.shoulderR, 1.0f, 0.0f, 0.0f, -95.0f * f10);
            this.turn(quaternionfArray, this.shoulderR, 0.0f, 0.0f, 1.0f, -22.0f * f10);
            this.turn(quaternionfArray, this.elbowR, 1.0f, 0.0f, 0.0f, -70.0f * f10);
            this.turn(quaternionfArray, this.elbowR, 0.0f, 1.0f, 0.0f, 30.0f * f10);
            this.curl(quaternionfArray, this.fingersR, -1.0f, 0.45f * f10, 0.6f * f10);
            this.turn(quaternionfArray, this.spine1, 1.0f, 0.0f, 0.0f, 9.0f * f9);
            this.turn(quaternionfArray, this.chest, 1.0f, 0.0f, 0.0f, 6.0f * f9);
            this.turn(quaternionfArray, this.neck, 1.0f, 0.0f, 0.0f, 8.0f * f9);
            this.turn(quaternionfArray, this.head, 1.0f, 0.0f, 0.0f, 9.0f * f9);
            this.turn(quaternionfArray, this.hipR, 1.0f, 0.0f, 0.0f, -12.0f * f9);
            this.turn(quaternionfArray, this.kneeR, 1.0f, 0.0f, 0.0f, 22.0f * f9);
            this.turn(quaternionfArray, this.ankleR, 1.0f, 0.0f, 0.0f, -10.0f * f9);
            this.turn(quaternionfArray, this.hipL, 1.0f, 0.0f, 0.0f, -16.0f * f9);
            this.turn(quaternionfArray, this.kneeL, 1.0f, 0.0f, 0.0f, 30.0f * f9);
            this.turn(quaternionfArray, this.ankleL, 1.0f, 0.0f, 0.0f, -14.0f * f9);
        }
        float f32 = Root.window(f, 9.7f, 0.7f, 11.9f, 0.55f);
        this.casting = Root.window(f, 10.15f, 0.3f, 11.549999f, 0.35f);
        if (f32 > 0.0f) {
            float f33 = (float)Math.sin((f - 9.7f) * 3.3f) * this.casting;
            this.turn(quaternionfArray, this.shoulderR, 1.0f, 0.0f, 0.0f, -128.0f * f32);
            this.turn(quaternionfArray, this.shoulderR, 0.0f, 0.0f, 1.0f, -18.0f * f32 + 8.0f * f33);
            this.turn(quaternionfArray, this.elbowR, 1.0f, 0.0f, 0.0f, -22.0f * f32);
            this.turn(quaternionfArray, this.wristR, 1.0f, 0.0f, 0.0f, -20.0f * f32);
            this.curl(quaternionfArray, this.fingersR, -1.0f, -0.35f * f32, -0.5f * f32);
            this.turn(quaternionfArray, this.chest, 1.0f, 0.0f, 0.0f, -7.0f * f32);
            this.turn(quaternionfArray, this.neck, 1.0f, 0.0f, 0.0f, -12.0f * f32);
            this.turn(quaternionfArray, this.head, 1.0f, 0.0f, 0.0f, -16.0f * f32);
            this.turn(quaternionfArray, this.jaw, 1.0f, 0.0f, 0.0f, 7.0f * this.casting);
        }
        Quaternionf[] quaternionfArray2 = this.sit;
        this.turn(quaternionfArray2, this.spine1, 1.0f, 0.0f, 0.0f, 9.0f * f24);
        this.turn(quaternionfArray2, this.spine2, 1.0f, 0.0f, 0.0f, 6.0f);
        this.turn(quaternionfArray2, this.chest, 1.0f, 0.0f, 0.0f, 3.0f);
        this.turn(quaternionfArray2, this.neck, 1.0f, 0.0f, 0.0f, -9.0f);
        this.turn(quaternionfArray2, this.head, 1.0f, 0.0f, 0.0f, -6.0f);
        this.turn(quaternionfArray2, this.hipR, 1.0f, 0.0f, 0.0f, -78.0f);
        this.turn(quaternionfArray2, this.hipR, 0.0f, 0.0f, 1.0f, -10.0f);
        this.turn(quaternionfArray2, this.kneeR, 1.0f, 0.0f, 0.0f, 92.0f);
        this.turn(quaternionfArray2, this.ankleR, 1.0f, 0.0f, 0.0f, -18.0f);
        this.turn(quaternionfArray2, this.hipL, 1.0f, 0.0f, 0.0f, -74.0f);
        this.turn(quaternionfArray2, this.hipL, 0.0f, 0.0f, 1.0f, 10.0f);
        this.turn(quaternionfArray2, this.kneeL, 1.0f, 0.0f, 0.0f, 98.0f);
        this.turn(quaternionfArray2, this.ankleL, 1.0f, 0.0f, 0.0f, -18.0f);
        this.turn(quaternionfArray2, this.shoulderR, 0.0f, 0.0f, 1.0f, 30.0f);
        this.turn(quaternionfArray2, this.shoulderR, 1.0f, 0.0f, 0.0f, -44.0f);
        this.turn(quaternionfArray2, this.elbowR, 1.0f, 0.0f, 0.0f, -22.0f);
        this.turn(quaternionfArray2, this.shoulderL, 0.0f, 0.0f, 1.0f, -30.0f);
        this.turn(quaternionfArray2, this.shoulderL, 1.0f, 0.0f, 0.0f, -44.0f);
        this.turn(quaternionfArray2, this.elbowL, 1.0f, 0.0f, 0.0f, -22.0f);
        this.curl(quaternionfArray2, this.fingersR, -1.0f, 1.0f, 1.0f);
        this.curl(quaternionfArray2, this.fingersL, 1.0f, 1.0f, 1.0f);
        if (f > 14.2f) {
            f8 = Root.smooth(Root.span(f, 16.2f, 17.3f)) * (1.0f - Root.smooth(Root.span(f, this.vanishStart - 1.0f, this.vanishStart)));
            float[] fArray = this.lookAngles(vector3d);
            float f34 = Math.max(-75.0f, Math.min(75.0f, fArray[0])) * f8;
            f7 = Math.max(-30.0f, Math.min(30.0f, fArray[1])) * f8;
            this.turn(quaternionfArray2, this.chest, 0.0f, 1.0f, 0.0f, f34 * 0.2f);
            this.turn(quaternionfArray2, this.neck, 0.0f, 1.0f, 0.0f, f34 * 0.35f);
            this.turn(quaternionfArray2, this.head, 0.0f, 1.0f, 0.0f, f34 * 0.45f);
            this.turn(quaternionfArray2, this.head, 1.0f, 0.0f, 0.0f, -f7 * 0.6f);
            f6 = Root.window(f, 19.7f, 0.55f, 21.6f, 0.55f);
            if (f6 > 0.0f) {
                f5 = (float)Math.sin((double)(f - 19.7f) * Math.PI * 2.0 * 1.6) * Root.window(f, 20.1f, 0.3f, 21.2f, 0.3f);
                this.turn(quaternionfArray2, this.shoulderR, 1.0f, 0.0f, 0.0f, 44.0f * f6);
                this.turn(quaternionfArray2, this.shoulderR, 0.0f, 0.0f, 1.0f, -105.0f * f6);
                this.turn(quaternionfArray2, this.elbowR, 0.0f, 0.0f, 1.0f, -80.0f * f6 + 18.0f * f5);
                this.curl(quaternionfArray2, this.fingersR, -1.0f, -1.2f * f6, -1.3f * f6);
            }
        }
        f8 = Root.smooth(Root.span(f, 12.2f, 13.75f));
        float f35 = f < 12.7f ? (float)Math.sin(Math.PI * (double)Root.span(f, 11.9f, 12.7f)) : 0.0f;
        for (int i = 0; i < bindRotInv.count; ++i) {
            bindRotInv.rot[i].set((Quaternionfc)this.stand[i]).slerp((Quaternionfc)this.sit[i], f8);
        }
        if (f35 > 0.0f) {
            this.turn(bindRotInv.rot, this.hipR, 1.0f, 0.0f, 0.0f, -22.0f * f35);
            this.turn(bindRotInv.rot, this.kneeR, 1.0f, 0.0f, 0.0f, 38.0f * f35);
            this.turn(bindRotInv.rot, this.ankleR, 1.0f, 0.0f, 0.0f, -16.0f * f35);
            this.turn(bindRotInv.rot, this.hipL, 1.0f, 0.0f, 0.0f, -22.0f * f35);
            this.turn(bindRotInv.rot, this.kneeL, 1.0f, 0.0f, 0.0f, 38.0f * f35);
            this.turn(bindRotInv.rot, this.ankleL, 1.0f, 0.0f, 0.0f, -16.0f * f35);
            this.turn(bindRotInv.rot, this.spine1, 1.0f, 0.0f, 0.0f, 8.0f * f35);
        }
        if ((f4 = Root.window(f, 14.55f, 0.35f, 17.4f, 0.6f)) > 0.0f) {
            f7 = 0.5f + 0.5f * (float)Math.sin((double)(f - 14.7f) * Math.PI * 2.0 * 3.2);
            this.turn(bindRotInv.rot, this.jaw, 1.0f, 0.0f, 0.0f, (8.0f + 10.0f * f7) * f4);
            this.turn(bindRotInv.rot, this.head, 1.0f, 0.0f, 0.0f, -14.0f * f4);
            this.turn(bindRotInv.rot, this.chest, 1.0f, 0.0f, 0.0f, -5.0f * f4 * f7);
        }
        f7 = this.flyVel.length();
        f6 = Math.min(1.0f, f7 / 7.0f);
        f5 = Root.smooth(Root.span(f, 12.5f, 14.4f));
        float f36 = 0.25f + 0.75f * f6;
        for (n = 0; n < this.cloak.length; ++n) {
            f3 = f * (3.0f + 6.0f * f6) - (float)n * 0.85f;
            float f37 = (6.0f + 6.5f * (float)n) * (0.35f * f5 + f6) * 0.5f;
            this.turn(bindRotInv.rot, this.cloak[n], 1.0f, 0.0f, 0.0f, f37 + (float)Math.sin(f3) * (1.5f + 4.0f * f36) * (0.4f + 0.2f * (float)n));
            this.turn(bindRotInv.rot, this.cloak[n], 0.0f, 0.0f, 1.0f, (float)Math.sin(f3 * 0.7f + 1.3f) * 2.0f * f36);
        }
        for (n = 0; n < this.hair.length; ++n) {
            f3 = f * (2.2f + 5.0f * f6) - (float)n * 0.7f;
            this.turn(bindRotInv.rot, this.hair[n], 1.0f, 0.0f, 0.0f, 2.0f + 4.5f * (float)n * f6 + (float)Math.sin(f3) * (1.2f + 3.0f * f6));
            this.turn(bindRotInv.rot, this.hair[n], 0.0f, 0.0f, 1.0f, (float)Math.sin(f3 * 0.8f + 0.5f) * (1.0f + 2.5f * f6));
        }
        for (n = 1; n < this.hat.length; ++n) {
            f3 = f * (2.0f + 4.0f * f6) - (float)n * 0.6f;
            this.turn(bindRotInv.rot, this.hat[n], 1.0f, 0.0f, 0.0f, (float)n * 4.0f * f6 + (float)Math.sin(f3) * (1.0f + 2.0f * f6) * (float)n * 0.5f);
        }
        float f38 = (float)Math.sin(Math.PI * (double)Root.span(f, 12.5f, 13.299999f));
        bindRotInv.rootOffset.set(0.0f, -0.05f * f35 + 0.1f * Math.max(0.0f, f38) * (1.0f - f8 * 0.3f) - 0.045f * f9, 0.0f);
        bindRotInv.solve();
        if (!this.gripReady) {
            this.computeGrip();
        }
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)bindRotInv.world[this.wristL]).mul((Matrix4fc)this.heldGrip);
        Matrix4f matrix4f2 = this.seatedBroom(new Matrix4f());
        Matrix4f matrix4f3 = new Matrix4f((Matrix4fc)matrix4f2).translateLocal(0.36f, 0.06f, 0.02f);
        float f39 = Root.smooth(Root.span(f, 11.95f, 12.849999f));
        float f40 = Root.smooth(Root.span(f, 12.75f, 13.599999f));
        Matrix4f matrix4f4 = new Matrix4f();
        Root.blend(matrix4f, matrix4f3, f39, matrix4f4);
        Root.blend(matrix4f4, matrix4f2, f40, this.broom);
        float f41 = 0.0f;
        if (f >= 11.9f) {
            f41 = 0.62f * Root.smooth(Root.span(f, 12.5f, 14.299999f));
            f41 += 0.06f * (float)Math.sin((f - 11.9f) * 2.4f) * Root.smooth(Root.span(f, 13.599999f, 14.299999f));
        }
        this.fly(f, f14, f41, vector3d);
        if (this.exiting) {
            this.exitFade = Math.max(0.0f, this.exitFade - f14 / 0.9f);
        }
        if (f < 2.3f) {
            f2 = Root.span(f, 0.0f, 2.0f);
            this.dissolveMode = 1.0f;
            this.dissolveAt = -0.25f + 2.35f * (1.0f - (1.0f - f2) * (1.0f - f2) * (1.0f - f2));
        } else if (f >= this.vanishStart) {
            f2 = Root.span(f, this.vanishStart, this.vanishStart + 2.8f);
            this.dissolveMode = -1.0f;
            this.dissolveAt = -0.3f + 2.45f * Root.smooth(f2);
        } else {
            this.dissolveMode = 0.0f;
        }
        f2 = f >= this.vanishStart ? 1.0f - Root.smooth(Root.span(f, this.vanishStart + 1.54f, this.vanishStart + 2.8f)) : 1.0f;
        this.alpha = Root.smooth(Root.span(f, 0.0f, 0.35f)) * f2 * this.exitFade;
        float f42 = Math.max(1.0f - Root.smooth(Root.span(f, 2.2f, 3.7f)), this.casting * 0.7f);
        if (f >= this.vanishStart) {
            f42 = 1.0f;
        }
        this.glow = (0.45f + 0.55f * f42) * this.exitFade;
        this.finished = f >= this.vanishStart + 2.8f + 0.4f || this.exiting && this.exitFade <= 0.0f;
    }

    private float[] lookAngles(Vector3d vector3d) {
        Vector3f vector3f = this.model.transformPosition(this.rig.position(this.chest, new Vector3f()));
        Vector3f vector3f2 = new Vector3f((float)(vector3d.x - this.origin.x) - vector3f.x, (float)(vector3d.y - this.origin.y) - vector3f.y, (float)(vector3d.z - this.origin.z) - vector3f.z);
        new Matrix4f((Matrix4fc)this.model).invert().transformDirection(vector3f2);
        float f = (float)Math.toDegrees(Math.atan2(vector3f2.x, vector3f2.z));
        float f2 = (float)Math.toDegrees(Math.atan2(vector3f2.y, Math.sqrt(vector3f2.x * vector3f2.x + vector3f2.z * vector3f2.z)));
        return new float[]{f, f2};
    }

    private void computeGrip() {
        BindRotInv bindRotInv = this.rig;
        Vector3f vector3f = new Vector3f();
        for (int i = 1; i < 5; ++i) {
            vector3f.add((Vector3fc)bindRotInv.position(this.fingersL[i][0], this.v));
        }
        vector3f.div(4.0f);
        Vector3f vector3f2 = bindRotInv.position(this.wristL, new Vector3f());
        vector3f.lerp((Vector3fc)vector3f2, 0.35f);
        Matrix4f matrix4f = new Matrix4f().translation(vector3f.x + 0.012f, 0.0f, vector3f.z + 0.01f).rotateY((float)Math.toRadians(-20.0));
        this.heldGrip.set((Matrix4fc)bindRotInv.world[this.wristL]).invert().mul((Matrix4fc)matrix4f);
        this.gripReady = true;
    }

    private Matrix4f seatedBroom(Matrix4f matrix4f) {
        BindRotInv bindRotInv = this.rig;
        Vector3f vector3f = bindRotInv.position(this.wristL, new Vector3f());
        Vector3f vector3f2 = new Vector3f((Vector3fc)vector3f).add(-0.17f, 0.0f, 0.0f);
        Vector3f vector3f3 = bindRotInv.position(this.hipR, new Vector3f()).add((Vector3fc)bindRotInv.position(this.hipL, this.v)).mul(0.5f);
        vector3f3.y -= 0.115f;
        vector3f3.z -= 0.02f;
        Vector3f vector3f4 = new Vector3f((Vector3fc)vector3f2).sub((Vector3fc)vector3f3);
        vector3f4.y -= 0.02f;
        vector3f4.normalize();
        Vector3f vector3f5 = new Vector3f(1.0f, 0.0f, 0.0f);
        Vector3f vector3f6 = new Vector3f((Vector3fc)vector3f5).cross((Vector3fc)vector3f4).normalize();
        vector3f5.set((Vector3fc)vector3f4).cross((Vector3fc)vector3f6).normalize();
        Matrix4f matrix4f2 = new Matrix4f(vector3f5.x, vector3f5.y, vector3f5.z, 0.0f, vector3f4.x, vector3f4.y, vector3f4.z, 0.0f, vector3f6.x, vector3f6.y, vector3f6.z, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f);
        Vector3f vector3f7 = new Vector3f((Vector3fc)vector3f3).sub((Vector3fc)new Vector3f((Vector3fc)vector3f4).mul(0.74f));
        return matrix4f.translation((Vector3fc)vector3f7).mul((Matrix4fc)matrix4f2);
    }

    private static void blend(Matrix4f matrix4f, Matrix4f matrix4f2, float f, Matrix4f matrix4f3) {
        Vector3f vector3f = matrix4f.getTranslation(new Vector3f());
        Vector3f vector3f2 = matrix4f2.getTranslation(new Vector3f());
        Quaternionf quaternionf = matrix4f.getNormalizedRotation(new Quaternionf());
        Quaternionf quaternionf2 = matrix4f2.getNormalizedRotation(new Quaternionf());
        matrix4f3.translation((Vector3fc)vector3f.lerp((Vector3fc)vector3f2, f)).rotate((Quaternionfc)quaternionf.slerp((Quaternionfc)quaternionf2, f));
    }

    private void buildPath(Vector3f vector3f, Vector3d vector3d) {
        float f = (float)(vector3d.x - this.origin.x);
        float f2 = (float)(vector3d.z - this.origin.z);
        float f3 = (float)Math.atan2(vector3f.z - f2, vector3f.x - f);
        float f4 = Math.max(4.0f, (float)Math.hypot(vector3f.x - f, vector3f.z - f2));
        float[][] fArrayArray = new float[][]{{0.0f, 0.0f, 0.0f},new float[]{0.32f, 1.0f, 1.8f},new float[]{0.95f, 2.5f, 4.4f},new float[]{1.65f, 4.0f, 7.2f},new float[]{2.4f, 5.5f, 10.0f},new float[]{3.15f, 7.5f, 13.0f},new float[]{3.85f, 11.0f, 17.0f},new float[]{4.45f, 19.0f, 23.0f},new float[]{4.85f, 32.0f, 31.0f},new float[]{5.1f, 48.0f, 40.0f}};
        this.path = new Vector3f[fArrayArray.length];
        float f5 = vector3f.y;
        for (int i = 0; i < fArrayArray.length; ++i) {
            Vector3f vector3f2;
            float f6 = f3 + fArrayArray[i][0];
            float f7 = f4 + fArrayArray[i][1];
            Vector3f vector3f3 = vector3f2 = i == 0 ? new Vector3f((Vector3fc)vector3f) : new Vector3f(f + (float)Math.cos(f6) * f7, vector3f.y + fArrayArray[i][2], f2 + (float)Math.sin(f6) * f7);
            if (i > 0) {
                double d;
                if (this.ground != null && !Double.isNaN(d = this.ground.top(this.origin.x + (double)vector3f2.x, this.origin.z + (double)vector3f2.z))) {
                    vector3f2.y = Math.max(vector3f2.y, (float)(d - this.origin.y) + 3.6f);
                }
                vector3f2.y = Math.max(vector3f2.y, f5 + 0.4f);
            }
            f5 = vector3f2.y;
            this.path[i] = vector3f2;
        }
    }

    private Vector3f pathAt(float f, Vector3f vector3f) {
        int n = this.path.length;
        f = Math.max(0.0f, Math.min((float)n - 1.001f, f));
        int n2 = (int)f;
        float f2 = f - (float)n2;
        Vector3f vector3f2 = this.path[Math.max(0, n2 - 1)];
        Vector3f vector3f3 = this.path[n2];
        Vector3f vector3f4 = this.path[Math.min(n - 1, n2 + 1)];
        Vector3f vector3f5 = this.path[Math.min(n - 1, n2 + 2)];
        float f3 = f2 * f2;
        float f4 = f3 * f2;
        for (int i = 0; i < 3; ++i) {
            float f5 = vector3f2.get(i);
            float f6 = vector3f3.get(i);
            float f7 = vector3f4.get(i);
            float f8 = vector3f5.get(i);
            vector3f.setComponent(i, 0.5f * (2.0f * f6 + (-f5 + f7) * f2 + (2.0f * f5 - 5.0f * f6 + 4.0f * f7 - f8) * f3 + (-f5 + 3.0f * f6 - 3.0f * f7 + f8) * f4));
        }
        return vector3f;
    }

    private void fly(float f, float f2, float f3, Vector3d vector3d) {
        Vector3f vector3f;
        Vector3f vector3f2;
        if (f < 14.7f) {
            this.flyPos.set(0.0f, f3, 0.0f);
            this.flyVel.zero();
            this.flyYaw = this.bodyYaw;
            this.flyYawVel = 0.0f;
            this.flyRoll = 0.0f;
            this.flyRollVel = 0.0f;
            this.pathS = 0.0f;
            this.flyPitch = -0.16f * Root.smooth(Root.span(f, 13.7f, 14.7f));
            this.flyPitchVel = 0.0f;
            this.model.translation((Vector3fc)this.flyPos).rotateY(this.flyYaw).rotateX(this.flyPitch);
            return;
        }
        if (this.path == null) {
            this.buildPath(new Vector3f(0.0f, f3, 0.0f), vector3d);
        }
        float f4 = f - 14.7f;
        float f5 = 7.0f * Root.smooth(Root.span(f4, 0.0f, 2.8f)) + 0.35f;
        Vector3f vector3f3 = this.pathAt(this.pathS, new Vector3f());
        Vector3f vector3f4 = this.pathAt(this.pathS + 0.02f, new Vector3f());
        float f6 = Math.max(0.05f, vector3f4.distance((Vector3fc)vector3f3) / 0.02f);
        this.pathS += f5 * f2 / f6;
        if (this.vanishStart == Float.MAX_VALUE && (this.pathS > (float)this.path.length - 2.4f || f4 > 12.5f)) {
            this.vanishStart = f;
        }
        Vector3f vector3f5 = vector3f2 = this.pathS >= (float)this.path.length - 1.01f ? new Vector3f((Vector3fc)this.flyPos).fma(f2, (Vector3fc)this.flyVel) : this.pathAt(this.pathS, new Vector3f());
        if (f2 > 0.0f) {
            vector3f = new Vector3f((Vector3fc)vector3f2).sub((Vector3fc)this.flyPos).div(f2);
            this.flyVel.lerp((Vector3fc)vector3f, 1.0f - (float)Math.exp(-f2 * 12.0f));
        }
        this.flyPos.set((Vector3fc)vector3f2);
        vector3f = this.pathAt(this.pathS + 0.22f, new Vector3f()).sub((Vector3fc)vector3f2);
        if (vector3f.lengthSquared() < 1.0E-6f) {
            vector3f.set((Vector3fc)this.flyVel);
        }
        float f7 = vector3f.lengthSquared() > 1.0E-6f ? (float)Math.atan2(vector3f.x, vector3f.z) : this.flyYaw;
        float f8 = (float)Math.sqrt(vector3f.x * vector3f.x + vector3f.z * vector3f.z);
        float f9 = -((float)Math.atan2(vector3f.y, Math.max(0.05f, f8))) * 0.5f;
        float f10 = 7.0f;
        float f11 = 2.0f * (float)Math.sqrt(f10);
        this.flyYawVel += (Root.wrap(f7 - this.flyYaw) * f10 - this.flyYawVel * f11) * f2;
        this.flyYaw = Root.wrap(this.flyYaw + this.flyYawVel * f2);
        this.flyPitchVel += ((f9 - this.flyPitch) * f10 - this.flyPitchVel * f11) * f2;
        this.flyPitch += this.flyPitchVel * f2;
        float f12 = Math.max(-0.55f, Math.min(0.55f, -this.flyYawVel * 0.5f));
        this.flyRollVel += ((f12 - this.flyRoll) * 5.0f - this.flyRollVel * 2.0f * (float)Math.sqrt(5.0)) * f2;
        this.flyRoll += this.flyRollVel * f2;
        float f13 = 0.06f * (float)Math.sin(f * 2.6f);
        this.model.translation(this.flyPos.x, this.flyPos.y + f13, this.flyPos.z).rotateY(this.flyYaw).rotateX(this.flyPitch).rotateZ(this.flyRoll);
    }

    public Vector3f broomTail(Vector3f vector3f) {
        return new Matrix4f((Matrix4fc)this.model).mul((Matrix4fc)this.broom).transformPosition(vector3f.set(0.0f, 0.22f, 0.0f));
    }

    public Vector3f center(Vector3f vector3f) {
        return this.model.transformPosition(this.rig.position(this.chest, vector3f));
    }

    public Vector3f rightHand(Vector3f vector3f) {
        Vector3f vector3f2 = new Vector3f();
        for (int i = 1; i < 5; ++i) {
            vector3f2.add((Vector3fc)this.rig.position(this.fingersR[i][0], this.v));
        }
        vector3f2.div(4.0f);
        return this.model.transformPosition(vector3f.set((Vector3fc)vector3f2));
    }

    public Vector3f bodyAt(float f, float f2, Vector3f vector3f) {
        float f3 = f > 1.45f ? 0.22f : (f > 0.9f ? 0.2f : 0.16f);
        vector3f.set((float)Math.cos(f2) * f3, f, (float)Math.sin(f2) * f3);
        return this.model.transformPosition(vector3f);
    }

    public Vector3f velocity(Vector3f vector3f) {
        return vector3f.set((Vector3fc)this.flyVel);
    }

    public float speed() {
        return this.flyVel.length();
    }
}
