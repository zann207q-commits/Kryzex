package kryzex.cinematic;

import kryzex.gui.BaseRenderer;
import kryzex.gui.GuiRenderer;
import kryzex.gui.SpeakerOff;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class BarsWanted {
    private static boolean barsWanted;
    private static float bars;
    private static boolean hudWanted;
    private static boolean hudShown;
    private static float dip;
    private static float vignette;
    private static float notice;
    private static String noticeText;

    private BarsWanted() {
    }

    public static void cinematic(boolean bl) {
        barsWanted = bl;
        if (hudWanted != bl) return;
        boolean bl2 = hudWanted = !bl;
        if (!(dip < 0.0f)) return;
        dip = 0.0f;
    }

    public static void reset() {
        barsWanted = false;
        bars = 0.0f;
        hudWanted = true;
        hudShown = true;
        dip = -1.0f;
        vignette = 0.0f;
    }

    public static void notice(String string) {
        noticeText = string;
        notice = 2.2f;
    }

    public static boolean hideHud() {
        if (hudShown) return false;
        return true;
    }

    public static boolean visible() {
        if (bars > 0.001f) return true;
        if (dip >= 0.0f) return true;
        if (notice > 0.0f) return true;
        if (!(vignette > 0.001f)) return false;
        return true;
    }

    public static void frame(float f) {
        float f2 = barsWanted ? 1.0f : 0.0f;
        bars = bars < f2 ? Math.min(f2, bars + f / 0.85f) : Math.max(f2, bars - f / 0.75f);
        float f3 = vignette = vignette < f2 ? Math.min(f2, vignette + f / 1.4f) : Math.max(f2, vignette - f / 0.9f);
        if (dip >= 0.0f) {
            if ((dip += f / 0.7f) >= 0.5f && hudShown != hudWanted) {
                hudShown = hudWanted;
            }
            if (dip >= 1.0f) {
                dip = -1.0f;
                hudShown = hudWanted;
            }
        }
        if (!(notice > 0.0f)) return;
        notice -= f;
    }

    private static float smooth(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
    }

    public static void render(class_332 class_3322) {
        if (!BarsWanted.visible()) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        class_1041 class_10412 = class_3102.method_22683();
        int n = class_10412.method_4489();
        int n2 = class_10412.method_4506();
        float f = class_10412.method_4495();
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().scale(1.0f / f, 1.0f / f);
        try {
            float f2;
            float f3;
            float f4;
            GuiRenderer guiRenderer = new GuiRenderer(class_3322, f);
            float f5 = BarsWanted.smooth(vignette);
            if (f5 > 0.001f) {
                f4 = Math.max(n, n2);
                guiRenderer.glow(0.0f, 0.0f, f4 * 0.55f, BaseRenderer.argb(0.42f * f5, 0, 0, 0));
                guiRenderer.glow(n, 0.0f, f4 * 0.55f, BaseRenderer.argb(0.42f * f5, 0, 0, 0));
                guiRenderer.glow(0.0f, n2, f4 * 0.55f, BaseRenderer.argb(0.42f * f5, 0, 0, 0));
                guiRenderer.glow(n, n2, f4 * 0.55f, BaseRenderer.argb(0.42f * f5, 0, 0, 0));
            }
            if ((f4 = BarsWanted.smooth(bars)) > 0.001f) {
                f3 = (float)n2 * 0.105f * f4;
                f2 = (float)n2 * 0.02f;
                guiRenderer.rect(0.0f, 0.0f, n, f3, BaseRenderer.argb(0.97f, 3, 2, 5));
                guiRenderer.gradient(0.0f, f3, n, f2, BaseRenderer.argb(0.55f * f4, 3, 2, 5), BaseRenderer.argb(0.0f, 3, 2, 5));
                guiRenderer.rect(0.0f, (float)n2 - f3, n, f3, BaseRenderer.argb(0.97f, 3, 2, 5));
                guiRenderer.gradient(0.0f, (float)n2 - f3 - f2, n, f2, BaseRenderer.argb(0.0f, 3, 2, 5), BaseRenderer.argb(0.55f * f4, 3, 2, 5));
            }
            if (dip >= 0.0f) {
                f3 = (float)Math.sin(Math.PI * (double)Math.min(1.0f, dip));
                guiRenderer.rect(0.0f, 0.0f, n, n2, BaseRenderer.argb(0.72f * f3 * f3, 2, 1, 4));
            }
            if (!(notice > 0.0f)) return;
            f3 = Math.min(1.0f, notice / 0.4f) * Math.min(1.0f, (2.2f - notice) / 0.25f);
            f2 = (float)n2 / 1080.0f;
            float f6 = 15.0f * f2;
            float f7 = guiRenderer.textWidth(noticeText, f6, 0);
            float f8 = f7 + 64.0f * f2;
            float f9 = 40.0f * f2;
            float f10 = ((float)n - f8) / 2.0f;
            float f11 = (float)n2 * 0.13f + (1.0f - f3) * 8.0f * f2;
            guiRenderer.pushAlpha(f3);
            guiRenderer.shadow(f10, f11, f8, f9, f9 / 2.0f, 16.0f * f2, BaseRenderer.argb(0.45f, 0, 0, 0));
            guiRenderer.round(f10, f11, f8, f9, f9 / 2.0f, BaseRenderer.argb(0.86f, 24, 16, 28));
            guiRenderer.outline(f10, f11, f8, f9, f9 / 2.0f, Math.max(1.0f, f2), BaseRenderer.argb(0.5f, 255, 150, 70));
            guiRenderer.icon(SpeakerOff.MONITOR, f10 + 18.0f * f2, f11 + (f9 - 18.0f * f2) / 2.0f, 18.0f * f2, BaseRenderer.argb(0.9f, 255, 170, 90));
            guiRenderer.text(noticeText, f10 + 46.0f * f2, f11 + (f9 - f6) / 2.0f - f2, f6, 0, BaseRenderer.argb(1.0f, 240, 234, 232));
            guiRenderer.popAlpha();
            return;
        }
        finally {
            class_3322.method_51448().popMatrix();
        }
    }

    static {
        hudWanted = true;
        hudShown = true;
        dip = -1.0f;
        noticeText = "";
    }
}
