package kryzex.cinematic;

import kryzex.modules.render.Halloween;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_2874;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class UnderValid {
    private static final double NIGHT = 15200.0;
    private static final int NONE = 0;
    private static final int TO_NIGHT = 1;
    private static final int HOLD = 2;
    private static final int TO_REAL = 3;
    private static boolean wanted;
    private static float raw;
    private static int mode;
    private static double from;
    private static double delta;
    private static double progress;
    private static double duration;
    private static double vis;
    private static float outdoor;
    private static float under;
    private static boolean underValid;
    private static float lit;
    private static class_2338.class_2339 PROBE;
    private static int[] PROBES;
    private static int[] COLUMNS;
    private static float moonAngle;
    private static boolean moonValid;
    private static class_1937 world;

    private UnderValid() {
    }

    public static void setWanted(boolean bl) {
        wanted = bl;
        if (bl || mode != 1 && mode != 2) return;
        UnderValid.beginToReal();
    }

    public static float strength() {
        float f = Math.max(0.0f, Math.min(1.0f, raw));
        return f * f * (3.0f - 2.0f * f);
    }

    public static float darkness() {
        return UnderValid.strength() * (float)(Halloween.darkness.getValue() / 100.0) * (0.35f + 0.65f * UnderValid.nightness());
    }

    public static float nightness() {
        double d = mode != 0 ? UnderValid.mod(vis) : (world != null ? UnderValid.mod(world.method_8401().method_217()) : 18000.0);
        if (d >= 12000.0 && d < 13800.0) {
            return (float)UnderValid.smooth((d - 12000.0) / 1800.0);
        }
        if (d >= 13800.0 && d < 22200.0) {
            return 1.0f;
        }
        if (!(d >= 22200.0)) return 0.0f;
        return (float)UnderValid.smooth((24000.0 - d) / 1800.0);
    }

    private static double mod(double d) {
        double d2 = d % 24000.0;
        return d2 < 0.0 ? d2 + 24000.0 : d2;
    }

    private static double smooth(double d) {
        d = Math.max(0.0, Math.min(1.0, d));
        return d * d * d * (d * (d * 6.0 - 15.0) + 10.0);
    }

    private static boolean skyWorld(class_638 class_6382) {
        try {
            if (class_6382.method_8597().comp_5220() != class_2874.class_12326.field_64386) return false;
            if (!class_6382.method_8597().comp_642()) return false;
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    public static void frame(float f, class_310 class_3102) {
        float f2;
        class_638 class_6382 = class_3102.field_1687;
        if (class_6382 != world) {
            world = class_6382;
            mode = 0;
            raw = 0.0f;
            outdoor = 1.0f;
            under = 0.0f;
            underValid = false;
            lit = 0.0f;
            moonValid = false;
        }
        if (class_6382 == null) {
            return;
        }
        float f3 = wanted ? 1.0f : 0.0f;
        float f4 = f / 3.2f;
        raw = raw < f3 ? Math.min(f3, raw + f4) : Math.max(f3, raw - f4);
        boolean bl = UnderValid.skyWorld(class_6382);
        double d = class_6382.method_28104().method_217();
        if (wanted && bl && (mode == 0 || mode == 3)) {
            UnderValid.beginToNight(d);
        }
        if (!bl && mode != 0) {
            mode = 0;
        }
        switch (mode) {
            case 1: {
                vis = from + delta * UnderValid.smooth(progress += (double)f / duration);
                if (!(progress >= 1.0)) break;
                mode = 2;
                vis = from + delta;
                break;
            }
            case 3: {
                double d2 = UnderValid.mod(d - UnderValid.mod(from));
                if (d2 > 21000.0) {
                    d2 -= 24000.0;
                }
                vis = from + d2 * UnderValid.smooth(progress += (double)f / duration);
                if (!(progress >= 1.0)) break;
                mode = 0;
                break;
            }
        }
        class_4184 class_41842 = class_3102.field_1773.method_19418();
        if (class_41842 == null || !class_41842.method_19332()) return;
        class_243 class_2432 = class_41842.method_71156();
        float f5 = f2 = bl ? UnderValid.measureUnder(class_6382, class_2432) : 0.0f;
        if (!underValid) {
            under = f2;
            underValid = true;
        } else {
            under += (f2 - under) * (1.0f - (float)Math.exp(-f / 1.4f));
        }
        outdoor = 1.0f - under;
        int n = class_6382.method_8314(class_1944.field_9282, class_2338.method_49638((class_2374)class_2432));
        lit += ((float)n / 15.0f - lit) * (1.0f - (float)Math.exp(-f / 0.9f));
    }

    private static float measureUnder(class_638 class_6382, class_243 class_2432) {
        int n = class_3532.method_15357((double)class_2432.field_1352);
        int n2 = class_3532.method_15357((double)class_2432.field_1351);
        int n3 = class_3532.method_15357((double)class_2432.field_1350);
        float f = 0.0f;
        float f2 = 0.0f;
        for (int i = 0; i < PROBES.length; i += 3) {
            PROBE.method_10103(n + PROBES[i], n2 + PROBES[i + 1], n3 + PROBES[i + 2]);
            int n4 = class_6382.method_8314(class_1944.field_9284, (class_2338)PROBE);
            f += (float)n4;
            f2 = Math.max(f2, (float)n4);
        }
        float f3 = (0.6f * f / (float)(PROBES.length / 3) + 0.4f * f2) / 15.0f;
        float f4 = 1.0f - (float)UnderValid.smooth((f3 - 0.3f) / 0.56f);
        float f5 = 0.0f;
        for (int i = 0; i < COLUMNS.length; i += 2) {
            f5 += (float)class_6382.method_8624(class_2902.class_2903.field_13203, n + COLUMNS[i], n3 + COLUMNS[i + 1]);
        }
        float f6 = Math.max(0.0f, Math.min(1.0f, ((f5 /= (float)(COLUMNS.length / 2)) - (float)class_2432.field_1351 - 1.0f) / 12.0f));
        return f4 * (0.6f + 0.4f * f6);
    }

    private static void beginToNight(double d) {
        double d2;
        double d3 = mode == 3 ? vis : d;
        double d4 = UnderValid.mod(d3);
        if (d4 >= 12500.0) {
            d2 = 15200.0 - d4;
            if (d2 < -11000.0) {
                d2 += 24000.0;
            }
        } else {
            d2 = UnderValid.mod(15200.0 - d4);
        }
        double d5 = 0.0;
        if (d4 < 11000.0) {
            long l = (long)Math.floor((d3 + d2) / 24000.0);
            d5 = (double)(-Math.floorMod(l, 8L)) * 24000.0;
        }
        from = d3 + d5;
        delta = d2;
        progress = 0.0;
        duration = Math.max(2.6, Math.min(8.5, 2.6 + Math.abs(d2) / 13000.0 * 6.0));
        vis = from;
        mode = 1;
    }

    private static void beginToReal() {
        if (world == null) {
            mode = 0;
            return;
        }
        double d = world.method_8401().method_217();
        double d2 = UnderValid.mod(d - UnderValid.mod(vis));
        from = vis;
        progress = 0.0;
        duration = Math.max(2.6, Math.min(7.0, 2.6 + Math.abs(d2 > 21000.0 ? d2 - 24000.0 : d2) / 13000.0 * 5.0));
        mode = 3;
    }

    public static long timeOfDay(class_1937 class_19372, long l) {
        if (mode != 0 && class_19372 == world) return (long)Math.floor(vis);
        return l;
    }

    public static float lightmap(int n, float f) {
        float f2;
        float f3 = UnderValid.strength();
        if (f3 <= 0.0f) {
            return f;
        }
        float f4 = UnderValid.darkness();
        float f5 = under;
        switch (n) {
            case 1: {
                f2 = f * (1.0f - 0.66f * f4);
                return f2;
            }
            case 2: {
                f2 = f * (1.0f - 0.3f * f4 * (1.0f - 0.6f * f5));
                return f2;
            }
            case 3: {
                f2 = f * (1.0f - f3) + f3 * UnderValid.ambientFloor(f5);
                return f2;
            }
            case 5: {
                f2 = f + (1.0f - f) * 0.4f * f4 * (1.0f - f5);
                return f2;
            }
            case 6: {
                f2 = f * (1.0f - f3);
                return f2;
            }
            default: {
                f2 = f;
            }
        }
        return f2;
    }

    private static float ambientFloor(float f) {
        float f2 = (float)(Halloween.darkness.getValue() / 100.0);
        float f3 = 0.066f;
        float f4 = 0.19f - 0.045f * f2;
        float f5 = f3 + (f4 - f3) * f;
        return Math.max(0.0f, ((f5 - 0.03f) / 0.96f - 0.03f) / 0.97f);
    }

    public static Vector3f skyLight(Vector3f vector3f) {
        float f = UnderValid.strength();
        if (!(f > 0.0f)) return vector3f;
        vector3f.mul(1.0f + -0.19999999f * f, 1.0f + -0.24000001f * f, 1.0f + 0.059999943f * f);
        return vector3f;
    }

    public static float fogAmount() {
        float f = UnderValid.strength();
        if (f <= 0.0f) {
            return 0.0f;
        }
        float f2 = (float)(Halloween.fogDensity.getValue() / 100.0);
        return f * (float)Math.pow(f2, 0.8) * (0.18f + 0.82f * outdoor) * (0.4f + 0.6f * UnderValid.nightness());
    }

    private static float nearEnd() {
        float f = (float)(Halloween.fogDensity.getValue() / 100.0);
        return (150.0f + -126.0f * f) * (1.0f + 0.6f * lit);
    }

    public static void fog(float[] fArray, Vector4f vector4f) {
        float f = UnderValid.fogAmount();
        if (f <= 0.0f) {
            return;
        }
        float f2 = UnderValid.nearEnd();
        fArray[0] = UnderValid.lerp(fArray[0], Math.min(fArray[0], f2 * 0.03f), f);
        fArray[1] = UnderValid.lerp(fArray[1], Math.min(fArray[1], f2), f);
        fArray[4] = UnderValid.lerp(fArray[4], Math.min(fArray[4], f2 * 1.45f), f);
        fArray[5] = UnderValid.lerp(fArray[5], Math.min(fArray[5], f2 * 2.2f), f);
        float f3 = f * 0.9f;
        vector4f.x = UnderValid.lerp(vector4f.x, 0.08f, f3);
        vector4f.y = UnderValid.lerp(vector4f.y, 0.066f, f3);
        vector4f.z = UnderValid.lerp(vector4f.z, 0.108f, f3);
    }

    private static float lerp(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }

    public static int skyColor(int n) {
        return UnderValid.mixRgb(n, 1510692, UnderValid.strength() * 0.78f * UnderValid.nightness());
    }

    public static int sunset(int n) {
        return n & 0xFF000000 | UnderValid.mixRgb(n, 16735778, UnderValid.strength() * 0.8f) & 0xFFFFFF;
    }

    public static int clouds(int n) {
        float f = UnderValid.strength() * (0.3f + 0.7f * UnderValid.nightness());
        int n2 = Math.round((float)(n >>> 24) * (1.0f - 0.6f * f));
        return n2 << 24 | UnderValid.mixRgb(n, 2761270, f * 0.85f) & 0xFFFFFF;
    }

    public static float stars(float f) {
        return f * (1.0f + 0.35f * UnderValid.strength());
    }

    private static int mixRgb(int n, int n2, float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        int n3 = Math.round((float)(n >> 16 & 0xFF) + (float)((n2 >> 16 & 0xFF) - (n >> 16 & 0xFF)) * f);
        int n4 = Math.round((float)(n >> 8 & 0xFF) + (float)((n2 >> 8 & 0xFF) - (n >> 8 & 0xFF)) * f);
        int n5 = Math.round((float)(n & 0xFF) + (float)((n2 & 0xFF) - (n & 0xFF)) * f);
        return n & 0xFF000000 | n3 << 16 | n4 << 8 | n5;
    }

    public static void moonAngle(float f) {
        moonAngle = f;
        moonValid = true;
    }

    public static Vector4f moonDir() {
        if (!moonValid) {
            return new Vector4f(0.0f, 1.0f, 0.0f, 0.0f);
        }
        float f = -((float)Math.sin(moonAngle));
        float f2 = (float)Math.cos(moonAngle);
        return new Vector4f(f, f2, 0.0f, Math.max(0.0f, Math.min(1.0f, (f2 + 0.08f) / 0.25f)));
    }

    public static float outdoor() {
        return outdoor;
    }

    public static float under() {
        return under;
    }

    public static float lit() {
        return lit;
    }

    public static boolean overridingTime() {
        if (mode == 0) return false;
        return true;
    }

    static {
        mode = 0;
        duration = 1.0;
        outdoor = 1.0f;
        PROBE = new class_2338.class_2339();
        PROBES = new int[]{0, 0, 0, 0, 2, 0, 0, 6, 0, 3, 1, 0, -3, 1, 0, 0, 1, 3, 0, 1, -3};
        COLUMNS = new int[]{0, 0, 4, 0, -4, 0, 0, 4, 0, -4};
    }
}
