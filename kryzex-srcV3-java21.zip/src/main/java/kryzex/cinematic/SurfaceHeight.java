package kryzex.cinematic;

public interface SurfaceHeight {
    public double top(double var1, double var3);
}
