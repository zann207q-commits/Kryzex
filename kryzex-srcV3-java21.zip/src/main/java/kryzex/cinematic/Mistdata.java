package kryzex.cinematic;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import kryzex.cinematic.HalloweenShaders;
import kryzex.cinematic.Skydata;
import kryzex.cinematic.UnderValid;
import net.minecraft.class_1011;
import net.minecraft.class_10789;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9801;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.BufferUtils;

public final class Mistdata {
    private static final int CELL = 7;
    private static final int RANGE = 6;
    private static final float FAR = 40.0f;
    private static final int UBO_SIZE = 96;
    public static final RenderPipeline PIPELINE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/hw_mist")).withVertexShader(HalloweenShaders.MIST).withFragmentShader(HalloweenShaders.MIST).withUniform("Projection", class_10789.field_60031).withUniform("Fog", class_10789.field_60031).withUniform("MistData", class_10789.field_60031).withSampler("Sampler0").withSampler("DepthSampler").withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382).build();
    private static GpuTexture puff;
    private static GpuTextureView puffView;
    private static GpuBuffer ubo;
    private static ByteBuffer data;
    private static float fade;
    private static long lastNanos;

    private Mistdata() {
    }

    private static float hash(int n, int n2, int n3) {
        int n4 = n * 73856093 ^ n2 * 19349663 ^ n3 * 83492791;
        n4 = (n4 ^ n4 >>> 13) * 1274126177;
        return (float)((n4 ^ n4 >>> 16) & 0xFFFF) / 65535.0f;
    }

    public static void draw(class_4184 class_41842) {
        class_310 class_3102 = class_310.method_1551();
        class_638 class_6382 = class_3102.field_1687;
        long l = System.nanoTime();
        float f = lastNanos == 0L ? 0.016f : Math.min(0.1f, (float)(l - lastNanos) / 1.0E9f);
        lastNanos = l;
        float f2 = UnderValid.fogAmount() * UnderValid.outdoor() * UnderValid.nightness();
        if ((fade += (f2 - fade) * (1.0f - (float)Math.exp(-f / 0.9f))) < 0.004f || class_6382 == null || class_41842 == null || !Skydata.hasMatrices()) {
            return;
        }
        if (!HalloweenShaders.ready(PIPELINE)) {
            return;
        }
        try {
            float f3;
            float f4;
            Mistdata.ensure();
            class_243 class_2432 = class_41842.method_71156();
            Matrix4f matrix4f = Skydata.view();
            Matrix4f matrix4f2 = new Matrix4f((Matrix4fc)Skydata.projection()).mul((Matrix4fc)matrix4f);
            FrustumIntersection frustumIntersection = new FrustumIntersection((Matrix4fc)matrix4f2);
            float f5 = matrix4f.m00();
            float f6 = matrix4f.m10();
            float f7 = matrix4f.m20();
            float f8 = matrix4f.m01();
            float f9 = matrix4f.m11();
            float f10 = matrix4f.m21();
            float f11 = ((float)(class_6382.method_75260() % 240000L) + class_3102.method_61966().method_60637(false)) / 20.0f;
            float f12 = 1.0f - 0.55f * UnderValid.darkness();
            int n = Math.round(150.0f * f12);
            int n2 = Math.round(142.0f * f12);
            int n3 = Math.round(176.0f * f12);
            int n4 = Math.floorDiv((int)Math.floor(class_2432.field_1352), 7);
            int n5 = Math.floorDiv((int)Math.floor(class_2432.field_1350), 7);
            class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
            int n6 = 0;
            class_2338.class_2339 class_23392 = new class_2338.class_2339();
            for (int i = -6; i <= 6; ++i) {
                for (int j = -6; j <= 6; ++j) {
                    int n7 = n4 + i;
                    int n8 = n5 + j;
                    for (int k = 0; k < 2; ++k) {
                        int n9;
                        double d;
                        double d2;
                        int n10;
                        f4 = Mistdata.hash(n7, n8, k);
                        if (f4 < 0.18f) continue;
                        f3 = (f4 * 7.0f + f11 * (0.035f + 0.02f * f4)) % 1.0f;
                        float f13 = (float)Math.sin(Math.PI * (double)f3);
                        double d3 = (double)((float)(n7 * 7) + Mistdata.hash(n7, n8, 9 + k) * 7.0f) + (double)(f3 * 7.0f) * 0.9;
                        double d4 = (double)((float)(n8 * 7) + Mistdata.hash(n7, n8, 17 + k) * 7.0f) + (double)(f3 * 7.0f) * 0.35;
                        int n11 = (int)Math.floor(d3);
                        if (!class_6382.method_8393(n11 >> 4, (n10 = (int)Math.floor(d4)) >> 4) || (d2 = (d = (double)(n9 = class_6382.method_8624(class_2902.class_2903.field_13197, n11, n10)) + 0.55 + (double)k * 0.9 + (double)Mistdata.hash(n7, n8, 31 + k) * 0.8) - class_2432.field_1351) > 22.0 || d2 < -26.0) continue;
                        float f14 = 3.2f + f4 * 3.4f + (float)k * 1.2f;
                        float f15 = (float)(d3 - class_2432.field_1352);
                        float f16 = (float)d2;
                        float f17 = (float)(d4 - class_2432.field_1350);
                        float f18 = (float)Math.sqrt(f15 * f15 + f17 * f17);
                        float f19 = 1.0f - Mistdata.smooth((f18 - 28.0f) / 12.0f);
                        if (f19 <= 0.0f || !frustumIntersection.testSphere(f15, f16, f17, f14 * 1.2f)) continue;
                        class_23392.method_10103(n11, n9, n10);
                        float f20 = (float)class_6382.method_8314(class_1944.field_9282, (class_2338)class_23392) / 15.0f;
                        float f21 = (0.1f + 0.1f * f4) * fade * f13 * f19 * (1.0f - 0.65f * f20);
                        if (f21 < 0.003f) continue;
                        int n12 = Math.min(255, Math.round(f21 * 255.0f));
                        float f22 = k == 0 ? 0.0f : 1.0f;
                        float f23 = 1.0f - f22;
                        class_2872.method_22912(f15 - f5 * f14 - f8 * f14, f16 - f6 * f14 - f9 * f14, f17 - f7 * f14 - f10 * f14).method_22913(f22, 1.0f).method_1336(n, n2, n3, n12);
                        class_2872.method_22912(f15 + f5 * f14 - f8 * f14, f16 + f6 * f14 - f9 * f14, f17 + f7 * f14 - f10 * f14).method_22913(f23, 1.0f).method_1336(n, n2, n3, n12);
                        class_2872.method_22912(f15 + f5 * f14 + f8 * f14, f16 + f6 * f14 + f9 * f14, f17 + f7 * f14 + f10 * f14).method_22913(f23, 0.0f).method_1336(n, n2, n3, n12);
                        class_2872.method_22912(f15 - f5 * f14 + f8 * f14, f16 - f6 * f14 + f9 * f14, f17 - f7 * f14 + f10 * f14).method_22913(f22, 0.0f).method_1336(n, n2, n3, n12);
                        ++n6;
                    }
                }
            }
            class_9801 class_98012 = class_2872.method_60794();
            if (class_98012 == null || n6 == 0) {
                if (class_98012 == null) return;
                class_98012.close();
                return;
            }
            try (class_9801 class_98013 = class_98012;){
                class_310 class_3103 = class_310.method_1551();
                class_276 class_2762 = class_3103.method_1522();
                Matrix4f matrix4f3 = Skydata.projection();
                f4 = matrix4f3.m32() / (matrix4f3.m22() - 1.0f);
                f3 = matrix4f3.m32() / (matrix4f3.m22() + 1.0f);
                data.clear();
                matrix4f.get(0, data);
                Skydata.put4(data, 64, f4, f3, 1.6f, 0.0f);
                Skydata.put4(data, 80, class_2762.field_1482, class_2762.field_1481, 0.0f, 0.0f);
                data.position(0);
                data.limit(96);
                CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
                commandEncoder.writeToBuffer(ubo.slice(), data);
                GpuBuffer gpuBuffer = PIPELINE.getVertexFormat().uploadImmediateVertexBuffer(class_98012.method_60818());
                RenderSystem.class_5590 class_55902 = RenderSystem.getSequentialBuffer((VertexFormat.class_5596)VertexFormat.class_5596.field_27382);
                GpuBuffer gpuBuffer2 = class_55902.method_68274(class_98012.method_60822().comp_751());
                GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_2762.method_71639();
                try (RenderPass renderPass = commandEncoder.createRenderPass(Mistdata::lmbd$draw$0, gpuTextureView, OptionalInt.empty());){
                    renderPass.setPipeline(PIPELINE);
                    RenderSystem.bindDefaultUniforms((RenderPass)renderPass);
                    renderPass.setUniform("MistData", ubo);
                    renderPass.bindTexture("Sampler0", puffView, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
                    renderPass.bindTexture("DepthSampler", class_2762.method_71640(), RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST));
                    renderPass.setVertexBuffer(0, gpuBuffer);
                    renderPass.setIndexBuffer(gpuBuffer2, class_55902.method_31924());
                    renderPass.drawIndexed(0, 0, class_98012.method_60822().comp_751(), 1);
                    return;
                }
            }
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: Halloween mist skipped: " + String.valueOf(throwable));
        }
    }

    private static float smooth(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * (3.0f - 2.0f * f);
    }

    private static void ensure() {
        if (puff != null) {
            return;
        }
        GpuDevice gpuDevice = RenderSystem.getDevice();
        int n = 96;
        puff = gpuDevice.createTexture(Mistdata::lmbd$ensure$0, 5, TextureFormat.RGBA8, n, n, 1, 1);
        try (class_1011 class_10112 = new class_1011(n, n, false);){
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    float f = ((float)j + 0.5f) / (float)n * 2.0f - 1.0f;
                    float f2 = ((float)i + 0.5f) / (float)n * 2.0f - 1.0f;
                    float f3 = (float)Math.sqrt(f * f + f2 * f2);
                    float f4 = Math.max(0.0f, 1.0f - f3);
                    f4 = f4 * f4 * (3.0f - 2.0f * f4);
                    float f5 = 0.0f;
                    float f6 = 0.5f;
                    float f7 = 2.5f;
                    for (int k = 0; k < 4; ++k) {
                        f5 += f6 * Mistdata.valueNoise(f * f7 + (float)k * 3.1f, f2 * f7 - (float)k * 1.7f);
                        f6 *= 0.5f;
                        f7 *= 2.1f;
                    }
                    float f8 = Math.max(0.0f, Math.min(1.0f, f4 * (0.55f + 0.75f * f5)));
                    int n2 = Math.round(f8 * 255.0f);
                    class_10112.method_61941(j, i, n2 << 24 | n2 << 16 | n2 << 8 | n2);
                }
            }
            gpuDevice.createCommandEncoder().writeToTexture(puff, class_10112);
        }
        puffView = gpuDevice.createTextureView(puff);
        ubo = gpuDevice.createBuffer(Mistdata::lmbd$ensure$1, 136, 96L);
        data = BufferUtils.createByteBuffer(96);
    }

    private static float valueNoise(float f, float f2) {
        int n = (int)Math.floor(f);
        int n2 = (int)Math.floor(f2);
        float f3 = f - (float)n;
        float f4 = f2 - (float)n2;
        f3 = f3 * f3 * (3.0f - 2.0f * f3);
        f4 = f4 * f4 * (3.0f - 2.0f * f4);
        float f5 = Mistdata.hash(n, n2, 5);
        float f6 = Mistdata.hash(n + 1, n2, 5);
        float f7 = Mistdata.hash(n, n2 + 1, 5);
        float f8 = Mistdata.hash(n + 1, n2 + 1, 5);
        return f5 + (f6 - f5) * f3 + (f7 - f5) * f4 + (f5 - f6 - f7 + f8) * f3 * f4;
    }

    public static void release() {
        for (AutoCloseable autoCloseable : new AutoCloseable[]{puffView, puff, ubo}) {
            if (autoCloseable == null) continue;
            try {
                autoCloseable.close();
            }
            catch (Throwable throwable) {

            }
        }
        puffView = null;
        puff = null;
        ubo = null;
        data = null;
        fade = 0.0f;
    }

    private static String lmbd$ensure$1() {
        return "Kryzex Halloween mist";
    }

    private static String lmbd$ensure$0() {
        return "Kryzex mist puff";
    }

    private static String lmbd$draw$0() {
        return "Kryzex Halloween mist";
    }
}
