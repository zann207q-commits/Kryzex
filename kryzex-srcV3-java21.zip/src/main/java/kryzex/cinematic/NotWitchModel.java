package kryzex.cinematic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import kryzex.cinematic.VertexCount;
import org.joml.Matrix4f;

public final class NotWitchModel {
    public final String[] jointNames;
    public final int[] parent;
    public final Matrix4f[] bind;
    public final VertexCount witch;
    public final VertexCount broom;
    private final Map<String, Integer> byName = new HashMap<String, Integer>();

    private NotWitchModel(String[] stringArray, int[] nArray, Matrix4f[] matrix4fArray, VertexCount vertexCount, VertexCount vertexCount2) {
        this.jointNames = stringArray;
        this.parent = nArray;
        this.bind = matrix4fArray;
        this.witch = vertexCount;
        this.broom = vertexCount2;
        for (int i = 0; i < stringArray.length; ++i) {
            this.byName.put(stringArray[i], i);
        }
    }

    public int joint(String string) {
        Integer n = this.byName.get(string);
        if (n == null) {
            return -1;
        }
        int n2 = n;
        return n2;
    }

    public static NotWitchModel load(InputStream inputStream) throws IOException {
        try (DataInputStream dataInputStream = new DataInputStream(new BufferedInputStream(new GZIPInputStream(inputStream), 65536));){
            float[] object;
            if (dataInputStream.readInt() != 1264012593) {
                throw new IOException("not a witch model");
            }
            int n = dataInputStream.readShort();
            String[] stringArray = new String[n];
            int[] nArray = new int[n];
            Matrix4f[] matrix4fArray = new Matrix4f[n];
            for (int i = 0; i < n; ++i) {
                stringArray[i] = dataInputStream.readUTF();
                nArray[i] = dataInputStream.readShort();
                object = new float[16];
                for (int j = 0; j < 16; ++j) {
                    object[j] = dataInputStream.readFloat();
                }
                matrix4fArray[i] = new Matrix4f().set((float[])object);
            }
            VertexCount vertexCount = NotWitchModel.readMesh(dataInputStream);
            VertexCount object2 = NotWitchModel.readMesh(dataInputStream);
            NotWitchModel notWitchModel = new NotWitchModel(stringArray, nArray, matrix4fArray, vertexCount, object2);
            return notWitchModel;
        }
    }

    private static VertexCount readMesh(DataInputStream dataInputStream) throws IOException {
        int n;
        int n2 = dataInputStream.readInt();
        float[] fArray = new float[n2 * 3];
        byte[] byArray = new byte[n2 * 3];
        float[] fArray2 = new float[n2 * 2];
        byte[] byArray2 = new byte[n2 * 4];
        short[] sArray = new short[n2 * 4];
        for (n = 0; n < n2; ++n) {
            int n3;
            fArray[n * 3] = dataInputStream.readFloat();
            fArray[n * 3 + 1] = dataInputStream.readFloat();
            fArray[n * 3 + 2] = dataInputStream.readFloat();
            byArray[n * 3] = dataInputStream.readByte();
            byArray[n * 3 + 1] = dataInputStream.readByte();
            byArray[n * 3 + 2] = dataInputStream.readByte();
            fArray2[n * 2] = dataInputStream.readFloat();
            fArray2[n * 2 + 1] = dataInputStream.readFloat();
            for (n3 = 0; n3 < 4; ++n3) {
                byArray2[n * 4 + n3] = dataInputStream.readByte();
            }
            for (n3 = 0; n3 < 4; ++n3) {
                sArray[n * 4 + n3] = dataInputStream.readShort();
            }
        }
        n = dataInputStream.readInt();
        VertexCount vertexCount = new VertexCount(n2, n);
        System.arraycopy(fArray, 0, vertexCount.pos, 0, fArray.length);
        System.arraycopy(byArray, 0, vertexCount.normal, 0, byArray.length);
        System.arraycopy(fArray2, 0, vertexCount.uv, 0, fArray2.length);
        System.arraycopy(byArray2, 0, vertexCount.joints, 0, byArray2.length);
        System.arraycopy(sArray, 0, vertexCount.weights, 0, sArray.length);
        for (int i = 0; i < n; ++i) {
            vertexCount.indices[i] = dataInputStream.readInt();
        }
        return vertexCount;
    }
}
