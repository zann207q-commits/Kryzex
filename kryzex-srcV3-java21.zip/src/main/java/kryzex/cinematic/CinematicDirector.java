package kryzex.cinematic;

import kryzex.cinematic.Ambience;
import kryzex.cinematic.BarsWanted;
import kryzex.cinematic.InputLocked;
import kryzex.cinematic.Mistdata;
import kryzex.cinematic.CinematicPhase;
import kryzex.cinematic.HalloweenParticles;
import kryzex.cinematic.Skydata;
import kryzex.cinematic.UnderValid;
import kryzex.cinematic.WelcomeKryzexClient;
import kryzex.cinematic.WitchActor;
import kryzex.client.KryzexClient;
import kryzex.fx.TotemUndying;
import kryzex.gui.ClickGuiScreen;
import kryzex.gui.GuiAudio;
import kryzex.gui.Muted;
import kryzex.gui.Theme;
import kryzex.modules.client.KryzexPlus;
import kryzex.modules.render.Halloween;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_638;

public final class CinematicDirector {
    public static final float LOCK_SECONDS = 20.0f;
    private static CinematicPhase phase = CinematicPhase.IDLE;
    private static float phaseT;
    private static float lockLeft;
    private static long lastNanos;
    private static class_638 lastWorld;
    private static boolean moduleOn;
    private static WelcomeKryzexClient welcome;
    public static float worstFrame;

    private CinematicDirector() {
    }

    public static CinematicPhase phase() {
        return phase;
    }

    public static void onModuleEnabled() {
        moduleOn = true;
        UnderValid.setWanted(true);
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1687 == null || class_3102.field_1724 == null) return;
        CinematicDirector.startEvent();
    }

    public static void onModuleDisabled() {
        moduleOn = false;
        UnderValid.setWanted(false);
        Ambience.stopEvent();
        if (phase == CinematicPhase.IDLE) return;
        CinematicDirector.abort();
    }

    public static void replayIntro() {
        class_310 class_3102 = class_310.method_1551();
        if (!moduleOn || phase != CinematicPhase.IDLE || class_3102.field_1687 == null || class_3102.field_1724 == null) return;
        CinematicDirector.startEvent();
    }

    public static boolean guiLocked() {
        if (phase != CinematicPhase.IDLE) return true;
        if (!(lockLeft > 0.0f)) return false;
        return true;
    }

    public static void lockedNotice() {
        int n = Math.max(1, (int)Math.ceil(Math.max(lockLeft, phase != CinematicPhase.IDLE ? 1.0f : 0.0f)));
        BarsWanted.notice((String)(phase == CinematicPhase.IDLE ? "Kryzex unlocks in " + n + "s" : "Kryzex unlocks after the Halloween intro"));
    }

    private static void startEvent() {
        ClickGuiScreen clickGuiScreen;
        class_310 class_3102 = class_310.method_1551();
        phase = CinematicPhase.CLOSING;
        phaseT = 0.0f;
        lockLeft = 20.0f;
        WitchActor.preload();
        Ambience.playEvent(CinematicDirector.eventVolume());
        ClickGuiScreen clickGuiScreen2 = clickGuiScreen = KryzexClient.INSTANCE != null ? KryzexClient.INSTANCE.GUI : null;
        if (clickGuiScreen != null && class_3102.field_1755 == clickGuiScreen) {
            clickGuiScreen.requestClose();
        }
        BarsWanted.cinematic(true);
    }

    private static float eventVolume() {
        try {
            return (float)(Halloween.eventVolume.getValue() / 100.0);
        }
        catch (Throwable throwable) {
            return 0.6f;
        }
    }

    static void titleFinished(WelcomeKryzexClient welcomeKryzexClient) {
        class_310 class_3102 = class_310.method_1551();
        if (phase != CinematicPhase.TITLE || welcomeKryzexClient != welcome) {
            return;
        }
        if (class_3102.field_1755 == welcomeKryzexClient) {
            class_3102.method_1507(null);
        }
        welcome = null;
        CinematicDirector.beginWitch();
    }

    private static void beginWitch() {
        worstFrame = 0.0f;
        phase = CinematicPhase.WITCH;
        phaseT = 0.0f;
        InputLocked.begin();
        if (WitchActor.start()) return;
        CinematicDirector.beginOutro();
    }

    private static void beginOutro() {
        phase = CinematicPhase.OUTRO;
        phaseT = 0.0f;
        InputLocked.release();
        BarsWanted.cinematic(false);
    }

    private static void abort() {
        class_310 class_3102 = class_310.method_1551();
        if (welcome != null) {
            if (class_3102.field_1755 == welcome) {
                class_3102.method_1507(null);
            }
            welcome = null;
        }
        if (WitchActor.running()) {
            WitchActor.hurry();
            phase = CinematicPhase.WITCH;
        } else {
            CinematicDirector.beginOutro();
        }
        lockLeft = Math.min(lockLeft, 1.5f);
    }

    public static void hardReset() {
        class_310 class_3102 = class_310.method_1551();
        if (welcome != null && class_3102.field_1755 == welcome) {
            class_3102.method_1507(null);
        }
        welcome = null;
        phase = CinematicPhase.IDLE;
        phaseT = 0.0f;
        lockLeft = 0.0f;
        InputLocked.reset();
        BarsWanted.reset();
        WitchActor.reset();
        HalloweenParticles.clear();
        Ambience.stopEvent();
    }

    public static void frame() {
        float f;
        class_310 class_3102 = class_310.method_1551();
        long l = System.nanoTime();
        float f2 = lastNanos == 0L ? 0.016f : Math.min(0.1f, (float)(l - lastNanos) / 1.0E9f);
        lastNanos = l;
        float f3 = f = class_3102.method_1493() ? 0.0f : f2;
        if (class_3102.field_1687 != lastWorld) {
            if (lastWorld != null) {
                CinematicDirector.hardReset();
                Skydata.release();
                Mistdata.release();
                HalloweenParticles.release();
            }
            lastWorld = class_3102.field_1687;
        }
        UnderValid.frame(f, class_3102);
        CinematicDirector.syncMenuMusic(class_3102);
        if (lockLeft > 0.0f) {
            lockLeft = Math.max(0.0f, lockLeft - f);
        }
        phaseT += f;
        if (phase == CinematicPhase.WITCH) {
            worstFrame = Math.max(worstFrame, f2);
        }
        switch (phase.ordinal()) {
            case 1: {
                boolean bl;
                boolean bl2 = bl = KryzexClient.INSTANCE == null || class_3102.field_1755 != KryzexClient.INSTANCE.GUI;
                if (class_3102.field_1687 == null) {
                    CinematicDirector.hardReset();
                    break;
                }
                if (!(bl && phaseT > 0.35f) && !(phaseT > 1.2f)) break;
                welcome = new WelcomeKryzexClient();
                class_3102.method_1507((class_437)welcome);
                phase = CinematicPhase.TITLE;
                phaseT = 0.0f;
                break;
            }
            case 2: {
                if (welcome == null || class_3102.field_1755 == welcome || !(phaseT > 0.5f)) break;
                welcome = null;
                CinematicDirector.beginWitch();
                break;
            }
            case 3: {
                WitchActor.update(f);
                if (!WitchActor.finished()) break;
                CinematicDirector.beginOutro();
                break;
            }
            case 4: {
                if (InputLocked.active() || !(phaseT > 1.2f)) break;
                phase = CinematicPhase.IDLE;
                WitchActor.reset();
                break;
            }
        }
        HalloweenParticles.update(f);
        TotemUndying.frame();
        InputLocked.update(f);
        BarsWanted.frame(f2);
    }

    private static void syncMenuMusic(class_310 class_3102) {
        boolean bl = false;
        float f = 0.35f;
        boolean bl2 = true;
        try {
            ClickGuiScreen clickGuiScreen = KryzexClient.INSTANCE != null ? KryzexClient.INSTANCE.GUI : null;
            bl = clickGuiScreen != null && clickGuiScreen.showing() && Theme.selected() == Theme.Halloween && KryzexPlus.halloweenMusic.getValue();
            f = (float)(KryzexPlus.halloweenVolume.getValue() / 100.0);
            bl2 = KryzexPlus.beatShake.getValue();
        }
        catch (Throwable throwable) {

        }
        float f2 = 1.0f;
        try {
            f2 = class_3102.field_1690.method_71978(class_3419.field_15250);
        }
        catch (Throwable throwable) {

        }
        Muted.requested(bl, f);
        Ambience.setBeatEnabled(bl2);
        Ambience.setEventVolume(CinematicDirector.eventVolume());
        GuiAudio.setMaster(f2);
    }
}
