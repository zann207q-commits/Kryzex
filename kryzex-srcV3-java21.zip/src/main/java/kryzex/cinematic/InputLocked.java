package kryzex.cinematic;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class InputLocked {
    private static boolean active;
    private static boolean inputLocked;
    private static float blend;
    private static boolean releasing;
    private static float yaw;
    private static float pitch;
    private static float yawVel;
    private static float pitchVel;
    private static class_243 target;
    private static float stiffness;
    private static float aimBias;
    private static float fov;
    private static float fovVel;
    private static float fovTarget;

    private InputLocked() {
    }

    public static void begin() {
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (class_7462 == null) {
            return;
        }
        if (!active) {
            yaw = class_7462.method_36454();
            pitch = class_7462.method_36455();
            yawVel = 0.0f;
            pitchVel = 0.0f;
            fov = 1.0f;
            fovVel = 0.0f;
            blend = 0.0f;
        }
        active = true;
        releasing = false;
        inputLocked = true;
        fovTarget = 1.0f;
    }

    public static void follow(class_243 class_2432, float f, float f2, float f3) {
        target = class_2432;
        stiffness = f;
        fovTarget = f2;
        aimBias = f3;
    }

    public static void release() {
        if (!active) return;
        releasing = true;
        fovTarget = 1.0f;
    }

    public static void reset() {
        active = false;
        releasing = false;
        inputLocked = false;
        blend = 0.0f;
        fov = 1.0f;
        fovTarget = 1.0f;
        target = null;
    }

    public static boolean active() {
        return active;
    }

    public static boolean inputLocked() {
        return inputLocked;
    }

    private static float wrap(float f) {
        if ((f %= 360.0f) >= 180.0f) {
            f -= 360.0f;
        }
        if (!(f < -180.0f)) return f;
        f += 360.0f;
        return f;
    }

    public static void update(float f) {
        if (!active) {
            return;
        }
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (class_7462 == null || class_3102.field_1687 == null) {
            InputLocked.reset();
            return;
        }
        if (f <= 0.0f) {
            return;
        }
        float f2 = releasing ? 0.0f : 1.0f;
        float f3 = f / (releasing ? 1.15f : 0.55f);
        float f4 = blend = blend < f2 ? Math.min(f2, blend + f3) : Math.max(f2, blend - f3);
        if (releasing && blend <= 0.0f) {
            active = false;
            releasing = false;
            inputLocked = false;
            fov = 1.0f;
            target = null;
            return;
        }
        if (target != null && !releasing) {
            class_243 class_2432 = class_7462.method_5836(1.0f);
            class_243 class_2433 = target.method_1020(class_2432);
            double d = Math.sqrt(class_2433.field_1352 * class_2433.field_1352 + class_2433.field_1350 * class_2433.field_1350);
            float f5 = (float)Math.toDegrees(Math.atan2(-class_2433.field_1352, class_2433.field_1350));
            float f6 = (float)(-Math.toDegrees(Math.atan2(class_2433.field_1351, Math.max(0.01, d))));
            f6 += aimBias;
            f6 = Math.max(-88.0f, Math.min(88.0f, f6));
            float f7 = stiffness;
            float f8 = 2.0f * (float)Math.sqrt(f7);
            int n = Math.max(1, (int)Math.ceil(f / 0.008f));
            float f9 = f / (float)n;
            for (int i = 0; i < n; ++i) {
                float f10 = InputLocked.wrap(f5 - yaw);
                yawVel += (f10 * f7 - yawVel * f8) * f9;
                yaw += yawVel * f9;
                pitchVel += ((f6 - pitch) * f7 - pitchVel * f8) * f9;
                pitch += pitchVel * f9;
            }
        }
        float f11 = 3.2f;
        float f12 = 2.0f * (float)Math.sqrt(f11) * 1.05f;
        fovVel += ((fovTarget - fov) * f11 - fovVel * f12) * f;
        fov += fovVel * f;
    }

    private static float weight() {
        float f = Math.max(0.0f, Math.min(1.0f, blend));
        return f * f * (3.0f - 2.0f * f);
    }

    public static float yaw(float f) {
        return active ? f + InputLocked.wrap(yaw - f) * InputLocked.weight() : f;
    }

    public static float pitch(float f) {
        return active ? f + (pitch - f) * InputLocked.weight() : f;
    }

    public static float fov(float f) {
        return active ? f * (1.0f + (fov - 1.0f) * InputLocked.weight()) : f;
    }

    static {
        stiffness = 8.0f;
        fov = 1.0f;
        fovTarget = 1.0f;
    }
}
