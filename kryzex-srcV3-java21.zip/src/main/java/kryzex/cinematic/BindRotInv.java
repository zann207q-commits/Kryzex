package kryzex.cinematic;

import kryzex.cinematic.NotWitchModel;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class BindRotInv {
    public final NotWitchModel asset;
    public final int count;
    private final Matrix4f[] restLocal;
    private final Matrix4f[] invBind;
    private final Quaternionf[] bindRot;
    private final Quaternionf[] bindRotInv;
    public final Matrix4f[] world;
    public final Matrix4f[] skin;
    public final Quaternionf[] rot;
    public final Vector3f rootOffset = new Vector3f();
    private final Quaternionf tmpQ = new Quaternionf();

    public BindRotInv(NotWitchModel notWitchModel) {
        this.asset = notWitchModel;
        this.count = notWitchModel.jointNames.length;
        this.restLocal = new Matrix4f[this.count];
        this.invBind = new Matrix4f[this.count];
        this.bindRot = new Quaternionf[this.count];
        this.bindRotInv = new Quaternionf[this.count];
        this.world = new Matrix4f[this.count];
        this.skin = new Matrix4f[this.count];
        this.rot = new Quaternionf[this.count];
        for (int i = 0; i < this.count; ++i) {
            Matrix4f matrix4f = notWitchModel.bind[i];
            this.invBind[i] = new Matrix4f((Matrix4fc)matrix4f).invert();
            int n = notWitchModel.parent[i];
            this.restLocal[i] = n < 0 ? new Matrix4f((Matrix4fc)matrix4f) : new Matrix4f((Matrix4fc)notWitchModel.bind[n]).invert().mul((Matrix4fc)matrix4f);
            this.bindRot[i] = matrix4f.getNormalizedRotation(new Quaternionf());
            this.bindRotInv[i] = new Quaternionf((Quaternionfc)this.bindRot[i]).invert();
            this.world[i] = new Matrix4f((Matrix4fc)matrix4f);
            this.skin[i] = new Matrix4f();
            this.rot[i] = new Quaternionf();
        }
    }

    public void reset() {
        for (Quaternionf quaternionf : this.rot) {
            quaternionf.identity();
        }
        this.rootOffset.zero();
    }

    public void solve() {
        for (int i = 0; i < this.count; ++i) {
            Matrix4f matrix4f = this.world[i];
            int n = this.asset.parent[i];
            if (n < 0) {
                matrix4f.translation((Vector3fc)this.rootOffset).mul((Matrix4fc)this.restLocal[i]);
            } else {
                matrix4f.set((Matrix4fc)this.world[n]).mul((Matrix4fc)this.restLocal[i]);
            }
            Quaternionf quaternionf = this.rot[i];
            if (quaternionf.x != 0.0f || quaternionf.y != 0.0f || quaternionf.z != 0.0f) {
                this.tmpQ.set((Quaternionfc)this.bindRotInv[i]).mul((Quaternionfc)quaternionf).mul((Quaternionfc)this.bindRot[i]);
                matrix4f.rotate((Quaternionfc)this.tmpQ);
            }
            this.skin[i].set((Matrix4fc)matrix4f).mul((Matrix4fc)this.invBind[i]);
        }
    }

    public Vector3f position(int n, Vector3f vector3f) {
        return this.world[n].getTranslation(vector3f);
    }

    public Vector3f bindPosition(int n, Vector3f vector3f) {
        return this.asset.bind[n].getTranslation(vector3f);
    }
}
