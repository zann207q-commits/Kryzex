package kryzex.cinematic;

public final class VertexCount {
    public final int vertexCount;
    public final float[] pos;
    public final byte[] normal;
    public final float[] uv;
    public final byte[] joints;
    public final short[] weights;
    public final int[] indices;

    VertexCount(int n, int n2) {
        this.vertexCount = n;
        this.pos = new float[n * 3];
        this.normal = new byte[n * 3];
        this.uv = new float[n * 2];
        this.joints = new byte[n * 4];
        this.weights = new short[n * 4];
        this.indices = new int[n2];
    }
}
