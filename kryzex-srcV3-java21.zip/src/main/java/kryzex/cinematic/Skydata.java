package kryzex.cinematic;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import kryzex.cinematic.HalloweenShaders;
import kryzex.cinematic.UnderValid;
import net.minecraft.class_10789;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;
import org.lwjgl.BufferUtils;

public final class Skydata {
    private static final int UBO_SIZE = 144;
    public static final RenderPipeline PIPELINE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"r87f4560b4c09f4", (String)"pipeline/hw_sky")).withVertexShader(HalloweenShaders.SKY).withFragmentShader(HalloweenShaders.SKY).withUniform("SkyData", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
    private static final Matrix4f VIEW = new Matrix4f();
    private static final Matrix4f PROJ = new Matrix4f();
    private static boolean haveMatrices;
    private static GpuBuffer ubo;
    private static ByteBuffer data;

    private Skydata() {
    }

    public static void capture(Matrix4f matrix4f, Matrix4f matrix4f2) {
        VIEW.set((Matrix4fc)matrix4f);
        PROJ.set((Matrix4fc)matrix4f2);
        haveMatrices = true;
    }

    public static Matrix4f projection() {
        return PROJ;
    }

    public static Matrix4f view() {
        return VIEW;
    }

    public static boolean hasMatrices() {
        return haveMatrices;
    }

    public static void draw() {
        float f = UnderValid.strength() * UnderValid.nightness();
        class_310 class_3102 = class_310.method_1551();
        if (f <= 0.004f || !haveMatrices || class_3102.field_1687 == null || !HalloweenShaders.ready(PIPELINE)) {
            return;
        }
        try {
            if (ubo == null) {
                ubo = RenderSystem.getDevice().createBuffer(Skydata::lmbd$draw$0, 136, 144L);
                data = BufferUtils.createByteBuffer(144);
            }
            Matrix4f matrix4f = new Matrix4f((Matrix4fc)PROJ).mul((Matrix4fc)VIEW).invert();
            Vector4f vector4f = UnderValid.moonDir();
            float f2 = 1.0f - class_3102.field_1687.method_8430(1.0f);
            float f3 = ((float)(class_3102.field_1687.method_75260() % 240000L) + class_3102.method_61966().method_60637(false)) / 20.0f;
            data.clear();
            matrix4f.get(0, data);
            Skydata.put4(data, 64, vector4f.x, vector4f.y, vector4f.z, vector4f.w * f2);
            Skydata.put4(data, 80, f * 0.94f, f3, 0.0f, 0.0f);
            Skydata.put4(data, 96, 0.03f, 0.015f, 0.05f, 1.0f);
            Skydata.put4(data, 112, 0.135f, 0.066f, 0.165f, 1.0f);
            Skydata.put4(data, 128, 0.32f, 0.11f, 0.035f, 0.55f);
            data.position(0);
            data.limit(144);
            CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
            commandEncoder.writeToBuffer(ubo.slice(), data);
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : class_3102.method_1522().method_71639();
            try (RenderPass renderPass = commandEncoder.createRenderPass(Skydata::lmbd$draw$1, gpuTextureView, OptionalInt.empty());){
                renderPass.setPipeline(PIPELINE);
                renderPass.setUniform("SkyData", ubo);
                renderPass.draw(0, 3);
                return;
            }
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: Halloween sky skipped: " + String.valueOf(throwable));
        }
    }

    static void put4(ByteBuffer byteBuffer, int n, float f, float f2, float f3, float f4) {
        byteBuffer.putFloat(n, f);
        byteBuffer.putFloat(n + 4, f2);
        byteBuffer.putFloat(n + 8, f3);
        byteBuffer.putFloat(n + 12, f4);
    }

    public static void release() {
        if (ubo != null) {
            ubo.close();
            ubo = null;
        }
        data = null;
    }

    private static String lmbd$draw$1() {
        return "Kryzex Halloween sky";
    }

    private static String lmbd$draw$0() {
        return "Kryzex Halloween sky";
    }
}
