package kryzex.cinematic;

import net.minecraft.class_243;
import net.minecraft.class_3414;

final class Volume {
    final class_3414 event;
    final class_243 at;
    final float volume;
    final float pitch;
    float delay;

    Volume(class_3414 class_34142, class_243 class_2432, float f, float f2, float f3) {
        this.event = class_34142;
        this.at = class_2432;
        this.volume = f;
        this.pitch = f2;
        this.delay = f3;
    }
}
