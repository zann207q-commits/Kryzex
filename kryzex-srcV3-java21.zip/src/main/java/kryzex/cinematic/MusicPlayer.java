package kryzex.cinematic;

import it.unimi.dsi.fastutil.floats.FloatConsumer;
import java.io.BufferedInputStream;
import java.io.InputStream;
import kryzex.cinematic.Ambience;
import net.minecraft.class_4228;

final class MusicPlayer
implements FloatConsumer {
    final String path;
    final boolean loop;
    volatile boolean playing;
    volatile boolean stopping;
    volatile float level;
    boolean ended;
    float target;
    float rateUp;
    float rateDown;
    long frames;
    private class_4228 stream;
    private float[] buf = new float[8192];
    private int len;
    private int pos;
    private float gain = -1.0f;
    private float lp1;
    private float lp2;
    private float energySlow = 1.0E-4f;
    private float energyBlock;
    private int energyCount;
    private long lastBeat = -44100L;

    MusicPlayer(String string, boolean bl) {
        this.path = string;
        this.loop = bl;
    }

    void resume() {
        if (this.stream == null || this.ended) {
            this.open();
            return;
        } else {
            this.playing = true;
            this.stopping = false;
        }
    }

    void pause() {
        this.playing = false;
        this.stopping = false;
        this.level = 0.0f;
    }

    void open() {
        this.closeStream();
        try {
            InputStream inputStream = Ambience.class.getResourceAsStream(this.path);
            if (inputStream == null) {
                System.err.println("Kryzex: missing " + this.path);
                return;
            }
            this.stream = new class_4228((InputStream)new BufferedInputStream(inputStream, 32768));
            this.playing = true;
            this.stopping = false;
            this.ended = false;
            this.level = 0.0f;
            this.frames = 0L;
            this.len = 0;
            this.pos = 0;
            this.gain = -1.0f;
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Kryzex: could not open " + this.path + ": " + String.valueOf(throwable));
            this.closeStream();
            this.playing = false;
        }
    }

    void close() {
        this.closeStream();
        this.playing = false;
        this.stopping = false;
        this.level = 0.0f;
        this.len = 0;
        this.pos = 0;
    }

    private void closeStream() {
        if (this.stream == null) return;
        try {
            this.stream.close();
        }
        catch (Throwable throwable) {

        }
        this.stream = null;
    }

    public void accept(float f) {
        if (this.len == this.buf.length) {
            float[] fArray = new float[this.buf.length * 2];
            System.arraycopy(this.buf, 0, fArray, 0, this.len);
            this.buf = fArray;
        }
        this.buf[this.len++] = f;
    }

    private boolean ensure() {
        while (this.pos + 1 >= this.len) {
            if (this.stream == null) {
                return false;
            }
            this.len = 0;
            this.pos = 0;
            try {
                if (this.stream.method_59758((FloatConsumer)this)) continue;
                if (!this.loop) {
                    this.ended = true;
                    return false;
                }
                this.closeStream();
                InputStream inputStream = Ambience.class.getResourceAsStream(this.path);
                if (inputStream == null) {
                    return false;
                }
                this.stream = new class_4228((InputStream)new BufferedInputStream(inputStream, 32768));
            }
            catch (Throwable throwable) {
                System.err.println("Kryzex: music decode failed: " + String.valueOf(throwable));
                this.ended = true;
                this.closeStream();
                return false;
            }
        }
        return true;
    }

    void mix(float[] fArray, int n, float f, boolean bl, long l) {
        if (this.gain < 0.0f) {
            this.gain = f;
        }
        for (int i = 0; i < n; ++i) {
            if (this.target <= 0.0f && this.level <= 0.0f) {
                return;
            }
            if (!this.ensure()) {
                this.level = 0.0f;
                return;
            }
            float f2 = this.buf[this.pos++];
            float f3 = this.buf[this.pos++];
            ++this.frames;
            this.level = this.target > this.level ? Math.min(this.target, this.level + this.rateUp) : Math.max(this.target, this.level - this.rateDown);
            this.gain += (f - this.gain) * 2.0E-4f;
            float f4 = Ambience.smoothLevel(this.level) * this.gain;
            fArray[i * 2] = fArray[i * 2] + f2 * f4;
            fArray[i * 2 + 1] = fArray[i * 2 + 1] + f3 * f4;
            if (!bl) continue;
            float f5 = (f2 + f3) * 0.5f;
            this.lp1 += 0.017f * (f5 - this.lp1);
            this.lp2 += 0.017f * (this.lp1 - this.lp2);
            this.energyBlock += this.lp2 * this.lp2;
            ++this.energyCount;
            if (this.energyCount != 256) continue;
            float f6 = this.energyBlock / 256.0f;
            this.energyBlock = 0.0f;
            this.energyCount = 0;
            long l2 = l + (long)i;
            float f7 = f6 / (this.energySlow + 1.0E-7f);
            this.energySlow += (f6 - this.energySlow) * 0.0083f;
            if (!(f7 > 1.55f) || !((float)(l2 - this.lastBeat) > 10584.0f) || !(f6 > 2.0E-5f)) continue;
            this.lastBeat = l2;
            float f8 = Math.min(1.0f, (f7 - 1.55f) / 1.6f + 0.35f);
            Ambience.recordBeat(l2, f8);
        }
    }
}
