package kryzex.cinematic;

public final class DissolveScale {
    public float alpha = 1.0f;
    public float emissive;
    public int block;
    public int sky;
    public float worldLight = 0.8f;
    public float rim;
    public float dissolveAt;
    public float dissolveEdge = 0.09f;
    public float dissolveMode;
    public float dissolveScale = 9.0f;
    public final float[] dissolveColor = new float[]{1.0f, 0.52f, 0.18f, 2.4f};
    public final float[] keyDir = new float[]{0.2f, 0.8f, 0.3f, 1.0f};
    public final float[] keyColor = new float[]{0.62f, 0.64f, 0.92f};
    public final float[] fillColor = new float[]{1.0f, 0.52f, 0.2f, 0.3f};
    public final float[] ambient = new float[]{0.17f, 0.14f, 0.22f};
    public final float[] rimColor = new float[]{0.6f, 0.55f, 0.95f};
}
