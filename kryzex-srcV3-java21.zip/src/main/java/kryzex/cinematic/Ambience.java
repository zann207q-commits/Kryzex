package kryzex.cinematic;

import kryzex.cinematic.MusicPlayer;
import kryzex.gui.GuiAudio;

public final class Ambience {
    static final int SR = 44100;
    private static final float MENU_FADE_IN = 1.8f;
    private static final float MENU_FADE_OUT = 5.0f;
    private static final float EVENT_FADE_IN = 2.6f;
    private static final float EVENT_HOLD = 56.0f;
    private static final float EVENT_FADE_OUT = 5.5f;
    static final MusicPlayer MENU = new MusicPlayer("/assets/r87f4560b4c09f4/r9fcf91052858cc/halloween_menu.ogg", true);
    static final MusicPlayer EVENT = new MusicPlayer("/assets/r87f4560b4c09f4/r9fcf91052858cc/halloween_event.ogg", false);
    private static volatile boolean menuWanted;
    private static volatile float menuVolume;
    private static volatile float eventVolume;
    private static volatile boolean eventRequested;
    private static volatile boolean eventStopRequested;
    private static volatile boolean beatEnabled;
    private static final int BEATS = 32;
    private static long[] beatFrame;
    private static float[] beatStrength;
    private static volatile int beatHead;

    private Ambience() {
    }

    public static void setMenuWanted(boolean bl, float f) {
        menuVolume = Math.max(0.0f, Math.min(1.0f, f));
        if (bl != menuWanted) {
            menuWanted = bl;
        }
        if (!bl && !Ambience.MENU.playing) return;
        GuiAudio.wake();
    }

    public static void setEventVolume(float f) {
        eventVolume = Math.max(0.0f, Math.min(1.0f, f));
    }

    public static void playEvent(float f) {
        Ambience.setEventVolume(f);
        if (Ambience.EVENT.playing && !Ambience.EVENT.stopping) return;
        eventRequested = true;
        GuiAudio.wake();
    }

    public static void stopEvent() {
        if (!Ambience.EVENT.playing) return;
        eventStopRequested = true;
        GuiAudio.wake();
    }

    public static boolean eventPlaying() {
        if (Ambience.EVENT.playing) return true;
        if (!eventRequested) return false;
        return true;
    }

    public static boolean menuPlaying() {
        return Ambience.MENU.playing;
    }

    public static boolean active() {
        if (Ambience.MENU.playing) return true;
        if (Ambience.EVENT.playing) return true;
        if (menuWanted) return true;
        if (!eventRequested) return false;
        return true;
    }

    public static boolean replacesAmbience() {
        if (menuWanted) return true;
        if (!Ambience.MENU.playing) return false;
        if (!(Ambience.MENU.level > 0.02f)) return false;
        return true;
    }

    public static void setBeatEnabled(boolean bl) {
        beatEnabled = bl;
    }

    public static float beat() {
        if (!Ambience.MENU.playing || !beatEnabled) return 0.0f;
        long l = GuiAudio.heardFrame();
        float f = 0.0f;
        int n = beatHead;
        for (int i = 0; i < 32; ++i) {
            float f2;
            int n2 = (n - 1 - i + 32) % 32;
            float f3 = beatStrength[n2];
            if (f3 <= 0.0f || (f2 = (float)(l - beatFrame[n2]) / 44100.0f) < 0.0f) continue;
            if (f2 > 1.2f) return f * Ambience.smoothLevel(Ambience.MENU.level);
            float f4 = Math.min(1.0f, f2 / 0.035f);
            f4 = f4 * f4 * (3.0f - 2.0f * f4);
            f = Math.max(f, f3 * f4 * (float)Math.exp(-f2 / 0.22f));
        }
        return f * Ambience.smoothLevel(Ambience.MENU.level);
    }

    public static float smoothLevel(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return f * f * (3.0f - 2.0f * f);
    }

    public static void mix(float[] fArray, int n, float f, long l) {
        boolean bl;
        MusicPlayer musicPlayer = MENU;
        boolean bl2 = bl = menuWanted && !Ambience.EVENT.playing;
        if (bl && !musicPlayer.playing) {
            musicPlayer.resume();
        }
        if (musicPlayer.playing) {
            musicPlayer.target = bl ? 1.0f : 0.0f;
            musicPlayer.rateUp = 1.2597631E-5f;
            musicPlayer.rateDown = 1.0f / (44100.0f * (Ambience.EVENT.playing ? 2.0f : 5.0f));
            musicPlayer.mix(fArray, n, menuVolume * f, true, l);
            if (!bl && musicPlayer.level <= 0.0f) {
                musicPlayer.pause();
            }
        }
        MusicPlayer musicPlayer2 = EVENT;
        if (eventRequested) {
            eventRequested = false;
            if (!musicPlayer2.playing) {
                musicPlayer2.open();
            }
            musicPlayer2.stopping = false;
            musicPlayer2.target = 1.0f;
        }
        if (eventStopRequested) {
            eventStopRequested = false;
            if (musicPlayer2.playing) {
                musicPlayer2.stopping = true;
            }
        }
        if (!musicPlayer2.playing) return;
        float f2 = (float)musicPlayer2.frames / 44100.0f;
        if (f2 >= 58.6f) {
            musicPlayer2.stopping = true;
        }
        musicPlayer2.target = musicPlayer2.stopping ? 0.0f : 1.0f;
        musicPlayer2.rateUp = 8.721438E-6f;
        musicPlayer2.rateDown = 1.0f / (44100.0f * (f2 >= 56.0f ? 5.5f : 2.4f));
        musicPlayer2.mix(fArray, n, eventVolume * f, false, l);
        if (!(musicPlayer2.stopping && musicPlayer2.level <= 0.0f) && !musicPlayer2.ended) return;
        musicPlayer2.close();
    }

    static void recordBeat(long l, float f) {
        int n = beatHead;
        Ambience.beatFrame[n] = l;
        Ambience.beatStrength[n] = f;
        beatHead = (n + 1) % 32;
    }

    public static void closeAll() {
        MENU.close();
        EVENT.close();
        menuWanted = false;
        eventRequested = false;
        eventStopRequested = false;
    }

    static {
        menuVolume = 0.35f;
        eventVolume = 0.6f;
        beatEnabled = true;
        beatFrame = new long[32];
        beatStrength = new float[32];
    }
}
